import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { parseFeed, mergeNews, createNewsFeed } from '../server/newsFeed.js';
import { mapHeadlines } from '../src/services/news.js';

const RSS = `<?xml version="1.0"?><rss><channel><title>x</title>
<item><title><![CDATA[Fed's Powell: rates stay higher for longer]]></title><link>https://example.com/a?utm=1</link><pubDate>Mon, 23 Nov 2026 16:00:00 GMT</pubDate></item>
<item><title>ECB holds rates &amp; signals patience</title><link>https://example.com/b</link><pubDate>Mon, 23 Nov 2026 15:00:00 GMT</pubDate></item>
<item><title>bad link item here</title><link>javascript:alert(1)</link></item>
<item><title>x</title><link>https://example.com/short</link></item></channel></rss>`;
const ATOM = `<feed><entry><title>Gold jumps after US CPI surprise</title><link href="https://other.example/g"/><updated>2026-11-23T16:30:00Z</updated></entry></feed>`;

test('RSS and Atom are parsed; unsafe links and junk titles are dropped; entities decoded', () => {
  const a = parseFeed(RSS, 'A'); assert.equal(a.length, 2);
  assert.equal(a[0].title, "Fed's Powell: rates stay higher for longer"); assert.equal(a[1].title, 'ECB holds rates & signals patience');
  assert.equal(a[0].time, Date.parse('2026-11-23T16:00:00Z'));
  const b = parseFeed(ATOM, 'B'); assert.equal(b.length, 1); assert.equal(b[0].url, 'https://other.example/g');
});

test('merge: newest first and one copy of the same story', () => {
  const a = parseFeed(RSS, 'A'); const dup = parseFeed(RSS.replace('https://example.com/b', 'https://mirror.example/b'), 'C');
  const m = mergeNews([a, parseFeed(ATOM, 'B'), dup]);
  assert.deepEqual(m.map((x) => x.title), ['Gold jumps after US CPI surprise', "Fed's Powell: rates stay higher for longer", 'ECB holds rates & signals patience']);
});

test('one failing source never empties the list; the last good list survives a restart', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'news-'));
  let t = 1_000_000; const now = () => t; let down = false;
  const fetchFn = async (u) => { if (u.includes('bad') || down) return { ok: false, status: 403, text: async () => '' }; return { ok: true, status: 200, text: async () => (u.includes('atom') ? ATOM : RSS) }; };
  const sources = [{ id: 'a', name: 'A', url: 'https://a/rss' }, { id: 'b', name: 'B', url: 'https://bad/rss' }, { id: 'c', name: 'C', url: 'https://c/atom' }];
  const logs = []; const f = createNewsFeed({ dataDir: dir, sources, fetchFn, now, log: { warn: (m) => logs.push(m) } });
  const r = await f.headlines(); assert.equal(r.items.length, 3); assert.equal(r.sources.find((s) => s.id === 'b').ok, false); assert.ok(logs.some((m) => /\[news\] b failed/.test(m)));
  down = true; t += 10 * 60_000; const r2 = await f.headlines(); assert.equal(r2.items.length, 3);   // everything down: last good list
  const f2 = createNewsFeed({ dataDir: dir, sources, fetchFn, now, log: { warn() {} } });
  assert.equal((await f2.headlines()).items.length, 3);   // a restart with every source down still has the saved list
  fs.rmSync(dir, { recursive: true, force: true });
});

test('the page maps server headlines to its item shape with safe links', () => {
  const now = Date.parse('2026-11-23T16:40:00Z');
  const items = mapHeadlines({ items: [{ id: '1', title: 'Fed holds', url: 'https://x.example/1', source: 'FXStreet', time: now - 5 * 60000 }, { id: '2', title: 'Bad', url: 'javascript:1', source: 'S', time: null }] }, now);
  assert.equal(items[0].ago, '5 min ago'); assert.equal(items[0].source, 'FXStreet');
  assert.equal(items[1].url, 'https://investinglive.com');
});
