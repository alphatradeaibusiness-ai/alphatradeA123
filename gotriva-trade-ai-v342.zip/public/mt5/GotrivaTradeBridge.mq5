//+------------------------------------------------------------------+
//|                                          GotrivaTradeBridge.mq5    |
//|   Bridge between MetaTrader 5 and the GOTRIVA TRADE AI server.      |
//|                                                                  |
//|   What it does                                                   |
//|   - Checks that this terminal is logged in to the MT5 account    |
//|     number and server you entered (and refuses anything else).   |
//|   - Every few seconds: sends a heartbeat (balance, equity, open  |
//|     positions) to your GOTRIVA TRADE AI server and receives queued  |
//|     orders, using WebRequest over HTTPS.                         |
//|   - Executes an order ONLY when "Allow trading" is on, within    |
//|     your maximum lot, and reports the result (ticket, retcode).  |
//|   - Documents every command and result in                         |
//|     MQL5\Files\GotrivaTradeBridge\log-YYYYMMDD.csv and on the      |
//|     server (website page "MetaTrader 5").                        |
//|                                                                  |
//|   Why there is no password input                                 |
//|   The EA runs inside your terminal, which is ALREADY logged in   |
//|   to your broker. Your MT5 password is never needed, and sending |
//|   it to any website would put your account at risk. The link is  |
//|   made with a one-time "pairing token" from the website instead, |
//|   bound to your account number and server.                       |
//|                                                                  |
//|   Setup (once)                                                   |
//|   1. Website -> MetaTrader 5 page -> enter account number and    |
//|      server -> "Create pairing token" -> copy the token.         |
//|   2. MT5 -> Tools -> Options -> Expert Advisors -> tick           |
//|      "Allow WebRequest for listed URL" and add your site URL     |
//|      (exactly the same as InpBaseUrl below).                     |
//|   3. Copy this file to MQL5\Experts, compile it in MetaEditor    |
//|      (F7), attach it to any chart, fill the inputs, and enable   |
//|      "Algo Trading" if you want it to execute orders.            |
//+------------------------------------------------------------------+
#property copyright "GOTRIVA TRADE AI"
#property version   "1.00"
#property description "GOTRIVA TRADE AI <-> MetaTrader 5 bridge (WebRequest, pairing token, documented orders)."

#include <Trade\Trade.mqh>

//--- inputs ---------------------------------------------------------
input group "Connection"
input string InpBaseUrl       = "https://your-site.example";   // Site URL (also add it in Tools > Options > Expert Advisors)
input long   InpAccount       = 0;                              // MT5 account number (رقم حساب MT5)
input string InpServer        = "";                             // MT5 server name, e.g. "MetaQuotes-Demo" (اسم الخادم)
input string InpToken         = "";                             // Pairing token from the website (رمز الربط) - NOT your password
input int    InpPollSeconds   = 2;                              // Poll interval (seconds, 1-60)
input int    InpTimeoutMs     = 5000;                           // WebRequest timeout (ms)

input group "Trading safety"
input bool   InpAllowTrading  = false;                          // Allow executing orders from the website
input double InpMaxLot        = 0.10;                           // Maximum volume per order (lots)
input int    InpSlippagePts   = 20;                             // Max deviation (points)
input ulong  InpMagic         = 20261102;                       // Magic number of bridge orders
input string InpSymbolSuffix  = "";                             // Broker symbol suffix, e.g. ".m" or "pro"

//--- connection state ----------------------------------------------
enum ENUM_BRIDGE_STATE
  {
   BRIDGE_STARTING = 0,
   BRIDGE_CONNECTED,
   BRIDGE_NO_BROKER,          // terminal not connected to the broker
   BRIDGE_URL_NOT_ALLOWED,    // WebRequest URL not in Tools > Options > Expert Advisors
   BRIDGE_AUTH_FAILED,        // wrong token / account / server
   BRIDGE_SERVER_DOWN,        // site unreachable or error
   BRIDGE_WRONG_ACCOUNT       // terminal logged in to another account / server
  };

CTrade            g_trade;
ENUM_BRIDGE_STATE g_state        = BRIDGE_STARTING;
string            g_stateMsg     = "";
datetime          g_lastOk       = 0;
int               g_failures     = 0;
datetime          g_nextTry      = 0;
bool              g_hello        = false;
string            g_done[];                 // command ids already executed (never twice)
int               g_executed     = 0;

//+------------------------------------------------------------------+
int OnInit()
  {
   if(StringLen(InpToken) < 20 || StringFind(InpToken, "mt5_") != 0)
     { Alert("GotrivaTradeBridge: paste the pairing token from the website (it starts with mt5_)."); return(INIT_PARAMETERS_INCORRECT); }
   if(InpAccount <= 0 || StringLen(InpServer) < 2)
     { Alert("GotrivaTradeBridge: enter your MT5 account number and server name."); return(INIT_PARAMETERS_INCORRECT); }
   if(StringFind(InpBaseUrl, "https://") != 0 && StringFind(InpBaseUrl, "http://localhost") != 0)
     { Alert("GotrivaTradeBridge: the site URL must start with https://"); return(INIT_PARAMETERS_INCORRECT); }
   if(!CheckAccount())
      return(INIT_FAILED);

   g_trade.SetExpertMagicNumber(InpMagic);
   g_trade.SetDeviationInPoints(InpSlippagePts);
   g_trade.SetTypeFillingBySymbol(_Symbol);
   EventSetTimer(MathMax(1, MathMin(60, InpPollSeconds)));
   LogLine("", "start", "", 0, "ok", "", "trading " + (InpAllowTrading ? "on" : "off") + ", max lot " + DoubleToString(InpMaxLot, 2));
   ShowStatus();
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   LogLine("", "stop", "", 0, "ok", "", "reason " + IntegerToString(reason));
   Comment("");
  }

void OnTimer()
  {
   if(!CheckConnection()) { ShowStatus(); return; }
   if(!g_hello) { g_hello = SendHello(); ShowStatus(); return; }
   Poll();
   ShowStatus();
  }

//+------------------------------------------------------------------+
//| The terminal must be logged in to exactly the entered account.   |
//+------------------------------------------------------------------+
bool CheckAccount()
  {
   long   login  = AccountInfoInteger(ACCOUNT_LOGIN);
   string server = AccountInfoString(ACCOUNT_SERVER);
   if(login == 0) return(true);   // not logged in yet: checked again on every timer tick
   if(login != InpAccount || StringCompare(server, InpServer, false) != 0)
     {
      SetState(BRIDGE_WRONG_ACCOUNT, "Terminal is on " + IntegerToString(login) + " @ " + server + ", inputs say " + IntegerToString(InpAccount) + " @ " + InpServer);
      Alert("GotrivaTradeBridge: ", g_stateMsg);
      return(false);
     }
   return(true);
  }

//+------------------------------------------------------------------+
//| Connection status: broker link, account match, server reachability|
//| Returns true when it is OK to talk to the server now.            |
//+------------------------------------------------------------------+
bool CheckConnection()
  {
   if(!TerminalInfoInteger(TERMINAL_CONNECTED)) { SetState(BRIDGE_NO_BROKER, "Terminal is not connected to the broker"); return(false); }
   if(AccountInfoInteger(ACCOUNT_LOGIN) != InpAccount || StringCompare(AccountInfoString(ACCOUNT_SERVER), InpServer, false) != 0)
     { SetState(BRIDGE_WRONG_ACCOUNT, "Logged in to a different account/server than the inputs"); g_hello = false; return(false); }
   if(g_state == BRIDGE_AUTH_FAILED) return(false);                 // fix the token and re-attach the EA
   if(g_nextTry > TimeLocal()) return(false);                       // back-off after failures
   return(true);
  }

bool TradingPermitted()
  {
   return(InpAllowTrading
          && TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)
          && MQLInfoInteger(MQL_TRADE_ALLOWED)
          && AccountInfoInteger(ACCOUNT_TRADE_ALLOWED)
          && AccountInfoInteger(ACCOUNT_TRADE_EXPERT));
  }

void SetState(ENUM_BRIDGE_STATE s, string msg)
  {
   if(s != g_state || msg != g_stateMsg) Print("GotrivaTradeBridge: ", StateName(s), " - ", msg);
   g_state = s; g_stateMsg = msg;
  }

string StateName(ENUM_BRIDGE_STATE s)
  {
   switch(s)
     {
      case BRIDGE_CONNECTED:       return("CONNECTED / متصل");
      case BRIDGE_NO_BROKER:       return("NO BROKER CONNECTION");
      case BRIDGE_URL_NOT_ALLOWED: return("WEBREQUEST URL NOT ALLOWED");
      case BRIDGE_AUTH_FAILED:     return("PAIRING REFUSED");
      case BRIDGE_SERVER_DOWN:     return("SERVER UNREACHABLE / غير متصل");
      case BRIDGE_WRONG_ACCOUNT:   return("WRONG ACCOUNT");
     }
   return("STARTING");
  }

void ShowStatus()
  {
   string last = g_lastOk > 0 ? TimeToString(g_lastOk, TIME_DATE | TIME_SECONDS) : "-";
   Comment("GOTRIVA TRADE AI bridge\n",
           "Status: ", StateName(g_state), "\n",
           (g_stateMsg != "" ? g_stateMsg + "\n" : ""),
           "Account: ", IntegerToString(InpAccount), " @ ", InpServer, "\n",
           "Trading from site: ", (TradingPermitted() ? "ON" : "OFF"), "  (max ", DoubleToString(InpMaxLot, 2), " lot)\n",
           "Last server contact: ", last, "   Orders executed: ", IntegerToString(g_executed));
  }

//+------------------------------------------------------------------+
//| HTTP                                                             |
//+------------------------------------------------------------------+
int Http(const string path, const string body, string &response)
  {
   char   data[], result[];
   string headers = "Content-Type: application/json\r\nX-Bridge-Token: " + InpToken + "\r\n";
   string resultHeaders;
   int n = StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(n > 0) ArrayResize(data, n - 1);                               // drop the terminating zero
   string url = InpBaseUrl;
   if(StringSubstr(url, StringLen(url) - 1) == "/") url = StringSubstr(url, 0, StringLen(url) - 1);
   ResetLastError();
   int code = WebRequest("POST", url + path, headers, InpTimeoutMs, data, result, resultHeaders);
   response = CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8);
   if(code == -1)
     {
      int err = GetLastError();
      if(err == 4014) SetState(BRIDGE_URL_NOT_ALLOWED, "Add " + InpBaseUrl + " in Tools > Options > Expert Advisors > Allow WebRequest");
      else            SetState(BRIDGE_SERVER_DOWN, "WebRequest error " + IntegerToString(err));
      Fail();
      return(-1);
     }
   if(code == 401 || StringFind(response, "ERR|bad_token") == 0 || StringFind(response, "ERR|account_mismatch") == 0 || StringFind(response, "ERR|server_mismatch") == 0)
     {
      SetState(BRIDGE_AUTH_FAILED, "Server refused the pairing: " + response + " - create a new token on the website and re-attach the EA");
      LogLine("", "auth", "", 0, "refused", "", response);
      return(code);
     }
   if(code >= 500 || code == 429 || code == 404)
     {
      SetState(BRIDGE_SERVER_DOWN, "Server answered HTTP " + IntegerToString(code) + (code == 404 ? " (is the API deployed on this URL?)" : ""));
      Fail();
      return(code);
     }
   g_failures = 0; g_nextTry = 0; g_lastOk = TimeLocal();
   SetState(BRIDGE_CONNECTED, "");
   return(code);
  }

void Fail()
  {
   g_failures++;
   int wait = (int)MathMin(60, MathPow(2, MathMin(g_failures, 6)));   // 2,4,8..60 s
   g_nextTry = TimeLocal() + wait;
  }

//+------------------------------------------------------------------+
//| JSON helpers                                                     |
//+------------------------------------------------------------------+
string Esc(string s)
  {
   StringReplace(s, "\\", "\\\\");
   StringReplace(s, "\"", "\\\"");
   StringReplace(s, "\r", " ");
   StringReplace(s, "\n", " ");
   return(s);
  }
string Q(const string s) { return("\"" + Esc(s) + "\""); }
string D(const double v, const int digits = 2) { return(DoubleToString(v, digits)); }

string AccountJson()
  {
   string j = "{";
   j += "\"account\":" + Q(IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN))) + ",";
   j += "\"server\":" + Q(AccountInfoString(ACCOUNT_SERVER)) + ",";
   j += "\"company\":" + Q(AccountInfoString(ACCOUNT_COMPANY)) + ",";
   j += "\"currency\":" + Q(AccountInfoString(ACCOUNT_CURRENCY)) + ",";
   j += "\"build\":" + IntegerToString(TerminalInfoInteger(TERMINAL_BUILD)) + ",";
   j += "\"balance\":" + D(AccountInfoDouble(ACCOUNT_BALANCE)) + ",";
   j += "\"equity\":" + D(AccountInfoDouble(ACCOUNT_EQUITY)) + ",";
   j += "\"margin\":" + D(AccountInfoDouble(ACCOUNT_MARGIN)) + ",";
   j += "\"leverage\":" + IntegerToString(AccountInfoInteger(ACCOUNT_LEVERAGE)) + ",";
   j += "\"allowTrading\":" + (TradingPermitted() ? "true" : "false") + ",";
   j += "\"terminalTrade\":" + (TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) ? "true" : "false") + ",";
   j += "\"maxLot\":" + D(InpMaxLot) + ",";
   j += "\"positions\":[";
   int total = PositionsTotal(), added = 0;
   for(int i = 0; i < total && added < 50; i++)
     {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      int digits = (int)SymbolInfoInteger(PositionGetString(POSITION_SYMBOL), SYMBOL_DIGITS);
      if(added > 0) j += ",";
      j += "{\"ticket\":" + Q(IntegerToString((long)ticket));
      j += ",\"symbol\":" + Q(PositionGetString(POSITION_SYMBOL));
      j += ",\"type\":" + Q(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_SELL ? "sell" : "buy");
      j += ",\"volume\":" + D(PositionGetDouble(POSITION_VOLUME));
      j += ",\"price\":" + D(PositionGetDouble(POSITION_PRICE_OPEN), digits);
      j += ",\"sl\":" + D(PositionGetDouble(POSITION_SL), digits);
      j += ",\"tp\":" + D(PositionGetDouble(POSITION_TP), digits);
      j += ",\"profit\":" + D(PositionGetDouble(POSITION_PROFIT)) + "}";
      added++;
     }
   j += "]}";
   return(j);
  }

//+------------------------------------------------------------------+
//| Protocol                                                         |
//+------------------------------------------------------------------+
bool SendHello()
  {
   string resp;
   int code = Http("/api/mt5/ea/hello", AccountJson(), resp);
   if(code == 200 && StringFind(resp, "OK") == 0)
     {
      LogLine("", "hello", "", 0, "connected", "", "paired with the server");
      return(true);
     }
   return(false);
  }

void Poll()
  {
   string resp;
   int code = Http("/api/mt5/ea/poll", AccountJson(), resp);
   if(code != 200 || StringFind(resp, "OK") != 0) return;
   string lines[];
   int n = StringSplit(resp, '\n', lines);
   for(int i = 1; i < n; i++)                                        // line 0 = "OK|serverTime|pollMs"
     {
      string line = lines[i];
      StringTrimLeft(line); StringTrimRight(line);
      if(StringLen(line) > 0) HandleCommand(line);
     }
  }

//| line: id|action|symbol|volume|sl|tp|ticket|comment                |
void HandleCommand(const string line)
  {
   string f[];
   if(StringSplit(line, '|', f) < 8) { Print("GotrivaTradeBridge: bad command line ", line); return; }
   string id = f[0], action = f[1], symbol = f[2], ticketStr = f[6], comment = f[7];
   double volume = StringToDouble(f[3]), sl = StringToDouble(f[4]), tp = StringToDouble(f[5]);

   if(AlreadyDone(id)) { Ack(id, false, 0, 0, 0, "duplicate: already handled"); return; }
   MarkDone(id);

   if(!TradingPermitted())
     {
      string why = !InpAllowTrading ? "Allow trading is OFF in the EA inputs" : "Algo Trading / account trading is disabled in the terminal";
      LogLine(id, action, symbol, volume, "refused", "", why);
      Ack(id, false, 0, 0, 0, why);
      return;
     }

   if(action == "close")
     {
      ulong ticket = (ulong)StringToInteger(ticketStr);
      if(!PositionSelectByTicket(ticket) || PositionGetInteger(POSITION_MAGIC) != (long)InpMagic)
        { LogLine(id, action, ticketStr, 0, "failed", ticketStr, "position not found or not opened by the bridge"); Ack(id, false, 0, 0, 0, "position not found or not opened by the bridge"); return; }
      string psym = PositionGetString(POSITION_SYMBOL);
      double pvol = PositionGetDouble(POSITION_VOLUME);
      bool okc = g_trade.PositionClose(ticket);
      Report(id, action, psym, pvol, okc, ticket);
      return;
     }

   if(action != "buy" && action != "sell") { Ack(id, false, 0, 0, 0, "unknown action " + action); return; }

   string sym = symbol + InpSymbolSuffix;
   if(!SymbolSelect(sym, true)) { LogLine(id, action, sym, volume, "failed", "", "symbol not available at this broker"); Ack(id, false, 0, 0, 0, "symbol " + sym + " not available at this broker"); return; }

   double vol = NormalizeVolume(sym, volume);
   if(vol <= 0) { Ack(id, false, 0, 0, 0, "volume outside the broker limits or above the EA maximum lot"); LogLine(id, action, sym, volume, "refused", "", "volume limits"); return; }
   int digits = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   sl = sl > 0 ? NormalizeDouble(sl, digits) : 0.0;
   tp = tp > 0 ? NormalizeDouble(tp, digits) : 0.0;

   g_trade.SetTypeFillingBySymbol(sym);
   bool ok = action == "buy" ? g_trade.Buy(vol, sym, 0.0, sl, tp, comment)
                             : g_trade.Sell(vol, sym, 0.0, sl, tp, comment);
   Report(id, action, sym, vol, ok, 0);
  }

void Report(const string id, const string action, const string sym, const double vol, const bool sent, const ulong closedTicket)
  {
   uint   rc     = g_trade.ResultRetcode();
   bool   ok     = sent && (rc == TRADE_RETCODE_DONE || rc == TRADE_RETCODE_PLACED || rc == TRADE_RETCODE_DONE_PARTIAL);
   ulong  ticket = closedTicket > 0 ? closedTicket : (g_trade.ResultOrder() > 0 ? g_trade.ResultOrder() : g_trade.ResultDeal());
   double price  = g_trade.ResultPrice();
   string msg    = g_trade.ResultRetcodeDescription();
   if(ok) g_executed++;
   LogLine(id, action, sym, vol, ok ? "done" : "failed", IntegerToString((long)ticket), IntegerToString(rc) + " " + msg);
   Ack(id, ok, ticket, price, rc, msg);
  }

void Ack(const string id, const bool ok, const ulong ticket, const double price, const uint retcode, const string msg)
  {
   string body = "{\"id\":" + Q(id) + ",\"ok\":" + (ok ? "true" : "false") + ",\"ticket\":" + Q(IntegerToString((long)ticket)) +
                 ",\"price\":" + D(price, 6) + ",\"retcode\":" + IntegerToString(retcode) + ",\"message\":" + Q(msg) + "}";
   string resp;
   for(int attempt = 0; attempt < 3; attempt++)                      // the result must reach the server's log
     {
      if(Http("/api/mt5/ea/ack", body, resp) == 200) return;
      Sleep(500 * (attempt + 1));
     }
   Print("GotrivaTradeBridge: could not report result of ", id, " to the server (kept in the local log)");
  }

double NormalizeVolume(const string sym, double v)
  {
   double mn = SymbolInfoDouble(sym, SYMBOL_VOLUME_MIN), mx = SymbolInfoDouble(sym, SYMBOL_VOLUME_MAX), st = SymbolInfoDouble(sym, SYMBOL_VOLUME_STEP);
   if(v > InpMaxLot) return(0.0);                                    // never above the customer's own limit
   if(st > 0) v = MathFloor(v / st + 1e-9) * st;
   if(v < mn || v > mx) return(0.0);
   int d = (int)MathMax(0, MathCeil(-MathLog10(st > 0 ? st : 0.01)));
   return(NormalizeDouble(v, d));
  }

bool AlreadyDone(const string id)
  {
   for(int i = 0; i < ArraySize(g_done); i++) if(g_done[i] == id) return(true);
   return(false);
  }
void MarkDone(const string id)
  {
   int n = ArraySize(g_done);
   if(n >= 200) { ArrayRemove(g_done, 0, 50); n = ArraySize(g_done); }
   ArrayResize(g_done, n + 1);
   g_done[n] = id;
  }

//+------------------------------------------------------------------+
//| Documentation: one CSV line per event, one file per day          |
//| MQL5\Files\GotrivaTradeBridge\log-YYYYMMDD.csv                     |
//+------------------------------------------------------------------+
void LogLine(const string id, const string action, const string symbol, const double volume, const string status, const string ticket, const string message)
  {
   MqlDateTime t; TimeToStruct(TimeLocal(), t);
   string name = StringFormat("GotrivaTradeBridge\\log-%04d%02d%02d.csv", t.year, t.mon, t.day);
   int h = FileOpen(name, FILE_READ | FILE_WRITE | FILE_CSV | FILE_ANSI | FILE_SHARE_READ, ',');
   if(h == INVALID_HANDLE) { Print("GotrivaTradeBridge: cannot write ", name, " error ", GetLastError()); return; }
   if(FileSize(h) == 0) FileWrite(h, "time", "account", "command_id", "action", "symbol", "volume", "status", "ticket", "message");
   FileSeek(h, 0, SEEK_END);
   FileWrite(h, TimeToString(TimeLocal(), TIME_DATE | TIME_SECONDS), IntegerToString(InpAccount), id, action, symbol, DoubleToString(volume, 2), status, ticket, message);
   FileClose(h);
  }
//+------------------------------------------------------------------+
