import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import { spawn } from 'node:child_process';

// The server serves a saved good copy of the calendar after a restart even when the source refuses it.
test('v326: ff-cache.json written by an earlier run is served when the source is unreachable', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ffc-'));
  const body = JSON.stringify([{ title: 'CPI m/m', country: 'USD', date: '2026-11-13T08:30:00-05:00', impact: 'High', forecast: '0.2%', previous: '0.1%' }]);
  fs.writeFileSync(path.join(dir, 'ff-cache.json'), JSON.stringify({ 'http://127.0.0.1:9/ff.json': { at: Date.now() - 60 * 60_000, type: 'application/json', body } }));
  const port = 18000 + Math.floor(Math.random() * 1000);
  const child = spawn(process.execPath, ['server/index.js'], { env: { ...process.env, PORT: String(port), SERVER_DATA_DIR: dir, FF_CAL_URL: 'http://127.0.0.1:9/ff.json', NODE_ENV: 'test', ATA_TEST: '1' }, stdio: 'ignore' });
  try {
    let res = null;
    for (let i = 0; i < 40 && !res; i++) { await new Promise((r) => setTimeout(r, 250)); try { const r = await fetch(`http://127.0.0.1:${port}/ff/cal/thisweek`); res = { status: r.status, text: await r.text(), cache: r.headers.get('x-cache') }; } catch { /* not up yet */ } }
    assert.ok(res, 'server started');
    assert.equal(res.status, 200); assert.equal(res.cache, 'STALE'); assert.equal(JSON.parse(res.text)[0].title, 'CPI m/m');
  } finally { child.kill(); }
});

test('v326: in the browser, the calendar falls back to the source when our server cannot get it', async () => {
  const calls = [];
  const saved = { location: globalThis.location, fetch: globalThis.fetch, localStorage: globalThis.localStorage };
  globalThis.location = { origin: 'https://site.test' };
  globalThis.fetch = async (url) => { calls.push(String(url)); if (String(url).startsWith('/ff/')) return { ok: false, status: 502, text: async () => '' }; return { ok: true, status: 200, text: async () => JSON.stringify([{ title: 'NFP', country: 'USD', date: '2026-11-13T08:30:00-05:00', impact: 'High' }]) }; };
  try {
    const { getCalendar } = await import('../src/services/news.js?v326');
    const r = await getCalendar({ force: true });
    assert.deepEqual(calls, ['/ff/cal/thisweek', 'https://nfs.faireconomy.media/ff_calendar_thisweek.json']);
    assert.equal(r.events[0].title, 'NFP');
  } finally { for (const [k, v] of Object.entries(saved)) { if (v === undefined) delete globalThis[k]; else globalThis[k] = v; } }
});
