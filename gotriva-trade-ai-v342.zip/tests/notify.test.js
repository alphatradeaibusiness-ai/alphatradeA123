// Phone alerts (Telegram + ntfy) set from the website: owner only, a REAL test message before saving, encrypted at rest,
// never returned, and the worker side (createNotifier) reads the same encrypted file. Runs the real server against mocks.
import test from 'node:test';
import assert from 'node:assert';
import crypto from 'node:crypto';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { cleanNotify, sendNtfy, effectiveNotify, createNotifier, parseStored } from '../server/notify.js';
import { createStore } from '../server/aiGateway.js';

const PROJECT = 'alphatrade-test'; const KID = 'k-notify';
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
function token({ uid = 'owner-uid', email = 'shheahmad417@gmail.com', verified = true } = {}) {
  const now = Math.floor(Date.now() / 1000);
  const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
  const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: now - 10, auth_time: now - 10, exp: now + 3600, email, email_verified: verified, firebase: { sign_in_provider: 'google.com' } }));
  return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), privateKey))}`;
}
const certs = { [KID]: publicKey.export({ type: 'spki', format: 'pem' }) };
const listen = (srv) => new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv.address().port)));
function call(port, p, { method = 'GET', tok, body } = {}) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? null : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { origin: `http://127.0.0.1:${port}`, ...(data ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data) } : {}), ...(tok ? { authorization: `Bearer ${tok}` } : {}) } }, (res) => {
      let raw = ''; res.on('data', (c) => (raw += c)); res.on('end', () => { let j = null; try { j = JSON.parse(raw); } catch { /* not json */ } resolve({ status: res.statusCode, body: j, raw }); });
    });
    r.on('error', reject); if (data) r.write(data); r.end();
  });
}

const GOOD_TOKEN = `123456789:AAH${'a'.repeat(32)}`;
const BAD_TOKEN = `123456789:AAH${'BAD'.repeat(11)}`;
/** Telegram/ntfy in their real answer shapes. Telegram: bad token → 401, chat 999999 → 400. ntfy: topic containing "failtopic" → 500. */
function mocks(seen) {
  const tg = http.createServer((q, s) => {
    let raw = ''; q.on('data', (c) => (raw += c)); q.on('end', () => {
      const body = JSON.parse(raw || '{}'); seen.push({ via: 'tg', url: q.url, body });
      s.setHeader('content-type', 'application/json');
      if (q.url.includes('BAD')) { s.statusCode = 401; return s.end(JSON.stringify({ ok: false, error_code: 401, description: 'Unauthorized' })); }
      if (String(body.chat_id) === '999999') { s.statusCode = 400; return s.end(JSON.stringify({ ok: false, error_code: 400, description: 'Bad Request: chat not found' })); }
      s.end(JSON.stringify({ ok: true, result: {} }));
    });
  });
  const nt = http.createServer((q, s) => {
    let raw = ''; q.on('data', (c) => (raw += c)); q.on('end', () => {
      const body = JSON.parse(raw || '{}'); seen.push({ via: 'ntfy', body });
      s.statusCode = String(body.topic).includes('failtopic') ? 500 : 200; s.end('{}');
    });
  });
  return { tg, nt };
}
async function startServer(env) {
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; child.stdout.on('data', (c) => (log += c)); child.stderr.on('data', (c) => (log += c));
  for (let i = 0; i < 60; i++) { try { await call(port, '/api/notify/status'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
  return { port, child, log: () => log };
}

test('cleanNotify: formats are checked, empty fields mean "leave as is"', () => {
  assert.deepStrictEqual(cleanNotify({}).value, {});
  assert.deepStrictEqual(cleanNotify({ telegramToken: GOOD_TOKEN, telegramChatId: '-1001234567890', ntfyTopic: 'my-topic_123' }).value, { telegramToken: GOOD_TOKEN, telegramChatId: '-1001234567890', ntfyTopic: 'my-topic_123' });
  assert.equal(cleanNotify({ telegramToken: 'abc' }).error, 'telegram_token_format');
  assert.equal(cleanNotify({ telegramChatId: 'not a chat' }).error, 'telegram_chat_format');
  assert.equal(cleanNotify({ ntfyTopic: 'short' }).error, 'ntfy_topic_format');
  assert.equal(cleanNotify({ ntfyTopic: 'has space in it' }).error, 'ntfy_topic_format');
  assert.equal(cleanNotify({ telegramChatId: '@my_channel' }).value.telegramChatId, '@my_channel');
});

test('effectiveNotify: the website value wins, the environment is the fallback', () => {
  const env = { TELEGRAM_BOT_TOKEN: 'envtok', TELEGRAM_CHAT_ID: '5', ALERT_TOPIC: 'env-topic-1' };
  assert.deepStrictEqual(effectiveNotify(null, env), { telegramToken: 'envtok', telegramChatId: '5', ntfyTopic: 'env-topic-1' });
  assert.equal(effectiveNotify({ ntfyTopic: 'site-topic-1' }, env).ntfyTopic, 'site-topic-1');
  assert.equal(effectiveNotify({ ntfyTopic: 'site-topic-1' }, env).telegramToken, 'envtok');
  assert.deepStrictEqual(effectiveNotify(null, {}), { telegramToken: '', telegramChatId: '', ntfyTopic: '' });
  assert.equal(parseStored({ apiKey: 'not json' }), null);
});

test('sendNtfy: posts the topic/title/message, hides the topic in errors', async () => {
  let got; const ok = await sendNtfy({ topic: 'abcdefgh1', title: 'T', body: 'B', fetchImpl: async (u, o) => { got = JSON.parse(o.body); return { ok: true, status: 200 }; } });
  assert.deepStrictEqual([ok.ok, got.topic, got.message, got.title], [true, 'abcdefgh1', 'B', 'GOTRIVA TRADE AI · T']);
  const bad = await sendNtfy({ topic: 'abcdefgh1', title: 'T', body: 'B', fetchImpl: async () => { throw new Error('boom abcdefgh1'); } });
  assert.equal(bad.ok, false); assert.ok(!String(bad.status).includes('abcdefgh1'));
  assert.equal((await sendNtfy({ topic: '' })).status, 'not-configured');
});

test('createNotifier (worker side): reads the encrypted file, re-reads after the ttl, falls back to env', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ntf-w-'));
  const store = createStore({ dir, secret: 'w'.repeat(40), name: 'notify-config.json' });
  let t = 0; const sent = [];
  const fetchImpl = async (u, o) => { sent.push({ u: String(u), body: JSON.parse(o.body) }); return { ok: true, status: 200 }; };
  const n = createNotifier({ store, env: {}, ttl: 1000, fetchImpl, now: () => t });
  assert.deepStrictEqual(n.configured(), { telegram: false, ntfy: false });
  store.save({ apiKey: JSON.stringify({ ntfyTopic: 'worker-topic-1' }), ownerUid: 'x' });
  assert.equal(n.configured().ntfy, false);                       // cached until the ttl passes
  t = 2000; assert.deepStrictEqual(n.configured(), { telegram: false, ntfy: true });
  const r = await n.send({ title: 'Signal', body: 'BTC long' });
  assert.equal(r.ntfy.ok, true); assert.equal(sent[0].body.topic, 'worker-topic-1');
  const wrong = createNotifier({ store: createStore({ dir, secret: 'z'.repeat(40), name: 'notify-config.json' }), env: {}, fetchImpl });   // a different AI_KEY_SECRET cannot read it
  assert.deepStrictEqual(wrong.configured(), { telegram: false, ntfy: false });
  fs.rmSync(dir, { recursive: true, force: true });
});

test('phone alerts end to end: owner only, real test message first, bad channels not saved, encrypted, never returned, deletable', async () => {
  const seen = []; const { tg, nt } = mocks(seen); const tp = await listen(tg); const np = await listen(nt);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ntf-')); const certFile = path.join(dir, 'certs.json'); fs.writeFileSync(certFile, JSON.stringify(certs));
  const { port, child, log } = await startServer({ NOTIFY_TEST_TELEGRAM_BASE: `http://127.0.0.1:${tp}`, NOTIFY_TEST_NTFY_BASE: `http://127.0.0.1:${np}/`, AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, AI_KEY_SECRET: 'n'.repeat(48), SERVER_DATA_DIR: dir, SERVER_NOTIFY_DIR: path.join(dir, 'notify'), TELEGRAM_BOT_TOKEN: '', TELEGRAM_CHAT_ID: '', ALERT_TOPIC: '', ANTHROPIC_API_KEY: '', AI_IP_PER_MINUTE: '1000', AI_DAILY_PER_IP: '1000', AI_DAILY_LIMIT: '1000' });
  const owner = token(); const user = token({ uid: 'u1', email: 'someone@example.com' });
  const all = []; const c = async (...a) => { const r = await call(port, ...a); all.push(r.raw); return r; };
  const put = (body, tok = owner) => c('/api/notify/config', { method: 'PUT', tok, body });
  const wait = () => new Promise((r) => setTimeout(r, 3100));   // the server spaces real sends 3 s apart
  const file = path.join(dir, 'notify', 'notify-config.json');
  try {
    const s0 = (await c('/api/notify/status', { tok: owner })).body;
    assert.equal(s0.owner, true); assert.equal(s0.telegram.set, false); assert.equal(s0.ntfy.set, false);
    assert.equal((await put({ ntfyTopic: 'good-topic-123' }, null)).status, 401);
    assert.equal((await put({ ntfyTopic: 'good-topic-123' }, user)).status, 403);
    assert.equal((await c('/api/notify/status', { tok: user })).body.telegram, undefined);              // nothing for non-owners
    assert.equal((await put({ telegramToken: GOOD_TOKEN })).body.code, 'telegram_incomplete');          // needs both halves
    assert.equal((await put({ ntfyTopic: 'x' })).body.code, 'ntfy_topic_format');
    assert.equal(seen.length, 0, 'nothing is sent for invalid input');
    // a rejected token is explained and NOT saved
    let r = await put({ telegramToken: BAD_TOKEN, telegramChatId: '12345' });
    assert.equal(r.body.ok, false); assert.equal(r.body.codes.telegram, 'telegram_token_invalid'); assert.equal(r.body.status.telegram.set, false); assert.ok(!fs.existsSync(file));
    await wait();
    r = await put({ telegramToken: GOOD_TOKEN, telegramChatId: '999999' });
    assert.equal(r.body.codes.telegram, 'telegram_chat_invalid'); assert.ok(!fs.existsSync(file));
    await wait();
    r = await put({ ntfyTopic: 'failtopic-123' });
    assert.equal(r.body.codes.ntfy, 'ntfy_failed'); assert.ok(!fs.existsSync(file));
    await wait();
    // good Telegram → a real message went to the (mock) Telegram API, then it is saved
    seen.length = 0;
    r = await put({ telegramToken: GOOD_TOKEN, telegramChatId: '12345' });
    assert.equal(r.body.ok, true); assert.equal(r.body.status.telegram.set, true); assert.equal(r.body.status.telegram.source, 'site'); assert.equal(r.body.status.telegram.tokenLast4, `…${GOOD_TOKEN.slice(-4)}`);
    assert.equal(seen.length, 1); assert.equal(seen[0].via, 'tg'); assert.ok(seen[0].url.includes(GOOD_TOKEN)); assert.equal(seen[0].body.chat_id, '12345');
    const raw = fs.readFileSync(file, 'utf8');
    assert.ok(!raw.includes(GOOD_TOKEN) && !raw.includes('12345') && !raw.includes('AAH'), 'plain values in the file');   // encrypted at rest
    assert.equal(fs.statSync(file).mode & 0o777, 0o600);
    await wait();
    // adding ntfy keeps Telegram, and only ntfy gets a test message
    seen.length = 0;
    r = await put({ ntfyTopic: 'good-topic-123' });
    assert.equal(r.body.ok, true); assert.equal(r.body.status.telegram.set, true); assert.equal(r.body.status.ntfy.set, true);
    assert.deepStrictEqual(seen.map((x) => x.via), ['ntfy']);
    assert.equal((await c('/api/notify/status', { tok: user })).body.ntfy, undefined);
    // the worker side reads the very same file with the same secret
    const w = createNotifier({ store: createStore({ dir: path.join(dir, 'notify'), secret: 'n'.repeat(48), name: 'notify-config.json' }), env: {}, ttl: 0, fetchImpl: async (u, o) => { seen.push({ via: 'worker', u: String(u), body: JSON.parse(o.body) }); return { ok: true, status: 200 }; } });
    assert.deepStrictEqual(w.configured(), { telegram: true, ntfy: true });
    // test button
    await wait(); seen.length = 0;
    r = await c('/api/notify/config/test', { method: 'POST', tok: owner, body: {} });
    assert.equal(r.body.ok, true); assert.deepStrictEqual(seen.map((x) => x.via).sort(), ['ntfy', 'tg']);
    // deleting one channel keeps the other; deleting the last removes the file
    assert.equal((await c('/api/notify/config?channel=telegram', { method: 'DELETE', tok: user })).status, 403);
    r = await c('/api/notify/config?channel=telegram', { method: 'DELETE', tok: owner });
    assert.equal(r.body.status.telegram.set, false); assert.equal(r.body.status.ntfy.set, true); assert.ok(fs.existsSync(file));
    r = await c('/api/notify/config', { method: 'DELETE', tok: owner });
    assert.equal(r.body.status.ntfy.set, false); assert.ok(!fs.existsSync(file));
    assert.equal((await c('/api/notify/config/test', { method: 'POST', tok: owner, body: {} })).body.code, 'not_configured');
    assert.ok(!all.join('\n').includes(GOOD_TOKEN) && !all.join('\n').includes('good-topic-123'), 'a secret leaked into a response');
    assert.ok(!log().includes(GOOD_TOKEN) && !log().includes('good-topic-123') && !log().includes('AAH'), 'a secret leaked into the log');
  } finally { child.kill(); tg.close(); nt.close(); fs.rmSync(dir, { recursive: true, force: true }); }
});
