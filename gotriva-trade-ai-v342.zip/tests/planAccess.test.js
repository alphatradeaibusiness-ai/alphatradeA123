import test from 'node:test';
import assert from 'node:assert/strict';
import { createEntitlements } from '../server/entitlements.js';
import { NAV_RANK, TIERS } from '../src/config/entitlements.js';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ent-'));
const subs = { a: { product: 'monthly' }, b: { product: 'semiannual' }, c: { product: 'max' }, ch: { product: 'channel' } };
const access = { subscription: (uid) => subs[uid] || null };   // an expired plan comes back as null from the real store

test('v323: the server checks page access with the same ranks as the menu', () => {
  const e = createEntitlements({ dir, access, env: { ENFORCE_PLANS: '1' } });
  assert.equal(e.canPage('a', 'mt5'), false); assert.equal(e.canPage('a', 'contest'), false); assert.equal(e.canPage('a', 'home'), true);
  assert.equal(e.canPage('b', 'mentors'), true); assert.equal(e.canPage('b', 'mt5'), false);
  assert.equal(e.canPage('c', 'liquidity'), true);
  assert.equal(e.canPage('ch', 'contest'), false); assert.equal(e.canPage('gone', 'contest'), false);   // channel-only / expired
  assert.equal(e.canPage('gone', 'mt5', { owner: true }), true);
  for (const [id, need] of Object.entries(NAV_RANK)) for (const [plan, t] of Object.entries(TIERS)) { subs.x = { product: plan }; assert.equal(e.canPage('x', id), t.rank >= need, `${plan} ${id}`); }
});

test('v323: with plans not enforced nothing is locked', () => {
  const e = createEntitlements({ dir, access, env: {} });
  assert.equal(e.canPage('gone', 'liquidity'), true);
});
