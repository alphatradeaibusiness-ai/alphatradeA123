import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateNova, trackNova, novaSummary, createNovaScanner, strategyRecord, NOVA, NOVA_MARKETS } from '../src/services/novaPulse.js';
import { findInstrument } from '../src/config/instruments.js';
import { paperSeries, PAPER } from '../src/services/aiPaperStrategies.js';

const T0 = 1_790_000_040;   // on a minute boundary
function series(n, seed = 7) {   // deterministic random walk with swings
  let s = seed; const rnd = () => { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; };
  const out = []; let p = 2000;
  for (let i = 0; i < n; i++) { const o = p; const d = (rnd() - 0.5) * 2 + Math.sin(i / 37) * 0.6; const c = o + d; out.push({ time: T0 + i * 60, open: o, high: Math.max(o, c) + rnd() * 0.5, low: Math.min(o, c) - rnd() * 0.5, close: c, volume: 100 + rnd() * 50 }); p = c; }
  return out;
}
const XAU = NOVA_MARKETS[0];

test('nova: all ten requested markets resolve to real instruments (NAS100 = US100)', () => {
  for (const m of NOVA_MARKETS) assert.ok(findInstrument(m.symbol), m.id);
  assert.equal(NOVA_MARKETS.find((m) => m.id === 'NAS100').aka, 'US100');
  assert.equal(NOVA.minWinRate, 0.67); assert.ok(NOVA.minTrades >= 30);
});

test('nova: stale or short data never gives a signal', () => {
  const cs = series(900);
  const fresh = (cs.at(-1).time + 60) * 1000 + 5000;
  assert.equal(evaluateNova({ market: XAU, candles: cs.slice(0, 100), nowMs: fresh }).state, 'insufficient');
  assert.equal(evaluateNova({ market: XAU, candles: cs, nowMs: fresh + 10 * 60_000 }).state, 'stale');
  const r = evaluateNova({ market: XAU, candles: cs, nowMs: fresh });
  assert.ok(['signal', 'no_signal'].includes(r.state)); assert.ok(r.checked > 0);
});

test('nova: a signal exists only with a measured win rate ≥ 67 % over ≥ 30 trades and a positive average', () => {
  for (let seed = 1; seed <= 6; seed++) {
    const cs = series(1500, seed); const now = (cs.at(-1).time + 60) * 1000 + 1000;
    const r = evaluateNova({ market: XAU, candles: cs, nowMs: now });
    for (const q of r.qualified) { assert.ok(q.winRate >= 0.67); assert.ok(q.n >= 30); }
    if (r.state === 'signal') {
      const s = r.signal; assert.ok(s.winRate >= 0.67 && s.sample >= 30 && s.avgR > 0);
      const sg = s.direction === 'long' ? 1 : -1; assert.ok((s.entry - s.stop) * sg > 0 && (s.target - s.entry) * sg > 0);
      assert.ok(r.qualified.some((q) => q.strategy === s.strategy));
    }
  }
});

test('nova: the record uses past trades only — adding future candles does not change earlier trades', () => {
  const cs = series(1200, 3); const id = Object.keys(PAPER)[0]; const ctx = { assetClass: 'metal', tf: '1m', tfSec: 60 };
  const a = strategyRecord(cs.slice(0, 800), paperSeries(cs.slice(0, 800)), id, ctx, 0.02);
  const b = strategyRecord(cs, paperSeries(cs), id, ctx, 0.02);
  assert.ok(b.n >= a.n);
});

test('nova: tracking — stop first on a candle that touches both, target, expiry', () => {
  const mk = (o) => ({ id: 'x', market: 'XAUUSD', direction: 'long', entry: 100, stop: 99, target: 101, rr: 1, barTime: T0, status: 'active', ...o });
  const c = (i, lo, hi, cl = 100) => ({ time: T0 + i * 60, open: 100, high: hi, low: lo, close: cl });
  const now = (T0 + 100 * 60) * 1000;
  assert.equal(trackNova(mk(), [c(1, 98.9, 101.2)], now).status, 'sl');
  assert.equal(trackNova(mk(), [c(1, 99.5, 100.5), c(2, 99.6, 101.1)], now).status, 'tp');
  const flat = Array.from({ length: NOVA.maxBars }, (_, i) => c(i + 1, 99.7, 100.4, 100.3));
  const e = trackNova(mk(), flat, now); assert.equal(e.status, 'expired'); assert.equal(e.result, 0.3);
  assert.equal(trackNova(mk(), [c(1, 99.5, 100.5)], now).status, 'active');
  const sum = novaSummary([{ status: 'tp', result: 1 }, { status: 'sl', result: -1 }, { status: 'active' }]);
  assert.equal(sum.closed, 2); assert.equal(sum.winRate, 0.5); assert.equal(sum.active, 1);
});

test('nova: scanner — demo data is never used, one market failing does not stop the rest, state is saved', async () => {
  const cs = series(900); let t = (cs.at(-1).time + 60) * 1000 + 2000; let saved = null;
  const deps = { getHistory: async (sym) => { if (sym === 'XAGUSD') throw new Error('boom'); if (sym === 'EURUSD') return { mode: 'demo', candles: cs }; return { mode: 'live', candles: cs, volumeKind: 'none', source: 'test' }; } };
  const sc = createNovaScanner({ deps, store: { load: () => null, save: (s) => { saved = JSON.parse(JSON.stringify(s)); } }, now: () => t, log: { warn() {} } });
  await sc.scanOnce();
  assert.equal(saved.markets.XAGUSD.state, 'error'); assert.equal(saved.markets.EURUSD.state, 'unavailable'); assert.equal(saved.markets.EURUSD.reason, 'demo_data');
  assert.equal(saved.markets.XAUUSD.state, 'live'); assert.ok(saved.lastScan);
  assert.ok(saved.signals.every((s) => s.winRate >= 0.67 && s.market !== 'EURUSD'));
  const n = saved.signals.length; await sc.scanOnce(); assert.equal(saved.signals.length, n);   // same candle: nothing new
});
