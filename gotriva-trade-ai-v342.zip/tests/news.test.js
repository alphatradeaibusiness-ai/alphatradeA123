import test from 'node:test';
import assert from 'node:assert/strict';


test('v318: news is linked to its own currency, not only to the index list', async () => {
  const { eventMoves, currenciesOf } = await import('../src/services/newsFeed.js');
  const ev = (country) => ({ country });
  assert.equal(eventMoves(ev('USD'), 'EURUSD'), true); assert.equal(eventMoves(ev('EUR'), 'EURUSD'), true); assert.equal(eventMoves(ev('JPY'), 'EURUSD'), false);
  assert.equal(eventMoves(ev('JPY'), 'USDJPY'), true); assert.equal(eventMoves(ev('GBP'), 'GBPUSD'), true);
  assert.equal(eventMoves(ev('USD'), 'XAGUSD'), true); assert.equal(eventMoves(ev('USD'), 'XPTUSD'), true); assert.equal(eventMoves(ev('EUR'), 'XAGUSD'), false);
  assert.deepEqual(currenciesOf('BTCUSDT'), ['USD']); assert.deepEqual(currenciesOf('USDJPY'), ['USD', 'JPY']);
});

test('v318: news alerts ring once per new high-impact item, never for old or low ones', async () => {
  const { dueAlerts } = await import('../src/services/newsAlerts.js');
  const now = 1_790_000_000_000; const seen = new Set();
  const events = [{ country: 'USD', title: 'CPI m/m', time: now - 60_000, impact: 'High', actual: '0.3%', forecast: '0.2%', previous: '0.1%' }, { country: 'EUR', title: 'x', time: now - 60_000, impact: 'Low', actual: '1' }, { country: 'GBP', title: 'Soon', time: now + 3 * 60_000, impact: 'High', actual: '' }];
  const a = dueAlerts(events, [{ id: '9', title: 'Fed speaker', impact: 'High', time: now - 60_000, source: '@x' }, { id: '8', title: 'old', impact: 'High', time: now - 3 * 3600e3 }], seen, now, 'en');
  assert.deepEqual(a.map((x) => x.title), ['USD · CPI m/m', 'GBP · Soon', '@x']);
  a.forEach((x) => seen.add(x.key)); assert.equal(dueAlerts(events, [], seen, now, 'en').length, 0);
});
