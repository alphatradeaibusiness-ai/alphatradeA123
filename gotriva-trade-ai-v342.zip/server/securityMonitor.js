// v236 security monitoring: what happened on the API that matters for security, kept as a short local log and turned into owner
// alerts when it looks like an attack. Nothing secret is ever written: no tokens, keys, bodies or e-mail addresses — only the
// event kind, the path (no query), the status, the account id prefix and the client IP (needed to block an attacker at the WAF).
//
// Events:  auth_fail (a request WITH a bearer token was refused 401) · admin_denied (403 on an owner path) · rate_limited (429)
//          admin_action (an owner write: keys, prices, coupons, broadcasts, grants…) · account_deleted
// Alerts (each at most once an hour per IP / kind, delivered to the owners through notify(title, body)):
//          suspicious_signin  ≥ 20 refused tokens from one IP in 10 minutes  (token guessing / stolen expired tokens)
//          admin_probe        ≥ 5 refused owner requests from one IP in 10 minutes (privilege-escalation attempts)
//          api_abuse          ≥ 100 rate-limited requests from one IP in 10 minutes (scripted flood)
//          sensitive_change   every change of a key / payment / plan setting (so a stolen owner session is noticed at once)
import fs from 'node:fs';
import path from 'node:path';

const WINDOW = 10 * 60_000;
export const THRESHOLDS = { auth_fail: 20, admin_denied: 5, rate_limited: 100 };
const ALERT_OF = { auth_fail: 'suspicious_signin', admin_denied: 'admin_probe', rate_limited: 'api_abuse' };
const SENSITIVE = /^\/api\/(ai\/config|billing\/config|market\/config|notify\/config|channel\/grant|admin\/(plans|coupons))/;
export const OWNER_PATH = /^\/api\/(admin\/|ai\/config|billing\/config|billing\/admin|market\/config|notify\/config|channel\/grant|contest\/award|live\/(start|end|viewers|viewer\/)|support\/calls)/;

export function createSecurityMonitor({ dir, notify = () => {}, now = Date.now, maxBytes = 5 * 1024 * 1024, keep = 300 } = {}) {
  const file = dir ? path.join(dir, 'security-events.jsonl') : null;
  const recentList = []; const counters = new Map(); const alerted = new Map(); const alerts = [];
  // Lines are buffered and written once a second (async), so a flood of events never blocks the server with disk writes.
  let buf = []; let dropped = 0;
  const flush = () => {
    if (!file || !buf.length) return;
    const lines = buf; buf = [];
    try {
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      try { if (fs.statSync(file).size > maxBytes) fs.renameSync(file, `${file}.1`); } catch { /* no file yet */ }
      fs.appendFile(file, lines.join(''), { mode: 0o600 }, () => {});
    } catch { /* monitoring never breaks a request */ }
  };
  const timer = setInterval(flush, 1000); timer.unref?.();
  const write = (e) => { if (!file) return; if (buf.length >= 2000) { dropped += 1; return; } buf.push(`${JSON.stringify(e)}\n`); };
  const alert = (kind, key, title, body) => {
    const k = `${kind}|${key}`; const t = now();
    if (alerted.get(k) > t - 3600_000) return false;
    alerted.set(k, t); if (alerted.size > 5000) alerted.clear();
    const a = { at: t, kind, key, title, body }; alerts.unshift(a); alerts.length = Math.min(alerts.length, 100);
    write({ ...a, type: 'alert' });
    try { Promise.resolve(notify(title, body)).catch(() => {}); } catch { /* best effort */ }
    return true;
  };
  /** e: { kind, path, status, ip, uid? } */
  function record(e) {
    const t = now();
    const ev = { at: t, kind: e.kind, path: String(e.path || '').split('?')[0].slice(0, 80), status: e.status, ip: String(e.ip || '').slice(0, 64), uid: e.uid ? String(e.uid).slice(0, 8) : undefined };
    recentList.unshift(ev); recentList.length = Math.min(recentList.length, keep);
    write(ev);
    if (THRESHOLDS[e.kind]) {
      const k = `${e.kind}|${ev.ip}`; const arr = (counters.get(k) || []).filter((x) => t - x < WINDOW); arr.push(t); counters.set(k, arr);
      if (counters.size > 20000) counters.clear();
      if (arr.length >= THRESHOLDS[e.kind]) alert(ALERT_OF[e.kind], ev.ip, `⚠️ GOTRIVA TRADE AI security: ${ALERT_OF[e.kind]}`, `${arr.length} × ${e.kind} from ${ev.ip} in 10 min (last: ${ev.path}). Check the admin dashboard; block the IP at the firewall if it continues.`);
    }
    if (e.kind === 'admin_action' && SENSITIVE.test(ev.path)) alert('sensitive_change', `${ev.path}|${t}`, '🔐 GOTRIVA TRADE AI: a sensitive setting changed', `${ev.path} (${e.method || ''}) by account ${ev.uid || '?'}… from ${ev.ip}. If this was not you: sign out everywhere, rotate the keys (INCIDENT_RESPONSE_PLAN.md).`);
    return ev;
  }
  /** Classifies one finished API request. Called from the server's request wrapper on 'finish'. */
  function observe(req, res, pathname, ip) {
    if (!pathname.startsWith('/api/')) return null;
    const s = res.statusCode; const m = req.method; const uid = req._user?.uid;
    if (s === 401 && /^Bearer /.test(req.headers.authorization || '')) return record({ kind: 'auth_fail', path: pathname, status: s, ip });
    if (s === 403 && OWNER_PATH.test(pathname) && uid) return record({ kind: 'admin_denied', path: pathname, status: s, ip, uid });
    if (s === 429) return record({ kind: 'rate_limited', path: pathname, status: s, ip, uid });
    if (s >= 200 && s < 300 && m !== 'GET' && OWNER_PATH.test(pathname)) return record({ kind: 'admin_action', path: pathname, status: s, ip, uid, method: m });
    if (s === 200 && m === 'DELETE' && pathname === '/api/user/account') return record({ kind: 'account_deleted', path: pathname, status: s, ip, uid });
    return null;
  }
  const summary = () => {
    const t = now(); const by = {};
    for (const e of recentList) if (t - e.at < 86_400_000) by[e.kind] = (by[e.kind] || 0) + 1;
    return { last24h: by, alerts: alerts.slice(0, 30), recent: recentList.slice(0, 100), thresholds: THRESHOLDS };
  };
  return { record, observe, summary, file, flush, dropped: () => dropped };
}
