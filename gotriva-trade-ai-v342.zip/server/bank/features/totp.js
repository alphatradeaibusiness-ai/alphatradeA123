// Authenticator-app two-factor (TOTP, RFC 6238: HMAC-SHA1, 6 digits, 30 s) + one-time backup codes.
// The secret is envelope-encrypted (vault, AAD bound to the user). A code can be used once (the time step is remembered, so a
// code read over a shoulder cannot be replayed inside its window), and 5 wrong codes in 10 minutes lock the factor for the
// rest of that window. Backup codes are stored only as keyed hashes and each works once.
import crypto from 'node:crypto';
import { bad } from '../validate.js';

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
export const base32 = (buf) => { let bits = 0; let v = 0; let out = ''; for (const b of buf) { v = (v << 8) | b; bits += 8; while (bits >= 5) { out += B32[(v >>> (bits - 5)) & 31]; bits -= 5; } } if (bits) out += B32[(v << (5 - bits)) & 31]; return out; };
export const unbase32 = (s) => { let bits = 0; let v = 0; const out = []; for (const c of String(s).replace(/=+$/, '').toUpperCase()) { const i = B32.indexOf(c); if (i < 0) throw new Error('b32'); v = (v << 5) | i; bits += 5; if (bits >= 8) { out.push((v >>> (bits - 8)) & 255); bits -= 8; } } return Buffer.from(out); };
/** RFC 4226 HOTP value for a counter. */
export function hotp(secret, counter, digits = 6) {
  const c = Buffer.alloc(8); c.writeBigUInt64BE(BigInt(counter));
  const h = crypto.createHmac('sha1', secret).update(c).digest(); const o = h[19] & 15;
  return String(((h[o] & 127) << 24 | h[o + 1] << 16 | h[o + 2] << 8 | h[o + 3]) % 10 ** digits).padStart(digits, '0');
}
export const totpAt = (secret, ms) => hotp(secret, Math.floor(ms / 30000));
const eq = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));

export function createTotp(ctx) {
  const { db, A, now, vault } = ctx;
  const FAILS = 5; const WINDOW = 10 * 60_000;
  const row = (uid) => db.prepare('SELECT * FROM totp WHERE uid = ?').get(uid);
  const enabled = (uid) => Boolean(row(uid)?.confirmed_at);
  const aad = (uid) => `totp:${uid}`;
  const locked = (uid) => db.prepare("SELECT COUNT(*) c FROM audit WHERE actor = ? AND action = 'totp.fail' AND ts > ?").get(uid, now() - WINDOW).c >= FAILS;
  const fail = (uid) => { db.tx(() => A.log(uid, 'totp.fail', uid, {})); };
  const norm = (c) => String(c ?? '').replace(/[\s-]/g, '');
  const backupHash = (uid, code) => vault.blind(`bk:${uid}:${norm(code).toLowerCase()}`);

  function enroll(uid, label = '') {
    if (!vault?.available) bad('encryption_unavailable', 503);
    if (enabled(uid)) bad('totp_exists', 409);
    const secret = crypto.randomBytes(20); const b32 = base32(secret);
    db.tx(() => {
      db.prepare('INSERT INTO totp (uid, secret_enc, confirmed_at, last_step, created_at) VALUES (?,?,NULL,0,?) ON CONFLICT(uid) DO UPDATE SET secret_enc = excluded.secret_enc, confirmed_at = NULL, last_step = 0, created_at = excluded.created_at')
        .run(uid, ctx.seal({ s: b32 }, aad(uid)), now());
      A.log(uid, 'totp.enroll', uid, {});
    });
    const acct = encodeURIComponent(String(label || 'account').slice(0, 60));
    return { secret: b32, uri: `otpauth://totp/GOTRIVA%20TRADE:${acct}?secret=${b32}&issuer=GOTRIVA%20TRADE&algorithm=SHA1&digits=6&period=30` };
  }
  /** Checks a 6-digit code (±1 step). Returns the accepted step, or 0. Never reuses a step. */
  function checkCode(uid, code, { consume = true } = {}) {
    const r = row(uid); const c = norm(code);
    if (!r || !/^\d{6}$/.test(c)) return 0;
    let secret; try { secret = unbase32(ctx.open(r.secret_enc, aad(uid)).s); } catch { return 0; }
    const cur = Math.floor(now() / 30000);
    for (const step of [cur, cur - 1, cur + 1]) {
      if (step <= r.last_step) continue;
      if (eq(hotp(secret, step), c)) { if (consume) db.prepare('UPDATE totp SET last_step = ? WHERE uid = ? AND last_step < ?').run(step, uid, step); return step; }
    }
    return 0;
  }
  function confirm(uid, code) {
    const r = row(uid); if (!r) bad('totp_not_started', 409); if (r.confirmed_at) bad('totp_exists', 409);
    if (locked(uid)) bad('too_many_attempts', 429);
    if (!checkCode(uid, code)) { fail(uid); bad('totp_invalid', 401); }
    const codes = Array.from({ length: 8 }, () => crypto.randomBytes(5).toString('hex'));
    db.tx(() => {
      db.prepare('UPDATE totp SET confirmed_at = ? WHERE uid = ?').run(now(), uid);
      db.prepare('DELETE FROM totp_backup WHERE uid = ?').run(uid);
      for (const k of codes) db.prepare('INSERT INTO totp_backup (uid, hash, used_at) VALUES (?,?,NULL)').run(uid, backupHash(uid, k));
      A.log(uid, 'totp.enable', uid, {});
    });
    ctx.notify?.(uid, 'security_changed', {});
    return { backupCodes: codes.map((k) => `${k.slice(0, 5)}-${k.slice(5)}`) };
  }
  /** The factor check used by the gate: a current code or an unused backup code. Throws on failure. */
  function require(uid, code) {
    if (!enabled(uid)) return false;
    if (locked(uid)) bad('too_many_attempts', 429);
    if (code == null || code === '') bad('totp_required', 401);
    const c = norm(code);
    if (/^\d{6}$/.test(c)) { if (checkCode(uid, c)) return true; }
    else if (/^[0-9a-fA-F]{10}$/.test(c)) {
      const r = db.prepare('UPDATE totp_backup SET used_at = ? WHERE uid = ? AND hash = ? AND used_at IS NULL').run(now(), uid, backupHash(uid, c));
      if (r.changes) { db.tx(() => A.log(uid, 'totp.backup_used', uid, {})); ctx.notify?.(uid, 'security_changed', {}); return true; }
    }
    fail(uid); bad('totp_invalid', 401);
  }
  function disable(uid, code) {
    require(uid, code);
    db.tx(() => { db.prepare('DELETE FROM totp WHERE uid = ?').run(uid); db.prepare('DELETE FROM totp_backup WHERE uid = ?').run(uid); A.log(uid, 'totp.disable', uid, {}); });
    ctx.notify?.(uid, 'security_changed', {});
    return { ok: true };
  }
  function newBackupCodes(uid, code) {
    require(uid, code);
    const codes = Array.from({ length: 8 }, () => crypto.randomBytes(5).toString('hex'));
    db.tx(() => { db.prepare('DELETE FROM totp_backup WHERE uid = ?').run(uid); for (const k of codes) db.prepare('INSERT INTO totp_backup (uid, hash, used_at) VALUES (?,?,NULL)').run(uid, backupHash(uid, k)); A.log(uid, 'totp.backup_new', uid, {}); });
    return { backupCodes: codes.map((k) => `${k.slice(0, 5)}-${k.slice(5)}`) };
  }
  const status = (uid) => ({ enabled: enabled(uid), pending: Boolean(row(uid)) && !enabled(uid), backupLeft: enabled(uid) ? db.prepare('SELECT COUNT(*) c FROM totp_backup WHERE uid = ? AND used_at IS NULL').get(uid).c : 0 });
  return { enabled, enroll, confirm, require, disable, newBackupCodes, status };
}
