// One AI gateway for the whole site: the provider, the key (encrypted at rest), the models, a real connection check,
// clear error codes and per-user limits. Every AI feature in the browser calls this server; the key never leaves it.
//
//   Storage: <SERVER_DATA_DIR>/ai-config.json (mode 600). The key is AES-256-GCM encrypted with a key derived from
//            AI_KEY_SECRET (scrypt). Without AI_KEY_SECRET nothing can be saved. Only the last 4 characters are ever
//            returned (to the owner); logs never contain the key.
//   Providers: 'anthropic' (Claude Messages API) or 'openai' (any OpenAI-compatible Chat Completions API, with its
//            own base URL and models — the key is never assumed to work with another company).
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export const PROVIDERS = ['anthropic', 'openai'];
export const DEFAULT_MODELS = { anthropic: 'claude-opus-5-5', openai: '' };
const TEST_PNG = 'iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAAK0lEQVR4nO3NQQEAAATAQATRP5QwSvC7BdjldMdn9XoHAAAAAAAAAAAAhy3SgAFYpLG4gwAAAABJRU5ErkJggg==';

/* ───────── encrypted store ───────── */
export function createStore({ dir, secret, name = 'ai-config.json' }) {
  const file = path.join(dir, name);
  const key = secret && String(secret).length >= 32 ? crypto.scryptSync(String(secret), 'alphatrade-ai-key-v1', 32) : null;
  const enc = (plain) => {
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', key, iv);
    const data = Buffer.concat([c.update(plain, 'utf8'), c.final()]);
    return { iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: data.toString('base64') };
  };
  const dec = (e) => {
    const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(e.iv, 'base64'));
    d.setAuthTag(Buffer.from(e.tag, 'base64'));
    return Buffer.concat([d.update(Buffer.from(e.data, 'base64')), d.final()]).toString('utf8');
  };
  return {
    file,
    canSave: () => Boolean(key),
    /** Stored record WITHOUT the key. */
    meta() {
      try { const r = JSON.parse(fs.readFileSync(file, 'utf8')); delete r.keyEnc; return r; } catch { return null; }
    },
    /** Stored record WITH the decrypted key (server-side use only), or null. */
    load() {
      if (!key) return null;
      try {
        const r = JSON.parse(fs.readFileSync(file, 'utf8'));
        if (!r.keyEnc) return null;
        const apiKey = dec(r.keyEnc); delete r.keyEnc;
        return { ...r, apiKey };
      } catch { return null; }   // missing file, or a different AI_KEY_SECRET (cannot decrypt) → not configured
    },
    save(record) {
      if (!key) throw new Error('no-secret');
      const { apiKey, ...rest } = record;
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      const tmp = `${file}.${process.pid}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify({ ...rest, keyEnc: enc(apiKey) }), { mode: 0o600 });
      fs.renameSync(tmp, file);
    },
    update(patch) {   // status fields only (never the key)
      try { const r = JSON.parse(fs.readFileSync(file, 'utf8')); fs.writeFileSync(file, JSON.stringify({ ...r, ...patch, keyEnc: r.keyEnc }), { mode: 0o600 }); } catch { /* nothing stored */ }
    },
    remove() { try { fs.rmSync(file, { force: true }); } catch { /* already gone */ } },
  };
}

/* ───────── error classification ───────── */
/**
 * Maps a provider failure to one code the site can explain:
 * invalid_key · no_credit · rate_limit · model_unavailable · no_permission · vision_unsupported · overloaded · bad_request · timeout · network · unknown
 */
export function classify(provider, status, body, { image = false } = {}) {
  const err = body?.error || {};
  const msg = String(err.message || body?.message || '').toLowerCase();
  const type = String(err.type || err.code || '').toLowerCase();
  if (status === 401 || type.includes('authentication') || type === 'invalid_api_key') return 'invalid_key';
  if (/credit balance|insufficient_quota|billing|quota|payment required/.test(msg + ' ' + type) || status === 402) return 'no_credit';
  if (status === 429 || type.includes('rate_limit')) return 'rate_limit';
  if (status === 404 || type.includes('not_found') || /model.*(not found|does not exist|not available)|model_not_found/.test(msg + ' ' + type)) return 'model_unavailable';
  if (status === 403 || type.includes('permission')) return 'no_permission';
  if (image && status === 400 && /image|vision|multimodal|content type|image_url/.test(msg)) return 'vision_unsupported';
  if (status === 529 || status === 503 || type.includes('overloaded')) return 'overloaded';
  if (status === 400) return 'bad_request';
  return 'unknown';
}

/* ───────── provider calls ───────── */
/**
 * @param cfg   { provider, apiKey, baseUrl, model, visionModel }
 * @param req   { system, messages: [{role, content: string}], image: 'data:image/..;base64,..' | null, maxTokens }
 * @returns { ok: true, text, model } | { ok: false, code, status }
 */
export async function callProvider(cfg, req, { fetchImpl = fetch, anthropicBase = 'https://api.anthropic.com', timeoutMs = 60_000 } = {}) {
  const image = req.image ? /^data:(image\/(?:png|jpeg|webp|gif));base64,(.+)$/.exec(req.image) : null;
  if (req.image && !image) return { ok: false, code: 'bad_request', status: 400 };
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  const msgs = req.messages.map((m) => ({ role: m.role, content: m.content }));
  try {
    let r; let model;
    if (cfg.provider === 'openai') {
      model = image ? (cfg.visionModel || '') : cfg.model;
      if (!model) return { ok: false, code: image ? 'vision_unsupported' : 'model_unavailable', status: 0 };
      if (image) {
        const last = msgs[msgs.length - 1];
        last.content = [{ type: 'image_url', image_url: { url: req.image } }, { type: 'text', text: last.content }];
      }
      r = await fetchImpl(`${String(cfg.baseUrl).replace(/\/$/, '')}/chat/completions`, {
        method: 'POST', signal: ctrl.signal,
        headers: { 'content-type': 'application/json', authorization: `Bearer ${cfg.apiKey}` },
        body: JSON.stringify({ model, max_tokens: req.maxTokens || 700, temperature: 0.2, messages: [{ role: 'system', content: req.system }, ...msgs] }),
      });
    } else {
      model = cfg.model || DEFAULT_MODELS.anthropic;
      if (image) {
        const last = msgs[msgs.length - 1];
        last.content = [{ type: 'image', source: { type: 'base64', media_type: image[1], data: image[2] } }, { type: 'text', text: last.content }];
      }
      r = await fetchImpl(`${anthropicBase.replace(/\/$/, '')}/v1/messages`, {
        method: 'POST', signal: ctrl.signal,
        headers: { 'content-type': 'application/json', 'x-api-key': cfg.apiKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model, max_tokens: Math.max(req.maxTokens || 700, 4096), system: req.system, messages: msgs }),   // v311: hidden reasoning counts against max_tokens; the prompts cap the visible answer, so the room costs nothing
      });
    }
    let body = await r.json().catch(() => ({}));
    if (!r.ok) return { ok: false, code: classify(cfg.provider, r.status, body, { image: Boolean(image) }), status: r.status };
    const pick = (b) => (cfg.provider === 'openai'
      ? String(b?.choices?.[0]?.message?.content || '')
      : (b.content || []).filter((x) => x.type === 'text').map((x) => x.text).join('\n'));
    let text = pick(body);
    // v302: a 200 reply with no text block (the model spent its tokens on hidden reasoning, or stopped early): ask once more with reasoning off and more room.
    if (!text.trim() && cfg.provider !== 'openai') {
      let diag = `stop=${body.stop_reason || '?'} blocks=${(body.content || []).map((x) => x.type).join(',') || 'none'}`;
      const again = async (extra, max) => {
        const rr = await fetchImpl(`${anthropicBase.replace(/\/$/, '')}/v1/messages`, {
          method: 'POST', signal: ctrl.signal,
          headers: { 'content-type': 'application/json', 'x-api-key': cfg.apiKey, 'anthropic-version': '2023-06-01' },
          body: JSON.stringify({ model, max_tokens: max, ...extra, system: req.system, messages: msgs }),
        }).catch(() => null);
        const bb = rr && rr.ok ? await rr.json().catch(() => ({})) : null;
        return { bb, st: rr ? rr.status : 'net', t: bb ? pick(bb) : '' };
      };
      // 2nd try: reasoning off; 3rd try (if the model refuses that switch): reasoning left on with a much larger budget
      let x = await again({ thinking: { type: 'disabled' } }, Math.max((req.maxTokens || 700) * 2, 4096));
      if (!x.t.trim()) { const y = await again({}, 8000); diag += ` retry1=${x.st} retry2=${y.st}`; x = y; }
      text = x.t;
      if (text.trim()) body = x.bb; else return { ok: false, code: 'unknown', status: r.status, diag };
    }
    if (!text.trim()) return { ok: false, code: 'unknown', status: r.status };
    return { ok: true, text, model: body.model || model };
  } catch (e) {
    return { ok: false, code: e?.name === 'AbortError' ? 'timeout' : 'network', status: 0 };
  } finally { clearTimeout(timer); }
}

/**
 * Real connection check: one tiny text request, then one tiny image request (does this key + model read images?).
 * Returns { ok, code, vision: { ok, code } } — never claims success without a successful provider reply.
 */
export async function testConfig(cfg, opts = {}) {
  const t = await callProvider(cfg, { system: 'Reply with the single word OK.', messages: [{ role: 'user', content: 'ping' }], maxTokens: 8 }, opts);
  if (!t.ok) return { ok: false, code: t.code, status: t.status, vision: { ok: false, code: 'not_tested' } };
  const v = await callProvider(cfg, { system: 'Answer with one word.', messages: [{ role: 'user', content: 'What is the main colour of this image?' }], image: `data:image/png;base64,${TEST_PNG}`, maxTokens: 8 }, opts);
  return { ok: true, code: null, model: t.model, vision: v.ok ? { ok: true, code: null } : { ok: false, code: v.code === 'bad_request' ? 'vision_unsupported' : v.code } };
}

/* ───────── per-user limits ───────── */
export function createUserLimiter({ perMinute = 10, perDay = 200 } = {}) {
  const minute = new Map(); const day = { d: '', n: new Map() };
  return (uid, now = Date.now()) => {
    const d = new Date(now).toISOString().slice(0, 10);
    if (day.d !== d) { day.d = d; day.n.clear(); }
    const arr = (minute.get(uid) || []).filter((x) => now - x < 60_000);
    if (arr.length >= perMinute) return 'user_rate_minute';
    if ((day.n.get(uid) || 0) >= perDay) return 'user_rate_day';
    arr.push(now); minute.set(uid, arr); day.n.set(uid, (day.n.get(uid) || 0) + 1);
    if (minute.size > 10000) minute.clear();
    return '';
  };
}

/** Validates the owner's form. Returns { value } or { error }. */
export function cleanConfig(input = {}, { allowHttpLocal = false } = {}) {
  const provider = PROVIDERS.includes(input.provider) ? input.provider : null;
  if (!provider) return { error: 'provider' };
  const apiKey = typeof input.apiKey === 'string' ? input.apiKey.trim() : '';
  if (apiKey && (apiKey.length < 20 || apiKey.length > 300 || /[^\x21-\x7e]/.test(apiKey))) return { error: 'key_format' };
  const model = String(input.model || DEFAULT_MODELS[provider] || '').trim().slice(0, 120);
  const visionModel = String(input.visionModel || '').trim().slice(0, 120);
  let baseUrl = '';
  if (provider === 'openai') {
    baseUrl = String(input.baseUrl || '').trim().replace(/\/$/, '');
    const okUrl = /^https:\/\/[^\s/]+(\/[^\s]*)?$/.test(baseUrl) || (allowHttpLocal && /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?(\/[^\s]*)?$/.test(baseUrl));
    if (!okUrl) return { error: 'base_url' };
    if (!model) return { error: 'model' };
  }
  if (/[^\w.\-:/@]/.test(model) || /[^\w.\-:/@]/.test(visionModel)) return { error: 'model' };
  return { value: { provider, apiKey, model, visionModel: provider === 'anthropic' ? '' : visionModel, baseUrl } };
}
