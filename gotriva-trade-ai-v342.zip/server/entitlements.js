// What a signed-in user may use, decided on the server (the browser can be edited, the server cannot).
//   ENFORCE_PLANS=1   paid features need an active plan: AI tools (with the plan's monthly allowance) and the
//                     server-side trade alerts. Off by default, so nothing changes until payments are live.
// Charting, back-tests and the other tools that run inside the browser cannot be truly locked by any website;
// those stay locked in the page (VITE_ENFORCE_PLANS) — the expensive and server-run parts are locked here.
import fs from 'node:fs';
import path from 'node:path';
import { TIERS, NAV_RANK } from '../src/config/entitlements.js';

const monthKey = (ms) => { const d = new Date(ms); return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`; };
const prevKey = (ms) => { const d = new Date(ms); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() - 1); return monthKey(+d); };

export function createEntitlements({ dir, access, env = process.env, now = Date.now }) {
  const enforce = env.ENFORCE_PLANS === '1';
  const file = path.join(dir, 'ai-usage.json');
  let cache = null;
  const load = () => { if (cache) return cache; try { cache = JSON.parse(fs.readFileSync(file, 'utf8')) || {}; } catch { cache = {}; } return cache; };
  const save = () => { fs.mkdirSync(dir, { recursive: true, mode: 0o700 }); const tmp = `${file}.${process.pid}.tmp`; fs.writeFileSync(tmp, JSON.stringify(cache), { mode: 0o600 }); fs.renameSync(tmp, file); };

  const planOf = (uid) => { const s = access.subscription(uid, now()); return s && TIERS[s.product] ? s.product : null; };
  function aiAllowance(uid) {
    const plan = planOf(uid); const t = TIERS[plan];
    if (!t) return { plan: null, total: 0, used: 0, left: 0 };
    const u = load()[uid] || {}; const k = monthKey(now());
    const unusedLast = Math.max(0, t.aiPerMonth - (u[prevKey(now())] || 0));
    const total = t.aiPerMonth + Math.min(unusedLast, t.aiPerMonth * t.aiCarryMonths);
    const used = u[k] || 0;
    return { plan, total, used, left: Math.max(0, total - used) };
  }
  /** Before an AI call. Returns null when allowed, else an error code. Owners are never limited. */
  function checkAi(user, { owner = false, support = false } = {}) {
    if (owner || !enforce || support) return null;   // the help chat stays free so people can ask before buying
    const a = aiAllowance(user.uid);
    if (!a.plan) return 'plan_required';
    if (a.plan === 'channel') return 'platform_plan_required';
    if (a.left <= 0) return 'ai_quota';
    return null;
  }
  /** After a successful AI call. */
  function countAi(uid) {
    const all = load(); const u = all[uid] || (all[uid] = {}); const k = monthKey(now());
    u[k] = (u[k] || 0) + 1;
    for (const key of Object.keys(u).sort().slice(0, -3)) delete u[key];   // keep three months
    save();
  }
  const canTradeAlerts = (uid) => !enforce || Boolean(planOf(uid));
  /** v323: the same page ranks as the side menu (NAV_RANK), checked here so a hidden button is never the only lock.
   *  Expired subscriptions count as no plan (access.subscription only returns an active one). Owners always pass. */
  function canPage(uid, page, { owner = false } = {}) {
    if (!enforce || owner) return true;
    const need = NAV_RANK[page] || 0; if (!need) return true;
    const plan = planOf(uid); return Boolean(plan) && (TIERS[plan]?.rank || 0) >= need;
  }
  const forget = (uid) => { const all = load(); if (all[uid]) { delete all[uid]; save(); } };
  return { enforce, planOf, aiAllowance, checkAi, countAi, canTradeAlerts, canPage, forget };
}
