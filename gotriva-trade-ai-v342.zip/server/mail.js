// Account e-mails (v295): a welcome e-mail on the first sign-in and a notice on later sign-ins, sent from "GOTRIVA TRADE AI".
// Provider: Resend (https://resend.com). The key is read only from the server environment and never leaves it:
//   RESEND_API_KEY   the API key (set on Render by the owner; without it nothing is sent and nothing breaks)
//   MAIL_FROM        e.g. GOTRIVA TRADE AI <hello@your-domain.com>  (a domain verified in Resend)
//   PUBLIC_URL       link used in the e-mails
import fs from 'node:fs';
import path from 'node:path';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const SIGNIN_GAP_MS = 10 * 60_000;

export function renderMail(kind, { name = '', when = '', url = '' } = {}) {
  const n = esc(String(name).split(' ')[0] || '');
  const welcome = kind === 'welcome';
  const subject = welcome ? 'Welcome to GOTRIVA TRADE AI | أهلاً فيك بـ GOTRIVA TRADE AI' : 'New sign-in to your GOTRIVA TRADE AI account | تسجيل دخول جديد';
  const ar = welcome
    ? `أهلاً ${n}، تم إنشاء حسابك بنجاح. تقدر تفتح الشارت والتحليل والإشارات من الرابط تحت. تذكير: كل المحتوى تعليمي وليس نصيحة مالية، والتداول فيه مخاطرة.`
    : `تم تسجيل دخول لحسابك بتاريخ ${esc(when)}. إذا كنت إنت، ما بدك تعمل شي. إذا مش إنت، غيّر كلمة المرور فوراً.`;
  const en = welcome
    ? `Hi ${n}, your account is ready. Open the charts, analysis and signals from the link below. Reminder: everything here is educational, not financial advice, and trading carries risk.`
    : `Your account was signed in on ${esc(when)}. If this was you, no action is needed. If it was not you, change your password right away.`;
  const html = `<!doctype html><html><body style="margin:0;background:#0b0a14;font-family:Arial,Helvetica,sans-serif"><table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px 12px"><table width="560" style="max-width:100%;background:#15132a;border-radius:14px;padding:28px;color:#e8e6f5"><tr><td><div style="font-size:22px;font-weight:700;color:#fff">GOTRIVA TRADE <span style="color:#a78bfa">AI</span></div><p style="font-size:15px;line-height:1.8;margin:18px 0">${en}</p><p dir="rtl" style="font-size:15px;line-height:1.9;margin:18px 0;color:#d6d3ee">${ar}</p>${url ? `<p style="margin:22px 0"><a href="${esc(url)}" style="background:#7c3aed;color:#fff;text-decoration:none;padding:12px 22px;border-radius:10px;font-weight:700;display:inline-block">${welcome ? 'Open GOTRIVA TRADE AI' : 'Open my account'}</a></p>` : ''}<p style="font-size:12px;color:#8b87a8;line-height:1.7;margin-top:24px">Trading carries high risk. All sales are final. You get this e-mail because someone used this address on GOTRIVA TRADE AI.</p></td></tr></table></td></tr></table></body></html>`;
  const text = `${en}\n\n${ar}\n${url ? `\n${url}\n` : ''}`;
  return { subject, html, text };
}

export function createMailer({ dir, env = process.env, fetchImpl = fetch, now = Date.now } = {}) {
  const file = dir ? path.join(dir, 'mail-state.json') : null;
  let st = null;
  const load = () => { if (st) return st; st = { welcomed: {}, lastSignin: {} }; if (file) { try { st = { ...st, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch { /* none yet */ } } return st; };
  const save = () => { if (!file) return; try { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(file, JSON.stringify(st), { mode: 0o600 }); } catch { /* disk not writable: the e-mail still goes out */ } };
  const key = () => String(env.RESEND_API_KEY || '').trim();
  const from = () => String(env.MAIL_FROM || 'GOTRIVA TRADE AI <onboarding@resend.dev>');
  return {
    configured: () => Boolean(key()),
    /** Called after a sign-in. First time for this account: welcome; later: a sign-in notice (at most one per 10 minutes). */
    async onSignin(user) {
      if (!key()) return { sent: false, reason: 'not_configured' };
      const to = String(user?.email || '').trim(); if (!to || !user.uid) return { sent: false, reason: 'no_email' };
      const s = load(); const t = now();
      let kind = 'signin';
      if (!s.welcomed[user.uid]) kind = 'welcome';
      else if (t - (s.lastSignin[user.uid] || 0) < SIGNIN_GAP_MS) return { sent: false, reason: 'recent' };
      const url = String(env.PUBLIC_URL || '').replace(/\/$/, '');
      const m = renderMail(kind, { name: user.name || '', when: new Date(t).toUTCString(), url });
      try {
        const res = await fetchImpl('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: `Bearer ${key()}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ from: from(), to: [to], subject: m.subject, html: m.html, text: m.text }), signal: AbortSignal.timeout(10_000) });
        if (!res.ok) return { sent: false, reason: `provider_${res.status}` };
      } catch { return { sent: false, reason: 'network' }; }
      if (kind === 'welcome') s.welcomed[user.uid] = t;
      s.lastSignin[user.uid] = t; save();
      return { sent: true, kind };
    },
  };
}
