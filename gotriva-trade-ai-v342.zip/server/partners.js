// v255 GOTRIVA PARTNER CLUB — affiliate program engine. Everything financial is decided HERE, on the server:
//  • partners: unique referral code (ALPHA-<RANK>-NNNNN) = link code = coupon code; clicks, registrations, paying customers
//  • ranks: 9 rank groups, 100 levels, each with its own requirement (verified, paying, unique customers; refunds excluded);
//    owners can edit every level, every rank, every benefit — benefits change real server behaviour (multiplier, holding
//    period, minimum payout, coupon discount, rank bonus, statistics depth, recognition)
//  • commissions: driven ONLY by Stripe payments that the signed webhook confirmed (server/stripe.js → onPayment). The first
//    paid purchase of a referred customer = NEW commission (and +1 qualified referral); every later purchase = RENEWAL
//    commission (lower, same original partner, never counted again). Matrix: 9 ranks × 7 price points × {new %, new fixed,
//    renewal %, renewal fixed}. Nothing is set by default — the owners set the numbers.
//  • financial protection: net revenue = collected − taxes − processing fees − other costs; a commission that breaks the
//    minimum margin or a cap is NOT changed — it is held for review with the numbers explained
//  • holding period, refunds / chargebacks (reverse unpaid, claw back paid), payouts (request → approve → paid only with a
//    payment reference typed by an owner), monthly reports, CSV export, hash-chained audit log (append-only)
//  • fraud: self-referral, same e-mail, same network as the partner, existing customers, duplicate registrations, suspended
//    partners — refused or held for review
// Storage: one AES-256-GCM encrypted file (key from AI_KEY_SECRET); every money change is written at once.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { RANKS, PRICE_TIERS, defaultLevels, DEFAULT_RANK_BENEFITS, BENEFITS, rankOfLevel } from '../src/config/partnerRanks.js';

const DAY = 86_400_000;
const clip = (s, n) => String(s ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, n);
const hex = (n = 6) => crypto.randomBytes(n).toString('hex');
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const int = (v, lo, hi, d = 0) => { const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
const num = (v, lo, hi, d = 0) => { const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
const month = (t) => new Date(t).toISOString().slice(0, 7);
const day = (t) => new Date(t).toISOString().slice(0, 10);
export const normEmail = (e) => { let [a, d] = String(e || '').toLowerCase().trim().split('@'); if (!a || !d) return ''; a = a.split('+')[0]; if (d === 'gmail.com' || d === 'googlemail.com') { a = a.replace(/\./g, ''); d = 'gmail.com'; } return `${a}@${d}`; };
const RANK_IDS = RANKS.map((r) => r.id);

const T = {
  welcome: ['أهلاً بك في نادي شركاء جوتريفا!', 'Welcome to Gotriva Partner Club!', 'رابطك وكوبونك جاهزين بلوحة الشريك.', 'Your link and coupon are ready on your partner dashboard.'],
  first_paid: ['مبروك! أول إحالة إلك تحوّلت لعميل دافع!', 'Congratulations! Your first referral has converted!', 'عميل جديد دفع اشتراكه عن طريقك.', 'A new customer paid through you.'],
  progress75: ['وصلت 75% من رتبتك الجاية!', 'You have reached 75% of your next rank!', 'كمّل — باقي {left} عميل.', 'Keep going — {left} more to go.'],
  rank_up: ['مبروك! فتحت رتبة {rank}!', 'Congratulations! You unlocked {rank} Rank!', 'مستواك هلّق {level} من 100.', 'You are now level {level} of 100.'],
  first_commission: ['أول عمولة إلك انحسبت!', 'Your first partner commission has been earned!', '{amount} — بتصير متاحة بعد فترة الحجز.', '{amount} — available after the holding period.'],
  renewal: ['عميل من طرفك جدّد اشتراكه!', 'Your referred customer renewed their subscription!', 'عمولة تجديد: {amount}.', 'Renewal commission: {amount}.'],
  payout: ['تمت الموافقة على سحبك!', 'Your payout has been approved!', 'المبلغ {amount} — بنعلمك لما ينبعت.', 'Amount {amount} — we will tell you when it is sent.'],
  payout_paid: ['انبعت سحبك', 'Your payout was sent', 'المبلغ {amount} — المرجع {ref}.', 'Amount {amount} — reference {ref}.'],
  legend: ['أهلاً بك في أسطورة جوتريفا!', 'Welcome to Gotriva Legend!', 'وصلت أعلى رتبة بنادي الشركاء.', 'You reached the highest partner rank.'],
};
const usd = (c) => `$${(c / 100).toFixed(2)}`;

function defaultConfig() {
  const ranks = {}; for (const r of RANKS) ranks[r.id] = { multiplier: 1, bonusCents: 0, holdDays: null, minPayoutCents: null, couponDiscountPct: null, benefits: [...DEFAULT_RANK_BENEFITS[r.id]] };
  const matrix = {}; for (const r of RANKS) { matrix[r.id] = {}; for (const t of PRICE_TIERS) matrix[r.id][t] = { newPct: 0, newFixedCents: 0, renPct: 0, renFixedCents: 0 }; }
  return {
    enabled: false, levels: defaultLevels(), ranks, matrix,
    finance: { taxPct: 0, feePct: 2.9, feeFixedCents: 30, otherPct: 0, minMarginPct: 50, maxCommissionPct: 50, maxCommissionCents: Object.fromEntries(PRICE_TIERS.map((t) => [t, null])), holdDays: 30, autoApprove: true },
    payout: { minPayoutCents: 5000, day: 5 },
    coupon: { discountPct: 0 },
    notify: Object.fromEntries(Object.keys(T).map((k) => [k, true])),
    gate: { telegram: true, inviteUrl: '' },   // v261: the club is only for members of the Telegram channel
    updatedAt: 0,
  };
}

export function createPartners({ dir, secret, now = Date.now, deliver = async () => null, langOf = () => 'ar', hasPaid = () => false, catalogue = {}, env = process.env } = {}) {
  const key = secret && String(secret).length >= 32 ? crypto.scryptSync(String(secret), 'alphatrade-partners-v1', 32) : null;
  const file = path.join(dir, 'partners.json'); let db = null;
  const enc = (buf) => { const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from('partners')); const d = Buffer.concat([c.update(buf), c.final()]); return Buffer.concat([iv, c.getAuthTag(), d]); };
  const dec = (buf) => { const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12)); d.setAAD(Buffer.from('partners')); d.setAuthTag(buf.subarray(12, 28)); return Buffer.concat([d.update(buf.subarray(28)), d.final()]); };
  const load = () => {
    if (db) return db;
    db = { config: defaultConfig(), partners: {}, codes: {}, referrals: {}, emails: {}, clicks: {}, commissions: [], byPayment: {}, payouts: [], audit: [], seq: 0 };
    if (key) { try { const j = JSON.parse(dec(fs.readFileSync(file)).toString('utf8')); db = { ...db, ...j, config: { ...defaultConfig(), ...j.config, gate: { ...defaultConfig().gate, ...(j.config?.gate || {}) } } }; } catch { /* first start */ } }
    return db;
  };
  const save = () => { if (!key || !db) return; fs.mkdirSync(dir, { recursive: true, mode: 0o700 }); const tmp = `${file}.${process.pid}.${hex(3)}.tmp`; fs.writeFileSync(tmp, enc(Buffer.from(JSON.stringify(db))), { mode: 0o600 }); fs.renameSync(tmp, file); };
  /** Append-only, hash-chained audit record. */
  function audit(type, data) {
    const d = load(); const prev = d.audit.at(-1)?.hash || '0'.repeat(16); const seq = (d.seq || 0) + 1; d.seq = seq;
    const rec = { seq, at: now(), type, data }; rec.prev = prev; rec.hash = sha(`${prev}|${seq}|${rec.at}|${type}|${JSON.stringify(data)}`).slice(0, 32);
    d.audit.push(rec); return rec;
  }
  const verifyAudit = () => { let prev = '0'.repeat(16); for (const r of load().audit) { if (r.prev !== prev || r.hash !== sha(`${prev}|${r.seq}|${r.at}|${r.type}|${JSON.stringify(r.data)}`).slice(0, 32)) return { ok: false, seq: r.seq }; prev = r.hash; } return { ok: true, n: load().audit.length }; };
  const cfg = () => load().config;
  const custRef = (uid) => `C-${sha(`cust|${uid}|${secret}`).slice(0, 6).toUpperCase()}`;
  const tierOf = (cents) => (PRICE_TIERS.includes(cents) ? cents : null);

  /* ── ranks ── */
  const qualified = (pid) => Object.values(load().referrals).filter((r) => r.partner === pid && r.paidAt && !r.void).length;
  const levelFor = (q) => { let lv = 1; for (const l of cfg().levels) if (q >= l.req) lv = l.level; return lv; };
  const rankCfg = (rid) => cfg().ranks[rid] || { multiplier: 1, benefits: [] };
  const has = (rid, b) => (rankCfg(rid).benefits || []).includes(b);
  const holdDaysFor = (rid) => (has(rid, 'shorter_hold') && rankCfg(rid).holdDays != null ? rankCfg(rid).holdDays : cfg().finance.holdDays);
  const minPayoutFor = (rid) => (has(rid, 'lower_min_payout') && rankCfg(rid).minPayoutCents != null ? rankCfg(rid).minPayoutCents : cfg().payout.minPayoutCents);
  const couponPctFor = (rid) => (has(rid, 'coupon_discount') && rankCfg(rid).couponDiscountPct != null ? rankCfg(rid).couponDiscountPct : cfg().coupon.discountPct);
  const multFor = (rid) => (has(rid, 'multiplier') ? Number(rankCfg(rid).multiplier) || 1 : 1);

  function notify(uid, kind, vars = {}) {
    if (!cfg().notify[kind]) return; const t = T[kind]; if (!t) return; const ar = langOf(uid) === 'ar';
    const fill = (s) => s.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? ''));
    Promise.resolve(deliver(uid, { kind: 'partner', title: fill(ar ? t[0] : t[1]), body: fill(ar ? t[2] : t[3]), url: '/#/app/partners', email: ['first_paid', 'rank_up', 'payout', 'payout_paid', 'legend'].includes(kind), tg: true })).catch(() => {});
  }
  /** Recompute a partner's level after a change; rank-up → bonus (once per rank) + level rewards (once per level) + notices. */
  function refreshRank(pid) {
    const p = load().partners[pid]; if (!p) return; const q = qualified(pid); const lv = levelFor(q); const before = p.level || 1; p.level = lv; p.qualified = q;
    const r0 = rankOfLevel(before).id, r1 = rankOfLevel(lv).id;
    if (lv > before) {
      for (const l of cfg().levels) if (l.level > before && l.level <= lv && l.rewardCents > 0 && !p.levelRewards?.includes(l.level)) {
        (p.levelRewards ||= []).push(l.level); addCommission({ partner: pid, kind: 'level_reward', amountCents: l.rewardCents, note: `level ${l.level}`, status: 'approved' });
      }
      p.rankHistory = [...(p.rankHistory || []), { at: now(), from: before, to: lv }].slice(-200); audit('level', { partner: pid, from: before, to: lv, qualified: q });
      if (r1 !== r0) {
        const rc = rankCfg(r1); if (has(r1, 'rank_bonus') && rc.bonusCents > 0 && !p.rankBonuses?.includes(r1)) { (p.rankBonuses ||= []).push(r1); addCommission({ partner: pid, kind: 'rank_bonus', amountCents: rc.bonusCents, note: r1, status: 'approved' }); }
        notify(pid, r1 === 'legend' ? 'legend' : 'rank_up', { rank: RANKS.find((x) => x.id === r1).name[langOf(pid) === 'ar' ? 'ar' : 'en'], level: lv });
      }
    } else if (lv < before) { p.rankHistory = [...(p.rankHistory || []), { at: now(), from: before, to: lv, reason: 'refund_or_fraud' }].slice(-200); audit('level', { partner: pid, from: before, to: lv, qualified: q }); }
    const nxt = cfg().levels.find((l) => l.rank !== rankOfLevel(lv).id && l.level > lv);
    if (nxt) { const cur = cfg().levels.find((l) => l.level === rankOfLevel(lv).from)?.req ?? 0; const pct = (q - cur) / Math.max(1, nxt.req - cur); const k = `${nxt.rank}`; if (pct >= 0.75 && !(p.notified75 || []).includes(k)) { (p.notified75 ||= []).push(k); notify(pid, 'progress75', { left: nxt.req - q }); } }
  }

  /* ── partners ── */
  function makeCode(rid) { const d = load(); for (let i = 0; i < 50; i++) { const c = `ALPHA-${rid === 'legend' ? 'LEGEND' : rid.toUpperCase()}-${10000 + crypto.randomInt(90000)}`; if (!d.codes[c]) return c; } return `ALPHA-${hex(4).toUpperCase()}`; }
  function join(u, { ipHash = '' } = {}) {
    if (!key) return { error: 'no_secret' }; if (!cfg().enabled) return { error: 'program_disabled' };
    const d = load(); if (d.partners[u.uid]) return { partner: d.partners[u.uid] };
    const code = makeCode('core');
    const p = { uid: u.uid, name: clip(u.name || String(u.email || '').split('@')[0], 40), emailHash: sha(normEmail(u.email)), code, status: 'active', joinedAt: now(), level: 1, qualified: 0, clicks: 0, regs: 0, ips: ipHash ? [ipHash] : [], rankHistory: [], payoutMethod: null };
    d.partners[u.uid] = p; d.codes[code] = u.uid; audit('join', { partner: u.uid, code }); save(); notify(u.uid, 'welcome'); return { partner: p };
  }
  const seenIp = (p, ipHash) => { if (!ipHash) return; if (!p.ips.includes(ipHash)) { p.ips.unshift(ipHash); p.ips.length = Math.min(p.ips.length, 20); } };
  const codeOwner = (code) => load().codes[String(code || '').toUpperCase().trim()] || null;
  function click(code, ipHash) {
    const pid = codeOwner(code); if (!pid || !cfg().enabled) return { ok: false }; const p = load().partners[pid]; if (p.status !== 'active') return { ok: false };
    const d = load(); const k = `${pid}|${day(now())}`; const set = (d.clicks[k] ||= []); if (set.includes(ipHash) || p.ips.includes(ipHash)) return { ok: true, counted: false };
    if (set.length < 5000) set.push(ipHash); p.clicks += 1;
    for (const kk of Object.keys(d.clicks)) if (now() - Date.parse(kk.split('|')[1]) > 60 * DAY) delete d.clicks[kk];
    save(); return { ok: true, counted: true };
  }
  /** A signed-in customer arrives with a partner code (link or coupon). First touch wins; locked at the first payment. */
  function attach(u, code, { ipHash = '', via = 'link' } = {}) {
    if (!cfg().enabled) return { error: 'program_disabled' };
    const d = load(); const pid = codeOwner(code); if (!pid) return { error: 'bad_code' }; const p = d.partners[pid];
    if (p.status !== 'active') return { error: 'partner_inactive' };
    if (pid === u.uid) return { error: 'self_referral' };
    const eh = sha(normEmail(u.email)); if (eh === p.emailHash) return { error: 'self_referral' };
    if (d.referrals[u.uid]) return d.referrals[u.uid].partner === pid ? { ok: true, already: true } : { error: 'already_referred' };
    if (d.partners[u.uid] && d.partners[u.uid].code) { /* a partner may also be a customer of another partner — allowed */ }
    if (hasPaid(u.uid)) return { error: 'existing_customer' };
    if (d.emails[eh]) return { error: 'duplicate_registration' };
    const flags = []; if (ipHash && p.ips.includes(ipHash)) flags.push('same_network');
    d.referrals[u.uid] = { partner: pid, at: now(), via: via === 'coupon' ? 'coupon' : 'link', flags, ipHash, paidAt: null, void: false, lockedAt: null, ref: custRef(u.uid) };
    d.emails[eh] = pid; p.regs += 1; audit('attach', { partner: pid, customer: custRef(u.uid), via, flags }); save();
    return { ok: true, flags };
  }

  /* ── coupon (the partner code works as a coupon at checkout) ── */
  function quote(code, product, cents, uid) {
    const pid = codeOwner(code); if (!pid || !cfg().enabled) return { error: 'invalid_coupon' }; const p = load().partners[pid]; if (p.status !== 'active') return { error: 'invalid_coupon' };
    if (pid === uid) return { error: 'self_referral' };
    const ref = load().referrals[uid]; if (ref && ref.partner !== pid) return { error: 'already_referred' };
    const pct = couponPctFor(rankOfLevel(p.level).id); const disc = Math.floor((cents * Math.max(0, Math.min(90, pct))) / 100);
    return { code: p.code, discountCents: disc, finalCents: cents - disc, partner: true };
  }
  const isCode = (code) => Boolean(codeOwner(code));

  /* ── commissions ── */
  function addCommission({ partner, kind, amountCents, note = '', status = 'approved', extra = {} }) {
    const c = { id: `k${hex(6)}`, partner, kind, amountCents, status, note: clip(note, 200), createdAt: now(), month: month(now()), holdUntil: now(), payoutId: null, ...extra };
    load().commissions.unshift(c); audit('commission', { id: c.id, partner, kind, amountCents, status }); return c;
  }
  /** Pure: the commission and the financial check for one payment (no side effects). */
  function calc({ rid, tier, kind, collectedCents }) {
    const f = cfg().finance; const m = cfg().matrix[rid]?.[tier] || { newPct: 0, newFixedCents: 0, renPct: 0, renFixedCents: 0 };
    const pct = kind === 'new' ? m.newPct : m.renPct; const fixed = kind === 'new' ? m.newFixedCents : m.renFixedCents;
    const base = Math.round((collectedCents * pct) / 100) + fixed; const mult = multFor(rid); const commission = Math.round(base * mult);
    const tax = Math.round((collectedCents * f.taxPct) / 100); const fee = Math.round((collectedCents * f.feePct) / 100) + (collectedCents > 0 ? f.feeFixedCents : 0); const other = Math.round((collectedCents * f.otherPct) / 100);
    const net = collectedCents - tax - fee - other; const remain = net - commission; const marginPct = net > 0 ? Math.round((remain / net) * 10000) / 100 : -100;
    const issues = [];
    if (commission > 0 && net > 0 && marginPct < f.minMarginPct) issues.push({ code: 'min_margin', ar: `هامش التطبيق ${marginPct}% أقل من الحد الأدنى ${f.minMarginPct}%`, en: `App margin ${marginPct}% is below the minimum ${f.minMarginPct}%` });
    if (commission > Math.round((collectedCents * f.maxCommissionPct) / 100)) issues.push({ code: 'max_pct', ar: `العمولة ${usd(commission)} أكبر من ${f.maxCommissionPct}% من المبلغ المدفوع`, en: `Commission ${usd(commission)} exceeds ${f.maxCommissionPct}% of the payment` });
    const cap = f.maxCommissionCents?.[tier]; if (cap != null && commission > cap) issues.push({ code: 'max_amount', ar: `العمولة أكبر من الحد ${usd(cap)} لهالخطة`, en: `Commission exceeds the ${usd(cap)} cap for this plan` });
    if (net <= 0 && commission > 0) issues.push({ code: 'no_net', ar: 'ما في صافي إيراد بعد الضرائب والرسوم', en: 'No net revenue after taxes and fees' });
    return { pct, fixedCents: fixed, baseCents: base, multiplier: mult, commissionCents: commission, taxCents: tax, feeCents: fee, otherCents: other, netCents: net, appRemainCents: remain, marginPct, issues };
  }
  /**
   * A payment confirmed by the signed Stripe webhook. Idempotent on paymentId. Returns a short result code.
   * { paymentId, pi, uid, product, listCents, collectedCents }
   */
  function onPayment({ paymentId, pi = null, uid, product, listCents, collectedCents }) {
    const d = load(); if (!paymentId || !uid) return 'bad';
    if (d.byPayment[paymentId]) return 'duplicate';
    const ref = d.referrals[uid]; if (!ref) return 'no_referral';
    const p = d.partners[ref.partner]; const item = catalogue[product];
    d.byPayment[paymentId] = 'seen';
    if (!item || item.kind !== 'plan') { audit('payment_skip', { paymentId, reason: 'not_a_plan', product }); save(); return 'not_commissionable'; }
    const isNew = !ref.paidAt; const kind = isNew ? 'new' : 'renewal'; const t = now();
    if (isNew) { ref.paidAt = t; ref.lockedAt = t; }
    const rid = rankOfLevel(p?.level || 1).id; const tier = tierOf(listCents);
    const base = { paymentId, pi, customer: ref.ref, product, listCents, collectedCents, tier, rank: rid, level: p?.level || 1, kind };
    let status; let note = ''; let r = null;
    if (!cfg().enabled) { status = 'none'; note = 'program_disabled'; }
    else if (!p || p.status !== 'active') { status = 'none'; note = 'partner_inactive'; }
    else if (!has(rid, 'commission')) { status = 'none'; note = 'rank_without_commission'; }
    else if (tier == null) { status = 'review'; note = 'price_not_in_matrix'; }
    else {
      r = calc({ rid, tier, kind, collectedCents });
      if (r.commissionCents <= 0) { status = 'none'; note = 'matrix_not_configured'; }
      else if (ref.flags?.length) { status = 'review'; note = `fraud_check:${ref.flags.join(',')}`; }
      else if (r.issues.length) { status = 'review'; note = r.issues.map((x) => x.code).join(','); }
      else status = 'pending';
    }
    const c = { id: `k${hex(6)}`, partner: ref.partner, ...base, ...(r || {}), amountCents: r?.commissionCents || 0, status, note, createdAt: t, month: month(t), holdUntil: t + holdDaysFor(rid) * DAY, payoutId: null };
    d.commissions.unshift(c); d.byPayment[paymentId] = c.id;
    audit('payment', { paymentId, commission: c.id, partner: ref.partner, kind, collectedCents, amountCents: c.amountCents, status, note });
    if (isNew && p) { const first = !d.commissions.some((x) => x.id !== c.id && x.partner === p.uid && x.kind === 'new'); refreshRank(p.uid); if (first) notify(p.uid, 'first_paid'); }
    if (p && c.amountCents > 0 && !p.firstCommission) { p.firstCommission = t; notify(p.uid, 'first_commission', { amount: usd(c.amountCents) }); }
    else if (p && kind === 'renewal') notify(p.uid, 'renewal', { amount: usd(c.amountCents) });
    save(); return `${kind}:${status}`;
  }
  /** Refund / chargeback from Stripe (or entered by an owner). Unpaid → reversed; already paid out → claw-back line. */
  function onRefund({ paymentId = null, pi = null, kind = 'refund', by = 'stripe' }) {
    const d = load(); const c = d.commissions.find((x) => (paymentId && x.paymentId === paymentId) || (pi && x.pi && x.pi === pi)); if (!c) return 'no_commission';
    if (c.refunded) return 'duplicate'; c.refunded = { kind, at: now(), by };
    if (c.status === 'paid') addCommission({ partner: c.partner, kind: 'clawback', amountCents: -c.amountCents, note: `${kind} of ${c.paymentId}`, status: 'approved', extra: { ref: c.id } });
    else if (c.payoutId) { const po = d.payouts.find((x) => x.id === c.payoutId); if (po && po.status !== 'paid') { po.items = po.items.filter((i) => i !== c.id); po.cents -= c.amountCents; } c.payoutId = null; c.status = 'reversed'; }
    else c.status = 'reversed';
    if (c.kind === 'new') { const ref = Object.values(d.referrals).find((r) => r.ref === c.customer && r.partner === c.partner); if (ref) { ref.void = true; refreshRank(c.partner); } }
    audit('refund', { commission: c.id, paymentId: c.paymentId, kind, by }); save(); return 'reversed';
  }
  /** Holding period over → approved (unless held for review). Call every few minutes. */
  function tick() {
    if (!cfg().finance.autoApprove) return 0; let n = 0;
    for (const c of load().commissions) if (c.status === 'pending' && c.holdUntil <= now()) { c.status = 'approved'; c.approvedAt = now(); audit('auto_approve', { id: c.id }); n++; }
    if (n) save(); return n;
  }

  /* ── balances & payouts ── */
  function balances(pid) {
    const cs = load().commissions.filter((c) => c.partner === pid); const sum = (f) => cs.filter(f).reduce((s, c) => s + c.amountCents, 0);
    const m = month(now()); const pm = month(new Date(new Date(now()).setUTCDate(0)).getTime());
    const earn = (c) => !['rejected', 'reversed', 'none'].includes(c.status);
    return {
      available: sum((c) => c.status === 'approved' && !c.payoutId), pending: sum((c) => c.status === 'pending' || c.status === 'review'), inPayout: sum((c) => c.status === 'approved' && c.payoutId),
      paid: sum((c) => c.status === 'paid'), lifetime: sum(earn),
      newLifetime: sum((c) => earn(c) && c.kind === 'new'), renewalLifetime: sum((c) => earn(c) && c.kind === 'renewal'), bonusLifetime: sum((c) => earn(c) && ['rank_bonus', 'level_reward'].includes(c.kind)), promoLifetime: sum((c) => earn(c) && c.kind === 'promo'),
      monthNew: sum((c) => earn(c) && c.month === m && c.kind === 'new'), monthRenewal: sum((c) => earn(c) && c.month === m && c.kind === 'renewal'), monthBonus: sum((c) => earn(c) && c.month === m && ['rank_bonus', 'level_reward', 'promo', 'clawback'].includes(c.kind)), monthTotal: sum((c) => earn(c) && c.month === m),
      prevMonthTotal: sum((c) => earn(c) && c.month === pm),
    };
  }
  const nextPayoutDate = () => { const d = new Date(now()); const day0 = cfg().payout.day; let t = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), day0); if (t <= now()) t = Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, day0); return t; };
  function requestPayout(u, b = {}) {
    const d = load(); const p = d.partners[u.uid]; if (!p) return { error: 'not_partner' }; if (p.status !== 'active') return { error: 'partner_inactive' };
    if (d.payouts.some((x) => x.partner === u.uid && ['requested', 'approved'].includes(x.status))) return { error: 'payout_open' };
    const method = ['paypal', 'bank', 'usdt', 'other'].includes(b.method) ? b.method : null; const account = clip(b.account, 200);
    if (!method || account.length < 4) return { error: 'payout_details' };
    const items = d.commissions.filter((c) => c.partner === u.uid && c.status === 'approved' && !c.payoutId); const cents = items.reduce((s, c) => s + c.amountCents, 0);
    const min = minPayoutFor(rankOfLevel(p.level).id); if (cents < min) return { error: 'below_minimum', min };
    const po = { id: `p${hex(6)}`, partner: u.uid, cents, items: items.map((c) => c.id), method, account, status: 'requested', at: now() };
    for (const c of items) c.payoutId = po.id; d.payouts.unshift(po); p.payoutMethod = { method, account }; audit('payout_request', { id: po.id, partner: u.uid, cents }); save();
    return { payout: payoutView(po, true) };
  }
  const payoutView = (po, own = false) => ({ id: po.id, cents: po.cents, method: po.method, account: own ? po.account : undefined, status: po.status, at: po.at, approvedAt: po.approvedAt || null, paidAt: po.paidAt || null, reference: po.reference || null, reason: po.reason || null, items: po.items.length });

  /* ── partner dashboard ── */
  function me(u) {
    const d = load(); const p = d.partners[u.uid]; const c = cfg();
    const rankList = RANKS.map((r) => ({ id: r.id, name: r.name, color: r.color, metal: r.metal, from: r.from, to: r.to, req: c.levels.find((l) => l.level === r.from)?.req ?? 0, benefits: c.ranks[r.id].benefits }));
    if (!p) return { joined: false, enabled: c.enabled, ranks: rankList, benefitNames: BENEFITS };
    const q = qualified(u.uid); const lv = levelFor(q); if (lv !== p.level) refreshRank(u.uid);
    const rk = rankOfLevel(p.level); const cur = c.levels.find((l) => l.level === p.level); const nxt = c.levels.find((l) => l.level === p.level + 1) || null;
    const nextRankLv = c.levels.find((l) => l.rank !== rk.id && l.level > p.level) || null;
    const refs = Object.entries(d.referrals).filter(([, r]) => r.partner === u.uid);
    const paying = refs.filter(([, r]) => r.paidAt && !r.void).length;
    const cs = d.commissions.filter((x) => x.partner === u.uid);
    const history = cs.filter((x) => x.paymentId).slice(0, 100).map((x) => ({ customer: x.customer, product: x.product, listCents: x.listCents, at: x.createdAt, payment: x.refunded ? x.refunded.kind : 'paid', kind: x.kind, amountCents: x.amountCents, status: x.status }));
    const out = {
      joined: true, enabled: c.enabled, status: p.status, code: p.code, name: p.name, joinedAt: p.joinedAt,
      level: p.level, rank: rk.id, qualified: q, levelReq: cur?.req ?? 0, next: nxt ? { level: nxt.level, req: nxt.req, left: Math.max(0, nxt.req - q), rank: nxt.rank } : null,
      nextRank: nextRankLv ? { id: nextRankLv.rank, level: nextRankLv.level, req: nextRankLv.req, left: Math.max(0, nextRankLv.req - q) } : null,
      progressPct: nxt ? Math.max(0, Math.min(100, Math.round(((q - (cur?.req ?? 0)) / Math.max(1, nxt.req - (cur?.req ?? 0))) * 100))) : 100,
      benefits: { unlocked: c.ranks[rk.id].benefits, multiplier: multFor(rk.id), holdDays: holdDaysFor(rk.id), minPayoutCents: minPayoutFor(rk.id), couponDiscountPct: couponPctFor(rk.id) },
      ranks: rankList, levels: c.levels.map((l) => ({ level: l.level, rank: l.rank, req: l.req, rewardCents: l.rewardCents, unlocked: q >= l.req })), benefitNames: BENEFITS,
      referral: { clicks: p.clicks, registrations: p.regs, paying, conversionPct: p.clicks ? Math.round((paying / p.clicks) * 1000) / 10 : 0, regConversionPct: p.regs ? Math.round((paying / p.regs) * 1000) / 10 : 0 },
      earnings: balances(u.uid), nextPayoutAt: nextPayoutDate(), payouts: d.payouts.filter((x) => x.partner === u.uid).slice(0, 50).map((x) => payoutView(x, true)), payoutMethod: p.payoutMethod,
      history, rankHistory: (p.rankHistory || []).slice(-20),
      growth: (() => { let run = 0; return cs.filter((x) => !['rejected', 'reversed', 'none'].includes(x.status) && x.amountCents).sort((a, b) => a.createdAt - b.createdAt).map((x) => { run += x.amountCents; return { t: x.createdAt, cents: run, kind: x.kind }; }); })(),
      legends: Object.values(d.partners).filter((x) => x.status === 'active' && has(rankOfLevel(x.level).id, 'recognition') && rankOfLevel(x.level).id === 'legend').map((x) => x.name).slice(0, 20),
    };
    if (has(rk.id, 'stats_plus')) {
      const byM = {}; const byP = {}; for (const x of cs) { if (['rejected', 'reversed', 'none'].includes(x.status)) continue; const mm = (byM[x.month] ||= { new: 0, renewal: 0, bonus: 0 }); if (x.kind === 'new') mm.new += x.amountCents; else if (x.kind === 'renewal') mm.renewal += x.amountCents; else mm.bonus += x.amountCents; if (x.product) byP[x.product] = (byP[x.product] || 0) + 1; }
      out.statsPlus = { byMonth: byM, byProduct: byP };
    }
    if (has(rk.id, 'analytics')) {
      const clicksByDay = {}; for (const [k, v] of Object.entries(d.clicks)) { const [pid, dd] = k.split('|'); if (pid === u.uid) clicksByDay[dd] = v.length; }
      const bySrc = { link: { regs: 0, paying: 0 }, coupon: { regs: 0, paying: 0 } }; for (const [, r] of refs) { bySrc[r.via].regs++; if (r.paidAt && !r.void) bySrc[r.via].paying++; }
      out.analytics = { clicksByDay, bySource: bySrc };
    }
    return out;
  }

  /* ── owners ── */
  function adminView() {
    const d = load(); const all = d.commissions; const sum = (f) => all.filter(f).reduce((s, c) => s + c.amountCents, 0);
    return {
      config: d.config, tiers: PRICE_TIERS, ranks: RANKS, benefitNames: BENEFITS, catalogue: Object.values(catalogue).filter((x) => x.kind === 'plan').map((x) => ({ id: x.id, cents: x.cents, inMatrix: PRICE_TIERS.includes(x.cents) })),
      totals: { partners: Object.keys(d.partners).length, referrals: Object.keys(d.referrals).length, paying: Object.values(d.referrals).filter((r) => r.paidAt && !r.void).length, pending: sum((c) => c.status === 'pending'), review: all.filter((c) => c.status === 'review').length, approved: sum((c) => c.status === 'approved'), paid: sum((c) => c.status === 'paid'), payoutsOpen: d.payouts.filter((p) => ['requested', 'approved'].includes(p.status)).length },
      partners: Object.values(d.partners).map((p) => ({ uid: p.uid, name: p.name, code: p.code, status: p.status, level: p.level, rank: rankOfLevel(p.level).id, qualified: qualified(p.uid), clicks: p.clicks, regs: p.regs, balance: balances(p.uid).available, lifetime: balances(p.uid).lifetime, joinedAt: p.joinedAt })).sort((a, b) => b.qualified - a.qualified),
      commissions: all.slice(0, 500), payouts: d.payouts.slice(0, 200),
      referrals: Object.values(d.referrals).slice(-300).map((r) => ({ ...r, ipHash: undefined })),
      audit: { tail: d.audit.slice(-60).reverse(), check: verifyAudit() },
    };
  }
  /** Validate and store an owner's configuration change. Never touches money already recorded. */
  function setConfig(patch = {}) {
    const c = structuredClone(cfg()); const errs = [];
    if ('enabled' in patch) c.enabled = Boolean(patch.enabled);
    if (patch.levels) {
      if (!Array.isArray(patch.levels) || patch.levels.length !== 100) errs.push('levels_100');
      else { const lv = patch.levels.map((l, i) => ({ level: i + 1, rank: rankOfLevel(i + 1).id, req: int(l.req, 0, 1e6), rewardCents: int(l.rewardCents, 0, 1e8) }));
        for (let i = 1; i < 100; i++) if (lv[i].req <= lv[i - 1].req) errs.push(`level_${i + 1}_not_increasing`);
        c.levels = lv; }
    }
    if (patch.ranks) for (const rid of RANK_IDS) { const r = patch.ranks[rid]; if (!r) continue; const o = c.ranks[rid];
      if ('multiplier' in r) o.multiplier = num(r.multiplier, 0, 10, 1); if ('bonusCents' in r) o.bonusCents = int(r.bonusCents, 0, 1e8);
      for (const k of ['holdDays', 'minPayoutCents', 'couponDiscountPct']) if (k in r) o[k] = r[k] === null || r[k] === '' ? null : k === 'holdDays' ? int(r[k], 0, 365) : k === 'couponDiscountPct' ? num(r[k], 0, 90) : int(r[k], 0, 1e8);
      if (Array.isArray(r.benefits)) o.benefits = r.benefits.filter((b) => b in BENEFITS); }
    if (patch.matrix) for (const rid of RANK_IDS) for (const t of PRICE_TIERS) { const m = patch.matrix?.[rid]?.[t]; if (!m) continue; const o = c.matrix[rid][t];
      o.newPct = num(m.newPct ?? o.newPct, 0, 100); o.renPct = num(m.renPct ?? o.renPct, 0, 100); o.newFixedCents = int(m.newFixedCents ?? o.newFixedCents, 0, t); o.renFixedCents = int(m.renFixedCents ?? o.renFixedCents, 0, t); }
    for (const rid of RANK_IDS) for (const t of PRICE_TIERS) { const o = c.matrix[rid][t]; const nw = (t * o.newPct) / 100 + o.newFixedCents; const rn = (t * o.renPct) / 100 + o.renFixedCents; if (rn > 0 && rn >= nw) errs.push(`renewal_not_lower:${rid}:${t}`); }
    if (patch.finance) { const f = c.finance, p = patch.finance;
      for (const [k, lo, hi] of [['taxPct', 0, 60], ['feePct', 0, 20], ['otherPct', 0, 60], ['minMarginPct', 0, 95], ['maxCommissionPct', 0, 90]]) if (k in p) f[k] = num(p[k], lo, hi, f[k]);
      if ('feeFixedCents' in p) f.feeFixedCents = int(p.feeFixedCents, 0, 10000); if ('holdDays' in p) f.holdDays = int(p.holdDays, 0, 365, 30); if ('autoApprove' in p) f.autoApprove = Boolean(p.autoApprove);
      if (p.maxCommissionCents) for (const t of PRICE_TIERS) if (t in p.maxCommissionCents) f.maxCommissionCents[t] = p.maxCommissionCents[t] === null || p.maxCommissionCents[t] === '' ? null : int(p.maxCommissionCents[t], 0, t); }
    if (patch.payout) { if ('minPayoutCents' in patch.payout) c.payout.minPayoutCents = int(patch.payout.minPayoutCents, 0, 1e8, 5000); if ('day' in patch.payout) c.payout.day = int(patch.payout.day, 1, 28, 5); }
    if (patch.coupon && 'discountPct' in patch.coupon) c.coupon.discountPct = num(patch.coupon.discountPct, 0, 90);
    if (patch.notify) for (const k of Object.keys(T)) if (k in patch.notify) c.notify[k] = Boolean(patch.notify[k]);
    if (patch.gate) { c.gate = { ...(c.gate || {}) }; if ('telegram' in patch.gate) c.gate.telegram = Boolean(patch.gate.telegram); if ('inviteUrl' in patch.gate) { const u = clip(patch.gate.inviteUrl, 200); if (u && !/^https:\/\/(t\.me|telegram\.me)\/[A-Za-z0-9_+\-/]{3,120}$/.test(u)) errs.push('bad_invite_url'); c.gate.inviteUrl = u; } }
    // soft warnings: higher ranks should not pay less than lower ranks on the same plan
    const warnings = []; for (const t of PRICE_TIERS) for (let i = 1; i < RANK_IDS.length; i++) { const a = c.matrix[RANK_IDS[i - 1]][t], b = c.matrix[RANK_IDS[i]][t]; if ((t * b.newPct) / 100 + b.newFixedCents < (t * a.newPct) / 100 + a.newFixedCents) warnings.push(`lower_than_previous_rank:${RANK_IDS[i]}:${t}`); }
    if (errs.length) return { error: 'invalid_config', details: errs.slice(0, 20) };
    c.updatedAt = now(); load().config = c; audit('config', { keys: Object.keys(patch) }); save(); return { ok: true, warnings: warnings.slice(0, 20) };
  }
  function adminAct(b = {}) {
    const d = load(); const by = clip(b.by, 80);
    const com = () => d.commissions.find((x) => x.id === b.id);
    switch (b.action) {
      case 'approve': { const c = com(); if (!c || !['pending', 'review'].includes(c.status)) return { error: 'bad_state' }; c.status = 'approved'; c.approvedAt = now(); c.approvedBy = by; audit('approve', { id: c.id, by }); break; }
      case 'reject': { const c = com(); if (!c || !['pending', 'review', 'approved'].includes(c.status) || c.payoutId) return { error: 'bad_state' }; const reason = clip(b.reason, 300); if (reason.length < 3) return { error: 'reason_required' }; c.status = 'rejected'; c.reason = reason; audit('reject', { id: c.id, reason, by }); break; }
      case 'refund': return { result: onRefund({ paymentId: b.paymentId, kind: b.kind === 'chargeback' ? 'chargeback' : 'refund', by: 'owner' }) };
      case 'promo': { const p = d.partners[b.uid]; const cents = int(b.cents, -1e8, 1e8); if (!p || !cents) return { error: 'bad_input' }; addCommission({ partner: p.uid, kind: cents > 0 ? 'promo' : 'adjustment', amountCents: cents, note: clip(b.note, 200) || 'owner', status: 'approved' }); break; }
      case 'suspend': case 'unsuspend': { const p = d.partners[b.uid]; if (!p) return { error: 'not_found' }; p.status = b.action === 'suspend' ? 'suspended' : 'active'; p.statusReason = clip(b.reason, 200); audit(b.action, { partner: p.uid, reason: p.statusReason, by }); break; }
      case 'recalc': { const p = d.partners[b.uid]; if (!p) return { error: 'not_found' }; refreshRank(p.uid); break; }
      case 'void_referral': { const r = Object.values(d.referrals).find((x) => x.ref === b.customer); if (!r) return { error: 'not_found' }; r.void = true; r.voidReason = clip(b.reason, 200); audit('void_referral', { customer: b.customer, reason: r.voidReason, by }); refreshRank(r.partner); break; }
      case 'payout_approve': { const po = d.payouts.find((x) => x.id === b.id); if (!po || po.status !== 'requested') return { error: 'bad_state' }; po.status = 'approved'; po.approvedAt = now(); audit('payout_approve', { id: po.id, by }); notify(po.partner, 'payout', { amount: usd(po.cents) }); break; }
      case 'payout_paid': { const po = d.payouts.find((x) => x.id === b.id); if (!po || po.status !== 'approved') return { error: 'bad_state' }; const ref = clip(b.reference, 120); if (ref.length < 3) return { error: 'reference_required' };
        po.status = 'paid'; po.paidAt = now(); po.reference = ref; for (const c of d.commissions) if (c.payoutId === po.id) { c.status = 'paid'; c.paidAt = po.paidAt; } audit('payout_paid', { id: po.id, cents: po.cents, reference: ref, by }); notify(po.partner, 'payout_paid', { amount: usd(po.cents), ref }); break; }
      case 'payout_reject': { const po = d.payouts.find((x) => x.id === b.id); if (!po || !['requested', 'approved'].includes(po.status)) return { error: 'bad_state' }; po.status = 'rejected'; po.reason = clip(b.reason, 300) || '—'; for (const c of d.commissions) if (c.payoutId === po.id) c.payoutId = null; audit('payout_reject', { id: po.id, reason: po.reason, by }); break; }
      default: return { error: 'bad_action' };
    }
    save(); return { ok: true };
  }
  function exportCsv(type) {
    const d = load(); const esc = (v) => { const s = String(v ?? ''); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; }; const rows = [];
    if (type === 'payouts') { rows.push(['id', 'partner', 'cents', 'method', 'status', 'requested', 'approved', 'paid', 'reference']); for (const p of d.payouts) rows.push([p.id, p.partner, p.cents, p.method, p.status, p.at && new Date(p.at).toISOString(), p.approvedAt && new Date(p.approvedAt).toISOString(), p.paidAt && new Date(p.paidAt).toISOString(), p.reference]); }
    else if (type === 'monthly') { const m = {}; for (const c of d.commissions) { if (['rejected', 'reversed', 'none'].includes(c.status)) continue; const k = `${c.month}|${c.partner}`; const o = (m[k] ||= { new: 0, renewal: 0, bonus: 0, promo: 0, adj: 0 }); if (c.kind === 'new') o.new += c.amountCents; else if (c.kind === 'renewal') o.renewal += c.amountCents; else if (c.kind === 'promo') o.promo += c.amountCents; else if (c.kind === 'clawback' || c.kind === 'adjustment') o.adj += c.amountCents; else o.bonus += c.amountCents; }
      rows.push(['month', 'partner', 'new_cents', 'renewal_cents', 'rank_bonus_cents', 'promo_cents', 'adjustments_cents', 'total_cents']); for (const [k, o] of Object.entries(m).sort()) { const [mm, p] = k.split('|'); rows.push([mm, p, o.new, o.renewal, o.bonus, o.promo, o.adj, o.new + o.renewal + o.bonus + o.promo + o.adj]); } }
    else { rows.push(['id', 'created', 'partner', 'customer', 'kind', 'product', 'list_cents', 'collected_cents', 'tax_cents', 'fee_cents', 'net_cents', 'commission_cents', 'app_remaining_cents', 'margin_pct', 'rank', 'multiplier', 'status', 'note', 'payment_id', 'payout_id']);
      for (const c of d.commissions) rows.push([c.id, new Date(c.createdAt).toISOString(), c.partner, c.customer, c.kind, c.product, c.listCents, c.collectedCents, c.taxCents, c.feeCents, c.netCents, c.amountCents, c.appRemainCents, c.marginPct, c.rank, c.multiplier, c.status, c.note || c.reason, c.paymentId, c.payoutId]); }
    return rows.map((r) => r.map(esc).join(',')).join('\n');
  }
  function forgetUser(uid) {
    const d = load(); const p = d.partners[uid];
    if (p) { delete d.codes[p.code]; p.name = 'deleted'; p.status = 'deleted'; p.ips = []; p.payoutMethod = null; for (const po of d.payouts) if (po.partner === uid) po.account = ''; }
    if (d.referrals[uid]) d.referrals[uid].ipHash = '';
    audit('forget', { uid: sha(uid).slice(0, 12) }); save();
  }
  const noteTelegram = (info) => { load().config.telegram = info; audit('telegram', { messageId: info.messageId, pinned: info.pinned, menu: info.menu }); save(); };
  return { adminConfig: () => cfg(), noteTelegram, join, click, attach, quote, isCode, onPayment, onRefund, tick, requestPayout, me, adminView, setConfig, adminAct, exportCsv, forgetUser, calc, verifyAudit, seenIp: (uid, ipHash) => { const p = load().partners[uid]; if (p && ipHash) { const had = p.ips.includes(ipHash); seenIp(p, ipHash); if (!had) save(); } }, canSave: () => Boolean(key), _db: () => load() };
}
