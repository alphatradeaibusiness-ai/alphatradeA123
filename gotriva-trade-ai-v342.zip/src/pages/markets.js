// Markets: every instrument the site's data providers really supply, grouped by asset class, with live price, 24 h change,
import { arName } from '../config/arNames.js';
// the day's range (where the price sits between the low and the high), volume, whether the market is open now, and a
// market-breadth summary (how many are up / down, the biggest movers). Refreshes every 15 seconds. Click → open the chart.
import { h, esc, fmtNum, fmtPct, fmtCompact } from '../utils/dom.js';
import { icons, assetIcon } from '../components/icons.js';
import { t, getLocale, getLang } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { INSTRUMENTS } from '../config/instruments.js';
import { getTickers, isUnavailable } from '../services/market/index.js';
import { sessionState } from '../services/multiStrategy.js';
import { store } from '../state/store.js';
import { navigate } from '../router.js';
import { whileMounted } from './tools/common.js';
import { pageHead } from './community.js';
import '../styles/markets.css';

const CLASSES = [
  ['all', { ar: 'الكل', en: 'All', he: 'הכול', es: 'Todos', zh: '全部' }],
  ['crypto', { ar: 'كريبتو', en: 'Crypto', he: 'קריפטו', es: 'Cripto', zh: '加密货币' }],
  ['metal', { ar: 'معادن', en: 'Metals', he: 'מתכות', es: 'Metales', zh: '金属' }],
  ['index', { ar: 'مؤشرات', en: 'Indices', he: 'מדדים', es: 'Índices', zh: '指数' }],
  ['energy', { ar: 'طاقة', en: 'Energy', he: 'אנרגיה', es: 'Energía', zh: '能源' }],
];
const SORTS = [['change', { ar: 'الأكثر حركة', en: 'Biggest movers', he: 'התנועה הגדולה', es: 'Mayor movimiento', zh: '涨跌幅' }], ['name', { ar: 'الاسم', en: 'Name', he: 'שם', es: 'Nombre', zh: '名称' }], ['volume', { ar: 'الحجم', en: 'Volume', he: 'נפח', es: 'Volumen', zh: '成交量' }]];

export function renderMarkets() {
  const st = { cls: 'all', q: '', sort: 'change' };
  let data = {}; const prev = {};
  const el = h(`<section class="subpage tool mk page-enter">${pageHead('bars', t('pages.marketsTitle'), t('pages.marketsSub'))}
    <div class="tool-body">
      <div class="mk-summary" data-summary></div>
      <div class="card mk-controls">
        <div class="seg mk-tabs" data-cls>${CLASSES.map(([k, n]) => `<button type="button" data-v="${k}" class="${k === st.cls ? 'is-on' : ''}">${esc(tx(n))}<em data-count="${k}"></em></button>`).join('')}</div>
        <label class="mk-search">${icons.search}<input type="search" data-q placeholder="${esc(tx({ ar: 'ابحث عن سوق…', en: 'Search markets…', he: 'חפש שוק…', es: 'Buscar mercado…', zh: '搜索市场…' }))}" aria-label="search"></label>
        <select class="select mk-sort" data-sort aria-label="sort">${SORTS.map(([k, n]) => `<option value="${k}">${esc(tx(n))}</option>`).join('')}</select>
      </div>
      <div class="card mk-table-card"><div class="mk-head" aria-hidden="true"><span>${esc(t('pages.colSymbol'))}</span><span>${esc(t('pages.colPrice'))}</span><span>${esc(t('pages.colChange'))}</span><span>${esc(tx({ ar: 'مدى اليوم', en: 'Day range', he: 'טווח יומי', es: 'Rango del día', zh: '日内区间' }))}</span><span>${esc(t('pages.colVolume') || 'Volume')}</span><span>${esc(tx({ ar: 'السوق', en: 'Market', he: 'שוק', es: 'Mercado', zh: '市场' }))}</span></div>
        <div class="mk-list" data-list><div class="perf-loading"><span class="spinner"></span><span>${esc(t('common.loading'))}</span></div></div></div>
      <p class="muted tool-note" data-note></p>
    </div></section>`);
  const $ = (s) => el.querySelector(s);
  const list = () => INSTRUMENTS.filter((i) => !isUnavailable(i.symbol));
  function row(i) {
    const r = data[i.symbol]; const ses = sessionState(i.type);
    if (!r || r.mode === 'error' || !Number.isFinite(r.price)) return `<div class="mk-row is-err" data-open="${i.symbol}"><span class="mk-sym">${assetIcon(i.icon, 30)}<span><b>${esc(i.symbol)}</b><small>${esc(getLang() === 'ar' && arName(i.symbol) ? arName(i.symbol) : `${i.base}/${i.quote}`)}</small></span></span><span class="muted mk-span">—</span></div>`;
    const up = r.changePct >= 0; const pos = r.high > r.low ? Math.max(0, Math.min(100, ((r.price - r.low) / (r.high - r.low)) * 100)) : 50;
    const flash = prev[i.symbol] != null && prev[i.symbol] !== r.price ? (r.price > prev[i.symbol] ? 'is-tick-up' : 'is-tick-down') : '';
    return `<div class="mk-row" data-open="${i.symbol}" role="button" tabindex="0">
      <span class="mk-sym">${assetIcon(i.icon, 30)}<span><b>${esc(i.symbol)}</b><small>${esc(getLang() === 'ar' && arName(i.symbol) ? arName(i.symbol) : `${i.base}/${i.quote}`)}${r.mode === 'demo' ? ` · <span class="badge badge-demo">${esc(t('status.demo'))}</span>` : ''}</small></span></span>
      <span class="mk-price mono ${flash}">${fmtNum(r.price, i.precision)}</span>
      <span class="mk-chg"><b class="mono ${up ? 'up' : 'down'}">${fmtPct(r.changePct)}</b></span>
      <span class="mk-range" dir="ltr" title="${fmtNum(r.low, i.precision)} – ${fmtNum(r.high, i.precision)}"><i style="left:${pos.toFixed(1)}%"></i><small class="mono">${fmtNum(r.low, i.precision)}</small><small class="mono">${fmtNum(r.high, i.precision)}</small></span>
      <span class="mk-vol mono">${r.volume ? fmtCompact(r.volume) : '—'}</span>
      <span class="mk-ses ${ses.open ? 'is-open' : 'is-closed'}"><i></i>${esc(ses.open ? tx({ ar: 'مفتوح', en: 'Open', he: 'פתוח', es: 'Abierto', zh: '开市' }) : tx({ ar: 'مسكّر', en: 'Closed', he: 'סגור', es: 'Cerrado', zh: '休市' }))}</span>
    </div>`;
  }
  function draw() {
    const all = list();
    for (const [k] of CLASSES) { const c = el.querySelector(`[data-count="${k}"]`); if (c) c.textContent = String(k === 'all' ? all.length : all.filter((i) => i.type === k).length); }
    const q = st.q.trim().toUpperCase();
    let rows = all.filter((i) => (st.cls === 'all' || i.type === st.cls) && (!q || i.symbol.includes(q) || i.base.includes(q)));
    const ch = (i) => data[i.symbol]?.changePct ?? -Infinity;
    rows = rows.sort(st.sort === 'name' ? (a, b) => a.symbol.localeCompare(b.symbol) : st.sort === 'volume' ? (a, b) => (data[b.symbol]?.quoteVolume || data[b.symbol]?.volume || 0) - (data[a.symbol]?.quoteVolume || data[a.symbol]?.volume || 0) : (a, b) => Math.abs(ch(b)) - Math.abs(ch(a)));
    $('[data-list]').innerHTML = rows.length ? rows.map(row).join('') : `<div class="sig-empty">${icons.search}<span>${esc(tx({ ar: 'ما في نتائج.', en: 'No results.', he: 'אין תוצאות.', es: 'Sin resultados.', zh: '没有结果。' }))}</span></div>`;
    // breadth & movers (live quotes only)
    const ok = all.map((i) => ({ i, r: data[i.symbol] })).filter((x) => x.r && Number.isFinite(x.r.changePct));
    const ups = ok.filter((x) => x.r.changePct >= 0).length; const downs = ok.length - ups;
    const best = [...ok].sort((a, b) => b.r.changePct - a.r.changePct)[0]; const worst = [...ok].sort((a, b) => a.r.changePct - b.r.changePct)[0];
    const wild = [...ok].filter((x) => x.r.high > x.r.low).sort((a, b) => (b.r.high - b.r.low) / b.r.price - (a.r.high - a.r.low) / a.r.price)[0];
    const tile = (label, x, val) => `<div class="card mk-tile"><span>${esc(label)}</span>${x ? `<b>${assetIcon(x.i.icon, 20)}<span class="mono">${esc(x.i.symbol)}</span></b><em class="mono ${val >= 0 ? 'up' : 'down'}">${fmtPct(val)}</em>` : '<b>—</b>'}</div>`;
    $('[data-summary]').innerHTML = ok.length ? `<div class="card mk-tile mk-breadth"><span>${esc(tx({ ar: 'اتساع السوق', en: 'Market breadth', he: 'רוחב השוק', es: 'Amplitud del mercado', zh: '市场宽度' }))}</span><b class="mono"><span class="up">${ups}▲</span> <span class="down">${downs}▼</span></b><div class="mk-bar"><i style="width:${((100 * ups) / ok.length).toFixed(1)}%"></i></div></div>
      ${tile(tx({ ar: 'الأكثر صعودًا', en: 'Top gainer', he: 'העולה הגדול', es: 'Mayor subida', zh: '涨幅最大' }), best, best?.r.changePct)}
      ${tile(tx({ ar: 'الأكثر هبوطًا', en: 'Top loser', he: 'היורד הגדול', es: 'Mayor caída', zh: '跌幅最大' }), worst, worst?.r.changePct)}
      ${wild ? `<div class="card mk-tile"><span>${esc(tx({ ar: 'الأكثر تذبذبًا اليوم', en: 'Most volatile today', he: 'התנודתי ביותר היום', es: 'Más volátil hoy', zh: '今日波动最大' }))}</span><b>${assetIcon(wild.i.icon, 20)}<span class="mono">${esc(wild.i.symbol)}</span></b><em class="mono">${fmtNum(((wild.r.high - wild.r.low) / wild.r.price) * 100, 2)}%</em></div>` : ''}` : '';
    $('[data-note]').textContent = `${tx({ ar: 'آخر تحديث', en: 'Updated', he: 'עודכן', es: 'Actualizado', zh: '更新于' })} ${new Date().toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit', second: '2-digit' })} · ${tx({ ar: 'بيتحدّث كل 15 ثانية · الأسعار من بينانس و تويلف داتا', en: 'refreshes every 15 s · prices from Binance and Twelve Data', he: 'מתעדכן כל 15 שניות', es: 'se actualiza cada 15 s', zh: '每 15 秒刷新' })}`;
  }
  let tickN = 0;
  async function refresh() {
    // v243: rows on screen every second, the whole list every 10 s (the rows keep their last price in between)
    tickN += 1; const all = list().map((i) => i.symbol);
    const vh = window.innerHeight || 800;
    const vis = [...el.querySelectorAll('[data-open]')].filter((r) => { const b = r.getBoundingClientRect(); return b.bottom > 0 && b.top < vh; }).map((r) => r.dataset.open);
    const want = tickN % 10 === 1 || !vis.length ? all : vis;
    try { const tk = await getTickers(want); for (const k of Object.keys(data)) prev[k] = data[k]?.price; data = { ...data, ...tk }; draw(); }
    catch { if (!Object.keys(data).length) $('[data-list]').innerHTML = `<div class="sig-empty">${icons.alert}<span>${esc(tx({ ar: 'ما قدرنا نجيب الأسعار.', en: 'Could not load prices.', he: 'לא ניתן לטעון מחירים.', es: 'No se pudieron cargar los precios.', zh: '无法加载价格。' }))}</span></div>`; }
  }
  $('[data-cls]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; st.cls = b.dataset.v; $('[data-cls]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b)); draw(); });
  $('[data-q]').addEventListener('input', (e) => { st.q = e.target.value; draw(); });
  $('[data-sort]').addEventListener('change', (e) => { st.sort = e.target.value; draw(); });
  const open = (sym) => { store.set('symbol', sym); navigate('#/app'); };
  $('[data-list]').addEventListener('click', (e) => { const r = e.target.closest('[data-open]'); if (r) open(r.dataset.open); });
  $('[data-list]').addEventListener('keydown', (e) => { if (e.key === 'Enter') { const r = e.target.closest('[data-open]'); if (r) open(r.dataset.open); } });
  refresh(); whileMounted(el, () => { if (!document.hidden) refresh(); }, 1000);   // v243: live every second (only while the tab is visible)
  return el;
}
