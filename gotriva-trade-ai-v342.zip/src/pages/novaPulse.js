// NOVA PULSE (v317) — the page of the independent 1-minute engine (src/services/novaPulse.js, run by the 24/7 server worker).
// Read-only: it shows the feed (/api/nova/feed), each market's live state, the open signals and the engine's own closed record.
import { h, esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { icons, assetIcon } from '../components/icons.js';
import { getInstrument } from '../config/instruments.js';
import { apiRequest } from '../services/ai/gateway.js';
import { fmtTz, tzLabel } from '../services/aiSignalUtil.js';
import { strategyOf } from '../config/aiSignalRules.js';
import { NOVA, NOVA_MARKETS, novaSummary } from '../services/novaPulse.js';
import '../styles/nova.css';

const POLL_MS = 20_000;

export function renderNova() {
  const AR = getLang() === 'ar'; const L = (ar, en) => (AR ? ar : en);
  const pct = (v) => (v == null ? '—' : `${Math.round(v * 100)}%`);
  const stratName = (id) => { const s = strategyOf(id); return s ? (AR ? s.name.ar : s.name.en) : id; };
  const MSTATE = { live: [L('حيّ', 'Live'), 'badge-live'], stale: [L('البيانات متأخرة أو السوق مسكّر', 'Delayed data / market closed'), 'badge-demo'], unavailable: [L('ما في بيانات حقيقية', 'No real data'), 'badge-error'], insufficient: [L('بيانات غير كافية', 'Not enough data'), 'badge-demo'], error: [L('خطأ بالمصدر', 'Source error'), 'badge-error'], pending: [L('بانتظار أول فحص', 'Waiting for the first scan'), 'badge-muted'] };
  const el = h(`<section class="subpage nova page-enter">
    <div class="subpage-head nova-hero"><h1><span class="nova-word">NOVA <b>PULSE</b></span><svg class="nova-wave" viewBox="0 0 44 24" aria-hidden="true"><path d="M1 12h9l3-8 5 16 4-12 3 4h18"/></svg></h1>
      <p class="muted">${esc(L('محرك مستقل على فريم الدقيقة. بيبعت توصية بس لما استراتيجية نسبة نجاحها المقاسة على هالسوق 67% أو أكتر.', 'An independent 1-minute engine. It sends a signal only when a strategy with a measured win rate of 67% or more on that market fires.'))}</p></div>
    <div class="nova-kpis" data-kpis></div>
    <div class="tool-card"><h2 class="card-title">${icons.bolt}<span>${esc(L('توصيات مفتوحة', 'Open signals'))}</span></h2><div class="nova-list" data-open></div></div>
    <div class="tool-card"><h2 class="card-title">${icons.radar}<span>${esc(L('الأسواق', 'Markets'))}</span></h2><div class="nova-mk" data-markets></div></div>
    <div class="tool-card"><h2 class="card-title">${icons.journal || ''}<span>${esc(L('آخر التوصيات المسكّرة', 'Recently closed'))}</span></h2><div class="nova-list" data-closed></div></div>
    <div class="tool-card nova-how"><h2 class="card-title">${icons.info || ''}<span>${esc(L('كيف بتنحسب النسبة', 'How the percentage is measured'))}</span></h2>
      <p>${esc(L(`كل دقيقة، المحرك بيعيد تشغيل كل استراتيجية على شموع الدقيقة الحقيقية لآخر أيام لنفس السوق، مع التكلفة، وبدون ما يشوف المستقبل. الاستراتيجية بتنحسب مؤهلة بس إذا ربحت ${Math.round(NOVA.minWinRate * 100)}% أو أكتر من ${NOVA.minTrades} صفقة على الأقل ومتوسط نتيجتها موجب. الهدف 1R والوقف 1R.`, `Every minute the engine replays each strategy on the real 1-minute candles of the last days for that market, with costs and no look-ahead. A strategy qualifies only if it won ${Math.round(NOVA.minWinRate * 100)}% or more of at least ${NOVA.minTrades} trades with a positive average. Target 1R, stop 1R.`))}</p>
      <p class="muted">${esc(L('النسبة وصف لأداء الماضي القريب، مش ضمان للصفقة الجاية. الأسواق اللي بياناتها متأخرة أو مسكّرة ما بيطلع عليها توصيات. هاي مش نصيحة مالية.', 'The percentage describes the recent past; it is not a guarantee for the next trade. Markets with delayed data or closed markets get no signals. This is not financial advice.'))}</p>
      <p class="muted" data-foot></p></div>
  </section>`);

  const card = (s) => {
    const long = s.direction === 'long'; const res = s.status === 'tp' ? ['TP', 'badge-live'] : s.status === 'sl' ? ['SL', 'badge-error'] : s.status === 'expired' ? [L('انتهى الوقت', 'Timed out'), 'badge-muted'] : [L('مفتوحة', 'Open'), 'badge-demo'];
    return `<article class="nova-card ${long ? 'is-long' : 'is-short'}">
      <header><b>${esc(s.market)}</b><span class="badge ${long ? 'badge-live' : 'badge-error'}">${esc(long ? L('شراء', 'BUY') : L('بيع', 'SELL'))}</span><span class="badge ${res[1]}">${esc(res[0])}${s.result != null ? ` ${s.result > 0 ? '+' : ''}${s.result}R` : ''}</span><time class="muted">${esc(fmtTz(Math.floor(s.createdAt / 1000), getLang()))}</time></header>
      <dl><div><dt>${esc(L('دخول', 'Entry'))}</dt><dd class="mono">${s.entry}</dd></div><div><dt>${esc(L('وقف', 'Stop'))}</dt><dd class="mono">${s.stop}</dd></div><div><dt>${esc(L('هدف', 'Target'))}</dt><dd class="mono">${s.target}</dd></div></dl>
      <p class="nova-why">${esc(stratName(s.strategy))} · ${esc(L(`نسبة النجاح المقاسة ${pct(s.winRate)} على ${s.sample} صفقة بآخر ${s.days} يوم`, `measured win rate ${pct(s.winRate)} over ${s.sample} trades in the last ${s.days} days`))}</p>
    </article>`;
  };
  const empty = (txt) => `<p class="muted nova-empty">${esc(txt)}</p>`;

  function paint(d) {
    const sigs = d.signals || []; const sum = novaSummary(sigs);
    const byId = new Map((d.markets || []).map((m) => [m.id, m]));
    const liveN = NOVA_MARKETS.filter((m) => byId.get(m.id)?.state === 'live').length;
    el.querySelector('[data-kpis]').innerHTML = [
      [L('أسواق حيّة', 'Live markets'), `${liveN}/${NOVA_MARKETS.length}`, 'radar', 'k-blue'],
      [L('توصيات مفتوحة', 'Open'), String(sum.active), 'bolt', 'k-gold'],
      [L('سجل المحرك الفعلي', 'Engine record'), sum.closed ? `${sum.wins}/${sum.closed} · ${pct(sum.winRate)}` : L('لسا ما في صفقات مسكّرة', 'No closed trades yet'), 'bars', 'k-green'],
      [L('آخر فحص', 'Last scan'), d.lastScan ? fmtTz(Math.floor(d.lastScan / 1000), getLang()) : '—', 'alarm', 'k-violet'],
    ].map(([k, v, ic, c]) => `<div class="nova-kpi ${c}"><i class="nova-kpi-ic" aria-hidden="true">${icons[ic] || ''}</i><span>${esc(k)}</span><b>${esc(v)}</b></div>`).join('');
    const open = sigs.filter((s) => s.status === 'active'); const closed = sigs.filter((s) => s.status !== 'active').slice(0, 30);
    el.querySelector('[data-open]').innerHTML = open.length ? open.map(card).join('') : empty(d.configured === false ? L('الماسح مش شغّال على السيرفر هلق.', 'The scanner is not running on the server right now.') : L('ما في توصية هلق. المحرك بيفحص كل دقيقة وبيبعت فوراً لما تتحقق الشروط.', 'No signal right now. The engine checks every minute and sends at once when the conditions are met.'));
    el.querySelector('[data-closed]').innerHTML = closed.length ? closed.map(card).join('') : empty(L('لسا ما في توصيات مسكّرة.', 'No closed signals yet.'));
    el.querySelector('[data-markets]').innerHTML = NOVA_MARKETS.map((m) => {
      const ms = byId.get(m.id) || { state: 'pending' }; const st = MSTATE[ms.state] || MSTATE.pending; const q = ms.qualified || [];
      return `<div class="nova-m"><span class="nova-m-ic">${/^(EUR|GBP|USD)(USD|JPY)$/.test(m.id) ? `<i class="nova-fx" dir="ltr">${esc(m.id.slice(0, 3))}</i>` : assetIcon(getInstrument(m.symbol)?.icon, 30)}</span><b>${esc(m.id)}${m.aka ? ` <small class="muted">= ${esc(m.aka)}</small>` : ''}</b><span class="badge ${st[1]}">${esc(st[0])}</span>
        <small class="muted">${ms.state === 'live' ? esc(q.length ? L(`${q.length} استراتيجية مؤهلة: `, `${q.length} qualified: `) + q.map((x) => `${stratName(x.strategy)} ${pct(x.winRate)}`).join(' · ') : L(`ولا استراتيجية من ${ms.checked || 0} وصلت 67% على هالسوق هلق`, `none of ${ms.checked || 0} strategies reaches 67% on this market now`)) : ''}</small></div>`;
    }).join('');
    el.querySelector('[data-foot]').textContent = `${L('التوقيت', 'Time zone')}: ${tzLabel()}`;
  }

  let stop = false; let timer = 0;
  const load = async () => {
    if (stop) return;
    try { paint(await apiRequest('GET', '/api/nova/feed', undefined, 15000)); }
    catch { if (!el.querySelector('.nova-card, .nova-m')) paint({ configured: false, signals: [], markets: [] }); }
    if (!stop) timer = setTimeout(load, POLL_MS);
  };
  paint({ signals: [], markets: [] }); load();
  el._cleanup = () => { stop = true; clearTimeout(timer); };
  return el;
}
