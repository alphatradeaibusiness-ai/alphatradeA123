// Gotriva AI — the full assistant page (also reachable from the side menu). A chat in the style of ChatGPT: it answers in the
// language and dialect the person writes or speaks in, keeps the conversation's context, accepts voice messages (speech to
// text in the browser) and can read its replies aloud. Two modes: trading assistant (answers from the dashboard's real
// snapshot only) and technical support (how to use the site). Both go through the site's AI gateway — no canned answers.
import { h, esc } from '../utils/dom.js';
import { icons, logoMark } from '../components/icons.js';
import { t, getLang } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { sendAiMessage, sendSupportMessage } from '../services/ai/client.js';
import { aiErrorText } from '../components/aiKeyCard.js';
import { describeError } from '../utils/http.js';
import { aiContext } from '../services/analysis.js';
import { micButton, speak, stopSpeaking, speechSupported, voiceSupported, SPEAKER_ICON, WAVE_ICON, conversation } from '../services/voice.js';
import { storage } from '../utils/storage.js';
import '../styles/alpha.css';
import { HERO_ART, WAVE_ART, AX_ICONS } from './alphaArt.js';

const KEY = 'alpha-chat';
const load = () => { try { const v = JSON.parse(sessionStorage.getItem(`ata:${KEY}`) || 'null'); return v && Array.isArray(v.chat) ? v : { chat: [], support: [] }; } catch { return { chat: [], support: [] }; } };
const persist = (h) => { try { sessionStorage.setItem(`ata:${KEY}`, JSON.stringify({ chat: h.chat.slice(-30), support: h.support.slice(-30) })); } catch { /* private mode */ } };

const SUGGEST = {
  chat: [
    { ar: 'شو رأيك بالسوق اللي فاتحه هلق؟', en: 'What do you think of the market I have open?', he: 'מה דעתך על השוק שפתוח אצלי?', es: '¿Qué opinas del mercado que tengo abierto?', zh: '你怎么看我现在打开的市场？' },
    { ar: 'اشرحلي مؤشر RSI ببساطة', en: 'Explain RSI simply', he: 'הסבר לי את RSI בפשטות', es: 'Explícame el RSI de forma sencilla', zh: '简单解释一下 RSI' },
    { ar: 'كيف بحسب حجم الصفقة الصح؟', en: 'How do I size a trade correctly?', he: 'איך מחשבים גודל עסקה נכון?', es: '¿Cómo calculo bien el tamaño de una operación?', zh: '如何正确计算仓位？' },
    { ar: 'ليش التوصية طلعت «لا صفقة»؟', en: 'Why did the signal say "no trade"?', he: 'למה ההמלצה יצאה "אין עסקה"?', es: '¿Por qué la señal dijo "sin operación"?', zh: '为什么信号显示“不交易”？' },
  ],
  support: [
    { ar: 'كيف بفعّل الإشعارات على تلفوني؟', en: 'How do I turn on phone notifications?', he: 'איך מפעילים התראות בטלפון?', es: '¿Cómo activo las notificaciones del móvil?', zh: '怎样开启手机通知？' },
    { ar: 'كيف بغيّر الاشتراك؟', en: 'How do I change my plan?', he: 'איך משנים את התוכנית?', es: '¿Cómo cambio mi plan?', zh: '如何更改套餐？' },
  ],
};

export function renderAlpha({ getDashboard } = {}) {
  const hist = load();
  let mode = storage.get('alpha-mode', 'chat') === 'support' ? 'support' : 'chat';
  let speakOn = storage.get('alpha-speak', false) === true;
  let busy = false;
  const T = (ar, en) => tx({ ar, en });
  const ACTIONS = [
    { ic: 'bars', title: T('تحليل عملة معينة', 'Analyse a coin'), fill: T('حلّل لي عملة ', 'Analyse this coin for me: ') },
    { ic: 'rsi', title: T('تحليل مؤشر RSI', 'RSI analysis'), q: T('شو بيقول مؤشر RSI على السوق المفتوح عندي هلق؟ في تشبع شرائي أو بيعي أو دايفرجنس؟', 'What does RSI say on the market I have open? Any overbought/oversold or divergence?') },
    { ic: 'candles', title: T('توقع حركة السوق', 'Market outlook'), q: T('شو السيناريو الأرجح لحركة السوق المفتوح عندي بالفترة الجاية؟ أعطيني سيناريوهين مع مستوى الإبطال لكل واحد.', 'What is the most likely next move for the market I have open? Give two scenarios with an invalidation level each.') },
    { ic: 'alert', title: T('إدارة المخاطر', 'Risk management'), q: T('كيف أدير المخاطرة على صفقة بالسوق المفتوح عندي؟ حجم الصفقة، مكان الستوب، ونسبة المخاطرة المناسبة.', 'How should I manage risk on a trade in the market I have open? Position size, stop placement and risk per trade.') },
    { ic: 'settings', title: T('اقتراح استراتيجية تداول', 'Suggest a strategy'), q: T('اقترح علي استراتيجية تداول مناسبة لحالة السوق المفتوح عندي هلق، مع شروط الدخول والخروج.', 'Suggest a trading strategy that suits the current state of the market I have open, with entry and exit rules.') },
    { ic: 'sliders', title: T('تحسين صفقتك', 'Improve your trade'), fill: T('عندي صفقة: الدخول … الستوب … الهدف … ، كيف بحسّنها؟', 'My trade: entry … stop … target … — how can I improve it?') },
  ];
  const SERVICES = [
    { ic: 'chip', href: '#/app/council', title: T('نماذج متقدمة', 'Advanced models'), sub: T('مجلس AI بعدة آراء', 'AI council, several views') },
    { ic: 'growth', href: '#/app/markets', title: T('تحليل ذكي', 'Smart analysis'), sub: T('قراءة شاملة للسوق', 'Full market read') },
    { ic: 'bolt', href: '#/app/ai-signal', title: T('فرص تداول', 'Trade setups'), sub: T('اكتشاف فرص جديدة', 'Find new setups') },
    { ic: 'shieldBell', href: '#/app/alerts', title: T('تنبيهات فورية', 'Instant alerts'), sub: T('إشعارات وتحركات مهمة', 'Alerts and key moves') },
  ];
  const el = h(`<section class="subpage alpha ax page-enter" aria-label="Gotriva AI">
    <header class="ax-hero alpha-head">
      ${HERO_ART}
      <div class="ax-brand">
        <div class="ax-logo"><span class="ax-mark">${logoMark(40)}</span><div><h1 dir="ltr">GOTRIVA TRADE <i>AI</i></h1><h2>${esc(T('مساعد التداول الذكي', 'Smart trading assistant'))}</h2></div></div>
        <p>${esc(T('تحليل الأسواق • توليد الاستراتيجيات • إدارة المخاطر • توصيات احترافية', 'Market analysis • Strategy ideas • Risk management • Professional setups'))}</p>
        <div class="ax-modes alpha-modes" role="tablist">
          <button type="button" data-mode="chat" role="tab">${AX_ICONS.target}<span>${esc(tx({ ar: 'مساعد التداول', en: 'Trading assistant', he: 'עוזר מסחר', es: 'Asistente de trading', zh: '交易助手' }))}</span></button>
          <button type="button" data-mode="support" role="tab">${AX_ICONS.headset}<span>${esc(tx({ ar: 'الدعم الفني', en: 'Technical support', he: 'תמיכה טכנית', es: 'Soporte técnico', zh: '技术支持' }))}</span></button>
        </div>
      </div>
      <div class="alpha-tools ax-tools">
        ${speechSupported() ? `<button type="button" class="btn btn-icon alpha-speak ${speakOn ? 'is-on' : ''}" data-speak aria-pressed="${speakOn}" title="${esc(tx({ ar: 'قراءة الردود بصوت', en: 'Read replies aloud', he: 'הקרא תשובות בקול', es: 'Leer respuestas en voz alta', zh: '朗读回复' }))}" aria-label="${esc(tx({ ar: 'قراءة الردود بصوت', en: 'Read replies aloud' }))}">${SPEAKER_ICON}</button>` : ''}
        ${voiceSupported() ? `<button type="button" class="btn btn-icon alpha-call" data-call title="${esc(tx({ ar: 'محادثة صوتية مع Gotriva AI', en: 'Voice conversation with Gotriva AI', he: 'שיחה קולית עם Gotriva AI', es: 'Conversación por voz con Gotriva AI', zh: '与 Gotriva AI 语音对话' }))}" aria-label="${esc(tx({ ar: 'محادثة صوتية', en: 'Voice conversation', he: 'שיחה קולית', es: 'Conversación por voz', zh: '语音对话' }))}">${WAVE_ICON}</button>` : ''}
        <button type="button" class="btn btn-icon" data-new title="${esc(tx({ ar: 'محادثة جديدة', en: 'New chat', he: 'שיחה חדשה', es: 'Nuevo chat', zh: '新对话' }))}" aria-label="${esc(tx({ ar: 'محادثة جديدة', en: 'New chat' }))}">${icons.plus}</button>
      </div>
    </header>
    <div class="ax-console">
      <div class="ax-ask"><span class="ax-mark lg">${logoMark(44)}</span><h2>${esc(tx({ ar: 'كيف بقدر ساعدك اليوم؟', en: 'How can I help you today?', he: 'איך אפשר לעזור היום?', es: '¿En qué puedo ayudarte hoy?', zh: '今天我能帮你什么？' }))}</h2></div>
      <div class="ax-actions" data-actions>${ACTIONS.map((x, i) => `<button type="button" class="ax-act" data-act="${i}">${AX_ICONS[x.ic]}<b>${esc(x.title)}</b><span class="ax-chev" aria-hidden="true">${icons.chevronDown}</span></button>`).join('')}</div>
      <div class="alpha-log" data-log aria-live="polite"></div>
      <div class="alpha-live" data-live hidden role="status" aria-live="polite">
        <span class="alpha-orb" aria-hidden="true"><i></i><i></i><i></i></span>
        <div class="alpha-live-txt"><b data-live-state></b><small data-live-heard dir="auto"></small></div>
        <button type="button" class="btn btn-sm alpha-live-stop" data-live-stop>${esc(tx({ ar: 'إنهاء', en: 'End', he: 'סיום', es: 'Terminar', zh: '结束' }))}</button>
      </div>
      <form class="alpha-composer ax-composer" data-form>
        <button class="alpha-send" type="submit" aria-label="${esc(t('ai.send'))}"><span class="flip-rtl">${icons.send}</span></button>
        <textarea name="q" rows="1" maxlength="6000" placeholder="${esc(tx({ ar: 'اكتب سؤالك هنا… أو اكبس المايك واحكي', en: 'Ask Gotriva AI… or tap the mic and talk', he: 'כתוב הודעה… או לחץ על המיקרופון ודבר', es: 'Escribe tu mensaje… o pulsa el micrófono y habla', zh: '输入消息…或点击麦克风说话' }))}" aria-label="Message"></textarea>
        <label class="ax-attach" title="${esc(T('إرفاق ملف نصي (txt, csv, json)', 'Attach a text file (txt, csv, json)'))}"><input type="file" accept=".txt,.csv,.json,.md,.log,text/plain,text/csv,application/json" data-file hidden/>${AX_ICONS.clip}<span class="sr-only">${esc(T('إرفاق ملف', 'Attach a file'))}</span></label>
        <span data-mic></span>
      </form>
      <small class="ax-file-note" data-file-note hidden role="status"></small>
    </div>
    <nav class="ax-services" aria-label="${esc(T('خدمات سريعة', 'Quick services'))}">${SERVICES.map((x) => `<a class="ax-svc" href="${x.href}">${AX_ICONS[x.ic]}<b>${esc(x.title)}</b><small>${esc(x.sub)}</small></a>`).join('')}</nav>
    <p class="alpha-fine">${esc(tx({ ar: 'Gotriva AI بيحكي من بيانات الموقع الحقيقية بس، وممكن يغلط. هاد مش نصيحة مالية.', en: 'Gotriva AI uses only the site\'s real data and can make mistakes. Not financial advice.', he: 'Gotriva AI משתמש רק בנתוני האתר ועלול לטעות. זה לא ייעוץ פיננסי.', es: 'Gotriva AI solo usa los datos reales del sitio y puede equivocarse. No es asesoramiento financiero.', zh: 'Gotriva AI 只使用网站的真实数据，可能出错。不构成投资建议。' }))}${voiceSupported() ? '' : ` ${esc(tx({ ar: 'المتصفح هاد ما بيدعم الرسائل الصوتية.', en: 'This browser does not support voice messages.', he: 'הדפדפן הזה לא תומך בהודעות קוליות.', es: 'Este navegador no admite mensajes de voz.', zh: '此浏览器不支持语音消息。' }))}`}</p>
    ${WAVE_ART}
  </section>`);
  const $ = (s) => el.querySelector(s);
  const log = $('[data-log]'); const form = $('[data-form]'); const box = form.q;

  const fmt = (s) => esc(s).replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/\n/g, '<br>');
  function draw() {
    el.querySelectorAll('[data-mode]').forEach((b) => { b.classList.toggle('is-on', b.dataset.mode === mode); b.setAttribute('aria-selected', String(b.dataset.mode === mode)); });
    const list = hist[mode];
    el.classList.toggle('is-empty', !list.length);
    if (!list.length) {
      log.innerHTML = mode === 'support' ? `<div class="alpha-chips">${SUGGEST.support.map((q) => `<button type="button" class="alpha-chip" data-q="${esc(tx(q))}">${esc(tx(q))}</button>`).join('')}</div>` : '';
      return;
    }
    log.innerHTML = list.map((m) => `<div class="alpha-msg is-${m.role}${m.error ? ' is-error' : ''}">${m.role === 'assistant' ? `<span class="alpha-avatar sm">${logoMark(18)}</span>` : ''}<div class="alpha-bubble" dir="auto">${fmt(m.content)}${m.role === 'assistant' && !m.error && speechSupported() ? `<button type="button" class="alpha-read" data-read="${esc(m.content.slice(0, 1500))}" aria-label="Listen">${SPEAKER_ICON}</button>` : ''}</div></div>`).join('')
      + (busy ? `<div class="alpha-msg is-assistant"><span class="alpha-avatar sm">${logoMark(18)}</span><div class="alpha-bubble alpha-typing"><i></i><i></i><i></i></div></div>` : '');
    log.scrollTop = log.scrollHeight;
  }
  async function ask(q, { silent = false } = {}) {
    const text = String(q || '').trim(); if (!text || busy) return '';
    const list = hist[mode]; list.push({ role: 'user', content: text }); box.value = ''; grow(); busy = true; draw(); persist(hist);
    const msgs = list.filter((m) => !m.error).slice(-16).map(({ role, content }) => ({ role, content }));
    try {
      let reply;
      if (mode === 'support') reply = await sendSupportMessage(msgs, 'alpha', getLang());
      else { const a = getDashboard?.()?.getAnalysis?.(); reply = await sendAiMessage(msgs, a ? aiContext(a) : { note: 'no chart open' }, getLang()); }
      list.push({ role: 'assistant', content: reply });
      if (speakOn && !silent) speak(reply, getLang());
      busy = false; persist(hist); if (el.isConnected) draw();
      return reply;
    } catch (err) {
      list.push({ role: 'assistant', error: true, content: t('ai.error', { msg: err?.code && /^[a-z_]+$/.test(err.code) ? aiErrorText(err.code) : describeError(err, t) }) });
    }
    busy = false; persist(hist); if (el.isConnected) draw();
    return '';
  }
  const grow = () => { box.style.height = 'auto'; box.style.height = `${Math.min(160, box.scrollHeight)}px`; };
  $('[data-mic]').replaceWith(micButton(box, { lang: getLang, autoSend: (v) => ask(v), label: tx({ ar: 'رسالة صوتية', en: 'Voice message', he: 'הודעה קולית', es: 'Mensaje de voz', zh: '语音消息' }) }));
  if (typeof matchMedia === 'function' && matchMedia('(max-width: 560px)').matches) box.placeholder = tx({ ar: 'اكتب سؤالك هنا…', en: 'Ask Gotriva AI…', he: 'כתוב הודעה…', es: 'Escribe tu mensaje…', zh: '输入消息…' });   // v333: short on phones (no cut-off second line)
  box.addEventListener('input', grow);
  box.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); ask(box.value); } });
  form.addEventListener('submit', (e) => { e.preventDefault(); ask(box.value); });
  // v333: the six quick actions — send a ready question to the trading assistant, or fill the box for the user to finish
  el.addEventListener('click', (e) => {
    const a = e.target.closest('[data-act]'); if (!a) return;
    const x = ACTIONS[Number(a.dataset.act)]; if (!x) return;
    if (mode !== 'chat') { mode = 'chat'; storage.set('alpha-mode', mode); draw(); }
    if (x.q) { ask(x.q); return; }
    box.value = x.fill; grow(); box.focus(); try { box.setSelectionRange(box.value.length, box.value.length); } catch { /* */ }
  });
  // v333: attach a text file — its text is added to the message (read in the browser; nothing is uploaded until you send)
  const fileNote = $('[data-file-note]');
  $('[data-file]').addEventListener('change', async (e) => {
    const f = e.target.files?.[0]; e.target.value = ''; if (!f) return;
    const note = (msg) => { fileNote.textContent = msg; fileNote.hidden = false; setTimeout(() => { fileNote.hidden = true; }, 6000); };
    if (!/\.(txt|csv|json|md|log)$/i.test(f.name) && !/^text\/|json/.test(f.type)) { note(T('بس ملفات نصية: txt أو csv أو json.', 'Text files only: txt, csv or json.')); return; }
    try {
      let txt = await f.text(); const cut = txt.length > 4000; txt = txt.slice(0, 4000);
      box.value = `${box.value ? `${box.value}\n\n` : ''}[${f.name}]\n${txt}`; grow(); box.focus();
      note(cut ? T('انضاف أول 4000 حرف من الملف.', 'The first 4000 characters were added.') : T('انضاف الملف للرسالة. اكتب سؤالك وابعت.', 'File added to your message. Ask your question and send.'));
    } catch { note(T('ما قدرت أقرأ الملف.', 'Could not read the file.')); }
  });
  el.addEventListener('click', (e) => {
    const m = e.target.closest('[data-mode]'); if (m) { mode = m.dataset.mode; storage.set('alpha-mode', mode); draw(); return; }
    const c = e.target.closest('[data-q]'); if (c) { ask(c.dataset.q); return; }
    const r = e.target.closest('[data-read]'); if (r) { speak(r.dataset.read, getLang()); return; }
    if (e.target.closest('[data-new]')) { hist[mode] = []; persist(hist); stopSpeaking(); draw(); return; }
    const sp = e.target.closest('[data-speak]'); if (sp) { speakOn = !speakOn; storage.set('alpha-speak', speakOn); sp.classList.toggle('is-on', speakOn); sp.setAttribute('aria-pressed', String(speakOn)); if (!speakOn) stopSpeaking(); }
  });
  // v276: hands-free voice conversation — tap once, talk, hear the answer, talk again; "End" hangs up.
  const live = $('[data-live]'); let call = null;
  const LIVE_TXT = {
    listen: { ar: 'بسمعك… احكي', en: 'Listening… go ahead', he: 'מקשיב… דבר', es: 'Te escucho… habla', zh: '正在听…请说' },
    think: { ar: 'بفكّر…', en: 'Thinking…', he: 'חושב…', es: 'Pensando…', zh: '思考中…' },
    speak: { ar: 'Gotriva AI بيحكي…', en: 'Gotriva AI is speaking…', he: 'Gotriva AI מדבר…', es: 'Gotriva AI está hablando…', zh: 'Gotriva AI 正在说…' },
  };
  const WHY = {
    'not-allowed': { ar: 'المايك مسكّر. اسمح للموقع يستعمل المايك من إعدادات المتصفح.', en: 'The microphone is blocked. Allow it for this site in the browser settings.', he: 'המיקרופון חסום. אפשר אותו לאתר בהגדרות הדפדפן.', es: 'El micrófono está bloqueado. Permítelo para este sitio en los ajustes del navegador.', zh: '麦克风被禁用，请在浏览器设置中允许本网站使用。' },
    'audio-capture': { ar: 'ما في مايك شغّال على هالجهاز.', en: 'No working microphone was found.', he: 'לא נמצא מיקרופון פעיל.', es: 'No se encontró un micrófono que funcione.', zh: '未找到可用的麦克风。' },
    unsupported: { ar: 'هالمتصفح ما بيدعم المحادثة الصوتية. جرّب Chrome أو Safari.', en: 'This browser does not support voice conversation. Try Chrome or Safari.', he: 'הדפדפן לא תומך בשיחה קולית. נסו Chrome או Safari.', es: 'Este navegador no admite conversación por voz. Prueba Chrome o Safari.', zh: '此浏览器不支持语音对话，请使用 Chrome 或 Safari。' },
    idle: { ar: 'سكّرت المحادثة لأنه ما في صوت من دقيقة.', en: 'Conversation ended after a minute of silence.', he: 'השיחה הסתיימה אחרי דקה של שקט.', es: 'La conversación terminó tras un minuto de silencio.', zh: '静音一分钟，已结束对话。' },
  };
  const setLive = (state, detail) => {
    if (state === 'off') {
      live.hidden = true; el.classList.remove('is-calling'); call = null;
      if (detail && WHY[detail]) { live.hidden = false; live.dataset.state = 'off'; $('[data-live-state]').textContent = tx(WHY[detail]); $('[data-live-heard]').textContent = ''; setTimeout(() => { if (!call) live.hidden = true; }, 6000); }
      return;
    }
    live.hidden = false; live.dataset.state = state; el.classList.add('is-calling');
    $('[data-live-state]').textContent = tx(LIVE_TXT[state]);
    if (state === 'listen') $('[data-live-heard]').textContent = '';
    if (state === 'think' && detail) $('[data-live-heard]').textContent = detail;
  };
  el.addEventListener('click', (e) => {
    if (e.target.closest('[data-call]')) { if (call) { call.stop(); return; } stopSpeaking(); call = conversation(getLang, { onAsk: (q) => ask(q, { silent: true }), onState: setLive, onHeard: (txt) => { $('[data-live-heard]').textContent = txt; } }); return; }
    if (e.target.closest('[data-live-stop]')) { call?.stop(); live.hidden = true; }
  });
  window.addEventListener('hashchange', () => call?.stop(), { once: true });
  draw();
  return el;
}
