// Private, subscription-aware recommendations. Price repaint never rebuilds open details.
import { h, esc, fmtNum } from '../utils/dom.js';
import { getLang, t } from '../i18n/index.js';
import { INSTRUMENTS } from '../config/instruments.js';
import { isUnavailable } from '../services/market/index.js';
import { signalState, onSignals, enableNotifications, notifyPermission, describe } from '../services/signals.js';
import { signalCardHtml, paintLive } from '../components/signalCard.js';
import { analysisImage } from '../services/analysisImage.js';
import { auth } from '../services/auth/index.js';
import { apiRequest } from '../services/ai/gateway.js';
import { CHANNEL_PRODUCTS, CHANNEL_PLANS } from '../config/channelPlans.js';
import { applySignal, wasApplied, oneClickLot } from '../services/mt5Apply.js';
import { toast } from '../components/ui.js';
import { ii } from '../components/icons.js';
import { learnState, resetLearning, LEARN_STRATEGIES } from '../services/learning.js';
import { MARKET_GROUPS, marketName } from '../config/marketNames.js';
import '../styles/recommendations.css';
import '../styles/mt5btn.css';
import { HERO_ARTS, PAGE_WAVE, CAT_ICONS } from './heroArt.js';   // v334: neon page art from the owner's pictures (chamfered buttons of v330 replaced)

export function renderSignals() {
  const en=getLang() !== 'ar', L=(ar,english)=>en?english:ar;
  const saved=(()=>{try{return JSON.parse(localStorage.getItem('ata:chan-market')||'{}')}catch{return {}}})();
  const state={symbol:saved.symbol||'all',cat:saved.cat||'all',strategy:'all',status:'all',order:'all',page:1};
  const el=h(`<section class="subpage rc-page page-enter"><header class="rc-heading has-art">${HERO_ARTS.signals}<div><small>${L('جوتريفا تريد / التوصيات','GOTRIVA TRADE / SIGNALS')}</small><h1><span>${L('قناة التوصيات','Recommendations')}</span><span class="pg-tile" aria-hidden="true">${CAT_ICONS.index}</span></h1><p class="muted">${L('كل فرصة بتفاصيلها، من الدخول حتى النتيجة.','Each setup, from entry to its recorded outcome.')}</p></div><a class="btn btn-sm" href="#/app/pricing">${ii('crown')}<span>${L('الباقات وزيادة الحصة','Plans & top-ups')}</span></a></header>
  <nav class="rc-markets" data-markets aria-label="${L('الأسواق','Markets')}"><div class="rcq-head" data-allowance aria-live="polite"></div><div class="rc-mk-row" data-cats></div><div class="rc-mk-row rc-mk-sub" data-subs></div></nav>
  <p class="rc-service muted" data-service></p>
  <div class="rc-toolbar"><label><span class="rc-lab">${CAT_ICONS.target}${L('نوع الدخول','Entry type')}</span><select aria-label="${L('نوع الدخول','Entry type')}" data-filter="order"><option value="all">${L('الكل','All')}</option><option value="market">${L('ماركت · دخول فوري','Market · instant entry')}</option><option value="limit">${L('ليمِت · ينتظر السعر','Limit · waits for price')}</option></select></label><button type="button" class="btn btn-sm" data-notify>${ii('bell')}<span data-notify-t>${L('تفعيل التنبيهات','Enable notifications')}</span></button></div>
  <nav class="rc-tabs" aria-label="${L('حالة التوصية','Recommendation status')}">${[['all',L('الكل','All'),''],['pending',L('بانتظار الدخول','Pending'),CAT_ICONS.clock],['active',L('نشطة','Active'),CAT_ICONS.pulse],['closed',L('منتهية','Closed'),CAT_ICONS.done]].map(([k,n,ic])=>`<button type="button" class="btn btn-sm" data-status="${k}" aria-pressed="${k==='all'}">${ic}<span>${n}</span><i data-count-status="${k}"></i></button>`).join('')}</nav>
  <p class="rc-scan-line muted" data-scan-note aria-live="polite"></p>
  <div class="card rc-boost">
    <label class="rc-boost-item"><span><b>${CAT_ICONS.monitor}${L('خلّي الشاشة صاحية','Keep screen awake')}</b><small>${L('الفحص بالمتصفح بيوقف لما الجوال ينام. هاد بيخليه شغّال والصفحة مفتوحة.','Browser scanning stops when the phone sleeps. This keeps it running while the page is open.')}</small></span><input type="checkbox" data-wake/></label>
    <p class="rc-boost-server muted"><span class="rc-srv-ic">${CAT_ICONS.server}</span><span data-server-line></span></p></div>
  <details class="card rc-settings rc-learn" data-learn><summary>${L('التعلّم من الأخطاء','Learning from mistakes')} <small class="muted" data-learn-sum></small></summary><div data-learn-body></div></details>
  <div class="rc-list" data-list></div><div class="rc-pagination"><button type="button" class="btn btn-sm" data-prev>${L('السابق','Previous')}</button><span data-count></span><button type="button" class="btn btn-sm" data-next>${L('التالي','Next')}</button></div>
  <details class="card rc-settings"><summary>${L('معلومات القناة','Channel information')}</summary><p>${L('المتابعة سعرية وليست تنفيذًا لدى الوسيط. نوع الدخول تحدده التوصية؛ لا يحوّل تغيير الفلتر أمر ماركت إلى ليمِت. الصور من الشموع المحفوظة عند إصدار التوصية، والمستويات تظهر أسفلها.','Price tracking is not broker execution. Entry type is specified by the setup; filtering does not convert Market to Limit. Images use candles captured at issue time; levels appear underneath.')}</p><p>${L('لا تُفرض فرص لإكمال الحصة. النتائج من الأسعار المستلمة، وقد تُفقد حركات بين تحديثين؛ الأسعار المتأخرة تظهر بوضوح. الحصة تتجدد شهريًا من تاريخ بدء الاشتراك.','Quotas are ceilings, not promised opportunities. Results use received quotes and can miss moves between updates. Stale prices are flagged. Allowances renew on each monthly subscription anniversary.')}</p><p>${L('التنبيهات على هذا الجهاز تعمل أثناء فتح التطبيق وبحسب إذن المتصفح.','Device notifications require browser permission and the app to be open.')}</p><button type="button" class="btn btn-sm" data-export hidden>${L('تصدير إعدادات عامل السيرفر','Export server worker settings')}</button></details>
  <details class="card rc-settings" data-owner hidden><summary>${L('إدارة اشتراكات القناة، للمالك','Channel subscription management, owner')}</summary><p>${L('فعّل بعد التحقق من الدفع لدى مزوّدك. تكرار مرجع الدفع لا يضيف حصة ثانية.','Activate only after verifying payment with your provider. Reusing a payment reference does not add allowance twice.')}</p><form class="rc-owner-form" data-grant><label>${L('معرّف المستخدم من Firebase','Firebase user ID')}<input class="input" name="uid" required maxlength="128"/></label><label>${L('الباقة أو الإضافة','Plan or top-up')}<select class="input" name="product">${Object.keys(CHANNEL_PLANS).map(k=>`<option value="${k}">${esc(k==='channel'?L('القناة المستقلة','Channel only'):t('pricing.plans.'+k))} · ${CHANNEL_PLANS[k].quota}</option>`).join('')}${CHANNEL_PRODUCTS.filter(p=>p.kind==='addon').map(p=>`<option value="${p.id}">+${p.count}</option>`).join('')}</select></label><label>${L('مرجع الدفع المؤكد','Verified payment reference')}<input class="input" name="paymentId" required maxlength="200"/></label><label>${L('بداية الاشتراك','Subscription start')}<input class="input" type="datetime-local" name="startsAt"/></label><label>${L('نهاية الاشتراك','Subscription end')}<input class="input" type="datetime-local" name="until"/></label><label><input type="checkbox" name="replace"/> ${L('استبدال الاشتراك الحالي عند تغيير نوع الباقة','Replace existing subscription when changing plan type')}</label><button type="submit" class="btn">${L('تفعيل شراء مؤكد','Activate verified purchase')}</button><p data-grant-result aria-live="polite"></p></form></details>${PAGE_WAVE}</section>`);
  const $=s=>el.querySelector(s); let listKey='',lastAllowance='',disposed=false;
  const date=ms=>ms?new Date(ms).toLocaleString(en?'en-GB':'ar-EG-u-nu-latn'):'—';
  const reason=s=>s.strategy==='trend'?L('تتبّع الاتجاه: الفريم الأعلى وترتيب EMA 20/50/200 وهيكل القمم والقيعان والزخم (ADX، RSI، MACD) كلهم بنفس الاتجاه، مع رجوع لـ EMA وشمعة تأكيد مسكّرة وعائد للمخاطرة ≥ 1.5.','Trend following: higher timeframe, EMA 20/50/200 order, swing structure and momentum (ADX, RSI, MACD) all agree, with a pullback to the EMA, a closed confirmation candle and reward-to-risk ≥ 1.5.'):s.strategy==='mean_reversion'?L('الارتداد للمتوسط: السعر لمس حد بولينجر ورجع لجوّا بشمعة مسكّرة، RSI بمنطقة تشبّع وعم يرجع، والسوق عرضي (ADX < 22) بدون اتجاه قوي ضد الصفقة.','Mean reversion: price touched a Bollinger band and closed back inside, RSI at an extreme and turning, ranging market (ADX < 22) with no strong trend against the trade.'):s.strategy==='lbr'?L('اختراق نطاق افتتاح لندن (07:00–07:30 UTC) بإغلاق شمعة 5 دقائق مع اتجاه الساعة، والدخول بأمر ليمِت عند حافة النطاق إذا رجع السعر لها خلال ساعة.','London opening range (07:00–07:30 UTC) broken by a 5-minute close with the 1-hour trend; limit entry at the broken edge if price returns within an hour.'):s.strategy==='edh'?L('إغلاق مؤكد خارج مستوى اليوم السابق وفق قواعد EDH.','Confirmed close beyond the previous day level under EDH rules.'):s.strategy==='smc'?L('إشارة مستوفية لقواعد السيولة وهيكل السوق في المحرك.','Signal meeting the engine’s liquidity and market structure rules.'):s.strategy==='zone'?L('توافق مناطق العرض والطلب مع فلاتر الاستراتيجية.','Supply/demand setup with the strategy’s confirmation filters.'):L('تأكيد الزخم وفق قواعد الاستراتيجية الكلاسيكية.','Momentum confirmation under the classic strategy rules.');
  const detail=s=>{
    const v=signalState().allowance?.view, research=v!=='essential', advanced=['advanced','complete'].includes(v), watch=s.tier==='watch', engine=s.tier==='engine';
    const risk=Math.abs(s.entry-s.stop),p=n=>fmtNum(n,s.precision);
    return `<details class="rc-details" data-detail="${esc(s.id)}"><summary>${L('التحليل وتفاصيل التوصية','Analysis & trade details')} <span>↗</span></summary><div class="rc-detail-body"><div data-chart="${esc(s.id)}"></div><div class="rc-detail-levels">${signalCardHtml(s,{animated:false})}</div><p>${esc(reason(s))}</p><dl class="rc-facts"><div><dt>${L('الإصدار','Issued')}</dt><dd>${date(s.createdAt)}</dd></div><div><dt>${L('التفعيل','Activated')}</dt><dd>${date(s.activatedAt)}</dd></div><div><dt>${L('صلاحية الدخول','Entry expiry')}</dt><dd>${s.order==='limit'?date(s.expiresAt):L('دخول ماركت عند الإصدار','Market at issue')}</dd></div><div><dt>${L('إلغاء الفكرة','Invalidation')}</dt><dd>${L('تجاوز وقف الخسارة عند','Beyond the stop at')} ${p(s.stop)}</dd></div><div><dt>${L('انتهاء المتابعة','Closed')}</dt><dd>${date(s.closedAt)}</dd></div></dl>
    ${research?`<div class="rc-research"><b>${L('أدلة الاستراتيجية','Strategy evidence')}</b><p>${s.score!=null?L('درجة شروط المحرك: ','Engine condition score: ')+fmtNum(s.score,0):L('لا توجد درجة شروط مسجلة لهذه التوصية.','No condition score recorded for this setup.')}</p>${s.confirm?`<p>${L('نتيجة فحص التأكيد: ','Confirmation check: ')}${fmtNum(s.confirm.score,0)} · ${L('عوامل متوافقة: ','Agreement count: ')}${Number(s.confirm.agree)||0}</p>`:''}${engine?`<p class="rc-watch-note">${L('توصية من محرك AI متعدد الاستراتيجيات: كل الشروط الإلزامية لهالاستراتيجية وفلاتر الأمان نجحت عند الإصدار. ما إلها نسبة نجاح تاريخية مثبتة بعد.','From the multi-strategy AI engine: every mandatory condition of this strategy and every safety filter passed at issue time. It has no proven historical win rate yet.')}</p>`:''}${watch?`<p class="rc-watch-note">${L('هاي التوصية «تحت المراقبة»: نتيجة تركيبتها إيجابية بس لسا ما وصلت شروط القناة الكاملة (62% على 30 صفقة). تعامل معها بحجم أصغر.','This setup is “under watch”: its combination is positive but has not yet met the full channel bar (62% over 30 trades). Consider a smaller size.')}</p>`:''}<p>${s.accuracy>0?`${L('نسبة تاريخية مقاسة، وليست احتمال نجاح الصفقة: ','Measured historical rate, not this trade’s win probability: ')} ${fmtNum(s.accuracy,0)}% · ${Number(s.trades)||0} ${L('صفقة','trades')}`:L('لا تتوفر نسبة نجاح موثقة لهذه التوصية.','No validated win rate for this recommendation.')}</p></div>`:''}
    ${advanced?`<div class="rc-ratios">${s.targets.map((n,i)=>`<span>${L('الهدف','Target')} ${i+1}: <b>${risk?fmtNum(Math.abs(n-s.entry)/risk,2):'—'}R</b></span>`).join('')}</div>`:''}<p class="muted">${L('وقف الخسارة والأهداف والدخول ثابتة في شريط التوصية. بعد الهدف الأول، يتابع المحرك المتبقي عند التعادل وفق قواعده.','Entry, stop and targets remain in the price strip. After target one, the engine tracks the remaining portion at breakeven under its rules.')}</p></div></details>`;
  };
  const draw=(node,s)=>{
    const box=node.querySelector('[data-chart]'); if(!box || box.childNodes.length)return;
    if(!s.evidence?.bars?.length){box.textContent=L('صورة الإصدار غير محفوظة لهذه التوصية القديمة.','Issue-time image was not saved for this older recommendation.');return;}
    const png=analysisImage(s.evidence.bars,s.evidence.zones||[],{symbol:s.symbol,tf:s.tf,source:s.evidence.source});
    box.innerHTML=`<img class="rc-analysis-image" src="${png}" alt="${L('شموع السوق ومناطق التحليل عند إصدار التوصية','Market candles and analysis zones at issue time')}"/>${['advanced','complete'].includes(signalState().allowance?.view)?`<a class="btn btn-sm" href="${png}" download="${esc(s.symbol)}-analysis.png">${L('حفظ الصورة','Save image')}</a>`:''}`;
  };
  // One quiet status line instead of the per-market table: how many markets are being scanned and when the last pass ended.
  const paintScan=st=>{
    const live=INSTRUMENTS.filter(i=>!isUnavailable(i.symbol)).length;
    const open=st.signals.filter(x=>['active','pending'].includes(x.status)).length;
    $('[data-scan-note]').textContent=st.lastScan
      ?L(`الفحص شغّال على ${live} سوق · آخر فحص ${new Date(st.lastScan).toLocaleTimeString('ar-EG-u-nu-latn')} · توصيات مفتوحة: ${open} · كل توصية بتضل ساعتين`,`Scanning ${live} markets · last pass ${new Date(st.lastScan).toLocaleTimeString('en-GB')} · open recommendations: ${open} · each stays for 2 hours`)
      :L('جاري أول فحص للأسواق… التوصيات بتوصل هون أول ما تكتمل شروطها.','First market scan in progress… recommendations land here as soon as their conditions are met.');
  };
  // Screen wake lock: the browser scanner only runs while the page is visible; this keeps the phone from sleeping.
  let wake=null; const wakeBox=$('[data-wake]');
  if(!('wakeLock' in navigator)){wakeBox.disabled=true;wakeBox.closest('label').title=L('المتصفح ما بيدعمها','Not supported by this browser');}
  const lock=async()=>{try{wake=await navigator.wakeLock.request('screen');wake.addEventListener('release',()=>{wake=null;});}catch{wakeBox.checked=false;}};
  wakeBox.addEventListener('change',()=>{if(wakeBox.checked)lock();else{wake?.release();wake=null;}});
  const onVis=()=>{if(!el.isConnected){document.removeEventListener('visibilitychange',onVis);wake?.release();return;}if(wakeBox.checked&&!wake&&document.visibilityState==='visible')lock();};
  document.addEventListener('visibilitychange',onVis);
  // One click → the recommendation is sent to the linked MetaTrader 5 terminal (services/mt5Apply.js).
  const MT5_ICO='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="13" rx="2.5"/><path d="M7 13l3-3 2.5 2.5L17 8"/></svg>';
  const OK_ICO='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>';
  const mt5Btn=s=>{
    if(s.status!=='active')return'';
    const long=s.direction!=='short';
    if(wasApplied(s.id))return`<div class="rc-mt5"><span class="mt5-go is-done" role="status">${OK_ICO}${L('انطبقت على MT5','Applied on MT5')}</span></div>`;
    return`<div class="rc-mt5"><button type="button" class="mt5-go" data-mt5="${esc(s.id)}" title="${long?L('شراء','Buy'):L('بيع','Sell')} · ${L('دخول فوري مع الوقف والأهداف','instant entry with stop & targets')}"><span class="mt5-go-bolt" aria-hidden="true">⚡</span><span class="mt5-go-txt">${L('تطبيق على MT5','Apply on MT5')}</span><span class="mt5-go-lot">· ${fmtNum(oneClickLot(),2)} ${L('لوت','lot')}</span><i class="mt5-go-spin" aria-hidden="true"></i></button></div>`;
  };
  const MT5_ERR={no_link:L('ما في حساب MT5 مربوط. اربطه من خانة «ربط ميتاتريدر 5».','No MT5 account linked. Link one on the “MetaTrader 5 bridge” page.'),terminal_offline:L('منصة MT5 مش متصلة. افتح MT5 وتأكد إنه الـ EA شغّال.','MT5 is offline. Open MT5 and make sure the EA is running.'),trading_disabled:L('التداول مطفي بالـ EA (Allow trading) أو Algo Trading بالمنصة.','Trading is off in the EA (Allow trading) or Algo Trading in MT5.'),not_active:L('التوصية مش نشطة.','The recommendation is not active.'),already_applied:L('انطبقت قبل.','Already applied.'),server_missing:L('ربط MT5 بيحتاج سيرفر الموقع.','The MT5 bridge needs the site server.'),signin_required:L('سجّل الدخول أول.','Sign in first.')};
  el.addEventListener('click',async ev=>{
    const b=ev.target.closest('[data-mt5]'); if(!b||b.disabled)return;
    const s=signalState().signals.find(x=>x.id===b.dataset.mt5); if(!s)return;
    b.disabled=true; b.classList.add('is-busy'); const txt=b.querySelector('.mt5-go-txt'); const label=txt.textContent; txt.textContent=L('عم يتبعت…','Sending…');
    try{const r=await applySignal(s);toast(L(`انبعتت ${r.orders.length===3?'3 أوامر (ثلث لكل هدف)':'الصفقة'} لـ MT5 ${r.link.account}. النتيجة بسجل خانة MT5.`,`Sent ${r.orders.length===3?'3 orders (a third per target)':'the trade'} to MT5 ${r.link.account}. Result in the MT5 page log.`),'success',6000);listKey='';render(signalState());}
    catch(e){b.disabled=false;b.classList.remove('is-busy');txt.textContent=label;b.classList.add('is-shake');setTimeout(()=>b.classList.remove('is-shake'),500);toast(MT5_ERR[e.code]||L('ما انطبقت: ','Not applied: ')+(e.code||'error'),'error',7000);}
  });
  // Learning from mistakes (services/learning.js): what the engine stored, where each strategy deviates, what it changed.
  const SNAME={trend:L('تتبّع الاتجاه','Trend'),mean_reversion:L('الارتداد للمتوسط','Mean reversion'),smc:'SMC'};
  const FNAME={session:L('الجلسة','Session'),regime:L('حالة السوق','Regime'),adx:'ADX',rsi:'RSI',vol:L('التذبذب','Volatility'),dir:L('الاتجاه','Direction'),hour:L('الساعة (UTC)','Hour (UTC)'),market:L('السوق','Market'),htf:L('الفريم الأعلى','Higher TF')};
  const fName=f=>{const [k,v]=String(f).split('=');const vv={with:L('مع الصفقة','with the trade'),against:L('ضد الصفقة','against the trade'),long:L('شراء','buy'),short:L('بيع','sell'),trending:L('اتجاه','trending'),ranging:L('عرضي','ranging'),high_volatility:L('تذبذب عالي','high volatility'),uncertain:L('غير واضح','uncertain'),neutral:L('محايد','neutral'),asia:L('آسيا','Asia'),london:L('لندن','London'),new_york:L('نيويورك','New York'),london_ny:L('لندن + نيويورك','London + New York'),'very-low':L('منخفض جدًا','very low'),low:L('منخفض','low'),normal:L('طبيعي','normal'),high:L('عالي','high')}[v]||v;return `${FNAME[k]||k}: ${vv}`;};
  let learnKey='';
  const paintLearn=()=>{
    const S=learnState(); const Lr=S.learned||{}; const key=JSON.stringify([S.outcomes.length,S.log.length,Object.keys(Lr.blocks||{}),Lr.adj,en]); if(key===learnKey)return; learnKey=key;
    const blocks=Object.values(Lr.blocks||{}), prob=Object.values(Lr.probation||{});
    $('[data-learn-sum]').textContent=L(`${S.outcomes.length} نتيجة محفوظة · ${blocks.length} حالة محجوبة`,`${S.outcomes.length} results stored · ${blocks.length} contexts blocked`);
    const rows=LEARN_STRATEGIES.map(k=>{const x=Lr.strategies?.[k]||{n:0};return `<tr><td>${esc(SNAME[k])}</td><td class="mono">${x.n||0}</td><td class="mono">${x.n?Math.round(x.win*100)+'%':'—'}</td><td class="mono ${x.mean<0?'down':'up'}">${x.n?(x.mean>0?'+':'')+fmtNum(x.mean,2)+'R':'—'}</td><td class="mono">${Lr.adj?.[k]?'+'+fmtNum(Lr.adj[k],2):'0'}</td></tr>`;}).join('');
    const dev=(Lr.deviations||[]).slice(0,5).map(d=>`<li><b>${esc(SNAME[d.strategy])}</b> · ${esc(fName(d.feature))}, ${d.n} ${L('صفقة','trades')}, ${(d.dev>0?'+':'')+fmtNum(d.dev,2)}R ${L('عن معدّلها','vs its average')}</li>`).join('');
    const KIND={block:L('حجب','Blocked'),unblock:L('رفع الحجب','Unblocked'),probation:L('فرصة تانية (تجربة)','Second chance (probation)'),rr:L('تعديل العائد للمخاطرة','R:R adjusted')};
    const log=(S.log||[]).slice(0,10).map(x=>`<li><time class="mono">${esc(new Date(x.at).toLocaleString(en?'en-GB':'ar-EG-u-nu-latn'))}</time> <b>${esc(KIND[x.kind]||x.kind)}</b> · ${esc(SNAME[x.strategy]||x.strategy)}${x.feature?' · '+esc(fName(x.feature)):''}${x.kind==='rr'?` · +${fmtNum(x.from,2)} → +${fmtNum(x.to,2)}`:''}${x.kind==='block'?` · ${x.n} ${L('صفقة','trades')}, ${L('نجاح','win')} ${Math.round(x.win*100)}%`:''}</li>`).join('');
    $('[data-learn-body]').innerHTML=`<p class="muted">${L('المحرك بيخزّن نتيجة كل توصية من الاتجاه والارتداد وSMC، وبيقارن أداء كل استراتيجية بكل ظرف (الجلسة، حالة السوق، ADX، RSI، التذبذب، الاتجاه، الساعة، السوق). الظرف اللي بيضل يخسر بيتجنّبه لهالاستراتيجية، وبعد 7 أيام بيرجع يجرّبه. إذا آخر النتائج خسرانة بيرفع حد العائد للمخاطرة تدريجيًا. EDH ما بتتأثر. هاد فلتر إحصائي، مش ضمان.','The engine stores the result of every trend, mean-reversion and SMC recommendation and compares each strategy across contexts (session, regime, ADX, RSI, volatility, direction, hour, market). A context that keeps losing is avoided for that strategy and re-tested after 7 days; when recent results turn negative the minimum R:R rises step by step. EDH is not affected. A statistical filter, not a guarantee.')}</p>
      <div class="table-scroll"><table class="kv-table"><thead><tr><th>${L('الاستراتيجية','Strategy')}</th><th>${L('النتائج','Results')}</th><th>${L('النجاح','Win')}</th><th>${L('متوسط R','Avg R')}</th><th>${L('زيادة حد R:R','R:R raise')}</th></tr></thead><tbody>${rows}</tbody></table></div>
      <h4>${L('محجوب حاليًا','Blocked now')}</h4>${blocks.length?`<ul class="rc-learn-list">${blocks.map(b=>`<li><b>${esc(SNAME[b.strategy])}</b> · ${esc(fName(b.feature))}, ${b.n} ${L('صفقة','trades')}, ${L('نجاح','win')} ${Math.round(b.win*100)}%, ${fmtNum(b.mean,2)}R · ${L('بيرجع يتجرّب بعد','re-tested after')} ${esc(new Date(b.since+7*864e5).toLocaleDateString(en?'en-GB':'ar-EG-u-nu-latn'))}</li>`).join('')}</ul>`:`<p class="muted">${L('ولا شي لسا.','Nothing yet.')}</p>`}
      ${prob.length?`<h4>${L('بفترة تجربة','On probation')}</h4><ul class="rc-learn-list">${prob.map(b=>`<li><b>${esc(SNAME[b.strategy])}</b> · ${esc(fName(b.feature))}</li>`).join('')}</ul>`:''}
      <h4>${L('أكبر انحرافات بالأداء','Largest performance deviations')}</h4>${dev?`<ul class="rc-learn-list">${dev}</ul>`:`<p class="muted">${L('بيحتاج 3 نتائج على الأقل بنفس الظرف.','Needs at least 3 results in the same context.')}</p>`}
      <h4>${L('سجل التعديلات','Changes log')}</h4>${log?`<ul class="rc-learn-list">${log}</ul>`:`<p class="muted">${L('لسا ما صار في تعديل.','No change yet.')}</p>`}
      <button type="button" class="btn btn-sm btn-ghost" data-learn-reset>${L('مسح اللي تعلّمه','Reset what it learned')}</button>`;
  };
  el.addEventListener('click',ev=>{const b=ev.target.closest('[data-learn-reset]');if(!b)return;if(b.dataset.armed!=='1'){b.dataset.armed='1';b.textContent=L('متأكد؟ اكبس مرة تانية','Sure? Click again');return;}resetLearning();learnKey='';paintLearn();toast(L('انمسح','Reset'),'success',2000);});
  // Top market menu: a tab per market group ("توصيات كريبتو"…) and, inside it, a tab per market with its own name.
  const typeOf=sym=>(INSTRUMENTS.find(i=>i.symbol===sym)||{}).type;
  let marketsKey='';
  const paintMarkets=st=>{
    const open=st.signals.filter(x=>['active','pending'].includes(x.status));
    const nCat=c=>open.filter(x=>c==='all'||typeOf(x.symbol)===c).length, nSym=sym=>open.filter(x=>x.symbol===sym).length;
    const key=JSON.stringify([state.cat,state.symbol,open.map(x=>x.symbol),en]); if(key===marketsKey)return; marketsKey=key;
    const chip=(attr,val,label,n,on)=>`<button type="button" class="rc-mk${on?' is-on':''}" ${attr}="${esc(val)}" aria-pressed="${on}">${attr==='data-cat'?(CAT_ICONS[val]||''):''}${esc(label)}${n?`<em>${n}</em>`:''}</button>`;
    $('[data-cats]').innerHTML=chip('data-cat','all',L('كل التوصيات','All signals'),nCat('all'),state.cat==='all')+MARKET_GROUPS.map(g=>chip('data-cat',g.id,en?g.name[1]:g.name[0],nCat(g.id),state.cat===g.id)).join('');
    const sub=$('[data-subs]');
    if(state.cat==='all'){sub.hidden=true;sub.innerHTML='';centerOn();return;}
    sub.hidden=false;
    sub.innerHTML=chip('data-sym','all',L('الكل','All'),nCat(state.cat),state.symbol==='all')+INSTRUMENTS.filter(i=>i.type===state.cat).map(i=>chip('data-sym',i.symbol,marketName(i.symbol,en),nSym(i.symbol),state.symbol===i.symbol)).join('');
    centerOn();
  };
  // keep the chosen tab visible inside its scrolling row (never scrolls the page itself)
  const centerOn=()=>requestAnimationFrame(()=>el.querySelectorAll('.rc-mk-row').forEach(row=>{const on=row.querySelector('.is-on');if(!on||row.hidden)return;const r=row.getBoundingClientRect(),c=on.getBoundingClientRect();row.scrollLeft+=(c.left+c.width/2)-(r.left+r.width/2);}));
  const keepMarket=()=>{try{localStorage.setItem('ata:chan-market',JSON.stringify({cat:state.cat,symbol:state.symbol}))}catch{}};
  el.addEventListener('click',ev=>{
    const c=ev.target.closest('[data-cat]'); if(c){state.cat=c.dataset.cat;state.symbol='all';state.page=1;listKey='';keepMarket();render(signalState());return;}
    const m=ev.target.closest('[data-sym]'); if(m){state.symbol=m.dataset.sym;state.page=1;listKey='';keepMarket();render(signalState());}
  });
  // v230: subscription / allowance card — real numbers only (this month's recommendations, open now, closed), the real plan
  // and renewal when the server knows them, a usage meter only when there is a real monthly cap.
  const quotaCard=(a,st)=>{
    const now=new Date(), m0=new Date(now.getFullYear(),now.getMonth(),1).getTime();
    const live=s=>['active','pending'].includes(s.status);
    const month=st.signals.filter(s=>Number(s.createdAt)>=m0), open=st.signals.filter(live).length, closed=month.filter(s=>!live(s)).length;
    const planName=a.plan?(a.plan==='channel'?L('القناة المستقلة','Channel only'):t('pricing.plans.'+a.plan)):'';
    const capped=a.mode!=='open'&&Number.isFinite(a.total)&&a.total>0&&!a.owner;
    const pct=capped?Math.min(100,Math.round(a.used/a.total*100)):0;
    const day=ms=>new Date(ms).toLocaleDateString(en?'en-GB':'ar-EG-u-nu-latn',{day:'numeric',month:'long',year:'numeric'});
    const [cls,badge]=a.owner?['is-owner',L('حساب المالك','Owner account')]:a.subscribed?['is-on',L('اشتراك فعّال','Active subscription')]:a.mode==='open'?['is-open',L('القناة مفتوحة','Channel open')]:a.active?['is-on',L('اشتراك فعّال','Active subscription')]:['is-off',L('بدون اشتراك','No subscription')];
    const line=a.owner?L('وصول كامل لكل التوصيات والتفاصيل.','Full access to every recommendation and detail.')
      :a.mode==='open'?L('كل توصيات القناة متاحة لحسابك، بدون حد شهري.','Every channel recommendation is available to your account, with no monthly cap.')
      :a.active?L(`المتبقي ${a.remaining} من ${a.total} هالشهر.`,`${a.remaining} of ${a.total} left this month.`)
      :L('اشترك بالقناة لحالها أو ضمن باقة حتى توصلك التوصيات.','Subscribe to the channel alone or within a plan to receive recommendations.');
    const stat=(n,label,k)=>`<div class="rcq-stat ${k}"><dt>${label}</dt><dd>${n}</dd></div>`;
    // v232: one slim line at the top of the market menu — status + plan on one side, three counters in the corner
    const meterHtml=capped?`<div class="rcq-meter" role="meter" aria-valuemin="0" aria-valuemax="${a.total}" aria-valuenow="${a.used}" aria-label="${esc(L('الحصة المستخدمة','Allowance used'))}" title="${esc(`${a.used} / ${a.total}`)}"><i style="width:${pct}%"></i></div>`:'';
    const tip=[line, a.renewsAt?`${L('التجديد: ','Renews: ')}${day(a.renewsAt)}`:''].filter(Boolean).join(' · ');
    return `<div class="rcq ${cls}" title="${esc(tip)}">
      <div class="rcq-id"><span class="rcq-badge">${esc(badge)}</span>${planName?`<span class="rcq-plan">${esc(planName)}</span>`:''}${!a.active&&!a.owner?`<a class="rcq-cta" href="#/app/pricing">${L('الباقات','Plans')}</a>`:''}${capped&&a.active&&a.remaining===0?`<a class="rcq-cta" href="#/app/pricing">${L('زيد توصيات','Add more')}</a>`:''}${meterHtml}</div>
      <dl class="rcq-stats" aria-label="${esc(L('توصيات هالشهر','This month’s recommendations'))}"><span class="rcq-cap">${L('توصيات هالشهر','This month')}</span>${stat(month.length,`<span class="rcq-d">${L('الكل','All')}</span><span class="rcq-m">${L('هالشهر','Month')}</span>`,'k-month')}${stat(open,L('مفتوحة','Open'),'k-open')}${stat(closed,L('منتهية','Closed'),'k-closed')}</dl>
    </div>`;
  };
  const render=st=>{
    paintMarkets(st);
    const a=st.allowance||{mode:'open',active:true};   // v230: the local channel is open; real plan details arrive with the server feed
    const allowance=a?quotaCard(a,st):`<span class="rcq-wait">${L('جارٍ التحقق…','Checking…')}</span>`;
    if(allowance!==lastAllowance){$('[data-allowance]').innerHTML=allowance;lastAllowance=allowance;}
    const errors={signin_required:L('سجّل الدخول لعرض توصيات اشتراكك.','Sign in to view your recommendations.'),signin_invalid:L('انتهت جلسة الدخول؛ سجّل الدخول مجددًا.','Session expired; sign in again.'),auth_not_configured:L('تسجيل الدخول على السيرفر يحتاج إعدادًا قبل تفعيل القناة.','Server sign-in must be configured before enabling the channel.')};
    $('[data-service]').textContent=st.feedError?(errors[st.feedError]||L('تعذر تحديث القناة. تبقى آخر توصيات مستلمة ظاهرة.','Channel update unavailable. Last received recommendations remain visible.')):st.feedConfigured===false?L('عامل التوصيات غير متصل؛ لا توجد بيانات تجريبية معروضة.','Recommendation worker is unavailable; no demo signals are shown.'):L('القناة تعمل محليًا، توصيات حقيقية من السوق المباشر · تحديث كل ثانية','Channel runs locally, real signals from the live market · updates every second');
    if(!a&&st.feedError) $('[data-allowance]').textContent=L('الحصة غير متاحة حتى التحقق من الحساب.','Allowance unavailable until account verification.');
    $('[data-export]').hidden=!a?.owner;
    $('[data-owner]').hidden=!a?.owner;
    paintScan(st); paintLearn();
    $('[data-server-line]').textContent=st.server?L(`السيرفر 24/7 متصل · آخر مزامنة ${new Date(st.server.at).toLocaleTimeString('ar-EG-u-nu-latn')}, التوصيات بتنفحص حتى والموقع مسكّر.`,`24/7 server connected · last sync ${new Date(st.server.at).toLocaleTimeString('en-GB')}, markets are scanned even while the site is closed.`):L('الفحص شغّال من متصفحك. خلّي الصفحة مفتوحة حتى توصلك التوصيات أول بأول.','Scanning runs in your browser. Keep this page open to receive recommendations as they happen.');
    { const base=st.signals.filter(s=>(state.cat==='all'||typeOf(s.symbol)===state.cat)&&(state.symbol==='all'||s.symbol===state.symbol)&&(state.strategy==='all'||s.strategy===state.strategy)&&(state.order==='all'||(s.order||'market')===state.order));
      const open=x=>['active','pending'].includes(x.status), n={all:base.filter(open).length,pending:base.filter(x=>x.status==='pending').length,active:base.filter(x=>x.status==='active').length,closed:base.filter(x=>!open(x)).length};
      el.querySelectorAll('[data-count-status]').forEach(i=>{i.textContent=n[i.dataset.countStatus]||'0';}); }
    const filtered=st.signals.filter(s=>(state.cat==='all'||typeOf(s.symbol)===state.cat)&&(state.symbol==='all'||s.symbol===state.symbol)&&(state.strategy==='all'||s.strategy===state.strategy)&&(state.order==='all'||(s.order||'market')===state.order)&&(state.status==='all'?['active','pending'].includes(s.status):state.status==='closed'?!['active','pending'].includes(s.status):s.status===state.status));
    const pages=Math.max(1,Math.ceil(filtered.length/20)); state.page=Math.min(pages,state.page);
    const list=filtered.slice((state.page-1)*20,state.page*20), key=`${auth.current()?.email}|${a?.view}|${state.page}|${list.map(s=>`${s.id}:${s.status}:${s.hits}`).join(',')}`;
    if(key!==listKey){
      const open=new Set([...el.querySelectorAll('details[data-detail][open]')].map(d=>d.dataset.detail));listKey=key;
      $('[data-list]').innerHTML=list.length?list.map(s=>`<article class="rc-recommendation">${signalCardHtml(s,{animated:false})}${mt5Btn(s)}${detail(s)}</article>`).join(''):`<div class="card rc-empty">${L('لا توجد توصيات مطابقة حاليًا. تظهر الفرص عند اكتمال الشروط وحسب حصتك.','No matching recommendations. Setups appear when conditions and your allowance permit.')}</div>`;
      el.querySelectorAll('[data-detail]').forEach(d=>{const s=list.find(x=>x.id===d.dataset.detail);d.addEventListener('toggle',()=>{if(d.open)draw(d,s);});if(open.has(s.id)){d.open=true;draw(d,s);}});
    }
    paintLive(el,list);
    $('[data-count]').textContent=`${filtered.length} ${L('توصية','recommendations')} · ${state.page} / ${pages}`;
    $('[data-prev]').disabled=state.page<=1;$('[data-next]').disabled=state.page>=pages;
    $('[data-notify-t]').textContent=notifyPermission()==='granted'?L('التنبيهات مفعّلة','Notifications enabled'):L('تفعيل التنبيهات','Enable notifications');
  };
  el.querySelectorAll('[data-filter]').forEach(n=>n.addEventListener('change',()=>{state[n.dataset.filter]=n.value;state.page=1;listKey='';render(signalState());}));
  el.querySelectorAll('[data-order]').forEach(n=>n.addEventListener('click',()=>{state.order=n.dataset.order;state.page=1;listKey='';el.querySelectorAll('[data-order]').forEach(x=>x.setAttribute('aria-pressed',String(x===n)));render(signalState());}));
  el.querySelectorAll('[data-status]').forEach(n=>n.addEventListener('click',()=>{state.status=n.dataset.status;state.page=1;listKey='';el.querySelectorAll('[data-status]').forEach(x=>x.setAttribute('aria-pressed',String(x===n)));render(signalState());}));
  $('[data-notify]').addEventListener('click',async()=>{const p=await enableNotifications();$('[data-service]').textContent=p==='granted'?L('تم تفعيل تنبيهات هذا الجهاز.','Device notifications enabled.'):L('لم يُسمح بالتنبيهات؛ راجع إعدادات المتصفح.','Notifications not allowed; check browser settings.');});
  $('[data-grant]').addEventListener('submit',async event=>{
    event.preventDefault();const form=event.currentTarget,out=$('[data-grant-result]'),btn=form.querySelector('button');btn.disabled=true;
    const f=new FormData(form),payload={uid:String(f.get('uid')).trim(),product:f.get('product'),paymentId:String(f.get('paymentId')).trim(),replace:f.get('replace')==='on'};
    if(f.get('startsAt'))payload.startsAt=+new Date(f.get('startsAt'));if(f.get('until'))payload.until=+new Date(f.get('until'));
    try{const r=await apiRequest('POST','/api/channel/grant',payload);out.textContent=r.duplicate?L('مرجع الدفع مستخدم سابقًا؛ لم تتغيّر الحصة.','Payment reference already used; allowance unchanged.'):L('تم تسجيل الاشتراك أو الإضافة. يظهر للمشترك عند تحديث القناة.','Subscription or top-up recorded. It appears when the subscriber feed refreshes.');}
    catch(e){const messages={invalid_dates:L('أدخل بداية ونهاية صالحتين للاشتراك.','Enter valid subscription start and end dates.'),active_subscription_required:L('الإضافة تحتاج اشتراكًا فعّالًا.','Top-ups require an active subscription.'),explicit_replacement_required:L('فعّل خيار الاستبدال لتغيير نوع الاشتراك الحالي.','Select replacement to change the existing subscription type.')};out.textContent=messages[e.code]||L('تعذر التفعيل. تحقق من الحساب ومرجع الدفع وصلاحيات المالك.','Activation failed. Check account, payment reference and owner permissions.');}
    finally{btn.disabled=false;}
  });
  for(const [sel,delta] of [['[data-prev]',-1],['[data-next]',1]])$(sel).addEventListener('click',()=>{state.page+=delta;render(signalState());});
  $('[data-export]').addEventListener('click',()=>{const out={};for(const k of ['settings','risk','plan','chan-pref','lang']){try{const v=localStorage.getItem('ata:'+k);if(v!==null)out[k]=JSON.parse(v);}catch{}}
    const url=URL.createObjectURL(new Blob([JSON.stringify(out,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='worker-config.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),4000);});
  render(signalState());const off=onSignals(st=>{if(!el.isConnected){if(!disposed){off();disposed=true;}return;}render(st);});
  return el;
}
export { describe };
