// Gotriva Elite Signals page (v247): the multi-market signal engine of the section — indices, precious metals, commodities and
// Bitcoin, scanned with every AI recommendation strategy independently. Filters (market type, strategy, timeframe, buy/sell),
// active signals and history, live prices, status of every signal, the strategy and its reasons, market availability.
// Data: services/eliteFeed.js (server feed, or this device's scanner when no server). All text through esc().
import { h, esc, fmtNum } from '../utils/dom.js';
import { getLang, getLocale } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { signalCardHtml, paintLive } from '../components/signalCard.js';
import { enableNotifications, notifyPermission } from '../services/signals.js';
import { eliteState, onElite, refreshElite } from '../services/eliteFeed.js';
import { cardStatus, LIVE_STATUSES, ELITE_STRATEGIES, ELITE_TFS } from '../services/eliteEngine.js';
import { ELITE_MARKETS } from '../config/eliteMarkets.js';
import { STRATEGIES } from '../config/aiSignalRules.js';
import { getTickers } from '../services/market/index.js';
import { applySignal, wasApplied, oneClickLot } from '../services/mt5Apply.js';
import { toast } from '../components/ui.js';
import '../styles/recommendations.css';
import '../styles/mt5btn.css';
import '../styles/elite.css';

const L = (ar, en) => tx({ ar, en });
const ENTERED = ['entry_hit', 'tp1', 'tp2'];
const CATS = () => [['all', L('الكل', 'All')], ['index', L('مؤشرات', 'Indices')], ['metal', L('معادن', 'Metals')], ['commodity', L('سلع', 'Commodities')], ['bitcoin', L('بيتكوين', 'Bitcoin')]];
const SNAME = (id) => { const d = STRATEGIES.find((s) => s.id === id); return d ? L(d.name.ar, d.name.en) : id; };
const TFN = (tf) => ({ '15m': L('15 دقيقة', '15m'), '1h': L('ساعة', '1H'), '4h': L('4 ساعات', '4H') })[tf] || tf;
const STATUS = () => ({
  active: ['ACTIVE', L('بانتظار الدخول', 'Waiting for entry')], entry_hit: ['ENTRY HIT', L('تم الدخول', 'Entered')],
  tp1: ['TP1 HIT', L('وصل الهدف 1', 'Target 1 reached')], tp2: ['TP2 HIT', L('وصل الهدف 2', 'Target 2 reached')], tp3: ['TP3 HIT', L('وصل الهدف 3', 'Target 3 reached')],
  sl: ['STOP LOSS HIT', L('ضرب الوقف', 'Stopped out')], expired: ['EXPIRED', L('انتهت الصلاحية', 'Expired')], cancelled: ['CANCELLED', L('ألغيت قبل الدخول', 'Cancelled before entry')],
});
const WHY_CLOSED = () => ({ stop_at_entry: L('الوقف كان على الدخول بعد الهدف 1', 'stop was at entry after TP1'), tp1_before_entry: L('السعر وصل الهدف 1 قبل الدخول', 'price reached TP1 before the entry'), invalidated: L('السعر كسر الوقف قبل الدخول', 'price broke the stop before the entry'), not_filled: L('ما وصل السعر للدخول', 'the entry was not reached'), max_hold: L('خلصت مدة الصفقة', 'maximum holding time reached') });
const UNAV = () => ({ not_tradable: L('مؤشر حسابي، مش أداة تداول عند المزوّدين الحاليين', 'a calculated index, not a tradable instrument at the current providers'), no_instrument: L('ما في أداة حقيقية إله بالمنصة', 'no real instrument on the platform'), demo_data: L('ما في أسعار حية هلق', 'no live prices right now'), no_data: L('ما في بيانات', 'no data'), stale_data: L('البيانات متأخرة', 'data delayed'), market_closed: L('السوق مسكّر', 'market closed'), few_candles: L('شموع غير كافية', 'not enough candles'), bad_data: L('بيانات تالفة', 'corrupt data') });
const clock = (ms) => new Date(ms).toLocaleString(getLocale(), { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' });
const iso = (v) => `⁦${v}⁩`;

export function renderElite() {
  const el = h(`<section class="subpage elite rc-page page-enter">
    <header class="el-hero">
      <picture class="el-logo" style="--el-mask:url(/elite/elite-logo.webp)"><img src="/elite/elite-logo.webp" width="671" height="448" alt="Gotriva Elite Signals" decoding="async" fetchpriority="high"/><span class="el-sparks" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i></span></picture>
      <div class="el-hero-txt">
        <span class="el-live" data-live-dot><i></i><span data-mode>${esc(L('بث مباشر', 'Live'))}</span></span>
        <h1>Gotriva Elite Signals</h1>
        <p>${esc(L('ماسح مباشر لأقوى المؤشرات والمعادن الثمينة والسلع الرئيسية والبيتكوين: كل استراتيجية من استراتيجيات توصية AI بتشتغل لحالها، وأول ما تحقق كل شروطها بتطلع إشارتها فوراً.', 'A live scanner of the strongest indices, precious metals, major commodities and Bitcoin: every AI recommendation strategy runs on its own, and the moment one meets all of its conditions its signal is published.'))}</p>
        <div class="el-actions"><button type="button" class="btn el-btn-gold" data-notify></button></div>
      </div>
    </header>
    <section class="el-scan" data-scan aria-live="polite"></section>
    <section class="el-stats" data-stats></section>
    <div class="el-filters" data-filters>
      <div class="el-cats" role="group" aria-label="${esc(L('نوع السوق', 'Market type'))}">${CATS().map(([k, n]) => `<button type="button" class="btn btn-sm" data-cat="${k}" aria-pressed="${k === 'all'}">${esc(n)}</button>`).join('')}</div>
      <div class="el-sel">
        <select class="input" data-f="strategy" aria-label="${esc(L('الاستراتيجية', 'Strategy'))}"><option value="">${esc(L('كل الاستراتيجيات', 'All strategies'))}</option>${ELITE_STRATEGIES.map((id) => `<option value="${id}">${esc(SNAME(id))}</option>`).join('')}</select>
        <select class="input" data-f="tf" aria-label="${esc(L('الفريم', 'Timeframe'))}"><option value="">${esc(L('كل الفريمات', 'All timeframes'))}</option>${ELITE_TFS.map((tf) => `<option value="${tf}">${esc(TFN(tf))}</option>`).join('')}</select>
        <select class="input" data-f="dir" aria-label="${esc(L('الاتجاه', 'Direction'))}"><option value="">${esc(L('شراء وبيع', 'Buy & sell'))}</option><option value="long">${esc(L('شراء', 'Buy'))}</option><option value="short">${esc(L('بيع', 'Sell'))}</option></select>
      </div>
    </div>
    <div class="rc-tabs el-tabs" role="tablist"><button type="button" class="btn btn-sm" data-tab="open" aria-pressed="true">${esc(L('الإشارات النشطة', 'Active signals'))}</button><button type="button" class="btn btn-sm" data-tab="closed" aria-pressed="false">${esc(L('السجل', 'History'))}</button></div>
    <div class="rc-list el-list" data-list></div>
    <details class="el-markets" data-markets><summary></summary><div class="el-mk-grid" data-mk></div></details>
    <p class="el-foot muted">${esc(L('كل إشارة من استراتيجية وحدة حققت كل شروطها الإلزامية على بيانات حية، بدون تصويت بين الاستراتيجيات. الدخول ماركت لما الشروط متحققة على السعر الحالي، وليميت بس لما الاستراتيجية بدها رجوع لمستوى قريب. ما في ضمان ربح؛ التزم بوقف الخسارة وحجم صفقة مناسب.', 'Each signal comes from one strategy that met all of its mandatory conditions on live data — no vote between strategies. Market entry when the conditions hold at the current price; limit only when the strategy needs a pullback to a nearby level. No profit is guaranteed; always use the stop and a sensible size.'))}</p>
  </section>`);
  const $ = (s) => el.querySelector(s);
  const f = { cat: 'all', strategy: '', tf: '', dir: '' };
  let tab = 'open'; let listKey = ''; let mkKey = ''; const prices = new Map();

  const notifyBtn = () => {
    const p = notifyPermission(); const b = $('[data-notify]');
    b.disabled = p === 'granted' || p === 'unsupported';
    b.textContent = p === 'granted' ? L('التنبيهات الفورية مفعّلة ✓', 'Instant alerts on ✓') : p === 'unsupported' ? L('التنبيهات مش مدعومة بهالمتصفح', 'Alerts not supported in this browser') : p === 'denied' ? L('التنبيهات محظورة بالمتصفح', 'Alerts blocked in the browser') : L('فعّل التنبيهات الفورية', 'Enable instant alerts');
  };
  $('[data-notify]').addEventListener('click', async () => { await enableNotifications(); notifyBtn(); });
  notifyBtn();

  const paintScan = (st) => {
    const ms = st.markets || []; const live = ms.filter((m) => m.state === 'live').length; const un = ms.filter((m) => m.state === 'unavailable').length;
    const box = $('[data-scan]');
    if (st.mode === 'starting') { box.innerHTML = `<div class="el-scan-row"><span class="el-spin" aria-hidden="true"></span><b>${esc(L('عم نجهّز الماسح…', 'Preparing the scanner…'))}</b></div>`; return; }
    const err = st.error ? `<span class="el-err">${esc(L('تعذّر تحديث البث — بنعيد المحاولة تلقائياً.', 'Could not refresh the feed — retrying automatically.'))}</span>` : '';
    box.innerHTML = `<div class="el-scan-row"><span class="el-scan-dot ${live ? 'on' : ''}" aria-hidden="true"></span><b>${esc(L(`الماسح شغّال على ${live} سوق`, `Scanning ${live} markets`))}</b>
      <span>${esc(L(`${ms.length} سوق بالقسم · ${un} غير متاح`, `${ms.length} markets in the section · ${un} unavailable`))}</span>
      <span>${esc(L('فريمات', 'Timeframes'))} ${esc(ELITE_TFS.map(TFN).join(' · '))}</span>
      ${st.lastScan ? `<time>${esc(L('آخر فحص', 'Last scan'))} ${esc(new Date(st.lastScan).toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit' }))}</time>` : ''}${err}</div>`;
    $('[data-mode]').textContent = st.mode === 'server' ? L('بث مباشر · السيرفر 24/7', 'Live · 24/7 server') : st.mode === 'local' ? L('بث مباشر · من جهازك', 'Live · on this device') : L('بث مباشر', 'Live');
  };
  const paintStats = (st) => {
    const s = st.summary || {}; const stat = (n, label, cls = '') => `<div class="el-stat ${cls}"><b>${esc(n)}</b><span>${esc(label)}</span></div>`;
    $('[data-stats]').innerHTML = stat(fmtNum(s.total || 0, 0), L('إشارات آخر 7 أيام', 'Signals, last 7 days')) + stat(fmtNum(s.open || 0, 0), L('نشطة هلّق', 'Active now'), 'k-open')
      + stat(fmtNum(s.closed || 0, 0), L('منتهية', 'Closed')) + stat(s.tp1Rate == null ? '—' : `${s.tp1Rate}%`, L('من اللي دخلت وصلت هدف 1', 'Of entered: reached TP1'), 'k-win');
  };
  const paintMarkets = (st) => {
    const ms = st.markets || []; const k = ms.map((m) => `${m.id}${m.state}${m.reason}`).join() + getLang(); if (k === mkKey) return; mkKey = k;
    const U = UNAV(); const name = (m) => { const n = ELITE_MARKETS.find((x) => x.id === m.id)?.names || []; return n.find((x) => /[a-z ]/.test(x)) || n[1] || m.id; };
    $('[data-markets] summary').textContent = L(`الأسواق (${ms.filter((m) => m.state !== 'unavailable').length} متاح · ${ms.filter((m) => m.state === 'unavailable').length} غير متاح)`, `Markets (${ms.filter((m) => m.state !== 'unavailable').length} available · ${ms.filter((m) => m.state === 'unavailable').length} unavailable)`);
    $('[data-mk]').innerHTML = CATS().slice(1).map(([c, n]) => `<div class="el-mk-col"><b>${esc(n)}</b>${ms.filter((m) => m.cat === c).map((m) => `<span class="el-mk is-${esc(m.state)}" title="${esc(m.reason ? U[m.reason] || m.reason : '')}"><i aria-hidden="true"></i>${esc(m.id)} <small>${esc(name(m))}</small>${m.state === 'unavailable' || ['stale', 'closed'].includes(m.state) ? ` <em>${esc(U[m.reason] || m.reason || '')}</em>` : ''}</span>`).join('')}</div>`).join('');
  };
  const filtered = (st) => (st.signals || []).filter((s) => (tab === 'open' ? LIVE_STATUSES.includes(s.status) : !LIVE_STATUSES.includes(s.status))
    && (f.cat === 'all' || s.category === f.cat) && (!f.strategy || s.strategy === f.strategy) && (!f.tf || s.tf === f.tf) && (!f.dir || s.direction === f.dir));
  const meta = (s) => {
    const S = STATUS()[s.status] || [s.status, '']; const W = WHY_CLOSED();
    const rr = Array.isArray(s.rrNet) ? s.rrNet.map((x) => `1:${fmtNum(x, 2)}`).join(' / ') : '';
    const reasons = (s.reasons || []).map((r) => `<li>${esc(L(r.ar, r.en))}${r.value ? ` <small>${esc(r.value)}</small>` : ''}</li>`).join('');
    return `<div class="el-meta">
      <span class="el-st is-${esc(s.status)}" title="${esc(S[1])}">${esc(S[0])}</span>
      <span class="el-tag">${esc(SNAME(s.strategy))}</span>
      <span>${esc(TFN(s.tf))} · <b class="el-et is-${esc(s.entryType)}">${esc(s.entryType === 'limit' ? 'LIMIT' : 'MARKET')}</b></span>
      ${rr ? `<span dir="ltr">R:R ${esc(rr)}</span>` : ''}
      ${s.conflict ? `<span class="el-conflict">${esc(L('تعارض: استراتيجية تانية عكس الاتجاه على نفس السوق', 'Conflict: another strategy points the other way on this market'))}</span>` : ''}
      <time>${esc(clock(s.createdAt))}</time>
    </div>
    <div class="el-meta el-meta2"><span>${esc(S[1])}${s.closeReason && W[s.closeReason] ? ` · ${esc(W[s.closeReason])}` : ''}</span>
      ${s.expiresAt && LIVE_STATUSES.includes(s.status) ? `<span>${esc(s.status === 'active' ? L('صالح لحد', 'Valid until') : L('أقصى مدة لحد', 'Held until'))} ${esc(clock(s.expiresAt))}</span>` : ''}
      ${s.entryType === 'limit' && s.dist?.atr != null ? `<span>${esc(L('بعد الدخول عن السعر وقت الإشارة', 'Entry distance at signal time'))} ${iso(`${fmtNum(s.dist.atr, 2)} ATR · ${fmtNum(s.dist.pct, 2)}%`)}</span>` : ''}</div>
    <details class="el-why"><summary>${esc(L('ليش طلعت الإشارة', 'Why this signal'))}</summary><p>${esc(L(s.explanation?.ar || '', s.explanation?.en || ''))}</p>${reasons ? `<ul>${reasons}</ul>` : ''}<small class="muted">${esc(s.source ? L(`البيانات: ${s.source}`, `Data: ${s.source}`) : '')} · ${esc(s.engine || '')}</small></details>`;
  };
  const mt5 = (s) => {
    if (s.status !== 'entry_hit') return '';
    if (wasApplied(s.id)) return `<div class="rc-mt5"><span class="mt5-go is-done" role="status">${esc(L('انطبقت على MT5', 'Applied on MT5'))}</span></div>`;
    return `<div class="rc-mt5"><button type="button" class="mt5-go" data-mt5="${esc(s.id)}"><span class="mt5-go-bolt" aria-hidden="true">⚡</span><span class="mt5-go-txt">${esc(L('تطبيق على MT5', 'Apply on MT5'))}</span><span class="mt5-go-lot">· ${esc(fmtNum(oneClickLot(), 2))}</span></button></div>`;
  };
  const view = (s) => ({ ...s, status: cardStatus(s.status), price: prices.get(s.symbol)?.price ?? s.price, priceAt: prices.get(s.symbol)?.at ?? s.priceAt });
  const paintList = (st) => {
    const list = filtered(st);
    const k = tab + JSON.stringify(f) + list.map((p) => `${p.id}${p.status}${p.hits}${p.conflict}`).join() + getLang() + st.mode;
    if (k !== listKey) {
      listKey = k;
      const empty = st.mode === 'starting' ? L('عم نجيب الإشارات…', 'Loading signals…')
        : tab === 'open' ? L('ما في إشارة نشطة بهالفلتر هلّق. الماسح شغّال، وأول ما تحقق استراتيجية كل شروطها على أي سوق، الإشارة بتطلع هون فوراً.', 'No active signal for this filter right now. The scanner is running; the moment a strategy meets all of its conditions on any market, the signal appears here.')
        : L('ما في إشارات منتهية آخر 7 أيام بهالفلتر.', 'No closed signals in the last 7 days for this filter.');
      $('[data-list]').innerHTML = list.length ? list.map((s) => `<article class="rc-recommendation el-card${s.conflict ? ' is-conflict' : ''}">${signalCardHtml(view(s), { animated: false, brand: 'elite' })}${meta(s)}${mt5(s)}</article>`).join('')
        : `<div class="card rc-empty el-empty"><img src="/elite/elite-icon.svg" width="44" height="44" alt=""/><p>${esc(empty)}</p></div>`;
    }
    paintLive(el, list.map(view));
  };
  const render = (st) => { paintScan(st); paintStats(st); paintList(st); paintMarkets(st); };

  el.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.tab; el.querySelectorAll('[data-tab]').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); listKey = ''; render(eliteState()); }));
  el.querySelectorAll('[data-cat]').forEach((b) => b.addEventListener('click', () => { f.cat = b.dataset.cat; el.querySelectorAll('[data-cat]').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); listKey = ''; render(eliteState()); }));
  el.querySelectorAll('[data-f]').forEach((s) => s.addEventListener('change', () => { f[s.dataset.f] = s.value; listKey = ''; render(eliteState()); }));
  el.addEventListener('click', async (ev) => {
    const b = ev.target.closest('[data-mt5]'); if (!b || b.disabled) return;
    const p = eliteState().signals.find((x) => x.id === b.dataset.mt5); if (!p) return;
    b.disabled = true; const txt = b.querySelector('.mt5-go-txt'); const label = txt.textContent; txt.textContent = L('عم يتبعت…', 'Sending…');
    try { const r = await applySignal({ ...p, status: 'active' }); toast(L(`انبعتت لـ MT5 ${r.link.account}.`, `Sent to MT5 ${r.link.account}.`), 'success', 5000); listKey = ''; render(eliteState()); }
    catch (e) { b.disabled = false; txt.textContent = label; toast(L('ما انطبقت: ', 'Not applied: ') + (e.code || 'error'), 'error', 6000); }
  });
  // live prices of the markets with an active signal (every 2 s while the page is open)
  let pBusy = false;
  const pull = async () => {
    if (pBusy || document.hidden) return; pBusy = true;
    try {
      const syms = [...new Set((eliteState().signals || []).filter((s) => LIVE_STATUSES.includes(s.status)).map((s) => s.symbol))];
      if (syms.length) { const t = await getTickers(syms); for (const sym of syms) { const q = t?.[sym]; if (q && q.mode === 'live' && Number.isFinite(q.price)) prices.set(sym, { price: q.price, at: Number.isFinite(q.at) ? q.at : Date.now() }); } paintList(eliteState()); }
    } catch { /* the card then shows the last received price */ } finally { pBusy = false; }
  };
  const tick = setInterval(() => { if (!el.isConnected) { clearInterval(tick); off(); return; } pull(); }, 2000);
  const off = onElite((st) => { if (el.isConnected) render(st); });
  render(eliteState()); pull();
  if (eliteState().mode !== 'starting') refreshElite();
  return el;
}
