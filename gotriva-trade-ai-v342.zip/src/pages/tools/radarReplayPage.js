// Gotriva Market Replay (v233): real history around a date, replayed bar by bar with the radar's reading at each moment —
// computed only from candles up to that moment (no look-ahead). Light canvas chart (no library), redrawn per frame only.
import { esc, fmtNum } from '../../utils/dom.js';
import { getInstrument } from '../../config/instruments.js';
import { getLocale } from '../../i18n/index.js';
import { storage } from '../../utils/storage.js';
import { store } from '../../state/store.js';
import { loadReplay, createReplay, WARMUP } from '../../services/radarReplay.js';
import { ema } from '../../indicators/index.js';
import { L, marketSelect, tfSeg, STATUS, TF_NAME } from './radarText.js';
import { onUnmount } from './common.js';

const SPEEDS = [1, 2, 4, 8, 16];
export function mountReplay(el, body) {
  const st = { symbol: store.get('symbol') || 'BTCUSDT', tf: '15m', date: '', ...(storage.get('radar-replay', {}) || {}) };
  if (!getInstrument(st.symbol)) st.symbol = 'BTCUSDT';
  const defDate = new Date(Date.now() - 3 * 86_400_000); defDate.setMinutes(0, 0, 0);
  const local = (d) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  body.innerHTML = `<div class="card rp-controls">${marketSelect('m', st.symbol)}${tfSeg('tf', st.tf)}
      <label class="rp-date"><span>${esc(L('التاريخ', 'Date'))}</span><input type="datetime-local" class="input" data-date value="${esc(st.date || local(defDate))}" max="${esc(local(new Date()))}"/></label>
      <button type="button" class="btn btn-primary btn-sm" data-load>${esc(L('حمّل', 'Load'))}</button></div>
    <div data-stage><div class="card sig-empty"><span>${esc(L('اختار سوق وفريم وتاريخ، واكبس «حمّل».', 'Pick a market, a timeframe and a date, then press “Load”.'))}</span></div></div>
    <p class="muted tool-note">${esc(L('كل قراءة محسوبة بس من الشموع اللي قبل اللحظة المعروضة، ولا شمعة من المستقبل. القراءة هي قلب الرادار (EMA 50/200، RSI، MACD، الهيكل وسحب السيولة) والخطة ATR (وقف 1.5× ATR، أهداف 1/2/3 R)؛ الباك تست الكامل تبع الرادار الحي ما بينعاد كل شمعة.', 'Every reading uses only the candles before the moment shown, never a future candle. The reading is the radar core (EMA 50/200, RSI, MACD, structure and sweeps) with an ATR plan (stop 1.5× ATR, targets 1/2/3 R); the live radar’s full back-test is not re-run per candle.'))}</p>`;
  const $ = (s) => body.querySelector(s);
  const keep = () => storage.set('radar-replay', { symbol: st.symbol, tf: st.tf, date: $('[data-date]').value });
  $('[data-m]').addEventListener('change', (e) => { st.symbol = e.target.value; keep(); });
  $('[data-tf]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; st.tf = b.dataset.v; keep(); $('[data-tf]').querySelectorAll('button').forEach((x) => { x.classList.toggle('is-on', x === b); x.setAttribute('aria-pressed', String(x === b)); }); });
  $('[data-date]').addEventListener('change', keep);

  let R = null; let cur = 0; let playing = false; let speed = 2; let raf = 0; let lastT = 0; let acc = 0; let ema50 = [], ema200 = [];
  const stop = () => { playing = false; cancelAnimationFrame(raf); const b = body.querySelector('[data-play]'); if (b) b.textContent = '▶'; };
  onUnmount(el, stop);

  $('[data-load]').addEventListener('click', async () => {
    stop(); keep(); const btn = $('[data-load]'); btn.disabled = true;
    $('[data-stage]').innerHTML = `<div class="perf-loading"><span class="spinner"></span><span>${esc(L('عم يحمّل التاريخ…', 'Loading history…'))}</span></div>`;
    try {
      const at = new Date($('[data-date]').value).getTime();
      const d = await loadReplay(st.symbol, st.tf, at);
      const inst = getInstrument(st.symbol);
      R = createReplay(d.candles, { tf: st.tf, symbol: st.symbol, precision: inst.precision }); cur = Math.max(WARMUP, d.startIndex);
      const closes = d.candles.map((c) => c.close); ema50 = ema(closes, 50); ema200 = ema(closes, 200);
      stage(d.source);
    } catch (e) {
      const m = { future: L('اختار تاريخ بالماضي.', 'Pick a date in the past.'), noLive: L('ما في بيانات حيّة لهالسوق هلّق.', 'No live data for this market right now.'), empty: L('ما رجعت بيانات لهالفترة.', 'No data came back for this period.'),
        outOfRange: e.from ? L(`التاريخ برّا المتاح لهالسوق على هالفريم. المتاح من ${new Date(e.from).toLocaleString(getLocale())} لـ ${new Date(e.to).toLocaleString(getLocale())}.`, `This date is outside the history available for this market and timeframe: ${new Date(e.from).toLocaleString(getLocale())} – ${new Date(e.to).toLocaleString(getLocale())}.`) : L('التاريخ برّا المتاح.', 'Date out of range.') }[e.code]
        || L('ما قدرنا نحمّل التاريخ من مصدر البيانات.', 'Could not load history from the data source.');
      $('[data-stage]').innerHTML = `<div class="card sig-empty"><span>${esc(m)}</span></div>`;
    } finally { btn.disabled = false; }
  });

  function stage(source) {
    $('[data-stage]').innerHTML = `<section class="card rp-replay">
      <canvas class="rp-canvas" data-cv aria-label="${esc(L('شارت الإعادة', 'Replay chart'))}"></canvas>
      <div class="rp-bar">
        <button type="button" class="btn btn-sm" data-back aria-label="${esc(L('شمعة لورا', 'One candle back'))}">⏮</button>
        <button type="button" class="btn btn-sm btn-primary" data-play aria-label="${esc(L('تشغيل / إيقاف', 'Play / pause'))}">▶</button>
        <button type="button" class="btn btn-sm" data-fwd aria-label="${esc(L('شمعة لقدّام', 'One candle forward'))}">⏭</button>
        <div class="seg" data-speed>${SPEEDS.map((s) => `<button type="button" data-s="${s}" class="${s === speed ? 'is-on' : ''}">${s}×</button>`).join('')}</div>
        <input type="range" class="rp-range" data-range min="${WARMUP}" max="${R.length - 1}" value="${cur}" aria-label="${esc(L('الوقت', 'Time'))}"/>
      </div>
      <div class="rp-read" data-read></div>
      <details class="rp-more-in"><summary>${esc(L('إشارات وصفقات لحد هاللحظة', 'Signals and trades up to this moment'))}</summary><div data-hist></div></details>
      <p class="muted rp-small">${esc(source)} · ${esc(TF_NAME()[st.tf])} · ${R.length} ${esc(L('شمعة حقيقية', 'real candles'))}</p></section>`;
    const s = (x) => body.querySelector(x);
    s('[data-play]').addEventListener('click', () => { if (playing) stop(); else { playing = true; s('[data-play]').textContent = '⏸'; lastT = performance.now(); acc = 0; raf = requestAnimationFrame(loop); } });
    s('[data-back]').addEventListener('click', () => { stop(); go(cur - 1); });
    s('[data-fwd]').addEventListener('click', () => { stop(); go(cur + 1); });
    s('[data-range]').addEventListener('input', (e) => { stop(); go(Number(e.target.value)); });
    s('[data-speed]').addEventListener('click', (e) => { const b = e.target.closest('[data-s]'); if (!b) return; speed = Number(b.dataset.s); s('[data-speed]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b)); });
    new ResizeObserver(() => draw()).observe(s('[data-cv]'));
    go(cur);
  }
  function loop(t) {
    if (!playing || !el.isConnected) return;
    acc += ((t - lastT) / 1000) * speed * 2; lastT = t;      // 2 candles / second at 1×
    if (acc >= 1) { const n = Math.floor(acc); acc -= n; if (cur + n >= R.length - 1) { go(R.length - 1); stop(); return; } go(cur + n); }
    raf = requestAnimationFrame(loop);
  }
  function go(i) {
    cur = Math.max(WARMUP, Math.min(R.length - 1, i));
    const r = body.querySelector('[data-range]'); if (r && Number(r.value) !== cur) r.value = String(cur);
    draw(); info();
  }
  function info() {
    const inst = getInstrument(st.symbol); const p = (v) => fmtNum(v, inst.precision); const c = R.candles[cur]; const rd = R.reading(cur); const S = R.state(cur);
    const dir = rd?.dir === 'long' ? L('إشارة شراء', 'Buy signal') : rd?.dir === 'short' ? L('إشارة بيع', 'Sell signal') : L('ما في إشارة', 'No signal');
    body.querySelector('[data-read]').innerHTML = `<span class="mono">${esc(new Date(c.time * 1000).toLocaleString(getLocale(), { dateStyle: 'medium', timeStyle: 'short' }))}</span><b class="mono">${esc(p(c.close))}</b>
      <span class="rp-bias is-${rd?.bias > 0.2 ? 'bull' : rd?.bias < -0.2 ? 'bear' : 'neutral'}">${esc(L('الميل', 'Bias'))} ${rd?.bias == null ? '—' : fmtNum(rd.bias * 100, 0)}</span><span>${esc(dir)}</span>
      ${rd?.event ? `<span>${esc(rd.event.kind)} ${rd.event.dir === 'bull' ? '↑' : '↓'}</span>` : ''}${rd?.sweep ? `<span class="rp-sw">${esc(rd.sweep.side === 'buy' ? L('سحب BSL', 'BSL sweep') : L('سحب SSL', 'SSL sweep'))}</span>` : ''}
      ${S.open ? `<span class="rp-open">${esc(L('صفقة مفتوحة', 'Open trade'))} · ${esc(STATUS()[S.open.status])}</span>` : ''}`;
    const done = S.trades; const w = done.filter((t) => t.r > 0).length; const sum = done.reduce((s, t) => s + t.r, 0);
    body.querySelector('[data-hist]').innerHTML = done.length ? `<p class="rp-small">${esc(L(`${done.length} صفقة · ${w} رابحة · مجموع ${fmtNum(sum, 2)}R (إعادة تاريخية، مش نتائج حيّة)`, `${done.length} trades · ${w} winners · total ${fmtNum(sum, 2)}R (historical replay, not live results)`))}</p>
      <ul class="rp-ev">${done.slice(-12).reverse().map((t) => `<li><b>${esc(t.direction === 'long' ? L('شراء', 'Buy') : L('بيع', 'Sell'))}</b> <span class="mono">${esc(p(t.entry))}</span> → ${esc(STATUS()[t.status])} <b class="${t.r >= 0 ? 'up-ish' : 'down-ish'}">${t.r > 0 ? '+' : ''}${fmtNum(t.r, 2)}R</b> <small class="muted">${esc(new Date(t.detectedAt).toLocaleString(getLocale(), { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }))}</small></li>`).join('')}</ul>`
      : `<p class="muted rp-small">${esc(L('لسا ما في صفقات لحد هاللحظة.', 'No trades up to this moment yet.'))}</p>`;
  }
  function draw() {
    const cv = body.querySelector('[data-cv]'); if (!cv || !R) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1); const w = cv.clientWidth || 600; const h = cv.clientHeight || 320;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h);
    const n = Math.max(30, Math.min(120, Math.floor(w / 7))); const from = Math.max(0, cur - n + 1); const bars = R.candles.slice(from, cur + 1);   // nothing after the cursor is drawn
    const S = R.state(cur); const lv = S.open ? [S.open.entry, S.open.stop, ...S.open.targets] : [];
    let hi = Math.max(...bars.map((c) => c.high), ...lv), lo = Math.min(...bars.map((c) => c.low), ...lv); const pad = (hi - lo) * 0.06; hi += pad; lo -= pad;
    const right = 64; const bw = (w - right) / n; const y = (v) => ((hi - v) / (hi - lo || 1)) * (h - 20) + 10;
    const css = getComputedStyle(cv); const up = css.getPropertyValue('--rp-up').trim() || '#22c55e', dn = css.getPropertyValue('--rp-dn').trim() || '#ef4444', grid = css.getPropertyValue('--rp-grid').trim() || 'rgba(148,163,184,.12)', txt = css.getPropertyValue('--rp-txt').trim() || '#9a97b3';
    g.strokeStyle = grid; g.lineWidth = 1; for (let k = 0; k <= 4; k++) { const yy = 10 + (k * (h - 20)) / 4; g.beginPath(); g.moveTo(0, yy); g.lineTo(w - right, yy); g.stroke(); g.fillStyle = txt; g.font = '10px system-ui'; g.fillText(fmtNum(hi - ((hi - lo) * k) / 4, getInstrument(st.symbol).precision), w - right + 4, yy + 3); }
    const line = (arr, color) => { g.strokeStyle = color; g.lineWidth = 1.4; g.beginPath(); let s = false; for (let k = 0; k < bars.length; k++) { const v = arr[from + k]; if (v == null) continue; const x = k * bw + bw / 2; if (!s) { g.moveTo(x, y(v)); s = true; } else g.lineTo(x, y(v)); } g.stroke(); };
    line(ema200, 'rgba(56,189,248,.7)'); line(ema50, 'rgba(245,158,11,.75)');
    bars.forEach((c, k) => { const x = k * bw + bw / 2; const col = c.close >= c.open ? up : dn; g.strokeStyle = col; g.beginPath(); g.moveTo(x, y(c.high)); g.lineTo(x, y(c.low)); g.stroke(); g.fillStyle = col; const t = y(Math.max(c.open, c.close)); g.fillRect(x - bw * 0.35, t, Math.max(1, bw * 0.7), Math.max(1, y(Math.min(c.open, c.close)) - t)); });
    // signals and exits that happened inside the visible window (all at or before the cursor)
    const mark = (i, dir, txtc) => { if (i < from || i > cur) return; const x = (i - from) * bw + bw / 2; const c = R.candles[i]; g.fillStyle = txtc; g.font = 'bold 12px system-ui'; g.textAlign = 'center'; g.fillText(dir === 'long' ? '▲' : '▼', x, dir === 'long' ? y(c.low) + 14 : y(c.high) - 5); g.textAlign = 'start'; };
    for (const t of [...S.trades, ...(S.open ? [S.open] : [])]) mark(t.signalIndex, t.direction, t.direction === 'long' ? up : dn);
    if (S.open) {
      const hl = (v, color, label) => { g.strokeStyle = color; g.setLineDash([5, 4]); g.beginPath(); g.moveTo(0, y(v)); g.lineTo(w - right, y(v)); g.stroke(); g.setLineDash([]); g.fillStyle = color; g.font = '10px system-ui'; g.fillText(label, 4, y(v) - 3); };
      hl(S.open.entry, txt, L('دخول', 'Entry')); hl(S.open.stop, dn, 'SL'); S.open.targets.forEach((t, i) => hl(t, up, `TP${i + 1}${S.open.hits > i ? ' ✓' : ''}`));
    }
  }
}
