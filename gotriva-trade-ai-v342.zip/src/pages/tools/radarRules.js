// Gotriva Radar — multi-condition alerts: build a rule from several conditions (price, RSI, candle
// change, trend, EMA 50, SMC break, volatility, squeeze, volume spike), each on its own timeframe,
// joined with AND / OR. Checked every 30 seconds; live ✓/✗ per condition; phone notification.
import { esc, fmtNum } from '../../utils/dom.js';
import { alertSlotOk } from '../../components/gate.js';
import { icons } from '../../components/icons.js';
import { t } from '../../i18n/index.js';
import { INSTRUMENTS } from '../../config/instruments.js';
import { isUnavailable } from '../../services/market/index.js';
import { alertState, onAlerts, addRule, removeRule, toggleRule, checkRules } from '../../services/alerts.js';
import { enableNotifications, notifyPermission } from '../../services/signals.js';
import { dateStr } from './common.js';
import { toast } from '../../components/ui.js';

const TFS = ['1m', '5m', '15m', '1h', '4h', '1D'];
// type → ops (value needed when the op list is numeric comparisons)
const TYPES = {
  price: { ops: ['gt', 'lt'], value: true },
  rsi: { ops: ['gt', 'lt'], value: true, def: 70 },
  chg: { ops: ['gt', 'lt'], value: true, def: 1 },
  trend: { ops: ['up', 'down'] },
  ema: { ops: ['above', 'below'] },
  smc: { ops: ['BOS_bull', 'BOS_bear', 'CHoCH_bull', 'CHoCH_bear'] },
  vol: { ops: ['gte'], value: true, def: 1.5 },
  squeeze: { ops: ['on'] },
  volume: { ops: ['gte'], value: true, def: 2.5 },
};
const opLabel = (type, op) => { const k = `tools.rules.op.${type}_${op}`; const v = t(k); return v === k ? t(`tools.rules.op.${op}`) : v; };
const TEMPLATES = [
  { key: 'oversoldBounce', conds: [{ type: 'rsi', op: 'lt', value: 30 }, { type: 'trend', op: 'up', tf: '4h' }, { type: 'smc', op: 'CHoCH_bull' }] },
  { key: 'breakout', conds: [{ type: 'smc', op: 'BOS_bull' }, { type: 'volume', op: 'gte', value: 2 }, { type: 'trend', op: 'up' }] },
  { key: 'squeeze', conds: [{ type: 'squeeze', op: 'on' }, { type: 'ema', op: 'above' }] },
  { key: 'dump', conds: [{ type: 'chg', op: 'lt', value: 1.5 }, { type: 'vol', op: 'gte', value: 1.8 }], logic: 'or' },
];

export function condText(c, ruleTf) {
  const tf = t(`perf.tfShort.${c.tf || ruleTf}`);
  const v = c.value != null && c.value !== '' ? fmtNum(Number(c.value), c.type === 'price' ? 2 : c.type === 'rsi' ? 0 : 1) : '';
  return `${t(`tools.rules.t.${c.type}`)} ${opLabel(c.type, c.op)} ${v} · ${tf}`.replace(/\s+/g, ' ').trim();
}

export function mountRules(page, body) {
  const list = INSTRUMENTS.filter((i) => !isUnavailable(i.symbol));
  const draft = { name: '', symbol: list[0].symbol, tf: '15m', logic: 'and', cooldownMin: 30, once: false, conds: [{ type: 'rsi', op: 'lt', value: 30 }] };
  body.innerHTML = `
    <article class="card tool-card fade-in"><h2 class="card-title">${icons.plus}<span>${esc(t('tools.rules.new'))}</span></h2>
      <div class="chips rl-templates">${TEMPLATES.map((x) => `<button type="button" class="chip" data-tpl="${x.key}">${icons.sparkle}${esc(t(`tools.rules.tpl.${x.key}`))}</button>`).join('')}</div>
      <div class="tf-grid">
        <label class="tf-field"><span>${esc(t('tools.rules.name'))}</span><input class="input" data-f="name" maxlength="40" placeholder="${esc(t('tools.rules.namePh'))}"></label>
        <label class="tf-field"><span>${esc(t('tools.common.symbol'))}</span><select class="select" data-f="symbol">${list.map((i) => `<option>${i.symbol}</option>`).join('')}</select></label>
        <label class="tf-field"><span>${esc(t('perf.timeframe'))}</span><select class="select" data-f="tf">${TFS.map((tf) => `<option value="${tf}" ${tf === draft.tf ? 'selected' : ''}>${esc(t(`perf.tfShort.${tf}`))}</option>`).join('')}</select></label>
        <label class="tf-field"><span>${esc(t('tools.rules.cooldown'))}</span><select class="select" data-f="cooldownMin">${[5, 15, 30, 60, 240].map((m) => `<option value="${m}" ${m === 30 ? 'selected' : ''}>${m} ${esc(t('tools.common.min'))}</option>`).join('')}</select></label>
      </div>
      <div class="rl-logic"><span>${esc(t('tools.rules.when'))}</span><div class="seg" data-logic><button type="button" data-v="and" class="is-on">${esc(t('tools.rules.and'))}</button><button type="button" data-v="or">${esc(t('tools.rules.or'))}</button></div></div>
      <div class="rl-conds" data-conds></div>
      <div class="tool-actions"><button type="button" class="btn btn-sm" data-addc>${icons.plus}<span>${esc(t('tools.rules.addCond'))}</span></button>
        <label class="tf-check"><input type="checkbox" data-f="once"><span>${esc(t('tools.rules.once'))}</span></label>
        <button type="button" class="btn btn-primary" data-save>${icons.alarm}<span>${esc(t('tools.rules.create'))}</span></button></div>
    </article>
    <article class="card tool-card fade-in"><div class="tool-head"><h2 class="card-title">${icons.alarm}<span>${esc(t('tools.rules.mine'))}</span></h2><button type="button" class="btn btn-sm btn-ghost" data-check>${icons.refresh}<span>${esc(t('tools.rules.checkNow'))}</span></button></div><div data-list></div></article>
    <p class="muted tool-note">${esc(t('tools.rules.note'))}</p>`;
  const $ = (s) => body.querySelector(s);

  function drawConds() {
    $('[data-conds]').innerHTML = draft.conds.map((c, i) => {
      const def = TYPES[c.type];
      return `<div class="rl-cond" data-i="${i}">
        ${i ? `<span class="rl-join">${esc(t(draft.logic === 'or' ? 'tools.rules.or' : 'tools.rules.and'))}</span>` : ''}
        <select class="select" data-c="type">${Object.keys(TYPES).map((k) => `<option value="${k}" ${k === c.type ? 'selected' : ''}>${esc(t(`tools.rules.t.${k}`))}</option>`).join('')}</select>
        <select class="select" data-c="op">${def.ops.map((o) => `<option value="${o}" ${o === c.op ? 'selected' : ''}>${esc(opLabel(c.type, o))}</option>`).join('')}</select>
        ${def.value ? `<input class="input mono" data-c="value" inputmode="decimal" value="${esc(c.value ?? def.def ?? '')}">` : '<span></span>'}
        <select class="select" data-c="tf"><option value="">${esc(t('tools.rules.sameTf'))}</option>${TFS.map((tf) => `<option value="${tf}" ${tf === c.tf ? 'selected' : ''}>${esc(t(`perf.tfShort.${tf}`))}</option>`).join('')}</select>
        <button type="button" class="btn btn-icon btn-ghost btn-sm" data-del="${i}" ${draft.conds.length < 2 ? 'disabled' : ''} aria-label="${esc(t('tools.common.delete'))}">${icons.trash}</button>
      </div>`;
    }).join('');
  }
  drawConds();

  body.querySelectorAll('[data-f]').forEach((x) => x.addEventListener(x.type === 'checkbox' ? 'change' : 'input', () => { draft[x.dataset.f] = x.type === 'checkbox' ? x.checked : x.dataset.f === 'cooldownMin' ? Number(x.value) : x.value; }));
  $('[data-logic]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; draft.logic = b.dataset.v; $('[data-logic]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b)); drawConds(); });
  $('[data-conds]').addEventListener('change', (e) => {
    const row = e.target.closest('[data-i]'); const k = e.target.dataset.c; if (!row || !k) return;
    const c = draft.conds[Number(row.dataset.i)];
    c[k] = e.target.value;
    if (k === 'type') { c.op = TYPES[c.type].ops[0]; c.value = TYPES[c.type].def ?? ''; drawConds(); }
  });
  $('[data-conds]').addEventListener('input', (e) => { const row = e.target.closest('[data-i]'); if (row && e.target.dataset.c === 'value') draft.conds[Number(row.dataset.i)].value = e.target.value; });
  $('[data-conds]').addEventListener('click', (e) => { const b = e.target.closest('[data-del]'); if (b && draft.conds.length > 1) { draft.conds.splice(Number(b.dataset.del), 1); drawConds(); } });
  $('[data-addc]').addEventListener('click', () => { if (draft.conds.length < 6) { draft.conds.push({ type: 'trend', op: 'up' }); drawConds(); } });
  body.querySelectorAll('[data-tpl]').forEach((b) => b.addEventListener('click', () => {
    const tp = TEMPLATES.find((x) => x.key === b.dataset.tpl);
    draft.conds = tp.conds.map((c) => ({ ...c })); draft.logic = tp.logic || 'and';
    draft.name = t(`tools.rules.tpl.${tp.key}`); $('[data-f="name"]').value = draft.name;
    $('[data-logic]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x.dataset.v === draft.logic));
    drawConds();
  }));
  $('[data-save]').addEventListener('click', async () => {
    if (draft.conds.some((c) => TYPES[c.type].value && !Number.isFinite(Number(c.value)))) { toast(t('tools.common.invalid'), 'error'); return; }
    if (notifyPermission() === 'default') await enableNotifications();
    if (!alertSlotOk()) return;
    addRule({ ...draft, conds: draft.conds.map((c) => ({ type: c.type, op: c.op, ...(TYPES[c.type].value ? { value: Number(c.value) } : {}), ...(c.tf ? { tf: c.tf } : {}) })) });
    toast(t('tools.alerts.created'), 'success');
  });
  $('[data-check]').addEventListener('click', () => checkRules());
  $('[data-list]').addEventListener('click', (e) => {
    const d = e.target.closest('[data-rdel]'); if (d) { removeRule(d.dataset.rdel); return; }
    const tg = e.target.closest('[data-rtoggle]'); if (tg) toggleRule(tg.dataset.rtoggle);
  });

  function draw(st) {
    $('[data-list]').innerHTML = st.rules.length ? `<div class="rl-list">${st.rules.map((r) => {
      const s = st.ruleStatus[r.id];
      const met = s?.results?.filter(Boolean).length ?? 0;
      return `<div class="rl-rule ${r.active ? '' : 'is-off'} ${s?.ok ? 'is-met' : ''}">
        <div class="rl-rhead"><span class="al-ico">${icons.alarm}</span><b>${esc(r.name || r.symbol)}</b><span class="muted mono">${esc(r.symbol)} · ${esc(t(`perf.tfShort.${r.tf}`))}</span>
          <span class="badge ${s?.ok ? 'badge-live' : 'badge-muted'}">${s ? esc(t('tools.rules.progress', { m: met, n: r.conds.length })) : '…'}</span></div>
        <ul class="rl-clist">${r.conds.map((c, i) => `<li class="${s?.results?.[i] === true ? 'ok' : s?.results?.[i] === false ? 'no' : ''}"><i>${s?.results?.[i] === true ? '✓' : s?.results?.[i] === false ? '✗' : '·'}</i>${i ? `<em>${esc(t(r.logic === 'or' ? 'tools.rules.or' : 'tools.rules.and'))}</em>` : ''}<span>${esc(condText(c, r.tf))}</span></li>`).join('')}</ul>
        <div class="rl-foot"><small class="muted">${esc(t('tools.rules.cooldownShort', { m: r.cooldownMin }))}${r.count ? ` · ${esc(t('tools.alerts.fired', { n: r.count, time: dateStr(r.lastFired) }))}` : ''}${s ? ` · ${esc(t('tools.rules.checked', { time: dateStr(s.at, { hour: '2-digit', minute: '2-digit', second: '2-digit' }) }))}` : ''}</small>
          <button type="button" class="btn btn-sm btn-ghost" data-rtoggle="${r.id}">${esc(t(r.active ? 'tools.alerts.pause' : 'tools.alerts.resume'))}</button>
          <button type="button" class="btn btn-icon btn-ghost btn-sm" data-rdel="${r.id}" aria-label="${esc(t('tools.common.delete'))}">${icons.trash}</button></div>
      </div>`;
    }).join('')}</div>` : `<div class="sig-empty">${icons.alarm}<span>${esc(t('tools.rules.empty'))}</span></div>`;
  }
  draw(alertState());
  let ready = false; setTimeout(() => { ready = true; }, 500);
  const off = onAlerts((st) => { if (ready && !page.isConnected) { off(); return; } draw(st); });
}
