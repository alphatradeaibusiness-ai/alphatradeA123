// Trade journal: every trade the user records (or imports from the signals channel) with its
// result in money, points and R, plus statistics, an equity curve and CSV export.
import { esc, fmtNum } from '../../utils/dom.js';
import { icons } from '../../components/icons.js';
import { t } from '../../i18n/index.js';
import { storage } from '../../utils/storage.js';
import { INSTRUMENTS, getInstrument } from '../../config/instruments.js';
import { signalState } from '../../services/signals.js';
import { journalStats } from '../../services/journalStats.js';
import { toolPage, money, signedMoney, signed, uid, num, lineSvg, downloadText, csvText, dateStr, pointSizeOf } from './common.js';
import { toast } from '../../components/ui.js';

const KEY = 'journal';
const load = () => storage.get(KEY, []);

/** Result of one recorded trade. */
export function tradeResult(x) {
  const dir = x.direction === 'long' ? 1 : -1;
  const move = (x.exit - x.entry) * dir;
  const risk = x.stop > 0 ? Math.abs(x.entry - x.stop) : null;
  const ps = pointSizeOf(x.symbol);
  return { usd: move * (x.qty || 0) - (x.fees || 0), points: x.points ?? move / ps, r: x.r ?? (risk ? move / risk : null) };
}

export function renderJournal() {
  const el = toolPage('journal', 'journal');
  let trades = load();
  const f = { symbol: '', period: 'all' };
  const body = el.querySelector('[data-body]');
  const nowLocal = () => { const d = new Date(Date.now() - new Date().getTimezoneOffset() * 60000); return d.toISOString().slice(0, 16); };
  body.innerHTML = `
    <div class="kpi-row" data-kpis></div>
    <article class="card tool-card fade-in" data-strat-card hidden><h2 class="card-title">${icons.layers || ''}<span>${esc(t('jx.byStrategy'))}</span></h2><div data-strat></div><p class="muted tool-note">${esc(t('jx.note'))}</p></article>
    <details class="card tool-card fade-in jr-add" ${trades.length ? '' : 'open'}><summary class="card-title">${icons.plus}<span>${esc(t('tools.journal.add'))}</span></summary>
      <form class="tf-grid" data-form>
        <label class="tf-field"><span>${esc(t('tools.common.symbol'))}</span><select class="select" name="symbol">${INSTRUMENTS.map((i) => `<option>${i.symbol}</option>`).join('')}</select></label>
        <label class="tf-field"><span>${esc(t('tools.common.direction'))}</span><select class="select" name="direction"><option value="long">${esc(t('common.long'))}</option><option value="short">${esc(t('common.short'))}</option></select></label>
        <label class="tf-field"><span>${esc(t('tools.journal.entry'))}</span><input class="input mono" name="entry" inputmode="decimal" required></label>
        <label class="tf-field"><span>${esc(t('tools.journal.exit'))}</span><input class="input mono" name="exit" inputmode="decimal" required></label>
        <label class="tf-field"><span>${esc(t('tools.journal.stop'))}</span><input class="input mono" name="stop" inputmode="decimal"></label>
        <label class="tf-field"><span>${esc(t('tools.journal.qty'))}</span><input class="input mono" name="qty" inputmode="decimal" placeholder="1"></label>
        <label class="tf-field"><span>${esc(t('tools.journal.fees'))}</span><input class="input mono" name="fees" inputmode="decimal" placeholder="0"></label>
        <label class="tf-field"><span>${esc(t('tools.journal.strategy'))}</span><select class="select" name="strategy"><option value="edh">EDH</option><option value="smc">SMC</option><option value="zone">${esc(t('zs.toggle'))}</option><option value="classic">${esc(t('perf.classic'))}</option><option value="other">${esc(t('tools.journal.other'))}</option></select></label>
        <label class="tf-field"><span>${esc(t('tools.journal.closedAt'))}</span><input class="input mono" type="datetime-local" name="closedAt" value="${nowLocal()}"></label>
        <label class="tf-field tf-wide"><span>${esc(t('tools.journal.notes'))}</span><input class="input" name="notes" maxlength="200" placeholder="${esc(t('tools.journal.notesPh'))}"></label>
        <div class="tf-field tf-end"><button class="btn btn-primary" type="submit">${icons.check}<span>${esc(t('tools.journal.save'))}</span></button></div>
      </form>
    </details>
    <div class="card perf-controls fade-in">
      <label class="perf-field"><span>${esc(t('tools.common.symbol'))}</span><select class="select" data-fsym><option value="">${esc(t('tools.common.all'))}</option>${INSTRUMENTS.map((i) => `<option>${i.symbol}</option>`).join('')}</select></label>
      <div class="perf-field"><span>${esc(t('tools.journal.period'))}</span><div class="seg" data-period>${['7', '30', 'all'].map((p) => `<button type="button" data-v="${p}" class="${f.period === p ? 'is-on' : ''}">${esc(t(`tools.journal.p${p}`))}</button>`).join('')}</div></div>
      <div class="tool-actions"><button type="button" class="btn btn-sm" data-import>${icons.bell}<span>${esc(t('tools.journal.import'))}</span></button>
        <button type="button" class="btn btn-sm btn-ghost" data-csv>${icons.download}<span>CSV</span></button></div>
    </div>
    <article class="card tool-card fade-in"><h2 class="card-title">${icons.trend}<span>${esc(t('tools.journal.curve'))}</span></h2><div data-curve></div></article>
    <article class="card tool-card fade-in"><h2 class="card-title">${icons.journal}<span>${esc(t('tools.journal.list'))}</span></h2><div data-list></div></article>`;
  const $ = (s) => body.querySelector(s);
  const save = () => storage.set(KEY, trades);
  const form = $('[data-form]');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const x = { id: uid(), symbol: form.symbol.value, direction: form.direction.value, entry: num(form.entry.value), exit: num(form.exit.value), stop: num(form.stop.value) || 0, qty: num(form.qty.value) || 1, fees: num(form.fees.value) || 0, strategy: form.strategy.value, notes: form.notes.value.trim(), closedAt: Date.parse(form.closedAt.value) || Date.now(), source: 'manual' };
    if (!(x.entry > 0) || !(x.exit > 0)) { toast(t('tools.common.invalid'), 'error'); return; }
    trades.unshift(x); save(); form.reset(); form.closedAt.value = nowLocal(); draw();
    toast(t('tools.journal.saved'), 'success');
  });
  $('[data-fsym]').addEventListener('change', (e) => { f.symbol = e.target.value; draw(); });
  $('[data-period]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; f.period = b.dataset.v; $('[data-period]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b)); draw(); });
  $('[data-list]').addEventListener('click', (e) => {
    const d = e.target.closest('[data-del]');
    if (d && confirm(t('tools.journal.confirmDel'))) { trades = trades.filter((x) => x.id !== d.dataset.del); save(); draw(); }
  });
  $('[data-import]').addEventListener('click', () => {
    // Closed signals → journal (1 unit each; the result follows the strategy's thirds rule).
    let n = 0;
    for (const s of signalState().signals) {
      if (s.status === 'active' || trades.some((x) => x.sigId === s.id)) continue;
      const dir = s.direction === 'long' ? 1 : -1;
      const exitRest = s.status === 'sl' ? s.stop : s.status === 'be' ? s.entry : s.targets[2];
      let move = 0;
      for (let k = 0; k < s.hits; k++) move += (s.targets[k] - s.entry) * dir / 3;
      move += (exitRest - s.entry) * dir * (3 - s.hits) / 3;
      const risk = Math.abs(s.entry - s.stop);
      trades.unshift({ id: uid(), sigId: s.id, tf: s.tf, openedAt: s.createdAt, symbol: s.symbol, direction: s.direction, entry: s.entry, exit: s.entry + move * dir, stop: s.stop, qty: 1, fees: 0, strategy: s.strategy, notes: `${t('tools.journal.fromSignal')} · ${s.tf} · ${t(`sig.status.${s.status}`)}`, closedAt: s.closedAt || s.createdAt, source: 'signal', r: risk ? move / risk : null });
      n++;
    }
    trades.sort((a, b) => b.closedAt - a.closedAt);
    save(); draw();
    toast(n ? t('tools.journal.imported', { n }) : t('tools.journal.nothing'), n ? 'success' : 'info');
  });
  $('[data-csv]').addEventListener('click', () => {
    const rows = [['closed_at', 'symbol', 'direction', 'entry', 'exit', 'stop', 'qty', 'fees', 'pnl_usd', 'points', 'r', 'strategy', 'notes']]
      .concat(trades.map((x) => { const r = tradeResult(x); return [new Date(x.closedAt).toISOString(), csvText(x.symbol), csvText(x.direction), x.entry, x.exit, x.stop || '', x.qty, x.fees || 0, r.usd.toFixed(2), r.points.toFixed(1), r.r != null ? r.r.toFixed(2) : '', csvText(x.strategy), csvText(x.notes)]; }));
    downloadText('gotrivatrade-journal.csv', rows.map((r) => r.join(',')).join('\n'));
  });

  function draw() {
    const since = f.period === 'all' ? 0 : Date.now() - Number(f.period) * 864e5;
    const list = trades.filter((x) => (!f.symbol || x.symbol === f.symbol) && x.closedAt >= since);
    const res = list.map((x) => ({ x, ...tradeResult(x) }));
    const wins = res.filter((r) => r.usd > 0);
    const losses = res.filter((r) => r.usd < 0);
    const net = res.reduce((a, r) => a + r.usd, 0);
    const gw = wins.reduce((a, r) => a + r.usd, 0); const gl = -losses.reduce((a, r) => a + r.usd, 0);
    const rs = res.filter((r) => r.r != null);
    const avgR = rs.length ? rs.reduce((a, r) => a + r.r, 0) / rs.length : null;
    const pts = res.reduce((a, r) => a + r.points, 0);
    // Longest losing streak (oldest → newest).
    let cur = 0; let worst = 0;
    [...res].reverse().forEach((r) => { cur = r.usd < 0 ? cur + 1 : 0; worst = Math.max(worst, cur); });
    const wr = res.length ? wins.length / res.length * 100 : 0;
    const js = journalStats(res.map((r) => ({ usd: r.usd, r: r.r, closedAt: r.x.closedAt, strategy: r.x.strategy })));
    const stratName = (k) => (k === 'edh' ? 'EDH' : k === 'lbr' ? 'LBR' : k === 'smc' ? 'SMC' : k === 'zone' ? t('zs.toggle') : k === 'classic' ? t('perf.classic') : t('jx.other'));
    $('[data-strat-card]').hidden = js.byStrategy.length < 2;   // a comparison needs at least two strategies
    $('[data-strat]').innerHTML = `<div class="table-scroll"><table class="kv-table perf-table"><thead><tr><th>${esc(t('jx.strategy'))}</th><th>${esc(t('tools.journal.trades'))}</th><th>${esc(t('tools.journal.winRate'))}</th><th>${esc(t('tools.journal.net'))}</th><th>${esc(t('tools.journal.pf'))}</th><th>${esc(t('jx.maxDD'))}</th></tr></thead><tbody>
      ${js.byStrategy.map((b) => `<tr><td>${esc(stratName(b.strategy))}</td><td class="mono">${b.n}</td><td class="mono">${fmtNum(b.winRate, 1)}%</td><td>${signedMoney(b.net)}</td><td class="mono">${b.profitFactor == null ? '—' : b.profitFactor === Infinity ? '∞' : fmtNum(b.profitFactor, 2)}</td><td class="mono">${money(b.maxDrawdown)}</td></tr>`).join('')}
      </tbody></table></div>`;
    $('[data-kpis]').innerHTML = `
      <div class="mini-kpi glow"><span>${esc(t('tools.journal.trades'))}</span><b class="mono">${res.length}</b><small><span class="up">${wins.length} ${esc(t('perf.winsShort'))}</span> · <span class="down">${losses.length} ${esc(t('perf.lossesShort'))}</span></small></div>
      <div class="mini-kpi"><span>${esc(t('tools.journal.winRate'))}</span><b class="mono">${fmtNum(wr, 1)}%</b><small class="wl-bar"><i style="width:${wr}%"></i></small></div>
      <div class="mini-kpi ${net >= 0 ? 'good' : 'bad'}"><span>${esc(t('tools.journal.net'))}</span><b>${signedMoney(net)}</b><small>${signed(pts, 0)} ${esc(t('sig.pts'))}</small></div>
      <div class="mini-kpi"><span>${esc(t('tools.journal.pf'))}</span><b class="mono">${gl > 0 ? fmtNum(gw / gl, 2) : gw > 0 ? '∞' : '—'}</b><small>${esc(t('tools.journal.avgR'))} ${avgR != null ? `<bdi class="mono">${fmtNum(avgR, 2)}R</bdi>` : '—'} · ${esc(t('tools.journal.streak'))} ${worst}</small></div>
      <div class="mini-kpi ${js.maxDrawdown > 0 ? 'bad' : ''}"><span>${esc(t('jx.maxDD'))}</span><b>${money(js.maxDrawdown)}</b><small>${js.maxDrawdownPct != null ? `${fmtNum(js.maxDrawdownPct, 1)}% ${esc(t('jx.ofPeak'))}` : '—'}</small></div>`;
    const eq = []; let acc = 0;
    [...res].sort((a, b) => a.x.closedAt - b.x.closedAt).forEach((r) => eq.push(acc += r.usd));
    $('[data-curve]').innerHTML = eq.length > 1 ? lineSvg(eq) : `<p class="muted">${esc(t('tools.journal.curveEmpty'))}</p>`;
    $('[data-list]').innerHTML = res.length ? `<div class="table-scroll"><table class="kv-table perf-table"><thead><tr><th>${esc(t('tools.journal.date'))}</th><th>${esc(t('tools.common.symbol'))}</th><th></th><th>${esc(t('tools.journal.entry'))}</th><th>${esc(t('tools.journal.exit'))}</th><th>$</th><th>${esc(t('sig.pts'))}</th><th>R</th><th>${esc(t('tools.journal.notes'))}</th><th></th></tr></thead><tbody>
      ${res.map(({ x, usd, points, r }) => { const p = getInstrument(x.symbol).precision; return `<tr>
        <td class="mono">${esc(dateStr(x.closedAt))}</td><td class="mono">${esc(x.symbol)}${x.source === 'signal' ? ' <span class="badge badge-muted">SIG</span>' : ''}</td>
        <td><span class="badge ${x.direction === 'long' ? 'badge-live' : 'badge-error'}">${esc(t(x.direction === 'long' ? 'common.long' : 'common.short'))}</span></td>
        <td class="mono">${fmtNum(x.entry, p)}</td><td class="mono">${fmtNum(x.exit, p)}</td><td>${signedMoney(usd)}</td><td>${signed(points, 0)}</td><td>${r != null ? signed(r, 2, 'R') : '—'}</td>
        <td class="jr-notes">${esc(x.notes || '')}</td><td><button type="button" class="btn btn-icon btn-ghost btn-sm" data-del="${x.id}" aria-label="${esc(t('tools.common.delete'))}">${icons.trash}</button></td></tr>`; }).join('')}
      </tbody></table></div>` : `<div class="sig-empty">${icons.journal}<span>${esc(t('tools.journal.empty'))}</span></div>`;
  }
  draw();
  return el;
}

export { money };
