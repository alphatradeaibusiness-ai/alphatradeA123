// Gotriva Opportunity Tracker (v233): every opportunity the radar showed, followed on real prices, with live-signal statistics.
// Back-test, paper and real results live in their own sections and are never mixed in here.
import { esc, fmtNum } from '../../utils/dom.js';
import { getLocale } from '../../i18n/index.js';
import { trackerList, trackerStats, onTracker, trackTick, alertPrefs, setAlertPref, clearTracker, ALERT_TYPES } from '../../services/radarTracker.js';
import { enableNotifications, notifyPermission } from '../../services/signals.js';
import { L, STATUS, GRADE, PART, TF_NAME } from './radarText.js';
import { whileMounted } from './common.js';

export function mountTracker(el, body) {
  let tab = 'open'; let armed = false;
  body.innerHTML = `<div data-stats></div>
    <div class="card rp-sources"><b>${esc(L('مصادر النتائج، كل واحد لحاله', 'Result sources, each kept separate'))}</b>
      <span class="is-on">${esc(L('الإشارات الحية (هون)', 'Live signals (here)'))}</span>
      <a href="#/app/lab">${esc(L('نتائج الباك تست ←', 'Back-test results →'))}</a><span class="muted">${esc(L('التداول التجريبي: مش متاح بالمنصة حالياً', 'Paper trading: not available on the platform right now'))}</span><a href="#/app/journal">${esc(L('الصفقات الحقيقية (السجل) ←', 'Real trades (journal) →'))}</a></div>
    <div class="rc-tabs rp-ttabs">${[['open', L('مفتوحة', 'Open')], ['closed', L('منتهية', 'Finished')], ['all', L('الكل', 'All')]].map(([k, n]) => `<button type="button" class="btn btn-sm" data-t="${k}" aria-pressed="${k === tab}">${esc(n)}</button>`).join('')}<button type="button" class="btn btn-sm" data-now>${esc(L('تحديث الأسعار هلّق', 'Check prices now'))}</button></div>
    <div data-list></div>
    <details class="card rp-more rp-prefs"><summary>${esc(L('إعدادات التنبيهات', 'Alert settings'))}</summary><div data-prefs></div></details>
    <p class="muted tool-note">${esc(L('كل فرصة بيعرضها الرادار بتنسجل تلقائياً مع خطتها، وبتنتابع على أسعار حقيقية. الرصد مش نجاح: الحالة بتتغيّر بس لما السعر يوصل فعلاً. إذا الشمعة لمست الوقف والهدف بنفس الوقت، بنحسبها وقف (الأحوط). بعد الهدف الأول الوقف بينتقل للدخول، وثلث الصفقة بيتسكّر عند كل هدف.', 'Every opportunity the radar shows is recorded with its plan and followed on real prices. Detection is not success: a status changes only when price actually trades there. A candle touching both the stop and a target counts as the stop (conservative). After TP1 the stop moves to entry; a third is closed at each target.'))}</p>`;
  const $ = (s) => body.querySelector(s);
  const fmtT = (ms) => new Date(ms).toLocaleString(getLocale(), { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  const num = (v, d = 2) => (v == null ? '—' : v === Infinity ? '∞' : fmtNum(v, d));
  const paintStats = () => {
    const s = trackerStats(trackerList());
    const k = (label, v, cls = '') => `<div class="rp-k ${cls}"><b>${esc(v)}</b><span>${esc(label)}</span></div>`;
    const grp = (title, rows, nameOf = (x) => x) => (rows.length ? `<div><h5>${esc(title)}</h5><table class="rp-table"><thead><tr><th></th><th>${esc(L('صفقات', 'Trades'))}</th><th>${esc(L('نجاح', 'Win'))}</th><th>R</th></tr></thead><tbody>${rows.slice(0, 8).map((g) => `<tr><td>${esc(nameOf(g.key))}</td><td>${g.n}</td><td>${g.winRate}%</td><td class="${g.r >= 0 ? 'up-ish' : 'down-ish'}">${g.r > 0 ? '+' : ''}${fmtNum(g.r, 2)}</td></tr>`).join('')}</tbody></table></div>` : '');
    $('[data-stats]').innerHTML = `<section class="card rp-dash"><h3>${esc(L('نتائج الإشارات الحية', 'Live signal results'))}</h3>
      <div class="rp-kpis">${k(L('كل الفرص', 'Total'), s.total)}${k(L('مفتوحة', 'Open'), s.open, 'k-open')}${k(L('مكتملة', 'Completed'), s.completed)}${k(L('رابحة', 'Winning'), s.wins, 'k-win')}${k(L('خاسرة', 'Losing'), s.losses, 'k-loss')}
        ${k(L('نسبة النجاح', 'Win rate'), s.winRate == null ? '—' : `${s.winRate}%`)}${k(L('متوسط R', 'Average R'), s.avgR == null ? '—' : `${s.avgR > 0 ? '+' : ''}${num(s.avgR)}`)}${k(L('معامل الربح', 'Profit factor'), num(s.profitFactor))}${k(L('أقصى تراجع', 'Max drawdown'), `${num(s.maxDrawdownR)}R`)}</div>
      ${s.completed ? `<details class="rp-more-in"><summary>${esc(L('حسب السوق / الفريم / الاستراتيجية', 'By market / timeframe / strategy'))}</summary><div class="rp-groups">${grp(L('السوق', 'Market'), s.byMarket)}${grp(L('الفريم', 'Timeframe'), s.byTf, (x) => TF_NAME()[x] || x)}${grp(L('الاستراتيجية', 'Strategy'), s.byStrategy, (x) => (x === 'atr' ? L('خطة ATR', 'ATR plan') : x === 'smc' ? 'SMC' : L('كلاسيكية', 'Classic')))}</div></details>`
        : `<p class="muted">${esc(L('لسا ما في فرص مكتملة، الأرقام بتطلع بس من نتائج حقيقية، ما في نسب مؤلفة.', 'No completed opportunities yet, numbers appear only from real outcomes, never invented.'))}</p>`}
      ${s.cancelled ? `<p class="muted rp-small">${esc(L(`${s.cancelled} فرصة انلغت أو انتهت قبل الدخول، مش محسوبة ربح ولا خسارة.`, `${s.cancelled} cancelled or expired before entry, counted as neither win nor loss.`))}</p>` : ''}</section>`;
  };
  const row = (o) => {
    const p = (v) => fmtNum(v, o.precision ?? 2); const S = STATUS(); const long = o.direction === 'long';
    const tps = o.targets.map((t, i) => `<span class="${o.hits > i ? 'is-hit' : ''}">TP${i + 1} <b class="mono">${esc(p(t))}</b>${o.hits > i ? ' ✓' : ''}</span>`).join('');
    const parts = (o.why || []).map((k) => PART()[k]).filter(Boolean).join(' · ');
    return `<article class="card rp-opp is-${o.status} ${long ? 'is-long' : 'is-short'}">
      <header><b class="mono">${esc(o.symbol)}</b><span class="badge ${long ? 'badge-live' : 'badge-error'}">${esc(long ? L('شراء', 'BUY') : L('بيع', 'SELL'))}</span><span class="rp-tf">${esc(TF_NAME()[o.tf] || o.tf)}</span>
        <span class="rp-status">${esc(S[o.status] || o.status)}${o.closed && o.r != null && o.triggeredAt ? ` · <b class="${o.r >= 0 ? 'up-ish' : 'down-ish'}">${o.r > 0 ? '+' : ''}${fmtNum(o.r, 2)}R</b>` : ''}</span>
        <span class="rp-score" title="${esc(o.grade ? GRADE()[o.grade] : '')}">${esc(String(o.score))}</span></header>
      <div class="rp-levels"><span>${esc(L('رُصدت', 'Detected'))} ${esc(fmtT(o.detectedAt))} · <b class="mono">${esc(p(o.detectedPrice))}</b></span><span>${esc(L('دخول', 'Entry'))} <b class="mono">${esc(p(o.entry))}</b>${o.order === 'limit' ? ` <small>${esc(L('(معلّق)', '(limit)'))}</small>` : ''}</span><span class="down-ish">SL <b class="mono">${esc(p(o.stop))}</b></span>${tps}</div>
      <footer>${parts ? `<span class="muted">${esc(L('ليش: ', 'Why: '))}${esc(parts)}</span>` : ''}<span class="muted">${esc(L('آخر سعر', 'Last'))} <b class="mono">${esc(p(o.lastPrice))}</b></span>${o.plan === 'atr' ? `<span class="muted">${esc(L('خطة ATR', 'ATR plan'))}</span>` : ''}</footer></article>`;
  };
  const paintList = () => {
    const all = trackerList(); const list = all.filter((o) => (tab === 'open' ? !o.closed : tab === 'closed' ? o.closed : true)).slice(0, 80);
    $('[data-list]').innerHTML = list.length ? `<div class="rp-opps">${list.map(row).join('')}</div>`
      : `<div class="card sig-empty"><span>${esc(tab === 'open' ? L('ما في فرص مفتوحة. افتح تبويب «الفرص» والرادار بيسجّل كل فرصة قوية لحاله.', 'No open opportunities. Open the “Opportunities” tab and the radar records each strong one automatically.') : L('ما في فرص منتهية لسا.', 'No finished opportunities yet.'))}</span></div>`;
  };
  const paintPrefs = () => {
    const pr = alertPrefs(); const N = { strong: L('ظهور فرصة قوية', 'A strong opportunity appears'), near: L('السعر قرّب من الدخول', 'Price approaches the entry'), entry: L('تفعيل الدخول', 'Entry confirmed'), tp: L('الوصول لأهداف 1 / 2 / 3', 'TP1 / TP2 / TP3 reached'), sl: L('ضرب وقف الخسارة', 'Stop loss reached'), expired: L('انتهاء صلاحية الفرصة', 'Opportunity expired'), sweep: L('سحب سيولة على سوق متابَع', 'Liquidity sweep on a followed market') };
    const perm = notifyPermission();
    $('[data-prefs]').innerHTML = `<div class="rp-prefs-grid">${ALERT_TYPES.map((k) => `<label class="checkbox"><input type="checkbox" data-pref="${k}" ${pr[k] ? 'checked' : ''}/><span>${esc(N[k])}</span></label>`).join('')}</div>
      <p class="muted rp-small">${esc(L('كل تنبيه بيوصل مرة وحدة بس.', 'Each alert is sent only once.'))} ${perm === 'granted' ? esc(L('تنبيهات الجهاز مفعّلة.', 'Device notifications are on.')) : `<button type="button" class="btn btn-sm" data-perm>${esc(L('فعّل تنبيهات الجهاز', 'Turn on device notifications'))}</button>`}</p>
      <button type="button" class="btn btn-sm rp-clear" data-clear>${esc(armed ? L('متأكد؟ اكبس كمان مرة لمسح السجل', 'Sure? Tap again to clear the history') : L('مسح سجل الفرص', 'Clear opportunity history'))}</button>`;
  };
  const paint = () => { if (!el.isConnected) return; paintStats(); paintList(); };
  body.addEventListener('click', async (e) => {
    const t = e.target.closest('[data-t]'); if (t) { tab = t.dataset.t; body.querySelectorAll('[data-t]').forEach((x) => x.setAttribute('aria-pressed', String(x === t))); paintList(); return; }
    if (e.target.closest('[data-now]')) { const b = e.target.closest('[data-now]'); b.disabled = true; await trackTick(); b.disabled = false; paint(); return; }
    if (e.target.closest('[data-perm]')) { await enableNotifications(); paintPrefs(); return; }
    if (e.target.closest('[data-clear]')) { if (!armed) { armed = true; paintPrefs(); setTimeout(() => { armed = false; if (el.isConnected) paintPrefs(); }, 4000); return; } armed = false; clearTracker(); paintPrefs(); paint(); }
  });
  body.addEventListener('change', (e) => { const c = e.target.closest('[data-pref]'); if (c) setAlertPref(c.dataset.pref, c.checked); });
  const off = onTracker(paint);
  whileMounted(el, () => { if (!el.isConnected) { off(); return; } paint(); }, 30_000);
  paint(); paintPrefs();
}
