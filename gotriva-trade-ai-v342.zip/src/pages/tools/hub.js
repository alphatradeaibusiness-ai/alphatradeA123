// Merged pages: related tools share one page with tabs, so the side menu stays short.
//   Gotriva Radar        → opportunities · multi-screen · support/resistance · liquidity ·
//                        volatility · correlation
//   Strategy lab       → results · automatic optimisation
//   Trade journal      → journal · smart analysis
//   Alerts             → price alerts · multi-condition alerts
//   News               → headlines · economic calendar
// Every old address still works and opens the right tab.
import { esc } from '../../utils/dom.js';
import { icons } from '../../components/icons.js';
import { t } from '../../i18n/index.js';
import { toolPage } from './common.js';
import { canTab, TAB_FEATURE } from '../../config/entitlements.js';
import { lockedCard } from '../../components/gate.js';
import { ALIASES } from './hubMap.js';
import { renderPerformance } from '../performance.js';
import { mountOpps } from './radar.js';
import { mountMulti } from './radarMulti.js';
import { mountLevels } from './radarLevels.js';
import { mountRules } from './radarRules.js';
import { renderWalkForward } from './walkforward.js';
import { renderJournal } from './journal.js';
import { renderSmartlog } from './smartlog.js';
import { renderAlerts } from './alerts.js';
import { renderNews } from './news.js';
import { HERO_ARTS, PAGE_WAVE } from '../heroArt.js';
import { renderCalendar } from './calendar.js';

// tab: { id (route), icon, mount(page, body) | render(ctx) }
export const HUBS = {
  radar: { icon: 'radar', title: 'radar', tabs: [
    { id: 'radar', icon: 'radar', label: 'opps', mount: mountOpps },
    { id: 'radar-smf', icon: 'drop', label: 'smf', mount: (el, b) => import('./radarSmf.js').then((m) => m.mountSmf(el, b)) },
    { id: 'radar-tracker', icon: 'journal', label: 'tracker', mount: (el, b) => import('./radarTrackerPage.js').then((m) => m.mountTracker(el, b)) },
    { id: 'radar-replay', icon: 'refresh', label: 'replay', mount: (el, b) => import('./radarReplayPage.js').then((m) => m.mountReplay(el, b)) },
    { id: 'radar-corr', icon: 'swap', label: 'corr', mount: (el, b) => import('./radarCorr.js').then((m) => m.mountCorr(el, b)) },
    { id: 'radar-multi', icon: 'grid', label: 'multi', mount: mountMulti },
    { id: 'radar-levels', icon: 'levels', label: 'levels', mount: mountLevels },
  ] },
  lab: { icon: 'flask', title: 'lab', tabs: [
    { id: 'lab', icon: 'trophy', label: 'results', render: () => renderPerformance() },
    { id: 'walkforward', icon: 'shield', label: 'stability', render: () => renderWalkForward() },
  ] },
  journal: { icon: 'journal', title: 'journal', tabs: [
    { id: 'journal', icon: 'journal', label: 'log', render: () => renderJournal() },
    { id: 'smartlog', icon: 'brain', label: 'smart', render: () => renderSmartlog() },
  ] },
  alerts: { icon: 'alarm', title: 'alerts', tabs: [
    { id: 'alerts', icon: 'alarm', label: 'price', render: () => renderAlerts() },
    { id: 'radar-rules', icon: 'sparkle', label: 'rules', render: null, mount: mountRules },
  ] },
  news: { icon: 'news', title: 'news', tabs: [
    { id: 'news', icon: 'news', label: 'headlines', render: () => renderNews() },
    { id: 'calendar', icon: 'calendar', label: 'calendar', render: () => renderCalendar() },
  ] },
};
const TAB_OF = {};
for (const [hub, def] of Object.entries(HUBS)) for (const tab of def.tabs) TAB_OF[tab.id] = { hub, tab };

/** The hub (and drawer entry) a route belongs to, or null. */
export function hubFor(sub) {
  const id = ALIASES[sub] || sub;
  return TAB_OF[id] ? { ...TAB_OF[id], id } : null;
}

export function renderHub(sub, ctx = {}) {
  const found = hubFor(sub);
  const def = HUBS[found.hub];
  const el = toolPage(def.title, def.icon);
  el.classList.add('hub', `hub-${found.hub}`);
  // v334: hero drawing + bottom wave (owner's reference pictures)
  const hero = el.querySelector('.tool-hero'); hero.classList.add('has-art'); hero.insertAdjacentHTML('afterbegin', HERO_ARTS[found.hub] || HERO_ARTS.chart); el.insertAdjacentHTML('beforeend', PAGE_WAVE);
  const body = el.querySelector('[data-body]');
  body.innerHTML = `<nav class="radar-tabs hub-tabs card fade-in" data-n="${def.tabs.length}" aria-label="${esc(t(`tools.${def.title}.title`))}">${def.tabs.map((x) => `<a href="#/app/${x.id}" class="${x.id === found.id ? 'is-on' : ''}" ${x.id === found.id ? 'aria-current="page"' : ''}>${icons[x.icon]}<span>${esc(t(`tools.hub.${x.label}`))}</span></a>`).join('')}</nav><div class="tool-body radar-pane" data-pane></div>`;
  const pane = body.querySelector('[data-pane]');
  // v233: many tabs scroll sideways on phones — bring the open one into view (horizontal only, the page does not jump)
  requestAnimationFrame(() => { const nav = body.querySelector('.radar-tabs'); const a = nav?.querySelector('.is-on'); if (!a || nav.scrollWidth <= nav.clientWidth) return;
    const nr = nav.getBoundingClientRect(), ar = a.getBoundingClientRect(); nav.scrollLeft += (ar.left + ar.width / 2) - (nr.left + nr.width / 2); });
  const tab = found.tab;
  if (!canTab(tab.id)) pane.innerHTML = lockedCard(TAB_FEATURE[tab.id]);
  else if (tab.render) {
    // A full page used as a tab: drop its own header (the hub already has one).
    const child = tab.render(ctx);
    child.querySelector(':scope > .tool-hero, :scope > .subpage-head')?.remove();
    child.classList.remove('page-enter');
    pane.append(child);
  } else tab.mount(el, pane);
  return el;
}
