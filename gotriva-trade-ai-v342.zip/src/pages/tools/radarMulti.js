// Gotriva Radar — multi-screen live analysis: up to 6 live charts side by side, each with its own
// asset and timeframe, automatic support/resistance lines, the strategy setup and a live reading
// (direction, score, trend, RSI, momentum, SMC). Presets: one asset on 4 timeframes, or 4 assets.
import { esc, fmtNum, fmtPct } from '../../utils/dom.js';
import { icons } from '../../components/icons.js';
import { t } from '../../i18n/index.js';
import { storage } from '../../utils/storage.js';
import { store } from '../../state/store.js';
import { navigate } from '../../router.js';
import { INSTRUMENTS, getInstrument } from '../../config/instruments.js';
import { getCandles, isUnavailable } from '../../services/market/index.js';
import { openLiveCandles } from '../../services/market/liveFeed.js';
import { ema } from '../../indicators/index.js';
import { supportResistance } from '../../indicators/levels.js';
import { radarScore } from '../../services/radarScore.js';
import { createMiniChart } from '../../components/chart/miniChart.js';

const yieldTask = () => new Promise((r) => setTimeout(r, 0));
import { onUnmount } from './common.js';

const TFS = ['5m', '15m', '1h', '4h', '1D'];
const LAYOUTS = [1, 2, 4, 6];
const DEFAULT = [['BTCUSDT', '15m'], ['BTCUSDT', '1h'], ['ETHUSDT', '1h'], ['XAUUSD', '1h'], ['SOLUSDT', '1h'], ['BNBUSDT', '4h']];

function createScreen(cfg, onChange) {
  const list = INSTRUMENTS.filter((i) => !isUnavailable(i.symbol));
  const el = document.createElement('article');
  el.className = 'card ms-screen fade-in';
  el.innerHTML = `<div class="ms-head">
      <select class="select ms-sym" aria-label="${esc(t('tools.common.symbol'))}">${list.map((i) => `<option ${i.symbol === cfg.symbol ? 'selected' : ''}>${i.symbol}</option>`).join('')}</select>
      <div class="seg ms-tfs">${TFS.map((tf) => `<button type="button" data-tf="${tf}" class="${tf === cfg.tf ? 'is-on' : ''}">${esc(t(`perf.tfShort.${tf}`))}</button>`).join('')}</div>
      <span class="ms-live" title="Live"><i></i></span>
      <span class="ms-px"><b class="mono" data-px>—</b><small class="mono" data-chg></small></span>
      <button type="button" class="btn btn-icon btn-ghost btn-sm ms-open" title="${esc(t('tools.radar.open'))}">${icons.candles}</button>
    </div>
    <div class="ms-chart"><div class="ms-loading"><span class="spinner"></span></div></div>
    <div class="ms-ana" data-ana></div>`;
  const chartBox = el.querySelector('.ms-chart');
  const chart = createMiniChart(chartBox, { precision: getInstrument(cfg.symbol).precision, compact: true });
  let candles = []; let ds = null; let feed = null; let lastHeavy = 0; let token = 0; let lastLight = 0;

  const ana = el.querySelector('[data-ana]');
  function draw(score, sr) {
    const inst = getInstrument(cfg.symbol);
    const p = (v) => fmtNum(v, inst.precision);
    const long = score?.direction === 'long';
    const ns = sr?.supports[0]; const nr = sr?.resistances[0];
    const lines = [];
    (sr?.supports || []).slice(0, 2).forEach((l, i) => lines.push({ price: l.price, color: `rgba(34,197,94,${0.55 + l.strength * 0.09})`, width: l.strength >= 4 ? 2 : 1, title: `S${i + 1}` }));
    (sr?.resistances || []).slice(0, 2).forEach((l, i) => lines.push({ price: l.price, color: `rgba(240,68,79,${0.55 + l.strength * 0.09})`, width: l.strength >= 4 ? 2 : 1, title: `R${i + 1}` }));
    if (score?.setup) {
      lines.push({ price: score.setup.entry, color: '#fbbf24', width: 2, style: 0, title: t('plan.entry') });
      lines.push({ price: score.setup.stop, color: '#f0444f', width: 1, style: 0, title: 'SL' });
      score.setup.targets.forEach((x, k) => lines.push({ price: x, color: '#22c55e', width: 1, style: 0, title: `TP${k + 1}`, axis: k === 0 }));
    }
    chart.setLines(lines);
    if (!score) { ana.innerHTML = `<span class="muted">${esc(t('tools.multi.noData'))}</span>`; return; }
    const trendTxt = score.trend >= 1 ? t('tools.radar.up') : score.trend <= -1 ? t('tools.radar.down') : score.trend > 0 ? t('tools.radar.upWeak') : t('tools.radar.downWeak');
    ana.innerHTML = `<span class="badge ${long ? 'badge-live' : 'badge-error'}">${esc(t(long ? 'common.long' : 'common.short'))} · ${score.score.toFixed(0)}</span>
      <span class="ms-chip ${score.trend > 0 ? 'up' : 'down'}">${esc(trendTxt)}</span>
      <span class="ms-chip">RSI <b>${fmtNum(score.rsi, 0)}</b></span>
      ${score.event ? `<span class="ms-chip ${score.event.dir === 'bull' ? 'up' : 'down'}">${score.event.kind} ${score.event.dir === 'bull' ? '↑' : '↓'}</span>` : ''}
      ${ns ? `<span class="ms-chip up">S <b class="mono">${p(ns.price)}</b> <small><bdi>${fmtPct(ns.distPct)}</bdi></small></span>` : ''}
      ${nr ? `<span class="ms-chip down">R <b class="mono">${p(nr.price)}</b> <small><bdi>${fmtPct(nr.distPct)}</bdi></small></span>` : ''}
      ${score.setup ? `<span class="ms-chip setup">${esc(t(score.setup.status === 'active' ? 'tools.radar.active' : 'tools.radar.pending'))}</span>` : ''}`;
    el.dataset.dir = score.direction;
    el.classList.toggle('is-long', long); el.classList.toggle('is-short', !long);
  }

  function analyze(heavy) {
    if (!ds || candles.length < 220) { draw(null, null); return; }
    const now = Date.now();
    if (!heavy && now - lastLight < 4000) return; // the forming candle: light refresh every 4 s
    lastLight = now;
    const sr = supportResistance(candles);
    if (heavy || now - lastHeavy > 30_000 || !el._score) { el._score = radarScore({ ...ds, candles }, store.get('settings')); lastHeavy = now; }
    draw(el._score, sr);
    onChange?.();
  }

  function price(c) {
    const inst = getInstrument(cfg.symbol);
    el.querySelector('[data-px]').textContent = fmtNum(c.close, inst.precision);
    const prev = candles.at(-2)?.close;
    const ch = el.querySelector('[data-chg]');
    if (prev) { const v = (c.close / prev - 1) * 100; ch.textContent = fmtPct(v); ch.className = `mono ${v >= 0 ? 'up' : 'down'}`; }
  }

  async function load() {
    const my = ++token;
    feed?.close(); feed = null;
    el._score = null;
    chartBox.querySelector('.ms-loading')?.removeAttribute('hidden');
    chart.setPrecision(getInstrument(cfg.symbol).precision);
    try {
      const d = await getCandles(cfg.symbol, cfg.tf);
      // Up to six screens arrive together: give each its own turn (a task per chart, then one for its analysis) so opening the page never blocks taps.
      await yieldTask();
      if (my !== token) return;
      ds = d; candles = d.candles.slice();
      chart.setData(candles, ema(candles.map((c) => c.close), 50));
      chart.showLast(120);
      el.classList.toggle('is-demo', d.mode !== 'live');
      price(candles.at(-1));
      await yieldTask();
      if (my !== token) return;
      analyze(true);
      feed = openLiveCandles(cfg.symbol, cfg.tf, {
        onStatus: (s) => el.classList.toggle('is-live', s === 'open'),
        onCandle: (c) => {
          if (my !== token || !candles.length) return;
          const last = candles.at(-1);
          let closed = false;
          if (c.time > last.time) { candles.push(c); if (candles.length > 600) candles.shift(); closed = true; } else if (c.time === last.time) candles[candles.length - 1] = { ...last, ...c };
          else return;
          chart.update(c);
          price(c);
          analyze(closed);
        },
      });
    } catch {
      ana.innerHTML = `<span class="down">${esc(t('tools.multi.noData'))}</span>`;
    } finally { chartBox.querySelector('.ms-loading')?.setAttribute('hidden', ''); }
  }

  el.querySelector('.ms-sym').addEventListener('change', (e) => { cfg.symbol = e.target.value; onChange?.(true); load(); });
  el.querySelector('.ms-tfs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tf]'); if (!b || b.dataset.tf === cfg.tf) return;
    cfg.tf = b.dataset.tf;
    el.querySelectorAll('.ms-tfs button').forEach((x) => x.classList.toggle('is-on', x === b));
    onChange?.(true); load();
  });
  el.querySelector('.ms-open').addEventListener('click', () => { store.set('timeframe', cfg.tf); store.set('symbol', cfg.symbol); navigate('#/app'); });
  load();
  return { el, cfg, get score() { return el._score; }, destroy() { token++; feed?.close(); chart.destroy(); }, theme: () => chart.theme() };
}

export function mountMulti(page, body) {
  const saved = storage.get('radar-multi', {});
  const st = { layout: LAYOUTS.includes(saved.layout) ? saved.layout : (innerWidth < 700 ? 2 : 4), screens: DEFAULT.map(([symbol, tf], i) => ({ symbol, tf, ...(saved.screens?.[i] || {}) })) };
  st.screens.forEach((s) => { if (isUnavailable(s.symbol) || !INSTRUMENTS.some((i) => i.symbol === s.symbol)) s.symbol = 'BTCUSDT'; });
  const save = () => storage.set('radar-multi', { layout: st.layout, screens: st.screens.map(({ symbol, tf }) => ({ symbol, tf })) });
  body.innerHTML = `
    <div class="card perf-controls fade-in ms-controls">
      <div class="perf-field"><span>${esc(t('tools.multi.layout'))}</span><div class="seg" data-layout>${LAYOUTS.map((n) => `<button type="button" data-v="${n}" class="${n === st.layout ? 'is-on' : ''}"><span class="ms-ico ms-ico-${n}"></span>${n}</button>`).join('')}</div></div>
      <div class="tool-actions">
        <button type="button" class="btn btn-sm" data-preset="mtf">${icons.grid}<span>${esc(t('tools.multi.presetMtf'))}</span></button>
        <button type="button" class="btn btn-sm" data-preset="assets">${icons.bars}<span>${esc(t('tools.multi.presetAssets'))}</span></button>
      </div>
    </div>
    <div class="card ms-verdict fade-in" data-verdict></div>
    <div class="ms-grid" data-grid></div>
    <p class="muted tool-note">${esc(t('tools.multi.note'))}</p>`;
  const grid = body.querySelector('[data-grid]');
  let screens = [];

  function verdict() {
    const active = screens.filter((s) => s.score);
    const box = body.querySelector('[data-verdict]');
    if (!active.length) { box.innerHTML = `<span class="spinner"></span><span class="muted">${esc(t('tools.multi.reading'))}</span>`; return; }
    const sameSym = new Set(screens.map((s) => s.cfg.symbol)).size === 1;
    const longs = active.filter((s) => s.score.direction === 'long').length;
    const shorts = active.length - longs;
    const agree = Math.max(longs, shorts);
    const dir = longs >= shorts ? 'long' : 'short';
    const strong = agree === active.length && active.length > 1;
    box.className = `card ms-verdict ${strong ? (dir === 'long' ? 'is-long' : 'is-short') : 'is-mixed'}`;
    box.innerHTML = `<span class="ms-v-ico">${icons.radar}</span><div><b>${esc(sameSym
      ? t(strong ? 'tools.multi.alignedMtf' : 'tools.multi.mixedMtf', { s: screens[0].cfg.symbol, n: agree, total: active.length, d: t(dir === 'long' ? 'common.long' : 'common.short') })
      : t('tools.multi.summary', { l: longs, s: shorts }))}</b>
      <span class="muted">${esc(t(sameSym ? (strong ? 'tools.multi.alignedHint' : 'tools.multi.mixedHint') : 'tools.multi.assetsHint'))}</span></div>
      <div class="ms-dots">${active.map((s) => `<i class="${s.score.direction}" title="${s.cfg.symbol} ${s.cfg.tf}"></i>`).join('')}</div>`;
  }
  let vTimer = null;
  const onChange = (cfgChanged) => { if (cfgChanged) save(); clearTimeout(vTimer); vTimer = setTimeout(verdict, 250); };

  function build() {
    screens.forEach((s) => s.destroy());
    grid.replaceChildren();
    grid.dataset.n = st.layout;
    screens = st.screens.slice(0, st.layout).map((cfg) => createScreen(cfg, onChange));
    screens.forEach((s, i) => { s.el.style.animationDelay = `${i * 70}ms`; grid.append(s.el); });
    verdict();
  }
  body.querySelector('[data-layout]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]'); if (!b) return;
    st.layout = Number(b.dataset.v); save();
    body.querySelectorAll('[data-layout] button').forEach((x) => x.classList.toggle('is-on', x === b));
    build();
  });
  body.querySelectorAll('[data-preset]').forEach((b) => b.addEventListener('click', () => {
    const sym = st.screens[0].symbol;
    if (b.dataset.preset === 'mtf') {
      ['15m', '1h', '4h', '1D', '5m', '1h'].forEach((tf, i) => { st.screens[i] = { symbol: sym, tf }; });
    } else {
      const syms = INSTRUMENTS.filter((i) => !isUnavailable(i.symbol)).map((i) => i.symbol);
      const tf = st.screens[0].tf;
      st.screens = st.screens.map((s, i) => ({ symbol: syms[i % syms.length], tf }));
    }
    if (st.layout < 4) { st.layout = 4; body.querySelectorAll('[data-layout] button').forEach((x) => x.classList.toggle('is-on', x.dataset.v === '4')); }
    save(); build();
  }));
  build();
  const offTheme = store.on('theme', () => screens.forEach((s) => s.theme()));
  onUnmount(page, () => { screens.forEach((s) => s.destroy()); offTheme(); });
}
