// Sign-in, sign-up and password-recovery screens (left side of the reference).
import { h, esc } from '../utils/dom.js';
import { icons, logoMark } from '../components/icons.js';
import { t, getLang, setLang, LANGS } from '../i18n/index.js';
import { auth, validate } from '../services/auth/index.js';
import { authErrorMessage } from '../services/auth/errors.js';
import { authConfig } from '../config/auth.js';
import { navigate } from '../router.js';
import { playLoginIntro } from '../components/loginIntro.js';
import { phoneFieldHtml, bindPhoneField } from '../components/phoneField.js';
import { savePhone } from '../services/members.js';
import { mailSignin } from '../services/mail.js';

const WAVES = `<svg class="auth-waves" viewBox="0 0 440 900" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
  <defs>
    <linearGradient id="wv1" x1="0" x2="1"><stop offset="0" class="lg-a0" stop-opacity="0"/><stop offset=".45" class="lg-a2"/><stop offset="1" class="lg-a0" stop-opacity=".1"/></linearGradient>
    <linearGradient id="wv2" x1="0" x2="1"><stop offset="0" class="lg-a0" stop-opacity=".1"/><stop offset=".6" class="lg-a2"/><stop offset="1" class="lg-a3" stop-opacity="0"/></linearGradient>
  </defs>
  <g>
    <path class="w-glow" d="M-40 300 C 60 250, 140 360, 240 320 S 400 250, 500 300" stroke="url(#wv1)" stroke-width="5"/>
    <path d="M-40 300 C 60 250, 140 360, 240 320 S 400 250, 500 300" stroke="url(#wv1)" stroke-width="1.6"/>
    <path d="M-40 318 C 70 270, 150 380, 250 338 S 410 268, 500 318" stroke="url(#wv2)" stroke-width="1" opacity=".7"/>
    <path d="M-40 336 C 80 290, 160 396, 260 356 S 420 286, 500 336" stroke="url(#wv1)" stroke-width=".8" opacity=".5"/>
  </g>
  <g>
    <path class="w-glow" d="M-40 820 C 80 760, 180 860, 300 800 S 440 760, 500 790" stroke="url(#wv2)" stroke-width="5"/>
    <path d="M-40 820 C 80 760, 180 860, 300 800 S 440 760, 500 790" stroke="url(#wv2)" stroke-width="1.4"/>
    <path d="M-40 840 C 90 780, 190 880, 310 820 S 450 780, 500 810" stroke="url(#wv1)" stroke-width=".8" opacity=".6"/>
  </g>
  <!-- Light pulses travelling along the waves -->
  <path class="w-run" d="M-40 300 C 60 250, 140 360, 240 320 S 400 250, 500 300" pathLength="100"/>
  <path class="w-run w-run2" d="M-40 820 C 80 760, 180 860, 300 800 S 440 760, 500 790" pathLength="100"/>
</svg>`;

/* Moving background: drifting aurora light, a perspective grid that flows toward the viewer,
   a strip of candles scrolling past with a live price line, light pulses along the waves and
   rising sparks. Everything is transform/opacity only (cheap on phones) and stops under reduced motion. */
function candleStrip() {
  // Deterministic pseudo-random walk so the strip looks like a real chart and tiles seamlessly.
  let seed = 7;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const n = 36;
  const w = 12;
  let price = 60;
  const bars = [];
  const pts = [];
  for (let i = 0; i < n; i++) {
    const back = i > n - 6 ? (60 - price) * 0.3 : 0; // ends near where it started so the loop joins
    const open = price;
    const close = Math.max(18, Math.min(102, open + (rnd() - 0.48) * 16 + back));
    const hi = Math.max(open, close) + rnd() * 7;
    const lo = Math.min(open, close) - rnd() * 7;
    const x = i * w + 3;
    const up = close >= open;
    bars.push(`<line x1="${x + 3}" x2="${x + 3}" y1="${hi.toFixed(1)}" y2="${lo.toFixed(1)}" class="${up ? 'cu' : 'cd'}"/><rect x="${x}" y="${Math.min(open, close).toFixed(1)}" width="6" height="${Math.max(1.5, Math.abs(close - open)).toFixed(1)}" rx="1" class="${up ? 'cu' : 'cd'}"/>`);
    pts.push(`${x + 3},${close.toFixed(1)}`);
    price = close;
  }
  const W = n * w;
  const one = `<g>${bars.join('')}<polyline class="cl" points="${pts.join(' ')}"/></g>`;
  return `<svg class="fx-candles" viewBox="0 0 ${W * 2} 120" preserveAspectRatio="none" aria-hidden="true">${one}<g transform="translate(${W} 0)">${one}</g></svg>`;
}
// Sparks spread over the page with varied timing and size (fixed pattern, no layout shift).
const SPARKS = Array.from({ length: 24 }, (_, i) => {
  const x = (i * 37 + 11) % 97;
  const y = (i * 53 + 7) % 95;
  return `<i style="--x:${x}%;--y:${y}%;--d:${((i * 0.73) % 7).toFixed(2)}s;--s:${2 + (i % 3)}px;--t:${6 + (i % 4) * 1.5}s"></i>`;
}).join('');
const FX = `<div class="auth-fx" aria-hidden="true">
  <i class="fx-blob fx-b1"></i><i class="fx-blob fx-b2"></i><i class="fx-blob fx-b3"></i>
  <i class="fx-beam"></i>
  <div class="fx-grid"></div>
  <div class="fx-strip">${candleStrip()}</div>
</div>`;

// Feature icons are built from separate parts so each can move: the shield's tick draws itself,
// the bars rise and fall like a live analysis, the trend line traces across, the bolt flashes.
const FEATURE_ICONS = {
  shield: '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="fi-shield" fill="currentColor" d="M12 2 4 5.2v6c0 5 3.4 9.4 8 10.8 4.6-1.4 8-5.8 8-10.8v-6Z"/><path class="fi-tick" d="m8.5 12 2.5 2.5 4.5-5" fill="none" stroke="#0d0c19" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" pathLength="1"/></svg>',
  bars: '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="currentColor"><rect class="fi-bar fi-b1" x="3" y="13" width="4" height="8" rx="1"/><rect class="fi-bar fi-b2" x="10" y="9" width="4" height="12" rx="1"/><rect class="fi-bar fi-b3" x="17" y="5" width="4" height="16" rx="1"/></g><path class="fi-trend" d="M3 10 9 5l4 3 7-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" pathLength="1"/></svg>',
  bolt: '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="fi-bolt" fill="currentColor" d="M14 1 4 14h7l-1.5 9L20 9.5h-7Z"/></svg>',
};
const FACT_ICONS = ['candles', 'chat', 'trophy'];
const feature = (kind, text, i) => `<div class="feat feat-${kind}" style="--i:${i}"><span class="feat-icon">${FEATURE_ICONS[kind]}<i class="feat-ring"></i></span><span class="feat-text">${esc(text)}</span></div>`;

function field({ name, type = 'text', icon, labelKey, autocomplete }) {
  const isPw = type === 'password';
  return `<div class="field-wrap">
    <label class="field" data-field="${name}">
      <span class="visually-hidden">${esc(t(labelKey))}</span>
      <span class="field-icon">${icons[icon]}</span>
      <input name="${name}" type="${type}" placeholder="${esc(t(labelKey))}" autocomplete="${autocomplete}" ${type === 'email' ? 'inputmode="email"' : ''}/>
      ${isPw ? `<button type="button" class="field-action" data-toggle-pw aria-label="show/hide">${icons.eye}</button>` : ''}
    </label>
    <p class="field-error" data-error-for="${name}" role="alert"></p>
  </div>`;
}

function formHtml(mode) {
  if (mode === 'signup') {
    return `<h2>${esc(t('auth.signUpTitle'))}</h2><p class="sub">${esc(t('auth.signUpSub'))}</p>
    <form class="auth-form" novalidate>
      ${field({ name: 'name', icon: 'user', labelKey: 'auth.name', autocomplete: 'name' })}
      ${field({ name: 'email', type: 'email', icon: 'mail', labelKey: 'auth.email', autocomplete: 'email' })}
      ${phoneFieldHtml()}
      ${field({ name: 'password', type: 'password', icon: 'lock', labelKey: 'auth.password', autocomplete: 'new-password' })}
      ${field({ name: 'confirm', type: 'password', icon: 'lock', labelKey: 'auth.confirmPassword', autocomplete: 'new-password' })}
      <div data-form-msg></div>
      <button class="btn btn-primary" type="submit"><span data-label>${esc(t('auth.signUp'))}</span><span class="flip-rtl">${icons.arrow}</span></button>
    </form>
    <p class="auth-foot">${esc(t('auth.haveAccount'))}<a href="#/login">${esc(t('auth.signIn'))}</a></p>
    <p class="auth-legal">${esc(t('lg.agree'))} <a href="#/legal">${esc(t('lg.tabs.terms'))}</a> ${esc(t('lg.and'))}<a href="#/legal/privacy">${esc(t('lg.tabs.privacy'))}</a>.</p>`;
  }
  if (mode === 'forgot') {
    return `<h2>${esc(t('auth.resetTitle'))}</h2><p class="sub">${esc(t('auth.resetSub'))}</p>
    <form class="auth-form" novalidate data-stage="request">
      ${field({ name: 'email', type: 'email', icon: 'mail', labelKey: 'auth.email', autocomplete: 'email' })}
      <div class="reset-local" hidden>${field({ name: 'password', type: 'password', icon: 'lock', labelKey: 'auth.newPassword', autocomplete: 'new-password' })}</div>
      <div data-form-msg></div>
      <button class="btn btn-primary" type="submit"><span data-label>${esc(t('auth.sendReset'))}</span><span class="flip-rtl">${icons.arrow}</span></button>
    </form>
    <p class="auth-foot"><a href="#/login">${esc(t('auth.backToSignIn'))}</a></p>`;
  }
  const prov = (p, label) => {
    const ok = auth.providerConfigured(p);
    return `<button type="button" class="btn ${ok ? '' : 'not-configured'}" data-provider="${p}">${icons[p]}<span>${esc(t(label))}</span>${ok ? '' : `<span class="tag">${esc(t('common.notConfigured'))}</span>`}</button>`;
  };
  return `<h2>${esc(t('auth.signInTitle'))}</h2><p class="sub">${esc(t('auth.welcome'))}</p>
    <form class="auth-form" novalidate>
      ${field({ name: 'email', type: 'email', icon: 'mail', labelKey: 'auth.email', autocomplete: 'email' })}
      ${field({ name: 'password', type: 'password', icon: 'lock', labelKey: 'auth.password', autocomplete: 'current-password' })}
      <div class="auth-row">
        <label class="checkbox"><input type="checkbox" name="remember" checked/><span>${esc(t('auth.remember'))}</span></label>
        <a href="#/forgot">${esc(t('auth.forgot'))}</a>
      </div>
      <div data-form-msg></div>
      <button class="btn btn-primary" type="submit"><span data-label>${esc(t('auth.signIn'))}</span><span class="flip-rtl">${icons.arrow}</span></button>
    </form>
    <button type="button" class="btn face-btn" data-face hidden>${icons.face}<span>${esc(getLang() !== 'ar' ? 'Sign in with Face ID' : 'الدخول بالوجه (Face ID)')}</span></button>
    <div class="auth-divider">${esc(t('common.or'))}</div>
    <div class="oauth">${prov('google', 'auth.google')}${prov('apple', 'auth.apple')}</div>
    <p class="auth-foot">${esc(t('auth.noAccount'))}<a href="#/signup">${esc(t('auth.createAccount'))}</a></p>
    <p class="auth-legal">${esc(t('lg.agree'))} <a href="#/legal">${esc(t('lg.tabs.terms'))}</a> ${esc(t('lg.and'))}<a href="#/legal/privacy">${esc(t('lg.tabs.privacy'))}</a>.</p>`;
}

export function renderAuthPage(container, mode) {
  const page = h(`<main class="auth-page page-enter">${FX}${WAVES}
    <div class="auth-sparks" aria-hidden="true">${SPARKS}</div>
    <div class="auth-col">
      <div class="auth-top">
        <div class="lang-select">
          <span class="lang-globe">${icons.globe}</span>
          <select aria-label="Language" data-lang-select>${LANGS.map(([k, n]) => `<option value="${k}" ${getLang() === k ? 'selected' : ''}>${n}</option>`).join('')}</select>
          <span class="lang-chevron">${icons.chevronDown}</span>
        </div>
      </div>
      <header class="auth-brand"><span class="logo-halo logo-halo-lg">${logoMark(78)}</span>
        <h1 class="brand-glow">GOTRIVA TRADE <span class="brand-ai">AI</span></h1>
        <p class="tagline">${esc(t('app.tagline'))}</p>
        <p class="subtagline">${esc(t('app.subtagline'))}</p>
      </header>
      <section class="card auth-card">${formHtml(mode)}
        <div class="alert alert-info auth-note">${icons.info}<div>${esc(authConfig.firebaseConfigured ? t('auth.firebaseNote') : t('auth.demoAuthNote'))}</div></div>
      </section>
      <section class="auth-showcase">
        <ul class="auth-facts">${t('auth.facts').map(([title, body], i) => `<li><span class="af-ico" aria-hidden="true">${icons[FACT_ICONS[i]]}</span><span><b>${esc(title)}</b><small>${esc(body)}</small></span></li>`).join('')}</ul>
      </section>
    </div></main>`);
  container.replaceChildren(page);

  page.querySelector('[data-lang-select]')?.addEventListener('change', (e) => setLang(e.target.value));
  page.querySelectorAll('[data-toggle-pw]').forEach((b) => b.addEventListener('click', () => {
    const input = b.parentElement.querySelector('input');
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    b.innerHTML = show ? icons.eyeOff : icons.eye;
  }));

  const form = page.querySelector('form');
  const submit = form.querySelector('[type=submit]');
  const msg = form.querySelector('[data-form-msg]');
  const phone = mode === 'signup' ? bindPhoneField(form.querySelector('.phone-wrap')) : null;

  const showMsg = (text, type = 'error') => {
    msg.innerHTML = text ? `<div class="alert alert-${type}">${type === 'error' ? icons.alert : icons.check}<div>${esc(text)}</div></div>` : '';
  };
  const setErrors = (errs) => {
    form.querySelectorAll('[data-error-for]').forEach((p) => {
      const key = errs[p.dataset.errorFor];
      p.textContent = key ? t(`auth.err.${key}`, { n: authConfig.minPasswordLength }) : '';
      p.closest('.field-wrap').querySelector('.field').classList.toggle('has-error', Boolean(key));
    });
    const first = Object.keys(errs)[0];
    if (first) form.querySelector(`[name=${first}]`)?.focus();
  };
  const busy = (on, labelKey) => {
    submit.disabled = on;
    submit.classList.toggle('is-loading', on);
    submit.querySelector('[data-label]').textContent = t(labelKey);
    submit.querySelector('.flip-rtl').innerHTML = on ? '<span class="spinner"></span>' : icons.arrow;
    form.setAttribute('aria-busy', String(on));
  };
  // Clear a field's error as the user fixes it.
  form.addEventListener('input', (e) => {
    const p = form.querySelector(`[data-error-for="${e.target.name}"]`);
    if (p && p.textContent) { p.textContent = ''; p.closest('.field-wrap').querySelector('.field').classList.remove('has-error'); }
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    showMsg('');
    const v = Object.fromEntries(new FormData(form));
    if (mode === 'signin') {
      const errs = validate({ email: v.email, password: v.password }, 'signin');
      setErrors(errs);
      if (Object.keys(errs).length) return;
      busy(true, 'auth.signingIn');
      try {
        await auth.signIn(v.email, v.password, form.remember.checked);
        mailSignin(); playLoginIntro(auth.current()?.name, () => navigate('#/app'));
      } catch (err) { showMsg(authErrorMessage(err, t)); busy(false, 'auth.signIn'); }
    } else if (mode === 'signup') {
      const errs = validate({ name: v.name, email: v.email, password: v.password, confirm: v.confirm }, 'signup');
      setErrors(errs);
      const ph = phone.validate();                       // strict per-country check (the server checks it again)
      if (!ph.ok && !Object.keys(errs).length) phone.focus();
      if (Object.keys(errs).length || !ph.ok) return;
      busy(true, 'auth.signingUp');
      try {
        await auth.signUp(v.name, v.email, v.password);
        savePhone({ e164: ph.e164, iso: ph.iso }).catch(() => {});   // kept and retried if the server is unreachable
        mailSignin(); playLoginIntro(auth.current()?.name || v.name, () => navigate('#/app'));
      } catch (err) { showMsg(authErrorMessage(err, t)); busy(false, 'auth.signUp'); }
    } else if (mode === 'forgot') {
      const stage = form.dataset.stage;
      if (stage === 'request') {
        const errs = validate({ email: v.email }, 'reset');
        setErrors(errs);
        if (Object.keys(errs).length) return;
        busy(true, 'auth.sending');
        try {
          const res = await auth.requestReset(v.email);
          if (res.demo) {
            form.dataset.stage = 'local';
            form.querySelector('.reset-local').hidden = false;
            form.email.readOnly = true;
            showMsg(t('auth.resetDemo'), 'success');
            busy(false, 'auth.setNewPassword');
            form.password.focus();
          } else {
            showMsg(t('auth.resetSent'), 'success');
            busy(false, 'auth.sendReset');
          }
        } catch (err) { showMsg(authErrorMessage(err, t)); busy(false, 'auth.sendReset'); }
      } else {
        const errs = validate({ password: v.password }, 'reset');
        setErrors(errs);
        if (Object.keys(errs).length) return;
        busy(true, 'auth.sending');
        try {
          await auth.localResetPassword(v.email, v.password);
          showMsg(t('auth.resetDone'), 'success');
          setTimeout(() => navigate('#/login'), 900);
        } catch (err) { showMsg(authErrorMessage(err, t)); busy(false, 'auth.setNewPassword'); }
      }
    }
  });

  // Face sign-in: shown only on devices with a built-in face / fingerprint unlock
  const faceBtn = page.querySelector('[data-face]');
  if (faceBtn) import('../services/faceLogin.js').then(async (F) => {
    if (!(await F.faceSupported())) return;
    faceBtn.hidden = false; if (F.faceHint()) faceBtn.classList.add('is-ready');
    // One-button start screen: this device already turned on face sign-in → show a big "Start" button first
    const card = page.querySelector('.auth-card');
    if (mode === 'signin' && F.faceHint() && card) {
      const en = getLang() !== 'ar';
      const box = h(`<div class="face-start"><h2>${esc(en ? 'Welcome back' : 'أهلاً فيك من جديد')}</h2>
        <p class="sub">${esc(en ? 'Tap Start and look at your device. Only the face you saved on this device can open your account.' : 'اضغط ابدأ وطلّ على جهازك. بس الوجه المحفوظ على هالجهاز بيفتح حسابك.')}</p>
        <button type="button" class="btn btn-primary face-start-btn" data-face-start>${icons.face}<span>${esc(en ? 'Start' : 'ابدأ')}</span></button>
        <button type="button" class="face-start-alt" data-face-alt>${esc(en ? 'Use e-mail or another method' : 'استخدم الإيميل أو طريقة ثانية')}</button></div>`);
      card.classList.add('face-first'); card.prepend(box);
      box.querySelector('[data-face-alt]').addEventListener('click', () => { card.classList.remove('face-first'); box.remove(); });
      box.querySelector('[data-face-start]').addEventListener('click', () => faceBtn.click());
    }
    faceBtn.addEventListener('click', async () => {
      showMsg(''); const original = faceBtn.innerHTML; faceBtn.disabled = true; faceBtn.innerHTML = '<span class="spinner"></span>';
      try { await F.faceSignIn(); mailSignin(); playLoginIntro(auth.current()?.name, () => navigate('#/app')); }
      catch (err) {
        const en = getLang() !== 'ar';
        const m = { cancelled: en ? 'Face check cancelled.' : 'انلغى فحص الوجه.', unknown_credential: en ? 'Face sign-in is not turned on for this account on this device. Sign in with your password, then turn it on in Profile.' : 'الدخول بالوجه مش مفعّل لهالحساب على هالجهاز. ادخل بكلمة المرور وفعّله من الملف الشخصي.', not_configured: en ? 'Face sign-in is not set up on this site yet.' : 'الدخول بالوجه لسا مش مجهّز على الموقع.', too_many_attempts: en ? 'Too many tries. Wait 10 minutes.' : 'محاولات كثيرة. استنى 10 دقايق.' }[err?.code];
        showMsg(m || authErrorMessage(err, t));
        const fc = page.querySelector('.auth-card.face-first'); if (fc) { fc.classList.remove('face-first'); fc.querySelector('.face-start')?.remove(); }
      } finally { faceBtn.disabled = false; faceBtn.innerHTML = original; }
    });
  }).catch(() => {});
  page.querySelectorAll('[data-provider]').forEach((b) => b.addEventListener('click', async () => {
    showMsg('');
    const original = b.innerHTML;
    b.disabled = true;
    b.innerHTML = '<span class="spinner"></span>';
    try {
      await auth.signInWithProvider(b.dataset.provider);
      mailSignin(); playLoginIntro(auth.current()?.name, () => navigate('#/app'));
    } catch (err) {
      showMsg(authErrorMessage(err, t));
    } finally {
      b.disabled = false;
      b.innerHTML = original;
    }
  }));
}
