// v334: hero illustrations for the hub pages and the signals channel (owner's reference pictures).
// Original vector art drawn for GOTRIVA TRADE AI — no external images, no other brands. Decorative only (aria-hidden).

const candles = (x0, y0, n, step, seed = 1) => {
  let y = y0; let out = '';
  for (let i = 0; i < n; i++) {
    const up = ((i * 7 + seed * 3) % 5) !== 0;
    const h = 10 + ((i * 13 + seed) % 14);
    y += up ? -6 : 5;
    const x = x0 + i * step;
    out += `<path d="M${x + 3} ${y - 6}v${h + 12}" stroke="${up ? '#ac7bf4' : '#854bf0'}" stroke-width="1.2" opacity=".75"/>`
      + `<rect x="${x}" y="${y}" width="6" height="${h}" rx="1.2" fill="${up ? 'url(#haUp)' : 'url(#haDn)'}" opacity="${0.45 + (i / n) * 0.5}"/>`;
  }
  return out;
};

const DEFS = `<defs>
  <linearGradient id="haUp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b884f5"/><stop offset="1" stop-color="#6b13ec"/></linearGradient>
  <linearGradient id="haDn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#905af2"/><stop offset="1" stop-color="#481a9d"/></linearGradient>
  <radialGradient id="haGlow" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#6b13ec" stop-opacity=".55"/><stop offset="1" stop-color="#6b13ec" stop-opacity="0"/></radialGradient>
  <linearGradient id="haGlass" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity=".22"/><stop offset=".5" stop-color="#6b13ec" stop-opacity=".12"/><stop offset="1" stop-color="#ffffff" stop-opacity=".06"/></linearGradient>
  <linearGradient id="haLiquid" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9b5af2" stop-opacity=".85"/><stop offset="1" stop-color="#5310c8" stop-opacity=".9"/></linearGradient>
  <radialGradient id="haSphere" cx="40%" cy="35%" r="65%"><stop offset="0" stop-color="#dfccfb"/><stop offset=".35" stop-color="#8a4bf0"/><stop offset=".8" stop-color="#481a9d"/><stop offset="1" stop-color="#16142a"/></radialGradient>
  <linearGradient id="haBull" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#d3b9f9"/><stop offset=".5" stop-color="#8a4bf0"/><stop offset="1" stop-color="#531fb3"/></linearGradient>
</defs>`;

/* Strategy lab: a glass flask with candles inside, on a glowing ring, candles rising behind it. */
const FLASK = `<svg class="ha-art" viewBox="0 0 300 150" aria-hidden="true" focusable="false">${DEFS}
  <ellipse cx="96" cy="134" rx="80" ry="14" fill="url(#haGlow)"/>
  <ellipse cx="96" cy="132" rx="66" ry="9" fill="none" stroke="#975af2" stroke-width="1.6" opacity=".85"/>
  <ellipse cx="96" cy="132" rx="82" ry="13" fill="none" stroke="#6313ec" stroke-width="1" opacity=".5"/>
  <g>${candles(150, 96, 14, 10, 2)}</g>
  <path d="M80 16h32M84 16v34L48 112q-8 20 14 20h68q22 0 14-20L108 50V16" fill="url(#haGlass)" stroke="#d3bbf9" stroke-width="2" stroke-linejoin="round"/>
  <path d="M60 96h72l10 18q6 14-10 14H60q-16 0-10-14z" fill="url(#haLiquid)" opacity=".85"/>
  <g>${[[66, 104, 12], [76, 98, 20], [86, 108, 10], [96, 94, 24], [106, 102, 16], [116, 98, 18]].map(([x, y, h]) => `<rect x="${x}" y="${y}" width="5" height="${h}" rx="1" fill="#e6d4fc" opacity=".9"/>`).join('')}</g>
  <path d="M90 22v24" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".45"/>
  <circle cx="72" cy="84" r="2.5" fill="#fff" opacity=".7"/><circle cx="112" cy="78" r="1.8" fill="#fff" opacity=".6"/>
</svg>`;

/* News: a glowing wireframe globe with an orbit ring, candles rising behind. */
const GLOBE = `<svg class="ha-art" viewBox="0 0 300 150" aria-hidden="true" focusable="false">${DEFS}
  <g>${candles(156, 92, 13, 10, 5)}</g>
  <circle cx="92" cy="76" r="70" fill="url(#haGlow)"/>
  <circle cx="92" cy="76" r="52" fill="url(#haSphere)" opacity=".92"/>
  <g fill="none" stroke="#dfccfb" stroke-width=".9" opacity=".75">
    <ellipse cx="92" cy="76" rx="52" ry="18"/><ellipse cx="92" cy="76" rx="52" ry="36"/><path d="M40 76h104"/>
    <ellipse cx="92" cy="76" rx="18" ry="52"/><ellipse cx="92" cy="76" rx="36" ry="52"/><path d="M92 24v104"/>
  </g>
  <path d="M70 52q10-8 22-2t18 10q-4 10-16 8t-14 6q-10-4-12-12zM104 88q12-2 18 8t-6 16q-10-4-12-14z" fill="#e8d9fc" opacity=".55"/>
  <ellipse cx="92" cy="80" rx="82" ry="20" fill="none" stroke="#9b5af2" stroke-width="2" opacity=".85" transform="rotate(-12 92 80)"/>
  <circle cx="20" cy="94" r="3" fill="#fff"/><circle cx="168" cy="62" r="2.4" fill="#fff" opacity=".85"/>
</svg>`;

/* Signals channel: a charging low-poly bull with candles and a rising wave behind. */
const BULL = `<svg class="ha-art" viewBox="0 0 300 150" aria-hidden="true" focusable="false">${DEFS}
  <g>${candles(12, 70, 9, 11, 3)}</g>
  <path d="M0 140C60 120 120 130 170 100S260 60 300 40" fill="none" stroke="#6b13ec" stroke-width="1.5" opacity=".6"/>
  <path d="M0 146C70 128 130 138 180 110S270 72 300 54" fill="none" stroke="#9b5af2" stroke-width="1" opacity=".4"/>
  <ellipse cx="160" cy="132" rx="110" ry="14" fill="url(#haGlow)"/>
  <g stroke="#e7d8fc" stroke-width=".8" stroke-linejoin="round">
    <path d="M222 58l26-8 18 4 10 12-6 10-16 2-10 8-8 16-6 22h-8l2-24-14-6-20 6-28 2-14 18-4 18h-8l2-22 8-16-12 4-10 18-2 16h-8l2-20 10-22-6-14 10-20 26-10 34-2 20-6z" fill="url(#haBull)" opacity=".9"/>
    <path d="M150 64l18 18 26-14 12 20 16-34 26 16M118 98l32-34M168 82l-10 30M194 68l2 34M248 50l-8 26" fill="none" opacity=".55"/>
  </g>
  <path d="M248 50q8-18 26-16q-14 4-16 18M262 54q14-10 30-2q-16 0-22 10" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round"/>
  <circle cx="264" cy="64" r="2" fill="#fff"/>
  <path d="M120 70q-24-6-34 12" fill="none" stroke="#d3bbf9" stroke-width="2" stroke-linecap="round"/>
</svg>`;

/* Default for the other hubs (radar, journal, alerts): rising candles and a trend line. */
const CHART = `<svg class="ha-art" viewBox="0 0 300 150" aria-hidden="true" focusable="false">${DEFS}
  <ellipse cx="150" cy="130" rx="130" ry="16" fill="url(#haGlow)"/>
  <g>${candles(40, 112, 20, 11, 4)}</g>
  <path d="M30 128C90 120 130 100 170 84S240 50 280 28" fill="none" stroke="#9b5af2" stroke-width="2.2" stroke-linecap="round"/>
  <path d="M268 22l14 4-6 13" fill="none" stroke="#9b5af2" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

export const HERO_ARTS = { lab: FLASK, news: GLOBE, signals: BULL, chart: CHART };

/* Purple mesh wave at the bottom of a page (same family as the Gotriva AI page). */
export const PAGE_WAVE = `<svg class="pg-wave" viewBox="0 0 900 90" preserveAspectRatio="none" aria-hidden="true" focusable="false">
  <defs><linearGradient id="pgw" x1="0" x2="1"><stop offset="0" stop-color="#6313ec" stop-opacity=".1"/><stop offset=".5" stop-color="#6b13ec" stop-opacity=".9"/><stop offset="1" stop-color="#9b5af2" stop-opacity=".2"/></linearGradient></defs>
  <g fill="none" stroke="url(#pgw)" stroke-width="1">${Array.from({ length: 9 }, (_, i) => `<path d="M0 ${80 - i * 2} C150 ${70 - i * 6} 250 ${30 + i * 2} 450 ${50 - i * 4} S750 ${80 - i * 5} 900 ${60 - i * 3}" opacity="${(0.25 + i * 0.08).toFixed(2)}"/>`).join('')}</g>
</svg>`;

/* Line icons for the market filters (same stroke style as the app's icons). */
const li = (d) => `<i class="ii" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${d}</svg></i>`;
export const CAT_ICONS = {
  all: li('<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/><path d="m3 17.5 9 4.5 9-4.5" opacity=".5"/>'),
  crypto: li('<path d="M9 6v12M9 6h5a3 3 0 010 6H9m0 0h5.5a3 3 0 010 6H9M11 4v2M14 4v2M11 18v2M14 18v2"/>'),
  metal: li('<path d="M3 19l2.2-5h7.6l2.2 5z"/><path d="M9 14l2.2-5h7.6L21 14"/><path d="M6 14l1.2-3"/>'),
  index: li('<path d="M4 20h16"/><rect x="5" y="12" width="3" height="6" rx=".8"/><rect x="10.5" y="8" width="3" height="10" rx=".8"/><rect x="16" y="4" width="3" height="14" rx=".8"/>'),
  energy: li('<path d="M12 3s6 6.5 6 11a6 6 0 01-12 0c0-4.5 6-11 6-11z"/><path d="M9.5 15a2.5 2.5 0 002.5 2.5"/>'),
  forex: li('<path d="M4 8h13l-3-3M20 16H7l3 3"/>'),
  stock: li('<path d="M3 17l5-5 4 3 8-8"/><path d="M15 7h5v5"/>'),
  monitor: li('<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>'),
  server: li('<rect x="4" y="4" width="16" height="6" rx="1.5"/><rect x="4" y="14" width="16" height="6" rx="1.5"/><path d="M8 7h.01M8 17h.01"/>'),
  target: li('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="M12 12l7-7"/>'),
  pulse: li('<path d="M3 12h4l2-6 4 12 2-6h6"/>'),
  clock: li('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'),
  done: li('<circle cx="12" cy="12" r="8.5"/><path d="m8.5 12 2.5 2.5 4.5-5"/>'),
};

/* Strategy-lab picker icons (display only). */
export const STRAT_ICONS = {
  edh: li('<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z"/><path d="M8.5 12h7M12 8.5v7"/>'),
  lbr: li('<path d="M4 20h16"/><rect x="5" y="12" width="3" height="6" rx=".8"/><rect x="10.5" y="8" width="3" height="10" rx=".8"/><rect x="16" y="4" width="3" height="14" rx=".8"/>'),
  classic: li('<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/>'),
  smc: li('<path d="M6 4v16M12 3v18M18 5v14"/><rect x="4.5" y="8" width="3" height="7" rx=".8"/><rect x="10.5" y="6" width="3" height="9" rx=".8"/><rect x="16.5" y="9" width="3" height="6" rx=".8"/>'),
  zone: li('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="M12 12l7-7"/>'),
};
