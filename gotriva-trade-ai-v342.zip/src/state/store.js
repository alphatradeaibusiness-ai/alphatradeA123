import { storage } from '../utils/storage.js';
import { INSTRUMENTS, findInstrument } from '../config/instruments.js';
import { DEFAULT_TIMEFRAME } from '../config/market.js';

// Persisted user settings (indicators, plan rules, point sizes).
export const DEFAULT_SETTINGS = {
  vp: { enabled: true, rows: 40, widthPct: 16, range: 'visible', valueAreaPct: 70, showPoc: true },
  frvp: { enabled: true, from: null, to: null, symbol: null, rows: 30 },
  rsi: { enabled: true, period: 14, overbought: 70, oversold: 30 },
  pressure: { enabled: true, window: 50 },
  fib: { enabled: true, signals: true, strong: true, notify: false, levels: [0, 0.382, 0.618, 1], mode: 'auto', follow: true, symbol: null, lookback: 120, high: null, low: null, highTime: null, lowTime: null },
  zones: { enabled: true },
  // Execution filters (services/execFilters.js) — all off by default; tested on real BTC data, none gave a robust edge.
  edh: { m1: { t1Pips: 30, t2Pips: 70, slPips: 30 }, m5: { t1Pips: 45, t2Pips: 80, slPips: 60 }, maxPerSide: 1, trendHours: 200, confirm5: true, showZones: true, pivLen: 5, dispMult: 2, maxOb: 2, maxSw: 3 },
  exec: { killzone: false, kzLondon: [7, 10], kzNy: [12, 15], silverBullet: false, atrBand: false, atrLo: 0.7, atrHi: 3, sweep: false, sweepBars: 12, cvd: false, voidCheck: false, htfOb: false, anomaly: false, dom: false },
  planLines: { enabled: true },
  ema: { enabled: false },
  bb: { enabled: false, period: 20, mult: 2 },   // Bollinger Bands (display only, never feeds a strategy)
  aview: true,      // full-analysis view: draws the liquidity map (SMC/ICT) and Bollinger Bands for the selected asset, and runs the progress panel
  // stopMode 'atr' (stop = atrMult × ATR, targets tpR × risk) or 'points' (fixed 30 / 50·80·130 points).
  plan: { direction: 'auto', stopMode: 'atr', atrMult: 3, htfTrendHours: 200, tpGapPts: 50, tp3GapPts: 30, tpR: [1, 2, 3.5], trendFilter: true, feePct: null, closeFirstTarget: false, maxPerDay: 0, beAtR: 0, trailAtr: 0 },
  pointSizes: Object.fromEntries(INSTRUMENTS.map((i) => [i.symbol, i.pointSize])),
  chartType: 'candles',
  chartClean: true, // clean view: fewer, lighter overlays
  liqMap: false,    // liquidity map on the chart (BOS/CHoCH, OB, FVG, premium/discount, session highs/lows) for any strategy
  ai: { enabled: true },
  // SMC v2: minimum 0–100 score to publish a trade, kill zones only (London / New York), 4h + Daily structure must agree.
  smc2: { minScore: 80, killZone: true, htf: true, publishUnproven: false, htfMode: 'both', reversal: false, rsiGate: false, minDisp: 1, fvgMin: 0.1, maxAfterTap: 15, stopBufAtr: 0.2, maxRiskAtr: 5 },
  // Zone strategy: supply/demand zones + volume + fixed volume profile + RSI + Fibonacci, scored out of 100.
  zone: { minScore: 80, htf: true, requireVp: true, minVolRatio: 1.3, minRR: 1, quant: true, regimeWeights: true, zGate: 0, flowGate: false },
  // Market-condition gate: block entries in conditions that were proven bad out-of-sample (services/adaptive.js).
  regime: { enabled: false },
  // Strict confirmation engine (services/confirm.js): BUY / SELL only with strong multi-family confluence; otherwise NO TRADE.
  confirm: { enabled: true, maxActive: 2, edhMinRR: 0.6 },
  // Risk guard for the signals channel.
  risk: { enabled: true, dailyLossR: 3, maxActive: 0, maxCorrelated: 2, newsMinutes: 30, streakPause: 3, derivFilter: true, accountSize: 1000, riskPct: 1, dailyLossPct: 2, corrDynamic: true, corrLimit: 0.75 },
  strategy: 'classic', // 'classic' | 'smc' | 'zone' | 'edh'
  preSmc: null,        // indicator switches saved when SMC turned them off
};

function merge(base, extra) {
  if (!extra || typeof extra !== 'object' || Array.isArray(base)) return extra ?? base;
  const out = { ...base };
  for (const k of Object.keys(base)) {
    if (extra[k] !== undefined) out[k] = typeof base[k] === 'object' && base[k] !== null && !Array.isArray(base[k]) ? merge(base[k], extra[k]) : extra[k];
  }
  return out;
}

function loadSettings() {
  const s = merge(structuredClone(DEFAULT_SETTINGS), storage.get('settings', {}));
  // One-time: the old default cap of 6 open signals is gone (no daily/open limit); a deliberate cap can be set again in Settings.
  if (!storage.get('cap6-lifted', false)) { storage.set('cap6-lifted', true); let ch = false; if (s.risk?.maxActive === 6) { s.risk.maxActive = 0; ch = true; } if (s.plan?.maxPerDay === 6) { s.plan.maxPerDay = 0; ch = true; } if (ch) storage.set('settings', s); }
  // One-time: Fibonacci-break alerts carry no measured accuracy, so they are off unless switched on again (Settings → Fibonacci).
  if (!storage.get('fibnotify-off', false)) { storage.set('fibnotify-off', true); if (s.fib?.notify) { s.fib.notify = false; storage.set('settings', s); } }
  return s;
}

const state = {
  symbol: (() => { const v = storage.get('symbol', 'BTCUSDT'); return typeof v === 'string' && findInstrument(v) ? v : 'BTCUSDT'; })(),
  timeframe: storage.get('timeframe', DEFAULT_TIMEFRAME),
  settings: loadSettings(),
  theme: storage.get('theme', 'dark'),
  palette: 'gold',
  user: null,
};

const listeners = new Map(); // key -> Set<fn>

export const store = {
  get: (k) => state[k],
  set(k, v) {
    state[k] = v;
    if (k === 'symbol' || k === 'timeframe' || k === 'theme' || k === 'palette') storage.set(k, v);
    if (k === 'settings') storage.set('settings', v);
    (listeners.get(k) || []).forEach((fn) => fn(v));
    (listeners.get('*') || []).forEach((fn) => fn(k, v));
  },
  /** Update a nested settings section, e.g. updateSettings('rsi', { period: 21 }). */
  updateSettings(section, patch) {
    const s = structuredClone(state.settings);
    s[section] = Array.isArray(patch) || typeof patch !== 'object' ? patch : { ...s[section], ...patch };
    this.set('settings', s);
  },
  resetSettings() { this.set('settings', structuredClone(DEFAULT_SETTINGS)); },
  on(k, fn) {
    if (!listeners.has(k)) listeners.set(k, new Set());
    listeners.get(k).add(fn);
    return () => listeners.get(k).delete(fn);
  },
};
