// "Your data" card on the profile page: download everything about you, or delete your account.
import { esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { icons } from './icons.js';
import { toast, openModal } from './ui.js';
import { auth } from '../services/auth/index.js';
import { authErrorMessage } from '../services/auth/errors.js';
import { t } from '../i18n/index.js';
import { apiRequest } from '../services/ai/gateway.js';
import { navigate } from '../router.js';

const L = (ar, en) => (getLang() !== 'ar' ? en : ar);
/** This browser's own records (journal, settings, alerts…) — every ata:* key; the sign-in password store is left out. */
function localData() {
  const out = {};
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i); if (!k || !k.startsWith('ata:') || /users|secret|token/i.test(k)) continue;
      try { out[k.slice(4)] = JSON.parse(localStorage.getItem(k)); } catch { out[k.slice(4)] = localStorage.getItem(k); }
    }
  } catch { /* storage off */ }
  return out;
}
function download(name, obj) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' })); a.download = name;
  document.body.append(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}

export const accountDataHtml = () => `<article class="card profile-card ad-card fade-in">
  <h2 class="card-title">${icons.shield || ''}<span>${esc(L('بياناتك', 'Your data'))}</span></h2>
  <p class="muted tool-note">${esc(L('نزّل نسخة من كل شي محفوظ عنك (على السيرفر وعلى هالجهاز)، أو امسح حسابك.', 'Download a copy of everything stored about you (on the server and on this device), or delete your account.'))}</p>
  <div class="ad-row"><button type="button" class="btn" data-export>${icons.download || ''}<span>${esc(L('نزّل بياناتي', 'Download my data (JSON)'))}</span></button>
  <button type="button" class="btn ad-danger" data-delete>${icons.trash || ''}<span>${esc(L('امسح حسابي', 'Delete my account'))}</span></button></div>
</article>`;

export function bindAccountData(root) {
  root.querySelector('[data-export]')?.addEventListener('click', async (e) => {
    const b = e.currentTarget; b.disabled = true;
    let server = null; try { server = await apiRequest('GET', '/api/user/export', undefined, 20000); } catch (x) { server = { unavailable: x?.code || 'error' }; }
    download(`gotrivatrade-my-data-${new Date().toISOString().slice(0, 10)}.json`, { server, thisDevice: localData() });
    toast(L('نزل الملف.', 'Downloaded.'), 'success'); b.disabled = false;
  });
  root.querySelector('[data-delete]')?.addEventListener('click', () => openModal(L('مسح الحساب', 'Delete account'), (body, close) => {
    const needPw = auth.canChangePassword();
    const word = L('امسح', 'DELETE');
    body.innerHTML = `<div class="ad-modal">
      <p>${esc(L('هاد بيمسح: صفقاتك المحفوظة، اشتراكك، حصة الذكاء الاصطناعي، وحساب الدخول. ما بينرجع.', 'This deletes your saved trades, your plan, your AI allowance and your sign-in account. It cannot be undone.'))}</p>
      <ul class="tool-list"><li>${esc(L('الاشتراك المدفوع اللي لسا فيه وقت بيروح كمان، وما في استرجاع تلقائي.', 'Any paid time left on your plan is lost too; there is no automatic refund.'))}</li>
      <li>${esc(L('مبالغ الدفعات بتضل بسجل المحاسبة بدون اسمك (واجب محاسبي).', 'Payment amounts stay in the bookkeeping record without your name (accounting duty).'))}</li>
      <li>${esc(L('إذا عندك رصيد بالبنك لازم تسحبه أول؛ وسجلات البنك بتنحفظ المدة اللي بيطلبها القانون.', 'Any bank balance must be withdrawn first; bank records are kept as long as the law requires.'))}</li></ul>
      <p class="muted">${esc(L('نصيحة: نزّل بياناتك قبل.', 'Tip: download your data first.'))}</p>
      <form class="tf-grid ad-form" data-f>
        ${needPw ? `<label class="field"><span>${esc(L('كلمة المرور', 'Password'))}</span><input class="input" type="password" name="pw" autocomplete="current-password" required></label>` : `<p class="muted">${esc(L('رح تنفتح نافذة تسجيل الدخول حتى تأكد إنه إنت.', 'A sign-in window will open to confirm it is you.'))}</p>`}
        <label class="field"><span>${esc(L(`اكتب «${word}» للتأكيد`, `Type “${word}” to confirm`))}</span><input class="input" name="w" autocomplete="off" required></label>
        <button class="btn ad-danger" type="submit">${icons.trash || ''}<span>${esc(L('امسح نهائيًا', 'Delete for good'))}</span></button>
      </form></div>`;
    const f = body.querySelector('[data-f]');
    f.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      if (f.w.value.trim() !== word) { toast(L(`لازم تكتب «${word}» بالزبط.`, `Type “${word}” exactly.`), 'error'); return; }
      const btn = f.querySelector('[type=submit]'); btn.disabled = true;
      try {
        await auth.reauth(needPw ? f.pw.value : '');
        if (auth.mode !== 'local') {
          try { await apiRequest('DELETE', '/api/user/account', { confirm: 'DELETE' }, 20000); }
          catch (x) {
            const msg = { bank_balance: L('عندك رصيد بالبنك. اسحبه أول وبعدين امسح الحساب.', 'You still have money in the bank. Withdraw it first.'), owner_account: L('حساب صاحب الموقع ما بينمسح من هون.', 'The site owner account cannot be deleted here.'), reauth_required: L('تسجيل الدخول لازم يكون جديد. جرّب كمان مرة.', 'A fresh sign-in is needed. Try again.') }[x?.code];
            if (msg || !['server_missing', 'server_unreachable'].includes(x?.code)) { toast(msg || L('ما قدرنا نمسح البيانات على السيرفر.', 'Could not delete the server data.'), 'error', 8000); btn.disabled = false; return; }
          }
        }
        const uid = auth.current()?.uid;
        await auth.deleteUser();
        try { for (const k of Object.keys(localStorage)) if (k.startsWith('ata:') && (!uid || k.includes(uid))) localStorage.removeItem(k); } catch { /* */ }
        close(); toast(L('انمسح حسابك.', 'Your account was deleted.'), 'success', 6000); navigate('#/login');
      } catch (x) { toast(authErrorMessage(x, t), 'error', 7000); btn.disabled = false; }
    });
  }));
}
