// v332: slim live price strip under the top bar (owner's reference design). Real quotes only: a symbol whose quote is not
// live is simply not shown, and the whole strip stays hidden when nothing is live.
import { h, esc, fmtNum } from '../utils/dom.js';
import { getTickers } from '../services/market/index.js';
import { pairName } from '../services/tradeMessages.js';
import { assetIcon } from './icons.js';
import { getInstrument } from '../config/instruments.js';

const SYMS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'ADAUSDT', 'DOGEUSDT', 'LINKUSDT', 'XAUUSD', 'EURUSD'];
export function stripHtml(tk) {
  return SYMS.map((s) => tk?.[s]).filter((q) => q && q.mode === 'live' && Number.isFinite(q.changePct)).map((q) => {
    const up = q.changePct >= 0;
    return `<span class="ps-item"><span class="ps-ic" aria-hidden="true">${assetIcon(getInstrument(q.symbol)?.icon, 16)}</span><b dir="ltr">${esc(pairName(q.symbol))}</b><span class="ps-px" dir="ltr">${esc(fmtNum(q.price, q.price >= 1000 ? 2 : q.price >= 1 ? 4 : 6))}</span><i class="${up ? 'is-up' : 'is-down'}" dir="ltr">${up ? '+' : '−'}${Math.abs(q.changePct).toFixed(2)}% ${up ? '▲' : '▼'}</i></span>`;
  }).join('');
}
export function createPriceStrip() {
  const el = h('<div class="price-strip" hidden aria-label="Live prices"><div class="ps-row" data-ps></div></div>');
  let timer = null; let busy = false;
  const tick = async () => {
    if (busy || document.hidden) return; busy = true;
    try { const html = stripHtml(await getTickers(SYMS)); el.hidden = !html; if (html) el.querySelector('[data-ps]').innerHTML = html; } catch { /* keeps the last strip */ } finally { busy = false; }
  };
  setTimeout(tick, 1500); timer = setInterval(tick, 20_000);
  return { el, stop: () => clearInterval(timer) };
}
