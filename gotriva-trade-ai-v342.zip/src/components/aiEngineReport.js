// The consolidated multi-strategy report shown inside the AI signal result (توصيات AI): the market header, news,
// every strategy with its PASS / FAIL / UNAVAILABLE checklist and measured values, the global filters and the final result.
import { esc } from '../utils/dom.js';
import { fmtTz } from '../services/aiSignalUtil.js';
import { pairName } from '../services/tradeMessages.js';
import { oneClickLot } from '../services/mt5Apply.js';

// Related market loaded for the statistics module (context only).
export const PEER = { BTCUSDT: 'ETHUSDT', ETHUSDT: 'BTCUSDT', SOLUSDT: 'ETHUSDT', BNBUSDT: 'BTCUSDT', XRPUSDT: 'BTCUSDT', DOGEUSDT: 'BTCUSDT', ADAUSDT: 'BTCUSDT', AVAXUSDT: 'ETHUSDT', LINKUSDT: 'ETHUSDT', LTCUSDT: 'BTCUSDT', XAUUSD: 'XAGUSD', XAGUSD: 'XAUUSD', US30: 'US100', US100: 'SPX500', SPX500: 'US100', USOIL: 'UKOIL', UKOIL: 'USOIL', GER40: 'EU50', EU50: 'GER40' };

const T = {
  status: {
    qualified: ['مؤهّلة', 'QUALIFIED'], not_qualified: ['غير مؤهّلة', 'NOT QUALIFIED'], unavailable: ['غير متاحة', 'UNAVAILABLE'],
    unvalidated: ['غير مُتحقَّق منها', 'UNVALIDATED'], busy: ['عندها صفقة مفتوحة', 'OPEN TRADE'], context: ['سياق فقط', 'CONTEXT ONLY'], conflict: ['تعارض', 'CONFLICT'],
  },
  check: { pass: ['ناجح', 'PASS'], fail: ['فاشل', 'FAIL'], unavailable: ['غير متاح', 'UNAVAILABLE'] },
  final: { buy: ['شراء', 'BUY'], sell: ['بيع', 'SELL'], no_trade: ['لا صفقة', 'NO TRADE'] },
  quality: { good: ['جيدة', 'GOOD'], limited: ['محدودة', 'LIMITED'], insufficient: ['غير كافية', 'INSUFFICIENT'] },
  regime: { trending: ['اتجاه', 'Trending'], ranging: ['عرضي', 'Ranging'], high_volatility: ['تذبذب عالي', 'High volatility'], uncertain: ['غير واضح', 'Uncertain'] },
  dir: { long: ['صاعد', 'Bullish'], short: ['هابط', 'Bearish'], neutral: ['محايد', 'Neutral'] },
  news: { clear: ['واضح', 'CLEAR'], soon: ['خبر قوي خلال 4 ساعات', 'HIGH-IMPACT EVENT NEARBY'], blackout: ['خبر قوي الآن (منع)', 'HIGH-IMPACT EVENT, BLACKOUT'], unavailable: ['بيانات الأخبار غير متاحة', 'NEWS DATA UNAVAILABLE'], stale: ['بيانات الأخبار قديمة', 'NEWS DATA UNAVAILABLE (stale)'] },
  spread: { ok: ['ضمن الحد', 'Within limit'], wide: ['واسع', 'Too wide'], estimated: ['تقديري (المزوّد ما بيعطي bid/ask)', 'Estimated (feed has no live bid/ask)'] },
  reason: {
    insufficient_data: ['البيانات غير كافية لتحليل كامل.', 'Not enough data for a complete analysis.'],
    no_strategy: ['ولا استراتيجية حققت كل شروطها الإلزامية.', 'No strategy met every one of its mandatory conditions.'],
    conflict: ['في استراتيجيات مؤهّلة باتجاهين عكس بعض (تعارض).', 'Qualified strategies point in opposite directions (conflict).'],
    news: ['مخاطر الأخبار: خبر قوي قريب أو بيانات الأخبار غير متاحة.', 'News risk: a high-impact event is close or news data is unavailable.'],
    global: ['فلتر أمان عام فشل.', 'A global safety filter failed.'],
    sizing: ['ما قدرنا نحسب حجم الصفقة من بيانات حسابك.', 'Position size could not be calculated from your account data.'],
    learned: ['المحرك تعلّم من نتائجه إنه هالصفقات خسرانة بهالظروف.', 'The engine learned from its results that these trades lose in this context.'],
  },
};
const L = (pair, lang) => pair[lang !== 'ar' ? 1 : 0];
const sess = { '24/7': ['24/7', '24/7'], asia: ['آسيا', 'Asia'], london: ['لندن', 'London'], london_ny: ['لندن + نيويورك', 'London + New York'], new_york: ['نيويورك', 'New York'], closed: ['مسكّر', 'Closed'], NYSE: ['NYSE', 'NYSE'], unknown: ['غير معروف', 'Unknown'] };

/** Plain-text reasons for a NO TRADE result: the main reason and the exact failed or missing conditions. */
export function engineReasonText(m, lang = 'ar') {
  const out = [L(T.reason[m.reason] || T.reason.global, lang)];
  for (const g of m.globals) if (g.status !== 'pass') out.push(`${L([g.label.ar, g.label.en], lang)}: ${L(T.check[g.status], lang)}${g.value ? ` (${g.value})` : ''}`);
  if (m.reason === 'no_strategy') {
    for (const s of m.strategies.filter((x) => ['not_qualified', 'unavailable'].includes(x.status))) {
      const bad = s.checks.filter((c) => c.status !== 'pass').map((c) => L([c.label.ar, c.label.en], lang));
      if (bad.length) out.push(`${L([s.name.ar, s.name.en], lang)}: ${bad.slice(0, 4).join(lang !== 'ar' ? ', ' : '، ')}`);
    }
  }
  return out.slice(0, 8);
}

/** Compact summary for the AI explanation (numbers exactly as computed). */
export function engineBrief(m) {
  return {
    final: m.final, reason: m.reason, qualified: m.qualified, pick: m.pick?.id || null, confidence: m.confidence, conflict: Boolean(m.conflict),
    trades: (m.trades || []).map((x) => ({ strategy: x.id, direction: x.direction, entry: x.plan.entry, stop: x.plan.stop, targets: x.plan.targets, rrMain: x.plan.rrMain })),
    assetClass: m.assetClass, dataQuality: m.dataQuality, session: m.session?.name, regime: m.regime, newsStatus: m.news?.newsStatus,
    strategies: m.strategies.map((s) => ({ id: s.id, status: s.status, direction: s.direction, failed: s.checks.filter((c) => c.status !== 'pass').map((c) => `${c.id}:${c.status}${c.value ? `(${c.value})` : ''}`) })),
    globalsFailed: m.globals.filter((g) => g.status !== 'pass').map((g) => `${g.id}:${g.status}${g.value ? `(${g.value})` : ''}`),
  };
}

const badge = (status, lang) => `<span class="aie-badge is-${esc(status)}">${esc(L(T.status[status] || [status, status], lang))}</span>`;
const row = (c, lang) => `<li class="is-${esc(c.status)}"><i aria-hidden="true"></i><span>${esc(L([c.label.ar, c.label.en], lang))}</span><b>${esc(L(T.check[c.status], lang))}</b>${c.value ? `<small dir="ltr">${esc(c.value)}</small>` : ''}</li>`;

const px = (v) => (Number.isFinite(v) ? (Math.abs(v) >= 1000 ? v.toFixed(2) : Math.abs(v) >= 10 ? v.toFixed(3) : v.toFixed(5)) : '—');
/** One trade per qualified strategy (its own entry / stop / targets). */
function tradesHtml(m, lang) {
  const ar = lang === 'ar'; const list = m.trades || [];
  if (!list.length) return '';
  const nm = (id) => { const s = m.strategies.find((x) => x.id === id); return s ? L([s.name.ar, s.name.en], lang) : id; };
  const cards = list.map((x) => {
    const long = x.direction === 'long';
    return `<article class="aie-trade ${long ? 'is-long' : 'is-short'}"><header><b>${esc(nm(x.id))}</b><span class="aie-tdir">${esc(L(long ? T.final.buy : T.final.sell, lang))}</span>${m.pick?.id === x.id ? `<em>${ar ? 'الصفقة الرئيسية' : 'Main trade'}</em>` : ''}</header>
      <dl dir="ltr"><div><dt>${ar ? 'الدخول' : 'Entry'}</dt><dd>${esc(px(x.plan.entry))}</dd></div><div><dt>${ar ? 'الوقف' : 'Stop'}</dt><dd class="dn">${esc(px(x.plan.stop))}</dd></div>${x.plan.targets.map((t, k) => `<div><dt>TP${k + 1}</dt><dd class="up">${esc(px(t))}</dd></div>`).join('')}<div><dt>R:R</dt><dd>${esc(String(x.plan.rrMain))}</dd></div>${x.plan.execution ? `<div><dt>${ar ? 'الأمر' : 'Order'}</dt><dd>${x.plan.execution === 'limit' ? (ar ? 'ليميت' : 'Limit') : (ar ? 'ماركت' : 'Market')}</dd></div>` : ''}${x.plan.quality != null ? `<div><dt>${ar ? 'الجودة' : 'Quality'}</dt><dd>${esc(String(x.plan.quality))}/100</dd></div>` : ''}</dl>${x.exec && !x.exec.ok ? `<p class="aie-note">${ar ? 'التنفيذ هلق مش صالح' : 'Not executable right now'} (${esc(String(x.exec.reason || ''))})</p>` : ''}${m.pick?.id === x.id || x.plan.execution === 'limit' || (x.exec && !x.exec.ok) ? '' : `<div class="rc-mt5"><button type="button" class="mt5-go" data-mt5ai="${esc(x.id)}"><span class="mt5-go-bolt" aria-hidden="true">⚡</span><span class="mt5-go-txt">${ar ? 'تطبيق على MT5' : 'Apply on MT5'}</span><span class="mt5-go-lot">· ${oneClickLot().toFixed(2)} ${ar ? 'لوت' : 'lot'}</span><i class="mt5-go-spin" aria-hidden="true"></i></button></div>`}</article>`;
  }).join('');
  return `<div class="aie-sec aie-trades-box"><h4>${ar ? `صفقة لكل استراتيجية محققة شروطها (${list.length})` : `One trade per qualified strategy (${list.length})`}</h4>
    ${m.conflict ? `<p class="aie-note is-warn">${ar ? 'انتبه: في استراتيجيات محققة شروطها باتجاهين عكس بعض. كل وحدة إلها صفقتها، بس فتحهم مع بعض بيلغي بعض، اختار وحدة.' : 'Note: qualified strategies point in opposite directions. Each has its own trade, but opening both cancels them out, pick one.'}</p>` : ''}
    <div class="aie-trades">${cards}</div></div>`;
}

/** What the AI signal page shows from the engine: the per-strategy trades, then the detailed report as one compact,
 *  always-closed row that the client opens when they want it (v209). */
export function engineHtml(m, lang = 'ar') { return tradesHtml(m, lang) + engineReportHtml(m, lang); }

export function engineReportHtml(m, lang = 'ar') {
  const ar = lang === 'ar';
  const at = fmtTz(Math.floor(m.at / 1000), lang);
  const kv = [
    [ar ? 'السوق' : 'Instrument', pairName(m.instrument)],
    [ar ? 'فئة الأصل' : 'Asset class', L(m.assetLabel, lang)],
    [ar ? 'مزوّد البيانات' : 'Data provider', m.provider === 'binance' ? 'Binance' : m.provider === 'twelvedata' ? 'Twelve Data' : (m.provider || '—')],
    [ar ? 'جودة البيانات' : 'Data quality', L(T.quality[m.dataQuality], lang)],
    [ar ? 'الجلسة' : 'Market session', L(sess[m.session?.name] || sess.unknown, lang)],
    [ar ? 'حالة السوق' : 'Market regime', L(T.regime[m.regime] || T.regime.uncertain, lang)],
    [ar ? 'الاتجاه العام (فريم أعلى)' : 'Overall direction (higher TF)', L(T.dir[m.overall] || T.dir.neutral, lang)],
    [ar ? 'السبريد والسيولة' : 'Spread / liquidity', L(T.spread[m.spreadState], lang)],
    [ar ? 'الأخبار' : 'News status', L(T.news[m.news?.newsStatus] || T.news.unavailable, lang)],
    [ar ? 'الفريمات (سياق / إعداد / دخول)' : 'Timeframes (context / setup / entry)', m.ladder ? m.ladder.join(' / ') : m.tf],
  ];
  const events = (m.news?.events || []).map((e) => `<li><b>${esc(e.title)}</b><span>${esc(e.country)} · ${esc(e.impact)} · ${esc(fmtTz(Math.floor(e.time / 1000), lang))}</span></li>`).join('');
  const strategies = m.strategies.map((s) => `<details class="aie-strat is-${esc(s.status)}">
      <summary><b>${esc(L([s.name.ar, s.name.en], lang))}</b>${s.direction && s.status !== 'context' && s.status !== 'unvalidated' ? `<span class="aie-dir">${esc(L(T.dir[s.direction], lang))}</span>` : ''}${badge(s.status, lang)}</summary>
      <ul class="aie-checks">${s.checks.map((c) => row(c, lang)).join('')}</ul>
      ${s.confirmations?.length ? `<p class="aie-note">${ar ? 'عوامل التأكيد (بترفع الجودة)' : 'Confirmations (raise the quality)'}${s.quality != null ? ` · ${s.quality}/100` : ''}</p><ul class="aie-checks">${s.confirmations.map((c) => row({ label: c.label, status: c.ok ? 'pass' : 'fail' }, lang)).join('')}</ul>` : ''}
      ${s.context?.length ? `<p class="aie-note">${ar ? 'سياق (ما بيمنع لحاله)' : 'Context (never blocks on its own)'}</p><ul class="aie-checks">${s.context.map((c) => row({ label: c.label, status: c.ok ? 'pass' : 'unavailable', value: c.value }, lang)).join('')}</ul>` : ''}</details>`).join('');
  const qualified = m.qualified.length ? m.qualified.map((id) => L([m.strategies.find((s) => s.id === id).name.ar, m.strategies.find((s) => s.id === id).name.en], lang)).join(ar ? '، ' : ', ') : (ar ? 'ولا وحدة' : 'None');
  const tested = m.strategies.filter((x) => ['trend', 'mean_reversion', 'smc', 'ict', 'asian_range', 'fvg', 'patterns', 'volume_profile', 'order_flow'].includes(x.id)).length;
  const passedG = m.globals.filter((g) => g.status === 'pass').length;
  return `<details class="aie">
    <summary class="aie-head"><span class="aie-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V5M4 19h16M8 15l3-4 3 2 5-6"/></svg></span>
      <span class="aie-ttl"><b>${ar ? 'تفاصيل التحليل' : 'Analysis details'}</b><small>${ar ? `${m.qualified.length}/${tested} استراتيجيات مؤهّلة · ${passedG}/${m.globals.length} فلاتر أمان` : `${m.qualified.length}/${tested} strategies qualified · ${passedG}/${m.globals.length} safety filters`}</small></span></summary>
    <dl class="aie-kv">${kv.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>
    <div class="aie-sec"><h4>${ar ? 'الأخبار والأحداث القادمة (24 ساعة)' : 'Relevant news & upcoming events (24 h)'}</h4>
      ${events ? `<ul class="aie-events">${events}</ul>` : `<p class="aie-note">${esc(m.news?.newsStatus === 'unavailable' || m.news?.newsStatus === 'stale' ? L(T.news.unavailable, lang) : (ar ? 'ما في أحداث مهمة لهالسوق خلال 24 ساعة.' : 'No relevant medium/high-impact events in the next 24 h.'))}</p>`}
      <p class="aie-note">${ar ? 'المصدر' : 'Source'}: ${esc(m.news?.source || '—')}${m.news?.fetchedAt ? ` · ${ar ? 'آخر تحديث' : 'updated'} ${esc(fmtTz(Math.floor(m.news.fetchedAt / 1000), lang))}` : ''} · ${ar ? 'نافذة المنع ±30 دقيقة حول الأخبار القوية' : 'blackout ±30 min around high-impact events'}</p></div>
    <div class="aie-sec"><h4>${ar ? 'نتائج الاستراتيجيات' : 'Strategy results'}</h4>${strategies}</div>
    <div class="aie-sec"><details class="aie-strat ${passedG === m.globals.length ? 'is-qualified' : 'is-not_qualified'}"><summary><b>${ar ? 'فلاتر الأمان العامة' : 'Global safety filters'}</b><span class="aie-badge ${passedG === m.globals.length ? 'is-qualified' : 'is-not_qualified'}">${passedG}/${m.globals.length}</span></summary><ul class="aie-checks">${m.globals.map((c) => row(c, lang)).join('')}</ul></details></div>
    <div class="aie-sec aie-sum"><div><dt>${ar ? 'الاستراتيجيات المؤهّلة' : 'Qualified strategies'}</dt><dd>${esc(qualified)}</dd></div>
      <div><dt>${ar ? 'النتيجة النهائية' : 'Final result'}</dt><dd>${esc(L(T.final[m.final], lang))}${m.pick ? ` · ${esc(L([m.strategies.find((s) => s.id === m.pick.id).name.ar, m.strategies.find((s) => s.id === m.pick.id).name.en], lang))}` : ''}</dd></div>
      <div><dt>${ar ? 'الثقة' : 'Confidence'}</dt><dd>${ar ? 'غير معايَرة (NOT CALIBRATED)' : 'NOT CALIBRATED'}</dd></div></div>
    ${m.riskWarn ? `<p class="aie-note is-warn">${ar ? 'نسبة المخاطرة اللي اخترتها أعلى من 0.5% (الحد التجريبي المحافظ لهالمحرك).' : 'Your chosen risk is above 0.5% (this engine\'s conservative research default).'}</p>` : ''}
    <p class="aie-note">${ar ? '«مؤهّلة» يعني كل شروطها نجحت، مش إنها مضمونة الربح. ما في أوامر حقيقية بتنفتح من هون.' : '"Qualified" means every condition passed, not a guaranteed win. No live orders are placed from here.'}</p>
  </details>`;
}
