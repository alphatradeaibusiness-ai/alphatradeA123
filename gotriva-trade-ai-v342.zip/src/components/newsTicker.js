// Live news strip above the chart: the economic releases (with Forex Factory's impact rating) and the headlines
// that concern the selected asset. Data: services/news.js (calendar every 30 min, headlines every 2 min).
import { h, esc } from '../utils/dom.js';
import { t } from '../i18n/index.js';
import { icons } from './icons.js';
import { getCalendar, getFFNews } from '../services/news.js';
import { tickerItems } from '../services/newsFeed.js';
import { checkNewsAlerts } from '../services/newsAlerts.js';

export function createNewsTicker() {
  const el = h(`<a class="news-ticker card" href="#/app/news" aria-live="off">
    <span class="nt-live">${icons.alert || ''}<b>${esc(t('nt.title'))}</b></span>
    <span class="nt-track"><span class="nt-run" data-run></span></span>
  </a>`);
  const run = el.querySelector('[data-run]');
  let symbol = null; let cal = { events: null, error: false }; let news = { items: null, error: false }; let lastHtml = ''; let lastW = 0;

  const when = (it) => {
    if (it.kind !== 'event') return it.ago || '';
    const m = Math.round((it.time - Date.now()) / 60000);
    if (Math.abs(m) < 1) return t('nt.now');
    return m > 0 ? t('nt.in', { m: m >= 120 ? `${Math.round(m / 60)}h` : `${m}m` }) : t('nt.ago', { m: -m >= 120 ? `${Math.round(-m / 60)}h` : `${-m}m` });
  };
  const itemHtml = (it) => {
    const imp = it.impact ? `<b class="nt-imp nt-${it.impact.toLowerCase()}">${esc(t(`nt.impact.${it.impact}`))}</b>` : '';
    const nums = it.kind === 'event' ? [['actual', it.actual], ['forecast', it.forecast], ['previous', it.previous]].filter(([, v]) => v).map(([k, v]) => `${esc(t(`nt.${k}`))} ${esc(v)}`).join(' · ') : '';
    return `<span class="nt-item">${imp}${it.country ? `<b class="mono">${esc(it.country)}</b>` : ''}<span>${esc(it.title)}</span>${nums ? `<small class="muted">${nums}</small>` : ''}<small class="muted">${esc(when(it))}</small></span>`;
  };

  function render() {
    let html;
    const items = symbol && (cal.events || news.items) ? tickerItems(symbol, cal.events, news.items) : [];
    if (items.length) {
      const one = items.map(itemHtml).join('<span class="nt-sep">•</span>');
      html = `<span class="nt-seq">${one}<span class="nt-sep">•</span></span><span class="nt-seq" aria-hidden="true">${one}<span class="nt-sep">•</span></span>`;
      el.classList.add('has-items');
    } else {
      const why = !symbol || (cal.events === null && news.items === null) ? (cal.error || news.error ? t('nt.unavailable') : t('nt.loading')) : t('nt.none');
      html = `<span class="nt-idle">${esc(why)}</span>`;
      el.classList.remove('has-items');
    }
    if (html === lastHtml) return;
    lastHtml = html; run.innerHTML = html;
    const w = run.firstElementChild?.scrollWidth || 0;
    if (!lastW || Math.abs(w - lastW) / lastW > 0.1) { lastW = w; run.style.setProperty('--nt-dur', `${Math.max(20, w / 55)}s`); }
  }

  async function refresh(force = false) {
    await Promise.all([
      getCalendar({ force }).then((r) => { cal = { events: r.events, error: false }; }).catch(() => { cal = { ...cal, error: true }; }),
      getFFNews({ force }).then((r) => { news = { items: r.items, error: false }; }).catch(() => { news = { ...news, error: true }; }),
    ]);
    try { checkNewsAlerts(cal.events, news.items); } catch { /* an alert problem never breaks the ticker */ }
    render();
  }
  const timer = setInterval(() => { if (!el.isConnected) { clearInterval(timer); return; } if (!document.hidden) refresh(); }, 120_000);
  refresh();

  return { el, update(sym) { if (sym !== symbol) { symbol = sym; render(); } } };
}
