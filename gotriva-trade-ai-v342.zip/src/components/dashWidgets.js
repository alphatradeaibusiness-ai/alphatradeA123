// v336: home dashboard panels laid out like the owner's reference dashboard.
// Every number is live data already in the app: quotes (getTickers), the signals channel (signalState), the user's own saved
// trades (listTrades) and Forex Factory headlines (getFFNews). Nothing is invented; an empty source shows an honest empty line.
import { h, esc, fmtNum } from '../utils/dom.js';
import { store } from '../state/store.js';
import { getTickers } from '../services/market/index.js';
import { INSTRUMENTS, getInstrument } from '../config/instruments.js';
import { signalState, onSignals } from '../services/signals.js';
import { listTrades, onTrades } from '../services/assistTrades.js';
import { getFFNews } from '../services/news.js';
import { assetIcon } from './icons.js';
import { pairName } from '../services/tradeMessages.js';
import { tx } from '../i18n/tx.js';
import { getLang } from '../i18n/index.js';

const L = (ar, en) => tx({ ar, en });
const li = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
const IC = {
  star: li('<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>'),
  fx: li('<path d="M4 8h13l-3-3M20 16H7l3 3"/>'),
  crypto: li('<path d="M9 6v12M9 6h5a3 3 0 010 6H9m0 0h5.5a3 3 0 010 6H9M11 4v2M14 4v2M11 18v2M14 18v2"/>'),
  index: li('<path d="M4 20h16"/><rect x="5" y="12" width="3" height="6" rx=".8"/><rect x="10.5" y="8" width="3" height="10" rx=".8"/><rect x="16" y="4" width="3" height="14" rx=".8"/>'),
  goods: li('<path d="M3 19l2.2-5h7.6l2.2 5z"/><path d="M9 14l2.2-5h7.6L21 14"/>'),
  robot: li('<rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 16.5h5"/>'),
  grid: li('<rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="5" rx="1.5"/><rect x="13" y="10" width="8" height="11" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/>'),
  gauge: li('<path d="M4 16a8 8 0 1116 0"/><path d="M12 16l4-5"/>'),
  news: li('<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>'),
  perf: li('<path d="M3 17l5-5 4 3 8-8"/><path d="M15 7h5v5"/>'),
  list: li('<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>'),
};

const TYPE_TABS = [
  ['watch', () => L('المتابعة', 'Watchlist'), IC.star, () => true],
  ['forex', () => L('فوركس', 'Forex'), IC.fx, (i) => i.type === 'forex'],
  ['crypto', () => L('كريبتو', 'Crypto'), IC.crypto, (i) => i.type === 'crypto'],
  ['index', () => L('مؤشرات', 'Indices'), IC.index, (i) => i.type === 'index'],
  ['goods', () => L('سلع', 'Commodities'), IC.goods, (i) => i.type === 'metal' || i.type === 'energy'],
];
const WATCH_DEFAULT = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XAUUSD', 'EURUSD', 'GBPUSD', 'US100', 'US500', 'NAS100', 'XAGUSD', 'USOIL', 'BNBUSDT'];
const ALL = INSTRUMENTS.map((i) => i.symbol);
const short = (i, s) => (i?.type === 'crypto' ? i.base : s);
const hist = new Map();
const lastPx = new Map();   // v337: last painted price, for the up/down flash
const tick = (s, px) => { const p = lastPx.get(s); lastPx.set(s, px); return Number.isFinite(p) && Number.isFinite(px) && p !== px ? (px > p ? ' tick-up' : ' tick-down') : ''; };   // symbol → recent prices this session (for the small lines)

const pctTxt = (p) => `${p >= 0 ? '+' : '−'}${Math.abs(p).toFixed(2)}%`;
const dec = (p) => (p >= 1000 ? 2 : p >= 10 ? 2 : p >= 1 ? 4 : 6);
const rel = (ms) => {
  if (!Number.isFinite(ms)) return '';
  const s = Math.round((Date.now() - ms) / 1000);
  try { const f = new Intl.RelativeTimeFormat(getLang(), { numeric: 'auto' }); if (s < 3600) return f.format(-Math.max(1, Math.round(s / 60)), 'minute'); if (s < 86400) return f.format(-Math.round(s / 3600), 'hour'); return f.format(-Math.round(s / 86400), 'day'); } catch { return ''; }
};
const spark = (arr, up) => {
  if (!arr || arr.length < 2) return '<svg class="dw-spark" viewBox="0 0 60 20" aria-hidden="true"><path d="M0 10h60" stroke="currentColor" stroke-opacity=".25"/></svg>';
  const lo = Math.min(...arr); const hi = Math.max(...arr); const k = hi - lo || 1;
  const pts = arr.map((v, i) => `${((i / (arr.length - 1)) * 60).toFixed(1)},${(18 - ((v - lo) / k) * 16).toFixed(1)}`).join(' ');
  return `<svg class="dw-spark ${up ? 'is-up' : 'is-down'}" viewBox="0 0 60 20" aria-hidden="true"><polyline points="${pts}" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>`;
};
const head = (icon, title, extra = '') => `<header class="dw-head"><h3>${icon}<span>${title}</span></h3>${extra}</header>`;

export function createDashWidgets() {
  let tk = {};
  const st = { tab: 'watch', heat: 'crypto', trades: 'active', perf: 'all' };

  /* ── watchlist + market mood ── */
  const watch = h(`<section class="dw-col dw-watch">
    <div class="card dw-card dw-wl">
      <nav class="dw-tabs" role="tablist" aria-label="${esc(L('قائمة الأسواق', 'Market list'))}">${TYPE_TABS.map(([k, n, ic]) => `<button type="button" role="tab" data-wl="${k}" aria-selected="${k === 'watch'}">${ic}<span>${esc(n())}</span></button>`).join('')}</nav>
      <div class="dw-thead"><span>${esc(L('الرمز', 'Symbol'))}</span><span>${esc(L('السعر', 'Price'))}</span><span aria-hidden="true"></span><span>${esc(L('24س %', '24h %'))}</span></div>
      <div class="dw-rows" data-wl-rows></div>
    </div>
    <div class="card dw-card dw-mood">${head(IC.gauge, esc(L('مزاج السوق', 'Market sentiment')))}<div class="dw-mood-body" data-mood></div></div>
  </section>`);

  /* ── AI signals + heatmap ── */
  const right = h(`<section class="dw-col dw-right">
    <div class="card dw-card dw-sig">${head(IC.robot, esc(L('إشارات AI', 'AI Signals')), `<a class="dw-live" href="#/app/signals" data-sig-live>${esc(L('القناة', 'Channel'))}</a>`)}<div class="dw-sig-list" data-sig></div></div>
    <div class="card dw-card dw-heat">${head(IC.grid, esc(L('خريطة السوق الحرارية', 'Market heatmap')))}
      <nav class="dw-tabs dw-tabs-sm" role="tablist">${TYPE_TABS.slice(1).map(([k, n]) => `<button type="button" role="tab" data-ht="${k}" aria-selected="${k === 'crypto'}">${esc(n())}</button>`).join('')}</nav>
      <div class="dw-heat-grid" data-heat></div></div>
  </section>`);

  /* ── bottom row: trades / performance / news ── */
  const trades = h(`<section class="card dw-card dw-trades">
    <nav class="dw-tabs dw-tabs-sm" role="tablist">${[['active', L('صفقات مفتوحة', 'Open trades')], ['pending', L('معلّقة', 'Pending')], ['closed', L('مغلقة', 'Closed')]].map(([k, n]) => `<button type="button" role="tab" data-tr="${k}" aria-selected="${k === 'active'}">${esc(n)}<i data-tr-n="${k}"></i></button>`).join('')}</nav>
    <div class="dw-table-wrap"><table class="dw-table"><thead><tr><th>${esc(L('الرمز', 'Symbol'))}</th><th>${esc(L('النوع', 'Type'))}</th><th>${esc(L('الدخول', 'Entry'))}</th><th>${esc(L('السعر الحالي', 'Current'))}</th><th>${esc(L('النتيجة', 'P/L'))}</th></tr></thead><tbody data-tr-rows></tbody></table></div>
  </section>`);
  const perf = h(`<section class="card dw-card dw-perf">${head(IC.perf, esc(L('الأداء', 'Performance')), `<nav class="dw-tabs dw-tabs-xs" role="tablist">${[['day', L('اليوم', 'Today')], ['7', L('7 أيام', '7D')], ['30', L('30 يوم', '30D')], ['all', L('الكل', 'All')]].map(([k, n]) => `<button type="button" role="tab" data-pf="${k}" aria-selected="${k === 'all'}">${esc(n)}</button>`).join('')}</nav>`)}<div class="dw-perf-body" data-perf></div></section>`);
  const news = h(`<section class="card dw-card dw-news">${head(IC.news, esc(L('آخر الأخبار والتحليلات', 'Latest news & analysis')), `<a class="dw-more" href="#/app/news">${esc(L('عرض الكل', 'View all'))}</a>`)}<ul class="dw-news-list" data-news><li class="dw-empty">${esc(L('جاري تحميل الأخبار…', 'Loading news…'))}</li></ul></section>`);

  /* ── painters ── */
  const q = (s) => tk[s];
  function paintWatch() {
    const f = TYPE_TABS.find((x) => x[0] === st.tab)[3];
    const syms = st.tab === 'watch' ? WATCH_DEFAULT.filter((s) => ALL.includes(s)) : INSTRUMENTS.filter(f).map((i) => i.symbol);
    const cur = store.get('symbol');
    watch.querySelector('[data-wl-rows]').innerHTML = syms.map((s) => {
      const x = q(s); const i = getInstrument(s); const ok = x && x.mode !== 'unavailable' && Number.isFinite(x.price); const up = (x?.changePct ?? 0) >= 0;
      return `<button type="button" class="dw-row${s === cur ? ' is-on' : ''}${ok ? tick(s, x.price) : ''}" data-sym="${esc(s)}"><span class="dw-sym">${assetIcon(i?.icon, 22)}<b dir="ltr">${esc(short(i, s))}</b>${x?.mode === 'demo' ? `<i class="dw-demo" title="${esc(L('سعر تجريبي', 'Demo price'))}" aria-label="${esc(L('سعر تجريبي', 'Demo price'))}"></i>` : ''}</span><span class="dw-px" dir="ltr">${ok ? esc(fmtNum(x.price, dec(x.price))) : '—'}</span>${spark(hist.get(s), up)}<span class="dw-ch ${up ? 'is-up' : 'is-down'}" dir="ltr">${ok && Number.isFinite(x.changePct) ? pctTxt(x.changePct) : '—'}</span></button>`;
    }).join('');
  }
  function paintMood() {
    const live = ALL.map(q).filter((x) => x && x.mode === 'live' && Number.isFinite(x.changePct));
    const box = watch.querySelector('[data-mood]');
    if (live.length < 3) { box.innerHTML = `<p class="dw-empty">${esc(L('بانتظار أسعار حيّة كفاية لقياس المزاج.', 'Waiting for enough live prices.'))}</p>`; return; }
    const up = live.filter((x) => x.changePct > 0).length; const pct = Math.round((up / live.length) * 100);
    const word = pct >= 60 ? L('صاعد', 'Bullish') : pct <= 40 ? L('هابط', 'Bearish') : L('محايد', 'Neutral');
    const c = 2 * Math.PI * 26;
    box.innerHTML = `<svg class="dw-ring" viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="26" class="bg"/><circle cx="32" cy="32" r="26" class="fg" style="stroke-dasharray:${(c * pct / 100).toFixed(1)} ${c.toFixed(1)}" transform="rotate(-90 32 32)"/><text x="32" y="37" text-anchor="middle">${pct}%</text></svg>
      <div class="dw-mood-txt"><b class="${pct >= 60 ? 'is-up' : pct <= 40 ? 'is-down' : ''}">${esc(word)}</b><span>${esc(L(`${up} صاعد · ${live.length - up} هابط من ${live.length} سوق حيّ`, `${up} up · ${live.length - up} down of ${live.length} live markets`))}</span><i class="dw-bar"><i style="width:${pct}%"></i></i></div>`;
  }
  function paintHeat() {
    const f = TYPE_TABS.find((x) => x[0] === st.heat)[3];
    const list = INSTRUMENTS.filter(f).map((i) => ({ i, x: q(i.symbol) })).filter((o) => o.x && o.x.mode !== 'unavailable' && Number.isFinite(o.x.changePct)).slice(0, 10);
    const box = right.querySelector('[data-heat]');
    if (!list.length) { box.innerHTML = `<p class="dw-empty">${esc(L('ما في أسعار لهالقسم هلأ.', 'No prices for this group right now.'))}</p>`; return; }
    box.innerHTML = list.map(({ i, x }, n) => { const p = x.changePct; const a = Math.min(1, Math.abs(p) / 4); return `<button type="button" class="dw-tile${n < 2 ? ' is-big' : ''} ${p >= 0 ? 'is-up' : 'is-down'}" style="--a:${(0.18 + a * 0.6).toFixed(2)}" data-sym="${esc(i.symbol)}"><b dir="ltr">${esc(short(i, i.symbol))}</b><span dir="ltr">${pctTxt(p)}</span></button>`; }).join('');
  }
  function paintSignals() {
    const s = signalState(); const box = right.querySelector('[data-sig]');
    const list = (s.signals || []).filter((x) => ['active', 'pending'].includes(x.status)).slice(0, 4);
    if (!list.length) { box.innerHTML = `<p class="dw-empty">${esc(s.scanning ? L('جاري فحص الأسواق…', 'Scanning markets…') : L('ما في توصيات مفتوحة هلأ. القناة بتنبهك أول ما تطلع وحدة.', 'No open signals right now.'))}</p>`; return; }
    box.innerHTML = list.map((x) => {
      const i = getInstrument(x.symbol); const pr = i?.precision ?? 2; const buy = x.direction === 'long';
      return `<a class="dw-sig-row" href="#/app/signals"><div class="dw-sig-top">${assetIcon(i?.icon, 20)}<b dir="ltr">${esc(pairName(x.symbol))}</b><em class="${buy ? 'is-buy' : 'is-sell'}">${esc(buy ? L('شراء', 'BUY') : L('بيع', 'SELL'))}</em><time>${esc(rel(x.createdAt))}</time></div>
        <div class="dw-sig-lv"><span>${esc(L('دخول', 'Entry'))} <b dir="ltr">${esc(fmtNum(x.entry, pr))}</b></span><span>${esc(L('هدف', 'TP'))} <b dir="ltr">${esc(fmtNum(x.targets?.[0], pr))}</b></span><span>${esc(L('وقف', 'SL'))} <b dir="ltr">${esc(fmtNum(x.stop, pr))}</b></span></div>
        ${Number.isFinite(x.accuracy) && x.accuracy > 0 ? `<small>${esc(L('دقة الاستراتيجية', 'Strategy accuracy'))}: <b dir="ltr">${Math.round(x.accuracy)}%</b></small>` : ''}</a>`;
    }).join('');
  }
  function paintTrades() {
    const all = listTrades().filter((x) => x.mode === 'live');
    const groups = { active: all.filter((x) => x.status === 'active'), pending: all.filter((x) => x.status === 'pending'), closed: all.filter((x) => ['done', 'stopped', 'breakeven'].includes(x.status)) };
    trades.querySelectorAll('[data-tr-n]').forEach((n) => { n.textContent = groups[n.dataset.trN].length ? ` (${groups[n.dataset.trN].length})` : ''; });
    const rows = groups[st.trades].slice(0, 6);
    const body = trades.querySelector('[data-tr-rows]');
    if (!rows.length) { body.innerHTML = `<tr><td colspan="5" class="dw-empty">${esc(L('ما في صفقات هون. الصفقات اللي بتحفظها من مساعد الصفقات بتطلع هون.', 'No trades here yet. Trades you save from the trade assistant appear here.'))}</td></tr>`; return; }
    body.innerHTML = rows.map((x) => {
      const i = getInstrument(x.symbol); const pr = i?.precision ?? 2; const buy = x.direction === 'long'; const px = q(x.symbol)?.price;
      const risk = Math.abs(x.entry - x.stop) || 0;
      const r = x.status === 'active' && Number.isFinite(px) && risk ? ((px - x.entry) / risk) * (buy ? 1 : -1) : Number.isFinite(x.resultR) ? x.resultR : null;
      return `<tr><td><span class="dw-sym">${assetIcon(i?.icon, 18)}<b dir="ltr">${esc(pairName(x.symbol))}</b></span></td><td class="${buy ? 'is-up' : 'is-down'}">${esc(buy ? L('شراء', 'Long') : L('بيع', 'Short'))}</td><td dir="ltr">${esc(fmtNum(x.entry, pr))}</td><td dir="ltr">${Number.isFinite(px) ? esc(fmtNum(px, pr)) : '—'}</td><td dir="ltr" class="${r == null ? '' : r >= 0 ? 'is-up' : 'is-down'}">${r == null ? '—' : `${r >= 0 ? '+' : '−'}${Math.abs(r).toFixed(2)}R`}</td></tr>`;
    }).join('');
  }
  function paintPerf() {
    const now = Date.now() / 1000; const from = st.perf === 'day' ? now - 86400 : st.perf === '7' ? now - 7 * 86400 : st.perf === '30' ? now - 30 * 86400 : 0;
    const closed = listTrades().filter((x) => x.mode === 'live' && ['done', 'stopped', 'breakeven'].includes(x.status) && Number.isFinite(x.resultR) && (x.closedAt || 0) >= from).sort((a, b) => a.closedAt - b.closedAt);
    const box = perf.querySelector('[data-perf]');
    if (!closed.length) { box.innerHTML = `<p class="dw-empty">${esc(L('ما في صفقات مسكّرة بهالفترة لسا، فما في أداء نعرضه.', 'No closed trades in this period yet.'))}</p>`; return; }
    let cum = 0; const curve = [0, ...closed.map((x) => (cum += x.resultR))];
    const wins = closed.filter((x) => x.resultR > 0).length; const best = Math.max(...closed.map((x) => x.resultR)); const worst = Math.min(...closed.map((x) => x.resultR));
    const lo = Math.min(...curve); const hi = Math.max(...curve); const k = hi - lo || 1;
    const pts = curve.map((v, i) => `${((i / (curve.length - 1 || 1)) * 200).toFixed(1)},${(70 - ((v - lo) / k) * 62).toFixed(1)}`).join(' ');
    const R = (v) => `${v >= 0 ? '+' : '−'}${Math.abs(v).toFixed(2)}R`;
    box.innerHTML = `<div class="dw-perf-main"><b class="dw-big ${cum >= 0 ? 'is-up' : 'is-down'}" dir="ltr">${R(cum)}</b><small>${esc(L('مجموع النتيجة بوحدات المخاطرة (R)', 'Total result in risk units (R)'))}</small>
      <svg class="dw-curve" viewBox="0 0 200 74" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="dwg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#742bee" stop-opacity=".55"/><stop offset="1" stop-color="#742bee" stop-opacity="0"/></linearGradient></defs><polygon points="0,74 ${pts} 200,74" fill="url(#dwg)"/><polyline points="${pts}" fill="none" stroke="#6b13ec" stroke-width="2"/></svg></div>
      <dl class="dw-kv"><div><dt>${esc(L('نسبة الربح', 'Win rate'))}</dt><dd dir="ltr">${Math.round((wins / closed.length) * 100)}%</dd></div><div><dt>${esc(L('عدد الصفقات', 'Total trades'))}</dt><dd>${closed.length}</dd></div><div><dt>${esc(L('أفضل صفقة', 'Best trade'))}</dt><dd class="is-up" dir="ltr">${R(best)}</dd></div><div><dt>${esc(L('أسوأ صفقة', 'Worst trade'))}</dt><dd class="is-down" dir="ltr">${R(worst)}</dd></div></dl>`;
  }
  async function paintNews() {
    const box = news.querySelector('[data-news]');
    try {
      const r = await getFFNews();
      const items = (r.items || []).slice(0, 5);
      box.innerHTML = items.length ? items.map((n) => `<li><a href="${esc(n.url)}" target="_blank" rel="noopener"><i aria-hidden="true">${IC.news}</i><span lang="en" dir="auto">${esc(n.title)}</span><time>${esc(rel(n.time))}</time></a></li>`).join('')
        : `<li class="dw-empty">${esc(L('ما في عناوين هلأ.', 'No headlines right now.'))}</li>`;
    } catch { box.innerHTML = `<li class="dw-empty">${esc(L('تعذّر تحميل الأخبار هلأ. افتح صفحة الأخبار.', 'Could not load news right now.'))}</li>`; }
  }

  /* ── events ── */
  const pick = (e) => { const b = e.target.closest('[data-sym]'); if (b) { store.set('symbol', b.dataset.sym); window.scrollTo?.({ top: 0, behavior: 'smooth' }); } };
  watch.addEventListener('click', (e) => { const t = e.target.closest('[data-wl]'); if (t) { st.tab = t.dataset.wl; watch.querySelectorAll('[data-wl]').forEach((x) => x.setAttribute('aria-selected', String(x === t))); paintWatch(); return; } pick(e); });
  right.addEventListener('click', (e) => { const t = e.target.closest('[data-ht]'); if (t) { st.heat = t.dataset.ht; right.querySelectorAll('[data-ht]').forEach((x) => x.setAttribute('aria-selected', String(x === t))); paintHeat(); return; } pick(e); });
  trades.addEventListener('click', (e) => { const t = e.target.closest('[data-tr]'); if (t) { st.trades = t.dataset.tr; trades.querySelectorAll('[data-tr]').forEach((x) => x.setAttribute('aria-selected', String(x === t))); paintTrades(); } });
  perf.addEventListener('click', (e) => { const t = e.target.closest('[data-pf]'); if (t) { st.perf = t.dataset.pf; perf.querySelectorAll('[data-pf]').forEach((x) => x.setAttribute('aria-selected', String(x === t))); paintPerf(); } });

  let busy = false;
  async function refresh() {
    if (busy || document.hidden) return; busy = true;
    try {
      tk = await getTickers(ALL) || {};
      for (const [s, x] of Object.entries(tk)) { if (!Number.isFinite(x?.price)) continue; const a = hist.get(s) || []; if (a.at(-1) !== x.price) a.push(x.price); hist.set(s, a.slice(-30)); }
    } catch { /* keep last */ } finally { busy = false; }
    paintWatch(); paintMood(); paintHeat(); paintTrades();
  }
  paintWatch(); paintMood(); paintHeat(); paintSignals(); paintTrades(); paintPerf(); paintNews();
  const offSig = onSignals(paintSignals); const offTr = onTrades(() => { paintTrades(); paintPerf(); });
  const offSym = store.on('symbol', paintWatch);
  setTimeout(refresh, 600);
  const t1 = setInterval(refresh, 15_000); const t2 = setInterval(paintNews, 5 * 60_000);
  const stop = () => { clearInterval(t1); clearInterval(t2); offSig?.(); offTr?.(); offSym?.(); };
  return { watch, right, trades, perf, news, stop };
}
