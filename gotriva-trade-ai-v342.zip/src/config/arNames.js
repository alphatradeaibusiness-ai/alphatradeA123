// v336: Arabic market names for the Arabic interface (the ticker symbol itself stays as it is, like on every trading platform).
const N = {
  BTCUSDT: 'بيتكوين', ETHUSDT: 'إيثيريوم', SOLUSDT: 'سولانا', BNBUSDT: 'بي إن بي', XRPUSDT: 'ريبل', DOGEUSDT: 'دوجكوين', ADAUSDT: 'كاردانو',
  AVAXUSDT: 'أفالانش', LINKUSDT: 'تشينلينك', LTCUSDT: 'لايتكوين', TRXUSDT: 'ترون', DOTUSDT: 'بولكادوت', ATOMUSDT: 'كوزموس', NEARUSDT: 'نير',
  SUIUSDT: 'سوي', PEPEUSDT: 'بيبي',
  XAUUSD: 'الذهب / دولار', XAGUSD: 'الفضة / دولار', XPTUSD: 'البلاتين / دولار', XPDUSD: 'البلاديوم / دولار', COPPER: 'النحاس / دولار',
  USOIL: 'نفط غرب تكساس / دولار', UKOIL: 'نفط برنت / دولار', NATGAS: 'الغاز الطبيعي / دولار',
  US30: 'داو جونز 30', US100: 'ناسداك 100', SPX500: 'إس آند بي 500', US2000: 'راسل 2000', UK100: 'فوتسي 100 البريطاني', GER40: 'داكس 40 الألماني',
  FRA40: 'كاك 40 الفرنسي', EU50: 'يورو ستوكس 50', JP225: 'نيكاي 225 الياباني', HK50: 'هانغ سنغ', AUS200: 'إيه إس إكس 200 الأسترالي',
  SPAIN35: 'إيبكس 35 الإسباني', SWISS20: 'السويسري 20', NED25: 'إيه إي إكس 25 الهولندي', KOSPI: 'كوسبي الكوري', INDIA50: 'نيفتي 50 الهندي',
  EURUSD: 'يورو / دولار', GBPUSD: 'جنيه إسترليني / دولار', USDJPY: 'دولار / ين ياباني', USDCHF: 'دولار / فرنك سويسري', USDCAD: 'دولار / دولار كندي',
  AUDUSD: 'دولار أسترالي / دولار', NZDUSD: 'دولار نيوزيلندي / دولار', EURJPY: 'يورو / ين ياباني', GBPJPY: 'جنيه / ين ياباني', EURGBP: 'يورو / جنيه',
};
export const arName = (symbol) => N[String(symbol || '').toUpperCase()] || null;
