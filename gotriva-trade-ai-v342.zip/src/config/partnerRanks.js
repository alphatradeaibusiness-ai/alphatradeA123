// v255 Gotriva Partner Club — shared definitions (server + page). Everything here is a DEFAULT the platform owners can change
// from the admin panel (stored on the server); no commission percentage is set by default — the owners decide.
export const RANKS = [
  { id: 'core', from: 1, to: 10, name: { ar: 'كور', en: 'Core' }, color: '#38bdf8', metal: ['#0ea5e9', '#22d3ee'] },
  { id: 'bronze', from: 11, to: 20, name: { ar: 'برونزي', en: 'Bronze' }, color: '#cd7f32', metal: ['#8a5a2b', '#e0a46a'] },
  { id: 'silver', from: 21, to: 35, name: { ar: 'فضي', en: 'Silver' }, color: '#c0c7d1', metal: ['#8b95a3', '#eef2f7'] },
  { id: 'gold', from: 36, to: 50, name: { ar: 'ذهبي', en: 'Gold' }, color: '#f5c542', metal: ['#b8860b', '#ffe08a'] },
  { id: 'platinum', from: 51, to: 65, name: { ar: 'بلاتيني', en: 'Platinum' }, color: '#9fe7e0', metal: ['#5fb3ad', '#e6fffb'] },
  { id: 'diamond', from: 66, to: 80, name: { ar: 'ماسي', en: 'Diamond' }, color: '#7dd3fc', metal: ['#3b82f6', '#a5f3fc'] },
  { id: 'master', from: 81, to: 90, name: { ar: 'ماستر', en: 'Master' }, color: '#c084fc', metal: ['#7c3aed', '#e9d5ff'] },
  { id: 'elite', from: 91, to: 99, name: { ar: 'إيليت', en: 'Elite' }, color: '#f472b6', metal: ['#be185d', '#fbcfe8'] },
  { id: 'legend', from: 100, to: 100, name: { ar: 'أسطورة جوتريفا', en: 'Gotriva Legend' }, color: '#fde047', metal: ['#f59e0b', '#fef9c3'] },
];
// Milestone = paid referrals needed for the FIRST level of each rank (from the brief). Level 1 is unlocked on joining.
export const MILESTONES = { core: 1, bronze: 10, silver: 20, gold: 40, platinum: 70, diamond: 100, master: 150, elite: 250, legend: 500 };
// The seven subscription price points the commission matrix supports (USD cents). A product is matched by its list price.
export const PRICE_TIERS = [8000, 19000, 35000, 65000, 75000, 85000, 100000];

/** Default per-level requirements: strictly increasing, interpolated between the rank milestones. */
export function defaultLevels() {
  const out = [];
  RANKS.forEach((r, ri) => {
    const start = MILESTONES[r.id]; const next = RANKS[ri + 1] ? MILESTONES[RANKS[ri + 1].id] : start; const n = r.to - r.from + 1;
    for (let i = 0; i < n; i++) {
      const lv = r.from + i;
      let req = lv === 1 ? 0 : r.id === 'core' ? lv - 1 : Math.round(start + (i * (next - start)) / n);
      out.push({ level: lv, rank: r.id, req, rewardCents: 0 });
    }
  });
  for (let i = 1; i < out.length; i++) if (out[i].req <= out[i - 1].req) out[i].req = out[i - 1].req + 1;   // strictly increasing
  return out;
}
/** The benefits a rank can switch on (each one is enforced by the server — see server/partners.js). */
export const BENEFITS = {
  dashboard: { ar: 'لوحة الشريك', en: 'Partner dashboard' },
  link: { ar: 'رابط إحالة شخصي', en: 'Personal referral link' },
  coupon: { ar: 'كوبون شخصي', en: 'Personal coupon' },
  commission: { ar: 'عمولات على الاشتراكات', en: 'Subscription commissions' },
  stats_basic: { ar: 'إحصائيات أساسية', en: 'Basic statistics' },
  stats_plus: { ar: 'إحصائيات إضافية (حسب الخطة والشهر)', en: 'Additional statistics (by plan and month)' },
  analytics: { ar: 'تحليلات متقدمة (التحويل لكل مصدر ويوم)', en: 'Advanced analytics (conversion by source and day)' },
  multiplier: { ar: 'مضاعف عمولة الرتبة', en: 'Rank commission multiplier' },
  shorter_hold: { ar: 'فترة حجز أقصر', en: 'Shorter holding period' },
  lower_min_payout: { ar: 'حد سحب أدنى أقل', en: 'Lower minimum payout' },
  coupon_discount: { ar: 'خصم أكبر لعملاء كوبونك', en: 'Bigger discount for your coupon customers' },
  rank_bonus: { ar: 'مكافأة الوصول للرتبة', en: 'Rank achievement bonus' },
  recognition: { ar: 'تكريم خاص داخل التطبيق', en: 'Special recognition inside the app' },
};
export const DEFAULT_RANK_BENEFITS = {
  core: ['dashboard', 'link', 'coupon', 'commission', 'stats_basic'],
  bronze: ['dashboard', 'link', 'coupon', 'commission', 'stats_basic', 'stats_plus', 'rank_bonus'],
  silver: ['dashboard', 'link', 'coupon', 'commission', 'stats_basic', 'stats_plus', 'analytics', 'rank_bonus'],
  gold: ['dashboard', 'link', 'coupon', 'commission', 'stats_basic', 'stats_plus', 'analytics', 'multiplier', 'rank_bonus'],
  platinum: ['dashboard', 'link', 'coupon', 'commission', 'stats_basic', 'stats_plus', 'analytics', 'multiplier', 'shorter_hold', 'rank_bonus'],
  diamond: ['dashboard', 'link', 'coupon', 'commission', 'stats_basic', 'stats_plus', 'analytics', 'multiplier', 'shorter_hold', 'lower_min_payout', 'rank_bonus'],
  master: ['dashboard', 'link', 'coupon', 'commission', 'stats_basic', 'stats_plus', 'analytics', 'multiplier', 'shorter_hold', 'lower_min_payout', 'coupon_discount', 'rank_bonus'],
  elite: ['dashboard', 'link', 'coupon', 'commission', 'stats_basic', 'stats_plus', 'analytics', 'multiplier', 'shorter_hold', 'lower_min_payout', 'coupon_discount', 'rank_bonus'],
  legend: ['dashboard', 'link', 'coupon', 'commission', 'stats_basic', 'stats_plus', 'analytics', 'multiplier', 'shorter_hold', 'lower_min_payout', 'coupon_discount', 'rank_bonus', 'recognition'],
};
export const rankOfLevel = (lv) => RANKS.find((r) => lv >= r.from && lv <= r.to) || RANKS[0];
