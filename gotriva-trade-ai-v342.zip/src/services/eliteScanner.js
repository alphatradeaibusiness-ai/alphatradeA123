// v247 Gotriva Elite Signals — the market scanner. Runs on the 24/7 server worker (server/worker.js → elite-signals.json, read by
// /api/elite/feed) and, only when no server feed exists (a static deploy), in the browser with the same code.
//
// Every enabled market × every timeframe (15m / 1h / 4h) is evaluated once per newly CLOSED candle with eliteEngine.js
// (the AI recommendation strategies, each one independently). Open signals are followed on 1-minute candles. One market or one
// strategy failing never stops the others: errors are logged and the scan goes on. Nothing is published from demo, stale or
// missing data.
import { ELITE_MARKETS, eliteAvailability } from '../config/eliteMarkets.js';
import { evaluateMarket, trackSignal, markConflicts, ELITE_TFS, TF_SEC, LIVE_STATUSES, FINAL_STATUSES } from './eliteEngine.js';
import { presetCfg } from './multiStrategy.js';
import { engineMode } from './engineMode.js';

export const KEEP_DAYS = 14;
export const MAX_SIGNALS = 400;
const SCAN_EVERY_MS = 30_000;
const TRACK_EVERY_MS = 30_000;
const STALE_RETRY_MS = 5 * 60_000;

/** Market-data functions of the platform (lazy, so tests can inject their own). */
export async function defaultDeps() {
  const [mk, htf, news] = await Promise.all([import('./market/index.js'), import('./htfData.js'), import('./news.js')]);
  return {
    getHistory: mk.getHistory,
    quote: async (sym) => { const t = (await mk.getTickers([sym]))?.[sym]; return t && t.mode === 'live' && Number.isFinite(t.price) ? { price: t.price, at: Number.isFinite(t.at) ? t.at : Date.now(), bid: t.bid, ask: t.ask } : null; },
    prefetchHtf: htf.prefetchHtf, htfCandles: htf.htfCandles,
    calendar: async () => { try { const c = await news.getCalendar(); return Array.isArray(c?.events) ? { events: c.events, at: c.at ?? Date.now(), stale: Boolean(c.stale) } : null; } catch { return null; } },
  };
}

/**
 * store: { load() → state | null, save(state) } · onNew(signals) · onChange(state)
 * → { state(), scanOnce(), trackOnce(), start(), stop() }
 */
export function createEliteScanner({ deps, store, onNew = () => {}, onChange = () => {}, log = console, tfs = ELITE_TFS, markets = ELITE_MARKETS, now = Date.now, cfg = null } = {}) {
  let st = (() => { const s = store?.load?.(); return s && Array.isArray(s.signals) ? { signals: s.signals, markets: s.markets || {}, lastScan: s.lastScan || 0, lastTrack: s.lastTrack || 0, errors: s.errors || [] } : { signals: [], markets: {}, lastScan: 0, lastTrack: 0, errors: [] }; })();
  let D = deps || null; let timer = 0; let running = false; let busy = false;
  const save = () => { try { store?.save?.(st); } catch (e) { log.warn?.('[elite] save', e?.message); } onChange(st); };
  const err = (where, e) => { const m = String(e?.message || e).slice(0, 120); st.errors.unshift({ at: now(), where, msg: m }); st.errors = st.errors.slice(0, 30); log.warn?.(`[elite] ${where}: ${m}`); };
  const prune = () => {
    const keep = now() - KEEP_DAYS * 86_400_000;
    st.signals = st.signals.filter((s) => LIVE_STATUSES.includes(s.status) || (s.closedAt || s.createdAt) >= keep).sort((a, b) => b.createdAt - a.createdAt).slice(0, MAX_SIGNALS);
  };

  async function scanMarket(m) {
    const a = eliteAvailability(m);
    const ms = (st.markets[m.id] ||= { id: m.id, cat: m.cat, symbol: m.symbol, bars: {}, retry: {} });
    if (!a.ok) { Object.assign(ms, { state: 'unavailable', reason: a.reason, at: now() }); return []; }
    const added = [];
    for (const tf of tfs) {
      const sec = TF_SEC[tf]; const t = now();
      const lastClosed = Math.floor(t / 1000 / sec) * sec - sec;   // open time of the newest closed candle
      if (ms.bars[tf] === lastClosed && !(ms.retry[tf] && t >= ms.retry[tf])) continue;   // already evaluated on this candle
      try {
        const ds = await D.getHistory(a.symbol, tf, 600);
        if (!ds || ds.mode !== 'live') { Object.assign(ms, { state: 'unavailable', reason: ds?.mode === 'demo' ? 'demo_data' : 'no_data', at: t }); ms.bars[tf] = lastClosed; ms.retry[tf] = t + STALE_RETRY_MS; continue; }
        try { await D.prefetchHtf(a.symbol, sec); } catch { /* the engine then uses the chart's own structure */ }
        const [quote, calendar] = await Promise.all([D.quote(a.symbol).catch(() => null), D.calendar().catch(() => null)]);
        const r = evaluateMarket({ market: m, inst: a.inst, tf, ds, htf: D.htfCandles?.(a.symbol) || null, calendar, quote, nowMs: now(), signals: st.signals, cfg: cfg || presetCfg(engineMode()) });
        ms.bars[tf] = r.barTime ?? lastClosed;
        ms.retry[tf] = ['stale', 'closed', 'unavailable', 'insufficient'].includes(r.state) ? now() + STALE_RETRY_MS : 0;
        Object.assign(ms, { state: r.state === 'ok' || r.state === 'no_trade' ? 'live' : r.state, reason: r.state === 'ok' || r.state === 'no_trade' ? null : r.reason, at: now(), source: ds.source || null, price: quote?.price ?? ms.price ?? null });
        (ms.last ||= {})[tf] = { state: r.state, reason: r.reason, at: now(), rejected: (r.rejected || []).slice(0, 6).map((x) => ({ strategy: x.strategy, reason: x.reason })) };
        if (r.signals.length) { st.signals.unshift(...r.signals); added.push(...r.signals); }
      } catch (e) { err(`${m.id} ${tf}`, e); ms.retry[tf] = now() + 60_000; }
    }
    return added;
  }

  async function scanOnce() {
    D ||= await defaultDeps();
    const added = [];
    for (const m of markets) {
      try { added.push(...await scanMarket(m)); } catch (e) { err(m.id, e); }
      await new Promise((r) => setTimeout(r, 10));
    }
    markConflicts(st.signals); prune(); st.lastScan = now(); save();
    if (added.length) { try { onNew(added); } catch (e) { err('onNew', e); } }
    return added;
  }

  async function trackOnce() {
    D ||= await defaultDeps();
    const live = st.signals.filter((s) => LIVE_STATUSES.includes(s.status));
    const bySym = new Map(); for (const s of live) { if (!bySym.has(s.symbol)) bySym.set(s.symbol, []); bySym.get(s.symbol).push(s); }
    let changed = false;
    for (const [sym, list] of bySym) {
      try {
        const ds = await D.getHistory(sym, '1m', 300);
        if (!ds || ds.mode !== 'live' || !ds.candles?.length) continue;   // never follow a signal on generated prices
        const q = await D.quote(sym).catch(() => null);
        for (const s of list) {
          const before = `${s.status}|${s.hits}|${s.price}`;
          trackSignal(s, ds.candles, { nowMs: now(), barSec: 60, price: q?.price ?? null, priceAt: q?.at ?? null });
          if (`${s.status}|${s.hits}|${s.price}` !== before) changed = true;
        }
      } catch (e) { err(`track ${sym}`, e); }
    }
    st.lastTrack = now();
    if (changed) { markConflicts(st.signals); prune(); }
    save();
    return changed;
  }

  const loop = async () => {
    if (!running) return;
    if (!busy) {
      busy = true;
      try { if (now() - st.lastTrack >= TRACK_EVERY_MS) await trackOnce(); await scanOnce(); } catch (e) { err('loop', e); } finally { busy = false; }
    }
    if (running) timer = setTimeout(loop, SCAN_EVERY_MS);
  };
  return {
    state: () => st,
    scanOnce, trackOnce,
    start() { if (running) return; running = true; loop(); },
    stop() { running = false; clearTimeout(timer); },
  };
}

export { FINAL_STATUSES, LIVE_STATUSES };
