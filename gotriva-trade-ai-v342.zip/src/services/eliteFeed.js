// Gotriva Elite Signals in the page (v247). Runs for the whole app session:
//  • server mode: GET /api/elite/feed every 20 s — one shared feed for every member, made by the Elite market scanner on the
//    24/7 server worker (src/services/eliteScanner.js)
//  • local mode (no server feed on this host, e.g. a static deploy): the same scanner runs on this device while the site is open
//  • every NEW signal → an instant alert titled "Gotriva Elite Signals" (in-app + system notification when allowed)
import { apiRequest } from './ai/gateway.js';
import { auth } from './auth/index.js';
import { storage } from '../utils/storage.js';
import { ELITE_BRAND, eliteAlertBody } from './elite.js';
import { eliteSummary } from './eliteEngine.js';
import { ELITE_MARKETS, eliteAvailability } from '../config/eliteMarkets.js';
import { pairName } from './tradeMessages.js';
import { getLang } from '../i18n/index.js';

const POLL_MS = 20_000;
const LOCAL_KEY = 'elite-scan-v2';
const SEEN_KEY = 'elite-seen-v2';
const listeners = new Set();
const baseMarkets = () => ELITE_MARKETS.map((m) => { const a = eliteAvailability(m); return { id: m.id, cat: m.cat, region: m.region || null, symbol: m.symbol, state: a.ok ? 'pending' : 'unavailable', reason: a.reason }; });
let state = { mode: 'starting', signals: [], markets: baseMarkets(), summary: eliteSummary([]), at: 0, lastScan: null, error: null };
let timer = 0; let started = false; let serverOff = 0; let busy = false; let local = null;

export const eliteState = () => state;
export const onElite = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = () => listeners.forEach((fn) => { try { fn(state); } catch (e) { console.error(e); } });

const seen = () => new Set(storage.get(SEEN_KEY, []) || []);
function announce(signals, first) {
  const was = seen(); const fresh = signals.filter((p) => !was.has(p.id));
  storage.set(SEEN_KEY, [...new Set([...signals.map((p) => p.id), ...was])].slice(0, 600));
  if (first) return;   // the first load after opening the site shows the list, it does not ring for old signals
  for (const p of fresh.filter((x) => Date.now() - (x.createdAt || 0) < 15 * 60_000).slice(0, 3)) alertPick(p);
}
async function alertPick(p) {
  const body = eliteAlertBody(p, getLang(), pairName);   // same text as the server push; tag = the signal id, so a push and this never ring twice
  window.dispatchEvent(new CustomEvent('alpha-signal', { detail: { title: ELITE_BRAND, body, cardShown: false } }));
  if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
  const opts = { body, icon: '/elite/elite-icon-192.png', badge: '/elite/elite-icon-192.png', tag: p.id, renotify: false, lang: document.documentElement.lang, dir: document.documentElement.dir };
  try { const reg = await navigator.serviceWorker?.getRegistration(); if (reg) { await reg.showNotification(ELITE_BRAND, opts); return; } } catch { /* below */ }
  try { new Notification(ELITE_BRAND, opts); } catch { /* not allowed here (e.g. iOS without Home Screen) */ }
}

function set(next, first = false) {
  const prevIds = state.signals.map((p) => p.id).join();
  state = { ...state, ...next };
  if (state.signals.map((p) => p.id).join() !== prevIds || first) announce(state.signals, first);
  emit();
}

function localView(st, first = false) {
  const now = Date.now();
  const signals = st.signals.filter((x) => ['active', 'entry_hit', 'tp1', 'tp2'].includes(x.status) || now - (x.closedAt || x.createdAt || 0) < 7 * 86_400_000);
  const markets = baseMarkets().map((m) => { const ms = st.markets?.[m.id]; return m.state === 'unavailable' ? m : { ...m, state: ms?.state || 'pending', reason: ms?.reason || null, at: ms?.at || null }; });
  set({ mode: 'local', signals, markets, summary: eliteSummary(signals), at: now, lastScan: st.lastScan || null, error: null }, first);
}
async function startLocal() {
  if (local) return;
  const { createEliteScanner } = await import('./eliteScanner.js');
  if (local) return;
  let first = true;
  local = createEliteScanner({
    store: { load: () => storage.get(LOCAL_KEY, null), save: (st) => storage.set(LOCAL_KEY, { ...st, signals: st.signals.slice(0, 200) }) },
    onChange: (st) => { localView(st, first); first = false; },
    log: { warn: () => {} },
  });
  localView(local.state(), true); first = false;
  local.start();
}
const stopLocal = () => { local?.stop(); local = null; };

async function tick(first = false) {
  if (busy) return; busy = true;
  try {
    if (auth.current() && Date.now() >= serverOff && auth.mode !== 'local') {
      try {
        const d = await apiRequest('GET', '/api/elite/feed', undefined, 10_000);
        if (d?.configured && Array.isArray(d.signals)) { stopLocal(); set({ mode: 'server', signals: d.signals, markets: d.markets || baseMarkets(), summary: d.summary || eliteSummary(d.signals), at: d.at, lastScan: d.lastScan || null, error: null }, first); return; }
        serverOff = Date.now() + 5 * 60_000;   // the server has no Elite scanner: scan on this device for a while
      } catch (e) { if (['server_missing', 'server_unreachable', 'bad_reply'].includes(e?.code)) serverOff = Date.now() + 5 * 60_000; else { state = { ...state, error: e?.code || 'error' }; emit(); } }
    }
    await startLocal();
  } finally { busy = false; }
}

export function startElite() {
  if (started) return; started = true;
  tick(true);
  timer = setInterval(() => { if (!document.hidden) tick(); }, POLL_MS);
  document.addEventListener('visibilitychange', onVis);
}
const onVis = () => { if (!document.hidden) tick(); };
export function stopElite() { clearInterval(timer); stopLocal(); document.removeEventListener('visibilitychange', onVis); started = false; }
export const refreshElite = () => tick();
