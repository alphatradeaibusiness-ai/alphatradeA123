// News alerts with sound (v318). Every refresh of the ticker feeds the calendar + headlines here; a HIGH-impact item that is NEW
// since the last look rings once: a short chime and an in-app alert titled with the item's currency ("USD · CPI m/m"). A calendar
// event rings when its actual number is published (and once more when it is about to release, 5 min before). First load stays silent.
import { storage } from '../utils/storage.js';
import { getLang } from '../i18n/index.js';

const SEEN = 'news-alert-seen-v1'; const SOUND = 'news-sound';
export const newsSoundOn = () => storage.get(SOUND, true) !== false;
export const setNewsSound = (on) => storage.set(SOUND, !!on);

let ctx = null;
/** Two short rising tones. Browsers only allow it after a tap on the page; failing silently is fine (the alert still shows). */
export function chime() {
  try {
    ctx ||= new (window.AudioContext || window.webkitAudioContext)(); if (ctx.state === 'suspended') ctx.resume?.();
    const t0 = ctx.currentTime;
    [[880, 0], [1320, 0.16]].forEach(([f, d]) => { const o = ctx.createOscillator(); const g = ctx.createGain(); o.type = 'sine'; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t0 + d); g.gain.exponentialRampToValueAtTime(0.18, t0 + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d + 0.28); o.connect(g).connect(ctx.destination); o.start(t0 + d); o.stop(t0 + d + 0.3); });
  } catch { /* no audio here */ }
}

/** Pure: which items ring now? → [{ key, title, body }] (exported for tests) */
export function dueAlerts(events, headlines, seen, now = Date.now(), lang = 'ar') {
  const ar = lang === 'ar'; const out = [];
  for (const e of Array.isArray(events) ? events : []) {
    if (e.impact !== 'High') continue;
    const base = `${e.country}|${e.title}|${e.time}`;
    if (e.actual && now - e.time < 6 * 3600e3 && !seen.has(`${base}|actual`)) {
      out.push({ key: `${base}|actual`, title: `${e.country} · ${e.title}`, body: `${ar ? 'صدر' : 'Released'}: ${e.actual}${e.forecast ? ` · ${ar ? 'المتوقع' : 'forecast'} ${e.forecast}` : ''}${e.previous ? ` · ${ar ? 'السابق' : 'previous'} ${e.previous}` : ''}` });
    } else if (!e.actual && e.time - now <= 5 * 60e3 && e.time - now > -60e3 && !seen.has(`${base}|soon`)) {
      out.push({ key: `${base}|soon`, title: `${e.country} · ${e.title}`, body: ar ? 'خبر عالي التأثير بعد دقايق' : 'High-impact news in a few minutes' });
    }
  }
  for (const n of Array.isArray(headlines) ? headlines : []) {
    if (n.impact !== 'High' || !n.id || seen.has(`n|${n.id}`)) continue;
    if (n.time != null && now - n.time > 30 * 60e3) continue;
    out.push({ key: `n|${n.id}`, title: n.source ? `${n.source}` : (ar ? 'خبر عاجل' : 'Breaking'), body: n.title });
  }
  return out;
}

let first = true;
export function checkNewsAlerts(events, headlines) {
  if (events == null && headlines == null) return;
  const seen = new Set(storage.get(SEEN, []) || []);
  const due = dueAlerts(events, headlines, seen, Date.now(), getLang());
  due.forEach((d) => seen.add(d.key));
  if (due.length) storage.set(SEEN, [...seen].slice(-400));
  if (first) { first = false; return; }   // opening the site never rings for what was already there
  const fresh = due.slice(0, 3); if (!fresh.length) return;
  if (newsSoundOn()) chime();
  for (const d of fresh) window.dispatchEvent(new CustomEvent('alpha-signal', { detail: { title: d.title, body: d.body, cardShown: false } }));
}
