// The Gotriva Radar's directional score, in one place so the radar and the AI engine use the exact
// same formula: trend (EMA 50/200) 30%, momentum 25%, SMC structure 30%, RSI 15%. Range −1 … +1.
const clamp = (v) => Math.max(-1, Math.min(1, v));

export function radarParts({ price, e50, e200, rsi, momentum, smcTrend, smcFresh }) {
  const trend = price > e50 && e50 > e200 ? 1 : price < e50 && e50 < e200 ? -1 : price > e200 ? 0.4 : -0.4;
  const smcDir = smcTrend === 'bull' ? 1 : smcTrend === 'bear' ? -1 : 0;
  return [
    ['trend', trend, 0.3],
    ['momentum', momentum != null ? (momentum - 50) / 50 : 0, 0.25],
    ['smc', smcDir * (smcFresh ? 1 : 0.6), 0.3],
    ['rsi', Number.isFinite(rsi) ? clamp((rsi - 50) / 20) : 0, 0.15],
  ];
}
export const radarBias = (parts) => parts.reduce((s, [, v, w]) => s + v * w, 0);
