// Gotriva Market Replay (v233). Real historical candles around a chosen date, replayed bar by bar.
// No look-ahead: the reading at bar i is computed ONLY from candles[0..i] (cached per index once computed, and every cached
// value was itself computed from data up to its own index). A simulated trade only advances on bars the cursor has passed.
// The replay reading is the radar's directional core (EMA 50/200 + RSI + MACD + market structure / sweeps) — the full
// back-test part of the live radar is not re-run per bar; this is said on the page.
import { getInstrument } from '../config/instruments.js';
import { TIMEFRAMES } from '../config/market.js';
import { fetchBinanceCandles } from './market/binance.js';
import { getHistory } from './market/index.js';
import { quickBiasOf, smartMoneyFlow, cleanCandles, TF_SEC } from './radarPro.js';
import { atr } from '../indicators/index.js';
import { makeOpp, stepOpp } from './radarTracker.js';

export const WARMUP = 220;   // candles needed before the first reading (EMA 200)

/** Real candles around `dateMs` (≈ 450 before, ≈ 450 after). → { candles, startIndex, source } or throws { code }. */
export async function loadReplay(symbol, tf, dateMs, now = Date.now()) {
  const inst = getInstrument(symbol); const def = TIMEFRAMES.find((x) => x.id === tf); const sec = TF_SEC[tf];
  if (!inst || !def) throw Object.assign(new Error('bad'), { code: 'bad' });
  if (!(dateMs < now)) throw Object.assign(new Error('future'), { code: 'future' });
  let candles, source;
  if (inst.provider === 'binance') {
    const end = Math.min(now, dateMs + 450 * sec * 1000);
    candles = cleanCandles(await fetchBinanceCandles(symbol, def.binance, 1000, end)); source = 'Binance';
  } else {
    const ds = await getHistory(symbol, tf, 2000);
    if (!ds || ds.mode !== 'live') throw Object.assign(new Error('nolive'), { code: 'noLive' });
    candles = cleanCandles(ds.candles); source = ds.source;
  }
  if (!candles.length) throw Object.assign(new Error('empty'), { code: 'empty' });
  const t = Math.floor(dateMs / 1000);
  let idx = candles.findIndex((c) => c.time >= t);
  if (idx < 0) idx = candles.length - 1;
  if (idx < WARMUP || candles[0].time > t) {
    throw Object.assign(new Error('range'), { code: 'outOfRange', from: (candles[Math.min(WARMUP, candles.length - 1)]?.time || 0) * 1000, to: candles.at(-1).time * 1000 });
  }
  return { candles, startIndex: idx, source };
}

/** Replay engine over a fixed candle array. All results depend only on candles up to the index asked. */
export function createReplay(candles, { tf, symbol, precision = 2 } = {}) {
  const readings = new Array(candles.length).fill(undefined);
  const reading = (i) => {
    if (i < WARMUP) return null;
    if (readings[i] !== undefined) return readings[i];
    const past = candles.slice(Math.max(0, i - 400), i + 1);           // the window ends AT i — nothing after it
    const bias = quickBiasOf(past);
    const smf = smartMoneyFlow(past, { lookback: 250 });   // historical bars are all closed
    const a = atr(past, 14).at(-1);
    const ev = smf?.events?.at(-1) || null;
    const dir = bias == null ? null : bias >= 0.55 && ev?.dir === 'bull' && ev.ago <= 20 ? 'long' : bias <= -0.55 && ev?.dir === 'bear' && ev.ago <= 20 ? 'short' : null;
    readings[i] = { i, time: candles[i].time, price: candles[i].close, bias, dir, event: ev, sweep: smf?.sweeps?.find((s) => s.ago <= 2) || null, zone: smf?.zone || null, atr: a };
    return readings[i];
  };
  /** Signals and simulated trades up to (and including) bar `cursor`. */
  const state = (cursor) => {
    const trades = []; let open = null; let cool = -1;
    for (let i = WARMUP; i <= cursor; i++) {
      if (open) { const { opp } = stepOpp(open, [candles[i]], candles[i].time * 1000); open = opp; if (open.closed) { trades.push(open); open = null; cool = i + 3; } continue; }
      if (i < cool) continue;
      const r = reading(i); if (!r?.dir || !(r.atr > 0)) continue;
      const o = makeOpp({ symbol, tf, direction: r.dir, price: r.price, precision, atrPct: (r.atr / r.price) * 100, setup: null, score: 0, mode: 'live' }, null, candles[i].time * 1000);
      if (o) { open = { ...o, lastBar: candles[i].time + 1, signalIndex: i, event: r.event?.kind || null }; }
    }
    return { trades, open };
  };
  return { candles, reading, state, length: candles.length };
}
