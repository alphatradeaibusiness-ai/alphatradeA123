// SMC / ICT trade assistant — the rules behind the sidebar panel. Pure functions: nothing here reads the store,
// the network or the clock (the caller passes `now`), so every number on screen can be reproduced in a test.
//
// What it reads from the candles (and from the real 4h / Daily candles when they are loaded):
//   • Bias            market structure on the higher frames (swing: Daily [+4h]; scalp: 4h + 1h). Frames that
//                     disagree → no trade. Without higher-frame data the chart's own structure is used and said so.
//   • Liquidity       buy-side above (unswept swing highs, equal highs, previous day/week high, session highs) and
//                     sell-side below (the mirror). These are the targets.
//   • Sweep + shift   a wick through a liquidity level that closed back inside, then a break of structure the other
//                     way (ICT "market structure shift"). Adds confluence; not required.
//   • POI             an order block that is still valid (no close through its far edge) or an unfilled fair value
//                     gap, on the bias side of price, in discount for a buy / premium for a sell.
//   • Kill zones      London 02:00–05:00 and New York 07:00–10:00 New York time (scalp, non-crypto).
//
// Entry: limit → OB near edge, or the FVG midpoint (consequent encroachment). market → only when price is in the POI
// right now and the candle reacts in the trade's direction; otherwise the answer is "wait".
// Stop: beyond the POI (or the sweep wick when it is lower/higher) plus an ATR buffer. Targets: the nearest liquidity
// pools in the trade's direction, R-multiples only when there are fewer than three pools.
// Every condition is listed with pass / fail. The count is a checklist, NOT a probability of winning.
import { atr } from '../indicators/index.js';
import { findSwings, findStructure, orderBlockFor, obInvalidated, findFVGs, sessionLevels } from '../indicators/smc.js';
import { aggregate, structureTimeline, killZone } from './smc2.js';

const H1 = 3600; const H4 = 14400; const D1 = 86400; const W1 = 604800;
const WEEK_OFFSET = 4 * D1;   // Unix weeks start on Thursday; ICT weeks start on Monday 00:00 UTC

export const STYLES = {
  swing: { len: 5, sweepBars: 40, poiDistAtr: 8, bufAtr: 0.3, minRiskAtr: 0.6, maxRiskAtr: 6, minTp1R: 1.5, maxR: 10, minRR: 2.5, fallbackR: [2, 3, 5], expiryBars: 30, frames: ['d1', 'h4'], tfs: ['1h', '4h', '1D'] },
  scalp: { len: 3, sweepBars: 24, poiDistAtr: 5, bufAtr: 0.15, minRiskAtr: 0.3, maxRiskAtr: 3, minTp1R: 1, maxR: 6, minRR: 2, fallbackR: [1.5, 2.5, 3.5], expiryBars: 16, frames: ['h4', 'h1'], tfs: ['1m', '5m', '15m'] },
};
export const ASSETS = ['crypto', 'forex', 'metal', 'index', 'energy', 'stock'];
export const ACCOUNTS = {
  spot: { riskPct: 1, leverage: 1, short: false },                       // cash account: no leverage, no short selling
  margin: { riskPct: 1, leverage: 10, short: true },                      // CFD / futures with leverage
  prop: { riskPct: 0.5, leverage: 30, short: true, dailyLossPct: 5, maxLossPct: 10 },   // funded-challenge style limits
  demo: { riskPct: 1, leverage: 10, short: true },
};
export const MAX_RISK_PCT = 5;
// Round-trip trading cost (spread + commission) in % of price, a typical retail figure per market. The user can change it.
export const COSTS = { crypto: 0.1, forex: 0.01, metal: 0.04, index: 0.03, energy: 0.06, stock: 0.1 };
// Lower timeframe used to confirm an entry inside the zone ("confirm" execution).
// Conditions that are information only by default; the user can make any of them required (e.g. after a back-test showed it helps).
export const OPTIONAL = ['structure', 'sweep', 'mss', 'ote', 'killzone', 'ltf', 'nyopen', 'silver', 'volume', 'judas'];
export const LTF = { '1D': '1h', '4h': '15m', '1h': '5m', '15m': '1m', '5m': '1m' };
// Contract size of one standard lot, where it is a market convention. Others differ by broker → units only.
const LOT = { forex: 100000, XAUUSD: 100 };

const round = (v, d = 8) => (Number.isFinite(v) ? Math.round(v * 10 ** d) / 10 ** d : v);
const num = (v, d) => { if (v === '' || v == null) return d; const n = Number(v); return Number.isFinite(n) ? n : d; };

/** Clean the panel's inputs (anything odd falls back to a safe default). */
export function cleanInputs(i = {}) {
  const style = STYLES[i.style] ? i.style : 'swing';
  const account = ACCOUNTS[i.account] ? i.account : 'margin';
  const acc = ACCOUNTS[account];
  const riskPct = Math.min(MAX_RISK_PCT, Math.max(0.05, num(i.riskPct, acc.riskPct)));
  const leverage = account === 'spot' ? 1 : Math.min(500, Math.max(1, Math.round(num(i.leverage, acc.leverage))));
  const asset = ASSETS.includes(i.asset) ? i.asset : 'crypto';
  return {
    style, account, riskPct, leverage, asset,
    execution: ['market', 'confirm'].includes(i.execution) ? i.execution : 'limit',
    capital: Math.max(0, Math.min(1e12, num(i.capital, 0))),
    costPct: Math.min(2, Math.max(0, num(i.costPct, COSTS[asset]))),
    maxDailyLossPct: Math.min(50, Math.max(0, num(i.maxDailyLossPct, acc.dailyLossPct ?? 3))),
    require: Array.isArray(i.require) ? OPTIONAL.filter((x) => i.require.includes(x)) : [],
    maxOpen: Math.round(Math.min(20, Math.max(1, num(i.maxOpen, 3)))),
  };
}

/* ───────── higher-timeframe bias ───────── */
/** Weekly bars from Monday 00:00 UTC. */
export function weekly(bars) {
  const out = [];
  for (const c of bars) {
    const key = Math.floor((c.time - WEEK_OFFSET) / W1);
    const last = out.at(-1);
    if (last && last.key === key) { last.high = Math.max(last.high, c.high); last.low = Math.min(last.low, c.low); last.close = c.close; }
    else out.push({ key, time: key * W1 + WEEK_OFFSET, open: c.open, high: c.high, low: c.low, close: c.close });
  }
  return out;
}
function frameBars(cs, tfSec, frame, htf) {
  if (frame === 'd1') return htf?.d1?.length ? { bars: htf.d1, span: D1 } : tfSec < D1 ? { bars: aggregate(cs, D1), span: D1 } : null;
  if (frame === 'h4') return htf?.h4?.length ? { bars: htf.h4, span: H4 } : tfSec < H4 ? { bars: aggregate(cs, H4), span: H4 } : null;
  if (frame === 'h1') return tfSec < H1 ? { bars: aggregate(cs, H1), span: H1 } : null;
  if (frame === 'w1') return tfSec < W1 ? { bars: weekly(htf?.d1?.length ? htf.d1 : cs), span: W1 } : null;
  return null;
}
/** Trend on each higher frame known at the last candle (only closed bars). */
export function htfBias(cs, tfSec, style, htf = null) {
  const at = cs.at(-1).time + tfSec;
  const frames = {};
  const list = style === 'swing' && tfSec >= D1 ? ['w1'] : STYLES[style].frames;
  for (const f of list) {
    const fb = frameBars(cs, tfSec, f, htf);
    if (!fb || fb.span <= tfSec) continue;
    const trendAt = structureTimeline(fb.bars, fb.span, 12);
    const tr = trendAt(at);
    if (tr) frames[f] = tr;
  }
  const vals = Object.values(frames);
  const bias = !vals.length ? null : vals.every((v) => v === vals[0]) ? vals[0] : 'mixed';
  return { frames, bias, source: htf?.d1?.length || htf?.h4?.length ? 'htf' : 'chart' };
}

/* ───────── liquidity ───────── */
function untaken(cs, s) {
  for (let j = s.index + 1; j < cs.length; j++) if (s.type === 'high' ? cs[j].high > s.price : cs[j].low < s.price) return false;
  return true;
}
/** Previous day / week high and low (closed periods only). */
function periodLevels(cs, tfSec, htf) {
  const out = [];
  const d1 = htf?.d1?.length ? htf.d1 : tfSec < D1 ? aggregate(cs, D1) : null;
  if (d1 && d1.length >= 2) { const p = d1.at(-2); out.push({ kind: 'PDH', price: p.high, time: p.time }, { kind: 'PDL', price: p.low, time: p.time }); }
  const base = d1 && d1.length > 8 ? d1 : cs;
  if (tfSec < W1 && base.length > 8) {
    const wk = weekly(base);
    if (wk.length >= 2) { const p = wk.at(-2); out.push({ kind: 'PWH', price: p.high, time: p.time }, { kind: 'PWL', price: p.low, time: p.time }); }
  }
  return out;
}
export function liquidityMap(cs, swings, tfSec, a, style, htf) {
  const last = cs.at(-1).close;
  const open = swings.filter((s) => untaken(cs, s));
  const tol = 0.15 * a;
  const eq = [];
  // Equal highs / lows: two or more untaken swings within 0.15 ATR — resting stops that price tends to run.
  for (const type of ['high', 'low']) {
    const list = open.filter((s) => s.type === type).sort((x, y) => x.price - y.price);
    for (let i = 0; i < list.length - 1; i++) {
      if (Math.abs(list[i + 1].price - list[i].price) <= tol) {
        const p = type === 'high' ? Math.max(list[i].price, list[i + 1].price) : Math.min(list[i].price, list[i + 1].price);
        if (!eq.some((e) => e.type === type && Math.abs(e.price - p) <= tol)) eq.push({ type, kind: type === 'high' ? 'EQH' : 'EQL', price: p, time: Math.min(list[i].time, list[i + 1].time) });
      }
    }
  }
  const levels = [
    ...open.map((s) => ({ kind: s.type === 'high' ? 'BSL' : 'SSL', price: s.price, time: s.time })),
    ...eq.map((e) => ({ kind: e.kind, price: e.price, time: e.time })),
    ...periodLevels(cs, tfSec, htf),
  ];
  if (style === 'scalp') for (const s of sessionLevels(cs, tfSec)) levels.push({ kind: `${s.name} H`, price: s.high, time: s.highTime }, { kind: `${s.name} L`, price: s.low, time: s.lowTime });
  // Buy-side liquidity is a HIGH above price (stops of shorts / breakout buys); sell-side is a LOW below it.
  const isHigh = (l) => /(BSL|EQH|PDH|PWH| H)$/.test(l.kind);
  const above = levels.filter((l) => l.price > last && isHigh(l)).sort((x, y) => x.price - y.price);
  const below = levels.filter((l) => l.price < last && !isHigh(l)).sort((x, y) => y.price - x.price);
  return { above, below, eq };
}

/** Latest liquidity sweep: a wick through an untaken swing (or the previous day's level) that closed back inside. */
export function findSweep(cs, swings, bars, extra = []) {
  for (let i = cs.length - 1; i >= Math.max(1, cs.length - bars); i--) {
    const c = cs[i];
    // Previous day / week levels only count from the end of their period (index of the first candle after it).
    const periodStart = (l) => { const end = l.time + (/^PW/.test(l.kind) ? W1 : D1); let j = 0; while (j < cs.length && cs[j].time < end) j++; return j - 1; };
    const prior = [...swings.filter((s) => s.index < i - 1 && s.index >= i - 200), ...extra.map((l) => ({ ...l, type: /H$/.test(l.kind) ? 'high' : 'low', index: periodStart(l) })).filter((l) => l.index >= 0 && l.index < i)];
    for (const s of prior) {
      let taken = false;
      for (let j = s.index + 1; j < i; j++) if (s.type === 'high' ? cs[j].high > s.price : cs[j].low < s.price) { taken = true; break; }
      if (taken) continue;
      if (s.type === 'low' && c.low < s.price && c.close > s.price) return { dir: 'bull', level: s.price, extreme: c.low, index: i, time: c.time, levelTime: s.time };
      if (s.type === 'high' && c.high > s.price && c.close < s.price) return { dir: 'bear', level: s.price, extreme: c.high, index: i, time: c.time, levelTime: s.time };
    }
  }
  return null;
}

/* ───────── points of interest ───────── */
export function pointsOfInterest(cs, events, a, fvgMinAtr = 0.1) {
  const fvgs = findFVGs(cs, Math.min(cs.length, 250)).filter((g) => g.top - g.bottom >= fvgMinAtr * a);
  const obs = [];
  for (let i = events.length - 1; i >= 0 && obs.length < 8; i--) {
    if (cs.length - events[i].index > 250) break;
    const ob = orderBlockFor(cs, events[i]);
    if (!ob || obInvalidated(cs, ob) || obs.some((o) => o.index === ob.index)) continue;
    let mitigated = false;
    for (let j = ob.breakIndex + 1; j < cs.length; j++) if (ob.dir === 'bull' ? cs[j].low <= ob.top : cs[j].high >= ob.bottom) { mitigated = true; break; }
    // Displacement: the move that broke structure left an imbalance (FVG) behind — the ICT quality check for an OB.
    let withFvg = false;
    for (let k = ob.index + 2; k <= Math.min(cs.length - 1, ob.breakIndex + 2) && !withFvg; k++) withFvg = ob.dir === 'bull' ? cs[k].low > cs[k - 2].high : cs[k].high < cs[k - 2].low;
    obs.push({ ...ob, kind: 'OB', event: events[i].kind, mitigated, withFvg });
  }
  return { obs, fvgs: fvgs.slice(-8).map((g) => ({ ...g, kind: 'FVG' })), breakers: breakerBlocks(cs, events, a), ifvgs: inverseFvgs(cs, a, fvgMinAtr) };
}

/**
 * Breaker blocks: an order block that price CLOSED through (it failed) flips sides — a failed bullish OB becomes resistance
 * (bearish breaker) and the reverse. Valid until a later close goes back through it.
 */
export function breakerBlocks(cs, events, a) {
  const out = [];
  for (let i = events.length - 1; i >= 0 && out.length < 4; i--) {
    if (cs.length - events[i].index > 250) break;
    const ob = orderBlockFor(cs, events[i]); if (!ob) continue;
    let v = -1;
    for (let j = ob.breakIndex + 1; j < cs.length; j++) if (ob.dir === 'bull' ? cs[j].close < ob.bottom : cs[j].close > ob.top) { v = j; break; }
    if (v < 0 || out.some((o) => o.index === ob.index)) continue;
    const dir = ob.dir === 'bull' ? 'bear' : 'bull';
    let alive = true;
    for (let j = v + 1; j < cs.length; j++) if (dir === 'bear' ? cs[j].close > ob.top : cs[j].close < ob.bottom) { alive = false; break; }
    if (alive && ob.top - ob.bottom > 0.05 * a) out.push({ dir, top: ob.top, bottom: ob.bottom, index: ob.index, time: ob.time, flipTime: cs[v].time, kind: 'BB', mitigated: false, withFvg: false });
  }
  return out;
}

/** Inverse FVGs: a fair value gap that price closed fully through flips sides. Valid until a close goes back through it. */
export function inverseFvgs(cs, a, minAtr = 0.1) {
  const out = [];
  for (let i = Math.max(2, cs.length - 250); i < cs.length; i++) {
    const p = cs[i - 2]; const c = cs[i];
    const g = c.low > p.high ? { dir: 'bull', top: c.low, bottom: p.high } : c.high < p.low ? { dir: 'bear', top: p.low, bottom: c.high } : null;
    if (!g || g.top - g.bottom < minAtr * a) continue;
    let v = -1;
    for (let j = i + 1; j < cs.length; j++) if (g.dir === 'bull' ? cs[j].close < g.bottom : cs[j].close > g.top) { v = j; break; }
    if (v < 0) continue;
    const dir = g.dir === 'bull' ? 'bear' : 'bull';
    let alive = true;
    for (let j = v + 1; j < cs.length; j++) if (dir === 'bear' ? cs[j].close > g.top : cs[j].close < g.bottom) { alive = false; break; }
    if (alive) out.push({ dir, top: g.top, bottom: g.bottom, index: i - 1, time: cs[i - 1].time, flipTime: cs[v].time, kind: 'IFVG' });
  }
  return out.slice(-4);
}

/** Volume of the candle that created a zone ÷ its 20-candle average, or null without real volume. */
export function displacementVolume(cs, poi) {
  if (!poi || cs.filter((c) => c.volume > 0).length < cs.length * 0.8) return null;
  let idx = poi.index;
  if (poi.kind === 'OB' && Number.isInteger(poi.breakIndex)) {
    idx = poi.index + 1;
    for (let k = poi.index + 1; k <= Math.min(poi.breakIndex, cs.length - 1); k++) if (Math.abs(cs[k].close - cs[k].open) > Math.abs(cs[idx].close - cs[idx].open)) idx = k;
  } else if (poi.kind === 'BB' || poi.kind === 'IFVG') idx = cs.findIndex((c) => c.time === poi.flipTime);
  if (!(idx >= 20) || idx >= cs.length) return null;
  let sum = 0; for (let k = idx - 20; k < idx; k++) sum += cs[k].volume || 0;
  return sum > 0 ? cs[idx].volume / (sum / 20) : null;
}

/* ───────── New York clock: midnight open and Silver Bullet hours ───────── */
const nyFmt = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', hour: 'numeric', minute: 'numeric', hourCycle: 'h23' });
export function nyClock(timeSec) {
  const parts = nyFmt.formatToParts(new Date(timeSec * 1000));
  return { h: Number(parts.find((x) => x.type === 'hour').value), m: Number(parts.find((x) => x.type === 'minute').value) };
}
/** Open of the candle at 00:00 New York time of the current NY day (intraday charts ≤ 1h), or null. */
export function nyMidnightOpen(cs, tfSec) {
  if (!(tfSec <= H1)) return null;
  const stop = cs.at(-1).time - 26 * H1;
  for (let i = cs.length - 1; i >= 0 && cs[i].time >= stop; i--) {
    const k = nyClock(cs[i].time);
    if (k.h === 0 && k.m === 0) return { price: cs[i].open, time: cs[i].time };
  }
  return null;
}
/** ICT Silver Bullet windows (New York time): 03–04, 10–11, 14–15. */
export function silverBullet(timeSec) { const { h } = nyClock(timeSec); return h === 3 ? 'london' : h === 10 ? 'am' : h === 14 ? 'pm' : null; }

/* ───────── position size ───────── */
export function sizePosition({ capital, riskPct, entry, stop, account, leverage, asset, symbol, targets = [] }) {
  const dist = Math.abs(entry - stop);
  if (!(capital > 0) || !(dist > 0) || !(entry > 0)) return null;
  let riskAmount = (capital * riskPct) / 100;
  let units = riskAmount / dist;
  let capped = null;
  const lev = account === 'spot' ? 1 : Math.max(1, leverage || 1);
  if (units * entry > capital * lev) { units = (capital * lev) / entry; riskAmount = units * dist; capped = account === 'spot' ? 'capital' : 'leverage'; }
  const notional = units * entry;
  const lotSize = LOT[symbol] || LOT[asset] || null;
  return {
    riskAmount: round(riskAmount, 2), riskPctActual: round((riskAmount / capital) * 100, 3), units: round(units, 8), notional: round(notional, 2),
    margin: round(notional / lev, 2), leverage: lev, lots: lotSize ? round(units / lotSize, 4) : null, lotSize, capped,
    rewards: targets.map((tp) => round(Math.abs(tp - entry) * units, 2)),
    // Equal parts at each target (the management the results assume): units to close at each one.
    parts: targets.length ? targets.map(() => round(units / targets.length, 8)) : [],
  };
}

/* ───────── lower-timeframe confirmation ───────── */
/**
 * Inside the zone, wait for the lower timeframe to turn: after price taps the POI, a candle must CLOSE beyond the high (long) /
 * low (short) of the last opposite-colour candle before the lowest (highest) point since the tap — a small change of character.
 * Entry = that close; stop = the extreme made since the tap.
 * Only LTF candles inside [from, to) are used, so a test never sees later prices.
 */
export function ltfConfirm(ltf, poi, dir, from, to, buffer) {
  if (!ltf?.length) return { status: 'no_data' };
  const seg = ltf.filter((c) => c.time >= from && c.time < to);
  if (seg.length < 4) return { status: 'no_data' };
  const long = dir === 'bull';
  const tap = seg.findIndex((c) => (long ? c.low <= poi.top : c.high >= poi.bottom));
  if (tap < 0) return { status: 'waiting' };
  // Reference: the high (long) / low (short) of the last opposite-colour candle at or before the extreme since the tap.
  const refAt = (k) => { for (let i = k; i >= Math.max(0, k - 5); i--) { const c = seg[i]; if (long ? c.close < c.open : c.close > c.open) return long ? c.high : c.low; } return long ? seg[k].high : seg[k].low; };
  let ext = tap;
  for (let j = tap + 1; j < seg.length; j++) {
    const c = seg[j];
    if (long ? c.close < poi.bottom : c.close > poi.top) return { status: 'invalid' };   // closed through the zone
    if (long ? c.low <= seg[ext].low : c.high >= seg[ext].high) { ext = j; continue; }
    const ref = refAt(ext);
    if (long ? c.close > ref : c.close < ref) return { status: 'confirmed', entry: c.close, stop: long ? seg[ext].low - buffer : seg[ext].high + buffer, time: c.time, ref };
  }
  return { status: 'tapped', ref: refAt(ext) };
}

/* ───────── the analysis ───────── */
/**
 * @param candles chart candles (oldest first; the last one may still be forming)
 * @param input   panel inputs (see cleanInputs) + { symbol, tfSec, htf: {h4,d1}|null }
 */
export function analyzeSmcIct(candles, input = {}) {
  const o = cleanInputs(input);
  const P = STYLES[o.style];
  const tfSec = input.tfSec || (candles?.length > 1 ? candles[1].time - candles[0].time : 3600);
  const base = { inputs: o, symbol: input.symbol || '', tfSec, style: o.style };
  if (!candles || candles.length < 80) return { ...base, verdict: 'insufficient', reasons: ['insufficient_data'], checks: [], zones: emptyZones() };
  const cs = candles;
  const last = cs.at(-1);
  const a = atr(cs, 14).at(-1) || (last.high - last.low) || last.close * 0.001;
  const swings = findSwings(cs, P.len);
  const { events, trend } = findStructure(cs, swings, P.len);
  const bias = htfBias(cs, tfSec, o.style, input.htf);
  const liq = liquidityMap(cs, swings, tfSec, a, o.style, input.htf);
  const periodExtras = [...liq.above, ...liq.below].filter((l) => /^P[DW][HL]$/.test(l.kind));
  const sweep = findSweep(cs, swings, P.sweepBars, periodExtras);
  const mss = sweep ? events.find((e) => e.index > sweep.index && e.dir === sweep.dir) || null : null;
  const { obs, fvgs, breakers, ifvgs } = pointsOfInterest(cs, events, a);

  // Dealing range: the latest confirmed swing high and swing low → premium (above 50%) / discount (below), OTE 62–79%.
  const hi = [...swings].reverse().find((s) => s.type === 'high');
  const lo = [...swings].reverse().find((s) => s.type === 'low');
  const range = hi && lo && hi.price > lo.price ? { high: hi.price, low: lo.price, eq: (hi.price + lo.price) / 2, fromTime: Math.min(hi.time, lo.time) } : null;

  const zones = {
    range, obs: obs.slice(0, 4), fvgs: fvgs.slice(-4), breakers: breakers.slice(0, 3), ifvgs: ifvgs.slice(-3),
    liquidity: [...liq.above.slice(0, 4), ...liq.below.slice(0, 4)], sweep, mss: mss ? { index: mss.index, time: mss.time, level: mss.level, dir: mss.dir, kind: mss.kind } : null,
  };
  const out = { ...base, atr: round(a), price: last.close, trend, bias, range, sweep, zones, time: last.time };

  // Direction: the higher frames decide; with none loaded, the chart's own structure (said so in the checks).
  let dir = bias.bias === 'bull' || bias.bias === 'bear' ? bias.bias : bias.bias === 'mixed' ? null : trend;
  const reasons = [];
  // v234 (opt-in, «توصية AI»): a strong conflict (the highest frame is against the chart's structure) still blocks; a minor one
  // (the highest frame agrees with the chart, only the middle frame is in a pullback) is allowed and reported.
  let htfConflict = bias.bias === 'mixed' ? 'strong' : 'none';
  if (input.htfMode === 'tiered' && bias.bias === 'mixed') {
    const top = bias.frames[Object.keys(bias.frames)[0]];
    if (top && trend === top) { dir = top; htfConflict = 'minor'; }
  }
  if (bias.bias === 'mixed' && htfConflict === 'strong') reasons.push('htf_conflict');
  out.htfConflict = htfConflict;
  if (!dir) { if (!reasons.length) reasons.push('no_structure'); return { ...out, verdict: 'no_trade', reasons, checks: [] }; }
  const long = dir === 'bull';
  const sign = long ? 1 : -1;

  // POI on the bias side of price, not too far away.
  // v234 (opt-in): the caller can bring the zone closer (a realistic pending-order distance for the style)
  const poiDist = Number.isFinite(input.poiMaxAtr) && input.poiMaxAtr > 0 ? Math.min(P.poiDistAtr, input.poiMaxAtr) : P.poiDistAtr;
  const near = (z) => (long ? z.bottom <= last.close + 0.1 * a && z.top >= last.close - poiDist * a : z.top >= last.close - 0.1 * a && z.bottom <= last.close + poiDist * a);
  const inPd = (z) => !range || (long ? (z.top + z.bottom) / 2 <= range.eq : (z.top + z.bottom) / 2 >= range.eq);
  const ote = range ? (long ? { top: range.high - 0.62 * (range.high - range.low), bottom: range.high - 0.79 * (range.high - range.low) } : { bottom: range.low + 0.62 * (range.high - range.low), top: range.low + 0.79 * (range.high - range.low) }) : null;
  const overlapsOte = (z) => ote && z.bottom <= ote.top && z.top >= ote.bottom;
  const KIND_PTS = { OB: 2, BB: 2, IFVG: 1, FVG: 0 };
  const cands = [...obs, ...fvgs, ...breakers, ...ifvgs].filter((z) => z.dir === dir).filter(near).map((z) => ({
    ...z, score: (inPd(z) ? 4 : 0) + KIND_PTS[z.kind] + (z.withFvg ? 2 : 0) + (z.mitigated ? 0 : 1) + (overlapsOte(z) ? 1 : 0),
    dist: Math.abs((long ? z.top : z.bottom) - last.close),
  })).sort((x, y) => y.score - x.score || x.dist - y.dist);
  const poi = cands[0] || null;
  zones.poi = poi;
  zones.ote = ote;
  if (!poi) return { ...out, direction: long ? 'long' : 'short', verdict: 'no_trade', reasons: ['no_poi'], checks: [] };

  // Entry
  const proximal = long ? poi.top : poi.bottom;
  const limitEntry = poi.kind === 'FVG' || poi.kind === 'IFVG' ? (poi.top + poi.bottom) / 2 : proximal;   // gaps: 50% (consequent encroachment); blocks: near edge
  const inPoi = long ? last.low <= poi.top + 0.1 * a && last.close >= poi.bottom : last.high >= poi.bottom - 0.1 * a && last.close <= poi.top;
  const reacting = long ? last.close > last.open || (cs.at(-2).close > cs.at(-2).open && cs.at(-2).low <= poi.top) : last.close < last.open || (cs.at(-2).close < cs.at(-2).open && cs.at(-2).high >= poi.bottom);
  const execution = o.execution;
  let waiting = false;
  let entry = limitEntry;
  let fill = 'limit';
  let confirm = null;
  if (execution === 'market') {
    if (inPoi && reacting) { entry = last.close; fill = 'market'; }
    else waiting = true;   // price is not in the zone (or not reacting yet): a market order now would be a chase
  } else if (execution === 'confirm') {
    confirm = ltfConfirm(input.ltf, poi, dir, last.time - 2 * tfSec, last.time + tfSec, 0.1 * a);
    if (confirm.status === 'confirmed') { entry = confirm.entry; fill = 'market'; } else waiting = true;
  } else if (long ? last.close < limitEntry : last.close > limitEntry) {
    // Price already traded through the limit level: a buy limit above price would fill at once — it is a market entry.
    entry = last.close; fill = 'market';
  }

  // Stop
  const sweepNear = sweep && sweep.dir === dir && (long ? sweep.extreme >= poi.bottom - 1.5 * a && sweep.extreme <= poi.top : sweep.extreme <= poi.top + 1.5 * a && sweep.extreme >= poi.bottom);
  const far = long ? Math.min(poi.bottom, sweepNear ? sweep.extreme : Infinity) : Math.max(poi.top, sweepNear ? sweep.extreme : -Infinity);
  let stop = far - sign * P.bufAtr * a;
  // A lower-timeframe confirmation gives its own, tighter stop (the extreme since the tap), never tighter than half the minimum.
  if (confirm?.status === 'confirmed') stop = Math.abs(entry - confirm.stop) >= 0.5 * P.minRiskAtr * a ? confirm.stop : entry - sign * 0.5 * P.minRiskAtr * a;
  else if (Math.abs(entry - stop) < P.minRiskAtr * a) stop = entry - sign * P.minRiskAtr * a;
  const risk = Math.abs(entry - stop);

  // Targets: liquidity in the trade's direction, at least minTp1R away, deduplicated; R-multiples fill the gaps.
  const pools = (long ? liq.above : liq.below).concat(range ? [{ kind: long ? 'RANGE H' : 'RANGE L', price: long ? range.high : range.low, time: range.fromTime }] : [])
    .filter((l) => (l.price - entry) * sign >= P.minTp1R * risk && (l.price - entry) * sign <= P.maxR * risk)
    .sort((x, y) => (x.price - y.price) * sign);
  const liqT = [];
  for (const l of pools) { if (liqT.length >= 3) break; if (!liqT.length || (l.price - liqT.at(-1).price) * sign > 0.3 * risk) liqT.push({ price: l.price, source: l.kind }); }
  // Fewer than three liquidity targets: R-multiples fill the free slots (nearest first), the liquidity targets always stay.
  const extra = P.fallbackR.map((r) => ({ price: entry + sign * r * risk, source: `${r}R` }))
    .filter((f) => liqT.every((l) => Math.abs(l.price - f.price) > 0.3 * risk));
  const targets = [...liqT, ...extra.slice(0, 3 - liqT.length)].sort((x, y) => (x.price - y.price) * sign);
  const rr = targets.map((t) => round(Math.abs(t.price - entry) / risk, 2));
  // Spread + commission, in R: it is taken off every win and added to every loss.
  const costR = round((entry * o.costPct) / 100 / risk, 3);
  const rrNet = rr.map((v) => round(v - costR, 2));
  // The R:R that is checked (after costs): the furthest target that is a real liquidity level, else TP2.
  const liqIdx = targets.map((t, k) => (/R$/.test(t.source) ? -1 : k)).filter((k) => k >= 0).at(-1);
  const rrMain = rrNet[liqIdx ?? Math.min(1, rr.length - 1)];

  // Checklist
  const crypto = o.asset === 'crypto';
  const kz = tfSec < H4 ? killZone(last.time) : null;
  const checks = [
    { id: 'bias', ok: bias.bias === dir || htfConflict === 'minor', mandatory: Object.keys(bias.frames).length > 0, note: htfConflict === 'minor' ? 'minor_conflict' : bias.bias ? null : 'chart_only' },
    { id: 'structure', ok: trend === dir || (mss && mss.dir === dir), mandatory: false },
    { id: 'sweep', ok: Boolean(sweep && sweep.dir === dir), mandatory: false },
    { id: 'mss', ok: Boolean(mss && mss.dir === dir), mandatory: false },
    { id: 'poi', ok: true, mandatory: true, note: poi.kind === 'OB' ? (poi.withFvg ? 'ob_fvg' : 'ob') : poi.kind.toLowerCase() },
    { id: 'pd', ok: inPd(poi), mandatory: true },
    { id: 'ote', ok: Boolean(overlapsOte(poi)), mandatory: false },
    // v313: the kill zone is context only — a recommendation can come at any hour the market is open (it used to be required for scalps outside crypto)
    { id: 'killzone', ok: o.style === 'swing' || crypto || tfSec >= H4 || Boolean(kz), mandatory: false, note: kz },
    { id: 'rr', ok: rrMain >= P.minRR, mandatory: true, note: `${rrMain} / ${P.minRR}` },
    { id: 'risk', ok: risk <= P.maxRiskAtr * a, mandatory: true },
    { id: 'account', ok: long || ACCOUNTS[o.account].short, mandatory: true },
    // High-impact news for this market within the next hour (or the last 30 min): no market entry; a limit order is only warned.
    { id: 'news', ok: input.news?.level !== 'high', mandatory: fill === 'market' || execution !== 'limit', note: input.news?.known ? input.news.level : 'unknown' },
    { id: 'daily', ok: !(o.maxDailyLossPct > 0 && num(input.todayLossPct, 0) >= o.maxDailyLossPct), mandatory: true, note: `${round(num(input.todayLossPct, 0), 2)} / ${o.maxDailyLossPct}` },
  ];
  if (execution === 'confirm') checks.push({ id: 'ltf', ok: confirm?.status === 'confirmed', mandatory: false, note: confirm?.status || 'no_data' });
  // Open positions: no new trade once the chosen maximum is open (the same direction on several crypto coins is one bet).
  const ex = input.exposure || { open: 0 };
  const sameDir = ex.sameAsset?.[long ? 'long' : 'short'] ?? ex.sameDir ?? 0;
  checks.push({ id: 'exposure', ok: ex.open < o.maxOpen, mandatory: true, note: `${ex.open} / ${o.maxOpen}`, sameDir });
  // Intraday ICT timing: buy below the New York midnight open / sell above it; Silver Bullet hours on 15m and below.
  const nyo = o.style === 'scalp' ? nyMidnightOpen(cs, tfSec) : null;
  if (nyo) checks.push({ id: 'nyopen', ok: long ? entry < nyo.price : entry > nyo.price, mandatory: false, note: String(nyo.price) });
  if (o.style === 'scalp' && tfSec <= 900) { const sb = silverBullet(last.time); checks.push({ id: 'silver', ok: Boolean(sb), mandatory: false, note: sb }); }
  if (nyo) zones.nyOpen = nyo;
  // Displacement on real volume: the candle that created the zone traded ≥ 1.5× its 20-candle average (only when the
  // market has real volume — indices / metals from some providers have none, then the check is left out).
  const vr = displacementVolume(cs, poi);
  if (vr != null) checks.push({ id: 'volume', ok: vr >= 1.5, mandatory: false, note: String(round(vr, 2)) });
  // Judas swing (ICT power of three): after the Asian range, the London / New York move first ran the Asian low (for a buy)
  // or high (for a sell) and closed back — the sweep we trade against.
  if (o.style === 'scalp' && tfSec <= H1) {
    const asia = sessionLevels(cs, tfSec).find((x) => x.name === 'ASIA');
    if (asia) checks.push({ id: 'judas', ok: Boolean(sweep && sweep.dir === dir && sweep.time >= asia.end && killZone(sweep.time) && (long ? sweep.extreme < asia.low : sweep.extreme > asia.high)), mandatory: false });
  }
  for (const c of checks) if (o.require.includes(c.id)) c.mandatory = true;
  for (const c of checks) if (c.mandatory && !c.ok) reasons.push(c.id);
  const verdict = reasons.length ? 'no_trade' : waiting ? 'wait' : 'trade';
  const plan = {
    direction: long ? 'long' : 'short', execution: fill,
    entry: round(entry), stop: round(stop), targets: targets.map((t) => round(t.price)), sources: targets.map((t) => t.source), rr, rrNet, rrMain, costR, risk: round(risk),
    confirm: confirm ? { status: confirm.status, ref: confirm.ref ?? null } : null,
    poi: { kind: poi.kind, top: poi.top, bottom: poi.bottom, time: poi.time, withFvg: Boolean(poi.withFvg) },
    validUntil: last.time + P.expiryBars * tfSec, createdAt: last.time,
  };
  const size = sizePosition({ capital: o.capital, riskPct: o.riskPct, entry, stop, account: o.account, leverage: o.leverage, asset: o.asset, symbol: input.symbol, targets: plan.targets });
  const passed = checks.filter((c) => c.ok).length;
  // Tags kept with a saved trade, so the user's own results can later be split by condition and session.
  const tags = [...checks.filter((c) => c.ok && ['structure', 'sweep', 'mss', 'ote', 'ltf', 'nyopen', 'silver', 'volume', 'judas'].includes(c.id)).map((c) => c.id), ...(kz ? [`kz_${kz}`] : []), `poi_${poi.kind.toLowerCase()}`];
  return { ...out, direction: plan.direction, verdict, reasons, waiting, checks, score: { passed, total: checks.length }, plan, size, tags };
}
function emptyZones() { return { range: null, obs: [], fvgs: [], breakers: [], ifvgs: [], liquidity: [], sweep: null, mss: null, poi: null, ote: null }; }

/* ───────── outcome of a saved trade ───────── */
/**
 * Walks the candles after the trade was planned. Management assumed (and shown to the user): equal parts closed at each
 * target, stop moved to entry once TP1 is hit. A candle that touches both the stop and a target counts as the stop.
 * Status: pending → active → done | stopped | breakeven; or expired / missed before a fill.
 */
export function trackTrade(trade, candles, live) {
  const long = trade.direction === 'long';
  const n = trade.targets.length;
  let status = trade.execution === 'market' ? 'active' : 'pending';
  let filledAt = trade.execution === 'market' ? trade.createdAt : null;
  let hits = 0; let stop = trade.stop; let closedAt = null;
  for (const c of candles) {
    if (c.time <= trade.createdAt) continue;
    if (status === 'pending') {
      if (trade.validUntil && c.time > trade.validUntil) { status = 'expired'; closedAt = c.time; break; }
      if (long ? c.high >= trade.targets[0] && c.low > trade.entry : c.low <= trade.targets[0] && c.high < trade.entry) { status = 'missed'; closedAt = c.time; break; }
      if (long ? c.low <= trade.entry : c.high >= trade.entry) { status = 'active'; filledAt = c.time; } else continue;
    }
    if (long ? c.low <= stop : c.high >= stop) { status = hits ? 'breakeven' : 'stopped'; closedAt = c.time; break; }
    while (hits < n && (long ? c.high >= trade.targets[hits] : c.low <= trade.targets[hits])) hits++;
    if (hits >= 1) stop = trade.entry;
    if (hits >= n) { status = 'done'; closedAt = c.time; break; }
  }
  // v327: a pending order is also filled by the still-forming candle / the live price (not only after the bar closes).
  if (status === 'pending' && live) {
    const fc = live.forming && live.forming.time > trade.createdAt ? live.forming : null;
    const hi = fc ? fc.high : null; const lo = fc ? fc.low : null;
    const px = Number(live.price);
    const hiX = Math.max(...[hi, px].filter(Number.isFinite)); const loX = Math.min(...[lo, px].filter(Number.isFinite));
    if (Number.isFinite(hiX) && Number.isFinite(loX) && !(trade.validUntil && live.now > trade.validUntil)) {
      const tp = trade.targets[0];
      const missed = long ? hiX >= tp && loX > trade.entry : loX <= tp && hiX < trade.entry;
      const filled = long ? loX <= trade.entry : hiX >= trade.entry;
      if (missed) { status = 'missed'; closedAt = live.now; } else if (filled) { status = 'active'; filledAt = Math.floor(live.now); }
    }
  }
  const closed = ['done', 'stopped', 'breakeven'].includes(status);
  const won = trade.rr.slice(0, hits).reduce((s, r) => s + r / n, 0);
  const cost = Number.isFinite(trade.costR) ? trade.costR : 0;   // spread + commission in R, paid once the order is filled
  const resultR = closed || hits ? round((status === 'stopped' ? -1 : won) - cost, 3) : null;
  return { status, hits, filledAt, closedAt, resultR };
}

/** Totals of the user's saved assistant trades (closed ones only). */
export function historyStats(items) {
  const closed = items.filter((x) => ['done', 'stopped', 'breakeven'].includes(x.status) && Number.isFinite(x.resultR));
  const wins = closed.filter((x) => x.resultR > 0).length;
  const totalR = closed.reduce((s, x) => s + x.resultR, 0);
  return { n: items.length, closed: closed.length, wins, winRate: closed.length ? wins / closed.length : null, totalR: round(totalR, 2), avgR: closed.length ? round(totalR / closed.length, 2) : null };
}

/* ───────── top-down: one line per timeframe ───────── */
/** Structure, premium / discount and the nearest zones and liquidity on one timeframe (for the top-down table). */
export function frameSummary(cs, len = 3) {
  if (!cs || cs.length < 40) return null;
  const last = cs.at(-1);
  const a = atr(cs, 14).at(-1) || (last.high - last.low) || last.close * 0.001;
  const swings = findSwings(cs, len);
  const { events, trend } = findStructure(cs, swings, len);
  const { obs, fvgs, breakers, ifvgs } = pointsOfInterest(cs, events, a);
  const zones = [...obs, ...fvgs, ...breakers, ...ifvgs];
  const above = zones.filter((z) => z.bottom > last.close).sort((x, y) => x.bottom - y.bottom)[0] || null;
  const below = zones.filter((z) => z.top < last.close).sort((x, y) => y.top - x.top)[0] || null;
  const hi = [...swings].reverse().find((s) => s.type === 'high'); const lo = [...swings].reverse().find((s) => s.type === 'low');
  const eq = hi && lo && hi.price > lo.price ? (hi.price + lo.price) / 2 : null;
  const open = swings.filter((s) => untaken(cs, s));
  const bsl = open.filter((s) => s.type === 'high' && s.price > last.close).sort((x, y) => x.price - y.price)[0] || null;
  const ssl = open.filter((s) => s.type === 'low' && s.price < last.close).sort((x, y) => y.price - x.price)[0] || null;
  const lb = events.at(-1) || null;
  const z = (x) => (x ? { kind: x.kind, dir: x.dir, top: x.top, bottom: x.bottom } : null);
  return { trend, lastBreak: lb ? { kind: lb.kind, dir: lb.dir, time: lb.time } : null, pd: eq == null ? null : last.close > eq ? 'premium' : 'discount', eq, above: z(above), below: z(below), bsl: bsl?.price ?? null, ssl: ssl?.price ?? null, price: last.close };
}

/* ───────── session clock for the panel ───────── */
const NY_WINDOWS = [['kz_london', 120, 300], ['sb_london', 180, 240], ['kz_ny', 420, 600], ['sb_am', 600, 660], ['sb_pm', 840, 900]];
/**
 * Which ICT windows (New York time) are open now and how many minutes until the next one opens.
 * Returns { now: [{ id, endsIn }], next: { id, in } }. Stepped in 1-minute steps over the next 24 h (DST-safe).
 */
export function sessionClock(nowSec) {
  const minuteOf = (t) => { const k = nyClock(t); return k.h * 60 + k.m; };
  const m0 = minuteOf(nowSec);
  const now = NY_WINDOWS.filter(([, a, b]) => m0 >= a && m0 < b).map(([id, , b]) => ({ id, endsIn: b - m0 }));
  let next = null;
  for (let d = 1; d <= 1440 && !next; d++) {
    const m = minuteOf(nowSec + d * 60);
    const w = NY_WINDOWS.find(([, a]) => m === a);
    if (w) next = { id: w[0], in: d };
  }
  return { now, next };
}
