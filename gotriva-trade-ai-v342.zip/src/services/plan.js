// v297: asks the server which plan this account really has (the browser cannot be trusted to say), and whether plans are enforced.
import { apiRequest } from './ai/gateway.js';
import { setEnforce, setVerifiedPlan, ENFORCE, currentPlan } from '../config/entitlements.js';

/** Resolves once the server answered (or after 4 s). Never throws: when the server cannot be reached nothing is locked in the page. */
export async function syncPlan() {
  setVerifiedPlan(null);   // never keep the previous account's plan
  await askServer();
}
async function askServer() {
  try {
    const me = await Promise.race([apiRequest('GET', '/api/billing/me', undefined, 4000), new Promise((_, no) => setTimeout(() => no(new Error('timeout')), 4500))]);
    if (me?.enforce) { setEnforce(true); setVerifiedPlan(me.owner ? 'max' : (me.plan || 'free')); }
    return true;
  } catch { return false; /* offline or not signed in: keep what we had */ }
}
/** v323: re-ask the server (every 5 min, on returning to the tab). Resolves true when the plan changed — the caller redraws the
 *  menu and the page, so an upgrade, a downgrade or an expired subscription shows without a reload. */
export async function recheckPlan() {
  const before = `${ENFORCE}|${currentPlan()}`;
  if (!(await askServer())) return false;
  return `${ENFORCE}|${currentPlan()}` !== before;
}
