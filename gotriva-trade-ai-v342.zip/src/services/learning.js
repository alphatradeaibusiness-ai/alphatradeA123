// Continuous learning from mistakes (v224) for the multi-strategy AI engine (trend / mean reversion / SMC).
// EDH and LBR are NOT touched: they keep their own proof and mistake review (channel.js).
//
// 1. Store: every closed engine recommendation is kept as an outcome — its strategy, the market context it was issued in
//    (session, regime, ADX, RSI, volatility, direction, hour, market, trend alignment) and its result in R
//    (R = multiples of the risk taken; −1 = full stop, partial exits counted like the channel manages them).
// 2. Analyse: per strategy, the outcomes are grouped by each context feature ("trend · Asia session", "SMC · ADX 15–20"…).
//    Each group's expectancy is compared with the strategy's own average (the performance deviation). Old outcomes weigh
//    less (half-life 30 days) and small groups are pulled towards the strategy average (Bayesian shrinkage), so one
//    unlucky trade never changes anything.
// 3. Adjust (automatically, with the reason logged):
//    • a context where a strategy keeps losing is avoided for that strategy (blocked) — after 7 days it is re-tested
//      (probation); if it still loses it is blocked again.
//    • when a strategy's recent results turn negative, its minimum reward-to-risk is raised step by step (+0.15, at most
//      +0.45); when results recover, it goes back down. It never goes below the engine's own value.
// Everything is reversible (reset), explainable (log), and it only ever makes the engine stricter where data shows losses —
// it never loosens a rule below what the strategy itself requires. It is a statistical filter, not a guarantee.
import { storage } from '../utils/storage.js';
import { observe as adaptiveObserve, adaptiveDecision, adaptiveWeight } from './adaptiveLearning.js';

export const LEARN_STRATEGIES = ['trend', 'mean_reversion', 'smc', 'ict', 'asian_range', 'fvg', 'patterns', 'volume_profile', 'order_flow'];   // v319: the new strategies learn from their losses too
export const LEARN = {
  halfLifeDays: 30,       // weight of an outcome halves every 30 days
  prior: 5,               // shrinkage strength (pseudo-outcomes at the strategy's average)
  minGroup: 8,            // a group needs this much (weighted) evidence before it can be blocked
  blockMeanR: -0.25,      // block when the shrunk expectancy is below this…
  blockWinRate: 0.4,      // …and the shrunk win rate below 40 %
  probationDays: 7,       // a blocked context is re-tested after 7 days
  recentN: 20,            // window for the reward-to-risk adjustment
  rrStep: 0.15, rrMax: 0.45,
  keep: 600,              // outcomes kept
};
const DAY = 86_400_000;
const KEY = 'learn-v1';
const TF_SEC = { '1m': 60, '5m': 300, '15m': 900, '1h': 3600, '4h': 14400, '1D': 86400 };

/* ───────── context features (bucketed so groups have enough data) ───────── */
const band = (v, edges, names) => { if (!Number.isFinite(v)) return null; for (let i = 0; i < edges.length; i++) if (v < edges[i]) return names[i]; return names[names.length - 1]; };
/** The features of one trade's context, each as a short "name=value" key. */
export function featuresOf(ctx = {}) {
  const f = [];
  if (ctx.session) f.push(`session=${ctx.session}`);
  if (ctx.regime) f.push(`regime=${ctx.regime}`);
  const adx = band(ctx.adx, [15, 20, 25, 35], ['<15', '15-20', '20-25', '25-35', '35+']); if (adx) f.push(`adx=${adx}`);
  const rsi = band(ctx.rsi, [30, 45, 55, 70], ['<30', '30-45', '45-55', '55-70', '70+']); if (rsi) f.push(`rsi=${rsi}`);
  const vol = band(ctx.atrPct, [0.15, 0.4, 1], ['very-low', 'low', 'normal', 'high']); if (vol) f.push(`vol=${vol}`);
  if (ctx.direction) f.push(`dir=${ctx.direction}`);
  if (Number.isFinite(ctx.hour)) f.push(`hour=${Math.floor(ctx.hour / 4) * 4}-${Math.floor(ctx.hour / 4) * 4 + 4}`);
  if (ctx.symbol) f.push(`market=${ctx.symbol}`);
  if (ctx.htf) f.push(`htf=${ctx.htf === ctx.direction ? 'with' : ctx.htf === 'neutral' ? 'neutral' : 'against'}`);
  return f;
}

/** Result of a closed recommendation in R, the way the channel manages it (a third at each target, stop to entry after TP1). */
export function outcomeR(s) {
  const risk = Math.abs((s.entry ?? 0) - (s.initialStop ?? s.stop ?? 0));
  if (!(risk > 0)) return null;
  const sg = s.direction === 'short' ? -1 : 1;
  const tR = (s.targets || []).map((t) => ((t - s.entry) * sg) / risk);
  const hit = Math.min(3, s.hits || 0);
  const banked = tR.slice(0, hit).reduce((a, r) => a + r / 3, 0);
  if (s.status === 'sl' && hit === 0) return -1;
  if (s.status === 'tp3') return banked;
  if (s.status === 'be' || s.status === 'sl') return banked;                       // the rest left at the entry
  if (s.status === 'expired' && Number.isFinite(s.price)) return banked + ((3 - hit) / 3) * (hit ? Math.max(0, ((s.price - s.entry) * sg) / risk) : ((s.price - s.entry) * sg) / risk);
  return null;
}

/* ───────── analysis (pure) ───────── */
const weight = (at, now) => 0.5 ** ((now - at) / (LEARN.halfLifeDays * DAY));
function stats(list, now) {
  let w = 0, wr = 0, ww = 0;
  for (const o of list) { const k = weight(o.at, now); w += k; wr += k * o.r; if (o.r > 0) ww += k; }
  return { n: list.length, w, mean: w ? wr / w : 0, win: w ? ww / w : 0, sumR: wr, sumWin: ww };
}

/**
 * The whole learned state from the stored outcomes: per strategy the average, every context group with its deviation,
 * the blocked contexts (with reason) and the reward-to-risk adjustment. `prev` keeps block dates for the probation.
 */
export function analyse(outcomes, prev = {}, now = Date.now()) {
  const out = { strategies: {}, blocks: {}, probation: {}, adj: {}, deviations: [], at: now };
  for (const strat of LEARN_STRATEGIES) {
    const mine = outcomes.filter((o) => o.strategy === strat);
    const base = stats(mine, now);
    out.strategies[strat] = { n: base.n, mean: base.mean, win: base.win };
    // groups by feature
    const groups = new Map();
    for (const o of mine) for (const f of o.features || []) { if (!groups.has(f)) groups.set(f, []); groups.get(f).push(o); }
    for (const [f, list] of groups) {
      const g = stats(list, now);
      const k = LEARN.prior;
      const mean = (g.sumR + k * base.mean) / (g.w + k);                    // shrunk towards the strategy average
      const win = (g.sumWin + k * base.win) / (g.w + k);
      const dev = mean - base.mean;
      if (g.n >= 3) out.deviations.push({ strategy: strat, feature: f, n: g.n, mean: +mean.toFixed(3), win: +win.toFixed(3), dev: +dev.toFixed(3) });
      const key = `${strat}|${f}`;
      const bad = g.w >= LEARN.minGroup && mean < LEARN.blockMeanR && win < LEARN.blockWinRate;
      if (!bad) continue;
      const was = prev.blocks?.[key], prob = prev.probation?.[key];
      const info = { strategy: strat, feature: f, n: g.n, mean: +mean.toFixed(3), win: +win.toFixed(3) };
      if (was) {
        // after 7 days a blocked context gets a second chance (probation): it trades again and is watched
        if (now - was.since > LEARN.probationDays * DAY) out.probation[key] = { ...info, since: now };
        else out.blocks[key] = { ...info, since: was.since };
      } else if (prob) {
        // on probation: a new loss there blocks it again at once; otherwise it stays allowed
        if (list.some((o) => o.at > prob.since && o.r < 0)) out.blocks[key] = { ...info, since: now };
        else out.probation[key] = { ...info, since: prob.since };
      } else out.blocks[key] = { ...info, since: now };
    }
    // reward-to-risk adjustment from the most recent outcomes
    const recent = [...mine].sort((a, b) => b.at - a.at).slice(0, LEARN.recentN);
    const cur = Number(prev.adj?.[strat]) || 0;
    let next = cur;
    if (recent.length >= 10) {
      const e = recent.reduce((a, o) => a + o.r, 0) / recent.length;
      if (e < 0) next = Math.min(LEARN.rrMax, cur + LEARN.rrStep);
      else if (e > 0.2) next = Math.max(0, cur - LEARN.rrStep);
    }
    out.adj[strat] = +next.toFixed(2);
  }
  out.deviations.sort((a, b) => a.dev - b.dev);
  return out;
}

/** Is this trade allowed by what was learned? → { ok, why?, minRR } */
// opts (v234, «توصية AI» page): { minGroupN } — a block counts only when its group has at least this many real results,
// and the R:R raise only after `minGroupN` recent results; the channel calls it without opts and keeps its rule.
export function check(state, strategy, ctx, rr, baseRR = 0, opts = null) {
  if (!LEARN_STRATEGIES.includes(strategy) || !state) return { ok: true, minRR: 0 };
  const minN = Number(opts?.minGroupN) || 0;
  for (const f of featuresOf(ctx)) {
    const b = state.blocks?.[`${strategy}|${f}`];
    if (b && (!minN || (Number(b.n) || 0) >= minN)) return { ok: false, why: 'context', feature: f, block: b, minRR: 0 };
  }
  const nStrat = Number(state.strategies?.[strategy]?.n) || 0;
  const add = minN && nStrat < minN ? 0 : Number(state.adj?.[strategy]) || 0;
  if (add > 0 && Number.isFinite(rr) && rr < baseRR + add) return { ok: false, why: 'rr', need: +(baseRR + add).toFixed(2), rr, minRR: add };
  return { ok: true, minRR: add };
}

/* ───────── storage (per browser, and in the server worker's own store) ───────── */
const empty = () => ({ outcomes: [], seen: [], log: [], learned: { strategies: {}, blocks: {}, probation: {}, adj: {}, deviations: [] } });
export const learnState = () => { const s = storage.get(KEY, null); return s && Array.isArray(s.outcomes) ? s : empty(); };
const save = (s) => storage.set(KEY, s);

/** Records a closed engine recommendation once, re-analyses, and logs every change it made. Returns the change lines. */
export function learnFrom(sig, now = Date.now()) {
  if (!LEARN_STRATEGIES.includes(sig?.strategy) || !sig.ctx) return [];
  const s = learnState();
  if (s.seen.includes(sig.id)) return [];
  const r = Number.isFinite(sig._r) ? sig._r : outcomeR(sig); if (r == null) return [];
  s.seen = [sig.id, ...s.seen].slice(0, LEARN.keep * 2);
  s.outcomes = [{ id: sig.id, strategy: sig.strategy, symbol: sig.symbol, tf: sig.tf, at: sig.closedAt || now, r: +r.toFixed(3), status: sig.status, features: featuresOf({ ...sig.ctx, direction: sig.direction, symbol: sig.symbol }) }, ...s.outcomes].slice(0, LEARN.keep);
  const before = s.learned || {};
  const after = analyse(s.outcomes, before, now);
  const changes = [];
  for (const [k, b] of Object.entries(after.blocks)) if (!before.blocks?.[k]) changes.push({ at: now, kind: 'block', strategy: b.strategy, feature: b.feature, n: b.n, mean: b.mean, win: b.win });
  for (const k of Object.keys(before.blocks || {})) if (!after.blocks[k]) changes.push({ at: now, kind: after.probation[k] ? 'probation' : 'unblock', strategy: before.blocks[k].strategy, feature: before.blocks[k].feature });
  for (const st of LEARN_STRATEGIES) if ((before.adj?.[st] || 0) !== after.adj[st]) changes.push({ at: now, kind: 'rr', strategy: st, from: before.adj?.[st] || 0, to: after.adj[st] });
  s.learned = after;
  s.log = [...changes, ...s.log].slice(0, 200);
  save(s);
  // v250: the hidden adaptive engine gets the same closed outcome (with how it ended), never from Elite / EDH / LBR
  const start = Number(sig.activatedAt || sig.filledAtMs || sig.createdAt) || null; const end = Number(sig.closedAt) || now;
  adaptiveObserve({ id: sig.id, strategy: sig.strategy, r: +r.toFixed(3), at: end, features: s.outcomes[0].features, hits: sig.hits ?? null, status: sig.status, tf: sig.tf || null,
    tfSec: TF_SEC[sig.tf] || null, durMs: start && end > start ? end - start : null, rr: Number.isFinite(sig.rrMain) ? sig.rrMain : null, src: String(sig.id).startsWith('ai|') ? 'ai' : 'channel' });
  return changes;
}
/** Same, for a result already known in R (the customer's saved AI-page trades). */
export function learnFromResult({ id, strategy, symbol, direction, ctx, r, at = Date.now(), hits = null, status = 'result', tf = null, openedAt = null }) {
  if (!Number.isFinite(r)) return [];
  // v250: saved AI trades give their times in SECONDS — read as milliseconds they looked 55 years old (weight ≈ 0)
  const ms = (v) => (Number(v) > 0 && Number(v) < 1e12 ? Number(v) * 1000 : Number(v) || null);
  const end = ms(at) || Date.now();
  return learnFrom({ id, strategy, symbol, direction, ctx, status, hits, tf, createdAt: ms(openedAt), closedAt: end, _r: r }, end);
}
export function learnCheck(strategy, ctx, rr, baseRR, opts = null) {
  const c = check(learnState().learned, strategy, ctx, rr, baseRR, opts);
  if (!c.ok || !LEARN_STRATEGIES.includes(strategy)) return c;
  // v250: then the hidden adaptive engine — only its promoted (out-of-sample + shadow validated) model, bounded
  const d = adaptiveDecision(strategy, featuresOf(ctx || {}), rr, (Number(baseRR) || 0) + (c.minRR || 0));
  if (!d.ok) return d.why === 'rr' ? { ok: false, why: 'rr', need: d.need, rr, minRR: (c.minRR || 0) + d.rrAdd } : { ok: false, why: 'context', feature: d.pattern || 'pattern', minRR: 0 };
  return { ...c, minRR: (c.minRR || 0) + (d.rrAdd || 0), weight: d.w };
}
/** v250: the bounded adaptive weight of a strategy in this context (1 until a validated model exists) — used for ranking. */
export const learnWeight = (strategy, ctx) => adaptiveWeight(strategy, featuresOf(ctx || {}));
export const resetLearning = () => save(empty());
