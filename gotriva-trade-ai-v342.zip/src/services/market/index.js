// Market data facade: picks a provider per instrument, falls back to labelled Demo Mode.
import { marketConfig, TIMEFRAMES } from '../../config/market.js';
import { getInstrument, INSTRUMENTS } from '../../config/instruments.js';
import { fetchBinanceCandles, fetchBinanceTickers, BINANCE_SOURCE } from './binance.js';
import { fetchTwelveCandles, fetchTwelveQuote, TWELVE_SOURCE } from './twelvedata.js';
import { fetchYahooCandles, fetchYahooQuote, yahooSymbolFor, YAHOO_SOURCE } from './yahoo.js';
import { generateDemoCandles, demoTicker } from './demo.js';
import { fetchJson } from '../../utils/http.js';
let hubOffUntil = 0;   // v243: the price hub is missing on this host → per-symbol requests for a while

const DEMO_SOURCE = 'Demo data';
// Twelve Data's free plan allows 8 requests/minute and 800/day, so its responses are cached:
// candles 2 min, quote 5 min (≈ 40 requests/hour while the page is open).
const TWELVE_CACHE_MS = 120_000;
const TWELVE_QUOTE_CACHE_MS = 300_000;
const cache = new Map();

// Symbols the provider refuses for this API key (not in the plan / unknown symbol).
// They are hidden and not requested again for 6 hours, so they cost no API credits.
const UNAVAILABLE_MS = 6 * 60 * 60 * 1000;
const unavailable = new Map(); // symbol -> retry-after timestamp
const isPlanError = (err) => /available starting with|upgrad|symbol.*(missing|invalid)|invalid.*symbol/i.test(String(err?.message || ''));
/** After the owner changes the market-data key, symbols hidden for plan reasons get another chance. */
export const resetMarketAvailability = () => { unavailable.clear(); cache.clear(); };
export const isUnavailable = (symbol) => (unavailable.get(symbol) || 0) > Date.now();
function markIfUnavailable(symbol, err) {
  if (isPlanError(err)) { unavailable.set(symbol, Date.now() + UNAVAILABLE_MS); return true; }
  return false;
}

function providerAvailable(inst) {
  if (inst.provider === 'binance') return true;
  if (inst.provider === 'twelvedata') return Boolean(marketConfig.twelveDataKey) || typeof window !== 'undefined';
  return false;
}

// v230: identical requests in flight share one fetch, and a failure is remembered for 15 s. Before, every re-render (a
// language switch, a page change) fetched every symbol again, and on a network that blocks Yahoo it retried every host each time.
const pendingFetch = new Map();
const FAIL_MS = 15_000;
async function cached(key, ttl, fn) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < (hit.err ? FAIL_MS : ttl)) { if (hit.err) throw hit.err; return hit.value; }
  if (pendingFetch.has(key)) return pendingFetch.get(key);
  const p = (async () => {
    try { const value = await fn(); cache.set(key, { at: Date.now(), value }); return value; }
    catch (err) { cache.set(key, { at: Date.now(), err }); throw err; }
    finally { pendingFetch.delete(key); }
  })();
  pendingFetch.set(key, p);
  return p;
}

function demoDataset(symbol, tf, notice) {
  return {
    symbol, tf, mode: 'demo', source: DEMO_SOURCE, volumeKind: 'synthetic',
    candles: generateDemoCandles(symbol, tf, marketConfig.candleLimit), fetchedAt: Date.now(), notice,
  };
}

/**
 * Load candles for a symbol/timeframe.
 * @returns {Promise<{symbol, tf, mode:'live'|'demo', source, volumeKind:'taker'|'estimated'|'none'|'synthetic', candles, fetchedAt, notice?}>}
 */
export async function getCandles(symbol, tf) {
  const inst = getInstrument(symbol);
  const tfDef = TIMEFRAMES.find((x) => x.id === tf);
  if (!tfDef) throw new Error(`Unknown timeframe ${tf}`);

  if (marketConfig.mode === 'demo') return demoDataset(symbol, tf, null);
  if (!providerAvailable(inst)) {
    if (marketConfig.mode === 'live') throw new Error(`No API key configured for ${symbol}`);
    return demoDataset(symbol, tf, { key: 'status.providerDemo' });
  }
  try {
    if (inst.provider === 'binance') {
      const candles = (await cached(`bn:${symbol}:${tf}`, 2_000, () => fetchBinanceCandles(inst.symbol, tfDef.binance))).map((c) => ({ ...c }));   // re-renders share one fetch; each caller gets its own copy
      return { symbol, tf, mode: 'live', source: BINANCE_SOURCE, volumeKind: 'taker', candles, fetchedAt: Date.now() };
    }
    // 1) Yahoo Finance — free, no API key, real prices. Primary source for gold/indices/forex.
    const ySym = yahooSymbolFor(symbol);
    if (ySym) {
      try {
        const candles = await cached(`yh:${symbol}:${tf}`, 5_000, () => fetchYahooCandles(ySym, tf));
        const hasVolume = candles.some((c) => Number.isFinite(c.volume));
        return { symbol, tf, mode: 'live', source: YAHOO_SOURCE, volumeKind: hasVolume ? 'estimated' : 'none', candles, fetchedAt: Date.now() };
      } catch { /* fall through to Twelve Data / demo */ }
    }
    // 2) Twelve Data (needs an API key saved by the owner).
    const candles = await cached(`td:${symbol}:${tf}`, TWELVE_CACHE_MS, () => fetchTwelveCandles(inst.providerSymbol, tfDef.twelve));
    const hasVolume = candles.some((c) => Number.isFinite(c.volume));
    return { symbol, tf, mode: 'live', source: TWELVE_SOURCE, volumeKind: hasVolume ? 'estimated' : 'none', candles, fetchedAt: Date.now() };
  } catch (err) {
    markIfUnavailable(symbol, err);
    if (marketConfig.mode === 'live') throw err;
    return demoDataset(symbol, tf, { key: 'status.fallback', error: err });
  }
}

/**
 * Longer history for the strategy backtest (up to `bars` candles, newest last).
 * Binance returns at most 1000 candles per request, so older pages are fetched with endTime.
 * Twelve Data returns up to 5000 in one request (1 credit). Falls back to labelled demo data.
 */
const inflight = new Map();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Pages of up to 1000 candles, oldest pages fetched with endTime. Each page is retried twice;
 *  if a later (older) page still fails, the candles already received are used (still real data). */
async function binanceHistory(symbol, tf, tfDef, bars) {
  let out = [];
  let end = null;
  while (out.length < bars) {
    let page = null;
    let lastErr = null;
    for (let attempt = 0; attempt < 3 && !page; attempt++) {
      try { page = await fetchBinanceCandles(getInstrument(symbol).symbol, tfDef.binance, Math.min(1000, bars - out.length), end); } catch (err) { lastErr = err; await sleep(600 * (attempt + 1)); }
    }
    if (!page) {
      if (out.length >= 400) break; // enough real history to test on
      throw lastErr || new Error('Binance history failed');
    }
    if (!page.length) break;
    out = page.concat(out);
    end = page[0].time * 1000 - 1;
    if (page.length < 1000 && out.length < bars) break;
  }
  return { symbol, tf, mode: 'live', source: BINANCE_SOURCE, volumeKind: 'taker', candles: out };
}

export async function getHistory(symbol, tf, bars) {
  const inst = getInstrument(symbol);
  const tfDef = TIMEFRAMES.find((x) => x.id === tf);
  const demo = (notice) => ({ symbol, tf, mode: 'demo', source: DEMO_SOURCE, volumeKind: 'synthetic', candles: generateDemoCandles(symbol, tf, bars), notice });
  if (marketConfig.mode === 'demo') return demo(null);
  if (!providerAvailable(inst)) return demo({ key: 'status.providerDemo' });
  try {
    if (inst.provider === 'binance') {
      // Same request already running (e.g. auto mode and a manual click) → share it; results are kept 60 s.
      return await cached(`bh:${symbol}:${tf}:${bars}`, 60_000, () => {
        const key = `${symbol}:${tf}:${bars}`;
        if (!inflight.has(key)) inflight.set(key, binanceHistory(symbol, tf, tfDef, bars).finally(() => inflight.delete(key)));
        return inflight.get(key);
      });
    }
    const ySym = yahooSymbolFor(symbol);
    if (ySym) {
      try {
        // Cache no longer than half a candle, so a live check always sees the newest close (the 5-minute cache made 1m data look stale).
        const candles = await cached(`yhh:${symbol}:${tf}:${bars}`, Math.min(5 * 60_000, Math.max(20_000, (tfDef?.seconds || 300) * 500)), () => fetchYahooCandles(ySym, tf, bars));
        const hasVolume = candles.some((c) => Number.isFinite(c.volume));
        return { symbol, tf, mode: 'live', source: YAHOO_SOURCE, volumeKind: hasVolume ? 'estimated' : 'none', candles };
      } catch { /* fall through */ }
    }
    const candles = await cached(`tdh:${symbol}:${tf}:${bars}`, 10 * 60_000, () => fetchTwelveCandles(inst.providerSymbol, tfDef.twelve, Math.min(5000, bars)));
    const hasVolume = candles.some((c) => Number.isFinite(c.volume));
    return { symbol, tf, mode: 'live', source: TWELVE_SOURCE, volumeKind: hasVolume ? 'estimated' : 'none', candles };
  } catch (err) {
    markIfUnavailable(symbol, err);
    return demo({ key: 'status.fallback', error: err });
  }
}

/** 24h tickers for the market cards. Each entry carries its own mode/source. */
export async function getTickers(symbols = INSTRUMENTS.map((i) => i.symbol)) {
  const out = {};
  const live = marketConfig.mode !== 'demo';
  const binanceSyms = symbols.filter((s) => getInstrument(s).provider === 'binance');
  const others = symbols.filter((s) => getInstrument(s).provider !== 'binance');

  const demoFor = (s, error) => { out[s] = { ...demoTicker(s), mode: 'demo', source: DEMO_SOURCE, error }; };

  if (live && binanceSyms.length) {
    try {
      const res = await fetchBinanceTickers(binanceSyms);
      binanceSyms.forEach((s) => (res[s] ? (out[s] = { ...res[s], mode: 'live', source: BINANCE_SOURCE }) : demoFor(s)));
    } catch (err) {
      if (marketConfig.mode === 'live') binanceSyms.forEach((s) => { out[s] = { symbol: s, error: err, mode: 'error' }; });
      else binanceSyms.forEach((s) => demoFor(s, err));
    }
  } else binanceSyms.forEach((s) => demoFor(s));

  // v243: every Yahoo-priced market in ONE request to the site's own price hub (refreshed on the server every second).
  // A static host without the server (or an old server) answers 404 → back to the per-symbol path below, as before.
  const hubSyms = live ? others.filter((s) => yahooSymbolFor(s) && providerAvailable(getInstrument(s)) && !isUnavailable(s)) : [];
  if (hubSyms.length && Date.now() >= hubOffUntil) {
    try {
      const key = `hub:${[...hubSyms].sort().join(',')}`;
      const r = await cached(key, 900, () => fetchJson(`/api/market/quotes?s=${encodeURIComponent(hubSyms.join(','))}`, { timeoutMs: 6000 }));
      for (const s of hubSyms) { const q = r?.quotes?.[s]; if (q && Number.isFinite(q.price)) out[s] = { symbol: s, price: q.price, changePct: q.changePct, high: q.high, low: q.low, at: q.at, mode: 'live', source: YAHOO_SOURCE }; }
    } catch (e) { if (e?.status === 404 || e?.status === 405) hubOffUntil = Date.now() + 10 * 60_000; }
  }
  for (const s of others) { // eslint-disable-line no-continue
    if (out[s]) continue;   // already priced by the hub

    const inst = getInstrument(s);
    if (live && providerAvailable(inst) && isUnavailable(s)) { out[s] = { symbol: s, mode: 'unavailable' }; continue; }
    if (live && providerAvailable(inst)) {
      try {
        // Yahoo first — free real-time quotes, no key needed.
        const ySym = yahooSymbolFor(s);
        if (ySym) {
          const q = await cached(`yhq:${s}`, 1_000, () => fetchYahooQuote(ySym));
          out[s] = { symbol: s, ...q, mode: 'live', source: YAHOO_SOURCE };
          continue;
        }
        const q = await cached(`tdq:${s}`, TWELVE_QUOTE_CACHE_MS, () => fetchTwelveQuote(inst.providerSymbol));
        out[s] = { symbol: s, ...q, mode: 'live', source: TWELVE_SOURCE };
      } catch (err) {
        if (markIfUnavailable(s, err)) out[s] = { symbol: s, mode: 'unavailable', error: err };
        else if (marketConfig.mode === 'live') out[s] = { symbol: s, error: err, mode: 'error' };
        else demoFor(s, err);
      }
    } else demoFor(s);
  }
  return out;
}
