// Voice for Gotriva AI: speech-to-text with the browser's own recogniser (Chrome / Edge / Android, Safari 14.5+) in the user's
// language, and optional spoken replies (speechSynthesis). The recording is turned into text on the device or by the browser
// vendor's speech service; the site never stores audio. Where the browser has no recogniser, `voiceSupported()` is false and
// the microphone button is hidden.
const LOCALES = { ar: 'ar-SA', en: 'en-US', he: 'he-IL', es: 'es-ES', zh: 'zh-CN' };
const Rec = () => (typeof window !== 'undefined' ? window.SpeechRecognition || window.webkitSpeechRecognition : null);
export const voiceSupported = () => Boolean(Rec());
export const speechSupported = () => typeof window !== 'undefined' && 'speechSynthesis' in window;

/**
 * Starts listening. onText(finalText) once the person stops talking; onPartial(text) while talking; onEnd(error|null).
 * Returns a stop() function.
 */
export function listen(lang, { onText, onPartial, onEnd } = {}) {
  const R = Rec(); if (!R) { onEnd?.('unsupported'); return () => {}; }
  const r = new R();
  r.lang = LOCALES[lang] || lang || 'ar-SA'; r.interimResults = true; r.continuous = false; r.maxAlternatives = 1;
  let final = ''; let done = false;
  r.onresult = (e) => {
    let interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) { const t = e.results[i][0].transcript; if (e.results[i].isFinal) final += t; else interim += t; }
    onPartial?.((final + interim).trim());
  };
  r.onerror = (e) => { if (done) return; done = true; onEnd?.(e.error || 'error'); };
  r.onend = () => { if (done) return; done = true; if (final.trim()) onText?.(final.trim()); onEnd?.(null); };
  try { r.start(); } catch { done = true; onEnd?.('busy'); }
  return () => { try { r.stop(); } catch { /* already stopped */ } };
}

/** Reads a reply aloud in the given language (cancels any reply still being read). */
/** opts (v280): { pitch, rate, pick } — pick chooses among the device's voices for that language so each mentor sounds different. */
export function speak(text, lang, onDone, opts = {}) {
  if (!speechSupported() || !text) { onDone?.(); return; }
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(String(text).slice(0, 1500));
    u.lang = LOCALES[lang] || lang; u.rate = opts.rate || 1; u.pitch = opts.pitch || 1;
    if (onDone) { let fired = false; const end = () => { if (!fired) { fired = true; onDone(); } }; u.onend = end; u.onerror = end; }
    const vs = speechSynthesis.getVoices().filter((x) => x.lang?.toLowerCase().startsWith(u.lang.slice(0, 2).toLowerCase())); const v = vs.length ? vs[(opts.pick || 0) % vs.length] : null; if (v) u.voice = v;
    speechSynthesis.speak(u);
  } catch { onDone?.(); }
}
export const stopSpeaking = () => { try { speechSynthesis.cancel(); } catch { /* */ } };

export const MIC_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>';
export const SPEAKER_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/></svg>';

/**
 * A microphone button wired to an input/textarea: tap to talk, the words appear in the field; tap again to stop.
 * autoSend(text) is called with the final text (e.g. to send the message right away).
 */
export function micButton(field, { lang, autoSend, label = 'Voice' } = {}) {
  const b = document.createElement('button');
  b.type = 'button'; b.className = 'btn btn-icon voice-mic'; b.innerHTML = MIC_ICON; b.setAttribute('aria-label', label); b.title = label;
  if (!voiceSupported()) { b.hidden = true; return b; }
  let stop = null;
  b.addEventListener('click', () => {
    if (stop) { stop(); return; }
    b.classList.add('is-rec'); b.setAttribute('aria-pressed', 'true');
    const before = field.value ? `${field.value} ` : '';
    stop = listen(typeof lang === 'function' ? lang() : lang, {
      onPartial: (t) => { field.value = before + t; },
      onText: (t) => { field.value = before + t; if (autoSend) autoSend(field.value); },
      onEnd: () => { stop = null; b.classList.remove('is-rec'); b.setAttribute('aria-pressed', 'false'); },
    });
  });
  return b;
}

/** v280: text as it should be read aloud — no markdown marks, links, emoji bullets or code. */
export const spokenText = (t) => String(t || '').replace(/```[\s\S]*?```/g, ' ').replace(/https?:\/\/\S+/g, ' ').replace(/[*_#>`|~]+/g, ' ').replace(/^\s*[-•]\s+/gm, '').replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '').replace(/[ \t]+/g, ' ').replace(/ *\n */g, '\n').replace(/ +([،,.!?؟:؛])/g, '$1').replace(/\n{2,}/g, '\n').trim();

export const WAVE_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M3 10v4M7 7v10M11 4v16M15 8v8M19 11v2"/></svg>';

/**
 * v276: hands-free voice conversation (like a phone call with the assistant). Listens → onAsk(text) returns the reply →
 * the reply is read aloud → listens again, until stop() is called. onState('listen'|'think'|'speak'|'off', detail).
 * Silence keeps listening; a refused microphone or an unsupported browser ends the conversation with that reason.
 */
export function conversation(getLang, { onAsk, onState, onHeard, voice } = {}) {
  if (!voiceSupported()) { onState?.('off', 'unsupported'); return { stop() {} }; }
  let on = true; let stopRec = null; let quiet = 0;
  const end = (why) => { if (!on) return; on = false; try { stopRec?.(); } catch { /* */ } stopSpeaking(); onState?.('off', why || null); };
  const round = () => {
    if (!on) return;
    onState?.('listen'); let heard = false;
    stopRec = listen(getLang(), {
      onPartial: (t) => onHeard?.(t),
      onText: async (t) => {
        heard = true; quiet = 0; if (!on) return; onState?.('think', t);
        let reply = ''; try { reply = await onAsk(t); } catch { reply = ''; }
        if (!on) return;
        if (!reply) { round(); return; }
        onState?.('speak', reply); speak(reply, getLang(), () => { if (on) round(); }, voice || {});
      },
      onEnd: (err) => {
        if (!on || heard) return;
        if (err === 'not-allowed' || err === 'service-not-allowed' || err === 'unsupported' || err === 'audio-capture') { end(err); return; }
        if (++quiet > 6) { end('idle'); return; }   // about a minute of silence: hang up
        setTimeout(round, 250);
      },
    });
  };
  round();
  return { stop: () => end(null), get on() { return on; } };
}
