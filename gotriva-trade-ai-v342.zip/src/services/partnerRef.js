// v255 Gotriva Partner Club — referral link capture. A partner link looks like https://<site>/?pref=ALPHA-CORE-12345 (also
// #/r/ALPHA-CORE-12345). The code is kept in this browser for 30 days; the click is counted on the server (once per network
// per day); after the visitor signs in, the server links the account to the partner (it checks self-referral, existing
// customers and duplicates — this page decides nothing).
import { apiRequest } from './ai/gateway.js';

const KEY = 'ata:pref'; const CODE_RE = /^ALPHA-[A-Z0-9-]{3,24}$/;
const read = () => { try { const j = JSON.parse(localStorage.getItem(KEY) || 'null'); return j && Date.now() - j.at < 30 * 86_400_000 ? j : null; } catch { return null; } };
export function captureReferral() {
  let code = null;
  try { code = new URLSearchParams(location.search).get('pref'); } catch { /* */ }
  const m = location.hash.match(/^#\/r\/([A-Za-z0-9-]{6,30})/); if (m) code = m[1];
  code = String(code || '').toUpperCase().trim(); if (!CODE_RE.test(code)) return null;
  if (!read() || read().code !== code) { try { localStorage.setItem(KEY, JSON.stringify({ code, at: Date.now(), done: false })); } catch { /* */ } }
  fetch('/api/partners/click', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ code }) }).catch(() => {});
  if (m) location.replace(`${location.pathname}${location.search}#/signup`);
  return code;
}
export async function attachReferral() {
  const r = read(); if (!r || r.done) return;
  try { await apiRequest('POST', '/api/partners/attach', { code: r.code, via: 'link' }); localStorage.setItem(KEY, JSON.stringify({ ...r, done: true })); }
  catch (e) { if (e?.code && !['server_unreachable', 'server_missing', 'timeout', 'rate_limited', 'bad_reply', 'signin_required', 'unknown', 'no_secret'].includes(e.code)) { try { localStorage.setItem(KEY, JSON.stringify({ ...r, done: true })); } catch { /* */ } } }
}
