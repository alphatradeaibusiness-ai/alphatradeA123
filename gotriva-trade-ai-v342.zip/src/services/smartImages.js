// AI Smart Images inside GOTRIVA TRADE: the user's own image library (kept in this browser, IndexedDB), described
// once by the AI, and matched automatically to content — today the news headlines. Every AI request goes through the
// site's AI gateway (the owner's key stays on the server). The AI may only pick ids from the list it is given; when
// nothing fits it picks nothing. Choices are cached; all new headlines of a refresh go in ONE request.
import { storage } from '../utils/storage.js';
import { aiPost } from './ai/gateway.js';

const DB = 'ata-smart-images'; const STORE = 'images';
const PICKS = 'si-picks';
export const SI_DEFAULTS = { enabled: true, news: true };
export const siSettings = () => ({ ...SI_DEFAULTS, ...storage.get('si-settings', {}) });
export const setSiSettings = (p) => storage.set('si-settings', { ...siSettings(), ...p });

/* ───────── storage (IndexedDB, falls back to memory) ───────── */
let mem = null;
function openDb() {
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(DB, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: 'id' });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch { resolve(null); }
  });
}
async function tx(mode, fn) {
  const db = await openDb();
  if (!db) { mem = mem || new Map(); return fn(null); }
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORE, mode); const st = t.objectStore(STORE);
    let out; Promise.resolve(fn(st)).then((v) => { out = v; });
    t.oncomplete = () => resolve(out); t.onerror = () => reject(t.error);
  });
}
const req2p = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });

export async function listImages() {
  return tx('readonly', (st) => (st ? req2p(st.getAll()) : [...mem.values()])).then((l) => (l || []).sort((a, b) => b.addedAt - a.addedAt));
}
export async function putImage(img) { return tx('readwrite', (st) => (st ? req2p(st.put(img)) : mem.set(img.id, img))); }
export async function deleteImage(id) {
  const picks = storage.get(PICKS, {});
  for (const k of Object.keys(picks)) if (picks[k].img === id) delete picks[k];
  storage.set(PICKS, picks);
  return tx('readwrite', (st) => (st ? req2p(st.delete(id)) : mem.delete(id)));
}

/* ───────── AI: describe each image once ───────── */
export async function describeImage(img, lang = 'ar', post = aiPost) {
  const j = await post('/images/describe', { image: img.data, lang });
  if (!j || !j.description) throw new Error('reply');
  const desc = { description: String(j.description).slice(0, 300), alt: String(j.alt || '').slice(0, 125), keywords: (Array.isArray(j.keywords) ? j.keywords : []).map((x) => String(x).slice(0, 40)).slice(0, 16), at: Date.now() };
  const out = { ...img, desc };
  await putImage(out);
  return out;
}

/* ───────── matching ───────── */
const STOP = new Set(['the', 'and', 'for', 'with', 'that', 'this', 'from', 'are', 'was', 'its', 'has', 'have', 'will', 'into', 'over', 'after', 'says', 'said', 'new', 'من', 'في', 'على', 'إلى', 'عن', 'مع', 'هذا', 'هذه']);
export const words = (s) => (String(s || '').toLowerCase().match(/[\p{L}\p{N}]{3,}/gu) || []).filter((w) => !STOP.has(w));
const imgText = (im) => [im.name.replace(/\.[a-z]+$/i, '').replace(/[-_]/g, ' '), im.desc?.description, im.desc?.alt, (im.desc?.keywords || []).join(' ')].filter(Boolean).join(' · ');

/** Up to `limit` candidate images for a set of headlines, ranked by shared words (best first, then newest). */
export function candidates(images, texts, limit = 30) {
  const tw = new Set(texts.flatMap(words));
  return images.map((im, i) => ({ im, s: words(imgText(im)).filter((w) => tw.has(w)).length, i }))
    .sort((a, b) => b.s - a.s || a.i - b.i).slice(0, limit).map((x) => x.im);
}

/**
 * Images for news headlines: cached picks first; the uncached ones (max 20) go in one AI request.
 * Returns Map(headline id → image) — only headlines that got an image.
 */
export async function imagesForHeadlines(items, { post = aiPost } = {}) {
  const s = siSettings();
  const result = new Map();
  if (!s.enabled || !s.news || !items?.length) return result;
  const images = (await listImages()).filter((im) => im.desc);
  if (!images.length) return result;
  const byId = new Map(images.map((im) => [im.id, im]));
  const picks = storage.get(PICKS, {});
  const todo = [];
  for (const n of items.slice(0, 40)) {
    const c = picks[n.id];
    if (c && (c.img === null || byId.has(c.img)) && c.n === images.length) { if (c.img) result.set(n.id, byId.get(c.img)); }
    else todo.push(n);
  }
  const batch = todo.slice(0, 20);
  if (batch.length) {
    const cands = candidates(images, batch.map((n) => n.title));
    const res = await post('/images/match', { items: batch.map((n) => ({ title: n.title })), candidates: cands.map((im) => ({ id: im.id, text: imgText(im).slice(0, 240) })) });
    const ids = new Set(cands.map((c) => c.id)); const got = new Map();
    for (const p of Array.isArray(res?.picks) ? res.picks : []) {   // the server already drops invented ids; checked again here
      const i = Number(p?.i);
      if (Number.isInteger(i) && i >= 0 && i < batch.length) got.set(i, p.id != null && ids.has(String(p.id)) ? String(p.id) : null);
    }
    batch.forEach((n, i) => {
      if (!got.has(i)) return;            // no answer for this one → asked again next time
      const id = got.get(i);
      picks[n.id] = { img: id, at: Date.now(), n: images.length };   // re-checked when the library changes size
      if (id) result.set(n.id, byId.get(id));
    });
    const keys = Object.keys(picks); if (keys.length > 400) for (const k of keys.slice(0, keys.length - 400)) delete picks[k];
    storage.set(PICKS, picks);
  }
  return result;
}

export const clearPicks = () => storage.set(PICKS, {});
