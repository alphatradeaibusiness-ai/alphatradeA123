// v261: the GOTRIVA PARTNER CLUB menu item is shown only to members of the site's Telegram channel (checked on the server
// with the Telegram Bot API). Until the server says yes, the item stays hidden. Owners always see it.
import { apiRequest } from './ai/gateway.js';

let last = 0; let state = null;
const css = () => { if (document.getElementById('pc-gate-css')) return; const s = document.createElement('style'); s.id = 'pc-gate-css'; s.textContent = 'html:not([data-pc-gate="on"]) [data-nav="partners"]{display:none!important}'; document.head.append(s); };
export function partnerGateState() { return state; }
export async function refreshPartnerGate({ signedIn = true, fresh = false } = {}) {
  css();
  if (!signedIn) { state = null; document.documentElement.dataset.pcGate = 'off'; return null; }
  if (!fresh && Date.now() - last < 60_000 && state) return state;
  last = Date.now();
  try { state = await apiRequest('GET', `/api/partners/access${fresh ? '?fresh=1' : ''}`); } catch { state = state || { allowed: false, reason: 'check_failed' }; }
  document.documentElement.dataset.pcGate = state.allowed ? 'on' : 'off';
  return state;
}
