// The signed-in user's SMC / ICT assistant trades. Kept on this device per account, and in the user's own encrypted file
// on the site's server when it is reachable (the two are merged by id; the newer update wins). On a static host without
// the server the history stays on this device and the panel says so.
import { learnFromResult } from './learning.js';
import { storage } from '../utils/storage.js';
import { auth } from './auth/index.js';
import { apiRequest, AI_BASE } from './ai/gateway.js';
import { trackTrade } from './smcAssist.js';
import { stats } from './smcBacktest.js';

const BASE = AI_BASE.replace(/\/api\/ai$/, '/api/user');
const uid = () => auth.current()?.uid || auth.current()?.email || 'guest';
const key = () => `assist-trades:${uid()}`;
const listeners = new Set();
let sync = { state: 'local', at: 0 };   // local | synced | offline | no_secret

export const syncState = () => sync;
export const onTrades = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = () => listeners.forEach((fn) => { try { fn(); } catch { /* a view error must not break the others */ } });
export const listTrades = () => (storage.get(key(), []) || []).sort((a, b) => b.savedAt - a.savedAt);
function saveLocal(items) { storage.set(key(), items.slice(0, 500)); emit(); }

const signedIn = () => Boolean(auth.current()?.uid);
async function push(item) {
  if (!signedIn()) return;
  try { await apiRequest('PUT', `${BASE}/trades`, { item }, 15000); sync = { state: 'synced', at: Date.now() }; }
  catch (e) { sync = { state: e?.code === 'no_secret' ? 'no_secret' : 'offline', at: Date.now() }; }
}

/** Pulls the server copy and merges it with this device's (once per page load and on demand). */
export async function pullTrades() {
  if (!signedIn()) { sync = { state: 'local', at: Date.now() }; return listTrades(); }
  try {
    const r = await apiRequest('GET', `${BASE}/trades`, undefined, 15000);
    const local = new Map(listTrades().map((x) => [x.id, x]));
    const toPush = [];
    for (const s of r.items || []) { const l = local.get(s.id); if (!l || s.updatedAt >= l.updatedAt) local.set(s.id, s); }
    const serverIds = new Map((r.items || []).map((x) => [x.id, x.updatedAt]));
    for (const l of local.values()) if (!serverIds.has(l.id) || serverIds.get(l.id) < l.updatedAt) toPush.push(l);
    saveLocal([...local.values()].sort((a, b) => b.savedAt - a.savedAt));
    sync = { state: 'synced', at: Date.now(), watch: r.watch || null };   // watch: what the server itself tracks and notifies
    for (const x of toPush.slice(0, 50)) await push(x);
  } catch (e) { sync = { state: e?.code === 'no_secret' ? 'no_secret' : 'offline', at: Date.now() }; emit(); }
  return listTrades();
}

const rid = () => `tr_${Date.now().toString(36)}${crypto.getRandomValues(new Uint32Array(2)).reduce((s, n) => s + n.toString(36), '')}`.slice(0, 32);

/** Saves the current plan of an assistant reading. */
export function saveTrade(reading, { symbol, tf, mode }) {
  const p = reading.plan; const o = reading.inputs; const now = Date.now();
  const item = {
    id: rid(), symbol, tf, style: o.style, direction: p.direction, execution: p.execution, account: o.account, asset: o.asset, status: p.execution === 'market' ? 'active' : 'pending',
    entry: p.entry, stop: p.stop, risk: p.risk, targets: p.targets, rr: p.rr, createdAt: p.createdAt, savedAt: now, updatedAt: now,
    validUntil: p.execution === 'market' ? null : p.validUntil, filledAt: p.execution === 'market' ? p.createdAt : null, closedAt: null, hits: 0, resultR: null,
    capital: o.capital || null, riskPct: o.riskPct, riskAmount: reading.size?.riskAmount ?? null, units: reading.size?.units ?? null, mode: mode === 'live' ? 'live' : 'demo', note: '',
    costR: p.costR ?? 0, tags: (reading.tags || []).slice(0, 12), strategy: reading.strategy || 'smc', ctx: reading.learnCtx || null,
    // v234 («توصية AI»): the engine version and a time line of every status change with its reason
    ...(reading.engineVersion ? { engine: String(reading.engineVersion).slice(0, 40) } : {}),
    history: [{ at: now, status: p.execution === 'market' ? 'active' : 'pending', hits: 0, reason: 'saved' }], cancelReason: null,
  };
  saveLocal([item, ...listTrades()]);
  push(item).then(emit);
  return item;
}

/**
 * v248: saved trades that can no longer be followed are closed honestly instead of counting as "open" forever (they filled the
 * open-trade limit and blocked every new recommendation): a pending order past its validity → expired; an active trade older
 * than its style's maximum holding time (scalp 48 h, swing 14 days) → expired ('max_hold', no result claimed).
 */
export function expireStale(nowMs = Date.now(), maxHoldHours = { scalp: 48, swing: 336 }) {
  const items = listTrades(); const nowS = Math.floor(nowMs / 1000); const changed = [];
  for (const x of items) {
    if (x.mode !== 'live' || !['pending', 'active'].includes(x.status)) continue;
    const start = Number(x.filledAt || x.createdAt) || 0;
    let why = null;
    if (x.status === 'pending' && Number(x.validUntil) > 0 && nowS > Number(x.validUntil) + 60) why = 'expired';
    else if (x.status === 'active' && start > 0 && nowS - start > (maxHoldHours[x.style] || maxHoldHours.swing) * 3600) why = 'max_hold';
    if (!why) continue;
    Object.assign(x, { status: 'expired', cancelReason: x.cancelReason || why, closedAt: nowS, updatedAt: nowMs });
    x.history = [...(Array.isArray(x.history) ? x.history : []), { at: nowMs, status: 'expired', hits: x.hits || 0, reason: why }].slice(-20);
    changed.push(x);
  }
  if (changed.length) { saveLocal(items); for (const x of changed) push({ ...x }); }
  return changed;
}

/** Changes the user's own note on a trade (the only field the user edits by hand). */
export function updateTrade(id, { note }) {
  const items = listTrades(); const x = items.find((y) => y.id === id); if (!x) return;
  x.note = String(note || '').replace(/[\u0000-\u001f]/g, ' ').slice(0, 200); x.updatedAt = Date.now();
  saveLocal(items); push({ ...x });
}

/** Cancels a pending order (v234: e.g. high-impact news before it activated). Only a pending order can be cancelled. */
export function cancelTrade(id, reason) {
  const items = listTrades(); const x = items.find((y) => y.id === id); if (!x || x.status !== 'pending') return null;
  const why = /^[a-z_]{2,24}$/.test(String(reason || '')) ? reason : 'cancelled';
  Object.assign(x, { status: 'cancelled', cancelReason: why, closedAt: Math.floor(Date.now() / 1000), updatedAt: Date.now() });
  x.history = [...(Array.isArray(x.history) ? x.history : []), { at: Date.now(), status: 'cancelled', hits: 0, reason: why }].slice(-20);
  saveLocal(items); push({ ...x });
  return { ...x };
}

export function removeTrade(id) {
  saveLocal(listTrades().filter((x) => x.id !== id));
  if (signedIn()) apiRequest('DELETE', `${BASE}/trades/${encodeURIComponent(id)}`, undefined, 15000).catch(() => {});
}

/** Re-checks open trades of this symbol / timeframe against real candles; changed ones are saved, synced and returned. */
export function refreshOutcomes(symbol, tf, candles, mode, live) {
  if (!candles?.length || mode !== 'live') return [];   // outcomes are only ever judged on real prices
  const items = listTrades(); const changes = [];
  for (const x of items) {
    if (x.symbol !== symbol || x.tf !== tf || x.mode !== 'live' || ['done', 'stopped', 'breakeven', 'expired', 'missed', 'cancelled'].includes(x.status)) continue;
    if (candles[0].time > x.createdAt) continue;   // the chart no longer covers the start of this trade: leave it as it is
    const r = trackTrade(x, candles, live ? { ...live, now: Math.floor(Date.now() / 1000) } : undefined);
    if (r.status !== x.status || r.hits !== x.hits || r.resultR !== x.resultR) {
      const before = { status: x.status, hits: x.hits };
      Object.assign(x, { status: r.status, hits: r.hits, filledAt: r.filledAt, closedAt: r.closedAt, resultR: r.resultR, updatedAt: Date.now() });
      x.history = [...(Array.isArray(x.history) ? x.history : []), { at: Date.now(), status: r.status, hits: r.hits, reason: r.status === 'missed' ? 'tp1_before_fill' : r.status === 'expired' ? 'expired' : r.hits > before.hits ? `tp${r.hits}` : r.status }].slice(-20);
      if (r.status === 'missed' && !x.cancelReason) x.cancelReason = 'tp1_before_fill';
      if (r.status === 'expired' && !x.cancelReason && !x.filledAt) x.cancelReason = 'expired';
      changes.push({ item: { ...x }, before }); push({ ...x });
      // the AI engine learns from the customer's own closed AI trades too (services/learning.js)
      if (Number.isFinite(x.resultR) && x.closedAt && x.ctx) learnFromResult({ id: `ai|${x.id}`, strategy: x.strategy, symbol: x.symbol, direction: x.direction, ctx: x.ctx, r: x.resultR, at: x.closedAt, hits: x.hits, status: x.status, tf: x.tf, openedAt: x.filledAt || x.createdAt });
    }
  }
  if (changes.length) saveLocal(items);
  return changes;
}

export function tradesCsv(items) {
  const cols = ['savedAt', 'symbol', 'tf', 'style', 'direction', 'execution', 'account', 'entry', 'stop', 'targets', 'rr', 'status', 'hits', 'resultR', 'riskAmount', 'units', 'mode'];
  const cell = (v) => { let s = Array.isArray(v) ? v.join(' / ') : v == null ? '' : String(v); if (typeof v !== 'number' && /^[=+\-@\t\r]/.test(s)) s = `'${s}`; return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  return [cols.join(','), ...items.map((x) => cols.map((c) => cell(c === 'savedAt' ? new Date(x.savedAt).toISOString() : x[c])).join(','))].join('\n');
}

/** Today's realised loss in % of the account (from closed, real-price assistant trades closed today, local time). */
export function todayLossPct(items = listTrades(), now = Date.now()) {
  const d = new Date(now); const start = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() / 1000;
  let pct = 0;
  for (const x of items) if (x.mode === 'live' && x.closedAt >= start && Number.isFinite(x.resultR)) pct += x.resultR * (x.riskPct || 0);
  return pct < 0 ? -pct : 0;
}

const CLOSED = ['done', 'stopped', 'breakeven'];
/** The user's closed trades split by style, market, direction, order type, session and condition (sample sizes shown). */
export function breakdown(items = listTrades()) {
  const closed = items.filter((x) => x.mode === 'live' && CLOSED.includes(x.status) && Number.isFinite(x.resultR)).sort((a, b) => a.closedAt - b.closedAt);
  const group = (keyOf) => {
    const m = new Map();
    for (const x of closed) for (const k of [].concat(keyOf(x))) { if (!m.has(k)) m.set(k, []); m.get(k).push(x); }
    return [...m].map(([k, list]) => { const st = stats(list); return { key: k, n: st.n, winRate: st.winRate, avgR: st.avgR, totalR: st.totalR }; }).sort((a, b) => b.n - a.n);
  };
  const session = (x) => (x.tags || []).find((t) => t.startsWith('kz_')) || 'kz_none';
  const tagGroups = ['sweep', 'mss', 'ote', 'ltf'].map((tg) => ({ tag: tg, with: stats(closed.filter((x) => (x.tags || []).includes(tg))), without: stats(closed.filter((x) => !(x.tags || []).includes(tg))) }))
    .map((g) => ({ tag: g.tag, with: { n: g.with.n, avgR: g.with.avgR, winRate: g.with.winRate }, without: { n: g.without.n, avgR: g.without.avgR, winRate: g.without.winRate } }));
  // After a loss: does the next trade do worse? (a common behaviour pattern)
  const afterLoss = []; for (let i = 1; i < closed.length; i++) if (closed[i - 1].resultR < 0) afterLoss.push(closed[i]);
  const overall = stats(closed);
  // This week vs last week (weeks start Monday, local time).
  const d = new Date(); const monday = new Date(d.getFullYear(), d.getMonth(), d.getDate() - ((d.getDay() + 6) % 7)).getTime() / 1000;
  const wk = (from, to) => { const l = closed.filter((x) => x.closedAt >= from && x.closedAt < to); const st = stats(l); return { n: st.n, totalR: st.totalR, winRate: st.winRate }; };
  const weeks = { this: wk(monday, Infinity), last: wk(monday - 7 * 86400, monday) };
  return {
    overall: { n: overall.n, winRate: overall.winRate, avgR: overall.avgR, totalR: overall.totalR, maxDD: overall.maxDD, profitFactor: overall.profitFactor, maxLossStreak: overall.maxLossStreak },
    byStyle: group((x) => x.style), bySymbol: group((x) => x.symbol), byDirection: group((x) => x.direction), byExecution: group((x) => x.execution), bySession: group(session),
    byTag: tagGroups, weeks, afterLoss: (() => { const s2 = stats(afterLoss); return { n: s2.n, avgR: s2.avgR, winRate: s2.winRate }; })(),
  };
}

/** Closed real-price assistant trades → the Journal page (once each; result in R after costs, 1 unit when size is unknown). */
export function sendToJournal() {
  const journal = storage.get('journal', []) || [];
  let n = 0;
  for (const x of listTrades()) {
    if (x.mode !== 'live' || !CLOSED.includes(x.status) || !Number.isFinite(x.resultR) || journal.some((j) => j.assistId === x.id)) continue;
    const dir = x.direction === 'long' ? 1 : -1;
    journal.unshift({ id: `j_${x.id}`, assistId: x.id, tf: x.tf, openedAt: (x.filledAt || x.createdAt) * 1000, symbol: x.symbol, direction: x.direction, entry: x.entry,
      exit: x.entry + dir * x.resultR * x.risk, stop: x.stop, qty: x.units || 1, fees: 0, r: x.resultR, strategy: 'smc_ict', notes: `SMC/ICT ${x.style}${x.note ? ` — ${x.note}` : ''}`,
      closedAt: (x.closedAt || x.createdAt) * 1000, source: 'assistant' });
    n++;
  }
  journal.sort((a, b) => b.closedAt - a.closedAt);
  storage.set('journal', journal);
  return n;
}
