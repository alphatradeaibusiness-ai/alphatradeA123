// v319 — five more INDEPENDENT strategies for the «توصية AI» page, each with its own checklist, entry, stop and targets:
//   ict (liquidity sweep → displacement → FVG / OTE entry) · asian_range (Asian session range breakout) · fvg (fair value gap,
//   standalone) · patterns (double top / bottom, head & shoulders) · volume_profile (POC / VAH / VAL from real volume).
// They are NEW: no back-test or live record yet, so the registry marks them 'new' and the card says so. Every result is stored
// and learned from like the others (services/learning.js). Pure: no DOM, no network. EDH and Gotriva Elite are not touched.
import { makeCheck as chk, pickDirection } from './multiStrategy.js';

const PASS = 'pass', FAIL = 'fail', NA = 'unavailable';
const okv = (b) => (b == null ? NA : b ? PASS : FAIL);
const r5 = (v) => (Number.isFinite(v) ? Math.round(v * 1e5) / 1e5 : v);
const r2 = (v) => Math.round(v * 100) / 100;
export const NEW_STRATEGY_IDS = ['ict', 'asian_range', 'fvg', 'patterns', 'volume_profile', 'order_flow'];

/** The shared end of every checklist: an objective stop (0.3–4 ATR) and reward-to-risk after costs. targets null → 1.5R / 2R / 3R. */
function finish(checks, { dir, entry, stop, a, targets = null, limitAt = null }, { minRR = 1.5, costPct = 0 } = {}) {
  const sg = dir === 'long' ? 1 : -1; const RR = [`العائد للمخاطرة ≥ ${minRR}`, `Reward-to-risk ≥ ${minRR}`];
  if (![entry, stop, a].every(Number.isFinite)) { checks.push(chk('stop', 'وقف منطقي من الهيكل', 'Objective structural stop', NA, '')); checks.push(chk('rr', ...RR, NA, '')); return null; }
  const risk = (entry - stop) * sg; const ok = risk > 0.3 * a && risk < 4 * a;
  checks.push(chk('stop', 'وقف منطقي من الهيكل', 'Objective structural stop', okv(ok), `${r5(stop)}`));
  if (!ok) { checks.push(chk('rr', ...RR, NA, 'no valid stop')); return null; }
  const T = targets || [1.5, 2, 3].map((k) => entry + sg * k * risk);
  const valid = T.every((t, k) => (t - entry) * sg > 0 && (k === 0 || (t - T[k - 1]) * sg >= 0));
  const rr = T.map((t) => r2(((t - entry) * sg) / risk)); const costR = (entry * costPct) / 100 / risk;
  const plan = valid ? { direction: dir, entry, stop, targets: T, rr, rrMain: r2(rr[1] - costR), risk, rTargets: !targets, limitAt: Number.isFinite(limitAt) && (entry - limitAt) * sg >= 0 ? limitAt : null, quality: 50 } : null;
  checks.push(chk('rr', ...RR, plan ? okv(plan.rrMain >= minRR) : FAIL, plan ? `${plan.rrMain}` : 'target behind entry'));
  return plan && plan.rrMain >= minRR ? plan : null;
}
const htfCheck = (S, dir) => chk('htf', 'الفريم الأعلى مش عكس الصفقة', 'Higher timeframe not against the trade', S.htfDir == null ? NA : okv(S.htfDir === dir || S.htfDir === 'neutral'), S.htfDir || 'not enough candles');
/** Latest gap in `dir` between bars from..to (3-candle imbalance, ≥ minAtr × ATR, never closed through). → { k, top, bottom } | null */
function lastGap(S, dir, from, to, minAtr = 0.25) {
  const cs = S.cs; const long = dir === 'long';
  for (let k = to - 1; k >= Math.max(1, from); k--) {
    const a = S.a[k]; if (!a) continue;
    const bottom = long ? cs[k - 1].high : cs[k + 1].high, top = long ? cs[k + 1].low : cs[k - 1].low;
    if (!(top - bottom >= minAtr * a)) continue;
    let dead = false; for (let j = k + 2; j <= S.i; j++) if (long ? cs[j].close < bottom : cs[j].close > top) { dead = true; break; }
    if (!dead) return { k, top, bottom };
  }
  return null;
}

/* ───────── ICT — its own model on the candles (separate from the SMC zone engine) ───────── */
export function ictStrategy(S, o = {}) {
  return pickDirection('ict', ['ICT (سيولة ← إزاحة ← FVG)', 'ICT (liquidity → displacement → FVG)'], (dir) => {
    const long = dir === 'long'; const sg = long ? 1 : -1; const i = S.i; const cs = S.cs; const a = S.a[i]; const c = cs[i]; const checks = [];
    const piv = long ? S.sw.lo : S.sw.hi; let s = -1, lvl = null;
    for (let k = i - 1; k >= Math.max(4, i - 15) && s < 0; k--) for (let j = piv.length - 1; j >= 0; j--) {
      const p = piv[j]; if (p.i + 3 > k) continue; if (k - p.i > 60) break;
      if (long ? cs[k].low < p.price && cs[k].close > p.price : cs[k].high > p.price && cs[k].close < p.price) { s = k; lvl = p.price; break; }
    }
    const h = new Date(c.time * 1000).getUTCHours(); const kz = (h >= 7 && h < 10) || (h >= 12 && h < 15);
    checks.push(chk('sweep', 'سحب سيولة (قمة/قاع مؤكد) بآخر 15 شمعة', 'Liquidity sweep of a confirmed swing within 15 candles', okv(s >= 0), s >= 0 ? `${r5(lvl)} · ${i - s} bars ago${kz ? ' · kill zone' : ''}` : 'none'));
    let mss = null, gap = null, ext = null, leg = null;
    if (s >= 0) {
      const ref = long ? Math.max(...cs.slice(s - 3, s + 1).map((b) => b.high)) : Math.min(...cs.slice(s - 3, s + 1).map((b) => b.low));
      mss = false; for (let m = s + 1; m <= i; m++) if (long ? cs[m].close > ref : cs[m].close < ref) { mss = true; break; }
      gap = lastGap(S, dir, s, i, 0.15);
      const seg = cs.slice(s, i + 1); ext = long ? Math.min(...seg.map((b) => b.low)) : Math.max(...seg.map((b) => b.high)); leg = long ? Math.max(...seg.map((b) => b.high)) : Math.min(...seg.map((b) => b.low));
    }
    checks.push(chk('mss', 'كسر هيكل بعد السحب (MSS)', 'Market structure shift after the sweep', okv(mss), ''));
    checks.push(chk('fvg', 'فجوة قيمة عادلة من الإزاحة', 'Fair value gap left by the displacement', s < 0 ? NA : okv(Boolean(gap)), gap ? `${r5(gap.bottom)}–${r5(gap.top)}` : 'none'));
    let inZone = null;
    if (gap && leg != null && Math.abs(leg - ext) > 0) {
      const retr = ((leg - (long ? c.low : c.high)) * sg) / ((leg - ext) * sg);
      const inGap = long ? c.low <= gap.top && c.close >= gap.bottom : c.high >= gap.bottom && c.close <= gap.top;
      inZone = (inGap || (retr >= 0.5 && retr <= 0.79)) && (long ? c.close > c.open : c.close < c.open);
    }
    checks.push(chk('entry', 'رجوع للفجوة أو OTE وشمعة تفاعل', 'Return to the gap or the OTE zone with a reaction candle', okv(inZone), ''));
    const plan = finish(checks, { dir, entry: c.close, stop: ext == null || !a ? NaN : ext - sg * 0.2 * a, a, limitAt: gap ? (long ? gap.top : gap.bottom) : null }, o);
    return { dir, checks, plan };
  });
}

/* ───────── Asian range breakout (00:00–07:00 UTC range, break between 07:00 and 16:00 UTC) ───────── */
export function asianRangeStrategy(S, o = {}) {
  const tfSec = o.tfSec || 900;
  return pickDirection('asian_range', ['اختراق النطاق الآسيوي', 'Asian range breakout'], (dir) => {
    const long = dir === 'long'; const sg = long ? 1 : -1; const i = S.i; const cs = S.cs; const a = S.a[i]; const c = cs[i]; const checks = [];
    const day = Math.floor(c.time / 86400) * 86400; const t = c.time - day;
    checks.push(chk('tf', 'فريم ساعة أو أصغر', 'Timeframe of 1 hour or lower', okv(tfSec <= 3600), `${tfSec / 60}m`));
    checks.push(chk('window', 'بعد إغلاق آسيا (07:00–16:00 UTC)', 'After the Asian session (07:00–16:00 UTC)', okv(t >= 7 * 3600 && t < 16 * 3600), `${String(Math.floor(t / 3600)).padStart(2, '0')}:${String(Math.floor((t % 3600) / 60)).padStart(2, '0')} UTC`));
    let hi = -Infinity, lo = Infinity, n = 0;
    for (let j = i; j >= 0 && cs[j].time >= day; j--) if (cs[j].time + tfSec <= day + 7 * 3600) { hi = Math.max(hi, cs[j].high); lo = Math.min(lo, cs[j].low); n++; }
    const has = n >= Math.max(3, Math.min(8, Math.floor((7 * 3600) / tfSec) - 1)) && hi > lo;
    checks.push(chk('range', 'نطاق آسيا محسوب من شموع اليوم', 'Asian range measured from today\'s candles', okv(has), has ? `${r5(lo)}–${r5(hi)}` : `${n} candles`));
    const lvl = long ? hi : lo; const back = cs[Math.max(0, i - 3)];
    const brk = has ? (long ? c.close > hi && back.close <= hi : c.close < lo && back.close >= lo) : null;
    checks.push(chk('break', 'إغلاق برا النطاق (اختراق جديد، آخر 3 شموع)', 'Close outside the range (fresh, within 3 candles)', okv(brk), has ? `${r5(lvl)}` : ''));
    checks.push(chk('body', 'شمعة الاختراق بنفس الاتجاه ومش ممدودة', 'Breakout candle in the same direction, not extended', has && a ? okv((long ? c.close > c.open : c.close < c.open) && (c.close - lvl) * sg <= 1.2 * a) : NA, ''));
    checks.push(htfCheck(S, dir));
    let stop = NaN;
    if (has && a) { const mid = (hi + lo) / 2; stop = (c.close - mid) * sg <= 3 * a ? mid : c.close - sg * 2 * a; }
    const plan = finish(checks, { dir, entry: c.close, stop, a, limitAt: has ? lvl : null }, o);
    return { dir, checks, plan };
  });
}

/* ───────── Fair value gap, standalone ───────── */
export function fvgStrategy(S, o = {}) {
  return pickDirection('fvg', ['فجوة القيمة العادلة (FVG)', 'Fair value gap (FVG)'], (dir) => {
    const long = dir === 'long'; const sg = long ? 1 : -1; const i = S.i; const cs = S.cs; const a = S.a[i]; const c = cs[i]; const checks = [];
    let gap = null;
    for (let from = i - 2; from >= Math.max(1, i - 30) && !gap; from--) { const g = lastGap(S, dir, from, from + 1, 0.25); if (g && Math.abs(cs[g.k].close - cs[g.k].open) >= 0.8 * (S.a[g.k] || Infinity)) gap = g; }
    checks.push(chk('gap', 'فجوة من شمعة اندفاع، لسا ما تسكّرت', 'A gap from a displacement candle, still open', okv(Boolean(gap)), gap ? `${r5(gap.bottom)}–${r5(gap.top)} · ${i - gap.k} bars ago` : 'none in 30 candles'));
    const e50 = S.e50[i];
    checks.push(chk('side', 'السعر بجهة EMA 50 مع الصفقة', 'Price on the trade\'s side of EMA 50', e50 == null ? NA : okv(long ? c.close > e50 : c.close < e50), e50 == null ? '' : `${r5(e50)}`));
    const p = cs[i - 1];
    const tap = gap && i > gap.k + 1 ? (long ? Math.min(c.low, i - 1 > gap.k + 1 ? p.low : Infinity) <= gap.top : Math.max(c.high, i - 1 > gap.k + 1 ? p.high : -Infinity) >= gap.bottom) : gap ? false : null;
    checks.push(chk('tap', 'السعر رجع للفجوة', 'Price returned into the gap', okv(tap), ''));
    checks.push(chk('reaction', 'شمعة تفاعل مسكّرة من الفجوة', 'Closed reaction candle out of the gap', gap ? okv(long ? c.close > c.open && c.close > gap.bottom : c.close < c.open && c.close < gap.top) : NA, ''));
    checks.push(htfCheck(S, dir));
    const stop = gap && a ? (long ? Math.min(gap.bottom, c.low) : Math.max(gap.top, c.high)) - sg * 0.25 * a : NaN;
    const plan = finish(checks, { dir, entry: c.close, stop, a, limitAt: gap ? (gap.top + gap.bottom) / 2 : null }, o);
    return { dir, checks, plan };
  });
}

/* ───────── Classic price patterns: double top / bottom, head & shoulders (confirmed pivots only) ───────── */
export function patternStrategy(S, o = {}) {
  return pickDirection('patterns', ['نماذج السعر الكلاسيكية', 'Classic price patterns'], (dir) => {
    const long = dir === 'long'; const sg = long ? 1 : -1; const i = S.i; const cs = S.cs; const a = S.a[i]; const c = cs[i]; const checks = [];
    const P = (long ? S.sw.lo : S.sw.hi).filter((p) => i - p.i <= 80); let pat = null;
    const neckOf = (x, y) => { const seg = cs.slice(x, y + 1); return long ? Math.max(...seg.map((b) => b.high)) : Math.min(...seg.map((b) => b.low)); };
    if (a && P.length >= 3) {
      const [A, B, C] = P.slice(-3);
      if ((A.price - B.price) * sg >= 0.3 * a && (C.price - B.price) * sg >= 0.3 * a && Math.abs(A.price - C.price) <= 0.6 * a) pat = { kind: long ? 'inverse head & shoulders' : 'head & shoulders', neck: neckOf(A.i, C.i), base: B.price, right: C.price };
    }
    if (!pat && a && P.length >= 2) {
      const [A, B] = P.slice(-2);
      if (B.i - A.i >= 5 && Math.abs(A.price - B.price) <= 0.4 * a) pat = { kind: long ? 'double bottom' : 'double top', neck: neckOf(A.i, B.i), base: long ? Math.min(A.price, B.price) : Math.max(A.price, B.price), right: B.price };
    }
    const height = pat ? (pat.neck - pat.base) * sg : null;
    checks.push(chk('pattern', long ? 'قاع مزدوج أو رأس وكتفين مقلوب' : 'قمة مزدوجة أو رأس وكتفين', long ? 'Double bottom or inverse head & shoulders' : 'Double top or head & shoulders', a ? okv(Boolean(pat) && height >= a) : NA, pat ? `${pat.kind} · neckline ${r5(pat.neck)} · measured move ${r5(pat.neck + sg * height)}` : 'none'));
    const back = cs[Math.max(0, i - 3)];
    checks.push(chk('break', 'إغلاق ورا خط العنق (جديد، آخر 3 شموع)', 'Close beyond the neckline (fresh, within 3 candles)', pat ? okv(long ? c.close > pat.neck && back.close <= pat.neck : c.close < pat.neck && back.close >= pat.neck) : NA, ''));
    checks.push(chk('body', 'شمعة بنفس الاتجاه ومش ممدودة', 'Candle in the same direction, not extended', pat && a ? okv((long ? c.close > c.open : c.close < c.open) && (c.close - pat.neck) * sg <= 1.2 * a) : NA, ''));
    let stop = NaN;
    if (pat && a) { const s0 = pat.right - sg * 0.2 * a; stop = (c.close - s0) * sg <= 3 * a ? s0 : c.close - sg * 2.5 * a; }
    const plan = finish(checks, { dir, entry: c.close, stop, a, limitAt: pat ? pat.neck : null }, o);
    return { dir, checks, plan };
  });
}

/** Volume profile of the last `n` closed candles before the current one → { poc, vah, val } | null (needs real volume). */
export function volumeProfile(cs, i, n = 120, bins = 30) {
  const seg = cs.slice(Math.max(0, i - n), i); if (seg.length < 60) return null;
  if (seg.filter((b) => b.volume > 0).length < seg.length * 0.8) return null;
  const lo = Math.min(...seg.map((b) => b.low)), hi = Math.max(...seg.map((b) => b.high)); const step = (hi - lo) / bins; if (!(step > 0)) return null;
  const v = new Array(bins).fill(0);
  for (const b of seg) { const x = Math.min(bins - 1, Math.max(0, Math.floor((b.low - lo) / step))), y = Math.min(bins - 1, Math.max(0, Math.floor((b.high - lo) / step))); const part = b.volume / (y - x + 1); for (let k = x; k <= y; k++) v[k] += part; }
  const total = v.reduce((s, x) => s + x, 0); let p = 0; for (let k = 1; k < bins; k++) if (v[k] > v[p]) p = k;
  let x = p, y = p, acc = v[p];
  while (acc < 0.7 * total && (x > 0 || y < bins - 1)) { const dn = x > 0 ? v[x - 1] : -1, up = y < bins - 1 ? v[y + 1] : -1; if (up >= dn) acc += v[++y]; else acc += v[--x]; }
  return { poc: lo + (p + 0.5) * step, val: lo + x * step, vah: lo + (y + 1) * step };
}

/* ───────── Volume profile: rejection at the value-area edge back towards the POC ───────── */
export function volumeProfileStrategy(S, o = {}) {
  const vp = volumeProfile(S.cs, S.i);
  return pickDirection('volume_profile', ['بروفايل الحجم (POC / VAH / VAL)', 'Volume profile (POC / VAH / VAL)'], (dir) => {
    const long = dir === 'long'; const sg = long ? 1 : -1; const i = S.i; const cs = S.cs; const a = S.a[i]; const c = cs[i]; const p = cs[i - 1]; const checks = [];
    checks.push(chk('volume', 'حجم تداول حقيقي لآخر 120 شمعة', 'Real traded volume for the last 120 candles', vp ? PASS : NA, vp ? `POC ${r5(vp.poc)} · VAH ${r5(vp.vah)} · VAL ${r5(vp.val)}` : 'this feed gives no volume'));
    const edge = vp ? (long ? vp.val : vp.vah) : null; const ext = long ? Math.min(c.low, p.low) : Math.max(c.high, p.high);
    checks.push(chk('edge', long ? 'لمس حد القيمة السفلي VAL ورجوع فوقه' : 'لمس حد القيمة العلوي VAH ورجوع تحته', long ? 'Touch of the value-area low and a close back above it' : 'Touch of the value-area high and a close back below it', vp && a ? okv((ext - edge) * sg <= 0.1 * a && (c.close - edge) * sg > 0) : NA, edge == null ? '' : `${r5(edge)}`));
    checks.push(chk('reaction', 'شمعة رفض مسكّرة', 'Closed rejection candle', vp ? okv(long ? c.close > c.open : c.close < c.open) : NA, ''));
    const adxV = S.d[i];
    checks.push(chk('range', 'ما في اتجاه قوي (ADX < 30)', 'No strong trend (ADX < 30)', !vp ? NA : adxV == null ? NA : okv(adxV < 30), adxV == null ? '' : `ADX ${r2(adxV)}`));
    const far = vp ? (long ? vp.vah : vp.val) : null;
    const plan = finish(checks, { dir, entry: c.close, stop: vp && a ? ext - sg * 0.3 * a : NaN, a, targets: vp ? [vp.poc, (vp.poc + far) / 2, far] : null, limitAt: edge }, o);
    return { dir, checks, plan };
  });
}

/* ───────── v320 — institutional order flow (from candle volume): deep-liquidity nodes + absorption + volume delta ───────── */
// There is no order book or tape in the app, so this reads what the candles' REAL volume shows: where most volume traded
// (high-volume nodes), whether a return to such a node is absorbed (high volume, long rejection wick) and which side the
// estimated delta favours (volume weighted by where each candle closed in its range — an estimate, labelled as one).
/** High-volume nodes of the last `n` candles before `i` → [{ bottom, top, vol }] sorted by price, or null without real volume. */
export function volumeNodes(cs, i, n = 120, bins = 30) {
  const seg = cs.slice(Math.max(0, i - n), i); if (seg.length < 60 || seg.filter((b) => b.volume > 0).length < seg.length * 0.8) return null;
  const lo = Math.min(...seg.map((b) => b.low)), hi = Math.max(...seg.map((b) => b.high)); const step = (hi - lo) / bins; if (!(step > 0)) return null;
  const v = new Array(bins).fill(0);
  for (const b of seg) { const x = Math.min(bins - 1, Math.max(0, Math.floor((b.low - lo) / step))), y = Math.min(bins - 1, Math.max(0, Math.floor((b.high - lo) / step))); const part = b.volume / (y - x + 1); for (let k = x; k <= y; k++) v[k] += part; }
  const avg = v.reduce((s, x) => s + x, 0) / bins; const out = [];
  for (let k = 0; k < bins; k++) { if (v[k] < 1.4 * avg) continue; const last = out.at(-1); if (last && Math.abs(last.top - (lo + k * step)) < step / 2) { last.top = lo + (k + 1) * step; last.vol += v[k]; } else out.push({ bottom: lo + k * step, top: lo + (k + 1) * step, vol: v[k] }); }
  return out;
}
export function orderFlowStrategy(S, o = {}) {
  const nodes = volumeNodes(S.cs, S.i);
  return pickDirection('order_flow', ['تدفق أوامر المؤسسات (حجم)', 'Institutional order flow (volume)'], (dir) => {
    const long = dir === 'long'; const sg = long ? 1 : -1; const i = S.i; const cs = S.cs; const a = S.a[i]; const c = cs[i]; const p = cs[i - 1]; const checks = [];
    checks.push(chk('volume', 'حجم تداول حقيقي لآخر 120 شمعة', 'Real traded volume for the last 120 candles', nodes ? PASS : NA, nodes ? `${nodes.length} high-volume nodes` : 'this feed gives no volume'));
    const ext = long ? Math.min(c.low, p.low) : Math.max(c.high, p.high);
    // the deep-liquidity node this candle reacted from: touched by the wick, closed back on the trade's side of it
    const node = nodes && a ? nodes.filter((z) => (long ? ext <= z.top + 0.1 * a && ext >= z.bottom - 0.3 * a && c.close > z.top : ext >= z.bottom - 0.1 * a && ext <= z.top + 0.3 * a && c.close < z.bottom)).sort((x, y) => y.vol - x.vol)[0] : null;
    checks.push(chk('node', 'رجوع لمنطقة سيولة عميقة (حجم عالي) وإغلاق برّاها', 'Return to a deep-liquidity (high-volume) zone and a close out of it', nodes ? okv(Boolean(node)) : NA, node ? `${r5(node.bottom)}–${r5(node.top)}` : 'none'));
    const vols = cs.slice(i - 20, i).map((b) => b.volume || 0); const avgV = vols.reduce((x, y) => x + y, 0) / (vols.length || 1);
    const rng = (b) => Math.max(b.high - b.low, 1e-12); const wick = (b) => (long ? Math.min(b.open, b.close) - b.low : b.high - Math.max(b.open, b.close)) / rng(b);
    const absorb = nodes && avgV > 0 ? Math.max(c.volume || 0, p.volume || 0) >= 1.3 * avgV && Math.max(wick(c), wick(p)) >= 0.35 : null;
    checks.push(chk('absorb', 'امتصاص: حجم ≥ 1.3× المتوسط مع ذيل رفض', 'Absorption: volume ≥ 1.3× average with a rejection wick', okv(absorb), avgV > 0 ? `${r2(Math.max(c.volume || 0, p.volume || 0) / avgV)}× · wick ${r2(Math.max(wick(c), wick(p)))}` : ''));
    const delta = cs.slice(i - 2, i + 1).reduce((s, b) => s + (b.volume || 0) * ((2 * (b.close - b.low)) / rng(b) - 1), 0);
    checks.push(chk('delta', 'دلتا الحجم التقديرية مع الصفقة (آخر 3 شموع)', 'Estimated volume delta with the trade (last 3 candles)', nodes ? okv(delta * sg > 0) : NA, nodes ? `${r2(delta)} (estimate from candles)` : ''));
    checks.push(chk('reaction', 'شمعة تأكيد مسكّرة', 'Closed confirmation candle', nodes ? okv(long ? c.close > c.open : c.close < c.open) : NA, ''));
    const stop = node && a ? (long ? Math.min(node.bottom, ext) : Math.max(node.top, ext)) - sg * 0.3 * a : NaN;
    const plan = finish(checks, { dir, entry: c.close, stop, a, limitAt: node ? (long ? node.top : node.bottom) : null }, o);
    return { dir, checks, plan };
  });
}
