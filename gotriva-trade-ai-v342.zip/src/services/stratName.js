// Display name of a strategy id ('classic' | 'smc' | 'zone' | 'edh' | 'lbr').
import { t, getLang } from '../i18n/index.js';
const NEW = { ict: ['ICT', 'ICT'], asian_range: ['اختراق النطاق الآسيوي', 'Asian range breakout'], fvg: ['فجوة القيمة العادلة', 'Fair value gap'], patterns: ['نماذج السعر', 'Price patterns'], volume_profile: ['بروفايل الحجم', 'Volume profile'], order_flow: ['تدفق أوامر المؤسسات', 'Institutional order flow'] };
export const stratName = (s) => (NEW[s] ? NEW[s][getLang() === 'ar' ? 0 : 1] : s === 'trend' ? (getLang() === 'ar' ? 'تتبّع الاتجاه' : 'Trend') : s === 'mean_reversion' ? (getLang() === 'ar' ? 'الارتداد للمتوسط' : 'Mean reversion') : s === 'smc' ? 'SMC' : s === 'zone' ? t('zs.name') : s === 'edh' ? 'EDH' : s === 'lbr' ? t('lbr.name') : t('perf.classic'));
