// Forex Factory data: the weekly economic calendar (official JSON feed) and the latest news
// headlines. Both are read through the site's own proxy paths (/ff/...) — Netlify rewrites them to
// Forex Factory (see public/_redirects), so the browser is not blocked by CORS.
import { storage } from '../utils/storage.js';

export const FF_CAL_URL = '/ff/cal/thisweek';
export const FF_NEWS_URL = '/ff/news';
const CAL_TTL = 30 * 60_000; // Forex Factory asks clients not to poll the feed often
const NEWS_TTL = 2 * 60_000;

// Outside a browser (the 24/7 server worker) there is no site origin for the /ff/... paths: read the feeds directly.
const DIRECT = { '/ff/cal/thisweek': 'https://nfs.faireconomy.media/ff_calendar_thisweek.json', '/ff/news': 'https://www.forexfactory.com/news' };
async function getText(url, timeoutMs = 12000) {
  if (typeof location === 'undefined' && DIRECT[url]) url = DIRECT[url];
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    let r;
    try { r = await fetch(url, { signal: ctl.signal, headers: { Accept: '*/*' } }); } catch (err) { if (!(typeof location !== 'undefined' && url === FF_CAL_URL)) throw err; r = null; }
    // v326: Forex Factory refuses our hosting server's address (HTTP 429/502 here) but not the visitor's own connection → for the
    // calendar feed only, ask the source directly from the browser. If the source forbids that (CORS) nothing changes.
    if ((!r || !r.ok) && typeof location !== 'undefined' && url === FF_CAL_URL) {
      try { const d = await fetch(DIRECT[FF_CAL_URL], { signal: ctl.signal }); if (d.ok) return await d.text(); } catch { /* blocked: keep the first error */ }
    }
    if (!r) throw new Error('network');
    if (!r.ok) throw Object.assign(new Error(`HTTP ${r.status}`), { status: r.status });
    return await r.text();
  } finally { clearTimeout(timer); }
}

const memo = new Map();
async function cached(key, ttl, fn, force) {
  const hit = memo.get(key) || storage.get(`cache:${key}`);
  if (!force && hit && Date.now() - hit.at < ttl) return { ...hit, cached: true };
  try {
    const value = await fn();
    const entry = { at: Date.now(), value };
    memo.set(key, entry);
    storage.set(`cache:${key}`, entry);
    return entry;
  } catch (err) {
    if (hit) return { ...hit, stale: true, error: err }; // keep showing the last good copy
    throw err;
  }
}

/** Currency → the site's instruments that usually move on its news. */
export const CCY_IMPACT = {
  USD: ['XAUUSD', 'US30', 'US100', 'SPX500', 'BTCUSDT'],
  EUR: ['XAUUSD'], GBP: [], JPY: ['XAUUSD'], CNY: ['XAUUSD'], CHF: ['XAUUSD'], AUD: [], CAD: [], NZD: [], ALL: ['XAUUSD', 'US30', 'US100', 'SPX500', 'BTCUSDT'],
};

/** `impact` above is whitelisted because it ends up in a CSS class name. Only http(s) links from scraped pages (a `javascript:` href must never reach an <a>). */
function safeHttpUrl(href) {
  try {
    const u = new URL(href, 'https://www.forexfactory.com');
    return u.protocol === 'https:' || u.protocol === 'http:' ? u.href : 'https://www.forexfactory.com/news';
  } catch { return 'https://www.forexfactory.com/news'; }
}

/** Economic calendar for the current week: [{ id, title, country, time(ms), impact, forecast, previous, actual }]. */
export async function getCalendar({ force = false } = {}) {
  const r = await cached('ffcal', CAL_TTL, async () => {
    const raw = JSON.parse(await getText(FF_CAL_URL));
    if (!Array.isArray(raw)) throw new Error('parse');
    return raw.map((e, i) => ({
      id: `${e.date}|${e.country}|${e.title}|${i}`,
      title: String(e.title || ''), country: String(e.country || ''), time: Date.parse(e.date),
      impact: ['High', 'Medium', 'Low', 'Holiday'].includes(String(e.impact)) ? String(e.impact) : 'Low', forecast: e.forecast || '', previous: e.previous || '', actual: e.actual || '',
    })).filter((e) => Number.isFinite(e.time)).sort((a, b) => a.time - b.time);
  }, force);
  return { events: r.value, at: r.at, stale: !!r.stale, error: r.error };
}

const AGO = /(\d+\s*(?:sec|min|hr|hour|day|wk|week)s?(?:\s*\d+\s*(?:min|hr)s?)?\s*ago|just now)/i;
function agoToMs(s) {
  if (!s) return null;
  if (/just now/i.test(s)) return 0;
  let ms = 0;
  for (const [, n, u] of s.matchAll(/(\d+)\s*(sec|min|hr|hour|day|wk|week)/gi)) {
    const k = u.toLowerCase();
    ms += Number(n) * (k.startsWith('sec') ? 1e3 : k.startsWith('min') ? 6e4 : k.startsWith('h') ? 36e5 : k.startsWith('d') ? 864e5 : 6048e5);
  }
  return ms;
}

/** Parse the Forex Factory news page into headlines. Exported for tests. */
export function parseFFNews(html, now = Date.now()) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const out = [];
  const seen = new Set();
  for (const a of doc.querySelectorAll('a[href*="/news/"]')) {
    const href = a.getAttribute('href') || '';
    const m = href.match(/\/news\/(\d+)-?[^"?#]*/);
    if (!m) continue;
    const title = (a.getAttribute('title') || a.textContent || '').replace(/\s+/g, ' ').trim();
    if (title.length < 12 || /^(more|comments?|\d+ comments?)$/i.test(title)) continue;
    if (seen.has(m[1])) { continue; }
    seen.add(m[1]);
    // Source and age live next to the headline ("bls.gov | 1 hr 4 min ago", "@realDonaldTrump | 2 min ago").
    let box = a.parentElement;
    for (let k = 0; k < 5 && box && !AGO.test(box.textContent || ''); k++) box = box.parentElement;
    const text = (box?.textContent || '').replace(/\s+/g, ' ');
    const ago = text.match(AGO)?.[1] || '';
    const src = text.match(/((?:@\w{2,30})|(?:[a-z0-9-]+\.)+[a-z]{2,})\s*\|\s*[^|]*?(?:ago|just now)/i)?.[1] || '';
    const impact = /high/i.test(box?.className || '') ? 'High' : '';
    const agoMs = agoToMs(ago);
    out.push({
      id: m[1], title, url: safeHttpUrl(href),
      source: src, isX: src.startsWith('@'), ago, time: agoMs != null ? now - agoMs : null, impact,
    });
    if (out.length >= 60) break;
  }
  return out;
}

export async function getFFNews({ force = false } = {}) {
  const r = await cached('ffnews', NEWS_TTL, async () => {
    const items = parseFFNews(await getText(FF_NEWS_URL));
    if (!items.length) throw new Error('parse');
    return items;
  }, force);
  return { items: r.value, at: r.at, stale: !!r.stale, error: r.error };
}

/** Curated accounts on X that break market news first. */
export const X_ACCOUNTS = [
  { handle: 'FirstSquawk', name: 'First Squawk', topic: 'macro' },
  { handle: 'DeItaone', name: 'Walter Bloomberg', topic: 'macro' },
  { handle: 'ForexLive', name: 'ForexLive', topic: 'fx' },
  { handle: 'financialjuice', name: 'Financial Juice', topic: 'macro' },
  { handle: 'WatcherGuru', name: 'Watcher.Guru', topic: 'crypto' },
  { handle: 'federalreserve', name: 'Federal Reserve', topic: 'fed' },
];

/** Live searches on X for each instrument. */
export const X_SEARCHES = [
  { label: 'BTC', q: '$BTC OR #Bitcoin' }, { label: 'ETH', q: '$ETH OR #Ethereum' },
  { label: 'Gold', q: 'XAUUSD OR #gold price' }, { label: 'Nasdaq', q: 'Nasdaq OR $NDX OR $QQQ' },
  { label: 'S&P 500', q: '$SPX OR "S&P 500"' }, { label: 'Fed', q: 'Fed OR FOMC OR Powell' },
];
export const xSearchUrl = (q) => `https://x.com/search?q=${encodeURIComponent(q)}&f=live`;
