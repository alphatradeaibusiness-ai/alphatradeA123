// Client of the digital bank (/api/bank/*). The server is the only authority: balances, limits and permissions are
// decided there. This module only calls it, keeps the latest wallet in memory and listens to the live stream.
import { apiRequest, AI_BASE } from '../ai/gateway.js';
import { auth } from '../auth/index.js';
import { askTotpCode } from './totpPrompt.js';

export const BANK_BASE = AI_BASE.replace(/\/api\/ai$/, '/api/bank');
const raw = (method, path, body, ms = 30000) => apiRequest(method, `${BANK_BASE}${path}`, body, ms);
/** Users with an authenticator app (and no passkey): when the server asks for the code, ask once and repeat the same request with it. */
const call = async (method, path, body, ms = 30000) => {
  try { return await raw(method, path, body, ms); }
  catch (e) {
    if (e?.code !== 'totp_required') throw e;
    if (path.startsWith('/admin/')) {
      // Owner console: one authenticator code unlocks the admin routes for a few minutes, then the request is retried.
      const code = await askTotpCode(); if (!code) throw e;
      await raw('POST', '/admin/unlock', { code }, ms);
      return raw(method, path, body, ms);
    }
    if (method === 'GET') throw e;
    const code = await askTotpCode(); if (!code) throw e;
    return raw(method, path, { ...(body || {}), passkey: code }, ms);
  }
};
export const newIdem = () => `i${Date.now().toString(36)}${crypto.getRandomValues(new Uint32Array(3)).reduce((s, n) => s + n.toString(36), '')}`.slice(0, 48);

export const bankApi = {
  status: () => call('GET', '/status', undefined, 10000),
  wallet: () => call('GET', '/wallet'),
  history: (q = {}) => call('GET', `/history?${new URLSearchParams(Object.entries(q).filter(([, v]) => v)).toString()}`),
  fund: (b) => call('POST', '/sandbox/fund', { ...b, idem: newIdem() }),
  deposits: () => call('GET', '/deposits'), requestDeposit: (b) => call('POST', '/deposits', { ...b, idem: newIdem() }),
  beneficiaries: () => call('GET', '/beneficiaries'), addBeneficiary: (b) => call('POST', '/beneficiaries', b), removeBeneficiary: (id, b = {}) => call('DELETE', `/beneficiaries/${id}`, b),
  withdrawals: () => call('GET', '/withdrawals'), withdraw: (b) => call('POST', '/withdrawals', { ...b, idem: b.idem || newIdem() }), cancelWithdrawal: (id) => call('POST', `/withdrawals/${id}/cancel`, {}),
  kyc: () => call('GET', '/kyc'), submitKyc: (b) => call('POST', '/kyc', b),
  cards: () => call('GET', '/cards'), requestCard: (b) => call('POST', '/cards', { ...b, idem: newIdem() }), cardAction: (id, a) => call('POST', `/cards/${id}/${a}`, {}),
  plans: () => call('GET', '/plans'), createPlan: (b) => call('POST', '/plans', b), planAction: (id, a) => call('POST', `/plans/${id}/${a}`, {}),
  orders: () => call('GET', '/orders'), holdings: () => call('GET', '/holdings'),
  // v150
  history2: (q = {}) => call('GET', `/history?${new URLSearchParams(Object.entries(q).filter(([, v]) => v)).toString()}`),
  label: (txn, b) => call('POST', `/history/${txn}/label`, b),
  pockets: () => call('GET', '/pockets'), createPocket: (b) => call('POST', '/pockets', b), updatePocket: (id, b) => call('POST', `/pockets/${id}`, b), deletePocket: (id) => call('DELETE', `/pockets/${id}`),
  movePocket: (b) => call('POST', '/pockets/move', { ...b, idem: newIdem() }),
  vault: () => call('GET', '/vault'), vaultIn: (b) => call('POST', '/vault/deposit', { ...b, idem: newIdem() }), vaultOut: (b) => call('POST', '/vault/release', b), vaultCancel: (id) => call('POST', `/vault/releases/${id}/cancel`, {}),
  passkeys: () => call('GET', '/passkeys'), passkeyOptions: () => call('POST', '/passkeys/register-options', {}), passkeyRegister: (b) => call('POST', '/passkeys/register', b),
  passkeyChallenge: (purpose, params) => call('POST', '/passkeys/challenge', { purpose, params }), passkeyRemove: (id, b) => call('DELETE', `/passkeys/${id}`, b),
  freeze: (b) => call('POST', '/freeze', b),
  totp: () => call('GET', '/totp'), totpEnroll: () => call('POST', '/totp/enroll', {}), totpConfirm: (code) => call('POST', '/totp/confirm', { code }), totpDisable: (code) => call('POST', '/totp/disable', { code }), totpBackup: (code) => call('POST', '/totp/backup-codes', { code }),
  approvals: () => call('GET', '/approvals'), setPolicy: (b) => call('POST', '/approvals/policy', b), invite: (label) => call('POST', '/approvals/invite', { label }),
  acceptInvite: (code) => call('POST', '/approvals/accept', { code }), removeApprover: (ref, b) => call('DELETE', `/approvals/approvers/${ref}`, b), vote: (id, b) => call('POST', `/approvals/${id}/vote`, b),
  vcards: () => call('GET', '/vcards'), createVcard: (b) => call('POST', '/vcards', b), updateVcard: (id, b) => call('POST', `/vcards/${id}`, b), vcardAction: (id, a) => call('POST', `/vcards/${id}/${a}`, {}),
  appleWallet: (id, b) => call('POST', `/vcards/${id}/apple-wallet`, b), revealVcard: (id, b) => call('POST', `/vcards/${id}/reveal`, b), simulate: (id, b) => call('POST', `/vcards/${id}/simulate`, b), simulateRefund: (authId) => call('POST', `/vcards/auths/${authId}/refund`, {}),
  purchases: (card) => call('GET', `/vcards/purchases${card ? `?card=${encodeURIComponent(card)}` : ''}`),
  blocked: () => call('GET', '/merchants/blocked'), block: (merchant, on) => call('POST', '/merchants/block', { merchant, on }),
  subs: () => call('GET', '/subscriptions'), addSub: (b) => call('POST', '/subscriptions', b), subAction: (id, a) => call('POST', `/subscriptions/${id}/${a}`, {}),
  budgets: () => call('GET', '/budgets'), setBudget: (b) => call('POST', '/budgets', b), deleteBudget: (c) => call('DELETE', `/budgets/${c}`),
  rules: () => call('GET', '/rules'), createRule: (b) => call('POST', '/rules', b), ruleAction: (id, a) => call('POST', `/rules/${id}/${a}`, {}),
  rewards: () => call('GET', '/rewards'), redeem: (b) => call('POST', '/rewards/redeem', b),
  rates: () => call('GET', '/fx/rates', undefined, 15000), calc: (q) => call('GET', `/fx/calc?${new URLSearchParams(q).toString()}`, undefined, 15000), convert: (b) => call('POST', '/fx/convert', { ...b, idem: newIdem() }),
  intlQuote: (b) => call('POST', '/intl/quote', b), intlConfirm: (b) => call('POST', '/intl/confirm', { ...b, idem: newIdem() }),
  ob: () => call('GET', '/ob'), obLink: (b) => call('POST', '/ob/link', b), obRefresh: (id) => call('POST', `/ob/${id}/refresh`, {}), obRevoke: (id) => call('DELETE', `/ob/${id}`), obTxns: (acc) => call('GET', `/ob/accounts/${acc}/txns`),
  insights: () => call('GET', '/insights'), dashboard: () => call('GET', '/dashboard', undefined, 20000), tax: (year) => call('GET', `/tax?year=${year}`), sell: (b) => call('POST', '/holdings/sell', { ...b, idem: newIdem() }),
  tickets: () => call('GET', '/tickets'), ticket: (id) => call('GET', `/tickets/${id}`), newTicket: (b) => call('POST', '/tickets', b), replyTicket: (id, body) => call('POST', `/tickets/${id}/reply`, { body }), closeTicket: (id) => call('POST', `/tickets/${id}/close`, {}),
  notifications: () => call('GET', '/notifications'), markRead: () => call('POST', '/notifications/read', {}), prefs: () => call('GET', '/notifications/prefs'), setPrefs: (b) => call('POST', '/notifications/prefs', b),
  pushKey: () => call('GET', '/push/key'), pushSubscribe: (subscription) => call('POST', '/push/subscribe', { subscription }), pushUnsubscribe: (endpoint) => call('POST', '/push/unsubscribe', { endpoint }),
  admin: {
    dashboard: () => call('GET', '/admin/dashboard'), tickets: () => call('GET', '/admin/tickets'), ticket: (id) => call('GET', `/admin/tickets/${id}`), replyTicket: (id, b) => call('POST', `/admin/tickets/${id}/reply`, b),
    risk: () => call('GET', '/admin/risk?open=1'), riskReview: (id, note = '') => call('POST', `/admin/risk/${id}/review`, { note }), compliance: () => call('GET', '/admin/compliance'), complianceGet: (id) => call('GET', `/admin/compliance/${id}`),
    queue: () => call('GET', '/admin/queue'), verify: () => call('GET', '/admin/verify'), audit: () => call('GET', '/admin/audit?limit=60'),
    deposit: (id, a, b) => call('POST', `/admin/deposits/${id}/${a}`, b), withdrawal: (id, a, b) => call('POST', `/admin/withdrawals/${id}/${a}`, b),
    destination: (id) => call('GET', `/admin/withdrawals/${id}/destination`), kycDetail: (uid) => call('GET', `/admin/kyc/${encodeURIComponent(uid)}`),
    kycReview: (uid, a, b) => call('POST', `/admin/kyc/${encodeURIComponent(uid)}/${a}`, b), card: (id) => call('GET', `/admin/cards/${id}`), cardUpdate: (id, b) => call('POST', `/admin/cards/${id}/update`, b),
  },
};

/**
 * Live updates: the server pushes a tiny "balance" event whenever this user's money state changes; we then re-read. Reconnects with
 * back-off (and with a fresh token, they expire); if the stream cannot be used, `onEvent` is also called every 20 s.
 */
export function startBankStream(onEvent) {
  let stop = false; let ctrl = null; let delay = 1000; let poll = null;
  const pollOn = () => { if (!poll) poll = setInterval(() => { if (!document.hidden) onEvent(); }, 20000); };
  const pollOff = () => { clearInterval(poll); poll = null; };
  async function loop() {
    while (!stop) {
      try {
        const tok = await auth.idToken().catch(() => null); if (!tok) throw new Error('no-token');
        ctrl = new AbortController();
        const res = await fetch(`${BANK_BASE}/stream`, { headers: { Authorization: `Bearer ${tok}`, Accept: 'text/event-stream' }, signal: ctrl.signal });
        if (!res.ok || !res.body) throw new Error(`stream ${res.status}`);
        pollOff(); delay = 1000;
        const rd = res.body.getReader(); const dec = new TextDecoder(); let buf = '';
        for (;;) {
          const { value, done } = await rd.read(); if (done) break;
          buf += dec.decode(value, { stream: true });
          let i; while ((i = buf.indexOf('\n\n')) >= 0) { const block = buf.slice(0, i); buf = buf.slice(i + 2); const m = /^event: (\w+)/m.exec(block); if (m) onEvent(m[1]); }
        }
      } catch { if (stop) return; pollOn(); }
      if (stop) return;
      await new Promise((r) => setTimeout(r, delay)); delay = Math.min(delay * 2, 30000);
    }
  }
  loop();
  return () => { stop = true; ctrl?.abort(); pollOff(); };
}

/** Tax report as a CSV file download (the server sends it as an attachment; a fetch with the token is needed). */
export async function downloadTaxCsv(year) {
  const tok = await auth.idToken().catch(() => null); if (!tok) throw Object.assign(new Error('signin_required'), { code: 'signin_required' });
  const r = await fetch(`${BANK_BASE}/tax.csv?year=${encodeURIComponent(year)}`, { headers: { Authorization: `Bearer ${tok}` } });
  if (!r.ok) throw Object.assign(new Error('download_failed'), { code: 'unknown' });
  const url = URL.createObjectURL(await r.blob());
  const a = document.createElement('a'); a.href = url; a.download = `gotrivatrade-tax-${year}.csv`; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

/** Owner: one compliance report as CSV (token needed, so fetch + blob like the tax CSV). */
export async function downloadComplianceCsv(id, name = 'report') {
  const tok = await auth.idToken().catch(() => null); if (!tok) throw Object.assign(new Error('signin_required'), { code: 'signin_required' });
  const r = await fetch(`${BANK_BASE}/admin/compliance/${encodeURIComponent(id)}.csv`, { headers: { Authorization: `Bearer ${tok}` } });
  if (!r.ok) throw Object.assign(new Error('download_failed'), { code: 'unknown' });
  const url = URL.createObjectURL(await r.blob());
  const a = document.createElement('a'); a.href = url; a.download = `gotrivatrade-compliance-${String(name).replace(/[^\w-]/g, '_')}.csv`; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
