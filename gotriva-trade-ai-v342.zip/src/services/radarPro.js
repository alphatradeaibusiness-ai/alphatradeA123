// Gotriva Radar Pro (v233) — pure analysis used by the upgraded radar tabs. No network, no DOM, no randomness.
// Everything is computed from real candles passed in; every number comes with the reason it was given.
//  • validateCandles — order, duplicates, gaps, bad prices, freshness (a stale feed is never shown as live)
//  • macd
//  • smartMoneyFlow — buy/sell-side liquidity, equal highs/lows, pools (taken or not), sweeps, OB, FVG, BOS/CHoCH/MSS,
//                     premium/discount, reversal zones, liquidity targets and two possible scenarios (never a promise)
//  • mtfAlignment   — direction per timeframe, conflicts, a real alignment score
//  • qualityScore   — 0–100 from 8 parts (trend, momentum, structure, liquidity, entry, timeframes, volatility, history),
//                     capped when higher timeframes contradict the entry — a setup-quality grade, NOT a win probability
//  • correlate      — Pearson correlation of returns on aligned timestamps, breakdown and divergence; "insufficient" when short
import { ema, rsi, atr } from '../indicators/index.js';
import { smcFull } from '../indicators/smc.js';

export const TF_SEC = { '1m': 60, '5m': 300, '15m': 900, '1h': 3600, '4h': 14400, '1D': 86400 };
export const RADAR_TFS = ['5m', '15m', '1h', '4h', '1D'];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const r2 = (v) => Math.round(v * 100) / 100;

/* ───────── data quality ───────── */
/**
 * → { ok, live, state: 'live' | 'stale' | 'closed' | 'bad', issues: [keys], duplicates, gaps, ageSec, lastTime }
 * A feed is "live" only when its newest candle is recent. A market that is shut (weekend) reads "closed", not stale.
 */
export function validateCandles(candles, tf, { crypto = false, now = Date.now() } = {}) {
  const sec = TF_SEC[tf] || 300; const issues = [];
  if (!Array.isArray(candles) || candles.length < 2) return { ok: false, live: false, state: 'bad', issues: ['empty'], duplicates: 0, gaps: 0, ageSec: null, lastTime: null };
  let dup = 0, gaps = 0, unsorted = 0, bad = 0;
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    if (![c.open, c.high, c.low, c.close].every(Number.isFinite) || c.high < c.low || c.close > c.high * 1.0000001 || c.close < c.low * 0.9999999 || c.close <= 0) bad++;
    if (i) {
      const d = c.time - candles[i - 1].time;
      if (d === 0) dup++; else if (d < 0) unsorted++;
      else if (crypto && d > sec * 1.5) gaps += Math.round(d / sec) - 1;   // crypto trades 24/7: any hole is a missing candle
    }
  }
  if (dup) issues.push('duplicates'); if (unsorted) issues.push('unsorted'); if (bad) issues.push('badPrices'); if (gaps) issues.push('gaps');
  const last = candles.at(-1).time; const ageSec = Math.max(0, Math.round(now / 1000 - last));
  const wd = new Date(now).getUTCDay(); const weekend = wd === 6 || (wd === 0 && new Date(now).getUTCHours() < 21);
  const staleAfter = Math.max(sec * 3, 15 * 60);
  let state = 'live';
  if (bad || unsorted) state = 'bad';
  else if (ageSec > staleAfter) state = !crypto && weekend ? 'closed' : 'stale';
  if (state === 'stale') issues.push('stale');
  return { ok: state !== 'bad', live: state === 'live', state, issues, duplicates: dup, gaps, ageSec, lastTime: last };
}
/** Sorted, duplicate-free copy (the newest duplicate wins) — used before any analysis. */
export function cleanCandles(candles) {
  const m = new Map(); for (const c of candles || []) if (c && Number.isFinite(c.time)) m.set(c.time, c);
  return [...m.values()].sort((a, b) => a.time - b.time);
}

/* ───────── MACD ───────── */
export function macd(closes, fast = 12, slow = 26, sig = 9) {
  const f = ema(closes, fast), s = ema(closes, slow);
  const line = closes.map((_, i) => (Number.isFinite(f[i]) && Number.isFinite(s[i]) ? f[i] - s[i] : NaN));
  const first = line.findIndex(Number.isFinite);
  const sigLine = new Array(closes.length).fill(NaN);
  if (first >= 0) { const e = ema(line.slice(first), sig); for (let i = 0; i < e.length; i++) sigLine[first + i] = e[i]; }
  const hist = line.map((v, i) => (Number.isFinite(v) && Number.isFinite(sigLine[i]) ? v - sigLine[i] : NaN));
  return { line, signal: sigLine, hist };
}

/* ───────── Smart Money Flow ───────── */
/**
 * Liquidity map of CLOSED candles. `candles` should exclude the forming one (the caller passes closed bars).
 * → null when there is not enough history, else { price, atr, pools, sweeps, obs, fvgs, events, range, zone, reversalZones,
 *    targets: { up, down }, concentration, bias, scenarios: [{ key, dir, target, invalidation }] }
 */
export function smartMoneyFlow(candles, { len = 3, lookback = 300, sweepBars = 30 } = {}) {
  const c = candles.length > lookback ? candles.slice(-lookback) : candles;
  if (c.length < 60) return null;
  const full = smcFull(c, { len, maxEvents: 6, maxObs: 6, maxFvgs: 6 });
  if (!full) return null;
  const A = atr(c, 14); const a = A.at(-1) || 0; const last = c.length - 1; const price = c[last].close;
  const tol = Math.max(a * 0.15, price * 0.0002);
  // pools: clusters of swing highs (buy-side) and swing lows (sell-side); equal = 2+ swings at the same level
  const cluster = (type) => {
    const pts = full.swings.filter((s) => s.type === type).sort((x, y) => x.price - y.price); const out = [];
    for (const s of pts) { const g = out.find((p) => Math.abs(p.price - s.price) <= tol); if (g) { g.members.push(s); g.price = type === 'high' ? Math.max(g.price, s.price) : Math.min(g.price, s.price); } else out.push({ price: s.price, members: [s] }); }
    return out.map((g) => {
      const lastIdx = Math.max(...g.members.map((m) => m.index));
      let takenAt = null, swept = false;
      for (let j = lastIdx + 1; j < c.length; j++) {
        const beyond = type === 'high' ? c[j].high > g.price : c[j].low < g.price;
        if (beyond) { takenAt = j; swept = type === 'high' ? c[j].close < g.price : c[j].close > g.price; break; }
      }
      return { side: type === 'high' ? 'buy' : 'sell', price: g.price, count: g.members.length, equal: g.members.length >= 2, taken: takenAt != null, takenAgo: takenAt != null ? last - takenAt : null, swept, formedAgo: last - lastIdx };
    });
  };
  const pools = [...cluster('high'), ...cluster('low')].filter((p) => p.formedAgo <= lookback);
  const sweeps = pools.filter((p) => p.taken && p.swept && p.takenAgo <= sweepBars).map((p) => ({ side: p.side, price: p.price, ago: p.takenAgo, equal: p.equal, dir: p.side === 'buy' ? 'bear' : 'bull' }))
    .sort((x, y) => x.ago - y.ago);
  // structure with MSS (a CHoCH whose breaking candle is a displacement: body ≥ 1.2 × ATR)
  const events = (full.recentEvents || []).map((e) => { const k = c[e.index]; const body = k ? Math.abs(k.close - k.open) : 0; const mss = e.kind === 'CHoCH' && body >= 1.2 * (A[e.index] || a); return { kind: mss ? 'MSS' : e.kind, dir: e.dir, price: e.price, ago: last - e.index }; });
  const obs = (full.obs || []).map((o) => ({ dir: o.dir, top: o.top, bottom: o.bottom, mitigated: o.mitigated, ago: o.age }));
  const fvgs = (full.fvgs || []).map((g) => ({ dir: g.dir, top: g.top, bottom: g.bottom, ago: last - g.index }));
  const range = full.range ? { high: full.range.high, low: full.range.low, eq: full.range.eq } : null;
  const zone = range ? (price > range.eq ? 'premium' : 'discount') : null;
  const reversalZones = [
    ...obs.filter((o) => !o.mitigated).map((o) => ({ kind: 'OB', ...o })),
    ...fvgs.map((g) => ({ kind: 'FVG', ...g })),
  ].filter((z) => range ? (z.dir === 'bull' ? z.top <= range.eq : z.bottom >= range.eq) : true)
    .sort((x, y) => Math.abs((x.top + x.bottom) / 2 - price) - Math.abs((y.top + y.bottom) / 2 - price)).slice(0, 4);
  const open = pools.filter((p) => !p.taken);
  const up = open.filter((p) => p.side === 'buy' && p.price > price).sort((x, y) => x.price - y.price)[0] || null;
  const down = open.filter((p) => p.side === 'sell' && p.price < price).sort((x, y) => y.price - x.price)[0] || null;
  const weight = (side) => open.filter((p) => p.side === side).reduce((s, p) => s + p.count, 0);
  const wUp = weight('buy'), wDown = weight('sell');
  const concentration = wUp + wDown ? (wUp > wDown * 1.4 ? 'above' : wDown > wUp * 1.4 ? 'below' : 'balanced') : 'none';
  const lastEv = events.at(-1) || null; const lastSweep = sweeps[0] || null;
  let bias = 'neutral';
  if (lastSweep && lastSweep.ago <= 10 && (!lastEv || lastEv.dir === lastSweep.dir || lastEv.ago > lastSweep.ago)) bias = lastSweep.dir;
  else if (lastEv) bias = lastEv.dir;
  const scenarios = [];
  const swingHi = [...full.swings].reverse().find((s) => s.type === 'high')?.price ?? null;
  const swingLo = [...full.swings].reverse().find((s) => s.type === 'low')?.price ?? null;
  if (bias === 'bull') {
    scenarios.push({ key: lastSweep?.dir === 'bull' ? 'sweepReversalUp' : 'continuationUp', dir: 'bull', target: up?.price ?? null, invalidation: lastSweep?.dir === 'bull' ? Math.min(lastSweep.price, swingLo ?? lastSweep.price) : swingLo });
    scenarios.push({ key: 'altDown', dir: 'bear', target: down?.price ?? null, invalidation: up?.price ?? swingHi });
  } else if (bias === 'bear') {
    scenarios.push({ key: lastSweep?.dir === 'bear' ? 'sweepReversalDown' : 'continuationDown', dir: 'bear', target: down?.price ?? null, invalidation: lastSweep?.dir === 'bear' ? Math.max(lastSweep.price, swingHi ?? lastSweep.price) : swingHi });
    scenarios.push({ key: 'altUp', dir: 'bull', target: up?.price ?? null, invalidation: down?.price ?? swingLo });
  } else scenarios.push({ key: 'range', dir: 'neutral', target: null, invalidation: null });
  return { price, atr: a, pools: pools.sort((x, y) => y.price - x.price), sweeps, obs, fvgs, events, range, zone, reversalZones, targets: { up, down }, concentration, bias, scenarios };
}

/* ───────── multi-timeframe alignment ───────── */
const TF_W = { '5m': 1, '15m': 1, '1h': 1.5, '4h': 2, '1D': 2.5 };
const dirOf = (b) => (b == null || !Number.isFinite(b) ? null : b >= 0.2 ? 'buy' : b <= -0.2 ? 'sell' : 'neutral');
/** biases: { tf: −1…+1 | null }. → { rows, score 0–100 | null, conflict, htfAgainst, dir } for the entry timeframe's direction. */
export function mtfAlignment(biases, entryTf) {
  const rows = RADAR_TFS.map((tf) => ({ tf, bias: biases[tf] ?? null, dir: dirOf(biases[tf]) }));
  const entry = rows.find((x) => x.tf === entryTf);
  const dir = entry?.dir && entry.dir !== 'neutral' ? entry.dir : (() => { const s = rows.reduce((a, x) => a + (x.bias ?? 0) * TF_W[x.tf], 0); return s >= 0 ? 'buy' : 'sell'; })();
  const known = rows.filter((x) => x.dir);
  if (known.length < 2) return { rows, score: null, conflict: false, htfAgainst: false, dir };
  let w = 0, agree = 0;
  for (const x of known) { w += TF_W[x.tf]; agree += TF_W[x.tf] * (x.dir === dir ? 1 : x.dir === 'neutral' ? 0.5 : 0); }
  const higher = RADAR_TFS.slice(RADAR_TFS.indexOf(entryTf) + 1);
  const opp = dir === 'buy' ? 'sell' : 'buy';
  return { rows, score: Math.round((agree / w) * 100), conflict: known.some((x) => x.dir === 'buy') && known.some((x) => x.dir === 'sell'),
    htfAgainst: rows.some((x) => higher.includes(x.tf) && x.dir === opp), dir };
}

/* ───────── 0–100 setup quality ───────── */
export const GRADES = [[90, 'exceptional'], [80, 'strong'], [70, 'good'], [60, 'moderate'], [0, 'weak']];
export const gradeOf = (s) => GRADES.find(([min]) => s >= min)[1];
/**
 * r = the existing radarScore() result · candles = closed candles · smf = smartMoneyFlow() · mtf = mtfAlignment() | null.
 * → { score, grade, parts: [{ key, pts, max, why: [{ key, params }] }], caps: [keys] }
 */
export function qualityScore({ r, candles, smf, mtf }) {
  const long = r.direction === 'long'; const sgn = long ? 1 : -1; const parts = [];
  const part = (key, max, pts, why) => parts.push({ key, max, pts: r2(clamp(pts, 0, max)), why });
  // 1 trend (EMA 50 / 200)
  const t = r.trend * sgn;
  part('trend', 15, t >= 1 ? 15 : t > 0 ? 8 : 0, [{ key: t >= 1 ? 'trendFull' : t > 0 ? 'trendPartial' : 'trendAgainst' }]);
  // 2 momentum (RSI + MACD + momentum score)
  const closes = candles.map((x) => x.close); const M = macd(closes); const h1 = M.hist.at(-1), h0 = M.hist.at(-2);
  let mp = 0; const mw = [];
  const rsiOk = long ? r.rsi >= 50 && r.rsi <= 70 : r.rsi <= 50 && r.rsi >= 30;
  if (rsiOk) { mp += 4; mw.push({ key: 'rsiOk', params: { v: Math.round(r.rsi) } }); } else mw.push({ key: 'rsiOff', params: { v: Math.round(r.rsi) } });
  if (Number.isFinite(h1) && h1 * sgn > 0) { mp += 3; mw.push({ key: 'macdWith' }); if (Number.isFinite(h0) && (h1 - h0) * sgn > 0) { mp += 1; mw.push({ key: 'macdRising' }); } } else mw.push({ key: 'macdAgainst' });
  if (r.momentum != null && (r.momentum - 50) * sgn > 5) { mp += 2; mw.push({ key: 'momWith', params: { v: Math.round(r.momentum) } }); }
  part('momentum', 10, mp, mw);
  // 3 market structure (BOS / CHoCH / MSS)
  const ev = smf?.events?.at(-1) || null; const evDir = ev ? (ev.dir === 'bull' ? 1 : -1) : 0;
  let sp = 0; const sw = [];
  if (ev && evDir === sgn) { sp = ev.kind === 'MSS' ? 12 : ev.kind === 'BOS' ? 10 : 8; if (ev.ago <= 20) sp += 3; sw.push({ key: 'structWith', params: { kind: ev.kind, ago: ev.ago } }); }
  else sw.push({ key: ev ? 'structAgainst' : 'structNone', params: ev ? { kind: ev.kind } : {} });
  part('structure', 15, sp, sw);
  // 4 liquidity (a sweep of the opposite side, room to the next pool)
  let lp = 0; const lw = [];
  const sweep = smf?.sweeps?.find((s) => (s.dir === 'bull' ? 1 : -1) === sgn && s.ago <= 15);
  if (sweep) { lp += 8; lw.push({ key: 'sweepWith', params: { side: sweep.side, ago: sweep.ago } }); }
  const tgt = long ? smf?.targets?.up : smf?.targets?.down;
  if (tgt && smf.atr > 0) { const room = Math.abs(tgt.price - smf.price) / smf.atr; if (room >= 1.5) { lp += 7; lw.push({ key: 'roomToTarget', params: { atr: r2(room) } }); } else lw.push({ key: 'targetClose', params: { atr: r2(room) } }); }
  else lw.push({ key: 'noTarget' });
  part('liquidity', 15, lp, lw);
  // 5 entry quality (premium / discount, at an untested OB / FVG)
  let ep = 0; const ew = [];
  if (smf?.zone) { const good = long ? smf.zone === 'discount' : smf.zone === 'premium'; if (good) { ep += 5; ew.push({ key: 'zoneGood', params: { zone: smf.zone } }); } else ew.push({ key: 'zoneBad', params: { zone: smf.zone } }); }
  const near = smf?.reversalZones?.find((z) => (z.dir === 'bull' ? 1 : -1) === sgn && smf.price >= z.bottom - smf.atr * 0.5 && smf.price <= z.top + smf.atr * 0.5);
  if (near) { ep += 5; ew.push({ key: 'atZone', params: { kind: near.kind } }); }
  part('entry', 10, ep, ew);
  // 6 timeframe alignment
  if (mtf?.score != null) part('mtf', 15, (mtf.score / 100) * 15, [{ key: 'mtfScore', params: { v: mtf.score } }, ...(mtf.htfAgainst ? [{ key: 'htfAgainst' }] : [])]);
  else part('mtf', 15, 6, [{ key: 'mtfUnknown' }]);
  // 7 volatility (ATR regime from the existing filters)
  const f = r.filters;
  part('volatility', 5, !f ? 2 : f.unstable.includes('atrSpike') ? 0 : f.weak.includes('atrDead') ? 2 : 5, [{ key: !f ? 'volUnknown' : f.unstable.includes('atrSpike') ? 'volSpike' : f.weak.includes('atrDead') ? 'volDead' : 'volOk', params: { pct: r2(r.atrPct) } }]);
  // 8 historical strategy performance (the same back-test as the radar, fees included)
  if (r.trades >= 5) part('history', 15, ((r.winRate - 40) / 30) * 15, [{ key: 'histOk', params: { win: Math.round(r.winRate), n: r.trades } }]);
  else part('history', 15, 4, [{ key: 'histFew', params: { n: r.trades || 0 } }]);
  let score = Math.round(parts.reduce((s, p) => s + p.pts, 0)); const caps = [];
  if (mtf?.htfAgainst) { score = Math.min(score, 59); caps.push('htfAgainst'); }
  if (f?.unstable?.length) { score = Math.min(score, 59); caps.push('unstable'); }
  return { score, grade: gradeOf(score), parts, caps };
}

/* ───────── correlation ───────── */
function pearson(x, y) {
  const n = x.length; if (n < 3) return null;
  const mx = x.reduce((s, v) => s + v, 0) / n, my = y.reduce((s, v) => s + v, 0) / n;
  let sxy = 0, sxx = 0, syy = 0;
  for (let i = 0; i < n; i++) { const a = x[i] - mx, b = y[i] - my; sxy += a * b; sxx += a * a; syy += b * b; }
  return sxx > 0 && syy > 0 ? sxy / Math.sqrt(sxx * syy) : null;
}
/**
 * Correlation of returns on the timestamps both series share. → { insufficient, n, r, recent, strength, sign, breakdown, divergence, move: { a, b } }
 */
export function correlate(a, b, { window = 200, recent = 50, divBars = 20, minBars = 60 } = {}) {
  const mb = new Map((b || []).map((c) => [c.time, c.close]));
  const pairs = (a || []).filter((c) => mb.has(c.time) && c.close > 0 && mb.get(c.time) > 0).map((c) => [c.close, mb.get(c.time)]).slice(-(window + 1));
  if (pairs.length < minBars + 1) return { insufficient: true, n: Math.max(0, pairs.length - 1) };
  const ra = [], rb = [];
  for (let i = 1; i < pairs.length; i++) { ra.push(Math.log(pairs[i][0] / pairs[i - 1][0])); rb.push(Math.log(pairs[i][1] / pairs[i - 1][1])); }
  const r = pearson(ra, rb); const rr = pearson(ra.slice(-recent), rb.slice(-recent));
  // the established relationship = the bars BEFORE the recent window (so a recent change is not averaged into it)
  const base = ra.length - recent >= 30 ? pearson(ra.slice(0, -recent), rb.slice(0, -recent)) : r;
  if (r == null) return { insufficient: true, n: ra.length };
  const abs = Math.abs(r); const strength = abs >= 0.7 ? 'strong' : abs >= 0.4 ? 'moderate' : abs >= 0.2 ? 'weak' : 'none';
  const breakdown = rr != null && base != null && (Math.abs(base - rr) >= 0.4 || (Math.abs(base) >= 0.3 && Math.sign(rr) !== Math.sign(base) && Math.abs(rr) >= 0.15));
  const cum = (x) => x.slice(-divBars).reduce((s, v) => s + v, 0);
  const ma = cum(ra), mbv = cum(rb);
  const moved = Math.abs(ma) > 0.002 && Math.abs(mbv) > 0.002;
  const divergence = moved && base != null && ((base >= 0.5 && Math.sign(ma) !== Math.sign(mbv)) || (base <= -0.5 && Math.sign(ma) === Math.sign(mbv)));
  return { insufficient: false, n: ra.length, r: r2(r), base: base == null ? null : r2(base), recent: rr == null ? null : r2(rr), strength, sign: r >= 0 ? 'positive' : 'negative', breakdown, divergence, move: { a: r2(ma * 100), b: r2(mbv * 100) } };
}

/* ───────── light reading for one moment (replay / multi-TF): uses only the candles it is given ───────── */
export function quickBiasOf(candles) {
  if (!candles || candles.length < 210) return null;
  const closes = candles.map((x) => x.close); const last = closes.length - 1; const p = closes[last];
  const e50 = ema(closes, 50)[last], e200 = ema(closes, 200)[last]; const rs = rsi(closes, 14)[last]; const M = macd(closes);
  const trend = p > e50 && e50 > e200 ? 1 : p < e50 && e50 < e200 ? -1 : p > e200 ? 0.4 : -0.4;
  const h = M.hist.at(-1);
  return clamp(trend * 0.5 + (Number.isFinite(rs) ? clamp((rs - 50) / 20, -1, 1) * 0.25 : 0) + (Number.isFinite(h) ? Math.sign(h) * 0.25 : 0), -1, 1);
}
