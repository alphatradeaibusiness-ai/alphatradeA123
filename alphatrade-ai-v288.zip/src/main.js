import './styles/base.css';
import { cssVar } from './utils/cssVars.js';
import './styles/login.css';
import './styles/phone.css';
import './styles/dashboard.css';
import './styles/motion.css';
import './styles/fx.css';
import './styles/tools.css';
import './styles/drawer.css';
import './styles/refresh.css';
import './styles/sidebar.css';
import './styles/human.css';
import './styles/terminal.css';   // v265 terminal polish (loaded last, appearance only)
import { applyDocumentLang, onLangChange } from './i18n/index.js';
import { store } from './state/store.js';
import { auth } from './services/auth/index.js';
import { startRouter, render } from './router.js';
import { recordVersion } from './services/strategyVersions.js';
import { replayClass } from './utils/motion.js';
import { startErrorReports } from './services/errorReport.js';
import { rememberReferral } from './services/members.js';
import { startPrivacyScreen } from './services/privacy.js';

async function boot() {
  if (import.meta.env?.PROD) startErrorReports();
  rememberReferral();   // invite links: #/signup?ref=CODE
  startPrivacyScreen(); // cover the app in the app switcher / when it leaves the screen
  applyDocumentLang();
  document.documentElement.dataset.theme = store.get('theme');
  document.documentElement.dataset.palette = 'aurora';
  // v230: read the chart colours once now, while the page is still empty (cheap), instead of after the app is built.
  for (const n of ['--a0-rgb', '--a1-rgb', '--a3-rgb', '--a0', '--purple-3', '--a-tint', '--a-tint2']) cssVar(n);
  const root = document.getElementById('app');
  try {
    await auth.init();
  } catch (err) {
    console.error('Auth initialisation failed', err);
  }
  // A language switch re-renders the current screen in the new direction (state is kept in the store).
  onLangChange(() => {
    document.querySelector('.toasts')?.replaceChildren();
    render({ force: true });
    replayClass(root, 'lang-swap');   // v230: restarted on the next frame, no forced layout of the whole app
  });
  // Re-check the route when the session changes (e.g. sign-out in another tab via Firebase).
  // Only signing in/out changes the route; profile edits (name) must not re-render the page.
  let signedIn = Boolean(auth.current());
  // v255 partner links: remember the code, count the click; link the account on the server once signed in
  import('./services/partnerRef.js').then((m) => { m.captureReferral(); if (signedIn) m.attachReferral(); }).catch(() => {});
  const gate = (fresh = false) => import('./services/partnerGate.js').then((m) => m.refreshPartnerGate({ signedIn, fresh })).catch(() => {});
  gate(); document.addEventListener('visibilitychange', () => { if (!document.hidden) gate(); });
  auth.onChange((u) => { if (Boolean(u) !== signedIn) { signedIn = Boolean(u); render(); if (signedIn) import('./services/partnerRef.js').then((m) => m.attachReferral()).catch(() => {}); gate(true); } });
  startRouter(root);
}

// Pause looping animations while the tab is hidden or the page is scrolling.
{
  const html = document.documentElement;
  let scrollTimer = null;
  const sync = () => html.classList.toggle('fx-paused', document.hidden || scrollTimer !== null);
  document.addEventListener('visibilitychange', sync);
  sync();
  window.addEventListener('scroll', () => {
    if (scrollTimer === null) { scrollTimer = 0; sync(); }
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => { scrollTimer = null; sync(); }, 180);
  }, { passive: true });
}

// Looping decorations only run where they can be seen: cards scrolled out of view pause their animations and
// resume the moment they come back (the closed side menu is paused in CSS). Nothing is removed.
if (typeof IntersectionObserver === 'function') {
  const SEL = '.card, .market-card, .signal-bar';
  const tracked = new Set();
  const io = new IntersectionObserver((entries) => {
    for (const e of entries) e.target.classList.toggle('fx-off', !e.isIntersecting);
  }, { rootMargin: '120px 0px' });
  const visit = (node, fn) => {
    if (node.nodeType !== 1) return;
    if (node.matches(SEL)) fn(node);
    node.querySelectorAll(SEL).forEach(fn);
  };
  const add = (node) => {
    if (!tracked.has(node) && node.isConnected) { tracked.add(node); io.observe(node); }
  };
  const remove = (node) => {
    if (!node.isConnected && tracked.delete(node)) io.unobserve(node);
  };
  new MutationObserver((records) => {
    for (const record of records) {
      record.removedNodes.forEach((node) => visit(node, remove));
      record.addedNodes.forEach((node) => visit(node, add));
    }
  }).observe(document.body, { childList: true, subtree: true });
  visit(document.body, add);
}

// Strategy versioning: the settings in use are version-stamped at start and after every trading-relevant change (2 s after the last edit).
{
  let tm = 0;
  recordVersion(store.get('settings'));
  store.on('settings', (v) => { clearTimeout(tm); tm = setTimeout(() => recordVersion(v), 2000); });
}

boot();

// Service worker for signal notifications (with the logo). Not available on plain http (except localhost).
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js', { updateViaCache: 'none' }).catch(() => {});
