// v252 AI Trading Mentor Marketplace — dashboard layout (live market strip, mentor hero with chat + quick actions,
// mentor marketplace, community leaderboard, personal goals). Each mentor has its own specialization, personality and
// teaching method; the persona's system prompt is built on the SERVER from the mentor id (config/mentors.js) with the same
// plan / allowance checks as every AI feature. Mentors teach — no personal financial advice, no profit promises.
// Conversations and goals stay in this browser only. Portraits are original drawings, not photos of real people.
import { h, esc, fmtNum } from '../utils/dom.js';
import { icons } from '../components/icons.js';
import { getLang } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { aiPost, apiRequest } from '../services/ai/gateway.js';
import { toast } from '../components/ui.js';
import { getTickers } from '../services/market/index.js';
import { auth } from '../services/auth/index.js';
import { MENTORS } from '../config/mentors.js';
import { whileMounted, onUnmount } from './tools/common.js';
import { roomErr } from './rooms.js';
import { conversation, stopSpeaking, voiceSupported, spokenText } from '../services/voice.js';
import '../styles/rooms.css';
import '../styles/mentorcall.css';

const L = (ar, en) => tx({ ar, en });
const LEVEL = { beginner: ['مبتدئ', 'Beginner'], intermediate: ['متوسط', 'Intermediate'], advanced: ['متقدّم', 'Advanced'] };
const MK = { crypto: ['كريبتو', 'Crypto'], forex: ['فوركس', 'Forex'], metal: ['معادن', 'Metals'], index: ['مؤشرات', 'Indices'] };
const TICK = [['BTCUSDT', 'BTC/USD', '₿'], ['ETHUSDT', 'ETH/USD', 'Ξ'], ['SOLUSDT', 'SOL/USD', '◎'], ['BNBUSDT', 'BNB/USD', 'B']];
const PHONE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/></svg>';
// v280: each mentor's own call voice (pitch / speed / which of the device's voices for the language).
const VOICE = { 'sara-smc': { pitch: 1.12, rate: 1, pick: 0 }, 'khaled-gold': { pitch: 0.82, rate: 0.95, pick: 1 }, 'leo-crypto': { pitch: 1.05, rate: 1.08, pick: 2 }, 'nora-macro': { pitch: 1.2, rate: 1, pick: 3 }, 'omar-risk': { pitch: 0.9, rate: 0.96, pick: 4 }, 'zen-mind': { pitch: 0.96, rate: 0.9, pick: 5 } };
const KEY = (id) => `ata:mentor:${id}`;
const store = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ } } };
const loadChat = (id) => store.get(KEY(id), []).slice(-30);
const saveChat = (id, l) => store.set(KEY(id), l.slice(-30));
const STARTERS = {
  'sara-smc': [['وين السيولة على الشارت؟', 'Where is the liquidity on a chart?'], ['شو الفرق بين BOS و CHoCH؟', 'BOS vs CHoCH?']],
  'khaled-gold': [['كيف أحسب حجم صفقة على الذهب؟', 'How do I size a gold trade?'], ['ليش الذهب بيتأثر بالدولار؟', 'Why does the dollar move gold?']],
  'leo-crypto': [['كيف أعرف الاختراق الحقيقي؟', 'How to tell a real breakout?'], ['شو خطر الرافعة؟', 'What are leverage risks?']],
  'nora-macro': [['كيف أتداول وقت الأخبار بأمان؟', 'Trading news safely?'], ['شو تأثير الفائدة على الأزواج؟', 'How do rates move FX pairs?']],
  'omar-risk': [['حساب 1000$، كم أخاطر بالصفقة؟', '$1000 account — how much risk per trade?'], ['شو يعني التوقع بالـR؟', 'What is expectancy in R?']],
  'zen-mind': [['خسرت 3 صفقات ورا بعض، شو أعمل؟', 'Lost 3 in a row — what now?'], ['كيف أراجع صفقة صح؟', 'How to review a trade properly?']],
};
const QUICK = [
  ['bars', 'حلّل السوق', 'Analyze market', (m) => L(`علّمني كيف أقرأ السوق هلّق بأسلوبك (${tx(m.spec)}). هاي أسعار حقيقية من المنصة: {px}. اشرحلي شو بشوف وشو بنتبه له، بدون توصية.`, `Teach me how to read the market right now in your style (${tx(m.spec)}). Real prices from the platform: {px}. Explain what to look at and watch for — no recommendation.`)],
  ['crosshair', 'لاقي فرصة', 'Find opportunity', () => L('علّمني خطوة بخطوة كيف أدوّر على فرصة تداول حسب طريقتك، وشو الشروط اللي لازم تتحقق قبل ما أفكر أدخل.', 'Teach me step by step how to look for a setup your way, and which conditions must be true before I even consider entering.')],
  ['shield', 'إدارة المخاطر', 'Manage risk', () => L('ساعدني أبني خطة إدارة مخاطر: نسبة المخاطرة بالصفقة، حد الخسارة اليومي، وحجم الصفقة. اسألني عن حجم حسابي إذا بدك.', 'Help me build a risk plan: risk per trade, daily loss limit and position sizing. Ask me my account size if needed.')],
  ['plus', 'صفقة جديدة', 'New trade', () => L('بدي أخطط لصفقة جديدة. اعطيني قائمة فحص قبل الدخول (الاتجاه، الدخول، الوقف، الهدف، نسبة العائد للمخاطرة) واسألني عنها وحدة وحدة.', 'I want to plan a new trade. Give me a pre-entry checklist (bias, entry, stop, target, R:R) and ask me each item one by one.')],
];

/** An original mentor portrait (vector, no photo): glowing ring, silhouette, chart line. */
function portrait(m, size = 150) {
  const id = `mg${m.id.replace(/\W/g, '')}${size}`;
  return `<svg class="mk-portrait" viewBox="0 0 160 160" width="${size}" height="${size}" role="img" aria-label="${esc(tx(m.name))}">
    <defs><radialGradient id="${id}b" cx="50%" cy="38%" r="65%"><stop offset="0" stop-color="hsl(${m.hue} 80% 32%)"/><stop offset="1" stop-color="#050b1f"/></radialGradient>
      <linearGradient id="${id}r" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22d3ee"/><stop offset=".5" stop-color="hsl(${m.hue} 90% 62%)"/><stop offset="1" stop-color="#a855f7"/></linearGradient>
      <linearGradient id="${id}p" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="hsl(${m.hue} 70% 70%)"/><stop offset="1" stop-color="hsl(${m.hue} 60% 35%)"/></linearGradient></defs>
    <circle cx="80" cy="80" r="74" fill="url(#${id}b)"/>
    <polyline points="22,104 42,96 56,100 72,84 88,90 104,70 120,76 138,56" fill="none" stroke="#22d3ee" stroke-width="1.6" opacity=".55"/>
    <circle cx="80" cy="66" r="25" fill="url(#${id}p)"/><path d="M34 140c4-27 22-40 46-40s42 13 46 40" fill="url(#${id}p)"/>
    <text x="80" y="72" text-anchor="middle" font-size="16" font-weight="800" fill="#06102a" font-family="system-ui">${esc(m.initials)}</text>
    <circle cx="80" cy="80" r="74" fill="none" stroke="url(#${id}r)" stroke-width="4"/></svg>`;
}

export function renderMentors() {
  const me = auth.current?.() || null; const first = String(me?.name || me?.displayName || '').split(/\s+/)[0];
  let cur = store.get('ata:mentor:current', MENTORS[0].id); if (!MENTORS.some((m) => m.id === cur)) cur = MENTORS[0].id;
  const root = h(`<section class="subpage tool cm rm mk page-enter">
    <div class="mk-ticks" data-ticks>${TICK.map(([s, n, g]) => `<div class="mk-tick" data-s="${s}"><span class="mk-tick-i">${g}</span><div><small>${n}</small><b>—</b></div><em></em></div>`).join('')}</div>
    <section class="mk-hero" data-hero></section>
    <section class="mk-chat" data-chat hidden></section>
    <section class="mk-sec">
      <div class="mk-sec-h"><h2>${icons.face} ${L('سوق المرشدين', 'Mentor marketplace')}</h2>
        <div class="mk-filters"><select class="input input-sm" data-f="level"><option value="">${L('كل المستويات', 'All levels')}</option>${Object.entries(LEVEL).map(([k, v]) => `<option value="${k}">${esc(L(...v))}</option>`).join('')}</select>
        <select class="input input-sm" data-f="market"><option value="">${L('كل الأسواق', 'All markets')}</option>${Object.entries(MK).map(([k, v]) => `<option value="${k}">${esc(L(...v))}</option>`).join('')}</select></div></div>
      <div class="mk-grid" data-list></div>
    </section>
    <div class="mk-bottom">
      <section class="mk-sec mk-comm"><div class="mk-sec-h"><h2>${icons.trophy} ${L('مجتمع المتداولين', 'Trader community')}</h2>
        <select class="input input-sm" data-per><option value="week">${L('هالأسبوع', 'This week')}</option><option value="month">${L('هالشهر', 'This month')}</option></select></div>
        <p class="mk-sub">${L('أنشط غرف التداول ودقة توقعاتها، محسوبة على السيرفر من نتائج حقيقية.', 'Most active trading rooms and their prediction accuracy — computed on the server from real results.')}</p>
        <div data-lb><p class="mk-sub">${L('عم نحمّل الترتيب…', 'Loading the ranking…')}</p></div></section>
      <section class="mk-sec mk-goals"><div class="mk-sec-h"><h2>${icons.crosshair} ${L('أهدافك', 'Your goals')}</h2><button type="button" class="mk-link" data-addgoal>${icons.plus} ${L('هدف جديد', 'New goal')}</button></div>
        <div data-goals></div></section>
    </div>
  </section>`);
  const $ = (s) => root.querySelector(s);
  let tickers = {};
  const mentor = () => MENTORS.find((m) => m.id === cur);

  /* ── live strip ── */
  async function loadTicks() {
    try { tickers = await getTickers(TICK.map((t) => t[0])); } catch { return; }
    for (const [s] of TICK) { const t = tickers[s]; const el = root.querySelector(`[data-s="${s}"]`); if (!el || !t || t.price == null) continue;
      el.querySelector('b').textContent = fmtNum(t.price, t.price > 100 ? 2 : 4); const e = el.querySelector('em');
      e.textContent = t.mode === 'demo' ? L('تجريبي', 'demo') : `${t.changePct >= 0 ? '+' : ''}${(+t.changePct || 0).toFixed(2)}%`; e.className = t.mode === 'demo' ? '' : t.changePct >= 0 ? 'up' : 'down'; }
  }

  /* ── hero ── */
  function hero() {
    const m = mentor(); const name = tx(m.name); const short = name.split(/\s+[—-]\s+/)[0];
    $('[data-hero]').innerHTML = `<div class="mk-hero-glow" style="--h:${m.hue}"></div>
      <div class="mk-hero-g">
        <div class="mk-hero-t"><small>${first ? L(`أهلاً ${esc(first)}، أنا`, `Hi ${esc(first)}, I'm`) : L('أهلاً، أنا', 'Hi, I am')}</small>
          <h1>${esc(short)} <span>AI</span></h1><p>${esc(tx(m.spec))}<br>${L('مرشدك للتعلّم، معك 24/7.', 'Your learning mentor, with you 24/7.')}</p></div>
        <div class="mk-hero-p">${portrait(m, 170)}<span class="mk-live">● ${L('مباشر', 'LIVE')}</span></div>
        <div class="mk-hero-c"><p>${L('السوق ما بينام.<br>وأنا دايمًا هون إلك.', 'The market never sleeps.<br>I am always here for you.')}</p>
          <ul><li>${icons.check} ${L('بحلّل معك', 'I analyze with you')}</li><li>${icons.check} ${L('بعلّمك', 'I teach')}</li><li>${icons.check} ${L('بحميك من المخاطر', 'I protect you from risk')}</li><li>${icons.check} ${L('بطوّرك', 'I help you grow')}</li></ul>
          <span class="mk-on">● ${L('متاح 24/7', 'Available 24/7')}</span></div>
      </div>
      <form class="mk-ask" data-ask>${icons.sparkle}<input name="q" maxlength="3000" autocomplete="off" placeholder="${esc(L(`احكي مع ${name}…`, `Talk with ${name}…`))}">${voiceSupported() ? `<button type="button" class="mk-callbtn" data-call="${m.id}" aria-label="${esc(L(`مكالمة صوتية مع ${short}`, `Voice call with ${short}`))}">${PHONE}<span>${L('مكالمة', 'Call')}</span></button>` : ''}<button aria-label="send">${icons.send}</button></form>
      <div class="mk-quick">${QUICK.map(([ic, a, b], i) => `<button type="button" data-q="${i}">${icons[ic]}<span>${esc(L(a, b))}</span></button>`).join('')}</div>
      <div class="mk-switch">${MENTORS.map((x) => `<button type="button" class="${x.id === cur ? 'is-on' : ''}" data-pick="${x.id}" title="${esc(tx(x.name))}">${portrait(x, 38)}<span>${esc(tx(x.name).split(' ')[0])}</span></button>`).join('')}</div>`;
    const f = $('[data-ask]'); f.addEventListener('submit', (e) => { e.preventDefault(); const q = f.q.value; f.q.value = ''; ask(q); });
  }
  root.addEventListener('click', (e) => {
    const p = e.target.closest('[data-pick]'); const q = e.target.closest('[data-q]'); const t = e.target.closest('[data-talk]'); const r = e.target.closest('[data-room]');
    if (p || t) { cur = (p || t).dataset.pick || t.dataset.talk; store.set('ata:mentor:current', cur); hero(); draw(); openChat(); if (t) $('[data-hero]').scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    if (q) { const m = mentor(); const px = TICK.map(([s, n]) => (tickers[s]?.price && tickers[s].mode !== 'demo' ? `${n} ${fmtNum(tickers[s].price, 2)} (${(+tickers[s].changePct || 0).toFixed(2)}%/24h)` : null)).filter(Boolean).join('، ') || L('غير متاحة هلّق', 'not available now');
      ask(QUICK[+q.dataset.q][3](m).replace('{px}', px)); }
    if (r) addToRoom(r.dataset.room);
    const c = e.target.closest('[data-call]'); if (c) startCall(c.dataset.call);
  });

  /* ── chat ── */
  let busy = false;
  function openChat() {
    const m = mentor(); const msgs = loadChat(m.id); const c = $('[data-chat]'); c.hidden = false;
    c.innerHTML = `<div class="mk-chat-h">${portrait(m, 40)}<div><b>${esc(tx(m.name))}</b><small>${esc(tx(m.method))}</small></div><button type="button" class="btn btn-sm btn-ghost" data-clear title="${esc(L('امسح', 'Clear'))}">${icons.trash}</button><button type="button" class="btn btn-sm btn-ghost" data-close>${icons.close}</button></div>
      <ol class="rm-msgs" data-msgs>${msgs.map((x) => `<li class="rm-msg${x.role === 'user' ? ' is-mine' : ' is-ai'}"><div class="rm-bubble"><div class="rm-text">${esc(x.content).replace(/\n/g, '<br>')}</div></div></li>`).join('') || `<li class="rm-msg is-sys"><span>${L('ابدأ بسؤال، أو اختار من الاقتراحات.', 'Start with a question — or pick a suggestion.')}</span></li>`}${busy ? '<li class="rm-msg is-ai"><div class="rm-bubble"><span class="spinner"></span></div></li>' : ''}</ol>
      <div class="rm-starters">${(STARTERS[m.id] || []).map(([a, b]) => `<button type="button" class="btn btn-sm btn-ghost" data-st>${esc(L(a, b))}</button>`).join('')}</div>
      <p class="mk-sub">${icons.info} ${L('تعليم بس، مش نصيحة مالية ولا وعود أرباح. المحادثة محفوظة على هالجهاز بس، وجواب الذكاء الاصطناعي ممكن يغلط.', 'Education only — no financial advice or profit promises. Saved on this device only; AI answers can be wrong.')}</p>`;
    const box = c.querySelector('[data-msgs]'); box.scrollTop = box.scrollHeight;
  }
  $('[data-chat]').addEventListener('click', (e) => {
    if (e.target.closest('[data-st]')) ask(e.target.closest('[data-st]').textContent);
    if (e.target.closest('[data-close]')) $('[data-chat]').hidden = true;
    if (e.target.closest('[data-clear]')) { saveChat(cur, []); openChat(); draw(); }
  });
  async function ask(text, { voice = false } = {}) {
    if (busy || !String(text).trim()) return ''; const id = cur; const msgs = loadChat(id); let reply = '';
    msgs.push({ role: 'user', content: String(text).trim() }); saveChat(id, msgs); busy = true; openChat(); if (!voice) $('[data-chat]').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    try { const r = await aiPost('/mentor', { mentor: id, messages: msgs.slice(-12), lang: getLang(), ...(voice ? { voice: true } : {}) }, { timeoutMs: 90000 }); reply = r.reply; msgs.push({ role: 'assistant', content: r.reply }); saveChat(id, msgs); bumpWeek(); }
    catch (x) { msgs.pop(); saveChat(id, msgs); if (voice) { busy = false; throw x; } toast(roomErr(x), 'error'); }
    busy = false; if (cur === id) openChat(); draw(); goals(); return reply;
  }

  /* ── v280 voice call: talk to the mentor hands-free (listen → mentor answers aloud → listen again) ── */
  let call = null; let callT0 = 0; let callTimer = null;
  const box = h(`<div class="mk-callbox" data-callbox hidden role="dialog" aria-modal="false" aria-live="polite"><div class="mk-callcard-in">
      <div class="mk-call-p" data-cp></div><b class="mk-call-n" data-cn></b><span class="mk-call-s" data-cs></span><small class="mk-call-t" data-ct>00:00</small>
      <p class="mk-call-h" data-ch dir="auto"></p>
      <button type="button" class="mk-call-end" data-end aria-label="${esc(L('إنهاء المكالمة', 'End call'))}">${PHONE}<span>${L('إنهاء', 'End')}</span></button>
      <small class="mk-call-note">${L('تعليم بس، مش نصيحة مالية. الصوت بيتحوّل لنص بالمتصفح، وما بنحفظ أي تسجيل.', 'Education only, not financial advice. Speech is turned into text by the browser; no recording is stored.')}</small></div></div>`);
  root.append(box);
  const CS = { listen: ['بسمعك… احكي', 'Listening… go ahead'], think: ['عم يفكّر…', 'Thinking…'], speak: ['عم يحكي…', 'Speaking…'] };
  const WHY = { 'not-allowed': ['المايك مسكّر. اسمح للموقع يستعمل المايك من إعدادات المتصفح.', 'The microphone is blocked. Allow it for this site in the browser settings.'], 'service-not-allowed': ['المتصفح منع التعرّف على الصوت.', 'The browser blocked speech recognition.'], 'audio-capture': ['ما في مايك شغّال على هالجهاز.', 'No working microphone was found.'], unsupported: ['هالمتصفح ما بيدعم المكالمات الصوتية. جرّب Chrome أو Safari.', 'This browser does not support voice calls. Try Chrome or Safari.'], idle: ['سكّرت المكالمة لأنه ما في صوت من دقيقة.', 'Call ended after a minute of silence.'], error: ['صار خطأ بالمكالمة، جرّب كمان مرة.', 'The call hit an error, try again.'] };
  const mmss = (ms) => { const s = Math.floor(ms / 1000); return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };
  function endUi(why) {
    clearInterval(callTimer); call = null; box.dataset.state = 'off'; root.classList.remove('is-calling');
    if (why && WHY[why]) { box.querySelector('[data-cs]').textContent = L(...WHY[why]); box.querySelector('[data-ch]').textContent = ''; setTimeout(() => { if (!call) box.hidden = true; }, 5000); }
    else box.hidden = true;
  }
  function startCall(id) {
    if (call) { call.stop(); if (id === cur) return; }
    if (!MENTORS.some((m) => m.id === id)) return;
    cur = id; store.set('ata:mentor:current', cur); hero(); draw(); openChat();
    const m = mentor(); const short = tx(m.name).split(/\s+[—-]\s+/)[0];
    box.style.setProperty('--h', m.hue); box.querySelector('[data-cp]').innerHTML = portrait(m, 120); box.querySelector('[data-cn]').textContent = short;
    box.querySelector('[data-ch]').textContent = ''; box.hidden = false; root.classList.add('is-calling');
    stopSpeaking(); callT0 = Date.now(); box.querySelector('[data-ct]').textContent = '00:00';
    clearInterval(callTimer); callTimer = setInterval(() => { box.querySelector('[data-ct]').textContent = mmss(Date.now() - callT0); }, 1000);
    call = conversation(getLang, {
      voice: VOICE[id] || {},
      onAsk: async (q) => { try { return spokenText(await ask(q, { voice: true })); } catch (x) { toast(roomErr(x), 'error'); call?.stop(); return ''; } },
      onHeard: (t) => { box.querySelector('[data-ch]').textContent = t; },
      onState: (s, d) => {
        if (s === 'off') { endUi(d); return; }
        box.dataset.state = s; box.querySelector('[data-cs]').textContent = L(...CS[s]);
        if (s === 'listen') box.querySelector('[data-ch]').textContent = '';
        if (s === 'speak' && d) box.querySelector('[data-ch]').textContent = String(d).slice(0, 220);
      },
    });
  }
  box.querySelector('[data-end]').addEventListener('click', () => { if (call) call.stop(); else endUi(null); });
  onUnmount(root, () => { call?.stop(); clearInterval(callTimer); });

  /* ── marketplace ── */
  const f = { level: '', market: '' };
  function draw() {
    $('[data-list]').innerHTML = MENTORS.filter((m) => (!f.level || m.level === f.level) && (!f.market || m.markets.includes(f.market))).map((m) => { const n = Math.ceil(loadChat(m.id).length / 2);
      return `<article class="mk-card rm-mentor${m.id === cur ? ' is-on' : ''}" style="--h:${m.hue}">
        <div class="mk-card-top">${portrait(m, 56)}<div><h3>${esc(tx(m.name))}</h3><p>${esc(tx(m.spec))}</p></div></div>
        <p class="mk-card-d"><b>${L('طريقة التعليم', 'Method')}:</b> ${esc(tx(m.method))}</p><p class="mk-card-d"><b>${L('الشخصية', 'Personality')}:</b> ${esc(tx(m.personality))}</p>
        <div class="rm-badges"><span class="rm-badge">${esc(L(...LEVEL[m.level]))}</span>${m.markets.map((x) => `<span class="rm-badge">${esc(L(...MK[x]))}</span>`).join('')}${n ? `<span class="rm-badge is-role">${n} ${L('سؤال', 'questions')}</span>` : ''}</div>
        <div class="rm-card-a"><button type="button" class="btn btn-sm btn-primary" data-talk="${m.id}">${icons.chat}<span>${L('احكي معه', 'Talk')}</span></button>${voiceSupported() ? `<button type="button" class="btn btn-sm mk-callcard" data-call="${m.id}" aria-label="${esc(L(`مكالمة صوتية مع ${tx(m.name).split(/\s+[—-]\s+/)[0]}`, `Voice call with ${tx(m.name).split(/\s+[—-]\s+/)[0]}`))}">${PHONE}<span>${L('مكالمة', 'Call')}</span></button>` : ''}<button type="button" class="btn btn-sm" data-room="${m.id}">${icons.plus}<span>${L('ضيفه لغرفتي', 'Add to my room')}</span></button></div>
      </article>`; }).join('') || `<p class="mk-sub">${L('ما في مرشد بهالفلتر.', 'No mentor matches.')}</p>`;
  }
  root.querySelectorAll('[data-f]').forEach((s) => s.addEventListener('change', () => { f[s.dataset.f] = s.value; draw(); }));
  async function addToRoom(id) {
    try {
      const d = await apiRequest('GET', '/api/rooms'); const rooms = [...d.mine, ...d.managed.filter((r) => r.role === 'admin')];
      if (!rooms.length) return toast(L('لازم تكون مالك أو مشرف عام بغرفة. اعمل غرفة من "غرف التداول".', 'You need to own or admin a room. Create one in Trading rooms.'), 'error');
      const pick = rooms.length === 1 ? rooms[0] : rooms[Number(window.prompt(rooms.map((r, i) => `${i + 1}. ${r.name}`).join('\n'), '1')) - 1];
      if (!pick) return;
      await apiRequest('POST', `/api/rooms/${pick.id}/aiconfig`, { mentor: id }); toast(L(`المرشد انضم لـ ${pick.name}`, `Mentor added to ${pick.name}`), 'success');
    } catch (x) { toast(roomErr(x), 'error'); }
  }

  /* ── community (real room ranking) ── */
  async function board() {
    const el = $('[data-lb]');
    try {
      const d = await apiRequest('GET', `/api/rooms/leaderboard?period=${$('[data-per]').value}`, undefined, 15000);
      el.innerHTML = d.items.length ? `<ol class="mk-lb">${d.items.slice(0, 6).map((x, i) => `<li><span class="mk-rank${i < 3 ? ` is-${i + 1}` : ''}">${i + 1}</span><div><b>${esc(x.name)}</b><small>${x.active} ${L('نشطين', 'active')} · ${x.messages} ${L('رسالة', 'msgs')}</small></div><em>${x.accuracy != null ? `🎯 ${x.accuracy}%` : '—'}</em></li>`).join('')}</ol>`
        : `<p class="mk-sub">${L('لسا ما في غرف كفاية بالترتيب. اعمل غرفة وادعي أصحابك!', 'Not enough rooms ranked yet. Create one and invite friends!')}</p><a class="btn btn-sm" href="#/app/rooms">${icons.chat}<span>${L('غرف التداول', 'Trading rooms')}</span></a>`;
    } catch (x) { el.innerHTML = `<p class="mk-sub">${esc(roomErr(x))}</p>`; }
  }
  $('[data-per]').addEventListener('change', board);

  /* ── goals (this device) ── */
  const wk = () => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - d.getDay()); return d.getTime(); };
  function bumpWeek() { const s = store.get('ata:mentor:week', { w: 0, n: 0 }); const w = wk(); store.set('ata:mentor:week', { w, n: s.w === w ? s.n + 1 : 1 }); }
  function goals() {
    if (store.get('ata:goals', null) == null) store.set('ata:goals', [{ id: 'g1', name: L('صندوق الطوارئ', 'Emergency fund'), cur: 0, target: 1000, unit: '$' }, { id: 'g2', name: L('تعلّم إدارة المخاطر', 'Learn risk management'), cur: 0, target: 10, unit: L('درس', 'lessons') }]);
    const list = store.get('ata:goals', []);
    const s = store.get('ata:mentor:week', { w: 0, n: 0 }); const asked = s.w === wk() ? s.n : 0;
    const row = (g, auto = false) => { const pct = Math.max(0, Math.min(100, Math.round((g.cur / (g.target || 1)) * 100)));
      return `<div class="mk-goal"${auto ? '' : ` data-g="${esc(g.id)}"`}><div class="mk-goal-h"><b>${esc(g.name)}</b><span>${pct}%</span></div><div class="mk-bar"><i style="width:${pct}%"></i></div>
        <div class="mk-goal-f"><small>${fmtNum(g.cur, 0)} / ${fmtNum(g.target, 0)} ${esc(g.unit || '')}</small>${auto ? `<small>${L('تلقائي', 'automatic')}</small>` : `<span><button type="button" data-gi="-1">−</button><button type="button" data-gi="1">+</button><button type="button" data-gd>${icons.trash}</button></span>`}</div></div>`; };
    $('[data-goals]').innerHTML = row({ name: L('أسئلة للمرشدين هالأسبوع', 'Mentor questions this week'), cur: asked, target: 10, unit: '' }, true) + list.map((g) => row(g)).join('')
      + `<p class="mk-sub">${L('أهدافك محفوظة على هالجهاز بس.', 'Goals are saved on this device only.')}</p>`;
  }
  $('[data-goals]').addEventListener('click', (e) => {
    const g = e.target.closest('[data-g]'); if (!g) return; const list = store.get('ata:goals', []); const it = list.find((x) => x.id === g.dataset.g); if (!it) return;
    const inc = e.target.closest('[data-gi]'); if (inc) { const step = Math.max(1, Math.round(it.target / 20)); it.cur = Math.max(0, Math.min(it.target, it.cur + Number(inc.dataset.gi) * step)); }
    if (e.target.closest('[data-gd]')) list.splice(list.indexOf(it), 1);
    store.set('ata:goals', list); goals();
  });
  $('[data-addgoal]').addEventListener('click', () => {
    const name = window.prompt(L('اسم الهدف', 'Goal name')); if (!name) return; const target = Number(window.prompt(L('الرقم المطلوب', 'Target number'), '100')); if (!(target > 0)) return;
    const unit = window.prompt(L('الوحدة (مثلاً $ أو درس)', 'Unit (e.g. $ or lessons)'), '$') || '';
    const base = store.get('ata:goals', []);
    base.push({ id: `g${Date.now()}`, name: name.slice(0, 60), cur: 0, target, unit: unit.slice(0, 12) }); store.set('ata:goals', base.slice(-8)); goals();
  });

  hero(); draw(); goals(); loadTicks(); board();
  if (loadChat(cur).length) openChat();
  whileMounted(root, loadTicks, 15000);
  return root;
}
