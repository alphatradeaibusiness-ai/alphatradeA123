// v251 AI Trading Council + Market X-Ray + Scenario engine (the NEXUS core, merged into one page).
// Eight independent analytical agents read the same CLOSED candles; the synthesis keeps their disagreements (it is never
// forced to agree) and says NO TRADE when there is no clear majority or a high-impact event is close. X-Ray separates
// liquidity zones ESTIMATED from price action from REAL order-book walls (live depth, crypto only). Scenario probabilities
// come only from historical analogs on this asset, with the sample size; under 20 analogs no probability is shown.
// Pure computation in the browser (services/council.js) — no AI key is used and nothing is invented.
import { h, esc, fmtNum } from '../utils/dom.js';
import { icons, ii } from '../components/icons.js';
import { tx } from '../i18n/tx.js';
import { toast } from '../components/ui.js';
import { getHistory } from '../services/market/index.js';
import { fetchBinanceDepth } from '../services/market/binance.js';
import { getCalendar } from '../services/news.js';
import { INSTRUMENTS } from '../config/instruments.js';
import { TIMEFRAMES } from '../config/market.js';
import { runCouncil } from '../services/council.js';
import { dateStr } from './tools/common.js';
import { pageHead } from './community.js';
import '../styles/rooms.css';

const L = (ar, en) => tx({ ar, en });
const AG = {
  trend: [ii('crosshair'), 'وكيل الاتجاه', 'Trend agent'], liquidity: [ii('drop'), 'وكيل السيولة', 'Liquidity agent'], news: [ii('news'), 'وكيل الأخبار', 'News agent'], risk: [ii('shield'), 'وكيل المخاطر', 'Risk agent'],
  pattern: [ii('layers'), 'وكيل الأنماط', 'Pattern agent'], sentiment: [ii('pulse'), 'وكيل المعنويات (من السعر)', 'Sentiment agent (price proxy)'], execution: [ii('settings'), 'وكيل التنفيذ', 'Execution agent'], devil: [ii('flame'), 'محامي الشيطان', 'Devil’s advocate'],
};
const STANCE = { bullish: ['صاعد', 'Bullish', 'up'], bearish: ['هابط', 'Bearish', 'down'], neutral: ['محايد', 'Neutral', ''], caution: ['حذر', 'Caution', 'warn'], critic: ['ناقد', 'Critic', 'warn'] };
const ZK = { buy_side: ['سيولة فوق (تقدير)', 'Buy-side liquidity (est.)', '#f59e0b'], sell_side: ['سيولة تحت (تقدير)', 'Sell-side liquidity (est.)', '#38bdf8'], fvg_bull: ['فجوة صاعدة FVG', 'Bullish FVG', '#22c55e'], fvg_bear: ['فجوة هابطة FVG', 'Bearish FVG', '#ef4444'], wall_bid: ['جدار شراء (دفتر أوامر حقيقي)', 'Bid wall (real order book)', '#10b981'], wall_ask: ['جدار بيع (دفتر أوامر حقيقي)', 'Ask wall (real order book)', '#f43f5e'] };
const SC = { bull: ['سيناريو صاعد', 'Bullish'], bear: ['سيناريو هابط', 'Bearish'], range: ['تذبذب عرضي', 'Range'], volatile: ['تقلّب قوي', 'Volatility expansion'], liquidity: ['سحب سيولة', 'Liquidity grab'] };
const SYMS = INSTRUMENTS.filter((i) => ['crypto', 'metal', 'index', 'forex', 'energy'].includes(i.type)).map((i) => i.symbol);
const NEXUS = [['liquidity', 'flame', 'خريطة السيولة الحية', 'Live liquidity map'], ['risk', 'shield', 'مركز المخاطر', 'Risk centre'], ['journal', 'journal', 'يوميات التداول', 'Trading journal'], ['news', 'news', 'الأخبار والتقويم', 'News & calendar'], ['lab', 'flask', 'المختبر والاختبار', 'Lab & back-tests'], ['studio', 'fingerprint', 'DNA الاستراتيجية', 'Strategy DNA'], ['radar', 'radar', 'الرادار', 'Radar'], ['rooms', 'chat', 'غرف التداول', 'Trading rooms'], ['mentors', 'face', 'المرشدين', 'Mentors']];

function drawXray(cv, c, xr, layers, minStr) {
  const dpr = window.devicePixelRatio || 1; const W = cv.clientWidth || 700, H = cv.clientHeight || 360; cv.width = W * dpr; cv.height = H * dpr;
  const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
  const n = Math.min(c.length, Math.max(60, Math.floor((W - 70) / 6))); const off = c.length - n; const k = c.slice(off); const padR = 66;
  let lo = Math.min(...k.map((x) => x.low)), hi = Math.max(...k.map((x) => x.high)); const pad = (hi - lo) * 0.08; lo -= pad; hi += pad;
  const y = (p) => 8 + (1 - (p - lo) / (hi - lo)) * (H - 24); const bw = (W - padR) / n; const x = (i) => (i - off) * bw + bw / 2;
  const dig = hi > 1000 ? 1 : hi > 10 ? 2 : 4;
  const zs = xr.zones.filter((z) => z.strength >= minStr && layers.has(z.source === 'order_book' ? 'book' : z.kind.startsWith('fvg') ? 'fvg' : 'liq') && z.hi > lo && z.lo < hi);
  for (const z of zs) { const col = ZK[z.kind]?.[2] || '#888'; g.globalAlpha = 0.1 + 0.4 * z.strength; g.fillStyle = col; const t = y(Math.min(hi, z.hi)), b = y(Math.max(lo, z.lo)); g.fillRect(0, t, W - padR, Math.max(2, b - t)); g.globalAlpha = 1;
    if (z.source === 'order_book') { g.strokeStyle = col; g.setLineDash([3, 3]); g.strokeRect(0, t, W - padR, Math.max(2, b - t)); g.setLineDash([]); } }
  g.strokeStyle = getComputedStyle(cv).getPropertyValue('--border') || 'rgba(255,255,255,.08)'; g.fillStyle = getComputedStyle(cv).getPropertyValue('--text-3') || '#888'; g.font = '10.5px ui-monospace, monospace';
  for (let s = 0; s <= 5; s++) { const p = lo + ((hi - lo) * s) / 5; g.beginPath(); g.moveTo(0, y(p)); g.lineTo(W - padR, y(p)); g.stroke(); g.fillText(p.toFixed(dig), W - padR + 4, y(p) + 3); }
  k.forEach((q, j) => { const i = j + off; const up = q.close >= q.open; g.strokeStyle = g.fillStyle = up ? '#22c55e' : '#ef4444'; g.beginPath(); g.moveTo(x(i), y(q.high)); g.lineTo(x(i), y(q.low)); g.stroke(); const t = y(Math.max(q.open, q.close)); g.fillRect(x(i) - bw * 0.35, t, Math.max(1, bw * 0.7), Math.max(1, y(Math.min(q.open, q.close)) - t)); });
  if (layers.has('sweeps')) {
    for (const s of [...xr.sweeps.map((v) => ({ ...v, t: 'S' })), ...xr.falseBreaks.map((v) => ({ ...v, t: 'F' }))]) { if (s.i < off) continue; g.fillStyle = s.t === 'S' ? '#eab308' : '#a78bfa'; g.font = 'bold 11px system-ui'; g.fillText(s.t === 'S' ? '⚡' : '✕', x(s.i) - 4, s.side === 'up' || s.side === 'buy_side' ? y(c[s.i].high) - 6 : y(c[s.i].low) + 14); }
  }
  const px = xr.price; g.fillStyle = '#7c5cff'; g.fillRect(W - padR, y(px) - 8, padR, 16); g.fillStyle = '#fff'; g.font = '10.5px ui-monospace, monospace'; g.fillText(px.toFixed(dig), W - padR + 4, y(px) + 4);
}

export function renderCouncil() {
  const root = h(`<section class="subpage tool cm rm cn page-enter">${pageHead('layers', L('مجلس AI وأشعة السوق', 'AI council & market X-Ray'), L('8 وكلاء تحليل مستقلين على نفس الشموع المسكّرة، مع الخلافات بينهم، خريطة سيولة، وسيناريوهات من حالات تاريخية مشابهة. كل رقم محسوب، ولا شي مخترع.', '8 independent analysis agents on the same closed candles, their disagreements, a liquidity map and scenarios from similar historical cases. Every number is computed — nothing is invented.'))}
    <nav class="cn-nexus">${NEXUS.map(([id, ic, a, b]) => `<a href="#/app/${id}" class="cn-nx">${icons[ic]}<span>${esc(L(a, b))}</span></a>`).join('')}</nav>
    <form class="card cn-bar" data-f><select class="input" name="symbol">${SYMS.map((s) => `<option${s === 'BTCUSDT' ? ' selected' : ''}>${s}</option>`).join('')}</select>
      <select class="input" name="tf">${['15m', '1h', '4h', '1D'].map((s) => `<option${s === '1h' ? ' selected' : ''}>${s}</option>`).join('')}</select>
      <button class="btn btn-primary">${icons.brain}<span>${L('شغّل المجلس', 'Run the council')}</span></button><span class="muted" data-meta></span></form>
    <div class="tool-body" data-out><p class="muted">${L('اختار السوق والفريم واضغط "شغّل المجلس".', 'Pick a market and timeframe, then “Run the council”.')}</p></div></section>`);
  const out = root.querySelector('[data-out]'); const f = root.querySelector('[data-f]');
  let state = null; const layers = new Set(['liq', 'fvg', 'book', 'sweeps']); let minStr = 0.2;
  const ev = (e) => `<li class="cn-ev is-${e.for}">${{ up: ii('trend'), down: ii('trend'), risk: ii('alert'), info: ii('info') }[e.for] || ''} ${esc(tx(e))}${e.from ? ` <small class="muted">— ${esc(L(AG[e.from]?.[1], AG[e.from]?.[2]))}</small>` : ''}</li>`;
  async function run() {
    const symbol = f.symbol.value, tf = f.tf.value; out.innerHTML = '<div class="perf-loading"><span class="spinner"></span></div>';
    try {
      const inst = INSTRUMENTS.find((i) => i.symbol === symbol); const sec = TIMEFRAMES.find((x) => x.id === tf)?.seconds || 3600;
      const [hist, cal, depth] = await Promise.all([getHistory(symbol, tf, 600), getCalendar().catch(() => ({ events: [] })), inst?.provider === 'binance' ? fetchBinanceDepth(symbol, 500).catch(() => null) : Promise.resolve(null)]);
      const c = hist.candles.filter((k) => (k.time + sec) * 1000 <= Date.now());
      const asset = inst?.type === 'metal' ? 'metal' : inst?.type || 'crypto';
      const res = runCouncil({ candles: c, symbol, tf, asset, events: cal.events || [], depth, now: Date.now() });
      if (res.error) { out.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${L('شموع قليلة للتحليل (أقل من 120).', 'Too few candles (under 120).')}</div></div>`; return; }
      state = { res, c, symbol, tf, mode: hist.mode, depth: Boolean(depth), calOk: Array.isArray(cal.events) && cal.events.length > 0 };
      root.querySelector('[data-meta]').textContent = `${c.length} ${L('شمعة مسكّرة', 'closed candles')} · ${hist.mode === 'demo' ? L('بيانات تجريبية', 'demo data') : (hist.source?.name || hist.source || '')} · ${dateStr(Date.now())}`;
      paint();
    } catch (x) { out.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(String(x?.message || x))}</div></div>`; }
  }
  function paint() {
    const { res, c } = state; const s = res.synthesis; const v = { bullish: ['ميل صاعد', 'Bullish lean', 'up'], bearish: ['ميل هابط', 'Bearish lean', 'down'], no_trade: ['NO TRADE — لا صفقة', 'NO TRADE', 'warn'] }[s.view];
    const why = { news: L('خبر قوي قريب', 'High-impact news is close'), no_majority: L('ما في أغلبية واضحة بين الوكلاء', 'No clear majority among agents'), conflict: L('الوكلاء منقسمين بقوة', 'Agents strongly split') }[s.why] || '';
    const an = res.analogs; const dig = res.price > 1000 ? 1 : res.price > 10 ? 2 : 4;
    out.innerHTML = `
      ${state.mode === 'demo' ? `<div class="alert alert-error">${icons.alert}<div>${L('بيانات تجريبية، التحليل للتجربة بس.', 'Demo data — for trying out only.')}</div></div>` : ''}
      <div class="card rm-sec cn-syn is-${v[2]}"><h2>${icons.brain} ${L('خلاصة المجلس', 'Council synthesis')}: <b>${esc(L(v[0], v[1]))}</b></h2>
        ${why ? `<p class="muted">${esc(why)}</p>` : ''}
        <div class="cn-tally"><span>${L('موافقين', 'Agree')}: ${s.agree.map((a) => L(AG[a][1], AG[a][2])).join('، ') || '—'}</span><span>${L('معارضين', 'Disagree')}: ${s.disagree.map((a) => L(AG[a][1], AG[a][2])).join('، ') || '—'}</span><span>${L('حذر', 'Caution')}: ${s.caution.map((a) => AG[a][0]).join(' ') || '—'}</span><span class="mono">tally ${s.tally}</span></div>
        <div class="cn-cols"><div><h4>${L('أدلة مؤيدة', 'Supporting evidence')}</h4><ul>${s.supporting.map(ev).join('') || '<li class="muted">—</li>'}</ul></div><div><h4>${L('أدلة معاكسة', 'Contrary evidence')}</h4><ul>${s.contra.map(ev).join('') || '<li class="muted">—</li>'}</ul></div>
        <div><h4>${L('مخاطر', 'Risks')}</h4><ul>${s.risks.map(ev).join('') || '<li class="muted">—</li>'}</ul><h4>${L('شو بيلغي الفكرة', 'Invalidation')}</h4><ul>${(s.invalid || []).map((x) => `<li>${ii('close')}${esc(tx(x))}</li>`).join('') || '<li class="muted">—</li>'}</ul></div></div>
        <p class="muted rm-note">${L('تحليل تعليمي من حسابات على الشموع، مش توصية ولا نصيحة مالية. الوكلاء ممكن يغلطوا.', 'Educational analysis computed from candles — not a recommendation or financial advice. Agents can be wrong.')}</p></div>
      <div class="cn-agents">${res.agents.map((a) => { const st = STANCE[a.stance] || STANCE.neutral; return `<article class="card cn-agent"><h3>${AG[a.id][0]} ${esc(L(AG[a.id][1], AG[a.id][2]))} <span class="cn-st is-${st[2]}">${esc(L(st[0], st[1]))}</span></h3><ul>${a.evidence.map(ev).join('') || `<li class="muted">${L('ما في إشارة واضحة', 'No clear signal')}</li>`}</ul>${a.id === 'news' && !state.calOk ? `<p class="muted">${L('التقويم الاقتصادي مش متاح هلّق.', 'Economic calendar unavailable now.')}</p>` : ''}</article>`; }).join('')}</div>
      <div class="card rm-sec"><h2>${icons.layers} Market X-Ray <small class="muted">${state.depth ? L('مع دفتر أوامر Binance الحقيقي', 'with the real Binance order book') : L('بدون دفتر أوامر (مش كريبتو أو مش متاح)، المناطق تقديرية من السعر', 'no order book (not crypto or unavailable) — zones are estimated from price')}</small></h2>
        <div class="cn-layers">${[['liq', 'سيولة مقدّرة', 'Estimated liquidity'], ['fvg', 'فجوات FVG', 'FVGs'], ['book', 'جدران دفتر الأوامر', 'Order-book walls'], ['sweeps', 'سحب/اختراق كاذب', 'Sweeps / false breaks']].map(([k, a, b]) => `<label><input type="checkbox" data-layer="${k}"${layers.has(k) ? ' checked' : ''}> ${esc(L(a, b))}</label>`).join('')}
          <label>${L('الشدة الدنيا', 'Min intensity')} <input type="range" min="0" max="0.9" step="0.1" value="${minStr}" data-str></label></div>
        <canvas class="cn-xray" data-cv></canvas>
        <div class="cn-legend">${Object.entries(ZK).map(([, z]) => `<span><i style="background:${z[2]}"></i>${esc(L(z[0], z[1]))}</span>`).join('')}<span>⚡ ${L('سحب سيولة', 'sweep')}</span><span>✕ ${L('اختراق كاذب', 'false break')}</span></div>
        <details><summary>${L('أقرب المناطق', 'Nearest zones')}</summary><div class="rm-table-wrap"><table class="rm-table"><thead><tr><th>${L('النوع', 'Kind')}</th><th>${L('من', 'From')}</th><th>${L('لـ', 'To')}</th><th>${L('الشدة', 'Strength')}</th><th>${L('المصدر', 'Source')}</th></tr></thead><tbody>
          ${res.xray.zones.slice(0, 14).map((z) => `<tr><td>${esc(L(ZK[z.kind]?.[0], ZK[z.kind]?.[1]))}</td><td class="mono">${fmtNum(z.lo, dig)}</td><td class="mono">${fmtNum(z.hi, dig)}</td><td>${Math.round(z.strength * 100)}%</td><td>${z.source === 'order_book' ? `<b>${L('دفتر أوامر حقيقي', 'real order book')}</b>${z.notional ? ` ($${fmtNum(z.notional / 1e6, 2)}M)` : ''}` : L('تقدير من السعر', 'estimated')}</td></tr>`).join('')}</tbody></table></div></details></div>
      <div class="card rm-sec"><h2>🎲 ${L('السيناريوهات', 'Scenarios')} <small class="muted">${an.n >= 20 ? L(`الاحتمالات من ${an.n} حالة تاريخية مشابهة على نفس السوق (أفق ${an.horizon} شمعة)`, `Probabilities from ${an.n} similar historical cases on this market (horizon ${an.horizon} candles)`) : L(`حالات مشابهة قليلة (${an.n})، ما في احتمالات`, `Too few similar cases (${an.n}) — no probabilities`)}</small></h2>
        <div class="cn-scen">${res.scenarios.map((x) => `<article class="card cn-sc is-${x.id}"><h4>${esc(L(...SC[x.id]))}</h4><p class="cn-p">${x.p != null ? `${Math.round(x.p * 100)}%` : '—'}</p><dl>${Object.entries(x.levels).filter(([, val]) => val != null).map(([k2, val]) => `<dt>${esc(k2)}</dt><dd class="mono">${fmtNum(val, dig)}</dd>`).join('')}</dl></article>`).join('')}</div>
        <p class="muted rm-note">${L('النسب هي شو صار تاريخيًا بحالات شبيهة (RSI، ADX، موقع السعر من EMA50)، مش توقع مضمون. "تقلّب قوي" ممكن يتداخل مع غيره.', 'Shares are what happened historically in similar cases (RSI, ADX, price vs EMA50) — not a guaranteed forecast. “Volatility expansion” can overlap the others.')}</p></div>`;
    const cv = out.querySelector('[data-cv]'); const draw = () => drawXray(cv, c, res.xray, layers, minStr); requestAnimationFrame(draw);
    out.querySelectorAll('[data-layer]').forEach((b) => b.addEventListener('change', () => { b.checked ? layers.add(b.dataset.layer) : layers.delete(b.dataset.layer); draw(); }));
    out.querySelector('[data-str]').addEventListener('input', (e) => { minStr = Number(e.target.value); draw(); });
    new ResizeObserver(draw).observe(cv);
  }
  f.addEventListener('submit', (e) => { e.preventDefault(); run().catch((x) => toast(String(x?.message || x), 'error')); });
  return root;
}
