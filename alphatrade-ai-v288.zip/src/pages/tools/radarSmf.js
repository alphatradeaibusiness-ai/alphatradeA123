// Alpha Smart Money Flow (v233): where liquidity sits, whether it was taken, sweeps, OB / FVG, structure, premium / discount and
// two possible scenarios — on real closed candles. A map of what happened, not a prediction.
import { esc, fmtNum } from '../../utils/dom.js';
import { getInstrument } from '../../config/instruments.js';
import { storage } from '../../utils/storage.js';
import { store } from '../../state/store.js';
import { getCandles } from '../../services/market/index.js';
import { smartMoneyFlow, validateCandles, cleanCandles } from '../../services/radarPro.js';
import { whileMounted, loading } from './common.js';
import { L, DATA, marketSelect, tfSeg, scenarioText } from './radarText.js';

export function mountSmf(el, body) {
  const st = { symbol: store.get('symbol') || 'BTCUSDT', tf: '15m', ...(storage.get('radar-smf', {}) || {}) };
  if (!getInstrument(st.symbol)) st.symbol = 'BTCUSDT';
  body.innerHTML = `<div class="card rp-controls">${marketSelect('m', st.symbol)}${tfSeg('tf', st.tf)}<span class="rp-data" data-data></span></div>
    <div data-out>${loading()}</div>
    <p class="muted tool-note">${esc(L('خريطة لما صار فعلاً على الشموع المغلقة: وين السيولة، شو انسحب منها، ووين مناطق الطلب والعرض. السيناريوهات احتمالات للدراسة، مش توقعات مضمونة.', 'A map of what actually happened on closed candles: where liquidity sits, what was taken, where supply and demand zones are. Scenarios are possibilities to study, not guaranteed outcomes.'))}</p>`;
  const $ = (s) => body.querySelector(s);
  const keep = () => storage.set('radar-smf', { symbol: st.symbol, tf: st.tf });
  $('[data-m]').addEventListener('change', (e) => { st.symbol = e.target.value; keep(); run(); });
  $('[data-tf]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; st.tf = b.dataset.v; keep(); $('[data-tf]').querySelectorAll('button').forEach((x) => { x.classList.toggle('is-on', x === b); x.setAttribute('aria-pressed', String(x === b)); }); run(); });

  let token = 0;
  async function run() {
    const my = ++token; const inst = getInstrument(st.symbol); const p = (v) => fmtNum(v, inst.precision);
    $('[data-out]').innerHTML = loading();
    let ds; try { ds = await getCandles(st.symbol, st.tf); } catch { ds = null; }
    if (my !== token || !el.isConnected) return;
    if (!ds || ds.mode !== 'live') { $('[data-out]').innerHTML = `<div class="card sig-empty"><span>${esc(DATA().noLive)}</span></div>`; $('[data-data]').textContent = ''; return; }
    const candles = cleanCandles(ds.candles);
    const q = validateCandles(candles, st.tf, { crypto: inst.provider === 'binance' });
    $('[data-data]').innerHTML = `<span class="rp-dot is-${q.state}"></span>${esc(q.state === 'live' ? `${ds.source} · ${L('مباشر', 'live')}` : DATA()[q.state] || q.state)}${q.issues.filter((k) => ['gaps', 'duplicates'].includes(k)).map((k) => ` · ${esc(DATA()[k])}`).join('')}`;
    if (!q.ok) { $('[data-out]').innerHTML = `<div class="card sig-empty"><span>${esc(DATA().bad)}</span></div>`; return; }
    const f = smartMoneyFlow(candles.slice(0, -1));   // closed candles only
    if (!f) { $('[data-out]').innerHTML = `<div class="card sig-empty"><span>${esc(L('ما في تاريخ كافي لهالفريم.', 'Not enough history on this timeframe.'))}</span></div>`; return; }
    $('[data-out]').innerHTML = view(f, p, inst.symbol);
  }

  function view(f, p, symbol) {
    const biasTxt = { bull: L('ميل صاعد', 'Bullish lean'), bear: L('ميل هابط', 'Bearish lean'), neutral: L('بدون اتجاه واضح', 'No clear lean') }[f.bias];
    const conc = { above: L('السيولة متركزة فوق السعر', 'Liquidity is concentrated above price'), below: L('السيولة متركزة تحت السعر', 'Liquidity is concentrated below price'), balanced: L('السيولة موزّعة فوق وتحت', 'Liquidity is balanced above and below'), none: L('ما في سيولة مفتوحة قريبة', 'No open liquidity nearby') }[f.concentration];
    // the map: price on the vertical axis, every level and zone in its real place
    const levels = [f.price, ...f.pools.map((x) => x.price), ...f.obs.flatMap((o) => [o.top, o.bottom]), ...f.fvgs.flatMap((g) => [g.top, g.bottom]), ...(f.range ? [f.range.high, f.range.low] : [])];
    const near = levels.filter((v) => Math.abs(v - f.price) <= f.atr * 14);
    const hi = Math.max(...near) + f.atr * 0.6, lo = Math.min(...near) - f.atr * 0.6;
    const W = 640, H = 380, y = (v) => 12 + ((hi - v) / (hi - lo || 1)) * (H - 24);
    const inMap = (v) => v <= hi && v >= lo;
    const zones = [...f.obs.filter((o) => inMap(o.top) || inMap(o.bottom)).map((o) => ({ ...o, k: 'OB' })), ...f.fvgs.filter((g) => inMap(g.top) || inMap(g.bottom)).map((g) => ({ ...g, k: 'FVG' }))];
    // labels never sit on top of each other: one keeps its text, a close neighbour keeps only its line (full value in its tooltip)
    const spread = (list, yOf, gap) => { let last = -Infinity; return [...list].sort((a, b) => yOf(a) - yOf(b)).map((x) => { const yy = yOf(x); const noLabel = yy - last < gap; if (!noLabel) last = yy; return { ...x, noLabel }; }); };
    const pools = spread(f.pools.filter((x) => inMap(x.price)), (x) => y(x.price), 14)
      .map((x) => (Math.abs(y(x.price) - y(f.price)) < 12 ? { ...x, noLabel: true } : x));   // the price tag wins its row
    const svg = `<svg class="rp-map" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(L('خريطة السيولة', 'Liquidity map'))}" dir="ltr">
      ${f.range && inMap(f.range.eq) ? `<rect x="0" y="${y(Math.min(hi, f.range.high))}" width="${W}" height="${Math.max(0, y(f.range.eq) - y(Math.min(hi, f.range.high)))}" class="z-prem"/><rect x="0" y="${y(f.range.eq)}" width="${W}" height="${Math.max(0, y(Math.max(lo, f.range.low)) - y(f.range.eq))}" class="z-disc"/>
        <line x1="0" x2="${W}" y1="${y(f.range.eq)}" y2="${y(f.range.eq)}" class="l-eq"/><text x="8" y="${y(f.range.eq) - 5}" class="t-dim">EQ 50%</text>` : ''}
      ${[...spread(zones.filter((z) => z.k === 'OB'), (z) => y(Math.min(hi, z.top)), 16), ...spread(zones.filter((z) => z.k === 'FVG'), (z) => y(Math.min(hi, z.top)), 16)].map((z) => `<rect x="${z.k === 'OB' ? 150 : 300}" width="140" y="${y(Math.min(hi, z.top))}" height="${Math.max(3, y(Math.max(lo, z.bottom)) - y(Math.min(hi, z.top)))}" rx="3" class="${z.k === 'OB' ? 'z-ob' : 'z-fvg'} ${z.dir} ${z.mitigated ? 'is-used' : ''}"><title>${esc(`${z.k} ${z.dir === 'bull' ? L('طلب', 'demand') : L('عرض', 'supply')} ${p(z.bottom)} – ${p(z.top)}${z.mitigated ? L(' · مُختبر', ' · tested') : ''}`)}</title></rect>${z.noLabel ? '' : `<text x="${(z.k === 'OB' ? 150 : 300) + 6}" y="${y(Math.min(hi, z.top)) + 13}" class="t-zone">${z.k}${z.dir === 'bull' ? '↑' : '↓'}</text>`}`).join('')}
      ${pools.map((x) => `<line x1="440" x2="${W - 8}" y1="${y(x.price)}" y2="${y(x.price)}" class="l-pool ${x.side} ${x.taken ? 'is-taken' : ''}"><title>${esc(`${x.side === 'buy' ? 'BSL' : 'SSL'} ${p(x.price)}`)}</title></line>${x.noLabel ? '' : `<text x="${W - 10}" y="${y(x.price) - 4}" text-anchor="end" class="t-pool ${x.side}">${x.side === 'buy' ? 'BSL' : 'SSL'}${x.equal ? (x.side === 'buy' ? ' · EQH' : ' · EQL') : ''}${x.taken ? (x.swept ? ' ✓ sweep' : ' ✓') : ''} ${esc(p(x.price))}</text>`}`).join('')}
      <line x1="0" x2="${W}" y1="${y(f.price)}" y2="${y(f.price)}" class="l-price"/><rect x="0" y="${y(f.price) - 10}" width="92" height="20" rx="5" class="b-price"/><text x="46" y="${y(f.price) + 4}" text-anchor="middle" class="t-price">${esc(p(f.price))}</text>
    </svg>`;
    const poolRows = f.pools.filter((x) => Math.abs(x.price - f.price) <= f.atr * 25).slice(0, 14).map((x) => `<tr><td><span class="rp-side ${x.side}">${x.side === 'buy' ? 'BSL' : 'SSL'}</span>${x.equal ? `<small>${x.side === 'buy' ? 'EQH' : 'EQL'} ×${x.count}</small>` : ''}</td><td class="mono">${esc(p(x.price))}</td><td>${x.taken ? (x.swept ? `<b class="down-ish">${esc(L(`انسحبت (sweep) قبل ${x.takenAgo} شمعة`, `swept ${x.takenAgo} candles ago`))}</b>` : esc(L(`انأخذت قبل ${x.takenAgo} شمعة`, `taken ${x.takenAgo} candles ago`))) : `<b class="up-ish">${esc(L('لسا مفتوحة', 'still open'))}</b>`}</td></tr>`).join('');
    const ev = f.events.slice(-4).reverse().map((e) => `<li><b>${esc(e.kind)}</b> ${e.dir === 'bull' ? '↑' : '↓'} <span class="mono">${esc(p(e.price))}</span> <small class="muted">${esc(L(`قبل ${e.ago} شمعة`, `${e.ago} candles ago`))}</small></li>`).join('');
    const tg = (t, side) => (t ? `<div class="rp-target ${side}"><small>${esc(side === 'up' ? L('أقرب هدف سيولة فوق', 'Nearest liquidity above') : L('أقرب هدف سيولة تحت', 'Nearest liquidity below'))}</small><b class="mono">${esc(p(t.price))}</b><span>${esc(t.equal ? L('قمم/قيعان متساوية', 'equal highs/lows') : L('قمة/قاع', 'swing'))}</span></div>` : '');
    return `<div class="rp-grid">
      <section class="card rp-sum">
        <div class="rp-sum-head"><b>${esc(symbol)}</b><span class="rp-bias is-${f.bias}">${esc(biasTxt)}</span>${f.zone ? `<span class="rp-zone is-${f.zone}">${esc(f.zone === 'premium' ? L('السعر بمنطقة غالية', 'Price in premium') : L('السعر بمنطقة رخيصة', 'Price in discount'))}</span>` : ''}</div>
        <p>${esc(conc)}.</p>
        <div class="rp-targets">${tg(f.targets.up, 'up')}${tg(f.targets.down, 'down')}</div>
        <div class="rp-scen"><h4>${esc(L('سيناريوهات محتملة', 'Possible scenarios'))}</h4><ol>${f.scenarios.map((s) => `<li class="is-${s.dir}">${esc(scenarioText(s, p))}</li>`).join('')}</ol><small class="muted">${esc(L('احتمالات للدراسة حسب السيولة والهيكل، مش توقع مضمون.', 'Possibilities from liquidity and structure — not a guaranteed outcome.'))}</small></div>
      </section>
      <section class="card rp-mapcard">${svg}<p class="rp-legend"><span class="k-bsl">BSL</span><span class="k-ssl">SSL</span><span class="k-ob">OB</span><span class="k-fvg">FVG</span><span class="k-prem">${esc(L('غالية', 'Premium'))}</span><span class="k-disc">${esc(L('رخيصة', 'Discount'))}</span><span>${esc(L('✓ = انأخذت', '✓ = taken'))}</span></p></section>
      <details class="card rp-more" open><summary>${esc(L('مجمّعات السيولة', 'Liquidity pools'))} <small>(${f.pools.length})</small></summary><table class="rp-table"><tbody>${poolRows || `<tr><td>${esc(L('ما في', 'None'))}</td></tr>`}</tbody></table></details>
      <details class="card rp-more"><summary>${esc(L('الهيكل وآخر عمليات سحب السيولة', 'Structure and recent sweeps'))}</summary>
        <ul class="rp-ev">${ev || `<li>${esc(L('ما في كسر هيكل', 'No structure break'))}</li>`}</ul>
        <ul class="rp-ev">${f.sweeps.slice(0, 4).map((s) => `<li><b>${esc(s.side === 'buy' ? L('سحب BSL', 'BSL sweep') : L('سحب SSL', 'SSL sweep'))}</b> <span class="mono">${esc(p(s.price))}</span> <small class="muted">${esc(L(`قبل ${s.ago} شمعة`, `${s.ago} candles ago`))}</small></li>`).join('') || `<li>${esc(L('ما في سحب سيولة بآخر 30 شمعة', 'No sweep in the last 30 candles'))}</li>`}</ul></details>
      <details class="card rp-more"><summary>${esc(L('مناطق انعكاس محتملة (OB / FVG)', 'Potential reversal zones (OB / FVG)'))}</summary><ul class="rp-ev">${f.reversalZones.map((z) => `<li><b>${esc(z.kind)}</b> ${z.dir === 'bull' ? L('طلب', 'demand') : L('عرض', 'supply')} <span class="mono">${esc(p(z.bottom))} – ${esc(p(z.top))}</span>${z.mitigated ? ` <small class="muted">${esc(L('مُختبرة', 'tested'))}</small>` : ''}</li>`).join('') || `<li>${esc(L('ما في مناطق مفتوحة', 'No open zones'))}</li>`}</ul></details>
    </div>`;
  }
  run();
  whileMounted(el, run, 60_000);
}
