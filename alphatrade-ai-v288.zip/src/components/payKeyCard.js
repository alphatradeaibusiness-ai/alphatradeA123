// Payments card inside the owner's keys page: paste the Stripe secret key once; the server checks it by creating
// the webhook in the owner's Stripe account and keeps both secrets encrypted. The page never keeps the key.
import { esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { icons } from './icons.js';
import { toast } from './ui.js';
import { apiRequest } from '../services/ai/gateway.js';

const L = (ar, en) => (getLang() !== 'ar' ? en : ar);
const ERR = {
  invalid_key: ['المفتاح غلط أو انلغى. انسخه من جديد من Stripe.', 'The key is wrong or was revoked. Copy it again from Stripe.'],
  no_permission: ['هالمفتاح ما إله صلاحية يعمل Webhook. استعمل الـ Secret key (sk_) مش مفتاح مقيّد.', 'This key cannot create webhooks. Use the Secret key (sk_), not a restricted key.'],
  publishable_key: ['هاد الـ Publishable key (pk_). بدنا الـ Secret key اللي بيبلّش بـ sk_.', 'That is the publishable key (pk_). Paste the Secret key that starts with sk_.'],
  key_format: ['لازم يبلّش بـ sk_test_ أو sk_live_.', 'It must start with sk_test_ or sk_live_.'],
  url_invalid: ['Stripe ما قبل رابط الموقع. لازم يكون الموقع منشور على https (مش localhost).', 'Stripe refused the site address. The site must be live on https (not localhost).'],
  bad_origin: ['رابط الموقع مش واضح. حط PUBLIC_URL بـ Render.', 'The site address is unclear. Set PUBLIC_URL on Render.'],
  no_secret: ['السيرفر بحاجة AI_KEY_SECRET (32 حرف أو أكثر) حتى يخزّن المفاتيح مشفّرة.', 'The server needs AI_KEY_SECRET (32+ characters) to store keys encrypted.'],
  network: ['ما قدرنا نوصل لـ Stripe. جرّب كمان شوي.', 'Could not reach Stripe. Try again shortly.'],
};
const err = (c, m) => (ERR[c] ? L(...ERR[c]) : `${L('Stripe رفض', 'Stripe refused')}: ${m || c}`);

export const payKeyCardHtml = () => `<article class="card tool-card fade-in ai-key-card" data-pay-panel>
  <div class="tool-head"><h2 class="card-title">${icons.card || icons.lock}<span>${esc(L('الدفع (Stripe)', 'Payments (Stripe)'))}</span></h2><span data-pay-pill></span></div>
  <div data-pay-body><p class="muted">…</p></div></article>`;

export function bindPayKeyCard(root) {
  const panel = root.querySelector('[data-pay-panel]'); if (!panel) return;
  const body = panel.querySelector('[data-pay-body]'); const pill = panel.querySelector('[data-pay-pill]');
  const paint = (st) => {
    const on = st?.configured;
    pill.innerHTML = `<span class="badge ${on ? (st.mode === 'live' ? 'badge-live' : 'badge-warn') : 'badge-muted'}">${esc(on ? (st.mode === 'live' ? L('شغّال، دفع حقيقي', 'On — live payments') : L('شغّال، وضع تجريبي', 'On — test mode')) : L('مش مربوط', 'Not connected'))}</span>`;
    body.innerHTML = `
      ${on ? `<p class="ai-k-meta">${esc(st.source === 'env' ? L('المفاتيح من إعدادات Render.', 'Keys come from the Render settings.') : L(`المفتاح المحفوظ بينتهي بـ ${st.last4 || '—'}`, `Saved key ends in ${st.last4 || '—'}`))}${st.webhookUrl ? `<br><small class="mono">${esc(st.webhookUrl)}</small>` : ''}</p>` : ''}
      ${st?.source === 'env' ? '' : `<form class="ai-k-form" data-pay-form autocomplete="off">
        <label class="field"><span>${esc(L('Secret key من Stripe (Developers ← API keys)', 'Stripe Secret key (Developers → API keys)'))}</span>
          <input class="input mono" dir="ltr" name="k" type="password" placeholder="sk_test_…" spellcheck="false" autocapitalize="off" required /></label>
        <div class="tool-row"><button class="btn btn-primary" type="submit">${esc(on ? L('بدّل المفتاح', 'Replace key') : L('اربط Stripe', 'Connect Stripe'))}</button>
        ${on ? `<button class="btn btn-ghost" type="button" data-pay-del>${esc(L('افصل', 'Disconnect'))}</button>` : ''}</div></form>`}
      <ul class="tool-list">
        <li>${esc(L('بتلزق المفتاح مرة وحدة: السيرفر بيعمل الـ Webhook بحسابك لحاله وبيخزّن كل شي مشفّر.', 'Paste the key once: the server creates the webhook in your account and stores everything encrypted.'))}</li>
        <li>${esc(L('جرّب أول بـ sk_test_ وبطاقة 4242 4242 4242 4242. بعد ما Stripe يفعّل حسابك بدّله بـ sk_live_.', 'Try sk_test_ first with card 4242 4242 4242 4242. After Stripe activates your account, replace it with sk_live_.'))}</li>
        <li>${esc(L('الموقع لازم يكون منشور على https حتى يوصله Stripe.', 'The site must be live on https so Stripe can reach it.'))}</li>
      </ul>`;
    const f = body.querySelector('[data-pay-form]');
    f?.addEventListener('submit', async (e) => {
      e.preventDefault(); const k = f.k.value.trim(); f.k.value = '';
      const btn = f.querySelector('[type=submit]'); btn.disabled = true;
      try {
        const r = await apiRequest('PUT', '/api/billing/config', { secretKey: k }, 40000);
        if (r.ok) toast(L('انربط Stripe ✓', 'Stripe connected ✓'), 'success'); else toast(err(r.code, r.message), 'error', 9000);
        paint(r.status);
      } catch (x) { toast(err(x?.code), 'error', 9000); btn.disabled = false; }
    });
    body.querySelector('[data-pay-del]')?.addEventListener('click', async () => {
      try { paint(await apiRequest('DELETE', '/api/billing/config', undefined, 20000)); toast(L('انفصل Stripe', 'Stripe disconnected'), 'info'); } catch (x) { toast(err(x?.code), 'error'); }
    });
  };
  apiRequest('GET', '/api/billing/config', undefined, 10000).then(paint).catch((x) => {
    // say why instead of hiding the card
    const why = {
      not_owner: L('بس صاحب الموقع (إيميل الأدمن) بيقدر يربط الدفع. سجّل دخول بإيميل الأدمن.', 'Only the site owner (admin e-mail) can connect payments. Sign in with the admin e-mail.'),
      server_missing: L('السيرفر المنشور قديم وما فيه الدفع. ارفع آخر نسخة على Render وجرّب كمان مرة.', 'The deployed server is older and has no payments yet. Deploy the latest version on Render and try again.'),
      server_unreachable: L('ما في اتصال بالسيرفر هلأ.', 'The server cannot be reached right now.'),
      auth_not_configured: L('تسجيل الدخول على السيرفر مش مضبوط: حط FIREBASE_PROJECT_ID بإعدادات Render.', 'Server sign-in is not set up: add FIREBASE_PROJECT_ID on Render.'),
      signin_required: L('سجّل دخول أول.', 'Sign in first.'),
      signin_invalid: L('انتهت جلسة الدخول. سجّل خروج ودخول من جديد.', 'Your sign-in expired. Sign out and in again.'),
    }[x?.code] || L('ما قدرنا نقرأ حالة الدفع من السيرفر. تأكد إنك رافع آخر نسخة.', 'Could not read the payment status from the server. Make sure the latest version is deployed.');
    pill.innerHTML = `<span class="badge badge-error">${esc(L('مش متاح', 'Unavailable'))}</span>`;
    body.innerHTML = `<p class="sa-note">${esc(why)}</p>`;
  });
}
