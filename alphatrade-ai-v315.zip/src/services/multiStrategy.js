// Multi-strategy, multi-asset engine for the "AI signal" page (توصيات AI).
//
// One analysis request runs EVERY strategy module on the same candle snapshot, each one independently, and returns a
// checklist (PASS / FAIL / UNAVAILABLE with the measured value) for every mandatory condition. A strategy QUALIFIES only
// when every one of its mandatory conditions is PASS; a recommendation is issued only when at least one strategy
// qualifies AND every global safety filter passes. Every qualified strategy gets its own trade; opposite directions are
// still given but flagged as a conflict.
// Otherwise the result is NO TRADE with the exact reasons.
//
// Modules: 1 trend following · 2 mean reversion · 3 SMC/ICT (the site's existing engine, read through stricter rules) ·
// 4 LSTM / deep learning (no validated model is shipped → UNVALIDATED, never a signal) · 5 news & calendar (context and
// risk filter) · 6 statistical relationships (research / context only, never a standalone signal).
//
// Pure: no DOM, no network. Thresholds are research defaults (configurable through `cfg`), not proven optimal values.
// "Qualified" means every checklist item passed — it is not a probability of winning.
import { ema, rsi, atr, bollinger } from '../indicators/index.js';
import { CCY_IMPACT } from './news.js';

const round = (v, d = 6) => (Number.isFinite(v) ? Math.round(v * 10 ** d) / 10 ** d : v);
const PASS = 'pass', FAIL = 'fail', NA = 'unavailable';

/* ───────── instrument profiles (per asset class; per-timeframe scaling) ───────── */
// atrPct: [min, max] ATR(14) as % of price on a 1-hour candle; scaled by sqrt(tf / 1h) for other timeframes.
// estSpreadPct: typical cost used only when the data feed gives no live bid/ask (labelled "estimated" in the output).
export const PROFILES = {
  crypto: { label: ['كريبتو', 'Crypto'], session: '24/7', atrPct: [0.12, 3.5], spreadMaxPct: 0.08, estSpreadPct: 0.02 },
  metal: { label: ['معادن', 'Metals'], session: 'fx', atrPct: [0.04, 1.6], spreadMaxPct: 0.06, estSpreadPct: 0.03 },
  energy: { label: ['طاقة وسلع', 'Energy & commodities'], session: 'fx', atrPct: [0.07, 2.6], spreadMaxPct: 0.12, estSpreadPct: 0.05 },
  index: { label: ['مؤشرات', 'Indices'], session: 'index', atrPct: [0.04, 1.6], spreadMaxPct: 0.05, estSpreadPct: 0.02 },
  forex: { label: ['فوركس', 'Forex'], session: 'fx', atrPct: [0.02, 0.8], spreadMaxPct: 0.03, estSpreadPct: 0.01 },
  stock: { label: ['أسهم', 'Stocks'], session: 'us_equity', atrPct: [0.05, 2.5], spreadMaxPct: 0.1, estSpreadPct: 0.03 },
};
// Context / setup / entry timeframes for each chosen chart timeframe (scalping: a higher frame for context, the chart for the
// setup, a lower one for the entry). Defaults, not universal rules.
export const TF_LADDER = { '1m': ['15m', '5m', '1m'], '5m': ['1h', '15m', '5m'], '15m': ['4h', '1h', '15m'], '1h': ['1D', '4h', '1h'], '4h': ['1W', '1D', '4h'], '1D': ['1W', '1D', '1D'] };

export const DEFAULTS = {
  adxTrend: 20, rsiLo: 30, rsiHi: 70, adxRange: 22,   // strategy thresholds (research defaults)
  minRR: 1.5,                // reward-to-risk on the main target, after estimated costs
  newsBeforeMin: 30, newsAfterMin: 30,
  dailyLossPct: 1.5, pauseAfterLosses: 2, maxOpenPerSymbol: 1,
  maxRiskPct: 0.5,           // research default for this engine (the page warns above it; the user's own choice is kept)
  calendarMaxAgeH: 12,
};

// Sensitivity presets (Settings → channel page). 'more' accepts closer targets and slightly weaker momentum / extremes, so more
// setups qualify; these looser values are NOT back-tested — the page says so and the result must be watched in the channel.
// 'balanced' (the one in use, v212): half-way between the two — a moderate increase in setups.
export const PRESETS = { normal: {}, balanced: { minRR: 1.35, adxTrend: 19, rsiLo: 32.5, rsiHi: 67.5, adxRange: 23.5 }, more: { minRR: 1.2, adxTrend: 18, rsiLo: 35, rsiHi: 65, adxRange: 25 } };
export const presetCfg = (mode) => PRESETS[mode] || PRESETS.normal;

/** Whether the market is open now (UTC rules; holidays are not known to the app → shown as "approximate"). */
export function sessionState(assetClass, nowMs = Date.now()) {
  const d = new Date(nowMs); const day = d.getUTCDay(); const m = d.getUTCHours() * 60 + d.getUTCMinutes();
  const prof = PROFILES[assetClass]; if (!prof) return { open: false, name: 'unknown' };
  if (prof.session === '24/7') return { open: true, name: '24/7' };
  if (prof.session === 'us_equity') { const open = day >= 1 && day <= 5 && m >= 13 * 60 + 30 && m < 20 * 60; return { open, name: open ? 'NYSE' : 'closed' }; }
  // FX-style (forex, metals, energy) and index CFDs: closed from Friday 21:00 to Sunday 22:00 UTC, daily pause 21:00–22:00.
  const weekend = (day === 5 && m >= 21 * 60) || day === 6 || (day === 0 && m < 22 * 60);
  const pause = m >= 21 * 60 && m < 22 * 60;
  const open = !weekend && !pause;
  const name = !open ? 'closed' : m < 7 * 60 ? 'asia' : m < 12 * 60 ? 'london' : m < 16 * 60 ? 'london_ny' : 'new_york';
  return { open, name };
}

/* ───────── indicators not in indicators/index.js ───────── */
export function adx(candles, period = 14) {
  const n = candles.length; const out = new Array(n).fill(null);
  if (n < period * 2 + 1) return out;
  let tr = 0, pdm = 0, ndm = 0; const dx = [];
  for (let i = 1; i < n; i++) {
    const c = candles[i], p = candles[i - 1];
    const up = c.high - p.high, dn = p.low - c.low;
    const t = Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close));
    const pd = up > dn && up > 0 ? up : 0, nd = dn > up && dn > 0 ? dn : 0;
    if (i <= period) { tr += t; pdm += pd; ndm += nd; if (i < period) continue; }
    else { tr = tr - tr / period + t; pdm = pdm - pdm / period + pd; ndm = ndm - ndm / period + nd; }
    const pdi = tr ? (100 * pdm) / tr : 0, ndi = tr ? (100 * ndm) / tr : 0;
    dx.push({ i, v: pdi + ndi ? (100 * Math.abs(pdi - ndi)) / (pdi + ndi) : 0 });
  }
  let a = null;
  dx.forEach((d, k) => {
    if (k < period - 1) return;
    a = k === period - 1 ? dx.slice(0, period).reduce((s, x) => s + x.v, 0) / period : (a * (period - 1) + d.v) / period;
    out[d.i] = a;
  });
  return out;
}
export function macd(closes, fast = 12, slow = 26, signal = 9) {
  const f = ema(closes, fast), s = ema(closes, slow);
  const line = closes.map((_, i) => (f[i] != null && s[i] != null ? f[i] - s[i] : null));
  const first = line.findIndex((v) => v != null);
  const sig = first < 0 ? line.map(() => null) : [...new Array(first).fill(null), ...ema(line.slice(first), signal)];
  return { line, signal: sig, hist: line.map((v, i) => (v != null && sig[i] != null ? v - sig[i] : null)) };
}
/** Pivot highs / lows (k bars each side), oldest first. */
export function swings(candles, k = 3) {
  const hi = [], lo = [];
  for (let i = k; i < candles.length - k; i++) {
    const c = candles[i]; let h = true, l = true;
    for (let j = i - k; j <= i + k; j++) { if (j === i) continue; const left = j < i; if (left ? candles[j].high >= c.high : candles[j].high > c.high) h = false; if (left ? candles[j].low <= c.low : candles[j].low < c.low) l = false; }
    if (h) hi.push({ i, price: c.high }); if (l) lo.push({ i, price: c.low });
  }
  return { hi, lo };
}
/** Candles grouped n-at-a-time (a higher timeframe made from the chart's own candles). */
export function aggregate(candles, n) {
  const out = [];
  for (let i = candles.length % n; i + n <= candles.length; i += n) {
    const g = candles.slice(i, i + n);
    out.push({ time: g[0].time, open: g[0].open, close: g.at(-1).close, high: Math.max(...g.map((c) => c.high)), low: Math.min(...g.map((c) => c.low)), volume: g.reduce((s, c) => s + (c.volume || 0), 0) });
  }
  return out;
}

const chk = (id, ar, en, status, value = '') => ({ id, label: { ar, en }, status, value: value === '' || value == null ? '' : String(value) });
const okv = (b) => (b == null ? NA : b ? PASS : FAIL);

/* ───────── shared snapshot (computed once, used by every module) ───────── */
export function snapshot(candles, { htf = null, tfSec = 900 } = {}) {
  const cs = candles.filter((c) => [c.open, c.high, c.low, c.close].every(Number.isFinite));
  const closes = cs.map((c) => c.close);
  const i = cs.length - 1;
  const e20 = ema(closes, 20), e50 = ema(closes, 50), e200 = ema(closes, 200);
  const r = rsi(closes, 14), a = atr(cs, 14), d = adx(cs, 14), m = macd(closes), bb = bollinger(closes, 20, 2);
  // Higher timeframe for context: real 4h/1D candles when the provider gives them, else the chart's own candles grouped ×4.
  const real = tfSec < 14400 ? htf?.h4 : htf?.d1;
  const hc = real && real.length >= 60 ? real : aggregate(cs, 4);
  const hcl = hc.map((c) => c.close); const he = ema(hcl, 50);
  const hj = hc.length - 1;
  const htfDir = hc.length >= 60 && he[hj] != null && he[hj - 5] != null
    ? (hcl[hj] > he[hj] && he[hj] > he[hj - 5] ? 'long' : hcl[hj] < he[hj] && he[hj] < he[hj - 5] ? 'short' : 'neutral') : null;
  return { cs, closes, i, e20, e50, e200, r, a, d, m, bb, htfDir, htfSource: real && real.length >= 60 ? 'provider' : 'aggregated', sw: swings(cs, 3) };
}

/** Market regime from ADX and ATR. */
export function regimeOf(S) {
  const adxV = S.d[S.i]; const a = S.a[S.i]; const px = S.closes[S.i];
  if (adxV == null || a == null) return 'uncertain';
  const atrs = S.a.slice(-100).filter((v) => v != null).sort((x, y) => x - y);
  const p90 = atrs[Math.floor(atrs.length * 0.9)] || a;
  if (a > p90 * 1.15 && a / px > 0) return 'high_volatility';
  if (adxV >= 25) return 'trending';
  if (adxV < 20) return 'ranging';
  return 'uncertain';
}

/* ───────── STRATEGY 1 — trend following ───────── */
export function trendStrategy(S, { minRR = DEFAULTS.minRR, costPct = 0, adxTrend = DEFAULTS.adxTrend, ai = false, chaseMaxAtr = 0.8 } = {}) {
  const evalDir = (dir) => {
    const long = dir === 'long'; const sg = long ? 1 : -1; const i = S.i; const c = S.cs[i]; const a = S.a[i];
    const e20 = S.e20[i], e50 = S.e50[i], e200 = S.e200[i];
    const checks = [];
    checks.push(chk('htf', 'اتجاه الفريم الأعلى', 'Higher-timeframe direction', S.htfDir == null ? NA : (S.htfDir === dir || (ai && S.htfDir === 'neutral')) ? PASS : FAIL, S.htfDir ? `${S.htfDir}${ai && S.htfDir === 'neutral' ? ' (no opposite trend — warning only)' : ''} (${S.htfSource})` : 'not enough candles'));   // v314 (AI page): a flat higher frame is a warning; an OPPOSITE one still blocks
    const align = e200 == null ? null : long ? e20 > e50 && e50 > e200 : e20 < e50 && e50 < e200;
    checks.push(chk('ma', 'ترتيب المتوسطات EMA 20/50/200', 'EMA 20/50/200 alignment', okv(align), e200 == null ? 'needs 200 candles' : `${round(e20, 5)} / ${round(e50, 5)} / ${round(e200, 5)}`));
    const H = S.sw.hi.slice(-2), Lw = S.sw.lo.slice(-2);
    const struct = H.length < 2 || Lw.length < 2 ? null : long ? H[1].price > H[0].price && Lw[1].price > Lw[0].price : H[1].price < H[0].price && Lw[1].price < Lw[0].price;
    checks.push(chk('structure', long ? 'هيكل قمم وقيعان صاعدة' : 'هيكل قمم وقيعان هابطة', long ? 'Higher highs & higher lows' : 'Lower highs & lower lows', okv(struct), H.length < 2 || Lw.length < 2 ? 'not enough swings' : `H ${round(H[0].price, 5)}→${round(H[1].price, 5)} · L ${round(Lw[0].price, 5)}→${round(Lw[1].price, 5)}`));
    const adxV = S.d[i], rsiV = S.r[i], hist = S.m.hist[i];
    const mom = adxV == null || rsiV == null || hist == null ? null : adxV >= adxTrend && (long ? rsiV >= 50 && rsiV <= 70 && hist > 0 : rsiV <= 50 && rsiV >= 30 && hist < 0);
    checks.push(chk('momentum', `الزخم (ADX ≥ ${adxTrend}، RSI، MACD)`, `Momentum (ADX ≥ ${adxTrend}, RSI, MACD)`, okv(mom), adxV == null ? '' : `ADX ${round(adxV, 1)} · RSI ${round(rsiV, 1)} · MACD ${round(hist, 5)}`));
    let pull = null;
    if (a != null && e20 != null && e50 != null) {
      pull = false;
      for (let k = Math.max(1, i - 5); k < i; k++) {
        const b = S.cs[k]; const ref20 = S.e20[k], ref50 = S.e50[k];
        const touch = long ? Math.min(Math.abs(b.low - ref20), Math.abs(b.low - ref50)) <= 0.3 * a : Math.min(Math.abs(b.high - ref20), Math.abs(b.high - ref50)) <= 0.3 * a;
        const held = long ? b.close > ref50 : b.close < ref50;
        if (touch && held) { pull = true; break; }
      }
    }
    checks.push(chk('pullback', 'رجوع لـ EMA 20/50 خلال 5 شموع', 'Pullback to EMA 20/50 within 5 candles', okv(pull), a == null ? '' : `ATR ${round(a, 5)}`));
    const conf = c && e20 != null ? (long ? c.close > c.open && c.close > e20 : c.close < c.open && c.close < e20) : null;
    checks.push(chk('confirm', 'شمعة تأكيد مسكّرة', 'Closed confirmation candle', okv(conf), c ? `O ${round(c.open, 5)} C ${round(c.close, 5)}` : ''));
    // Plan: stop beyond the last swing on the other side (+0.2 ATR); targets 1.5R / 2R / 3R.
    let plan = null;
    const swing = long ? S.sw.lo.at(-1) : S.sw.hi.at(-1);
    if (swing && a) {
      const entry = c.close; const stop = swing.price - sg * 0.2 * a; const risk = (entry - stop) * sg;
      const ok = risk > 0.4 * a && risk < 3.5 * a;
      checks.push(chk('stop', 'وقف من الهيكل والتذبذب', 'Stop from structure & volatility', okv(ok), `${round(stop, 5)} (${round(risk / a, 2)} ATR)`));
      if (ok) {
        const targets = [1.5, 2, 3].map((x) => entry + sg * x * risk);
        const costR = (entry * costPct) / 100 / risk;
        plan = { direction: dir, entry, stop, targets, rr: [1.5, 2, 3], rrMain: round(2 - costR, 2), risk };
        checks.push(chk('rr', `العائد للمخاطرة ≥ ${minRR}`, `Reward-to-risk ≥ ${minRR}`, okv(plan.rrMain >= minRR), `${plan.rrMain}`));
        // v234 («توصية AI» only): no chasing — the close must still be near the EMA 20 pullback zone
        if (ai) { const ext = Math.abs(c.close - e20) / a; checks.push(chk('chase', `السعر مش ممدود عن EMA 20 (≤ ${chaseMaxAtr} ATR)`, `Not extended from EMA 20 (≤ ${chaseMaxAtr} ATR)`, okv(ext <= chaseMaxAtr), `${round(ext, 2)} ATR`)); }
      } else checks.push(chk('rr', `العائد للمخاطرة ≥ ${minRR}`, `Reward-to-risk ≥ ${minRR}`, NA, 'no valid stop'));
    } else {
      checks.push(chk('stop', 'وقف من الهيكل والتذبذب', 'Stop from structure & volatility', NA, 'no swing found'));
      checks.push(chk('rr', `العائد للمخاطرة ≥ ${minRR}`, `Reward-to-risk ≥ ${minRR}`, NA, ''));
    }
    // v234: setup quality (0-100) for the AI page — how clearly the conditions are met; NOT a probability of winning
    if (ai && plan) {
      const q = 40 + 20 * Math.min(1, Math.max(0, ((adxV ?? 0) - adxTrend) / 15)) + (S.htfSource === 'provider' ? 15 : 5) + (struct ? 15 : 0) + (plan.rrMain >= 2 ? 10 : 5);
      plan.quality = Math.round(Math.min(100, q));
    }
    return { dir, checks, plan };
  };
  return pickDirection('trend', ['تتبّع الاتجاه', 'Trend following'], evalDir);
}

/* ───────── STRATEGY 2 — mean reversion ───────── */
export function meanReversionStrategy(S, { minRR = DEFAULTS.minRR, costPct = 0, rsiLo = DEFAULTS.rsiLo, rsiHi = DEFAULTS.rsiHi, adxRange = DEFAULTS.adxRange, ai = false } = {}) {
  const evalDir = (dir) => {
    const long = dir === 'long'; const sg = long ? 1 : -1; const i = S.i; const c = S.cs[i], p = S.cs[i - 1]; const a = S.a[i];
    const up = S.bb.upper?.[i] ?? S.bb[i]?.upper, lo = S.bb.lower?.[i] ?? S.bb[i]?.lower, mid = S.bb.middle?.[i] ?? S.bb.mid?.[i] ?? S.bb[i]?.middle;
    const band = (k, side) => (side === 'u' ? (S.bb.upper?.[k] ?? S.bb[k]?.upper) : (S.bb.lower?.[k] ?? S.bb[k]?.lower));
    const checks = [];
    let ext = null, extreme = null;
    if (up != null && lo != null) {
      ext = false;
      for (let k = Math.max(0, i - 3); k <= i; k++) {
        const b = S.cs[k];
        if (long ? b.low <= band(k, 'l') : b.high >= band(k, 'u')) { ext = true; extreme = extreme == null ? (long ? b.low : b.high) : long ? Math.min(extreme, b.low) : Math.max(extreme, b.high); }
      }
    }
    checks.push(chk('extreme', long ? 'لمس حد بولينجر السفلي (20، 2)' : 'لمس حد بولينجر العلوي (20، 2)', long ? 'Touched lower Bollinger band (20, 2)' : 'Touched upper Bollinger band (20, 2)', okv(ext), lo == null ? '' : `L ${round(lo, 5)} · U ${round(up, 5)}`));
    const rej = c && lo != null ? (long ? c.close > lo && c.close > c.open : c.close < up && c.close < c.open) : null;
    checks.push(chk('rejection', 'رفض ورجوع لجوّا الحدود بشمعة مسكّرة', 'Closed rejection back inside the band', okv(rej), c ? `C ${round(c.close, 5)}` : ''));
    const rs = S.r.slice(Math.max(0, i - 5), i + 1).filter((v) => v != null);
    const rsiOk = rs.length < 2 ? null : long ? Math.min(...rs) < rsiLo && S.r[i] > S.r[i - 1] : Math.max(...rs) > rsiHi && S.r[i] < S.r[i - 1];
    checks.push(chk('rsi', long ? `RSI نزل تحت ${rsiLo} وعم يرجع` : `RSI طلع فوق ${rsiHi} وعم يرجع`, long ? `RSI below ${rsiLo} and recovering` : `RSI above ${rsiHi} and turning down`, okv(rsiOk), rs.length ? `RSI ${round(S.r[i], 1)} (min ${round(Math.min(...rs), 1)} / max ${round(Math.max(...rs), 1)})` : ''));
    const adxV = S.d[i];
    checks.push(chk('regime', `السوق عرضي (ADX < ${adxRange})`, `Ranging market (ADX < ${adxRange})`, okv(adxV == null ? null : adxV < adxRange), adxV == null ? '' : `ADX ${round(adxV, 1)}`));
    const slope = S.e50[i] != null && S.e50[i - 20] != null && a ? (S.e50[i] - S.e50[i - 20]) / a : null;
    checks.push(chk('no_trend', 'ما في اتجاه قوي ضد الصفقة', 'No strong trend against the trade', okv(slope == null ? null : long ? slope > -1.5 : slope < 1.5), slope == null ? '' : `EMA50 slope ${round(slope, 2)} ATR / 20 bars`));
    const conf = c && p ? (long ? c.close > p.close && c.close > c.open : c.close < p.close && c.close < c.open) : null;
    checks.push(chk('confirm', 'تأكيد الدخول', 'Entry confirmation', okv(conf), ''));
    if (ai) {
      // v234 («توصية AI» only): never against a trending / exploding market, never right after a displacement candle
      const reg = regimeOf(S);
      checks.push(chk('regime_state', 'حالة السوق مش اتجاه قوي ولا تذبذب عالي', 'Market not trending hard or exploding', okv(!['trending', 'high_volatility'].includes(reg)), reg));
      const big = a ? S.cs.slice(Math.max(0, i - 2), i + 1).some((b) => b.high - b.low > 2.5 * a) : null;
      checks.push(chk('no_displacement', 'ما في شمعة اندفاع (> 2.5 ATR) بآخر 3 شموع', 'No displacement candle (> 2.5 ATR) in the last 3', okv(big == null ? null : !big), a ? `ATR ${round(a, 5)}` : ''));
    }
    let plan = null;
    if (extreme != null && a && mid != null) {
      const entry = c.close; const stop = extreme - sg * 0.25 * a; const risk = (entry - stop) * sg;
      const ok = risk > 0.3 * a && risk < 3 * a;
      checks.push(chk('stop', 'وقف ورا الطرف', 'Stop beyond the extreme', okv(ok), `${round(stop, 5)}`));
      if (ok) {
        const far = long ? up : lo;
        const targets = [mid, (mid + far) / 2, far].map((x) => x);
        const rr = targets.map((t) => round(((t - entry) * sg) / risk, 2));
        const costR = (entry * costPct) / 100 / risk;
        const valid = targets.every((t) => (t - entry) * sg > 0);
        plan = valid ? { direction: dir, entry, stop, targets, rr, rrMain: round(rr[1] - costR, 2), risk } : null;
        checks.push(chk('rr', `العائد للمخاطرة ≥ ${minRR}`, `Reward-to-risk ≥ ${minRR}`, plan ? okv(plan.rrMain >= minRR) : FAIL, plan ? `${plan.rrMain}` : 'target behind entry'));
      } else checks.push(chk('rr', `العائد للمخاطرة ≥ ${minRR}`, `Reward-to-risk ≥ ${minRR}`, NA, 'no valid stop'));
    } else {
      checks.push(chk('stop', 'وقف ورا الطرف', 'Stop beyond the extreme', NA, ''));
      checks.push(chk('rr', `العائد للمخاطرة ≥ ${minRR}`, `Reward-to-risk ≥ ${minRR}`, NA, ''));
    }
    if (ai && plan) {
      const adxV2 = S.d[i]; const rsiExt = rs.length ? (long ? rsiLo - Math.min(...rs) : Math.max(...rs) - rsiHi) : 0;
      const q = 40 + 20 * Math.min(1, Math.max(0, (adxRange - (adxV2 ?? adxRange)) / 10)) + 20 * Math.min(1, Math.max(0, rsiExt / 10)) + (plan.rrMain >= 2 ? 20 : 10);
      plan.quality = Math.round(Math.min(100, q));
    }
    return { dir, checks, plan };
  };
  return pickDirection('mean_reversion', ['الارتداد للمتوسط', 'Mean reversion'], evalDir);
}

/** Runs both directions; a direction qualifies only if all its checks pass; else shows the closer one. */
function pickDirection(id, name, evalDir) {
  const res = ['long', 'short'].map(evalDir);
  const q = res.filter((r) => r.checks.every((c) => c.status === PASS) && r.plan);
  if (q.length === 2) return { id, name: { ar: name[0], en: name[1] }, status: 'conflict', direction: null, checks: res[0].checks, plan: null };
  if (q.length === 1) return { id, name: { ar: name[0], en: name[1] }, status: 'qualified', direction: q[0].dir, checks: q[0].checks, plan: q[0].plan };
  const best = res.sort((x, y) => y.checks.filter((c) => c.status === PASS).length - x.checks.filter((c) => c.status === PASS).length)[0];
  const allNa = best.checks.every((c) => c.status === NA);
  return { id, name: { ar: name[0], en: name[1] }, status: allNa ? 'unavailable' : 'not_qualified', direction: best.dir, checks: best.checks, plan: null };
}

/* ───────── STRATEGY 3 — SMC / ICT (the site's engine, read through the spec's mandatory list) ───────── */
export function smcStrategy(reading, S) {
  const name = { ar: 'سمارت موني (SMC/ICT)', en: 'Smart Money Concepts (SMC/ICT)' };
  if (!reading || reading.verdict === 'insufficient' || !reading.plan) {
    return { id: 'smc', name, status: 'unavailable', direction: null, checks: [chk('data', 'في إعداد SMC هلق (منطقة دخول + هيكل)', 'An SMC setup exists now (entry zone + structure)', NA, 'engine returned no setup')], plan: null };
  }
  const ck = Object.fromEntries((reading.checks || []).map((c) => [c.id, c]));
  const pl = reading.plan; const long = pl.direction === 'long'; const limit = pl.execution === 'limit';
  const liq = (reading.zones?.liquidity || []).filter((l) => Number.isFinite(l?.price) && (long ? l.price < reading.price : l.price > reading.price));
  const swept = Boolean(ck.sweep?.ok);
  const c = S?.cs?.[S.i];
  const checks = [
    chk('pool', long ? 'سيولة بيع (قيعان) موجودة قبل الحدث' : 'سيولة شراء (قمم) موجودة قبل الحدث', long ? 'Sell-side liquidity pool existed' : 'Buy-side liquidity pool existed', swept || liq.length ? PASS : FAIL, liq.length ? `${liq.length} level(s)` : swept ? 'swept pool' : 'none'),
    chk('sweep', 'سحب السيولة (Sweep)', 'Liquidity sweep', ck.sweep ? okv(ck.sweep.ok) : NA, reading.sweep ? `${round(reading.sweep.extreme ?? reading.sweep.level, 5)}` : ''),
    chk('displacement', 'اندفاع بشمعة مسكّرة (Displacement)', 'Closed displacement', okv(Boolean(pl.poi && ['OB', 'FVG', 'BREAKER'].includes(String(pl.poi.kind).toUpperCase()))), pl.poi?.kind || ''),
    chk('bos', 'كسر هيكل BOS / CHOCH', 'BOS / CHOCH confirmed', ck.mss ? okv(ck.mss.ok) : NA, reading.zones?.mss ? `${reading.zones.mss.kind || ''} @ ${round(reading.zones.mss.level, 5)}` : ''),
    chk('poi', 'أوردر بلوك أو FVG صالح', 'Valid order block / FVG', ck.poi ? okv(ck.poi.ok) : NA, pl.poi ? `${pl.poi.kind} ${round(pl.poi.bottom, 5)}–${round(pl.poi.top, 5)}` : ''),
    // A resting limit order IS the entry at the zone: it needs no retest or candle before it is placed (it fills on the touch).
    limit
      ? chk('retest', 'أمر ليميت معلّق على منطقة الدخول', 'Pending limit order at the entry zone', okv(reading.verdict === 'trade'), 'fills when price reaches the zone')
      : chk('retest', 'السعر رجع لمنطقة الدخول', 'Price retested the entry zone', okv(!reading.waiting && reading.verdict !== 'wait'), reading.waiting ? 'not in the zone yet' : 'in zone'),
    limit
      ? chk('confirm', 'التأكيد = لمس المنطقة (أمر ليميت)', 'Confirmation = touch of the zone (limit order)', okv(reading.verdict === 'trade'), 'limit order')
      : chk('confirm', 'شمعة تأكيد مسكّرة', 'Closed confirmation candle', pl.confirm ? okv(pl.confirm.status === 'confirmed') : c ? okv(long ? c.close > c.open : c.close < c.open) : NA, pl.confirm?.status || ''),
    chk('stop', 'الوقف واضح من الهيكل', 'Stop is objectively defined', okv(Number.isFinite(pl.stop) && Boolean(ck.risk?.ok ?? true)), `${round(pl.stop, 5)}`),
    chk('engine', 'كل الشروط الإلزامية لمحرك الموقع', 'All of the site engine\'s mandatory checks', (reading.reasons || []).length ? FAIL : PASS, (reading.reasons || []).join(', ') || 'ok'),
  ];
  const ok = checks.every((x) => x.status === PASS);
  const plan = ok ? { direction: pl.direction, entry: pl.entry, stop: pl.stop, targets: pl.targets, rr: pl.rr, rrMain: pl.rrMain, risk: pl.risk, fromEngine: true } : null;
  return { id: 'smc', name, status: ok ? 'qualified' : 'not_qualified', direction: pl.direction, checks, plan };
}

/**
 * v234 — SMC / ICT for the «توصية AI» page, read in three tiers instead of "every ICT idea is mandatory":
 *  • core (all must PASS): the site engine's mandatory checks (HTF bias, POI, premium/discount, R:R after costs, risk, account,
 *    news, daily loss, exposure), a valid zone, an objective stop, and a real entry reason (a resting limit at the zone, or for a
 *    market entry: price in the zone and a closed reaction candle);
 *  • confirmations (raise the quality score; at least two are needed and one of them must be a liquidity sweep or a structure
 *    break — so a mere touch of a zone is never a trade);
 *  • context (shown, never blocks on its own): kill zone, Silver Bullet, Judas swing, New York midnight open, minor HTF disagreement.
 */
export const SMC_CONFIRM = { sweep: 14, mss: 14, displacement: 10, ote: 8, structure: 8, liquidity: 6 };
export function smcStrategyTiered(reading, S) {
  const name = { ar: 'سمارت موني (SMC/ICT)', en: 'Smart Money Concepts (SMC/ICT)' };
  if (!reading || reading.verdict === 'insufficient' || !reading.plan) {
    return { id: 'smc', name, status: 'unavailable', direction: null, checks: [chk('data', 'في إعداد SMC هلق (منطقة دخول + هيكل)', 'An SMC setup exists now (entry zone + structure)', NA, reading?.reasons?.join(', ') || 'engine returned no setup')], plan: null, confirmations: [], context: [] };
  }
  const ck = Object.fromEntries((reading.checks || []).map((c) => [c.id, c]));
  const pl = reading.plan; const long = pl.direction === 'long'; const limit = pl.execution === 'limit';
  const c = S?.cs?.[S.i];
  const vol = ck.volume ? ck.volume.ok : null;
  const confirmations = [
    { id: 'sweep', ok: Boolean(ck.sweep?.ok), label: { ar: 'سحب سيولة (Sweep)', en: 'Liquidity sweep' } },
    { id: 'mss', ok: Boolean(ck.mss?.ok), label: { ar: 'كسر هيكل BOS / CHoCH / MSS', en: 'Structure break BOS / CHoCH / MSS' } },
    { id: 'displacement', ok: Boolean(pl.poi?.withFvg || vol === true), label: { ar: 'اندفاع (منطقة مع FVG أو حجم ≥ 1.5×)', en: 'Displacement (zone with an FVG or volume ≥ 1.5×)' } },
    { id: 'ote', ok: Boolean(ck.ote?.ok), label: { ar: 'منطقة OTE (62–79%)', en: 'OTE zone (62–79%)' } },
    { id: 'structure', ok: Boolean(ck.structure?.ok), label: { ar: 'هيكل الفريم مع الصفقة', en: 'Chart structure with the trade' } },
    { id: 'liquidity', ok: (pl.sources || []).some((x) => !/R$/.test(String(x))), label: { ar: 'هدف عند سيولة حقيقية', en: 'A target at real liquidity' } },
  ];
  if (ck.ltf) confirmations.push({ id: 'ltf', ok: Boolean(ck.ltf.ok), label: { ar: 'تأكيد الفريم الأصغر', en: 'Lower-timeframe confirmation' } });
  const passed = confirmations.filter((x) => x.ok);
  const structural = passed.some((x) => x.id === 'sweep' || x.id === 'mss');
  const context = [
    ck.killzone ? { id: 'killzone', ok: Boolean(ck.killzone.ok), label: { ar: 'جلسة Kill zone', en: 'Kill zone session' }, value: ck.killzone.note || '' } : null,
    ck.silver ? { id: 'silver', ok: Boolean(ck.silver.ok), label: { ar: 'ساعة Silver Bullet', en: 'Silver Bullet hour' }, value: ck.silver.note || '' } : null,
    ck.judas ? { id: 'judas', ok: Boolean(ck.judas.ok), label: { ar: 'Judas swing', en: 'Judas swing' } } : null,
    ck.nyopen ? { id: 'nyopen', ok: Boolean(ck.nyopen.ok), label: { ar: 'جهة افتتاح منتصف الليل (نيويورك)', en: 'Side of the New York midnight open' } } : null,
    reading.htfConflict === 'minor' ? { id: 'htf_minor', ok: false, label: { ar: 'خلاف بسيط بالفريمات الأعلى (الفريم الأكبر مع الصفقة)', en: 'Minor higher-frame disagreement (the highest frame agrees)' } } : null,
  ].filter(Boolean);
  const entryOk = limit ? reading.verdict === 'trade' : !reading.waiting && reading.verdict !== 'wait' && (pl.confirm ? pl.confirm.status === 'confirmed' : c ? (long ? c.close > c.open : c.close < c.open) : false);
  const checks = [
    chk('engine', 'كل الشروط الإلزامية لمحرك الموقع', 'All of the site engine\'s mandatory checks', (reading.reasons || []).length ? FAIL : PASS, (reading.reasons || []).join(', ') || 'ok'),
    chk('poi', 'أوردر بلوك / Breaker / FVG صالح', 'Valid order block / breaker / FVG', ck.poi ? okv(ck.poi.ok) : NA, pl.poi ? `${pl.poi.kind} ${round(pl.poi.bottom, 5)}–${round(pl.poi.top, 5)}` : ''),
    chk('stop', 'الوقف واضح من الهيكل', 'Stop is objectively defined', okv(Number.isFinite(pl.stop) && Boolean(ck.risk?.ok ?? true)), `${round(pl.stop, 5)}`),
    limit
      ? chk('entry', 'سبب دخول: أمر ليميت على المنطقة', 'Entry reason: a limit order at the zone', okv(reading.verdict === 'trade'), 'fills when price reaches the zone')
      : chk('entry', 'سبب دخول: السعر بالمنطقة وشمعة تفاعل مسكّرة', 'Entry reason: price in the zone and a closed reaction candle', okv(entryOk), reading.waiting ? 'not in the zone yet' : pl.confirm?.status || 'reaction'),
    chk('confluence', 'تأكيدين على الأقل، واحد منهم سحب سيولة أو كسر هيكل', 'At least two confirmations, one a sweep or a structure break', okv(passed.length >= 2 && structural), `${passed.length}/${confirmations.length}${structural ? '' : ' · no sweep / break'}`),
  ];
  const ok = checks.every((x) => x.status === PASS);
  const quality = Math.min(100, 40 + passed.reduce((a, x) => a + (SMC_CONFIRM[x.id] ?? 6), 0));
  const plan = ok ? { direction: pl.direction, entry: pl.entry, stop: pl.stop, targets: pl.targets, rr: pl.rr, rrMain: pl.rrMain, risk: pl.risk, fromEngine: true, quality } : null;
  return { id: 'smc', name, status: ok ? 'qualified' : 'not_qualified', direction: pl.direction, checks, plan, confirmations, context, quality: ok ? quality : null };
}

/* ───────── STRATEGY 4 — LSTM / deep learning ───────── */
export function lstmStrategy() {
  return {
    id: 'lstm', name: { ar: 'تعلّم عميق (LSTM)', en: 'LSTM / deep learning' }, status: 'unvalidated', direction: null, plan: null,
    checks: [
      chk('model', 'نموذج مدرّب ومنشور', 'Trained model deployed', NA, 'no trained LSTM model is shipped with the app'),
      chk('walkforward', 'تحقق خارج العيّنة (walk-forward)', 'Out-of-sample walk-forward validation', NA, 'not available'),
      chk('calibration', 'معايرة الاحتمالات', 'Probability calibration', NA, 'NOT CALIBRATED'),
    ],
  };
}

/* ───────── STRATEGY 5 — news & calendar (context and risk filter) ───────── */
export function relevantEvents(symbol, events, nowMs = Date.now(), hours = 24) {
  if (!Array.isArray(events)) return [];
  const moves = (e) => (CCY_IMPACT[e.country] || CCY_IMPACT.ALL || []).includes(symbol);
  return events.filter((e) => moves(e) && e.time >= nowMs - 60 * 60_000 && e.time <= nowMs + hours * 3600_000 && ['High', 'Medium'].includes(e.impact)).slice(0, 8);
}
export function newsStrategy(symbol, cal, nowMs = Date.now(), cfg = DEFAULTS) {
  const name = { ar: 'الأخبار والتقويم الاقتصادي', en: 'News & economic calendar' };
  const events = Array.isArray(cal?.events) ? cal.events : null;
  const ageH = cal?.at ? (nowMs - cal.at) / 3600_000 : null;
  const fresh = events && !cal.stale && (ageH == null || ageH <= cfg.calendarMaxAgeH);
  // v248 (AI page, cfg.newsUnknown = 'warn'): an older copy of the week's calendar still knows the scheduled times → used for blackouts
  const usable = fresh || (cfg.newsUnknown === 'warn' && events && (ageH == null || ageH <= 7 * 24));
  const rel = usable ? relevantEvents(symbol, events, nowMs) : [];
  const blackout = usable ? rel.find((e) => e.impact === 'High' && e.time - nowMs <= cfg.newsBeforeMin * 60_000 && nowMs - e.time <= cfg.newsAfterMin * 60_000) : null;
  const soon = usable ? rel.find((e) => e.impact === 'High' && e.time > nowMs && e.time - nowMs <= 4 * 3600_000) : null;
  const status = !events ? 'unavailable' : blackout ? 'blackout' : !fresh ? 'stale' : soon ? 'soon' : 'clear';
  return {
    id: 'news', name, status: 'context', direction: null, plan: null, newsStatus: status, events: rel, blackout, soon,
    source: 'Forex Factory calendar', fetchedAt: cal?.at || null,
    checks: [
      chk('feed', 'بيانات التقويم متوفرة', 'Calendar data available', events ? PASS : NA, events ? `${events.length} events` : 'NEWS DATA UNAVAILABLE'),
      chk('fresh', 'البيانات حديثة', 'Data is fresh', events ? okv(fresh) : NA, ageH == null ? '' : `${round(ageH, 1)} h old`),
      chk('blackout', `ما في خبر قوي ±${cfg.newsBeforeMin} دقيقة`, `No high-impact event within ±${cfg.newsBeforeMin} min`, fresh ? okv(!blackout) : NA, blackout ? blackout.title : ''),
    ],
  };
}

/* ───────── STRATEGY 6 — statistical relationships (research / context only) ───────── */
export function correlation(a, b) {
  const n = Math.min(a.length, b.length); if (n < 20) return null;
  const x = a.slice(-n), y = b.slice(-n);
  const mx = x.reduce((s, v) => s + v, 0) / n, my = y.reduce((s, v) => s + v, 0) / n;
  let sxy = 0, sxx = 0, syy = 0;
  for (let k = 0; k < n; k++) { sxy += (x[k] - mx) * (y[k] - my); sxx += (x[k] - mx) ** 2; syy += (y[k] - my) ** 2; }
  return sxx && syy ? sxy / Math.sqrt(sxx * syy) : null;
}
/** peer: { symbol, candles } of a related instrument on the same timeframe, or null when none is loaded. */
export function relationStrategy(S, peer = null) {
  const name = { ar: 'العلاقات الإحصائية (بحث فقط)', en: 'Statistical relationships (research only)' };
  let value = 'no synchronized peer data';
  let status = NA;
  if (peer?.candles?.length >= 60) {
    const byT = new Map(peer.candles.map((c) => [c.time, c.close]));
    const pairs = S.cs.filter((c) => byT.has(c.time)).map((c) => [c.close, byT.get(c.time)]);
    const ret = (arr) => arr.slice(1).map((v, k) => Math.log(v / arr[k]));
    const r = pairs.length >= 60 ? correlation(ret(pairs.map((p) => p[0])), ret(pairs.map((p) => p[1]))) : null;
    if (r != null) { status = PASS; value = `${peer.symbol}: ρ ${round(r, 2)} (${pairs.length} bars)`; }
  }
  return {
    id: 'relations', name, status: 'context', direction: null, plan: null,
    checks: [
      chk('sync', 'بيانات متزامنة لسوق مرتبط', 'Synchronized data for a related market', status, value),
      chk('validated', 'نموذج إحصائي موثّق ومجرّب', 'Documented, tested statistical setup', NA, 'none — context only, never a standalone signal'),
    ],
  };
}

/* ───────── global filters + orchestrator ───────── */
/**
 * input: {
 *   symbol, inst: { type, precision, provider }, tf, tfSec, candles, mode ('live'|'demo'), htf, reading (SMC engine result),
 *   calendar ({ events, at, stale }) | null, spread: { bidAskPct } | null, peer, nowMs,
 *   account: { todayLossPct, recentResults: ['win'|'loss'…newest last], openSameSymbol, openByStrategy?: { [id]: n }, riskPct },
 *   sizeFor(plan) → size | null, onTrade(trade) → called the moment one strategy qualifies (before the others are evaluated)
 * }
 */
export function runAllStrategies(input, cfg = {}) {
  // cfg.ai (v234, «توصية AI» page only): tiered SMC, mean-reversion state filters, no-chase check, quality scores, extra filters.
  let C = { ...DEFAULTS, ...cfg };
  const now = input.nowMs ?? Date.now();
  const assetClass = { crypto: 'crypto', metal: 'metal', energy: 'energy', index: 'index', forex: 'forex', stock: 'stock' }[input.inst?.type] || null;
  const prof = PROFILES[assetClass];
  const cs = input.candles || [];
  const S = cs.length >= 60 ? snapshot(cs, { htf: input.htf, tfSec: input.tfSec }) : null;
  const last = cs.at(-1);
  // v234 («توصية AI»): the caller's cost model (real spread when known + commission + slippage); others keep the estimate
  const costPct = Number.isFinite(C.costPct) ? C.costPct : prof ? prof.estSpreadPct * 2 : 0;
  // per asset class / timeframe calibration — only applied when the caller passes values backed by evidence (none ship today)
  const cal = (C.calib && C.calib[assetClass] && C.calib[assetClass][input.tf]) || {};
  const session = assetClass ? sessionState(assetClass, now) : { open: false, name: 'unknown' };
  const news = newsStrategy(input.symbol, input.calendar, now, C);

  // Global safety filters first (cheap, shared by every strategy), so a strategy can trade the moment it qualifies.
  const ageSec = last ? now / 1000 - last.time : Infinity;
  const fresh = ageSec <= 2.5 * (input.tfSec || 900) + 120;
  const atrPct = S && S.a[S.i] ? (S.a[S.i] / S.closes[S.i]) * 100 : null;
  const scale = Math.sqrt((input.tfSec || 3600) / 3600);
  const volOk = prof && atrPct != null ? atrPct >= prof.atrPct[0] * scale && atrPct <= prof.atrPct[1] * scale : null;
  // «توصية AI» (v309): in calm-to-moderate volatility (ATR under 60 % of the upper limit, regime not high-volatility) the looser 'more'
  // thresholds apply (closer target, weaker momentum). Above that the normal ones stay; above the limit the volatility check blocks the trade.
  // These looser values are NOT back-tested. The caller's own risk / cost / news settings are never loosened.
  let relaxed = false;
  if (C.relaxWhenCalm && volOk === true && S && regimeOf(S) !== 'high_volatility' && atrPct <= 0.6 * prof.atrPct[1] * scale) {
    const L = PRESETS.more; C = { ...C, minRR: Math.min(C.minRR, L.minRR), adxTrend: Math.min(C.adxTrend, L.adxTrend), rsiLo: Math.max(C.rsiLo, L.rsiLo), rsiHi: Math.min(C.rsiHi, L.rsiHi), adxRange: Math.max(C.adxRange, L.adxRange) }; relaxed = true;
  }
  const sp = input.spread?.bidAskPct;
  const spreadState = Number.isFinite(sp) ? (sp <= (prof?.spreadMaxPct ?? 0) ? 'ok' : 'wide') : 'estimated';
  const acct = input.account || {};
  const losses = (acct.recentResults || []).slice(-C.pauseAfterLosses);
  const pause = losses.length >= C.pauseAfterLosses && losses.every((x) => x === 'loss');
  // Exposure is per strategy when the caller knows which strategy each open trade came from: one strategy's open trade
  // never blocks another strategy (each one is independent). Otherwise the old per-market limit applies.
  const perStrategy = acct.openByStrategy && typeof acct.openByStrategy === 'object';
  const globals = [
    chk('supported', 'السوق مدعوم من مزوّد بيانات حقيقي', 'Instrument supported by a real data provider', okv(Boolean(prof && input.inst?.provider)), input.inst?.provider || 'unsupported'),
    chk('live', 'أسعار حية (مش تجريبية)', 'Live prices (not demo)', okv(input.mode === 'live'), input.mode || ''),
    chk('data', 'شموع كافية وصالحة', 'Enough valid candles', okv(cs.length >= 210), `${cs.length} candles`),
    chk('fresh', 'آخر شمعة حديثة', 'Last candle is fresh', last ? okv(fresh) : NA, last ? `${Math.round(ageSec / 60)} min ago` : ''),
    chk('session', 'السوق مفتوح', 'Market is open', okv(session.open), session.name),
    chk('volatility', 'التذبذب ضمن الحدود', 'Volatility within limits', okv(volOk), atrPct == null || !prof ? '' : `ATR ${round(atrPct, 3)}% (${round(prof.atrPct[0] * scale, 3)}–${round(prof.atrPct[1] * scale, 3)}%)`),
    chk('spread', 'السبريد والسيولة', 'Spread & liquidity', spreadState === 'wide' ? FAIL : PASS, spreadState === 'estimated' ? `estimated ${prof ? prof.estSpreadPct : '?'}% (feed gives no live bid/ask)` : `${round(sp, 4)}% (max ${prof?.spreadMaxPct ?? '?'}%)`),
    // v248: with cfg.newsUnknown = 'warn' (AI page) a missing / stale calendar is a warning on the card, not a block of every
    // strategy on every market (Forex Factory often refuses the feed); a known high-impact event still blocks.
    chk('news', 'مخاطر الأخبار', 'News risk', news.newsStatus === 'clear' || news.newsStatus === 'soon' ? PASS : news.newsStatus === 'blackout' ? FAIL : C.newsUnknown === 'warn' ? PASS : NA, news.newsStatus === 'unavailable' || news.newsStatus === 'stale' ? 'NEWS DATA UNAVAILABLE' : news.newsStatus),
    chk('daily', `حد الخسارة اليومي ${C.dailyLossPct}%`, `Daily loss limit ${C.dailyLossPct}%`, okv(!(Number(acct.todayLossPct) >= C.dailyLossPct)), `${round(Number(acct.todayLossPct) || 0, 2)}%`),
    chk('streak', `توقف بعد ${C.pauseAfterLosses} خسارات ورا بعض`, `Pause after ${C.pauseAfterLosses} losses in a row`, okv(!pause), (acct.recentResults || []).slice(-3).join(', ') || 'none'),
    perStrategy
      ? chk('exposure', 'صفقة وحدة مفتوحة لكل استراتيجية على نفس السوق', 'At most one open trade per strategy on this market', PASS, Object.entries(acct.openByStrategy).filter(([, n]) => n > 0).map(([k, n]) => `${k}:${n}`).join(', ') || '0')
      : chk('exposure', 'صفقة وحدة مفتوحة على نفس السوق كحد أقصى', 'At most one open trade on this market', okv(!((acct.openSameSymbol || 0) >= C.maxOpenPerSymbol)), `${acct.openSameSymbol || 0}`),
  ];
  // v234: extra safety filters from the caller (data integrity, total / asset-class exposure), same PASS rule
  if (Array.isArray(C.extraGlobals)) for (const g of C.extraGlobals) if (g && g.id && g.status) globals.push(g);
  const globalsOk = globals.every((g) => g.status === PASS);
  // The market context of this analysis, attached to every trade (services/learning.js learns which contexts lose).
  const features = S ? { relaxed, session: session.name, regime: regimeOf(S), adx: round(S.d[S.i], 1), rsi: round(S.r[S.i], 1), atrPct: atrPct == null ? null : round(atrPct, 3), htf: S.htfDir || 'neutral', hour: new Date(now).getUTCHours() } : null;
  const busy = (id) => perStrategy && (Number(acct.openByStrategy[id]) || 0) >= C.maxOpenPerSymbol;

  // Every module, each one on its own. A tradable strategy (trend / mean reversion / SMC) that meets ALL of its own
  // conditions is handed to onTrade immediately, before the remaining modules run — it never waits for the others.
  const emitted = [];
  const emit = (st) => {
    if (!globalsOk || st.status !== 'qualified' || !st.plan || !st.checks.every((c) => c.status === PASS) || busy(st.id)) return;
    const size = input.sizeFor ? input.sizeFor(st.plan) : null;
    if (input.sizeFor && !size) return;
    const trade = { id: st.id, direction: st.direction, plan: st.plan, size, ctx: features };
    emitted.push(trade);
    try { input.onTrade?.(trade); } catch { /* the caller's handler never stops the analysis */ }
  };
  const strategies = [];
  if (S) {
    const modules = [
      () => trendStrategy(S, { minRR: C.minRR, costPct, adxTrend: cal.adxTrend ?? C.adxTrend, ai: Boolean(C.ai), chaseMaxAtr: C.chaseMaxAtr }),
      () => meanReversionStrategy(S, { minRR: C.minRR, costPct, rsiLo: cal.rsiLo ?? C.rsiLo, rsiHi: cal.rsiHi ?? C.rsiHi, adxRange: cal.adxRange ?? C.adxRange, ai: Boolean(C.ai) }),
      () => (C.ai ? smcStrategyTiered : smcStrategy)(typeof input.reading === 'function' ? input.reading() : input.reading, S),   // the SMC reading may be computed lazily
      () => lstmStrategy(),
      () => news,
      () => relationStrategy(S, input.peer),
    ];
    for (const run of modules) { let st; try { st = run(); } catch { continue; } if (st && features) st.ctx = features; strategies.push(st); emit(st); }
  }

  const { qualified, final, reason, pick, size, trades, conflict } = decide(S ? strategies.map((x) => (busy(x.id) ? { ...x, status: 'busy' } : x)) : null, globals, input.sizeFor);
  return {
    instrument: input.symbol, assetClass, assetLabel: prof?.label || ['—', '—'], tf: input.tf, ladder: TF_LADDER[input.tf] || null,
    at: now, provider: input.inst?.provider || null, dataQuality: !S || input.mode !== 'live' ? 'insufficient' : !fresh || cs.length < 210 ? 'limited' : 'good',
    session, regime: S ? regimeOf(S) : 'uncertain', overall: S?.htfDir || 'neutral', spreadState, news,
    strategies, globals, qualified, final, reason, pick: pick ? { id: pick.id, plan: pick.plan } : null, size, trades, conflict, emitted, features, minRR: C.minRR,
    confidence: 'NOT CALIBRATED', riskWarn: Number(acct.riskPct) > C.maxRiskPct,
  };
}

/**
 * The final decision from the module results and the global filters (exported for tests).
 * strategies: null when there was not enough data. → { qualified: [id], final: 'buy'|'sell'|'no_trade', reason, pick, size }
 */
export function decide(strategies, globals, sizeFor = null) {
  if (!strategies) return { qualified: [], final: 'no_trade', reason: 'insufficient_data', pick: null, size: null, trades: [], conflict: false };
  const qualified = strategies.filter((s) => s.status === 'qualified' && s.plan && s.checks.every((c) => c.status === PASS));
  const ids = qualified.map((s) => s.id);
  const dirs = [...new Set(qualified.map((s) => s.direction))];
  const conflict = dirs.length > 1;
  const globalFail = globals.filter((g) => g.status !== PASS);
  if (!qualified.length) return { qualified: ids, final: 'no_trade', reason: 'no_strategy', pick: null, size: null, trades: [], conflict };
  if (globalFail.length) return { qualified: ids, final: 'no_trade', reason: globalFail.some((g) => g.id === 'news') ? 'news' : 'global', pick: null, size: null, trades: [], conflict };
  // Every strategy that met all of its own conditions gets its own trade (its own levels and size). When they point in
  // opposite directions both are still given, flagged as a conflict so the page can warn about it.
  const trades = qualified.map((s) => ({ id: s.id, direction: s.direction, plan: s.plan, size: sizeFor ? sizeFor(s.plan) : null, ctx: s.ctx || null })).filter((x) => !sizeFor || x.size);
  if (!trades.length) return { qualified: ids, final: 'no_trade', reason: 'sizing', pick: null, size: null, trades: [], conflict };
  // Headline trade: the SMC engine plan first when it qualified (its levels come from real liquidity), else the best R:R.
  const best = trades.find((x) => x.id === 'smc') || [...trades].sort((a, b) => b.plan.rrMain - a.plan.rrMain)[0];
  return { qualified: ids, final: best.direction === 'long' ? 'buy' : 'sell', reason: null, pick: { id: best.id, plan: best.plan }, size: best.size, trades, conflict };
}
export const makeCheck = (...a) => chk(...a);
