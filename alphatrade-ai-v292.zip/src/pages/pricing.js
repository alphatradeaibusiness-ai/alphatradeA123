// Subscriptions page: monthly, 3-month, 6-month and yearly plans.
import { h, esc } from '../utils/dom.js';
import { icons, logoMark } from '../components/icons.js';
import { t, getLang } from '../i18n/index.js';
import { CHANNEL_PRODUCTS } from '../config/channelPlans.js';
import { readEnv } from '../config/env.js';
import '../styles/recommendations.css';
import { PLANS, planMath } from '../config/billing.js';
import { tx } from '../i18n/tx.js';
import '../styles/community.css';
import { toast } from '../components/ui.js';
import { apiRequest } from '../services/ai/gateway.js';
import { auth } from '../services/auth/index.js';
import { payMethodsHtml } from '../components/payMethods.js';

let billingP = null;   // server Stripe checkout available? (asked once per page load)
const billingOn = () => (billingP ||= fetch('/api/billing/status').then((r) => (r.ok ? r.json() : null)).then((j) => Boolean(j?.configured)).catch(() => false));
import { TIERS, FEATURE_RANK, currentPlan, aiAllowance, ENFORCE } from '../config/entitlements.js';

const COUPON_ERR = {
  invalid_coupon: { ar: 'الكوبون مش صحيح أو موقوف.', en: 'This coupon is not valid.', he: 'הקופון לא תקף.', es: 'El cupón no es válido.', zh: '优惠券无效。' },
  bad_code: { ar: 'الكوبون مش صحيح أو موقوف.', en: 'This coupon is not valid.', he: 'הקופון לא תקף.', es: 'El cupón no es válido.', zh: '优惠券无效。' },
  expired: { ar: 'الكوبون انتهى.', en: 'This coupon has expired.', he: 'פג תוקף הקופון.', es: 'El cupón ha caducado.', zh: '优惠券已过期。' },
  not_started: { ar: 'الكوبون لسا ما بلّش.', en: 'This coupon is not active yet.', he: 'הקופון עוד לא פעיל.', es: 'El cupón aún no está activo.', zh: '优惠券尚未生效。' },
  used_up: { ar: 'الكوبون خلص عدد استخداماته.', en: 'This coupon has been used up.', he: 'הקופון נוצל.', es: 'El cupón se ha agotado.', zh: '优惠券已用完。' },
  not_for_plan: { ar: 'الكوبون مش لهالباقة.', en: 'This coupon is not for this plan.', he: 'הקופון לא לתוכנית הזו.', es: 'El cupón no es para este plan.', zh: '优惠券不适用于此套餐。' },
  already_used: { ar: 'استعملت هالكوبون قبل.', en: 'You already used this coupon.', he: 'כבר השתמשת בקופון.', es: 'Ya usaste este cupón.', zh: '你已使用过此优惠券。' },
  self_referral: { ar: 'ما بتقدر تستعمل كود الشريك تبعك.', en: 'You cannot use your own partner code.', he: 'אי אפשר להשתמש בקוד השותף שלך.', es: 'No puedes usar tu propio código de socio.', zh: '不能使用你自己的合作伙伴代码。' },
  already_referred: { ar: 'حسابك مربوط بشريك تاني.', en: 'Your account is already linked to another partner.', he: 'החשבון שלך כבר מקושר לשותף אחר.', es: 'Tu cuenta ya está vinculada a otro socio.', zh: '你的账户已关联其他合作伙伴。' },
  partner_inactive: { ar: 'كود الشريك موقوف.', en: 'This partner code is not active.', he: 'קוד השותף לא פעיל.', es: 'Este código de socio no está activo.', zh: '该合作伙伴代码未启用。' },
  duplicate_registration: { ar: 'هالإيميل انربط بشريك قبل.', en: 'This e-mail was already linked to a partner.', he: 'האימייל כבר קושר לשותף.', es: 'Este correo ya se vinculó a un socio.', zh: '此邮箱已关联过合作伙伴。' },
  plan_inactive: { ar: 'هالباقة موقوفة هلق.', en: 'This plan is not available right now.', he: 'התוכנית לא זמינה.', es: 'Este plan no está disponible.', zh: '此套餐暂不可用。' },
};
const money = (v) => (Number.isInteger(v) ? String(v) : v.toFixed(2));

export function renderPricing() {
  const en=getLang() !== 'ar',L=(ar,english)=>en?english:ar;
  const products=CHANNEL_PRODUCTS.map(p=>({...p,link:readEnv(p.env)}));
  const cur = currentPlan();
  const al = aiAllowance();
  const el = h(`<section class="subpage pricing page-enter">
    <header class="subpage-head pricing-head">
      <h1 class="brand-glow" dir="auto" style="direction:inherit">${esc(t('pricing.title'))}</h1>
      <p class="muted">${esc(t('pricing.sub'))}</p>
      <p class="pricing-trial"><a class="btn btn-primary btn-sm" href="#/app/billing">${icons.gift || ''}<span>${esc(L('جرّب مجانًا 7 أيام، بدون بطاقة', 'Try free for 7 days, no card'))}</span></a></p>
      <p class="muted pricing-terms">${esc(L('الدفع لمرة وحدة لمدة محددة عن طريق Stripe، ما في تجديد تلقائي.', 'One-time payment for a fixed period through Stripe, no automatic renewal.'))} <a href="#/app/legal/refund">${esc(t('lg.tabs.refund'))}</a> · <a href="#/app/legal/terms">${esc(t('lg.tabs.terms'))}</a> · <a href="#/app/legal/contact">${esc(t('lg.tabs.contact'))}</a> · <a href="#/app/billing">${esc(L('اشتراكي', 'My subscription'))}</a></p>
    </header>
    <div class="pricing-paym"><small class="muted">${esc(tx({ ar: 'طرق الدفع المتاحة بصفحة الدفع الآمنة:', en: 'Payment methods at the secure checkout:' }))}</small>${payMethodsHtml()}</div>
    <form class="pricing-coupon" data-coupon><input class="input mono" name="code" maxlength="20" autocomplete="off" placeholder="${esc(tx({ ar: 'عندك كوبون خصم؟', en: 'Have a coupon?', he: 'יש לך קופון?', es: '¿Tienes un cupón?', zh: '有优惠券吗？' }))}"><button class="btn btn-sm" type="submit">${esc(tx({ ar: 'طبّق', en: 'Apply', he: 'החל', es: 'Aplicar', zh: '使用' }))}</button><span class="muted" data-coupon-note></span></form>
    <div class="plan-grid">
      ${PLANS.map((p, i) => {
        const m = planMath(p);
        return `<article class="card plan fade-in${p.best ? ' plan-best' : ''}" data-plan-card="${p.id}" style="animation-delay:${i * 70}ms">
          <span class="plan-logo${p.premium ? ' is-premium' : ''}" data-plan="${p.id}" style="--d:${i}" aria-hidden="true"><i class="plan-logo-ring"></i>${logoMark(30)}<i class="plan-logo-sheen"></i></span>
          ${p.best ? `<span class="plan-ribbon">${esc(t('pricing.best'))}</span>` : ''}
          <h2 class="plan-name">${esc(t(`pricing.plans.${p.id}`))}</h2>
          <div class="plan-tier"${p.premium ? ' hidden' : ''}>${esc(t(`ent.tier.${TIERS[p.id].name}`))}${ENFORCE && cur === p.id ? `<em>${esc(t('ent.yourPlan'))}</em>` : ''}</div>
          <div class="plan-price"><span class="plan-cur">$</span><span class="plan-amt mono" data-amt>${money(p.price)}</span><span class="plan-was" data-was hidden></span><span class="plan-per">${esc(t(`pricing.per.${p.id}`))}</span></div>
          <div class="plan-meta">
            ${p.months > 1 ? `<span class="mono">${esc(t('pricing.perMonth', { v: money(m.perMonth) }))}</span>${m.saving > 0 ? `<span class="plan-save">${esc(t('pricing.save', { pct: m.savingPct, v: money(m.saving) }))}</span>` : ''}` : '<span>&nbsp;</span>'}
          </div>
          <ul class="plan-features">${t(`ent.feat.${p.id}`).map((f, k) => `<li${k === 0 && p.id !== 'monthly' ? ' class="plan-inherit"' : ''}>${k === 0 && p.id !== 'monthly' ? '' : icons.check}<span>${esc(f)}</span></li>`).join('')}
            <li class="rc-plan-feature">${icons.check}<span><b>${TIERS[p.id].signalsPerMonth} ${L('توصية كل شهر','recommendations per month')}</b><small>${L('متابعة النتائج متاحة بعد استهلاك الحصة.','Existing results remain accessible after using the allowance.')}</small></span></li>
            <li class="plan-ai">${icons.sparkle || icons.check}<span><b>${esc(t('ent.aiLine', { n: TIERS[p.id].aiPerMonth }))}</b><small>${esc(TIERS[p.id].aiCarryMonths ? t('ent.carry', { m: TIERS[p.id].aiCarryMonths }) : t('ent.noCarry'))} · ${esc(t('ent.localLine'))}</small></span></li>
          </ul>
          <button type="button" class="btn ${p.best ? 'btn-primary' : ''} plan-cta" data-plan="${p.id}">${esc(t('pricing.subscribe'))}</button>
        </article>`;
      }).join('')}
    </div>
    <section class="card plan-compare fade-in">
      <h2 class="card-title">${esc(t('ent.compare'))}</h2>
      <div class="compare-scroll"><table class="kv-table compare-table">
        <thead><tr><th>${esc(t('ent.row'))}</th>${PLANS.map((p) => `<th>${esc(t(`ent.tier.${TIERS[p.id].name}`))}</th>`).join('')}</tr></thead>
        <tbody>
          ${['core', 'frvp', 'strategies', 'radarFull', 'autotest', 'quant', 'multiScreen', 'earlyAccess'].map((k) => `<tr><td>${esc(t(`ent.rows.${k}`))}</td>${PLANS.map((p) => `<td>${TIERS[p.id].rank >= (FEATURE_RANK[k] ?? 1) ? esc(t('ent.yes')) : esc(t('ent.no'))}</td>`).join('')}</tr>`).join('')}
          <tr><td>${esc(t('ent.rows.signals'))}</td>${PLANS.map((p) => `<td class="mono">${TIERS[p.id].signalsPerMonth}</td>`).join('')}</tr>
          <tr><td>${L('مستوى تفاصيل التوصية','Recommendation detail level')}</td>${[L('صورة ومستويات ومتابعة','Image, levels & tracking'),L('أدلة وشروط التحليل','Analysis evidence & conditions'),L('تفاصيل العائد وصور للحفظ','Reward ratios & image downloads'),L('كل تفاصيل القناة','Complete channel details')].map(n=>`<td>${n}</td>`).join('')}</tr>
          <tr><td>${esc(t('ent.rows.alerts'))}</td>${PLANS.map((p) => `<td class="mono">${TIERS[p.id].alerts > 0 ? TIERS[p.id].alerts : esc(t('ent.unlimited'))}</td>`).join('')}</tr>
          <tr><td>${esc(t('ent.rows.ai'))}</td>${PLANS.map((p) => `<td class="mono">${TIERS[p.id].aiPerMonth}</td>`).join('')}</tr>
        </tbody>
      </table></div>
      ${ENFORCE ? `<p class="muted ent-usage">${esc(t('ent.usage', { used: al.used, total: al.total }))}</p>` : ''}
    </section>
    <section class="channel-products"><h2>${L('قناة التوصيات وإضافات الحصة','Channel subscriptions & top-ups')}</h2><p class="muted">${L('اشترك بالقناة لحالها بدون باقة المنصة، أو أضف توصيات فوق حصة اشتراكك الحالي.','Subscribe to the channel without a platform plan, or add recommendations to your active allowance.')}</p><div class="plan-grid">${products.map(p=>`<article class="card plan"><h2 class="plan-name">${p.kind==='subscription'?L('القناة المستقلة','Channel only'):L('إضافة ','Top-up ')+p.count}</h2><div class="plan-price"><span class="plan-cur">$</span><span class="plan-amt mono">${p.price}</span><small>${p.kind==='subscription'?L('/ شهر','/ month'):L('دفعة واحدة','one-time')}</small></div><p><b>${p.count} ${L('توصية','recommendations')}</b></p><p class="muted">${p.kind==='subscription'?L('صورة التحليل، المستويات، أدلة الاستراتيجية، التنبيهات ومتابعة النتيجة. أدوات المنصة الأخرى غير مشمولة.','Analysis images, levels, strategy evidence, notifications and outcome tracking. Other platform tools are not included.'):L('تحتاج اشتراكًا فعّالًا بالمنصة أو القناة؛ تنتهي مع تجديد الحصة الحالية ولا تُرحّل.','Requires an active platform or channel subscription. Expires at the current allowance renewal; no carry-over.')}</p><button type="button" class="btn btn-primary" data-product="${p.id}">${p.kind==='subscription'?L('اشترك بالقناة','Subscribe to channel'):L('زيادة التوصيات','Add recommendations')}</button></article>`).join('')}</div><p class="muted">${L('الحصة سقف استخدام وليست عدد فرص مضمونًا. لا حد يومي منفصل؛ الحصة شهرية. تفعيل الاشتراك أو الإضافة بعد تأكيد الشراء فقط.','The allowance is a ceiling, not a guaranteed number of setups. There is no separate daily cap. Purchases activate only after payment confirmation.')}</p></section>
    <p class="muted pricing-note">${icons.shield}<span>${esc(t('pricing.note'))} ${esc(t('pricing.disclaimer'))}</span></p>
  </section>`);

  // The owners' current prices and plans (server), and a coupon checked on the server for each plan.
  let coupon = '';
  fetch('/api/plans').then((r) => (r.ok ? r.json() : null)).then((j) => {
    for (const x of j?.items || []) {
      const card = el.querySelector(`[data-plan-card="${x.id}"]`); if (!card) continue;
      if (!x.active) { card.hidden = true; continue; }
      card.querySelector('[data-amt]').textContent = money(x.price);
      const pl = PLANS.find((q) => q.id === x.id); if (pl) pl.price = x.price;
    }
  }).catch(() => {});
  el.querySelector('[data-coupon]').addEventListener('submit', async (e) => {
    e.preventDefault(); const code = e.currentTarget.code.value.trim().toUpperCase(); const note = el.querySelector('[data-coupon-note]');
    el.querySelectorAll('[data-was]').forEach((x) => { x.hidden = true; }); coupon = '';
    if (!code) { note.textContent = ''; return; }
    if (!auth.current()?.uid) { toast(t('pricing.signIn'), 'info', 5000); return; }
    let ok = 0; let last = null;
    for (const p of PLANS) {
      const card = el.querySelector(`[data-plan-card="${p.id}"]`); if (!card || card.hidden) continue;
      try { const q = await apiRequest('POST', '/api/coupon/check', { code, product: p.id }); const was = card.querySelector('[data-was]'); was.textContent = `$${money(p.price)}`; was.hidden = false; card.querySelector('[data-amt]').textContent = money(q.finalCents / 100); ok++; }
      catch (err) { last = err?.code; }
    }
    if (ok) { coupon = code; note.textContent = tx({ ar: `الكوبون ${code} مطبّق، السعر الجديد ظاهر على الباقات المشمولة.`, en: `Coupon ${code} applied, the new price shows on the eligible plans.`, he: `הקופון ${code} הוחל.`, es: `Cupón ${code} aplicado.`, zh: `已使用优惠券 ${code}。` }); }
    else note.textContent = tx(COUPON_ERR[last] || COUPON_ERR.invalid_coupon);
  });
  const paid = /[?&]paid=1/.test(location.hash);
  if (paid) toast(t('pricing.paidOk'), 'success', 9000);
  el.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-plan], [data-product]');
    if (!b) return;
    const plan = b.dataset.product ? products.find(p=>p.id===b.dataset.product) : PLANS.find((p) => p.id === b.dataset.plan);
    if (await billingOn()) {
      // Stripe Checkout made by our server: the price comes from the server, access starts when Stripe confirms the payment.
      if (!auth.current()?.uid) { toast(t('pricing.signIn'), 'info', 5000); return; }
      b.disabled = true;
      try {
        const r = await apiRequest('POST', '/api/billing/checkout', { product: plan.id, coupon: coupon || undefined }, 20000);
        if (r?.url && /^https:\/\/checkout\.stripe\.com\//.test(r.url)) { location.href = r.url; return; }   // only ever leave the site for Stripe Checkout
        toast(t('pricing.payFail'), 'error', 6000);
      } catch (err) { toast(err?.code === 'active_subscription_required' ? t('pricing.needSub') : COUPON_ERR[err?.code] ? tx(COUPON_ERR[err.code]) : t('pricing.payFail'), 'error', 6000); }
      b.disabled = false; return;
    }
    if (!plan.link) { toast(t('pricing.notConfigured'), 'info', 6000); return; }
    toast(t('pricing.redirect'), 'info', 3000);
    // Real link (not window.open) so it also works where pop-ups are blocked.
    const a = document.createElement('a');
    a.href = plan.link;
    a.target = '_blank';
    a.rel = 'noopener';
    a.click();
  });
  return el;
}
