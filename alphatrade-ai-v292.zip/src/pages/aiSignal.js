// "Ask the AI for a trade" — a 4-step wizard: trading style → market → symbol → account settings → analysis → recommendation card.
// Every number on the card comes from the site's own SMC / ICT engine (services/smcAssist.js) run on LIVE candles; the AI only
// explains that plan in words (when the AI is connected). Nothing is invented: on demo prices, missing data or failed checks
// the card says "no trade" and why. The checklist count is a checklist, not a probability of winning.
import { h, esc, fmtNum } from '../utils/dom.js';
import { restartClass } from '../utils/motion.js';
import { t, getLang } from '../i18n/index.js';
import { icons } from '../components/icons.js';
import { toast } from '../components/ui.js';
import { storage } from '../utils/storage.js';
import { auth } from '../services/auth/index.js';
import { store } from '../state/store.js';
import { INSTRUMENTS, EXTRA_INSTRUMENTS, getInstrument } from '../config/instruments.js';
import { TIMEFRAMES } from '../config/market.js';
import { getHistory, getTickers } from '../services/market/index.js';
import { prefetchHtf, htfCandles } from '../services/htfData.js';
import { getCalendar } from '../services/news.js';
import { newsRisk } from '../services/synthesis.js';
import { rsi, atr } from '../indicators/index.js';
import { analyzeSmcIct, cleanInputs, sizePosition, STYLES, ACCOUNTS } from '../services/smcAssist.js';
import { saveTrade, listTrades, todayLossPct, pullTrades, expireStale } from '../services/assistTrades.js';
import { tzLabel, tzOffset, fmtTz, signalStatus, trackPos, hubItems, MARKET_TOL_PTS } from '../services/aiSignalUtil.js';
import { riskSettings, costModel, EXEC, RISK, STRATEGIES, statusOf, strategyOf, ENGINE_VERSION } from '../config/aiSignalRules.js';
import { extraGlobals, isDuplicate, prepare, executeAll, pageEngineCfg, recentResultsFor } from '../services/aiSignalEngine.js';
import { runPaper } from '../services/aiPaperStrategies.js';
import { recordPaper, refreshPaper, recordDecision, backtests, saveBacktest } from '../services/aiPaperJournal.js';
import { dashHtml } from './aiSignalDash.js';
import { validateCandles } from '../services/radarPro.js';
import { binanceGet } from '../services/market/binance.js';
import { PROMPT_VERSION } from '../services/ai/prompts.js';
import { LTF } from '../services/smcAssist.js';
import { explainSmc, sendAiMessage } from '../services/ai/client.js';
import { aiErrorText } from '../components/aiKeyCard.js';
import { aiContext } from '../components/smcAssistPanel.js';
import { pairName, priceText } from '../services/tradeMessages.js';
import { runAllStrategies, presetCfg } from '../services/multiStrategy.js';
import { engineMode } from '../services/engineMode.js';
import { learnCheck, learnWeight } from '../services/learning.js';
import { engineHtml, engineReasonText, engineBrief, PEER } from '../components/aiEngineReport.js';
import { micButton } from '../services/voice.js';
import { applySignal, wasApplied, oneClickLot } from '../services/mt5Apply.js';
import { notify as pushNotify } from '../services/signals.js';
import { getTradingStyle } from '../services/tradingStyle.js';
import { isAdmin } from '../config/admin.js';
import '../styles/mt5btn.css';
import '../styles/aiSignal.css';
import '../styles/aiEngine.css';

const L = (ar, en) => (getLang() !== 'ar' ? en : ar);
// v246: the engine's internals (strategies, checks, PAPER research, the watch status) are for the site owner only
const OWN = () => { try { return Boolean(isAdmin()); } catch { return false; } };
const SA = (k, p) => t(`sa.${k}`, p);
const prefKey = () => `ai-signal:${auth.current()?.uid || 'guest'}`;
const DEF = { style: 'scalp', market: 'metal', symbol: 'XAUUSD', tf: '15m', account: 'margin', capital: 10000, riskPct: 1, execution: 'limit', dailyLossPct: RISK.dailyLossPct.def, maxOpen: RISK.maxOpen.def, ltf: false };

// Market groups shown in step 1 → instrument types and the asset used for costs / lot size.
export const MARKETS = {
  crypto: { types: ['crypto'], icon: 'btc' },
  metal: { types: ['metal', 'energy'], icon: 'gem' },
  index: { types: ['index'], icon: 'trend' },
  forex: { types: ['forex'], icon: 'globe' },
};
const ASSET_OF = { crypto: 'crypto', metal: 'metal', energy: 'energy', index: 'index', forex: 'forex' };
// v248: the AI page also analyses the extra instruments (US2000, XPDUSD, EURCHF, AUDJPY, CADJPY) on request
export const symbolsOf = (market) => [...INSTRUMENTS, ...EXTRA_INSTRUMENTS].filter((i) => MARKETS[market]?.types.includes(i.type)).map((i) => i.symbol);
export const defaultTf = (style) => (style === 'swing' ? '4h' : '15m');
// v244 automatic watch: after a NO TRADE answer the page keeps checking the chosen symbol (first) and the other symbols of the
// same market, once per new closed candle of the chosen timeframe, with exactly the same engine and conditions. The moment one
// qualifies, the trade is saved (followed to its stop / targets with alerts) and announced. Nothing is relaxed. It runs while
// the site is open (any page); one watcher at a time.
let watchGen = 0; let watchTimer = null; let watchStopFn = null; let watchInfo = null;
const watchKey = () => `ai-signal-watch:${auth.current()?.uid || 'guest'}`;

const GLYPH = {
  btc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M9 6h5a3 3 0 0 1 0 6H9zm0 6h6a3 3 0 0 1 0 6H9zM9 4v16M12 4v2M12 18v2"/></svg>',
  gem: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M6 4h12l3 5-9 11L3 9zM3 9h18M9 4l3 16 3-16"/></svg>',
};
const ic = (k) => GLYPH[k] || icons[k] || icons.sparkle || '';
const INTEL = { crypto: ['ذكاء الكريبتو', 'CRYPTO INTELLIGENCE'], metal: ['ذكاء المعادن', 'METAL INTELLIGENCE'], energy: ['ذكاء السلع', 'COMMODITY INTELLIGENCE'], index: ['ذكاء المؤشرات', 'INDEX INTELLIGENCE'], forex: ['ذكاء الفوركس', 'FOREX INTELLIGENCE'] };
const SUBNAME = { XAUUSD: ['ذهب فوري', 'Gold Spot'], XAGUSD: ['فضة فورية', 'Silver Spot'], XPTUSD: ['بلاتين فوري', 'Platinum Spot'], USOIL: ['نفط أمريكي', 'US Crude Oil'], UKOIL: ['نفط برنت', 'Brent Oil'], NATGAS: ['غاز طبيعي', 'Natural Gas'], COPPER: ['نحاس', 'Copper'], BTCUSDT: ['بيتكوين', 'Bitcoin'], ETHUSDT: ['إيثيريوم', 'Ethereum'], US30: ['داو جونز', 'Dow Jones'], US100: ['ناسداك 100', 'Nasdaq 100'], SPX500: ['إس آند بي 500', 'S&P 500'] };
const OTYPES = () => [
  ['market', 'bolt', L('ماركت', 'Market'), L('تنفيذ على السعر الحالي بالضبط', 'Fills at the exact current price')],
  ['limit', 'crosshair', L('ليميت', 'Limit'), L('أمر معلّق بيتفعّل تلقائيًا', 'Pending order, activates automatically')],
];
const ONOTE = () => ({
  market: L('سعر التنفيذ هو السعر الحالي بالضبط، أو بفرق 5 نقاط كحد أقصى. بتطلع بس إذا السعر جوّا منطقة الدخول هلق، وغير هيك «استنى».', 'The fill price is the exact current price, or within 5 points at most. Only given when price is inside the entry zone now; otherwise "wait".'),
  limit: L('أمر معلّق بسعر محدد: بيتفعّل تلقائيًا لما يوصل السعر للرقم، وقبل هيك ما في صفقة مفتوحة.', 'A pending order at a set price: it activates automatically when price reaches it; until then no trade is open.'),
});
const MKT_ICON = { crypto: 'btc', metal: 'gem', energy: 'gem', index: 'trend', forex: 'globe' };
const CHECK = '<span class="aisg-check" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m6 12 4 4 8-8"/></svg></span>';

/**
 * One signal card in the "Signal Hub" style: symbol + market, BUY / SELL, a status pill, ENTRY · STOP · TP1 · TP2 (· TP3),
 * a one-line note and a track from the stop to the last target with the live price on it.
 * x: { symbol, direction, entry, stop, targets, note, price, prec, status: { cls, ar, en } }
 */
export function hubCard(x) {
  const inst = getInstrument(x.symbol); const type = inst?.type || 'crypto'; const long = x.direction !== 'short';
  const prec = x.prec ?? inst?.precision ?? 2; const px = (v) => priceText(x.symbol, v, prec);
  const cells = [[L('الدخول', 'ENTRY'), px(x.entry), ''], [L('الوقف', 'STOP'), px(x.stop), 'down'], ...x.targets.map((v, k) => [`TP${k + 1}`, px(v), 'up'])];
  const tr = trackPos(x, x.price);
  const pct = (v) => `${(v * 100).toFixed(1)}%`;
  return `<article class="sh-card ${long ? 'is-long' : 'is-short'}">
    <div class="sh-top"><span class="sh-ic" data-accent="${type === 'energy' ? 'metal' : type}">${ic(MKT_ICON[type] || 'sparkle')}</span>
      <div class="sh-name"><b>${esc(pairName(x.symbol))}</b><span class="sh-dir">${icons.trend || ''}${esc(long ? L('شراء', 'BUY') : L('بيع', 'SELL'))}</span><small>${esc(L(...(INTEL[type] || INTEL.crypto)))}</small></div>
      <span class="sh-pill ${x.status.cls}"><i></i>${esc(L(x.status.ar, x.status.en))}</span></div>
    <div class="sh-lv" style="--n:${cells.length}">${cells.map(([k, v, c]) => `<div><small>${esc(k)}</small><b class="mono ${c}">${esc(v)}</b></div>`).join('')}</div>
    ${x.note ? `<p class="sh-note">${icons.sparkle || ''}<span>${esc(x.note)}</span></p>` : ''}
    ${tr ? `<div class="sh-track" title="${esc(L('مكان السعر بين الوقف والهدف الأخير', 'Price between the stop and the last target'))}"><i class="sh-fill" style="--p:${pct(tr.price ?? tr.entry ?? 0)}"></i>${tr.entry != null ? `<em class="sh-entry" style="--p:${pct(tr.entry)}"></em>` : ''}${tr.price != null ? `<b class="sh-mark" style="--p:${pct(tr.price)}"></b>` : ''}</div>` : ''}
  </article>`;
}

export function renderAiSignal() {
  let p = { ...DEF, ...(storage.get(prefKey(), {}) || {}) };
  if (!STYLES[p.style]) p.style = DEF.style;
  // v249: the trading style chosen in the profile is the only style this page uses
  const lockStyle = (o) => { const ts = getTradingStyle(); if (ts && o.style !== ts) { o.style = ts; if (!STYLES[ts].tfs.includes(o.tf)) o.tf = defaultTf(ts); } return o; };
  lockStyle(p);
  if (!MARKETS[p.market]) p.market = DEF.market;
  const save = () => storage.set(prefKey(), p);
  let step = 0; let run = 0; let result = null; const wsaved = storage.get(watchKey(), null); let shown = -1; let dashFrom = 0; let btRun = 0;   // `shown`: the step on screen before this paint (for the slide direction)
  const still = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;

  const el = h(`<section class="subpage aisg page-enter"><div class="aisg-box" data-box></div></section>`);
  const box = el.querySelector('[data-box]');

  const bar = (n) => `<div class="aisg-steps" aria-hidden="true">${[1, 2, 3, 4].map((k) => `<i class="${k <= n ? 'on' : ''} ${k === n && n > Math.min(shown, 4) ? 'is-new' : ''}"></i>`).join('')}</div>`;
  const head = (n, title) => `<header class="aisg-head">${n > 1 ? `<button type="button" class="aisg-back" data-back aria-label="${esc(L('رجوع', 'Back'))}">${icons.arrow || '‹'}</button>` : ''}
    <div><small>${esc(L(`إعداد الذكاء · ${n}/4`, `INTELLIGENCE SETUP · ${n}/4`))}</small><b>${esc(title)}</b></div>
    ${n ? `<button type="button" class="aisg-x" data-reset aria-label="${esc(L('إلغاء', 'Cancel'))}">${icons.close || '×'}</button>` : ''}</header>${bar(n)}`;

  function paint() {
    lockStyle(p);   // v249: a style changed in the profile applies at once
    if (step === 0) box.innerHTML = intro();
    else if (step === 1) box.innerHTML = `${head(1, L('نوع السوق', 'Market type'))}<div class="aisg-body"><h2>${esc(L('اختار السوق', 'Select market type'))}</h2><p class="muted">${esc(L('بأي سوق بدك تتداول؟', 'Choose the market you want to trade in'))}</p>
      <div class="aisg-grid aisg-stagger">${Object.entries(MARKETS).map(([k, m]) => `<button type="button" class="aisg-tile ${p.market === k ? 'is-on' : ''}" data-market="${k}" data-accent="${k}">${CHECK}<span class="aisg-ic">${ic(m.icon)}</span><b>${esc(L(...MLABEL[k].name))}</b><small>${esc(L(...MLABEL[k].sub))}</small></button>`).join('')}</div></div>`;
    else if (step === 2) box.innerHTML = `${head(2, L('الرمز', 'Symbol'))}<div class="aisg-body"><h2>${esc(L('اختار الرمز', 'Pick the symbol'))}</h2><p class="muted">${esc(L(...MLABEL[p.market].name))}</p>
      <div class="aisg-syms aisg-stagger">${symbolsOf(p.market).map((s) => `<button type="button" class="aisg-sym ${p.symbol === s ? 'is-on' : ''}" data-sym="${s}"><span class="aisg-sym-dot"></span>${esc(pairName(s))}</button>`).join('')}</div></div>`;
    else if (step === 3) box.innerHTML = params();
    else if (step === 4) box.innerHTML = generating();
    else if (step === 6) box.innerHTML = chatView();
    else if (step === 7) box.innerHTML = dashHtml({ symbol: p.symbol, tf: p.tf });
    else if (step === 8) box.innerHTML = `${head(4, L('المراقبة التلقائية', 'Auto watch'))}<div class="aisg-body">${watchHtml()}<div class="aisg-actions aisg-stagger"><button type="button" class="btn btn-primary" data-again>${icons.refresh || ''}<span>${esc(L('توصية جديدة', 'New signal'))}</span></button></div></div>`;
    else box.innerHTML = card(result);
    el.classList.toggle('is-chat', step === 6);
    clearInterval(hubTimer);
    box.dataset.dir = step >= shown ? 'fwd' : 'back';
    restartClass(box, ['aisg-anim'], 'aisg-anim');   // replay the entrance on every step
    box.querySelectorAll('.aisg-stagger').forEach((g) => [...g.children].forEach((c, i) => c.style.setProperty('--i', i)));
    shown = step;
    wire();
    countUp();
    if (step === 6) { loadHub(); initChat(); }
  }

  /* ───────── Signal Hub: the user's saved signals, live ───────── */
  let hubIdx = 0; let hubTimer = null; let hubList = [];
  async function loadHub() {
    clearInterval(hubTimer);
    const sec = box.querySelector('[data-hub]'); if (!sec) return;
    const draw = (prices = {}) => {
      const { list, open } = hubItems(listTrades(), 12); hubList = list;
      if (!sec.isConnected) return;
      box.querySelectorAll('[data-side-n]').forEach((n) => { n.textContent = String(open); });
      if (sec.dataset.mode === 'list') { drawList(sec, list, open, prices); return; }
      if (!list.length) { sec.hidden = true; return; }
      hubIdx = Math.min(hubIdx, list.length - 1);
      const x = list[hubIdx];
      const note = `${SA(`style.${x.style}`)} · ${t(`perf.tfShort.${x.tf}`) || x.tf} · ${L('انحفظت', 'saved')} ${fmtTz(Math.round(x.savedAt / 1000), getLang())}${x.resultR != null ? ` · ${x.resultR > 0 ? '+' : ''}${fmtNum(x.resultR, 2)}R` : ''}`;
      sec.hidden = false;
      sec.innerHTML = `<header class="sh-head"><span class="sh-hic">${icons.radar || ''}</span><div><b>Signal Hub <em class="sh-live">${esc(L('مباشر', 'LIVE'))}</em></b><small>${esc(L('مساحة ذكاء السوق', 'Market intelligence workspace'))}</small></div>
        <div class="sh-nav"><span class="mono">${hubIdx + 1} / ${list.length}</span><button type="button" data-hub-prev aria-label="${esc(L('السابق', 'Previous'))}">${icons.arrow || '‹'}</button><button type="button" data-hub-next aria-label="${esc(L('التالي', 'Next'))}">${icons.arrow || '›'}</button></div></header>
        <div class="sh-prog"><i style="--p:${((hubIdx + 1) / list.length) * 100}%"></i><small>${esc(L(`${open} مفتوحة`, `${open} AVAILABLE`))}</small></div>
        <div class="sh-slide">${hubCard({ ...x, note, price: prices[x.symbol], status: signalStatus(x) })}</div>`;
      sec.querySelector('[data-hub-prev]').onclick = () => { hubIdx = (hubIdx - 1 + list.length) % list.length; draw(prices); };
      sec.querySelector('[data-hub-next]').onclick = () => { hubIdx = (hubIdx + 1) % list.length; draw(prices); };
    };
    draw();
    await pullTrades().catch(() => null);
    if (!sec.isConnected) return;
    const syms = [...new Set(hubList.map((x) => x.symbol))];
    let prices = {};
    const refresh = async () => {
      try { const tk = syms.length ? await getTickers(syms) : {}; prices = Object.fromEntries(Object.entries(tk || {}).filter(([, v]) => v?.mode === 'live' && Number.isFinite(v.price)).map(([k, v]) => [k, v.price])); hubPrices = prices; } catch { /* keep the last prices */ }
      if (sec.isConnected) draw(prices); else clearInterval(hubTimer);
    };
    await refresh();
    if (hubList.length) hubTimer = setInterval(() => { if (!sec.isConnected) { clearInterval(hubTimer); return; } if (sec.dataset.mode !== 'list' && !sec.matches(':hover')) hubIdx = (hubIdx + 1) % Math.max(1, hubList.length); refresh(); }, sec.dataset.mode === 'list' ? 15000 : 7000);
  }
  const hubNote = (x) => `${x.status === 'pending' ? `${L(`أمر معلّق، بيتفعّل تلقائيًا عند \u2066${priceText(x.symbol, x.entry, getInstrument(x.symbol)?.precision ?? 2)}\u2069`, `Pending, activates automatically at ${priceText(x.symbol, x.entry, getInstrument(x.symbol)?.precision ?? 2)}`)} · ` : ''}${SA(`style.${x.style}`)} · ${t(`perf.tfShort.${x.tf}`) || x.tf} · ${fmtTz(Math.round(x.savedAt / 1000), getLang())}${x.resultR != null ? ` · ${x.resultR > 0 ? '+' : ''}${fmtNum(x.resultR, 2)}R` : ''}`;
  // Side panel of the AI chat: every saved signal, open ones first, with the live price on each track.
  function drawList(sec, list, open, prices) {
    sec.hidden = false;
    const firstPaint = !sec.dataset.drawn; sec.dataset.drawn = '1';
    sec.innerHTML = `<header class="sh-head"><span class="sh-hic">${icons.radar || ''}</span><div><b>Signal Hub <em class="sh-live">${esc(L('مباشر', 'LIVE'))}</em></b><small>${esc(L(`${open} مفتوحة · ${list.length} بالمجموع`, `${open} open · ${list.length} total`))}</small></div></header>
      ${list.length ? `<div class="sh-stack ${firstPaint ? 'aisg-stagger is-first' : ''}">${list.map((x) => hubCard({ ...x, note: hubNote(x), price: prices[x.symbol], status: signalStatus(x) })).join('')}</div>`
        : `<div class="sh-empty">${icons.radar || ''}<b>${esc(L('ما في صفقات لسا', 'No trades yet'))}</b><p>${esc(L('اطلب توصية من سكالب أو سوينغ واكبس «احفظ + إشعارات»، وبتظهر هون.', 'Request a Scalp or Swing signal and tap “Save & alerts”; it shows up here.'))}</p></div>`}`;
    sec.querySelectorAll('.sh-stack.is-first > *').forEach((c, i) => c.style.setProperty('--i', i));
  }

  /* ───────── Alpha AI chat (Claude) with the user's trades as context ───────── */
  const chatKey = () => `ai-chat:${auth.current()?.uid || 'guest'}`;
  let chat = (storage.get(chatKey(), []) || []).filter((m) => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string').slice(-40);
  let chatBusy = false;
  const CHIPS = () => [
    L('شو وضع صفقاتي المفتوحة؟', 'How are my open trades doing?'),
    L('وين أحط الستوب بعد TP1؟', 'Where should my stop go after TP1?'),
    L('اشرحلي آخر توصية', 'Explain my last signal'),
    L('كيف أدير المخاطرة بحساب 1000$؟', 'How do I manage risk on a $1,000 account?'),
  ];
  function chatView() {
    return `<header class="aisg-head aic-head"><button type="button" class="aisg-back" data-back aria-label="${esc(L('رجوع', 'Back'))}">${icons.arrow || '‹'}</button>
      <span class="aic-avatar">${icons.sparkle || ''}</span><div><small>Claude · ${esc(tzOffset())}</small><b>Alpha AI</b></div>
      <button type="button" class="aic-tbtn" data-side>${icons.radar || ''}<span>${esc(L('صفقاتي', 'My trades'))}</span><em data-side-n>0</em></button></header>
      <div class="aic">
        <div class="aic-main">
          <div class="aic-log" data-log aria-live="polite"></div>
          <div class="aic-chips" data-chips>${CHIPS().map((c) => `<button type="button" class="aic-chip" data-chip>${esc(c)}</button>`).join('')}</div>
          <form class="aic-form" data-chat><textarea name="m" rows="1" maxlength="1500" placeholder="${esc(L('اسأل عن السوق أو صفقاتك…', 'Ask anything about the market or your trades…'))}"></textarea>
            <button type="submit" class="aic-send" aria-label="${esc(L('إرسال', 'Send'))}">${icons.send || '➤'}</button></form>
          <p class="aisg-fine">${esc(L('الـ AI ممكن يغلط. هاي مش نصيحة مالية، فاتأكد من السوق قبل ما تتداول.', 'The AI can make mistakes. Not financial advice; check market conditions before trading.'))}</p>
        </div>
        <aside class="aic-side" data-sidepanel aria-label="${esc(L('صفقاتي', 'My trades'))}"><div class="aic-side-top"><b>${esc(L('الصفقات اللي داخلها', 'Trades you are in'))}</b><button type="button" class="aisg-x" data-side-close aria-label="${esc(L('سكّر', 'Close'))}">${icons.close || '×'}</button></div>
          <section class="sh sh-list" data-hub data-mode="list"></section></aside>
        <div class="aic-scrim" data-side-close></div>
      </div>`;
  }
  function chatContext() {
    const { list, open } = hubItems(listTrades(), 12);
    const pr = (v) => (Number.isFinite(v) ? Number(v) : null);
    const last = result?.reading?.plan ? { symbol: result.symbol, timeframe: result.tf, verdict: result.reading.verdict, direction: result.reading.plan.direction, entry: pr(result.reading.plan.entry), stop: pr(result.reading.plan.stop), targets: result.reading.plan.targets, orderType: result.reading.plan.execution } : null;
    return {
      page: 'ai-trading-chat', timezone: tzLabel(), now: fmtTz(Math.floor(Date.now() / 1000), 'en'), mode: 'live', engine: ENGINE_VERSION, promptVersion: PROMPT_VERSION,
      strategies: STRATEGIES.map((x) => ({ id: x.id, status: x.status.toUpperCase() })),
      backtests: backtests().slice(0, 2).map((b) => ({ symbol: b.symbol, tf: b.tf, bars: b.bars, costPct: b.costPct, test: Object.fromEntries(Object.entries(b.strategies || {}).filter(([, v]) => v.test).map(([k, v]) => [k, { n: v.test.n, expectancyR: v.test.expectancy, winRate: v.test.winRate, profitFactor: v.test.profitFactor, meetsLive: v.meetsLive }])) })),
      openTrades: open,
      myTrades: list.map((x) => ({ symbol: x.symbol, timeframe: x.tf, style: x.style, direction: x.direction, status: x.status, targetsHit: x.hits, entry: pr(x.entry), stop: pr(x.stop), targets: x.targets, resultR: x.resultR ?? null, saved: fmtTz(Math.round(x.savedAt / 1000), 'en'), livePrice: pr(hubPrices[x.symbol]) })),
      lastSignal: last,
      note: 'Trades and prices come from the site (saved signals tracked on real prices). The stop moves to entry after TP1. PAPER strategies are research only; LSTM is disabled.',
    };
  }
  let hubPrices = {};
  function initChat() {
    const log = box.querySelector('[data-log]'); const form = box.querySelector('[data-chat]'); if (!log || !form) return;
    const ta = form.m;
    const bubble = (role, text, cls = '') => {
      const b = document.createElement('div'); b.className = `aic-msg is-${role} ${cls}`;
      b.innerHTML = `${role === 'assistant' ? `<span class="aic-mini">${icons.sparkle || ''}</span>` : ''}<p></p>`;
      b.querySelector('p').textContent = text; log.appendChild(b); log.scrollTop = log.scrollHeight; return b;
    };
    const hello = L(`أهلا! أنا Alpha AI. بشوف صفقاتك المحفوظة وأسعارها، وبجاوبك عن السوق والمخاطرة والتوقيت (${tzOffset()}). شو بدك تعرف؟`, `Hi! I am Alpha AI. I can see your saved trades and their prices, and answer about the market, risk and timing (${tzOffset()}). What would you like to know?`);
    bubble('assistant', hello, 'is-hello');
    chat.forEach((m) => bubble(m.role, m.content));
    box.querySelector('[data-chips]').hidden = chat.length > 0;
    const grow = () => { ta.style.height = 'auto'; ta.style.height = `${Math.min(140, ta.scrollHeight)}px`; };
    ta.addEventListener('input', grow);
    // voice message: speak instead of typing (the words go into the box and are sent when you stop)
    const sendBtn = form.querySelector('.aic-send');
    sendBtn.before(micButton(ta, { lang: getLang, autoSend: () => form.requestSubmit(), label: L('رسالة صوتية', 'Voice message') }));
    ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); } });
    const send = async (q) => {
      q = String(q || '').trim(); if (!q || chatBusy) return;
      chatBusy = true; form.classList.add('is-busy'); box.querySelector('[data-chips]').hidden = true;
      chat.push({ role: 'user', content: q }); const ub = bubble('user', q);
      const typing = bubble('assistant', '', 'is-typing'); typing.querySelector('p').innerHTML = '<i></i><i></i><i></i>';
      try {
        const reply = await sendAiMessage(chat.slice(-16), chatContext(), getLang());
        typing.remove(); chat.push({ role: 'assistant', content: reply }); bubble('assistant', reply, 'is-new');
      } catch (err) {
        typing.remove(); chat.pop();
        const msg = err?.code && /^[a-z_]+$/.test(err.code) ? aiErrorText(err.code) : L('ما قدرنا نوصل للـ AI هلق.', 'Could not reach the AI right now.');
        const eb = bubble('assistant', msg, 'is-error');
        const rb = document.createElement('button'); rb.type = 'button'; rb.className = 'btn btn-sm'; rb.textContent = L('جرّب كمان مرة', 'Retry');
        rb.onclick = () => { eb.remove(); ub.remove(); send(q); }; eb.appendChild(rb);
      } finally {
        chatBusy = false; form.classList.remove('is-busy');
        try { storage.set(chatKey(), chat.slice(-40)); } catch { /* */ }
      }
    };
    form.addEventListener('submit', (e) => { e.preventDefault(); const q = ta.value; ta.value = ''; grow(); send(q); });
    box.querySelectorAll('[data-chip]').forEach((c) => c.addEventListener('click', () => send(c.textContent)));
    const side = box.querySelector('[data-sidepanel]');
    const setSide = (on) => { box.querySelector('.aic')?.classList.toggle('side-open', on); };
    box.querySelector('[data-side]')?.addEventListener('click', () => setSide(!box.querySelector('.aic')?.classList.contains('side-open')));
    box.querySelectorAll('[data-side-close]').forEach((b) => b.addEventListener('click', () => setSide(false)));
    void side;
  }
  // Money values on the result card count up once (the final text is already in the DOM, so nothing depends on it).
  function countUp() {
    if (still()) return;
    box.querySelectorAll('[data-count]').forEach((b) => {
      const to = Number(b.dataset.count); if (!Number.isFinite(to)) return;
      const d = Number(b.dataset.dec) || 0; const pre = b.dataset.pre || ''; const final = b.textContent; const t0 = performance.now(); const dur = 900;
      const tick = (now) => { const k = Math.min(1, (now - t0) / dur); const e = 1 - (1 - k) ** 3; b.textContent = `${pre}${fmtNum(to * e, d)}`; if (k < 1 && b.isConnected) requestAnimationFrame(tick); else b.textContent = final; };
      requestAnimationFrame(tick);
    });
  }
  // A choice animates (press + ripple, the others fade) before the next step slides in.
  function pick(btn, ev, next) {
    if (still()) { next(); return; }
    const r = btn.getBoundingClientRect(); const x = (ev?.clientX ?? r.left + r.width / 2) - r.left; const y = (ev?.clientY ?? r.top + r.height / 2) - r.top;
    const rip = document.createElement('span'); rip.className = 'aisg-ripple'; rip.style.left = `${x}px`; rip.style.top = `${y}px`; btn.appendChild(rip);
    btn.classList.add('is-picked'); btn.parentElement?.classList.add('has-pick');
    box.style.pointerEvents = 'none';
    setTimeout(() => { box.style.pointerEvents = ''; next(); }, 320);
  }

  function intro() {
    const cards = [
      ['scalp', 'bolt', L('سكالب', 'Scalp'), L('صفقات سريعة على فريم 1–15 دقيقة، بتتسكّر بنفس اليوم.', 'Quick trades on 1–15 minute charts, closed the same day.')],
      ['swing', 'trend', L('سوينغ', 'Swing'), L('صفقات على فريم ساعة لـ يوم، بتطوّل من يوم لكم يوم.', 'Trades on 1h–1D charts that run from a day to a few days.')],
    ].filter(([k]) => !getTradingStyle() || k === getTradingStyle());   // v249: only the style chosen in the profile
    return `<div class="aisg-hero"><span class="aisg-eye"><i class="aisg-ring"></i><i class="aisg-ring r2"></i>${icons.eye || ''}</span><h1>${esc(L('مساعد التداول بالذكاء الاصطناعي', 'AI Powered Trading Co-Pilot'))}</h1><p class="muted">${esc(L('اختار نوع الصفقة لنبلّش.', 'Pick your specialist to begin.'))}</p>${getTradingStyle() ? `<p class="aisg-meta aisg-style-lock">${esc(L(`أسلوبك من البروفايل: ${getTradingStyle() === 'scalp' ? 'سكالب' : 'سوينغ'}, التوصيات بتلتزم فيه بس.`, `Your style from the profile: ${getTradingStyle() === 'scalp' ? 'Scalping' : 'Swing'}, recommendations follow it only.`))} <a href="#/app/profile">${esc(L('غيّره', 'Change'))}</a></p>` : `<p class="aisg-meta aisg-style-lock">${esc(L('حدّد أسلوب تداولك من البروفايل لتلتزم التوصيات فيه.', 'Set your trading style in the profile so recommendations follow it.'))} <a href="#/app/profile">${esc(L('البروفايل', 'Profile'))}</a></p>`}</div>
      <div class="aisg-grid aisg-grid-2 aisg-stagger">${cards.map(([k, i, n, d]) => `<button type="button" class="aisg-tile aisg-spec ${p.style === k ? 'is-on' : ''}" data-style="${k}" data-accent="${k}">${CHECK}<span class="aisg-ic">${ic(i)}</span><b>${esc(n)}</b><small>${esc(d)}</small></button>`).join('')}
        <button type="button" class="aisg-tile aisg-spec aisg-ai-tile" data-ai data-accent="ai"><span class="aisg-ic">${icons.brain || icons.sparkle || ''}</span><span class="aisg-ai-t"><b>AI <em>Claude</em></b><small>${esc(L('احكي مع مساعد التداول، وشوف صفقاتك اللي داخلها على جنب.', 'Chat with the trading assistant and see the trades you are in on the side.'))}</small></span><span class="aisg-ai-go">${icons.arrow || '›'}</span></button></div>
      <div class="aisg-actions"><button type="button" class="btn btn-ghost btn-sm" data-dash>${icons.chart || icons.trend || ''}<span>${esc(L('لوحة الأداء', 'Performance'))}</span></button></div>
      <p class="aisg-fine">${esc(L('التوصية بتطلع من محرك الموقع (SMC/ICT، تتبّع الاتجاه، الارتداد للمتوسط) على أسعار حية، والـ AI بيشرحها. مش نصيحة مالية، والتداول فيه مخاطرة عالية.', 'The plan comes from the site\'s engine (SMC/ICT, trend following, mean reversion) on live prices; the AI explains it. Not financial advice, trading involves significant risk.'))}</p>`;
  }

  function params() {
    const tfs = STYLES[p.style].tfs;
    const inst = getInstrument(p.symbol); const type = inst?.type || 'crypto';
    const sub_ = SUBNAME[p.symbol] ? L(...SUBNAME[p.symbol]) : L(...(MLABEL[p.market]?.name || MLABEL.crypto.name));
    return `${head(3, L('إعدادات الصفقة', 'Trade parameters'))}<form class="aisg-body aisg-form aisg-stagger" data-form>
      <h2>${esc(L('شكّل صفقتك', 'Shape your trade'))}</h2><p class="muted">${esc(L('جهّز ملخص الذكاء لـ', 'Configure the intelligence brief for'))} <b class="aisg-hl">${esc(pairName(p.symbol))}</b></p>
      <div class="aisg-symrow"><span class="sh-ic" data-accent="${type === 'energy' ? 'metal' : type}">${ic(MKT_ICON[type] || 'sparkle')}</span><div><b class="mono">${esc(pairName(p.symbol))}</b><small>${esc(sub_)}</small></div><span class="aisg-tag">${esc(SA(`style.${p.style}`))}</span></div>
      <label class="aisg-f"><span>${icons.wallet || ''}${esc(SA('account.label'))}</span><select class="input" name="account">${Object.keys(ACCOUNTS).map((k) => `<option value="${k}" ${p.account === k ? 'selected' : ''}>${esc(SA(`account.${k}`))}</option>`).join('')}</select></label>
      <div class="aisg-row">
        <label class="aisg-f"><span>$ ${esc(L('رأس المال (دولار)', 'Trade capital (USD)'))}</span><input class="input mono" name="capital" inputmode="decimal" value="${esc(String(p.capital))}" required></label>
        <label class="aisg-f"><span>${icons.shield || ''}${esc(L('المخاطرة %', 'Risk %'))}</span><input class="input mono" name="riskPct" inputmode="decimal" value="${esc(String(p.riskPct))}" required></label>
      </div>
      <div class="aisg-f"><span>${icons.store || ''}${esc(L('نوع الأمر', 'Order type'))}</span><div class="aisg-otype">${OTYPES().map(([k, i, n, d]) => `<button type="button" class="aisg-opt ${p.execution === k ? 'is-on' : ''}" data-exec="${k}"><span class="aisg-opt-ic">${icons[i] || ''}</span><span class="aisg-opt-t"><b>${esc(n)}</b><small>${esc(d)}</small></span></button>`).join('')}</div>
        <p class="aisg-onote" data-onote>${icons.sparkle || ''}<span>${esc(ONOTE()[p.execution] || '')}</span></p></div>
      <div class="aisg-f"><span>${icons.candles || ''}${esc(L('الفريم', 'Timeframe'))}</span><div class="aisg-seg">${tfs.map((k) => `<button type="button" class="${p.tf === k ? 'is-on' : ''}" data-tf="${k}">${esc(t(`perf.tfShort.${k}`) || k)}</button>`).join('')}</div></div>
      <details class="aisg-f aisg-adv"><summary>${icons.shield || ''}${esc(L('إعدادات المخاطرة والتأكيد', 'Risk & confirmation settings'))}</summary>
        <div class="aisg-row">
          <label class="aisg-f"><span>${esc(L('حد الخسارة اليومي %', 'Daily loss limit %'))}</span><input class="input mono" name="dailyLossPct" inputmode="decimal" value="${esc(String(riskSettings(p).dailyLossPct))}"></label>
          <label class="aisg-f"><span>${esc(L('أقصى صفقات مفتوحة', 'Max open trades'))}</span><input class="input mono" name="maxOpen" inputmode="numeric" value="${esc(String(riskSettings(p).maxOpen))}"></label>
        </div>
        ${LTF[p.tf] ? `<label class="checkbox aisg-ltf"><input type="checkbox" name="ltf" ${p.ltf ? 'checked' : ''}><span>${esc(L(`تأكيد SMC من فريم ${LTF[p.tf]} قبل دخول الماركت`, `Confirm SMC market entries on ${LTF[p.tf]} first`))}</span></label>` : ''}
        <p class="aisg-meta">${esc(L(`نفس الحدود لكل المحرك: توقف بعد ${RISK.pauseAfterLosses.def} خسارات ورا بعض، مجموع المخاطرة المفتوحة ≤ ${RISK.maxOpenRiskPct}%، ونفس فئة السوق ≤ ${RISK.maxAssetRiskPct}%.`, `One set of limits for the whole engine: pause after ${RISK.pauseAfterLosses.def} losses in a row, total open risk ≤ ${RISK.maxOpenRiskPct}%, one asset class ≤ ${RISK.maxAssetRiskPct}%.`))}</p></details>
      <p class="aisg-tz">${icons.globe || ''}<span>${esc(L('المنطقة الزمنية:', 'Timezone:'))} <b class="mono">${esc(tzLabel())}</b></span></p>
      <button type="submit" class="btn btn-primary aisg-go">${icons.sparkle || ''}<span>${esc(L('اطلب التوصية', 'Generate signal'))}</span></button>
    </form>`;
  }

  const STAGES = () => [
    ['connect', L('الاتصال بالبورصة…', 'Connecting to exchange…')],
    ['candles', L('جلب الشموع الحية…', 'Fetching live candles…')],
    ['htf', L('قراءة الفريمات الأعلى…', 'Reading higher timeframes…')],
    ['ind', L('حساب RSI و ATR والهيكل…', 'Calculating RSI, ATR & structure…')],
    ['news', L('فحص الأخبار الاقتصادية…', 'Checking economic news…')],
    ['plan', L('بناء خطة الصفقة…', 'Building the trade plan…')],
    ['ai', L('شرح الذكاء الاصطناعي…', 'AI explanation…')],
  ];
  function generating() {
    return `${head(4, L('جاري التحليل…', 'Generating…'))}<div class="aisg-body aisg-gen">
      <div class="aisg-orb"><i class="aisg-orb-ring"></i><i class="aisg-orb-scan"></i><span>${icons.sparkle || ''}</span></div>
      <p class="muted">${esc(L('عم نحلّل', 'Analyzing'))}</p><h2 class="aisg-pair">${esc(pairName(p.symbol))}</h2>
      <div class="aisg-genbar"><i data-genbar></i><b class="mono" data-genpct>0%</b></div>
      <ul class="aisg-stages aisg-stagger">${STAGES().map(([k, txt]) => `<li data-st="${k}"><span class="aisg-dot"></span><div><b>${esc(txt)}</b><small data-note></small></div></li>`).join('')}</ul>
      <p class="aisg-fine">${esc(L('كل سطر بيتعلّم لما الخطوة تخلص فعلًا.', 'Each line is ticked only when that step is really done.'))}</p></div>`;
  }
  // The analysis runs at full speed; only its DISPLAY is paced: every stage is shown working for a moment, then its
  // real result is typed in, and the bar / percentage climb smoothly. Nothing is invented or delayed in the result itself.
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const RUN_MS = () => (still() ? 0 : 1000); const GAP_MS = () => (still() ? 0 : 260);
  let markQ = Promise.resolve(); let pctNow = 0; let pctRaf = 0;
  function setPct(target) {
    const barEl = box.querySelector('[data-genbar]'); const pctEl = box.querySelector('[data-genpct]');
    if (barEl) barEl.style.width = `${target}%`;
    if (!pctEl) return;
    cancelAnimationFrame(pctRaf);
    if (still()) { pctNow = target; pctEl.textContent = `${target}%`; return; }
    const from = pctNow; const t0 = performance.now(); const dur = 1400;
    const tick = (now) => { const k = Math.min(1, (now - t0) / dur); const e = 1 - (1 - k) ** 3; pctNow = Math.round(from + (target - from) * e); pctEl.textContent = `${pctNow}%`; if (k < 1 && pctEl.isConnected) pctRaf = requestAnimationFrame(tick); };
    pctRaf = requestAnimationFrame(tick);
  }
  function typeNote(el, text) {
    if (!el) return Promise.resolve();
    if (still() || !text) { el.textContent = text; return Promise.resolve(); }
    el.textContent = ''; const chars = [...text]; const step = Math.max(8, Math.min(28, 520 / chars.length)); let i = 0;
    return new Promise((res) => { const tick = () => { if (!el.isConnected) return res(); el.textContent = chars.slice(0, ++i).join(''); if (i < chars.length) setTimeout(tick, step); else res(); }; tick(); });
  }
  async function applyMark(k, state, note) {
    const li = box.querySelector(`[data-st="${k}"]`); if (!li) return;
    if (state === 'run') { if (!li.classList.contains('is-run')) { li.className = 'is-run'; li.dataset.t0 = String(Date.now()); } return; }
    if (!li.classList.contains('is-run')) { li.className = 'is-run'; li.dataset.t0 = String(Date.now()); }
    const shown = Date.now() - Number(li.dataset.t0 || 0); if (shown < RUN_MS()) await wait(RUN_MS() - shown);
    if (!li.isConnected) return;
    li.className = `is-${state}`;
    const all = box.querySelectorAll('[data-st]').length; const done = box.querySelectorAll('[data-st].is-done, [data-st].is-skip').length;
    setPct(Math.round((done / Math.max(1, all)) * 100));
    await typeNote(li.querySelector('[data-note]'), note);
    await wait(GAP_MS());
    // the next stage starts working on screen as soon as this one is ticked
    const next = li.nextElementSibling; if (next && !next.className && state !== 'fail') { next.className = 'is-run'; next.dataset.t0 = String(Date.now()); }
  }
  const mark = (k, state, note = '') => { markQ = markQ.then(() => applyMark(k, state, note)).catch(() => {}); return markQ; };
  const markOut = mark;

  /* ───────── v244 automatic watch ───────── */
  function stopWatch() { watchStopFn?.(); }
  function watchText() {
    const w = watchInfo; if (!w) return '';
    const last = w.at ? new Date(w.at).toLocaleTimeString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { hour: '2-digit', minute: '2-digit' }) : '…';
    return L(`\u2066${pairName(w.base.symbol)}\u2069${w.syms.length > 1 ? ` ومعه ${w.syms.length - 1} رموز تانية من نفس السوق` : ''} · فريم ${t(`perf.tfShort.${w.base.tf}`) || w.base.tf} · ${w.checks} فحص · آخر فحص ${last}`,
      `${pairName(w.base.symbol)}${w.syms.length > 1 ? ` + ${w.syms.length - 1} more in the same market` : ''} · ${t(`perf.tfShort.${w.base.tf}`) || w.base.tf} · ${w.checks} checks · last ${last}`);
  }
  function watchHtml() {
    if (!watchInfo || !watchStopFn || !OWN()) return '';
    return `<div class="aisg-exec is-watch aisg-stagger" data-watch><span class="aisg-watch-dot" aria-hidden="true"></span><p><b>${esc(L('المراقبة التلقائية شغّالة', 'Auto watch is on'))}</b> · <span data-watch-txt>${esc(watchText())}</span><br><small>${esc(L('بنفحص مع كل شمعة جديدة بنفس الشروط بالزبط. أول ما تكتمل الشروط على أي رمز، الصفقة بتنفتح وبتنحفظ لحالها وبيوصلك إشعار. بتضل شغّالة طول ما الموقع مفتوح.', 'Checked on every new candle with exactly the same conditions. The moment they are all met on any symbol, the trade opens, is saved and you get an alert. Runs while the site is open.'))}</small></p><button type="button" class="btn btn-ghost btn-sm" data-watch-stop>${esc(L('إيقاف', 'Stop'))}</button></div>`;
  }
  function paintWatch() { const n = box.querySelector('[data-watch-txt]'); if (n && el.isConnected) n.textContent = watchText(); }
  function startWatch(base) {
    stopWatch(); base = lockStyle({ ...base });
    const myGen = ++watchGen; const tfSec = TIMEFRAMES.find((x) => x.id === base.tf)?.seconds || 900;
    const syms = [base.symbol, ...symbolsOf(base.market).filter((s) => s !== base.symbol)];
    const w = { base, syms, checks: 0, at: 0, last: {} }; watchInfo = w;
    storage.set(watchKey(), { base, since: Date.now() });
    const stop = () => { if (myGen !== watchGen) return; watchGen += 1; clearTimeout(watchTimer); watchStopFn = null; watchInfo = null; storage.set(watchKey(), null); };
    watchStopFn = stop;
    const found = (res) => {
      stop();
      const r = res.reading;
      if (!isDuplicate(listTrades(), { symbol: res.symbol, strategy: r.strategy || 'smc', direction: r.plan.direction, entry: r.plan.entry, atr: r.atr })) { saveTrade(r, r.ctx); res.autoSaved = true; }
      const dir = r.plan.direction === 'long' ? L('شراء', 'BUY') : L('بيع', 'SELL');
      const px = (x) => priceText(res.symbol, x, res.prec);
      pushNotify(`${L('صفقة AI جديدة', 'New AI trade')} · ${pairName(res.symbol)}`, `${dir} · ${L('دخول', 'Entry')} ${px(r.plan.entry)} · ${L('وقف', 'Stop')} ${px(r.plan.stop)} · TP ${r.plan.targets.map(px).join(' / ')}`, `ai-watch-${res.symbol}`).catch(() => {});
      if (el.isConnected && [0, 5, 8].includes(step)) { result = res; step = 5; paint(); }
    };
    const tick = async () => {
      if (myGen !== watchGen) return;
      const bar = Math.floor(Date.now() / 1000 / tfSec);
      for (const s of syms) {
        if (myGen !== watchGen) return;
        if (w.last[s] === bar) continue;
        let res = null; try { res = await generate({ silent: true, pp: { ...base, symbol: s } }); } catch { res = null; }
        if (myGen !== watchGen) return;
        w.last[s] = bar; w.checks += 1; w.at = Date.now(); paintWatch();
        if (res) { found(res); return; }
        await new Promise((r) => setTimeout(r, 300));
      }
      watchTimer = setTimeout(tick, 20_000);
    };
    tick();
  }
  const afterMarks = (fn, ms = 700) => { markQ.then(() => wait(still() ? 0 : ms)).then(fn); };

  // What the AI gets: the site's numbers plus the clock it must use (UTC+03:00) and the plan's times already written in it.
  function aiBrief(reading, pp = p) {
    const c = aiContext(reading, reading.ctx);
    const orderNote = reading.plan?.execution === 'market' ? `Market order: fills at the current live price ${reading.plan.entry} (slippage at most ${MARKET_TOL_PTS} points).` : reading.plan?.execution === 'limit' ? `Pending limit order at ${reading.plan.entry}: it activates automatically when price reaches that level; no trade is open before that.` : null;
    const ex = reading.exec;
    return { ...c, engine: result?.multi ? engineBrief(result.multi) : undefined, orderNote, timezone: tzLabel(), times: { now: fmtTz(Math.floor(Date.now() / 1000), 'en'), lastCandle: fmtTz(reading.plan?.createdAt, 'en') || null, validUntil: reading.plan?.execution === 'limit' ? fmtTz(reading.plan.validUntil, 'en') : null },
      strategy: reading.strategy ? { id: reading.strategy, status: statusOf(reading.strategy).toUpperCase() } : null,
      execution: ex ? { type: ex.type, why: ex.why, note: reading.execNote || null, distance: ex.dist || null, expiryBars: ex.expiry?.bars ?? null, quote: reading.quote || null, spreadEstimated: reading.cost?.estimated ?? true, costPct: reading.cost?.totalPct ?? null, costR: reading.plan?.costR ?? null, rrAfterCosts: reading.plan?.rrNet ?? null } : null,
      wait: reading.waitReason || null, quality: reading.quality ?? null, htfConflict: reading.htfConflict || 'none', data: reading.data || null,
      paper: (result?.paper || []).filter((x) => x.status === 'signal').map((x) => ({ id: x.id, status: 'PAPER', direction: x.signal.direction })),
      backtest: (() => { const b = backtests().find((x) => x.symbol === pp.symbol && x.tf === pp.tf); const v = b?.strategies?.[reading.strategy]; return v?.test ? { strategy: reading.strategy, bars: b.bars, from: fmtTz(b.from, 'en'), to: fmtTz(b.to, 'en'), costPct: b.costPct, test: v.test, meetsLive: v.meetsLive } : null; })(),
      engineVersion: ENGINE_VERSION, promptVersion: PROMPT_VERSION };
  }

  // Live quote (v234): Binance gives a real bid / ask (book ticker); the other feeds give a last price only → the spread is
  // marked "estimated". A quote older than two minutes is not the current price.
  async function quoteOf(inst, pp = p) {
    let price = null, bid = null, ask = null, at = Date.now(), source = null;
    try { const tk = (await getTickers([pp.symbol]))?.[pp.symbol]; if (tk?.mode === 'live' && Number.isFinite(tk.price)) { price = tk.price; source = tk.source || null; if (Number.isFinite(tk.at)) at = tk.at; } } catch { /* no ticker */ }
    if (inst?.provider === 'binance') {
      try { const b = await binanceGet(`/api/v3/ticker/bookTicker?symbol=${encodeURIComponent(pp.symbol)}`); const bb = Number(b?.bidPrice), aa = Number(b?.askPrice); if (bb > 0 && aa >= bb) { bid = bb; ask = aa; if (price == null) { price = (bb + aa) / 2; at = Date.now(); } } } catch { /* book ticker unavailable */ }
    }
    if (!(price > 0)) return null;
    return { price, bid, ask, at, source, spreadPct: bid && ask ? Math.round((((ask - bid) / ((ask + bid) / 2)) * 100) * 10000) / 10000 : null };
  }

  // Multi-strategy engine (services/multiStrategy.js): all modules on the closed candles, plus a related market for the
  // statistics module when one is defined, plus the user's own recent results for the loss limits. v234: the «توصية AI»
  // options (tiered SMC, mean-reversion state filters, no-chase, quality), ONE set of risk limits and the real cost model.
  async function runEngine({ ds, tfSec, htf, reading, cal, inst, asset, open, cost, risk, extra, quote, pp = p }) {
    const nowS = Date.now() / 1000;
    const closed = ds.candles.filter((c) => c.time + tfSec <= nowS + 1);
    let peer = null; const ps = PEER[pp.symbol];
    if (ps) {
      try {
        const pd = await Promise.race([getHistory(ps, pp.tf, 600), new Promise((_, no) => setTimeout(() => no(new Error('timeout')), 8000))]);
        if (pd?.mode === 'live' && pd.candles?.length) peer = { symbol: ps, candles: pd.candles };
      } catch { /* the statistics module then shows "no synchronized data" */ }
    }
    const done = listTrades().filter((x) => x.mode === 'live' && Number.isFinite(x.resultR) && x.closedAt).sort((a, b) => a.closedAt - b.closedAt);
    // v248: the loss-streak pause only looks at the last RISK.pauseHours — before, two old losses paused the engine for ever
    // (no new trade could ever end the streak, so every request answered NO TRADE)
    const recentResults = recentResultsFor(done, Date.now(), RISK.pauseHours);
    return runAllStrategies({
      symbol: pp.symbol, inst, tf: pp.tf, tfSec, candles: closed, mode: ds.mode, htf, reading, calendar: cal, peer, nowMs: Date.now(),
      spread: quote?.spreadPct != null ? { bidAskPct: quote.spreadPct } : null,
      // each strategy is independent: an open trade from one strategy never blocks another strategy on the same market
      account: { todayLossPct: todayLossPct(), recentResults, openSameSymbol: open.filter((x) => x.symbol === pp.symbol).length, openByStrategy: open.filter((x) => x.symbol === pp.symbol).reduce((a, x) => { const k = x.strategy || 'smc'; a[k] = (a[k] || 0) + 1; return a; }, {}), riskPct: pp.riskPct },
      sizeFor: (plan) => sizePosition({ capital: reading.inputs?.capital ?? pp.capital, riskPct: reading.inputs?.riskPct ?? pp.riskPct, entry: plan.entry, stop: plan.stop, account: reading.inputs?.account ?? pp.account, leverage: reading.inputs?.leverage, asset, symbol: pp.symbol, targets: plan.targets }),
    }, pageEngineCfg({ base: presetCfg(engineMode()), style: pp.style, costPct: cost.totalPct, risk, extra }));
  }

  const WAIT_TEXT = (r, x) => ({
    too_far_atr: L(`منطقة الدخول بعيدة عن السعر (${fmtNum(x?.dist?.atr, 2)} ATR، الحد ${x?.limits?.atr} ATR)، أمر معلّق هناك مش واقعي.`, `The entry zone is far from price (${fmtNum(x?.dist?.atr, 2)} ATR, limit ${x?.limits?.atr} ATR), a pending order there is not realistic.`),
    too_far_pct: L(`منطقة الدخول بعيدة عن السعر (${fmtNum(x?.dist?.pct, 2)}%، الحد ${x?.limits?.pct}%).`, `The entry zone is far from price (${fmtNum(x?.dist?.pct, 2)}%, limit ${x?.limits?.pct}%).`),
    chase: L(`السعر ابتعد عن نقطة دخول الاستراتيجية (${fmtNum(x?.dist?.atr, 2)} ATR)، دخول ماركت هلق ملاحقة للسعر.`, `Price moved away from the strategy entry (${fmtNum(x?.dist?.atr, 2)} ATR), a market entry now would chase it.`),
    smc_zone: L('الدخول من منطقة SMC بأمر معلّق بس؛ ما بنحوّله لماركت لأنه السعر قرّب.', 'SMC enters from its zone with a pending order only; it is not turned into a market order because price is close.'),
  })[r] || null;
  const NOT_TEXT = (r) => ({
    no_price: L('ما قدرنا نجيب السعر الحالي بالضبط، فما في دخول ماركت. جرّب كمان شوي أو اختار ليميت.', 'Could not get the exact current price, so there is no market entry. Try again shortly or use a limit order.'),
    past_stop: L('السعر الحالي تخطّى الوقف، فالدخول ماركت هلق غلط.', 'The current price is already past the stop, so a market entry now is wrong.'),
    past_tp1: L('السعر الحالي وصل الهدف الأول قبل الدخول، ففاتت الفرصة كماركت.', 'The current price already reached TP1 before entry, so the market entry is gone.'),
    rr_low: L('على السعر الحالي العائد للمخاطرة بعد التكاليف صار أقل من الحد.', 'At the current price the reward-to-risk after costs is below the minimum.'),
    no_level: L('الاستراتيجية ما إلها مستوى أمر معلّق منطقي هلق.', 'The strategy has no logical pending-order level right now.'),
    wrong_side: L('مستوى الأمر المعلّق بالجهة الغلط من السعر.', 'The pending level is on the wrong side of price.'),
    stop_too_close: L('مستوى الأمر المعلّق قريب كتير من الوقف.', 'The pending level is too close to the stop.'),
    target_behind: L('الهدف ورا مستوى الدخول.', 'A target is behind the entry.'),
  })[r] || r;

  // The engine's decision becomes the page's verdict: NO TRADE when nothing qualified or a global filter failed; otherwise the
  // qualified strategy's own levels, run through the execution layer (Market / Limit, distance, expiry, costs, no chase).
  function applyEngine(reading, multi, ds, tfSec, asset, ctx) {
    const pp = ctx.pp || p;
    // What the engine learned from its own closed results (services/learning.js). v234: a context is only avoided after at
    // least 20 real results there (no conclusion from a handful); the learning never touches the risk limits.
    const learned = [];
    if (multi.trades?.length) {
      multi.trades = multi.trades.filter((x) => { const c = learnCheck(x.id, { ...(x.ctx || {}), direction: x.direction, symbol: pp.symbol }, x.plan.rrMain, multi.minRR || 0, { minGroupN: 20 }); if (!c.ok) learned.push(c.why === 'rr' ? L(`${x.id}: العائد ${c.rr} أقل من الحد اللي تعلّمه المحرك (${c.need})`, `${x.id}: R:R ${c.rr} below the learned minimum (${c.need})`) : L(`${x.id}: المحرك تعلّم إنه «${c.feature}» خسرانة لهالاستراتيجية (${c.block?.n ?? '?'} نتيجة)`, `${x.id}: the engine learned that “${c.feature}” loses for this strategy (${c.block?.n ?? '?'} results)`)); return c.ok; });
      if (learned.length && !multi.trades.length) { multi.final = 'no_trade'; multi.reason = 'learned'; multi.pick = null; }
    }
    reading.engine = { final: multi.final, pick: multi.pick?.id || null };
    reading.htfConflict = reading.htfConflict || 'none';
    if (multi.final === 'no_trade') {
      if (reading.verdict !== 'insufficient') { reading.verdict = 'no_trade'; reading.reasons = []; }
      reading.extraReasons = [...engineReasonText(multi, getLang()), ...learned];
      return;
    }
    // execution of every qualified trade (each strategy keeps its own levels)
    const last = ctx.closedLast;
    const ok = executeAll(multi.trades, { smcPlan: reading.plan, want: pp.execution, style: pp.style, asset, tf: pp.tf, tfSec, S: ctx.S, atr: ctx.atr, price: last.close, live: ctx.quote,
      minRR: multi.minRR || 0, smcMinRR: STYLES[pp.style]?.minRR ?? 0, costPct: ctx.cost.totalPct, createdAt: last.time, nowMs: Date.now(), weightOf: (x) => learnWeight(x.id, { ...(x.ctx || {}), direction: x.direction, symbol: pp.symbol }) });
    for (const x of ok) x.size = sizePosition({ capital: reading.inputs?.capital ?? pp.capital, riskPct: reading.inputs?.riskPct ?? pp.riskPct, entry: x.plan.entry, stop: x.plan.stop, account: reading.inputs?.account ?? pp.account, leverage: reading.inputs?.leverage, asset, symbol: pp.symbol, targets: x.plan.targets });
    const chosen = ok.find((x) => x.id === multi.pick?.id) || ok.find((x) => x.id === 'smc') || [...ok].sort((a, b) => b.plan.rrMain - a.plan.rrMain)[0] || null;
    if (!chosen) {
      const first = multi.trades.find((x) => x.id === multi.pick?.id) || multi.trades[0];
      const ex = first?.exec || {};
      if (ex.state === 'wait') {
        reading.verdict = 'wait'; reading.waiting = true; reading.strategy = first.id; reading.waitReason = WAIT_TEXT(ex.reason, ex) || NOT_TEXT(ex.reason);
        reading.plan = { ...(first.id === 'smc' ? reading.plan : {}), direction: first.plan.direction, execution: 'limit', entry: first.plan.entry, stop: first.plan.stop, targets: first.plan.targets, rr: first.plan.rr || [], sources: first.plan.sources || [], validUntil: last.time + 2 * tfSec, createdAt: last.time };
        reading.score = reading.score || { passed: 0, total: 0 };
        return;
      }
      reading.verdict = 'no_trade'; reading.reasons = [];
      reading.extraReasons = [...multi.trades.map((x) => `${L(strategyOf(x.id)?.name.ar || x.id, strategyOf(x.id)?.name.en || x.id)}: ${NOT_TEXT(x.exec?.reason)}`), ...learned];
      return;
    }
    multi.pick = { id: chosen.id, plan: chosen.plan }; multi.final = chosen.direction === 'long' ? 'buy' : 'sell';
    // v248: every other strategy that qualified on its own is shown as its own recommendation (ready market entries first,
    // then the best reward-to-risk) — no single-trade limit, nothing merged
    reading.others = ok.filter((x) => x !== chosen).sort((a, b) => (a.plan.execution === 'market' ? 0 : 1) - (b.plan.execution === 'market' ? 0 : 1) || (b.plan.rrMain || 0) - (a.plan.rrMain || 0))
      .map((x) => ({ id: x.id, direction: x.direction, plan: x.plan, exec: x.exec.exec || null, size: x.size || null, ctx: x.ctx || multi.features || null }));
    reading.strategy = chosen.id;
    reading.learnCtx = chosen.ctx || multi.features || null;
    reading.exec = chosen.exec.exec; reading.execNote = chosen.exec.note || null;
    reading.quality = chosen.plan.quality ?? null;
    const pl = chosen.plan;
    reading.plan = { ...(chosen.id === 'smc' ? reading.plan : { confirm: null, poi: null }), direction: pl.direction, execution: pl.execution, entry: pl.entry, stop: pl.stop, targets: pl.targets, sources: pl.sources, rr: pl.rr, rrNet: pl.rrNet, rrMain: pl.rrMain, costR: pl.costR, risk: pl.risk,
      validUntil: pl.validUntil, createdAt: pl.createdAt, strategy: chosen.id, marketFill: pl.execution === 'market' ? { price: pl.entry, tolPts: MARKET_TOL_PTS } : null };
    reading.verdict = 'trade'; reading.reasons = []; reading.waiting = false; reading.direction = pl.direction;
    const st = multi.strategies.find((x) => x.id === chosen.id); reading.score = { passed: st.checks.filter((c) => c.status === 'pass').length, total: st.checks.length };
    reading.size = chosen.size;
    if (Number.isFinite(chosen.exec.exec?.dist?.pts)) reading.marketMoved = chosen.exec.exec.dist.pts;
  }

  async function generate({ silent = false, pp: pp0 = p } = {}) {
    const pp = lockStyle({ ...pp0 });   // v249: never another style than the profile's
    const my = silent ? 0 : ++run; if (!silent) { stopWatch(); markQ = Promise.resolve(); pctNow = 0; step = 4; paint(); }
    const wg = watchGen;
    const alive = silent ? () => wg === watchGen : () => my === run && el.isConnected;
    const mark = silent ? () => Promise.resolve() : markOut;
    const inst = getInstrument(pp.symbol); const tfSec = TIMEFRAMES.find((x) => x.id === pp.tf)?.seconds || 900; const prec = inst?.precision ?? 2;
    const fail = (k, why) => { if (silent) return null; mark(k, 'fail', why); result = { symbol: pp.symbol, error: why }; recordDecision({ symbol: pp.symbol, tf: pp.tf, style: pp.style, final: 'no_trade', reasons: [why] }); afterMarks(() => { if (alive()) { startWatch({ ...pp }); step = 5; paint(); } }, 900); };
    try {
      mark('connect', 'run');
      const ds = await getHistory(pp.symbol, pp.tf, 600); if (!alive()) return;
      mark('connect', 'done', ds.source ? String(ds.source) : '');
      if (ds.mode !== 'live') return fail('candles', L('الأسعار هلق مش حية (وضع تجريبي)، ما منعطي توصية على أسعار مولّدة.', 'Prices are not live right now (demo), no recommendation on generated prices.'));
      // v234: data checks — freshness, duplicates, gaps; a delayed or corrupt feed stops the recommendation (never an old price)
      const asset = ASSET_OF[inst?.type] || 'crypto';
      const vData = validateCandles(ds.candles, pp.tf, { crypto: asset === 'crypto' });
      if (vData.state === 'bad') return fail('candles', L('بيانات الشموع تالفة، ما في توصية.', 'The candle data is corrupt, no recommendation.'));
      if (vData.state === 'stale') return fail('candles', L(`آخر شمعة متأخرة (${Math.round((vData.ageSec || 0) / 60)} دقيقة)، السعر مش مباشر، فما في توصية.`, `The last candle is delayed (${Math.round((vData.ageSec || 0) / 60)} min), the price is not live, so no recommendation.`));
      mark('candles', 'done', L(`${ds.candles.length} شمعة · آخر سعر ${fmtNum(ds.candles.at(-1).close, prec)}${vData.gaps || vData.duplicates ? ` · ${vData.gaps} فجوة · ${vData.duplicates} مكرر` : ''}`, `${ds.candles.length} candles · last ${fmtNum(ds.candles.at(-1).close, prec)}${vData.gaps || vData.duplicates ? ` · ${vData.gaps} gaps · ${vData.duplicates} duplicates` : ''}`));
      mark('htf', 'run');
      await prefetchHtf(pp.symbol, tfSec).catch(() => null); if (!alive()) return;
      const htf = htfCandles(pp.symbol);
      // optional lower-timeframe confirmation for SMC market entries (closed LTF candles only)
      let ltf = null;
      if (pp.ltf && pp.execution === 'market' && LTF[pp.tf]) {
        try { const l = await getHistory(pp.symbol, LTF[pp.tf], 500); const ls = TIMEFRAMES.find((x) => x.id === LTF[pp.tf])?.seconds || 60; if (l?.mode === 'live') ltf = l.candles.filter((c) => c.time + ls <= Date.now() / 1000 + 1); } catch { /* no LTF → the check says no_data */ }
        if (!alive()) return;
      }
      mark('htf', 'done', `${htf ? `4h ${htf.h4?.length || 0} · 1D ${htf.d1?.length || 0}` : L('مش متوفرة، بنستعمل هيكل الفريم نفسه', 'unavailable, using this chart\'s structure')}${ltf ? ` · LTF ${LTF[pp.tf]} ${ltf.length}` : ''}`);
      const closes = ds.candles.map((c) => c.close);
      const r14 = rsi(closes, 14).at(-1); const a14 = atr(ds.candles, 14).at(-1);
      mark('ind', 'done', `RSI ${r14 == null ? '—' : fmtNum(r14, 1)} · ATR ${a14 == null ? '—' : fmtNum(a14, prec)}`);
      mark('news', 'run');
      const cal = await getCalendar().catch(() => null); if (!alive()) return;
      const events = Array.isArray(cal?.events) ? cal.events : Array.isArray(cal) ? cal : null;
      const news = events ? newsRisk(pp.symbol, events, Date.now()) : null;
      mark('news', 'done', !news?.known ? L('التقويم مش متاح', 'calendar unavailable') : news.level === 'high' ? L(`خبر قوي قريب: ${news.event?.title || ''}`, `High-impact news soon: ${news.event?.title || ''}`) : L('ما في خبر قوي قريب', 'no high-impact news close'));
      mark('plan', 'run');
      try { expireStale(Date.now(), RISK.maxHoldHours); } catch { /* v248: stale saved trades never block new ones */ }
      const open = listTrades().filter((x) => x.mode === 'live' && ['pending', 'active'].includes(x.status));
      const risk = riskSettings(pp);
      const quote = await quoteOf(inst, pp); if (!alive()) return;
      const cost = costModel(asset, quote?.spreadPct ?? null);
      const nowS = Date.now() / 1000; const closedCs = ds.candles.filter((c) => c.time + tfSec <= nowS + 1);
      refreshPaper(pp.symbol, pp.tf, closedCs, ds.mode);
      const reading = analyzeSmcIct(ds.candles, { ...cleanInputs({ style: pp.style, account: pp.account, riskPct: pp.riskPct, capital: pp.capital, execution: ltf ? 'confirm' : pp.execution, asset, costPct: cost.totalPct, maxDailyLossPct: risk.dailyLossPct, maxOpen: risk.maxOpen }),
        symbol: pp.symbol, tfSec, htf, ltf, news, todayLossPct: todayLossPct(), htfMode: 'tiered', poiMaxAtr: EXEC.limitMaxAtr[pp.style], exposure: { open: open.length, sameAsset: { long: open.filter((x) => x.asset === asset && x.direction === 'long').length, short: open.filter((x) => x.asset === asset && x.direction === 'short').length } } });
      reading.ctx = { symbol: pp.symbol, tf: pp.tf, mode: ds.mode };
      reading.data = { state: vData.state, gaps: vData.gaps, duplicates: vData.duplicates, ageSec: vData.ageSec, source: ds.source || null, volumeKind: ds.volumeKind || null };
      reading.cost = cost; reading.quote = quote ? { price: quote.price, bid: quote.bid, ask: quote.ask, spreadPct: quote.spreadPct, ageSec: Math.round((Date.now() - quote.at) / 1000) } : null;
      reading.engineVersion = ENGINE_VERSION;
      if (!alive()) return;
      // Every strategy module on the same snapshot (closed candles only), then the global filters: one decision.
      const extra = extraGlobals({ validation: { ...vData, n: ds.candles.length }, open, riskPct: pp.riskPct, asset, maxOpen: risk.maxOpen });
      const multi = await runEngine({ ds, tfSec, htf, reading, cal: events ? { events, at: cal?.at ?? Date.now(), stale: Boolean(cal?.stale) } : null, inst, asset, open, cost, risk, extra, quote, pp }); if (!alive()) return;
      await new Promise((r) => setTimeout(r, 0)); if (!alive()) return;   // one heavy step per task: the phone stays responsive
      const prep = prepare(closedCs, { htf, tfSec, asset });
      applyEngine(reading, multi, ds, tfSec, asset, { S: prep.S, atr: prep.S?.a?.[prep.S.i] ?? a14, quote, cost, closedLast: closedCs.at(-1) || ds.candles.at(-1), pp });
      // PAPER strategies on the same closed candles: recorded and followed for research, never a recommendation
      await new Promise((r) => setTimeout(r, 0)); if (!alive()) return;
      const paper = runPaper(closedCs, { volumeKind: ds.volumeKind, assetClass: asset, tf: pp.tf, tfSec });
      recordPaper(paper.filter((x) => x.status === 'signal'), { symbol: pp.symbol, tf: pp.tf, style: pp.style, barTime: closedCs.at(-1)?.time, costPct: cost.totalPct });
      // counted for the owners' analytics (only the outcome: buy / sell / no trade and the strategy, nothing personal)
      if (silent && reading.verdict !== 'trade') return null;   // the watch keeps quiet until a trade qualifies
      if (ds.mode === 'live') import('../services/ai/gateway.js').then((g) => g.apiRequest('POST', '/api/me/reco', { final: multi.final, strategy: multi.pick?.id || undefined }, 8000)).catch(() => {});
      recordDecision({ symbol: pp.symbol, tf: pp.tf, style: pp.style, final: reading.verdict === 'trade' ? multi.final : reading.verdict === 'wait' ? 'wait' : 'no_trade', strategy: reading.verdict === 'trade' ? reading.strategy : null, reasons: reading.verdict === 'trade' ? [] : [reading.waitReason, ...(reading.extraReasons || []), ...(reading.reasons || []).map((x) => SA(`reasons.${x}`))].filter(Boolean).slice(0, 4) });
      mark('plan', 'done', `${SA(`verdict.${reading.verdict}`)} · ${L(`${multi.qualified.length} من ${multi.strategies.length} استراتيجيات مؤهّلة`, `${multi.qualified.length} of ${multi.strategies.length} strategies qualified`)}`);
      const res = { symbol: pp.symbol, tf: pp.tf, prec, reading, multi, paper, price: quote?.price ?? closedCs.at(-1)?.close ?? ds.candles.at(-1).close, ai: null, aiError: null };
      if (!silent) result = res;
      if (reading.verdict === 'insufficient') { mark('ai', 'skip', L('ما في خطة لنشرحها', 'no plan to explain')); }
      else {
        mark('ai', 'run');
        try {
          const text = await Promise.race([explainSmc(aiBrief(reading, pp), getLang()), new Promise((_, no) => setTimeout(() => no(new Error('timeout')), 45000))]);
          if (!alive()) return null; res.ai = String(text || '').trim(); mark('ai', 'done', L('جاهز', 'ready'));
        } catch (e) { if (!alive()) return null; res.aiError = true; mark('ai', 'skip', L('الـ AI مش متصل، الخطة من محرك الموقع بدون شرح', 'AI not connected, plan from the site engine, no explanation')); }
      }
      if (silent) return res;
      afterMarks(() => { if (alive()) { if (reading.verdict !== 'trade' && reading.verdict !== 'wait') startWatch({ ...pp }); step = 5; paint(); } }, 800);
    } catch (e) {
      if (silent) return null;
      if (alive()) fail('connect', L('ما قدرنا نجيب الأسعار. جرّب كمان شوي أو اختار رمز تاني.', 'Could not load prices. Try again shortly or pick another symbol.'));
    }
  }

  function card(res) {
    const again = `<div class="aisg-actions aisg-stagger"><button type="button" class="btn btn-primary" data-again>${icons.refresh || ''}<span>${esc(L('توصية جديدة', 'New signal'))}</span></button><button type="button" class="btn btn-ghost" data-dash>${icons.chart || icons.trend || ''}<span>${esc(L('لوحة الأداء', 'Performance'))}</span></button></div>`;
    // PAPER strategies of this analysis: research only, clearly not a recommendation (v234)
    const PN = (id) => { const x = strategyOf(id); return x ? L(x.name.ar, x.name.en) : id; };
    const paperHtml = (list) => { const sig = (list || []).filter((x) => x.status === 'signal'); if (!list?.length) return '';
      return `<details class="aie-strat aisg-paper"><summary><b>${esc(L('استراتيجيات تجريبية (PAPER)', 'Paper strategies (PAPER)'))}</b><span class="aie-badge is-paper">${sig.length}/${list.length}</span></summary>
        <p class="aie-note">${esc(L('للبحث بس: بتنسجل وبتنتابع على الأسعار الحقيقية بلوحة الأداء، ومش توصية ولا بتنبعت لـ MT5.', 'Research only: recorded and followed on real prices in the performance panel, not a recommendation and never sent to MT5.'))}</p>
        <ul class="aie-checks">${list.map((x) => `<li class="is-${x.status === 'signal' ? 'pass' : 'unavailable'}"><i aria-hidden="true"></i><span>${esc(PN(x.id))}</span><b>${esc(x.status === 'signal' ? (x.signal.direction === 'long' ? L('شراء (تجريبي)', 'BUY (paper)') : L('بيع (تجريبي)', 'SELL (paper)')) : x.status === 'none' ? L('ما في إشارة', 'no signal') : L('غير متاحة', 'unavailable'))}</b>${x.signal?.why ? `<small dir="ltr">${esc(x.signal.why)}</small>` : x.reason ? `<small>${esc(x.reason)}</small>` : ''}</li>`).join('')}</ul></details>`; };
    if (!res || res.error) return `${head(4, L('النتيجة', 'Result'))}<div class="aisg-body">${watchHtml()}<div class="aisg-card aisg-none aisg-stagger"><b>${esc(L('ما في توصية', 'No recommendation'))} · ${esc(pairName(res?.symbol || p.symbol))}</b><p>${esc(res?.error || '')}</p></div>${again}</div>`;
    const r = res.reading; const v = r.verdict; const px = (x) => priceText(res.symbol, x, res.prec);
    const iso = (x) => `\u2066${x}\u2069`;   // keeps "$52,376.01" / "1.5%" in order inside Arabic text
    if (v === 'no_trade' || v === 'insufficient' || !r.plan) {
      return `${head(4, L('النتيجة', 'Result'))}<div class="aisg-body">${watchHtml()}<div class="aisg-card aisg-none aisg-stagger">
        <div class="aisg-top"><span class="aisg-ic">${icons.shield || ''}</span><div><b class="aisg-sym-name">${esc(pairName(res.symbol))}</b><span class="muted">${esc(SA(`style.${r.style}`))} · ${esc(t(`perf.tfShort.${res.tf}`) || res.tf)}</span></div><span class="aisg-badge is-none">${esc(L('لا صفقة', 'NO TRADE'))}</span></div>
        <p>${esc(L('الشروط المطلوبة مش متحققة هلق، فالأحسن ما تدخل. هاد كمان قرار:', 'The required conditions are not met right now, so the best move is to stay out:'))}</p>
        ${OWN() ? '' : `<p class="aisg-fine">${esc(L('بنضل نراقب السوق، وأول ما تتحقق الشروط بتنفتح الصفقة وبيوصلك إشعار.', 'We keep watching the market; the moment the conditions are met the trade opens and you get an alert.'))}</p>`}
        ${OWN() ? `<ul class="aisg-why">${(r.reasons || []).map((x) => `<li>${esc(SA(`reasons.${x}`))}</li>`).join('')}${(r.extraReasons || []).map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}
        ${res.ai ? `<div class="aisg-ai"><b>${icons.sparkle || ''}${esc(L('رأي الـ AI', 'AI view'))}</b><p>${esc(res.ai)}</p></div>` : ''}
        ${res.multi && OWN() ? engineHtml(res.multi, getLang()) : ''}
        ${OWN() ? paperHtml(res.paper) : ''}
        <p class="aisg-fine">${esc(L('جرّب فريم تاني أو سوق تاني، أو ارجع بعد شوي.', 'Try another timeframe or market, or come back later.'))}</p></div>${again}</div>`;
    }
    const pl = r.plan; const long = pl.direction === 'long'; const sz = r.size;
    const status = v === 'wait' ? { cls: 'is-wait', ar: 'استنى', en: 'WAIT' } : pl.execution === 'market' ? { cls: 'is-active', ar: 'نشطة', en: 'ACTIVE' } : { cls: 'is-pending', ar: 'معلّقة', en: 'PENDING' };
    const note = `${SA(`style.${r.style}`)} · ${t(`perf.tfShort.${res.tf}`) || res.tf} · R:R ${pl.rr.map((x) => `1:${fmtNum(x, 2)}`).join(' / ')}`;
    const money = (x) => iso(`$${fmtNum(x, 2)}`);
    const tpList = pl.targets.map((x) => iso(px(x))).join(L('، ', ', '));
    const capAr = sz ? ` برأس مال ${money(r.inputs.capital)} ومخاطرة ${iso(`${fmtNum(r.inputs.riskPct, 2)}%`)}، أقصى خسارة إذا ضرب الوقف ${money(sz.riskAmount)}.` : '';
    const capEn = sz ? ` With ${money(r.inputs.capital)} capital and ${fmtNum(r.inputs.riskPct, 2)}% risk, the most you lose at the stop is ${money(sz.riskAmount)}.` : '';
    const dirAr = long ? 'شراء' : 'بيع'; const dirEn = long ? 'Buy' : 'Sell';
    const isMarket = pl.execution === 'market';
    const sentence = v === 'wait'
      ? (r.waitReason ? L(`استنى: ${r.waitReason} مستوى الاستراتيجية حوالين ${iso(px(pl.entry))}، الوقف عند ${iso(px(pl.stop))}. اطلب التوصية من جديد لما يقرّب السعر.`, `Wait: ${r.waitReason} The strategy level is around ${px(pl.entry)}, stop ${px(pl.stop)}. Ask again when price gets closer.`)
        : L(`استنى: السعر لسا مش بمنطقة الدخول، فما في دخول ${isMarket ? 'ماركت' : ''} هلق. المنطقة حوالين ${iso(px(pl.entry))}، الوقف عند ${iso(px(pl.stop))}، والأهداف ${tpList}. اطلب التوصية من جديد لما يوصلها السعر.`,
          `Wait: price is not in the entry zone yet, so there is no ${isMarket ? 'market ' : ''}entry now. The zone is around ${px(pl.entry)}, stop ${px(pl.stop)}, targets ${tpList}. Ask again when price gets there.`))
      : isMarket
        ? L(`ادخل ${dirAr} ${pairName(res.symbol)} هلق ماركت على السعر الحالي ${iso(px(pl.entry))} (التنفيذ على هالسعر أو بفرق ${MARKET_TOL_PTS} نقاط كحد أقصى)، الوقف عند ${iso(px(pl.stop))}، والأهداف ${tpList}.${capAr}`,
          `${dirEn} ${pairName(res.symbol)} now at market, at the current price ${px(pl.entry)} (filled at this price or within ${MARKET_TOL_PTS} points), stop at ${px(pl.stop)}, targets at ${tpList}.${capEn}`)
        : L(`حط أمر ليميت معلّق ${dirAr} ${pairName(res.symbol)} عند ${iso(px(pl.entry))}. الأمر بيتفعّل تلقائيًا لما يوصل السعر لهالرقم، وقبل هيك ما في صفقة مفتوحة. الوقف عند ${iso(px(pl.stop))}، والأهداف ${tpList}.${capAr}`,
          `Place a pending ${dirEn.toLowerCase()} limit order on ${pairName(res.symbol)} at ${px(pl.entry)}. It activates automatically when price reaches that level; until then no trade is open. Stop at ${px(pl.stop)}, targets at ${tpList}.${capEn}`);
    const ex = r.exec || null; const tz = tzOffset();
    const distTxt = (d) => (d ? [d.atr != null ? `${fmtNum(d.atr, 2)} ATR` : null, d.pct != null ? `${fmtNum(d.pct, 2)}%` : null].filter(Boolean).join(' · ') : '');
    const WHY = { zone: L('من منطقة SMC (OB / FVG)', 'from the SMC zone (OB / FVG)'), ema20: L('من منطقة الرجوع لـ EMA 20', 'from the EMA 20 pullback zone'), band: L('من حد بولينجر', 'from the Bollinger band'), in_zone: L('السعر الحالي جوّا منطقة الدخول وما في ملاحقة', 'the current price is inside the entry zone, no chasing') };
    const NOTE = { market_chase: L('اخترت ماركت بس السعر ممدود، فالدخول صار ليميت عند مستوى الاستراتيجية.', 'You chose market but price is extended, so the entry is a limit at the strategy level.'), smc_zone_limit: L('دخول SMC من منطقته بأمر معلّق بس.', 'SMC enters from its zone with a pending order only.') };
    const noteTxt = r.execNote ? (NOTE[r.execNote] || (String(r.execNote).startsWith('limit_') ? L('ما في مستوى ليميت منطقي، والدخول ماركت لسا صالح فانعرض ماركت.', 'No logical limit level, and a market entry is still valid, so it is shown as market.') : '')) : '';
    const execBox = v === 'wait' ? '' : isMarket
      ? `<div class="aisg-exec is-market">${icons.bolt || ''}<p><b>${esc(L('أمر ماركت', 'Market order'))}</b> · ${esc(L(`سعر التنفيذ = السعر الحالي ${iso(px(pl.entry))}`, `Fill price = current price ${px(pl.entry)}`))}<br><small>${esc(L(`ليش ماركت: ${WHY[ex?.why] || WHY.in_zone}${ex?.side ? ` · سعر ${ex.side === 'ask' ? 'الشراء (Ask)' : 'البيع (Bid)'}` : ''} · الانزلاق المسموح ${MARKET_TOL_PTS} نقاط${ex?.dist ? ` · بعد عن دخول الاستراتيجية ${distTxt(ex.dist)}` : ''}${noteTxt ? ` · ${noteTxt}` : ''}`, `Why market: ${WHY[ex?.why] || WHY.in_zone}${ex?.side ? ` · ${ex.side} price` : ''} · allowed slippage ${MARKET_TOL_PTS} points${ex?.dist ? ` · ${distTxt(ex.dist)} from the strategy entry` : ''}${noteTxt ? ` · ${noteTxt}` : ''}`))}</small></p></div>`
      : `<div class="aisg-exec is-limit">${icons.clock || icons.alarm || ''}<p><b>${esc(L('أمر معلّق (ليميت)', 'Pending limit order'))}</b> · ${esc(L(`بيتفعّل تلقائيًا لما يوصل السعر لـ ${iso(px(pl.entry))}`, `Activates automatically when price reaches ${px(pl.entry)}`))}<br><small>${esc(L(`ليش ليميت: ${WHY[ex?.why] || WHY.zone}${ex?.dist ? ` · بعد عن السعر الحالي ${distTxt(ex.dist)}` : ''} · صالح لحد ${fmtTz(pl.validUntil, getLang())} (${tz})${ex?.expiry ? ` · ${ex.expiry.bars} شمعة${ex.expiry.why === 'weekend' ? '، قبل إغلاق الأسبوع' : ''}` : ''}. بيلغى إذا انتهت الصلاحية أو وصل السعر TP1 قبل الدخول أو طلع خبر قوي قبل التفعيل.${noteTxt ? ` ${noteTxt}` : ''}`,
          `Why limit: ${WHY[ex?.why] || WHY.zone}${ex?.dist ? ` · ${distTxt(ex.dist)} from the current price` : ''} · valid until ${fmtTz(pl.validUntil, getLang())} (${tz})${ex?.expiry ? ` · ${ex.expiry.bars} candles${ex.expiry.why === 'weekend' ? ', before the weekly close' : ''}` : ''}. Cancelled if it expires, if price reaches TP1 before the fill, or if high-impact news comes before it activates.${noteTxt ? ` ${noteTxt}` : ''}`))}</small></p></div>`;
    // v246: what a client sees of the execution: the order and its validity, never the strategy's reasoning
    const clientExec = v === 'wait' ? '' : isMarket
      ? `<div class="aisg-exec is-market">${icons.bolt || ''}<p><b>${esc(L('أمر ماركت', 'Market order'))}</b> · ${esc(L(`سعر التنفيذ = السعر الحالي ${iso(px(pl.entry))}`, `Fill price = current price ${px(pl.entry)}`))}<br><small>${esc(L(`الانزلاق المسموح ${MARKET_TOL_PTS} نقاط`, `Allowed slippage ${MARKET_TOL_PTS} points`))}</small></p></div>`
      : `<div class="aisg-exec is-limit">${icons.clock || icons.alarm || ''}<p><b>${esc(L('أمر معلّق (ليميت)', 'Pending limit order'))}</b> · ${esc(L(`بيتفعّل تلقائيًا لما يوصل السعر لـ ${iso(px(pl.entry))}`, `Activates automatically when price reaches ${px(pl.entry)}`))}<br><small>${esc(L(`صالح لحد ${fmtTz(pl.validUntil, getLang())} (${tz}). بيلغى إذا انتهت الصلاحية أو وصل السعر TP1 قبل الدخول.`, `Valid until ${fmtTz(pl.validUntil, getLang())} (${tz}). Cancelled if it expires or price reaches TP1 before entry.`))}</small></p></div>`;
    // v248: what makes the trade invalid, the live price and the entry distance — for everyone (no strategy internals)
    const curPx = r.quote?.price ?? res.price;
    const distLine = Number.isFinite(curPx) && Number.isFinite(pl.entry) ? `${iso(px(curPx))} · ${L('بعد الدخول', 'entry distance')} ${iso(`${fmtNum(Math.abs(pl.entry - curPx), res.prec)} (${fmtNum((Math.abs(pl.entry - curPx) / curPx) * 100, 3)}%)`)}` : '';
    const invalid = v === 'wait' ? '' : `<p class="aie-note">${esc(L('الصفقة بتبطل إذا:', 'The trade is invalid if:'))} ${esc(isMarket ? L(`السعر ضرب الوقف ${iso(px(pl.stop))} (بعد TP1 الوقف على الدخول).`, `price hits the stop ${iso(px(pl.stop))} (after TP1 the stop is at entry).`) : L(`انتهت صلاحية الأمر قبل التفعيل، أو وصل السعر TP1 ${iso(px(pl.targets[0]))} أو كسر الوقف ${iso(px(pl.stop))} قبل الدخول.`, `the order expires unfilled, or price reaches TP1 ${iso(px(pl.targets[0]))} or breaks the stop ${iso(px(pl.stop))} before the entry.`))}${distLine ? ` · ${esc(L('السعر الحالي', 'Current price'))} ${esc(distLine)}` : ''}</p>`;
    const newsWarn = ['unavailable', 'stale'].includes(res.multi?.news?.newsStatus) ? `<p class="aie-note is-warn">${esc(L('تقويم الأخبار مش متاح هلق، تأكد بنفسك ما في خبر قوي قريب قبل الدخول.', 'The news calendar is unavailable right now, check yourself that no high-impact news is close before entering.'))}</p>` : '';
    // strategy, quality, costs and management (v234)
    const sid = r.strategy || pl.strategy || 'smc'; const sdef = strategyOf(sid);
    const c = r.cost; const q = r.quote;
    const detail = `<dl class="aie-kv aisg-detail">
      ${OWN() ? `<div><dt>${esc(L('الاستراتيجية', 'Strategy'))}</dt><dd>${esc(sdef ? L(sdef.name.ar, sdef.name.en) : sid)} <span class="aie-badge is-qualified">LIVE</span></dd></div>` : ''}
      ${r.quality != null ? `<div><dt>${esc(L('جودة الإعداد', 'Setup quality'))}</dt><dd>${esc(`${r.quality}/100`)} <small>${esc(L('(مش احتمال ربح)', '(not a win probability)'))}</small></dd></div>` : ''}
      ${pl.rrNet ? `<div><dt>${esc(L('R:R بعد التكاليف', 'R:R after costs'))}</dt><dd dir="ltr">${esc(pl.rrNet.map((x) => `1:${fmtNum(x, 2)}`).join(' / '))}</dd></div>` : ''}
      ${c ? `<div><dt>${esc(L('التكاليف', 'Costs'))}</dt><dd>${esc(L(`سبريد ${iso(`${fmtNum(c.spreadPct, 3)}%`)}${c.estimated ? ' (تقديري)' : ' (حي)'} + عمولة ${iso(`${fmtNum(c.commissionPct, 3)}%`)} + انزلاق ${iso(`${fmtNum(c.slippagePct, 3)}%`)} = ${iso(`${fmtNum(pl.costR ?? 0, 3)}R`)}`, `spread ${fmtNum(c.spreadPct, 3)}%${c.estimated ? ' (estimated)' : ' (live)'} + commission ${fmtNum(c.commissionPct, 3)}% + slippage ${fmtNum(c.slippagePct, 3)}% = ${fmtNum(pl.costR ?? 0, 3)}R`))}</dd></div>` : ''}
      ${q ? `<div><dt>${esc(L('السعر الحالي', 'Current price'))}</dt><dd dir="ltr">${esc(q.bid != null && q.ask != null ? `Bid ${px(q.bid)} · Ask ${px(q.ask)}` : `${px(q.price)} (Last)`)}</dd></div>` : ''}
      <div><dt>${esc(L('إدارة الصفقة', 'Management'))}</dt><dd>${esc(L(`ثلث عند كل هدف (${pl.targets.map((_, k) => iso(`TP${k + 1} ${Math.round(100 / pl.targets.length)}%`)).join('، ')}) · الوقف للدخول بعد TP1`, `a third at each target (${pl.targets.map((_, k) => `TP${k + 1} ${Math.round(100 / pl.targets.length)}%`).join(', ')}) · stop to entry after TP1`))}</dd></div>
      <div><dt>${esc(L('وقت الإشارة', 'Signal time'))}</dt><dd>${esc(`${fmtTz(pl.createdAt, getLang())} (${tz})`)}</dd></div>
    </dl>
    ${r.htfConflict === 'minor' ? `<p class="aie-note is-warn">${esc(L('تنبيه: الفريم الأعلى الأكبر مع الصفقة بس الفريم الوسطاني عكسها (تصحيح). الخلاف بسيط، بس المخاطرة أعلى.', 'Note: the highest frame agrees with the trade but the middle frame disagrees (a pullback). A minor conflict, but higher risk.'))}</p>` : ''}
    ${res.multi?.conflict && OWN() ? `<p class="aie-note is-warn">${esc(L('تعارض: في استراتيجيات مؤهّلة باتجاهين عكس بعض، شوف «صفقة لكل استراتيجية» تحت.', 'Conflict: qualified strategies point in opposite directions, see "one trade per strategy" below.'))}</p>` : ''}
    ${Number(p.riskPct) > RISK.warnRiskPct ? `<p class="aie-note is-warn">${esc(L(`المخاطرة ${fmtNum(p.riskPct, 2)}% أعلى من ${RISK.warnRiskPct}% للصفقة الوحدة.`, `Risk ${fmtNum(p.riskPct, 2)}% is above ${RISK.warnRiskPct}% per trade.`))}</p>` : ''}
    ${r.data?.source ? `<p class="aisg-meta">${esc(L(`البيانات: ${r.data.source}${r.data.volumeKind === 'taker' ? ' · حجم بورصة حقيقي' : r.data.volumeKind === 'estimated' ? ' · حجم تقديري/Tick' : ' · بدون حجم'}`, `Data: ${r.data.source}${r.data.volumeKind === 'taker' ? ' · real exchange volume' : r.data.volumeKind === 'estimated' ? ' · estimated / tick volume' : ' · no volume'}`))}</p>` : ''}`;
    const size = sz ? `<div class="aisg-size"><div><small>${esc(L('المخاطرة', 'Risk'))}</small><b class="mono down" data-count="${sz.riskAmount}" data-dec="2" data-pre="$">${esc(`$${fmtNum(sz.riskAmount, 2)}`)}</b></div><div><small>${esc(sz.lots != null ? L('لوت', 'Lots') : L('الكمية', 'Units'))}</small><b class="mono">${esc(sz.lots != null ? fmtNum(sz.lots, 2) : fmtNum(sz.units, sz.units < 1 ? 4 : 2))}</b></div><div><small>${esc(L('الربح عند TP1', 'Profit at TP1'))}</small><b class="mono up" data-count="${sz.rewards[0] || 0}" data-dec="2" data-pre="$">${esc(`$${fmtNum(sz.rewards[0] || 0, 2)}`)}</b></div></div>` : '';
    return `${head(4, L('التوصية', 'Recommendation'))}<div class="aisg-body"><div class="aisg-card aisg-stagger ${long ? 'is-long' : 'is-short'}">
      ${hubCard({ symbol: res.symbol, direction: pl.direction, entry: pl.entry, stop: pl.stop, targets: pl.targets, prec: res.prec, price: res.price, status, note })}
      ${OWN() ? execBox : clientExec}
      ${invalid}${newsWarn}
      ${v === 'wait' ? '' : size}
      ${v === 'wait' ? '' : detail}
      ${v === 'wait' ? '' : mt5Button(res)}
      <div class="aisg-reco">${icons.bulb || ''}<p><b>${esc(L('التوصية:', 'Recommendation:'))}</b> ${esc(sentence)}</p></div>
      <p class="aisg-meta">${esc(SA(`style.${r.style}`))} · ${esc(t(`perf.tfShort.${res.tf}`) || res.tf)}${OWN() ? ' · ' + esc(L(`الشروط ${r.score.passed}/${r.score.total} (قائمة فحص، مش نسبة نجاح)`, `Checks ${r.score.passed}/${r.score.total} (a checklist, not a win rate)`)) : ''}${pl.execution === 'limit' && v !== 'wait' ? ` · ${esc(L('صالحة لحد', 'valid until'))} ${esc(fmtTz(pl.validUntil, getLang()))} (${esc(tz)})` : ''}</p>
      ${res.ai ? `<div class="aisg-ai"><b>${icons.sparkle || ''}${esc(L('شرح الـ AI', 'AI explanation'))}</b><p>${esc(res.ai)}</p></div>` : res.aiError ? `<p class="aisg-fine">${esc(L('الـ AI مش متصل هلق، فالتوصية بدون شرح. الأرقام نفسها من محرك الموقع.', 'AI is not connected right now, so there is no explanation. The numbers are from the site engine.'))}</p>` : ''}
      ${res.multi && OWN() ? engineHtml(res.multi, getLang()) : ''}
      ${OWN() ? paperHtml(res.paper) : ''}
      <p class="aisg-fine">${esc(L('بعد TP1 الستوب بينتقل لسعر الدخول. هاي مش نصيحة مالية، والتداول فيه مخاطرة عالية.', 'After TP1 the stop moves to entry. Not financial advice, trading involves significant risk.'))}</p>
      ${OWN() ? `<p class="aisg-fine">${esc(`${ENGINE_VERSION} · ${PROMPT_VERSION}`)}</p>` : ''}</div>
      <div class="aisg-actions aisg-stagger">${v === 'wait' ? '' : `<button type="button" class="btn btn-primary" data-save ${res.autoSaved ? 'disabled' : ''}>${icons.bell || ''}<span>${esc(res.autoSaved ? L('انفتحت وانحفظت تلقائيًا', 'Opened & saved automatically') : L('احفظ + إشعارات', 'Save & alerts'))}</span></button>`}
        <button type="button" class="btn" data-chart>${icons.candles || ''}<span>${esc(L('افتح الشارت', 'Open chart'))}</span></button>
        <button type="button" class="btn btn-ghost" data-copy>${icons.journal || ''}<span>${esc(L('انسخ', 'Copy'))}</span></button>
        <button type="button" class="btn btn-ghost" data-again>${icons.refresh || ''}<span>${esc(L('توصية جديدة', 'New signal'))}</span></button>
        <button type="button" class="btn btn-ghost" data-dash>${icons.chart || icons.trend || ''}<span>${esc(L('لوحة الأداء', 'Performance'))}</span></button></div>${othersHtml(res)}</div>`;
  }

  // v248: every other qualifying recommendation of this analysis, each with its own levels (separate trades, never merged)
  function othersHtml(res) {
    const list = res.reading?.others || []; if (!list.length || res.reading.verdict !== 'trade') return '';
    const px = (x) => priceText(res.symbol, x, res.prec); const iso = (x) => `\u2066${x}\u2069`; const curPx = res.reading.quote?.price ?? res.price;
    return `<section class="aisg-others aisg-stagger"><h3>${esc(L(`توصيات تانية مؤهّلة (${list.length})`, `Other qualifying recommendations (${list.length})`))}</h3>${list.map((x, i) => {
      const pl = x.plan; const long = pl.direction === 'long'; const mk = pl.execution === 'market'; const sd = strategyOf(x.id);
      const dist = Number.isFinite(curPx) ? `${fmtNum(Math.abs(pl.entry - curPx), res.prec)} (${fmtNum((Math.abs(pl.entry - curPx) / curPx) * 100, 3)}%)` : '—';
      return `<article class="aisg-other ${long ? 'is-long' : 'is-short'}"><header><b>${esc(L(`توصية ${i + 2}`, `Recommendation ${i + 2}`))} · ${esc(long ? L('شراء', 'BUY') : L('بيع', 'SELL'))}</b><span class="aisg-badge ${mk ? 'is-active' : 'is-pending'}">${mk ? 'MARKET' : 'LIMIT'}</span>${OWN() && sd ? `<small>${esc(L(sd.name.ar, sd.name.en))}</small>` : ''}</header>
        <dl class="aie-kv"><div><dt>${esc(L('الدخول', 'Entry'))}</dt><dd dir="ltr">${esc(px(pl.entry))}</dd></div><div><dt>${esc(L('الوقف', 'Stop'))}</dt><dd dir="ltr" class="down">${esc(px(pl.stop))}</dd></div>
        ${pl.targets.map((t, k) => `<div><dt>TP${k + 1}</dt><dd dir="ltr" class="up">${esc(px(t))}</dd></div>`).join('')}
        ${pl.rrNet ? `<div><dt>${esc(L('R:R بعد التكاليف', 'R:R after costs'))}</dt><dd dir="ltr">${esc(pl.rrNet.map((v) => `1:${fmtNum(v, 2)}`).join(' / '))}</dd></div>` : ''}
        <div><dt>${esc(L('بعد الدخول عن السعر', 'Entry distance'))}</dt><dd dir="ltr">${esc(dist)}</dd></div>
        ${!mk && pl.validUntil ? `<div><dt>${esc(L('صالح لحد', 'Valid until'))}</dt><dd>${esc(fmtTz(pl.validUntil, getLang()))}</dd></div>` : ''}</dl>
        <p class="aie-note">${esc(L('الصفقة بتبطل إذا:', 'Invalid if:'))} ${esc(mk ? L(`ضرب الوقف ${iso(px(pl.stop))}.`, `price hits the stop ${iso(px(pl.stop))}.`) : L(`انتهت الصلاحية أو وصل السعر TP1 ${iso(px(pl.targets[0]))} أو الوقف ${iso(px(pl.stop))} قبل الدخول.`, `it expires, or price reaches TP1 ${iso(px(pl.targets[0]))} or the stop ${iso(px(pl.stop))} before the entry.`))}</p>
        <div class="aisg-actions"><button type="button" class="btn btn-sm" data-save-other="${i}">${icons.bell || ''}<span>${esc(L('احفظ + إشعارات', 'Save & alerts'))}</span></button>${mk ? mt5Button(res, x) : ''}</div></article>`;
    }).join('')}</section>`;
  }

  // One click → this recommendation (a market trade) is sent to the linked MetaTrader 5 terminal, with its stop and targets
  // and the position size computed above (lots) when there is one (services/mt5Apply.js). Pending limit plans have no button.
  const aiSig = (res, x) => {
    const pl = x?.plan || res.reading.plan; const strategy = x?.id || res.reading.strategy || pl.strategy || 'smc';
    return { id: `ai|${res.symbol}|${res.tf}|${strategy}|${pl.createdAt || 0}|${pl.direction}`, symbol: res.symbol, direction: pl.direction, stop: pl.stop, targets: pl.targets, strategy, status: 'active' };
  };
  const lotOf = (res) => (res.reading.size?.lots > 0 ? res.reading.size.lots : null);
  function mt5Button(res, x = null) {
    const r = res.reading; const pl = x?.plan || r.plan;
    if (!pl || (!x && (r.verdict !== 'trade' || pl.execution !== 'market'))) return '';
    const s = aiSig(res, x); const lot = (!x && lotOf(res)) || oneClickLot();
    if (wasApplied(s.id)) return `<div class="rc-mt5 aisg-mt5"><span class="mt5-go is-done" role="status">✓ ${esc(L('انطبقت على MT5', 'Applied on MT5'))}</span></div>`;
    return `<div class="rc-mt5 aisg-mt5"><button type="button" class="mt5-go" data-mt5ai="${esc(x?.id || '')}"><span class="mt5-go-bolt" aria-hidden="true">⚡</span><span class="mt5-go-txt">${esc(L('تطبيق على MT5', 'Apply on MT5'))}</span><span class="mt5-go-lot">· ${fmtNum(lot, 2)} ${esc(L('لوت', 'lot'))}</span><i class="mt5-go-spin" aria-hidden="true"></i></button></div>`;
  }
  const MT5_ERR = { no_link: L('ما في حساب MT5 مربوط. اربطه من خانة «ربط MT5».', 'No MT5 account linked. Link one on the “MT5 bridge” page.'), terminal_offline: L('منصة MT5 مش متصلة. افتح MT5 وتأكد إنه الـ EA شغّال.', 'MT5 is offline. Open MT5 and make sure the EA is running.'), trading_disabled: L('التداول مطفي بالـ EA (Allow trading) أو Algo Trading بالمنصة.', 'Trading is off in the EA (Allow trading) or Algo Trading in MT5.'), already_applied: L('انطبقت قبل.', 'Already applied.'), server_missing: L('ربط MT5 بيحتاج سيرفر الموقع.', 'The MT5 bridge needs the site server.'), signin_required: L('سجّل الدخول أول.', 'Sign in first.') };
  async function onMt5(b) {
    if (!result || b.disabled) return;
    const x = b.dataset.mt5ai ? result.multi?.trades?.find((t) => t.id === b.dataset.mt5ai) : null;
    const s = aiSig(result, x); const lot = (!x && lotOf(result)) || null;
    b.disabled = true; b.classList.add('is-busy'); const txt = b.querySelector('.mt5-go-txt'); const label = txt.textContent; txt.textContent = L('عم يتبعت…', 'Sending…');
    try {
      const r = await applySignal(s, { lot });
      toast(L(`انبعتت ${r.orders.length === 3 ? '3 أوامر (ثلث لكل هدف)' : 'الصفقة'} لـ MT5 ${r.link.account}. النتيجة بسجل خانة MT5.`, `Sent ${r.orders.length === 3 ? '3 orders (a third per target)' : 'the trade'} to MT5 ${r.link.account}. Result in the MT5 page log.`), 'success', 6000);
      b.closest('.rc-mt5').outerHTML = `<div class="rc-mt5 aisg-mt5"><span class="mt5-go is-done" role="status">✓ ${esc(L('انطبقت على MT5', 'Applied on MT5'))}</span></div>`;
    } catch (e) {
      b.disabled = false; b.classList.remove('is-busy'); txt.textContent = label; b.classList.add('is-shake'); setTimeout(() => b.classList.remove('is-shake'), 500);
      toast(MT5_ERR[e.code] || L('ما انطبقت: ', 'Not applied: ') + (e.code || 'error'), 'error', 7000);
    }
  }

  // Back-test from the performance panel (v234): real candles only, every strategy on its own, nothing tuned.
  async function runBacktest(btn) {
    const my = ++btRun; btn.disabled = true;
    const bar = box.querySelector('[data-btbar]'); const fill = box.querySelector('[data-btfill]'); const pc = box.querySelector('[data-btpct]'); const msg = box.querySelector('[data-btmsg]');
    const say = (t) => { if (msg) msg.textContent = t; };
    try {
      if (bar) bar.hidden = false; say(L('عم نجيب الشموع الحقيقية…', 'Loading real candles…'));
      const inst = getInstrument(p.symbol); const asset = ASSET_OF[inst?.type] || 'crypto'; const tfSec = TIMEFRAMES.find((x) => x.id === p.tf)?.seconds || 900;
      const ds = await getHistory(p.symbol, p.tf, 1500); if (my !== btRun || !el.isConnected) return;
      if (ds.mode !== 'live') { say(L('ما في بيانات حية لهالسوق هلق، ما في باك تست على أسعار مولّدة.', 'No live data for this market right now, no back-test on generated prices.')); btn.disabled = false; return; }
      const cs = ds.candles.filter((c) => c.time + tfSec <= Date.now() / 1000 + 1);
      const { runSuite } = await import('../services/aiBacktest.js');
      say(L(`عم نختبر ${cs.length} شمعة…`, `Testing ${cs.length} candles…`));
      const res = await runSuite(cs, { symbol: p.symbol, tf: p.tf, tfSec, assetClass: asset, volumeKind: ds.volumeKind, costPct: costModel(asset).totalPct, style: p.style, source: ds.source },
        { onProgress: (f) => { const v = Math.round(f * 100); if (fill) fill.style.width = `${v}%`; if (pc) pc.textContent = `${v}%`; }, isCancelled: () => my !== btRun || !el.isConnected });
      if (my !== btRun || !el.isConnected) return;
      if (res.error) { say(L(`تاريخ مش كافي (${cs.length} شمعة، لازم 400 على الأقل).`, `Not enough history (${cs.length} candles, 400 needed).`)); btn.disabled = false; return; }
      saveBacktest(res); paint();
    } catch (e) { if (my === btRun && el.isConnected) { say(L('ما قدرنا نكمّل الباك تست.', 'The back-test could not finish.')); btn.disabled = false; } }
  }

  function wire() {
    const q = (s) => box.querySelectorAll(s);
    q('[data-mt5ai]').forEach((b) => b.addEventListener('click', () => onMt5(b)));
    box.querySelector('[data-back]')?.addEventListener('click', () => { run++; btRun++; step = step === 7 ? dashFrom : step === 6 ? 0 : step >= 4 ? 3 : Math.max(0, step - 1); paint(); });
    q('[data-dash]').forEach((b) => b.addEventListener('click', () => { dashFrom = step; step = 7; paint(); }));
    box.querySelector('[data-bt]')?.addEventListener('click', (e) => runBacktest(e.currentTarget));
    box.querySelector('[data-reset]')?.addEventListener('click', () => { run++; step = 0; paint(); });
    q('[data-ai]').forEach((b) => b.addEventListener('click', (e) => pick(b, e, () => { step = 6; paint(); })));
    q('[data-style]').forEach((b) => b.addEventListener('click', (e) => { if (p.style !== b.dataset.style) { p.style = b.dataset.style; p.tf = defaultTf(p.style); } save(); pick(b, e, () => { step = 1; paint(); }); }));
    q('[data-market]').forEach((b) => b.addEventListener('click', (e) => { p.market = b.dataset.market; if (!symbolsOf(p.market).includes(p.symbol)) p.symbol = symbolsOf(p.market)[0]; save(); pick(b, e, () => { step = 2; paint(); }); }));
    q('[data-sym]').forEach((b) => b.addEventListener('click', (e) => { p.symbol = b.dataset.sym; save(); pick(b, e, () => { step = 3; paint(); }); }));
    q('[data-exec]').forEach((b) => b.addEventListener('click', (e) => {
      p.execution = b.dataset.exec; save(); q('[data-exec]').forEach((x) => x.classList.toggle('is-on', x === b));
      if (!still()) { const r = b.getBoundingClientRect(); const rip = document.createElement('span'); rip.className = 'aisg-ripple'; rip.style.left = `${e.clientX - r.left}px`; rip.style.top = `${e.clientY - r.top}px`; b.appendChild(rip); setTimeout(() => rip.remove(), 650); }
      const n = box.querySelector('[data-onote]'); if (n) { n.querySelector('span').textContent = ONOTE()[p.execution]; restartClass(n, ['is-swap'], 'is-swap'); }
    }));
    q('[data-tf]').forEach((b) => b.addEventListener('click', () => { p.tf = b.dataset.tf; save(); q('[data-tf]').forEach((x) => x.classList.toggle('is-on', x === b)); }));
    const form = box.querySelector('[data-form]');
    form?.account.addEventListener('change', () => { form.riskPct.value = ACCOUNTS[form.account.value].riskPct; });
    form?.addEventListener('submit', (e) => {
      e.preventDefault();
      const n = (v) => Number(String(v).replace(/[, $%]/g, ''));
      const cap = n(form.capital.value); const risk = n(form.riskPct.value);
      if (!(cap > 0)) { toast(L('اكتب رأس مال صحيح.', 'Enter a valid capital.'), 'error'); return; }
      if (!(risk > 0 && risk <= 5)) { toast(L('المخاطرة لازم تكون بين 0.05% و 5%.', 'Risk must be between 0.05% and 5%.'), 'error'); return; }
      lockStyle(p); if (!STYLES[p.style].tfs.includes(p.tf)) p.tf = defaultTf(p.style);
      const rs = riskSettings({ dailyLossPct: n(form.dailyLossPct?.value ?? p.dailyLossPct), maxOpen: n(form.maxOpen?.value ?? p.maxOpen) });
      p = { ...p, account: form.account.value, capital: Math.min(cap, 1e12), riskPct: risk, dailyLossPct: rs.dailyLossPct, maxOpen: rs.maxOpen, ltf: Boolean(form.ltf?.checked) }; save(); generate();
    });
    q('[data-again]').forEach((b) => b.addEventListener('click', () => { step = 0; result = null; paint(); }));
    box.querySelector('[data-watch-stop]')?.addEventListener('click', () => { stopWatch(); box.querySelector('[data-watch]')?.remove(); if (step === 8) { step = 0; paint(); } });
    box.querySelector('[data-save]')?.addEventListener('click', (e) => {
      const r = result.reading;
      // v234: the same strategy, market, direction and entry already open → not saved twice
      if (isDuplicate(listTrades(), { symbol: result.symbol, strategy: r.strategy || 'smc', direction: r.plan.direction, entry: r.plan.entry, atr: r.atr })) { toast(L('هالإشارة محفوظة ومفتوحة من قبل.', 'This signal is already saved and open.'), 'error'); e.currentTarget.disabled = true; return; }
      saveTrade(r, r.ctx); e.currentTarget.disabled = true;
      import('../services/bank/push.js').then((m) => m.enablePush()).catch(() => { try { if (typeof Notification !== 'undefined' && Notification.permission === 'default') Notification.requestPermission(); } catch { /* */ } });
      toast(L('انحفظت. رح يوصلك إشعار عند كل هدف أو وقف.', 'Saved. You will get an alert at each target or stop.'), 'success');
    });
    box.querySelectorAll('[data-save-other]').forEach((b) => b.addEventListener('click', () => {
      const x = result?.reading?.others?.[Number(b.dataset.saveOther)]; if (!x) return;
      const r = result.reading;
      if (isDuplicate(listTrades(), { symbol: result.symbol, strategy: x.id, direction: x.plan.direction, entry: x.plan.entry, atr: r.atr })) { toast(L('هالإشارة محفوظة ومفتوحة من قبل.', 'This signal is already saved and open.'), 'error'); b.disabled = true; return; }
      saveTrade({ ...r, plan: { ...x.plan, strategy: x.id }, size: x.size, strategy: x.id, learnCtx: x.ctx }, r.ctx); b.disabled = true;
      toast(L('انحفظت. رح يوصلك إشعار عند كل هدف أو وقف.', 'Saved. You will get an alert at each target or stop.'), 'success');
    }));
    box.querySelector('[data-chart]')?.addEventListener('click', () => { store.set('symbol', result.symbol); store.set('timeframe', result.tf); location.hash = '#/app'; });
    box.querySelector('[data-copy]')?.addEventListener('click', () => {
      const txt = box.querySelector('.aisg-reco p')?.textContent || '';
      navigator.clipboard?.writeText(txt).then(() => toast(L('انتسخت', 'Copied'), 'success')).catch(() => {});
    });
  }

  if (wsaved?.base?.symbol && getInstrument(wsaved.base.symbol)) { startWatch({ ...wsaved.base }); if (OWN()) step = 8; }   // one watcher: this page takes it over
  paint();
  return el;
}

const MLABEL = {
  crypto: { name: ['كريبتو', 'Crypto'], sub: ['بيتكوين، إيثيريوم وغيرهم', 'Bitcoin, Ethereum & more'] },
  metal: { name: ['معادن وسلع', 'Metals'], sub: ['ذهب، فضة، نفط وغاز', 'Gold, silver & commodities'] },
  index: { name: ['مؤشرات', 'Indices'], sub: ['US30، US100، SPX500 وغيرهم', 'US30, US100, SPX500 & more'] },
  forex: { name: ['فوركس', 'Forex'], sub: ['أزواج العملات', 'Currency pairs'] },
};
