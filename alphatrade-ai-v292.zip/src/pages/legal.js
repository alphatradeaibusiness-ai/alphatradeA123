// Terms of use and privacy policy: two tabs, numbered sections, a clear "draft for legal review" notice.
import { h, esc } from '../utils/dom.js';
import { t, getLang } from '../i18n/index.js';
import { icons } from '../components/icons.js';
import { fillBusiness } from '../config/business.js';

export const LEGAL_UPDATED = '2026-11-10';
const T = (k, p) => t(`lg.${k}`, p);

export function renderLegal({ standalone = false } = {}) {
  const TABS = ['terms', 'privacy', 'refund', 'challenges', 'contact'];
  let tab = TABS.find((k) => location.hash.includes(k)) || 'terms';
  const date = new Date(`${LEGAL_UPDATED}T00:00:00Z`).toLocaleDateString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { year: 'numeric', month: 'long', day: 'numeric' });
  const el = h(`<section class="subpage legal page-enter ${standalone ? 'legal-standalone' : ''}">
    ${standalone ? `<p><a class="btn btn-sm btn-ghost" href="#/login">${esc(T('back'))}</a></p>` : ''}
    <div class="subpage-head"><h1>${icons.book || ''}<span>${esc(T('title'))}</span></h1><p class="muted">${esc(T('sub'))}</p></div>
    <div class="alert alert-info legal-draft">${icons.info || ''}<div>${esc(T('draft'))}</div></div>
    <div class="seg legal-tabs" role="tablist">${TABS.map((k) => `<button type="button" role="tab" data-tab="${k}">${esc(T(`tabs.${k}`))}</button>`).join('')}</div>
    <article class="card tool-card legal-body" data-body></article>
  </section>`);
  const draw = () => {
    el.querySelectorAll('[data-tab]').forEach((b) => { b.classList.toggle('is-on', b.dataset.tab === tab); b.setAttribute('aria-selected', String(b.dataset.tab === tab)); });
    el.querySelector('[data-body]').innerHTML = `<h2 class="card-title">${esc(T(`tabs.${tab}`))}</h2><p class="muted tool-note">${esc(T('updated', { d: date }))}</p>
      <ol class="legal-list">${T(tab).map(([a, b]) => `<li><h3>${esc(a)}</h3><p>${esc(fillBusiness(b))}</p></li>`).join('')}</ol>`;
  };
  el.querySelector('.legal-tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (!b) return; tab = b.dataset.tab; draw(); });
  draw();
  return el;
}
