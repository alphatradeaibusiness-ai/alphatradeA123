// Back-test of every strategy of the app on REAL prices of gold, the US indices (ETF proxies), forex and crypto (Twelve Data),
// with the app's own engine (services/backtest.js) and the app's default rules. Costs: the app default AND a realistic low-cost level.
import fs from 'node:fs';
import { loadMarket, agg } from './load.mjs';
const P = '/tmp/claude-0/-home-claude/8ec99056-1357-57a3-bb99-754394c63670/scratchpad/w/alphatrade-ai-final/project';
const OUT = '/tmp/claude-0/-home-claude/8ec99056-1357-57a3-bb99-754394c63670/scratchpad/mkt';
const { runStrategy, summarize, rulesFrom } = await import(`${P}/src/services/backtest.js`);
const { evaluateCombo } = await import(`${P}/src/services/signals.js`);
const { store } = await import(`${P}/src/state/store.js`);
const { getInstrument, STOP_LOSS_POINTS, TARGET_POINTS } = await import(`${P}/src/config/instruments.js`);

// app symbol, data file, kind, price scale (ETF → index level, approximate), realistic round-trip cost in % of price
export const MARKETS = [
  ['XAUUSD', 'XAUUSD', 'metal', 1, 0.01],
  ['US30', 'DIA', 'etf', 100, 0.006], ['US100', 'QQQ', 'etf', 41, 0.006], ['SPX500', 'SPY', 'etf', 10, 0.006],
  ...['EURUSD', 'GBPUSD', 'USDJPY', 'USDCHF', 'AUDUSD', 'NZDUSD', 'USDCAD', 'EURGBP', 'EURJPY', 'GBPJPY'].map((s) => [s, s, 'fx', 1, 0.008]),
  ...['BTC', 'ETH', 'SOL', 'BNB', 'XRP', 'DOGE', 'ADA', 'AVAX', 'LINK', 'LTC', 'TRX', 'DOT', 'ATOM', 'NEAR', 'SUI', 'PEPE'].map((b) => [`${b}USDT`, `${b}USD`, 'crypto', 1, 0.04]),
];
const STRATS = ['edh', 'lbr', 'classic', 'smc', 'zone'];
const TFS = { '5m': 300, '15m': 900, '1h': 3600, '4h': 14400 };

const only = process.argv[2] ? process.argv[2].split(',') : null;
const results = [];
for (const [sym, file, kind, scale, lowCost] of MARKETS) {
  if (only && !only.includes(sym)) continue;
  const inst = getInstrument(sym);
  const m5 = loadMarket(file, '5min', kind, scale);
  const h1raw = loadMarket(file, '1h', kind, scale);
  if (m5.length < 1000) { console.log(sym, 'no data'); continue; }
  // 1h / 4h: the longer 1-hour history when fetched, else built from 5m
  const h1 = h1raw.length > m5.length / 12 ? h1raw : agg(m5, 3600);
  const series = { '5m': m5, '15m': agg(m5, 900), '1h': h1, '4h': agg(h1, 14400) };
  const htf = { h4: series['4h'], d1: agg(h1, 86400) };
  const base = { ...rulesFrom(store.get('settings'), inst), forced: null, pointSize: inst.pointSize, slPoints: STOP_LOSS_POINTS, tpPoints: TARGET_POINTS, volumeKind: kind === 'etf' ? 'real' : 'none', openOnLast: false, htfCandles: htf, edhDaily: htf.d1 };
  for (const [costName, fee] of [['app', base.feePct], ['low', lowCost]]) {
    const rules = { ...base, feePct: fee, minRiskPct: 5 * fee };
    for (const tf of Object.keys(TFS)) {
      const c = series[tf];
      for (const st of STRATS) {
        if (st === 'lbr' && tf !== '5m') continue;
        let tr;
        try { tr = runStrategy(st, c, rules).trades; } catch (e) { console.log(sym, tf, st, 'ERR', e.message); continue; }
        const s = summarize(tr).total; const ev = evaluateCombo(tr); const ev65 = evaluateCombo(tr, 65);
        const sorted = [...tr].sort((a, b) => a.closeTime - b.closeTime); const cut = Math.floor(sorted.length * 0.6);
        const recent = summarize(sorted.slice(cut)).total;
        const pip = (kind === 'etf' ? 1 : 10) * inst.pointSize;
        results.push({ sym, kind, cost: costName, fee, tf, st, from: c[0].time, to: c.at(-1).time, bars: c.length,
          n: s.trades, win: +s.winRate.toFixed(1), R: +s.r.toFixed(2), exp: +s.expectancy.toFixed(3), pf: Number.isFinite(s.profitFactor) ? +s.profitFactor.toFixed(2) : null,
          pips: +(s.points * inst.pointSize / pip).toFixed(0), recentN: recent.trades, recentWin: +recent.winRate.toFixed(1), recentR: +recent.r.toFixed(2),
          gate62: ev.qualified, gate65: ev65.qualified });
      }
    }
  }
  const mine = results.filter((r) => r.sym === sym && r.cost === 'low' && r.n >= 20).sort((a, b) => b.R - a.R).slice(0, 3);
  console.log(sym.padEnd(8), `5m ${m5.length} bars ${new Date(m5[0].time * 1000).toISOString().slice(0, 10)}→`, mine.map((r) => `${r.tf}/${r.st} n${r.n} ${r.win}% R${r.R}`).join(' | '));
}
fs.writeFileSync(`${OUT}/results${only ? '_' + only.join('_') : ''}.json`, JSON.stringify(results));
