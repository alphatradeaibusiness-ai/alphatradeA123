# Screenshot protection — what is possible where

| Where | What AlphaTrade AI does | Can screenshots be fully blocked? |
|---|---|---|
| Website / installed web app (PWA), any phone or computer | The app is covered the moment it leaves the screen (app switcher, home button, another tab or window), so the "recent apps" preview shows only a cover. Print Screen and the macOS screenshot shortcuts cover the page and clear the copied image where the browser allows. Printing prints only a notice. | **No.** No website can stop the phone's own screenshot buttons (Power + Volume) or screen recording. |
| Android app (native wrapper) | Add `FLAG_SECURE` to the activity window. Screenshots and screen recordings then come out black, and the app is hidden in "recent apps". | **Yes**, on Android this is enforced by the system. |
| iPhone app (native wrapper) | iOS does not allow an app to block screenshots. It can hide content while the screen is being recorded or mirrored (`UIScreen.isCaptured`) and react after a screenshot (`userDidTakeScreenshotNotification`). | **No** — only hiding and detection. |

## Turning on the Android protection (when the site is wrapped as an app)
With Capacitor: `npm i @capacitor-community/privacy-screen` and `npx cap sync`, or in `MainActivity` add
`getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);`

The web code (`src/services/privacy.js`) keeps working inside the app as an extra layer.
