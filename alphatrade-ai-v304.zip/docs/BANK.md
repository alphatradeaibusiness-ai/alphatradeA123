# Digital bank (v149)

A wallet, deposits, withdrawals, identity check (KYC), Visa card request and automatic investing inside AlphaTrade AI.
Page: **Menu → Account → Digital bank** (`#/app/bank`). Server: `server/bank/*`, routes `/api/bank/*`.

> **What this is and what it is not.** This is the *platform side* of a bank: accounts, a double-entry ledger, limits,
> encryption, review queues and an audit trail. It is **not connected to any bank, payment network, card issuer or broker.**
> Real money only moves if you (the owner) move it outside the site and then confirm it here, and running that for other
> people needs the licences of your country (e-money / payment institution, VASP for crypto, card programme with an issuer).
> Talk to a lawyer before turning on `BANK_MODE=live` for anyone but yourself.

## Turning it on

| Variable | Default | Meaning |
|---|---|---|
| `BANK_MASTER_KEY` | — (bank off) | **Required.** 32+ random chars. Encrypts personal data (KYC, IBANs, addresses, card delivery). Different from `AI_KEY_SECRET`. Lose it = encrypted data is unreadable. Generate: `openssl rand -base64 48` |
| `BANK_MASTER_KEY_PREV` | — | Old key(s), comma-separated, while rotating. Records are re-wrapped to the new key when touched. |
| `BANK_MODE` | `sandbox` | `sandbox`: test funds button, paper auto-invest at real Binance prices, nothing real. `live`: no test funds; deposits/withdrawals are confirmed by the owner after a real transfer made outside the site. |
| `BANK_DATA_DIR` | `<SERVER_DATA_DIR>/bank` | Where `bank.db` (SQLite, WAL) lives. Persistent disk, mode 0700/0600. **Never share it with the worker.** |
| `BANK_REAUTH_MINUTES` | live 15, sandbox 0 | Money and personal-data actions need a sign-in younger than this (Firebase `auth_time`). 0 = off. |
| `BANK_REQUIRE_MFA` | live 1, sandbox 0 | 1 = those actions need a Firebase second factor (turn on MFA in Firebase → Authentication). |
| `BANK_DEPOSIT_INSTRUCTIONS_USD` (`_EUR`, `_USDT`, `_BTC`) | — | Text shown with a live deposit (your account / wallet details). Without it the user sees "details not configured". |
| `ADMIN_EMAILS` | owner email | Who reviews (must be a **verified** email). The owner cannot review their own items. |

Requirements: **Node 22.13+** (`node:sqlite`). On an older Node the site runs and `/api/bank/*` answers `503 bank_disabled`.
The bank runs in **one process** (SQLite + in-memory live stream); do not run several web replicas against one `bank.db`.

`compose.yaml` already passes the `BANK_*` variables to the `web` service; `bank.db` lands on the `server-data` volume, which the worker does not mount.

## How money is kept

* **Double-entry ledger**, integer minor units (USD/EUR cents, USDT 6 dp, BTC 8 dp). Every transaction's legs sum to zero; the
  database refuses negative wallet/hold balances (CHECK) and refuses edits/deletes of ledger entries and audit rows (triggers).
* **Idempotency**: every money request carries a key (`Idempotency-Key` header or `idem`); a retry never doubles a credit or a debit.
  A bank reference (`extRef`) can be credited only once.
* **Holds**: a withdrawal moves the amount + fee into a hold first; reject/cancel releases it, completion pays it out.
* **Hash-chained audit log** of every action (who, what, when — no personal data in it). Owner desk shows "intact / broken"
  for both the ledger and the chain; the server also checks both at start.

## Security controls

* Firebase ID token on every call (verified on the server); email must be verified. Owner = verified email in `ADMIN_EMAILS`.
* Step-up for money/personal-data actions (fresh sign-in, MFA) in live mode.
* Envelope encryption (AES-256-GCM, per-record key wrapped by the master key, bound to the user and field); search by HMAC blind index only.
  Personal data is never returned in lists, never logged, never stored in the browser. Only the owner's review screen decrypts one record at a time (and that view is audited).
* Withdrawal rules: KYC level 1+, daily limits by level (L1 1,000 / L2 25,000 per currency per 24 h), minimum and fee per currency,
  max 5 requests per hour, a new withdrawal account usable only **24 h** after it is added, risk flags shown to the reviewer
  (first withdrawal, new account, large amount, money that just arrived). Every withdrawal is reviewed by a person; separation of duties.
* IBAN checksum, crypto address format per network, ISO country codes, age 18+, blocked-country list (illustrative — set yours).
* Rate limits (IP 240/min, user 120/min, writes 30/min), 16 KB JSON bodies only, writes need an allowed `Origin`.
* Real-time balances over `/api/bank/stream` (per-user SSE, only "something changed" pings — the page then re-reads).

## Flows

* **Deposit**: user asks → gets a reference (`ATB-…`) → pays outside with that reference → owner confirms with the bank/tx reference → wallet credited. Requests expire after 7 days.
* **Withdraw**: KYC → add account (IBAN or crypto address) → wait 24 h → request (amount + fee held) → owner approves → owner pays outside → marks completed with the payout reference.
* **KYC**: level 1 (identity + address), level 2 (+ source of funds, proof of address reference). Owner approves/rejects with a reason.
* **Visa card** (level 2): physical (delivery address, standard $15 / express $35, fee charged from USD and refunded if rejected/cancelled) or virtual.
  Status steps: requested → review → sent to issuer → produced → shipped (tracking) → delivered → active (user activates) / frozen.
  No card number, CVV or PIN is ever stored here — that is the issuer's job.
* **Auto-invest**: plans in USDT for BTC/ETH/SOL/BNB, daily/weekly/monthly, daily cap, skips when funds are short (pauses after 3),
  no catch-up of missed runs, refuses stale prices (>60 s). The first buy happens one period after the plan is created. Sandbox = paper fills at the live Binance price. Live without a broker adapter = orders recorded as `no_broker`, no money moves.

## Backups and keys

Back up `bank.db` **and** its `-wal` file together (or stop the server / use `sqlite3 bank.db ".backup x.db"`). Keep `BANK_MASTER_KEY`
in a secret manager, separately from the backups. Rotation: set the new key in `BANK_MASTER_KEY`, the old one in `BANK_MASTER_KEY_PREV`.

## Not done / needs you

* No bank rails, card issuer, KYC document provider or broker is connected — each needs a contract and an adapter.
* Real Firebase MFA, real payments, a real card and the real Binance price feed were not tested here (no network in the build sandbox).
* Compliance: limits, blocked countries, retention periods and the KYC fields must be set by whoever holds the licence.

# v150 additions

Everything below runs on the same ledger, encryption and audit trail as above. **In sandbox mode** every feature works end to end
with test funds and built-in simulators. **In live mode** the features that move real money outside the platform stay off until a
partner adapter is connected (they answer `no_card_issuer`, `no_fx_provider`, `no_transfer_provider`, `no_open_banking_provider`,
`no_broker`). No real card numbers, bank rails or custody exist in this code.

| Feature | Where | Live mode |
|---|---|---|
| Pockets (sub-wallets), up to 10, with goals | Wallet tab | works (internal ledger moves) |
| Transaction labels (category, tags, encrypted note), history filters | Wallet tab | works |
| Vault: savings lock, release after 24 h (cancellable), passkey + co-signers | Wallet tab | works — **not** crypto cold storage (needs a licensed custodian) |
| Converter (reference rates: ECB EUR, Binance BTC, USDT = 1 USD) | Wallet tab | calculator only; conversion needs a liquidity partner |
| Passkeys (fingerprint / face, WebAuthn ES256/RS256) | Security tab | works |
| Freeze everything | Security tab | works |
| Co-signers (M of N approvals for large withdrawals / vault releases) | Security tab | works |
| Notification centre + Web Push (VAPID, aes128gcm, per-device, hide amounts) | bell + Security tab | works |
| Virtual Visa cards: standard, single-use, one-merchant; limits; reveal via issuer; merchant blocks | Cards tab | needs a card issuer adapter |
| Card authorisation engine (limits, budget block, freeze, merchant lock/blocks, balance) + signed issuer webhook | server | works once an issuer sends events |
| Budgets (monthly per category, alerts 80/100 %, optional decline) | Budget & saving tab | works |
| Subscriptions (detected from repeated card charges, or manual; reminder 3 days before; stop = merchant block) | Budget & saving tab | works |
| Saving rules: round-ups, % of deposits, fixed schedule (cap + floor) | Budget & saving tab | works |
| Rewards: points for card spend, identity check, first passkey (no trading-volume points); 1,000 pts = 5 USD; 12-month expiry | Rewards tab | cashback off unless `BANK_REWARDS_CASHBACK=1` |
| Insights (plain rules) + dashboard (net worth, 6-month flow, spend by category) | Insights tab | works |
| Open Banking (read-only, 90-day consent, delete on unlink) | Insights tab | needs an AISP provider adapter (sandbox has a DEMO provider) |
| Cross-border transfer (quote valid 60 s, then the normal withdrawal review) | Withdraw tab | needs a transfer partner |
| Investment sale (paper) + yearly tax report (FIFO) + CSV | Invest tab | sale needs a broker; report works |
| Support tickets (encrypted), owner desk, reply notifications | Support tab | works |
| Voice commands (browser speech recognition, Arabic/English; money moves only after an on-screen confirmation) | mic button | works where the browser supports it |
| Owner dashboard (no personal data) | Owner desk | works |

## Passkeys and the step-up rule

* A user **without** a passkey: sensitive actions use the sign-in step-up (`BANK_REAUTH_MINUTES`, `BANK_REQUIRE_MFA`).
* A user **with** a passkey: sensitive actions need a passkey assertion over a server challenge that is bound to the exact action
  (purpose + amount + destination…), single-use and valid 2 minutes. Changing the amount after signing fails (`passkey_binding_mismatch`).
  Purposes: withdraw, beneficiary_add/remove, vault_release, intl_transfer, approval_vote, passkey_add/remove, card_reveal, vcard_create,
  card_limits, policy_set, unfreeze, approver_remove, redeem, ob_link. Adding a second passkey needs the first one.
* The relying party is the request's origin host; set `BANK_RP_ID` (your domain) and `BANK_ORIGINS` (comma separated, e.g.
  `https://alphatrade.example`) in production so every device registers against the same RP id.
* Attestation statements are not verified (synced passkeys send "none"); challenge, origin, RP id, user verification and signature are.

## Card issuer webhook

`POST /api/bank/issuer/webhook`, enabled when `BANK_ISSUER_WEBHOOK_SECRET` (32+ chars) is set. Header
`x-issuer-signature: t=<unix seconds>,v1=<hex HMAC-SHA256(secret, "<t>.<raw body>")>`, ±5 minutes. Generic events (an adapter maps the
provider's format to these): `authorization.request` {eventId, cardRef, merchant, category, amount, currency} → `{approved, reason}`;
`transaction.settled` {eventId, authEventId}; `transaction.reversed` {eventId, authEventId}. Every event id is processed once.

## New environment variables

`BANK_RP_ID`, `BANK_ORIGINS`, `BANK_VAPID_SUBJECT` (mailto: or https: contact for push services), `BANK_ISSUER_WEBHOOK_SECRET`,
`BANK_REWARDS_CASHBACK`. VAPID keys are generated on first start and stored encrypted in `bank.db`.

## Database migration

`bank.db` from v149 is migrated automatically at start (accounts table rebuilt with the new account kinds; balances copied as they are;
`PRAGMA user_version = 2`). Back up `bank.db` before upgrading anyway.

## v151 — card details, identity check, art, Apple Pay, premium UI

- **Card number / CVV.** A real Visa number can only come from a card issuer under a Visa programme; a number made here cannot be charged. The sandbox issuer makes a unique 16-digit **test** number per card (Luhn-valid, reserved test BIN 400000). It is stored only envelope-encrypted (AAD bound to the card) with a blind hash that forces uniqueness. The 3-digit CVV is **never stored**: it is derived on demand with a keyed HMAC of number + expiry (only 1,000 CVV values exist, so it is unique per card number, not across cards). Details show for 30 s after step-up (passkey/MFA), max 10 reveals per hour, audit-logged, `no-store`, and are wiped from the page on hide/timeout/tab switch. With a real issuer, `reveal` returns the issuer's token for its own secure frame and no number reaches this server.
- **Request form check.** Name on card and date of birth must match the owner-approved KYC; failures are generic, counted and lock the form after 5 per hour. Also applies to the physical card request.
- **Card art.** 6 muted colours × 5 patterns from a fixed list (nothing user-supplied reaches CSS); changeable later.
- **Apple Pay.** `POST /api/bank/vcards/:id/apple-wallet` validates Apple's certificates/nonce and calls `issuer.provisionApplePay(ref, req)`. It needs Apple's push-provisioning entitlement for the iOS app and an issuer that supports it; until then it answers `apple_pay_unavailable` (501). Wallet shows a device-specific number, never the card number.
- DB migration v2→v3 adds `art`, `holder`, `pan_enc`, `pan_hash` to `vcards` in place.
- **UI:** the premium redesign was tried and reverted at the owner's request; the previous look is back. Only the new card face remains.
- **Removed:** the TradingView embed (script, overlay, button, CSP entry, test). Lightweight Charts (the open-source library that draws the site's own chart) stays.

## v152 — authenticator 2FA, fraud scoring, compliance reports, identity, key rotation

**Authenticator app (TOTP, RFC 6238).** `features/totp.js`. Enrol → `POST /totp/enroll` (returns the base32 secret + `otpauth://` URI), confirm with a code → 8 single-use backup codes (stored only as keyed hashes). The secret is envelope-encrypted (AAD `totp:<uid>`). A code is accepted once (the time step is remembered), ±1 step of clock drift, and 5 wrong codes in 10 minutes lock the factor for that window. Where it applies: `gate()` (withdrawals, beneficiaries, vault release, intl transfer, approvals, policy, freeze-off…) and the direct step-up routes (KYC submit, card request, card freeze/unfreeze/activate, co-signer invite). **Passkeys take priority**: a user with a passkey keeps using it; TOTP is the second factor for users without one. The code travels in the body field `passkey` (string) or `totp`. The client asks for it automatically when the server answers `totp_required`. Not covered: `/admin/*` (owner already needs a recent sign-in + Firebase MFA in live mode).

**Fraud / risk scoring.** `features/risk.js`, rule-based and explainable (every point has a stored reason; thresholds in `cfg.risk`, defaults review 40 / block 85). Withdrawals: first withdrawal, new beneficiary, deposit-then-withdraw, near daily limit, unusual amount vs history, new account, recent security change, failed codes, rapid requests. `block` → `risk_blocked` (403, event stored, user notified, nothing moves); `review` → flag `risk_review` + an open event for the owner (`GET /admin/risk`, `POST /admin/risk/:id/review`, never your own). Cards: repeated non-balance declines or bursts of small charges at many merchants → decline `risk_card_testing`/`risk_velocity`, freeze **that card only**, notify. KYC: the same ID document on two accounts is refused with a generic error and recorded. This is not a trained model: tune on real data before relying on it.

**Compliance reports.** `features/compliance.js`. `runDue` stores one report per UTC day and per month (UNIQUE period): KYC mix, deposit/withdrawal volumes per currency, large transactions (default ≥ 10,000 USD at reference rates), cross-border transfers over the travel-rule threshold (default 1,000 USD), risk events, freezes, card declines, 2FA events, ledger + audit-chain verification. Owner: `GET /admin/compliance`, `GET /admin/compliance/:id[.csv]`, `POST /admin/compliance/run` (ad-hoc window ≤ 1 year). CSV cells are formula-injection safe. It supports a compliance officer; it is **not** a regulator filing (SAR/STR, FATCA/CRS, etc. need your licence's format and a human decision).

**Identity.** ID number is hashed with the vault's blind key (`kyc_ids`) to detect reuse; documents expiring within 30 days are refused (`id_expiring`). Document images are still never stored here — the verification vendor holds them.

**Key rotation.** Set `BANK_MASTER_KEY` to the new secret and `BANK_MASTER_KEY_PREV` to the old one, then `POST /admin/rewrap` (owner) re-wraps KYC, card forms, card numbers, beneficiaries and TOTP secrets. Caveat: the *blind hashes* (card-number uniqueness, ID reuse, beneficiary de-dup, backup codes) are keyed by the master key and change with it — after a rotation, regenerate backup codes (users can do it in the Security tab).

**Already existing, unchanged:** passkeys + Firebase second factor, envelope encryption, KYC tiers, USD/EUR/USDT/BTC wallets with conversion and cross-border quotes, budgets with 80/100 % alerts, pockets with goals and saving rules, notification centre + Web Push, tax CSV.

Schema version 4 (`totp`, `totp_backup`, `risk_events`, `compliance_reports`, `kyc_ids`); migration is automatic and additive.
