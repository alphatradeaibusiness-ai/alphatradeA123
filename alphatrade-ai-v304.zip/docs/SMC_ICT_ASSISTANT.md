# SMC / ICT trade assistant (v153)

First card of the dashboard's side column (beside the chart on desktop, under it on phones).

## Inputs
Swing / Scalp · Market / Limit · asset type (auto from the symbol, or crypto / forex / metals / indices / energy / stocks) · account type (cash/spot, margin, prop firm, demo) · capital (USD) · risk % per trade (max 5 %) · leverage · draw on chart. Saved per account on this device.

## What it reads (src/services/smcAssist.js — pure, tested)
- **Bias**: market structure on the higher frames — swing: Daily (+4h below 4h charts; Weekly on a Daily chart), scalp: 4h + 1h. Frames that disagree → NO TRADE. The real 4h/Daily candles are loaded when available; otherwise they are built from the chart and the panel says so.
- **Liquidity**: buy-side highs above price (untaken swing highs, equal highs, PDH, PWH, session highs on scalp) and sell-side lows below.
- **Sweep + MSS**: a wick through a liquidity level that closed back inside, then a structure break the other way.
- **POI**: a still-valid order block (no close through its far edge; "OB+FVG" when the break left an imbalance) or an unfilled FVG on the bias side, in discount for buys / premium for sells. OTE 62–79 % and ICT kill zones (London 02–05, New York 07–10 New York time) are checked.
- **Entry**: limit → OB near edge or FVG midpoint; market → only when price is in the POI now and reacting, otherwise **WAIT**.
- **Stop**: beyond the POI (or the sweep wick) + ATR buffer, never tighter than a minimum. **Targets**: the nearest liquidity in the trade's direction; R-multiples only fill missing slots. The R:R that is checked is to the furthest real liquidity target.
- **Size**: amount at risk = capital × risk %; units = risk / stop distance; capped by cash (spot) or leverage; lots only where the contract size is a convention (forex 100 000, XAUUSD 100 oz).

Every condition is listed with ✓/✗; required ones must all pass. The count is a checklist, not a win probability. The rules have not been back-tested as a strategy; saved trades show real outcomes.

## History ("save to my trades")
Only plans on real prices can be saved. Kept on the device per account and in the user's own encrypted file on the server (`/api/user/trades`, AES-256-GCM with `AI_KEY_SECRET`, file name = keyed hash of the uid, max 500). Outcomes are re-checked on real candles: waiting → open → all targets / stopped / break-even, or expired / missed. Result in R assumes equal parts at each target and the stop moved to entry after TP1. Shown in the panel, in a full table (CSV export) and on the Profile page.

## AI explanation
`POST /api/ai/smc` sends the reading (numbers only) to the site's AI key; the prompt forbids changing or inventing any level. Needs the AI key and sign-in, counts against the AI quota.

## Not changed
EDH and its settings, the existing SMC/strategy overlays and signals. The assistant is independent: it can disagree with the chart's AI badge or a strategy plan.

## v154 additions
- **Back-test** (`src/services/smcBacktest.js`, button "Back-test these rules"): the same rules candle by candle over 1 000–5 000 real candles, with costs, one position at a time, no look-ahead (window like the chart's; 4h / Daily candles only up to each moment; tested: a shorter history gives exactly the same closed trades). Walk-forward: first 70 % vs newest 30 %. Verdict is strict: < 30 trades → "too few"; average ≤ 0 → "negative"; newest 30 % not positive or < 10 trades → "not stable". The result is kept per market / timeframe / style / order type / required conditions and shown as a badge in the panel; it also goes to the AI explanation.
- **Which conditions help**: every distinct setup (also those a required check refused) is judged on its own and split by each condition (with / without, average R). A condition that helped by ≥ 0.2R with ≥ 10 cases each side can be made required in one click.
- **Required conditions**: structure, sweep, MSS, OTE, kill zone or LTF confirmation can be made required (Advanced).
- **Costs**: spread + commission % round trip (defaults per market: crypto 0.1, forex 0.01, metals 0.04, indices 0.03, energy 0.06, stocks 0.1). Every R:R is shown before and after costs; the R:R check, the back-test and saved results use the net figure.
- **Confirm entry**: a third order type. Inside the zone the lower timeframe (1D→1h, 4h→15m, 1h→5m, 15m/5m→1m) must close beyond the high/low of the last opposite candle before the extreme since the tap; stop = that extreme. Back-test of this mode: crypto only, up to ~30 000 LTF candles.
- **News**: high-impact calendar events for the market within the next hour (or the last 30 min) block a market / confirm entry and warn a limit order. Not available in back-tests (no historical calendar).
- **Daily loss stop**: realised loss of today's closed assistant trades (R × risk %) reaching the limit (default 3 %, prop 5 %) blocks new trades.
- **Alerts** (browser / phone notifications, permission asked): order filled, each target, stop, break-even, expiry, missed, and price within 0.3R of a waiting entry. Saved trades on other markets are re-checked once a minute.
- **Scanner**: the assistant on every market at the chart's timeframe, real data only, tradeable ones first; "Open" switches the chart.
- **Your results**: in "All trades" and on the Profile page — split by style, direction, order type, session, market and condition, trades after a loss, with an optional AI review (the existing review prompt; statistics only).
- **Copy plan** to the clipboard.

## v155 additions
- **Breaker blocks (BB)**: an order block price closed through flips sides and becomes a zone of the other direction, valid until a close goes back through it. **Inverse FVGs (IFVG)**: the same for fair value gaps. Both are POI candidates (entry: BB near edge, IFVG 50 %), drawn with orange dashed borders.
- **New York midnight open** (scalp, charts ≤ 1h): line on the chart and an optional check (buy below / sell above it). **Silver Bullet hours** (03–04, 10–11, 14–15 New York; scalp ≤ 15m): optional check. Both can be made required.
- **Exposure**: maximum open assistant trades (default 3, Advanced) is a required check; open trades in the same market type and direction are pointed out (they move together).
- **Partial close**: units to close at each target (equal parts — the management the results assume).
- **Top-down**: Weekly, Daily, 4h, 1h, 15m in one table — structure, last BOS/CHoCH, premium/discount, nearest zone above/below, nearest BSL/SSL — and how many frames agree.
- **Monte Carlo** (in the back-test): the same trades re-ordered 2 000 times (seeded) → typical and 1-in-20 drawdown in R and in % at your risk per trade, chance of a 20 % drawdown.
- **Compare settings** (in the back-test, same data): limit / market (/ confirm) × with or without a required sweep, ranked by the newest 30 % only, with a fitting warning; "Use these" applies a row.
- **Notes** on saved trades (history table), synced with the account.

## v156 additions
- **Volume displacement** (optional check, only where the market has real volume): the candle that created the zone (the biggest candle of an OB's break, the FVG's middle candle, the flip candle of a BB / IFVG) traded ≥ 1.5× its 20-candle average.
- **Judas swing** (optional, scalp ≤ 1h): after the Asian session, a London / New York kill-zone sweep ran the Asian low (buy) or high (sell) and closed back.
- **Risk per trade from the back-test**: the largest risk % whose 1-in-20 Monte Carlo drawdown stays under the drawdown you accept (default 10 %), and half-Kelly capped at 2 %; "Use x %" applies the smaller of the two. No edge (Kelly ≤ 0) → it says not to trade the settings.
- **Same settings on other markets**: the exact back-test on up to 12 crypto markets; "holds" only if ≥ 3 markets have ≥ 10 trades and ≥ 60 % of them are positive.
- **Zone alerts**: "Alert me at the zone" keeps the current zone for 7 days and notifies when price trades into it (checked with the chart and once a minute).
- **Drift**: in your results, the last 20 closed trades vs the ones before; flagged when clearly worse.

## v157 additions
- **Session clock** in the panel: which ICT window is open now (London / New York kill zone, the three Silver Bullet hours, New York time, DST-safe) and how long until the next one.
- **Chart image**: saves the chart with the assistant's zones and plan as a PNG.
- **Send to journal**: closed real-price assistant trades go to the Journal page once each (result in R after costs; units from the saved size).
- **This week vs last week** at the top of your results.
