# Backtest report — 2026-10-04
Engine: the app's own (services/backtest.js). Fee 0.1% round trip. Points are the app's unit (1 point = pointSize: BTC $1, ETH $0.1, SOL $0.01). Monthly cap = 1000 points, enforced as "no new trade if this month's realised loss + the trade's full stop + fee could pass the cap". First 60% of each history = in-sample, last 40% = out-of-sample.

## Per asset (all timeframes, all three strategies combined, cap ON)
| Asset | Trades | Win % | Net points | Avg R / trade | Worst month | Months over cap |
|---|---:|---:|---:|---:|---:|---:|
| BTCUSDT | 794 | 52.52 | -24,897 | -0.06 | -1,000 | 0 |

## Detail (cap OFF → cap ON)
| Asset | TF | Strategy | Period | Trades (no cap → cap) | Win % (cap) | Net pts (no cap) | Net pts (cap) | Avg R | PF | Max DD | Worst month (no cap → cap) | Verdict |
|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|---|
| BTCUSDT | 1m | classic | 2026-08-03 → 2026-10-02 | 4 → 4 | 50.00 | -315 | -315 | -0.04 | 0.73 | 662 | -590 → -590 | too few trades |
| BTCUSDT | 5m | classic | 2026-04-05 → 2026-10-02 | 140 → 46 | 52.17 | -13,350 | -1,867 | -0.05 | 0.84 | 4,770 | -8,951 → -841 | negative |
| BTCUSDT | 5m | smc | 2026-04-05 → 2026-10-02 | 1 → 1 | 0.00 | -487 | -487 | -1.20 | 0.00 | 487 | -487 → -487 | too few trades |
| BTCUSDT | 5m | zone | 2026-04-05 → 2026-10-02 | 1 → 1 | 0.00 | -788 | -788 | -1.09 | 0.00 | 788 | -788 → -788 | too few trades |
| BTCUSDT | 15m | classic | 2025-01-07 → 2026-10-02 | 888 → 260 | 52.69 | -62,863 | -10,447 | -0.07 | 0.87 | 17,563 | -14,112 → -1,000 | negative |
| BTCUSDT | 15m | smc | 2025-01-07 → 2026-10-02 | 2 → 1 | 0.00 | 259 | -611 | -1.14 | 0.00 | 611 | -611 → -611 | too few trades |
| BTCUSDT | 15m | zone | 2025-01-07 → 2026-10-02 | 1 → 1 | 0.00 | -621 | -621 | -1.13 | 0.00 | 621 | -621 → -621 | too few trades |
| BTCUSDT | 30m | classic | 2025-01-07 → 2026-10-02 | 726 → 144 | 51.39 | -126,635 | -6,574 | -0.07 | 0.88 | 12,865 | -21,537 → -1,000 | negative |
| BTCUSDT | 30m | smc | 2025-01-07 → 2026-10-02 | 2 → 0 | – | 1,065 | – | – | – | – | 0 → – | too few trades |
| BTCUSDT | 30m | zone | 2025-01-07 → 2026-10-02 | 3 → 2 | 50.00 | 1,200 | 468 | 0.19 | 1.84 | 559 | -559 → -559 | too few trades |
| BTCUSDT | 1h | classic | 2022-11-02 → 2026-10-02 | 836 → 280 | 51.79 | -61,154 | -8,233 | -0.07 | 0.89 | 12,839 | -27,638 → -998 | negative |
| BTCUSDT | 1h | smc | 2022-11-02 → 2026-10-02 | 3 → 1 | 0.00 | 914 | -353 | -1.08 | 0.00 | 353 | -2,193 → -353 | too few trades |
| BTCUSDT | 1h | zone | 2022-11-02 → 2026-10-02 | 5 → 4 | 0.00 | -4,288 | -2,731 | -1.12 | 0.00 | 2,731 | -1,558 → -859 | too few trades |
| BTCUSDT | 4h | classic | 2022-11-02 → 2026-10-02 | 209 → 49 | 69.39 | 6,306 | 7,660 | 0.22 | 1.86 | 2,115 | -17,034 → -961 | positive (verify out-of-sample) |
| BTCUSDT | 4h | smc | 2022-11-02 → 2026-10-02 | 7 → 0 | – | -9,897 | – | – | – | – | -5,076 → – | too few trades |

## Parameter grid — classic strategy, all assets and timeframes pooled (walk-forward)
| Setting | In-sample trades | In-sample avg R | Out-of-sample trades | Out-of-sample avg R |
|---|---:|---:|---:|---:|
| default (ATR×2, targets 1/2/3.5R) | 1647 | -0.09 | 1156 | -0.12 |
| stop ATR×3 | 1279 | -0.07 | 860 | -0.12 |
| targets 1.5/3/5R | 1273 | -0.11 | 903 | -0.12 |
| min stop 10× fee | 727 | -0.05 | 523 | -0.14 |

No setting was positive in both halves with ≥100 out-of-sample trades: do not adopt any of them as an "optimised" setting.

## How to read this
- A monthly cap bounds the realised loss only if fills happen at the stop; gaps and slippage can exceed it.
- If "Trades" collapses when the cap is on, the cap is smaller than one normal stop on that asset/timeframe: raise the cap or use a smaller timeframe-stop, do not widen the cap silently.
- "negative" verdicts mean the strategy loses money net of fees on that data; the cap only limits how much.