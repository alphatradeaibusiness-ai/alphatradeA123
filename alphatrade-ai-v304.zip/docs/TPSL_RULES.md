# TP / SL rules that keep the month inside a loss cap

Definitions: `P` = pointSize (BTC 1, ETH 0.1, SOL 0.01), `fee%` = your real round-trip fee, `ATR` = ATR(14) of the trading timeframe, `CAP` = monthly loss cap in points, `L` = realised loss so far this month (UTC calendar month, in points, counted when trades close).

1. **Stop distance** `risk = 2 × ATR` (price units). Points at risk: `rp = risk / P`.
2. **Fee floor** — skip the trade if `risk / entry × 100 < 5 × fee%` (the fee would cost more than 0.2R). Measured: 15m at 0.1% fee costs 0.19R, 1m costs 1.4R.
3. **Cap check (strict)** — take the trade only if `L + rp + fee_pts ≤ CAP`, where `fee_pts = fee%/100 × entry / P`. A trade can never lose more than its stop, so the month's realised loss cannot pass `CAP` (assuming the stop fills; a gap or slippage through the stop is NOT covered).
4. **Targets** `TP1 = entry ± 1R`, `TP2 = ± 2R`, `TP3 = ± 3.5R`; one third of the position leaves at each target.
5. **Break-even** — after TP1 the stop goes to the entry. A trade that touched TP1 can no longer lose (before fees).
6. **No trailing stop** — tested: it lowered the result on 15m, 1h and 4h (−0.17R vs −0.11R on 15m).
7. **Daily breaker** — stop for the day at `dailyLossPct / riskPct` R (2%/1% = 2R). **Streak pause** after 3 losses in a row.
8. **Month rollover** — the counter resets on the 1st (UTC). Once `L + smallest-possible-stop > CAP`, nothing more opens until the next month.

How to read the cap: in the app's units a cap of 500–1000 points is about 2 typical stops on BTC 15m (median stop 483), about 1 stop on 1h (850) and less than one stop on 4h (1698), so it blocks 4h entirely on BTC. For ETH/SOL the point is 10×/100× smaller, so the same number of points is far fewer dollars: set `monthlyLossBySymbol` per asset.

Cost of the cap: on BTC 15m classic it cut 888 trades to 260 and the worst month from −14,112 to −1,000 points, but the strategy is still negative net of fees (−10,447 vs −62,863 points). The cap limits losses; it does not create profit.
