# PRE-RELEASE SECURITY CHECKLIST — AlphaTrade AI (v236)

قبل أي نشر للإنتاج، كل بند لازم يكون ✅ أو عليه قرار موثّق. البنود اللي معلّمة **[خارجي]** ما بتنعمل من الكود.

## أ. آلي (بيمنع النشر إذا فشل)

- [ ] `npm test` كلها نجحت، ومعها `tests/securityPentest.test.js` و`tests/securityScan.test.js`.
- [ ] `node security/pentest.mjs` = كل الفحوصات PASSED.
- [ ] `node security/scan.mjs` = 0 High/Critical.
- [ ] GitHub Actions → **Security**: Gitleaks وSemgrep وnpm audit وTrivy (ملفات + صورة) خضر. وتقرير ZAP baseline اتراجع يدوياً.
- [ ] `npm run build`، و`dist/` ما فيها أي سر (فحص CI).

## ب. الأسرار والمفاتيح [خارجي]

- [ ] `AI_KEY_SECRET` و`BANK_MASTER_KEY` (32 حرف عشوائي على الأقل) محطوطين بـ Secret Manager تبع الاستضافة (Render Environment / Docker secrets)، مش بملف بالمستودع.
- [ ] ما في أي مفتاح بمتغير يبلّش بـ `VITE_`.
- [ ] إذا أي مفتاح انكشف بأي وقت (بمحادثة، صورة، أو commit): **اعتبره مخترق**، ألغيه من لوحة المزوّد (Anthropic، Stripe، Twelve Data، Telegram)، وحط واحد جديد.
- [ ] تدوير `AI_KEY_SECRET` بس عبر `security/rotate-ai-key.mjs` (نسخة جديدة مفحوصة، وبعدين تبديل المجلد). لا تغيّر المتغير مباشرة.
- [ ] `ADMIN_EMAILS` فيها إيميلات المالكين بس.

## ج. الحسابات [خارجي]

- [ ] Firebase Console:
  - [ ] Email enumeration protection مفعّل.
  - [ ] النطاقات المسموحة (Authorized domains) فيها الدومين الحقيقي بس.
  - [ ] Google / Apple sign-in مضبوطين.
- [ ] MFA مفعّل لحسابات المالكين بـ Firebase، وبعدها `ADMIN_REQUIRE_MFA=1` على السيرفر.
- [ ] جرّب استعادة كلمة السر وتغيير الإيميل على Staging.

## د. الدفع [خارجي]

- [ ] `STRIPE_SECRET_KEY` و`STRIPE_WEBHOOK_SECRET` بوضع live، ونقطة الـ webhook على `https://<domain>/api/billing/webhook` بس.
- [ ] جرّب دفعة test كاملة على Staging: تفعيل، ونفس الحدث مرتين بيطلع duplicate، والحدث المزوّر بيترفض.

## هـ. البنية التحتية [خارجي]

- [ ] HTTPS إجباري، وشهادة صالحة. افحص بـ testssl.sh على الدومين (TLS 1.2+ بس).
- [ ] WAF / DDoS (Cloudflare أو الاستضافة) قدّام السيرفر، و`TRUST_PROXY=1` بس إذا في proxy موثوق.
- [ ] ما في منفذ مفتوح غير 443 (والـ 80 بيحوّل لـ 443)، وملفات البيانات والنسخ الاحتياطية مش مكشوفة.
- [ ] V-06: ترحيل ملكية الـ volumes لـ uid 1000، وبعدين `USER node` بالـ Dockerfile.
- [ ] نسخة احتياطية انستعادت فعلاً على بيئة منفصلة وانفحصت.

## و. الإطلاق التجاري والقانون [خارجي — محامي مختص]

- [ ] مراجعة متطلبات ترخيص التوصيات المالية بكل دولة مستهدفة. إخلاء المسؤولية مش بديل.
- [ ] سياسة الخصوصية بتذكر: Firebase، Stripe، مزوّد الـ AI (شو بينبعتله)، Twelve Data، Binance، Telegram، ومدة الاحتفاظ بالبيانات.
- [ ] شروط الاستخدام وتحذير المخاطر المالية ظاهرين قبل الاشتراك.
- [ ] البنك الرقمي ضل `BANK_MODE=sandbox` لحد ما يصير في ترخيص وKYC/AML.
- [ ] تطبيقات المتاجر (إذا انعملت): Data Safety / App Privacy، وحذف الحساب من جوّا التطبيق، وسياسات الدفع داخل التطبيق.

## ي. المراقبة والاستجابة

- [ ] إشعارات المالكين (Push / Telegram) شغّالة، عشان توصل تنبيهات `suspicious_signin` و`admin_probe` و`api_abuse` و`sensitive_change`.
- [ ] حدا بيراجع `GET /api/admin/security` كل أسبوع.
- [ ] `INCIDENT_RESPONSE_PLAN.md` مقروءة، ومعروف مين بينفّذها.
- [ ] Dependabot شغّال (`.github/dependabot.yml`).
- [ ] `docs/PRIVACY_DATA_MAP.md` وصلت للمحامي لكتابة سياسة الخصوصية.

## ز. المخاطر المتبقية المقبولة (موثّقة)

| البند | القرار |
| --- | --- |
| V-05 تدوير `AI_KEY_SECRET` | مُصلح (v236) — بالأداة بس |
| V-06 الحاوية كـ root | مفتوح — ترحيل بوقت صيانة |
| V-07 سماحية 5 دقايق للتوكن | مقبول |
| V-08 CSP واسعة شوي | مقبول مؤقتاً |
| V-09 الوضع التجريبي المحلي | للتجربة بس، والإنتاج على Firebase |

## ح. اختبارات ما انعملت

- **NOT TESTED هون (ما في إنترنت ببيئة العمل):** ZAP وSemgrep وGitleaks وTrivy الرسميين — بيشتغلوا بالـ CI. وكمان اختبار Soak لساعات.
- **BLOCKED (ما في وصول):** Nuclei وtestssl على الدومين الحي، والاستضافة وDNS وWAF، وFirebase Console، وStripe live، والوسيط الحقيقي، واستعادة نسخة على الإنتاج.
- **لا ينطبق:** MobSF وMASVS وMASTG (ما في تطبيق Android/iOS بالمستودع).
