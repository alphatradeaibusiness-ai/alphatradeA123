import { test } from 'node:test';
import assert from 'node:assert/strict';
import { findSwings, findStructure, findFVGs, orderBlockFor, buildSetup, evaluateSetup, smcAnalysis } from '../src/indicators/smc.js';
import { generateDemoCandles } from '../src/services/market/demo.js';

// Build candles from a list of closes (open = previous close, wick ±0.5).
const fromCloses = (closes) => closes.map((c, i) => {
  const o = i ? closes[i - 1] : c;
  return { time: 1000 + i * 60, open: o, close: c, high: Math.max(o, c) + 0.5, low: Math.min(o, c) - 0.5 };
});

test('swings find local extremes', () => {
  const cs = fromCloses([10, 11, 12, 13, 12, 11, 10, 11, 12, 11, 10, 9, 10]);
  const sw = findSwings(cs, 2);
  assert.ok(sw.some((s) => s.type === 'high' && s.index === 3));
  assert.ok(sw.some((s) => s.type === 'low' && s.index === 6));
});

test('BOS then CHoCH are detected in order', () => {
  // up, pull back, break higher (BOS up), then fall below the last low (CHoCH down)
  const closes = [10, 11, 12, 13, 14, 13, 12, 11, 12, 13, 14, 15, 16, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8];
  const cs = fromCloses(closes);
  const sw = findSwings(cs, 2);
  const { events, trend } = findStructure(cs, sw, 2);
  assert.ok(events.length >= 2, JSON.stringify(events));
  assert.equal(events[0].dir, 'bull');
  assert.equal(events[0].kind, 'BOS');
  const last = events[events.length - 1];
  assert.equal(last.dir, 'bear');
  assert.equal(last.kind, 'CHoCH');
  assert.equal(trend, 'bear');
});

test('bullish order block is the last bearish candle before the impulse', () => {
  const closes = [10, 11, 12, 13, 14, 13, 12, 11, 12, 13, 14, 15, 16];
  const cs = fromCloses(closes);
  const sw = findSwings(cs, 2);
  const { events } = findStructure(cs, sw, 2);
  const ev = events.find((e) => e.dir === 'bull');
  const ob = orderBlockFor(cs, ev);
  assert.ok(cs[ob.index].close < cs[ob.index].open, 'OB candle is bearish');
  assert.equal(ob.index, 7); // the 12 → 11 candle at the bottom of the pull-back
});

test('fair value gaps', () => {
  const cs = [
    { time: 1, open: 10, high: 11, low: 9, close: 10.5 },
    { time: 2, open: 10.5, high: 14, low: 10.4, close: 13.8 },
    { time: 3, open: 13.8, high: 15, low: 12, close: 14.5 }, // low 12 > high 11 → bullish FVG 11..12
    { time: 4, open: 14.5, high: 15.5, low: 13, close: 15 },
  ];
  const g = findFVGs(cs);
  assert.equal(g.length, 1);
  assert.deepEqual([g[0].dir, g[0].bottom, g[0].top], ['bull', 11, 12]);
});

test('long setup: entry at OB top, stop below OB, targets ordered above', () => {
  const ob = { dir: 'bull', top: 100, bottom: 95, breakTime: 10, index: 1, breakIndex: 2 };
  const liq = { bsl: [{ price: 110 }, { price: 125 }], ssl: [] };
  const s = buildSetup(ob, liq, []);
  assert.equal(s.direction, 'long');
  assert.equal(s.entry, 100);
  assert.ok(s.stop < 95);
  assert.ok(s.targets[0] < s.targets[1] && s.targets[1] < s.targets[2]);
  assert.equal(s.targets[0], 110);
  assert.equal(s.targets[1], 125);
  assert.ok(s.targets.every((t) => t - s.entry >= s.distance - 1e-9));
});

test('short setup mirrors the long one', () => {
  const ob = { dir: 'bear', top: 105, bottom: 100, breakTime: 10, index: 1, breakIndex: 2 };
  const s = buildSetup(ob, { bsl: [], ssl: [{ price: 80 }] }, []);
  assert.equal(s.entry, 100);
  assert.ok(s.stop > 105);
  assert.equal(s.targets[0], 80);
  assert.ok(s.targets[0] > s.targets[1] && s.targets[1] > s.targets[2]);
});

test('setup status: pending → active → targets → stopped', () => {
  const setup = { direction: 'long', entry: 100, stop: 94, targets: [110, 120, 130], createdTime: 0 };
  const bar = (t, h, l) => ({ time: t, open: l, close: h, high: h, low: l });
  assert.equal(evaluateSetup(setup, [bar(1, 105, 101)]).status, 'pending');
  let r = evaluateSetup(setup, [bar(1, 105, 101), bar(2, 104, 99)]);
  assert.equal(r.status, 'active');
  r = evaluateSetup(setup, [bar(1, 105, 101), bar(2, 104, 99), bar(3, 121, 103)]);
  assert.equal(r.hits, 2);
  r = evaluateSetup(setup, [bar(1, 105, 101), bar(2, 104, 99), bar(3, 121, 103), bar(4, 104, 93)]);
  assert.equal(r.status, 'stopped');
  r = evaluateSetup(setup, [bar(2, 104, 99), bar(3, 131, 103)]);
  assert.equal(r.status, 'tp3');
});

test('full analysis on demo data is consistent', () => {
  for (const sym of ['BTCUSDT', 'XAUUSD', 'ETHUSDT']) {
    for (const tf of ['15m', '4h']) {
      const cs = generateDemoCandles(sym, tf, 500, Date.UTC(2026, 9, 1));
      const a = smcAnalysis(cs);
      assert.ok(a && (a.trend === 'bull' || a.trend === 'bear'));
      if (a.setup) {
        const s = a.setup;
        const sign = s.direction === 'long' ? 1 : -1;
        assert.ok((s.entry - s.stop) * sign > 0, 'stop on the far side');
        assert.ok(s.targets.every((t, i) => (t - (i ? s.targets[i - 1] : s.entry)) * sign > 0), 'targets ordered');
      }
    }
  }
});

test('smcFull reads the whole history: labelled swings, breaks, valid OBs, FVGs, dealing range', async () => {
  const { smcFull } = await import('../src/indicators/smc.js');
  const { generateDemoCandles } = await import('../src/services/market/demo.js');
  const cs = generateDemoCandles('BTCUSDT', '1h', 500, Date.UTC(2026, 5, 1));
  const m = smcFull(cs);
  assert.ok(m && m.bars === 500);
  assert.ok(m.labelled.length > 10 && m.labelled.every((s) => ['H', 'L', 'HH', 'HL', 'LH', 'LL'].includes(s.label)));
  assert.ok(m.recentEvents.length > 0 && m.recentEvents.length <= 6);
  for (const ob of m.obs) assert.ok(ob.top >= ob.bottom && typeof ob.mitigated === 'boolean');
  if (m.range) assert.ok(m.range.low < m.range.eq && m.range.eq < m.range.high && ['premium', 'discount'].includes(m.range.zone));
});
