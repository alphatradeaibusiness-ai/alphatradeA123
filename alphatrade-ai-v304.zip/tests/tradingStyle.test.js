// v249: the trading style chosen in the profile (scalp | swing), stored per account; «توصية AI» follows only it.
import test from 'node:test';
import assert from 'node:assert/strict';
const mem = new Map();
globalThis.localStorage = { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };
const { getTradingStyle, setTradingStyle, onTradingStyle, TRADING_STYLES } = await import('../src/services/tradingStyle.js');
const { STYLES } = await import('../src/services/smcAssist.js');

test('trading style: not chosen → null; only scalp / swing accepted; listeners hear the change', () => {
  assert.equal(getTradingStyle(), null);
  const seen = []; const off = onTradingStyle((v) => seen.push(v));
  assert.equal(setTradingStyle('swing'), true); assert.equal(getTradingStyle(), 'swing');
  assert.equal(setTradingStyle('daytrade'), false); assert.equal(getTradingStyle(), 'swing', 'an unknown value never replaces the choice');
  assert.equal(setTradingStyle('scalp'), true); assert.equal(getTradingStyle(), 'scalp');
  off(); setTradingStyle(null); assert.equal(getTradingStyle(), null);
  assert.deepEqual(seen, ['swing', 'scalp']);
  for (const s of TRADING_STYLES) assert.ok(STYLES[s]?.tfs?.length, `${s} has its own timeframes`);
  assert.deepEqual(STYLES.scalp.tfs, ['1m', '5m', '15m']); assert.deepEqual(STYLES.swing.tfs, ['1h', '4h', '1D']);
});
