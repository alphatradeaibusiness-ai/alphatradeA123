import test from 'node:test';
import assert from 'node:assert/strict';
import { validatePhone, checkE164, COUNTRIES, countryByIso, flagOf, guessCountry } from '../src/services/phoneNumbers.js';

test('country list: unique ISO codes, numeric dialling codes, sane lengths, flags', () => {
  const isos = COUNTRIES.map((c) => c.iso);
  assert.equal(new Set(isos).size, isos.length);
  assert.ok(COUNTRIES.length >= 200);
  for (const c of COUNTRIES) { assert.match(c.iso, /^[A-Z]{2}$/); assert.match(c.dial, /^\d{1,4}$/); assert.ok(c.min >= 4 && c.max <= 14 && c.min <= c.max, c.iso); assert.ok(c.dial.length + c.min <= 15, c.iso); }
  assert.equal(flagOf('jo'), '🇯🇴');
});

test('valid numbers in the usual ways people type them → one E.164 form', () => {
  const ok = (raw, iso, e164) => { const r = validatePhone(raw, iso); assert.equal(r.ok, true, `${iso} ${raw} → ${r.error}`); assert.equal(r.e164, e164); };
  ok('079 123 4567', 'JO', '+962791234567');
  ok('+962 79 123 4567', 'JO', '+962791234567');
  ok('00962791234567', 'JO', '+962791234567');
  ok('962791234567', 'JO', '+962791234567');
  ok('050-123-4567', 'IL', '+972501234567');
  ok('0599 123 456', 'PS', '+970599123456');
  ok('055 123 4567', 'SA', '+966551234567');
  ok('050 123 4567', 'AE', '+971501234567');
  ok('010 1234 5678', 'EG', '+201012345678');
  ok('07911 123456', 'GB', '+447911123456');
  ok('(415) 555-2671', 'US', '+14155552671');
  ok('1 415 555 2671', 'US', '+14155552671');
  ok('876 555 1234', 'JM', '+18765551234');
  ok('0151 23456789', 'DE', '+4915123456789');
  ok('98765 43210', 'IN', '+919876543210');
  ok('0532 123 45 67', 'TR', '+905321234567');
});

test('invalid input is refused with a precise reason', () => {
  const bad = (raw, iso, error) => assert.equal(validatePhone(raw, iso).error, error, `${iso} ${raw}`);
  bad('', 'JO', 'required');
  bad('0791234567', 'XX', 'country');
  bad('07912345a7', 'JO', 'chars');
  bad('<script>alert(1)</script>', 'JO', 'chars');
  bad('079​1234567', 'JO', 'chars');            // invisible character
  bad('+44 7911 123456', 'JO', 'prefix');
  bad('079 123', 'JO', 'short');
  bad('079 123 4567 89', 'JO', 'long');
  bad('071 123 4567', 'JO', 'format');               // not a Jordan mobile/landline pattern
  bad('(015) 555-2671', 'US', 'format');             // area code cannot start with 0/1
  bad('2222222222', 'US', 'format');                 // one repeated digit
  bad('5'.repeat(9), 'SA', 'format');
  bad('1'.repeat(40), 'GB', 'long');
  bad('+9+62791234567', 'JO', 'chars');
});

test('server re-check accepts only the exact E.164 the form produced', () => {
  assert.equal(checkE164('+962791234567', 'JO').ok, true);
  assert.equal(checkE164('+962791234567', 'SA').ok, false);
  assert.equal(checkE164('0791234567', 'JO').ok, false);
  assert.equal(checkE164({ toString: () => '+962791234567' }, 'JO').ok, false);
  assert.equal(countryByIso('jo').dial, '962');
  assert.equal(guessCountry(['ar-JO', 'en']), 'JO'); assert.equal(guessCountry(['ar']), null);
});
