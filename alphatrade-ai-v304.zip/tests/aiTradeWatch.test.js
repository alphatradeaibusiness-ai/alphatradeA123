import { test } from 'node:test';
import assert from 'node:assert/strict';

test('AI trade events: fill, every target, final, stop, breakeven', async () => {
  globalThis.localStorage ??= { getItem: () => null, setItem: () => {}, removeItem: () => {} };
  const { tradeEvents, eventMessage } = await import('../src/services/aiTradeWatch.js');
  const k = (a) => a.map((e) => `${e.kind}${e.n ?? ''}`).join(',');
  assert.equal(k(tradeEvents({ status: 'pending', hits: 0 }, { status: 'active', hits: 1, filledAt: 1 }, 3)), 'filled,tp1');
  assert.equal(k(tradeEvents({ status: 'active', hits: 1 }, { status: 'active', hits: 2 }, 3)), 'tp2');
  assert.equal(k(tradeEvents({ status: 'active', hits: 1 }, { status: 'done', hits: 3 }, 3)), 'tp2,final3');
  assert.equal(k(tradeEvents({ status: 'active', hits: 0 }, { status: 'stopped', hits: 0 }, 3)), 'sl');
  assert.equal(k(tradeEvents({ status: 'active', hits: 1 }, { status: 'breakeven', hits: 1 }, 3)), 'be1');
  assert.equal(k(tradeEvents({ status: 'pending', hits: 0 }, { status: 'expired', hits: 0 }, 3)), 'expired');
  const x = { symbol: 'XAUUSD', direction: 'short', entry: 3964.64, stop: 3990, targets: [3926.92, 3910.4, 3888.63] };
  const tp1 = eventMessage(x, { kind: 'tp', n: 1 }, 'en');
  assert.equal(tp1.title, 'Take Profit 1 Smashed! 🎯');
  assert.match(tp1.body.replace(/[⁦⁩]/g, ''), /XAU\/USD hit TP1 \(\$3,926\.92\)! Stop Loss moved to Entry/);
  assert.equal(eventMessage(x, { kind: 'final', n: 3 }, 'ar').title, 'الهدف تحقق! 🚀');
  assert.match(eventMessage(x, { kind: 'filled' }, 'ar').title, /تفعّل الأمر المعلّق/);
});
