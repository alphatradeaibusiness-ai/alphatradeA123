import test from 'node:test';
import assert from 'node:assert';
import { newsRisk, synthesize, explainRadar } from '../src/services/synthesis.js';
import { ema, rsi } from '../src/indicators/index.js';

const series = (n, f) => Array.from({ length: n }, (_, i) => { const c = f(i); return { time: 1_700_000_000 + i * 3600, open: c - 0.5, high: c + 1, low: c - 1, close: c, volume: 10 }; });

test('newsRisk: only high-impact events that move this symbol, within the window', () => {
  const now = 1_000_000_000_000;
  const ev = [{ title: 'NFP', country: 'USD', impact: 'High', time: now + 30 * 60_000 }, { title: 'GDP', country: 'GBP', impact: 'High', time: now + 10 * 60_000 }];
  assert.equal(newsRisk('XAUUSD', ev, now).level, 'high');
  assert.equal(newsRisk('XAUUSD', ev, now).minutes, 30);
  assert.equal(newsRisk('ETHUSDT', ev, now).level, 'none');   // USD news is not mapped to ETH
  assert.equal(newsRisk('XAUUSD', [{ ...ev[0], time: now + 3 * 3600_000 }], now).level, 'soon');
  assert.equal(newsRisk('XAUUSD', [{ ...ev[0], impact: 'Medium' }], now).level, 'none');
  assert.equal(newsRisk('XAUUSD', null, now).known, false);
});

test('synthesize: agreeing uptrend → long; high-impact news or demo data → wait with the reason', () => {
  const c = series(300, (i) => 100 + i * 0.5 + Math.sin(i / 3));
  const closes = c.map((x) => x.close);
  const an = { ema20: ema(closes, 20), ema50: ema(closes, 50), rsi: rsi(closes, 14), momentum: { score: 70 }, mode: 'live' };
  const htf = { h4: series(120, (i) => 50 + i), d1: series(60, (i) => 40 + i) };
  const s = synthesize(an, c, htf, { level: 'none', known: true });
  assert.equal(s.stance, 'long');
  assert.ok(s.factors.find((f) => f.key === 'htf').side === 'bull');
  const n = synthesize(an, c, htf, { level: 'high', event: { title: 'CPI' }, minutes: 20, known: true });
  assert.equal(n.stance, 'wait'); assert.ok(n.reasons.includes('news'));
  assert.equal(synthesize({ ...an, mode: 'demo' }, c, htf, null).stance, 'wait');
  // no higher-timeframe data: said so, not guessed
  assert.ok(synthesize(an, c, null, null).factors.some((f) => f.key === 'htfMissing'));
});

test('synthesize: mixed parts → wait', () => {
  const c = series(300, (i) => 100 + Math.sin(i / 4) * 3);
  const closes = c.map((x) => x.close);
  const an = { ema20: ema(closes, 20), ema50: ema(closes, 50), rsi: rsi(closes, 14), momentum: { score: 50 }, mode: 'live' };
  assert.equal(synthesize(an, c, null, null).stance, 'wait');
});

test('explainRadar: reasons for and against, avoid on unstable or news', () => {
  const r = { direction: 'long', trend: 1, momentum: 62, rsi: 55, event: { kind: 'BOS', dir: 'bull', ago: 3 }, trades: 12, winRate: 58, setup: { status: 'active' }, aligned: true, verdict: 'strong', filters: { unstable: [], weak: [] } };
  const e = explainRadar(r);
  assert.equal(e.state, 'setup');
  assert.deepEqual(e.pros.map((p) => p.key), ['trend', 'momentum', 'smc', 'history', 'setup']);
  assert.equal(explainRadar({ ...r, verdict: 'unstable', filters: { unstable: ['atrSpike'], weak: [] } }).state, 'avoid');
  assert.equal(explainRadar(r, { level: 'high', event: { title: 'NFP' }, minutes: 10 }).state, 'avoid');
  assert.ok(explainRadar({ ...r, trades: 2 }).cons.some((c) => c.key === 'fewTrades'));
});

test('sessionLevels: last completed Asia / London / NY highs and lows, real candle times, intraday only', async () => {
  const { sessionLevels } = await import('../src/indicators/smc.js');
  const day = 1_700_006_400 - (1_700_006_400 % 86400);   // a UTC midnight
  const c = [];
  for (let t = day; t < day + 30 * 3600; t += 900) { const h = ((t - day) / 3600) % 24; const p = 100 + h; c.push({ time: t, open: p, high: p + 1, low: p - 1, close: p }); }
  const s = sessionLevels(c, 900);
  const asia = s.find((x) => x.name === 'ASIA');
  assert.equal(asia.start, day);   // data ends at 05:45 on day 2, so day 2's Asia session (00–08) is not complete: day 1's is used
  assert.ok(asia.high >= asia.low && c.some((k) => k.time === asia.highTime && k.high === asia.high));
  assert.deepEqual(sessionLevels(c, 4 * 3600), []);   // 4h candles: no session map
});
