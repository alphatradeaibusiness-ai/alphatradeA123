// v248 «توصية AI» — the permanent NO TRADE root causes and the independent multi-strategy pipeline of the page, on REAL candles
// (tests/fixtures/ai-reco.json, Twelve Data: BTC/USD 1m/5m/15m/1h, EUR/USD 4h/1D). The pipeline below is the page's own:
// runAllStrategies + pageEngineCfg + executeAll (src/pages/aiSignal.js calls the same functions).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const mem = new Map();
globalThis.localStorage = { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };
const { runAllStrategies, presetCfg } = await import('../src/services/multiStrategy.js');
const { analyzeSmcIct, cleanInputs, STYLES } = await import('../src/services/smcAssist.js');
const { costModel, EXEC, RISK } = await import('../src/config/aiSignalRules.js');
const { executeAll, extraGlobals, prepare, pageEngineCfg, recentResultsFor, executionPlan, isDuplicate } = await import('../src/services/aiSignalEngine.js');
const { validateCandles } = await import('../src/services/radarPro.js');
const { INSTRUMENTS, EXTRA_INSTRUMENTS, findInstrument } = await import('../src/config/instruments.js');
const { YAHOO_SYMBOLS } = await import('../src/services/market/yahoo.js');

const FX = JSON.parse(fs.readFileSync(new URL('./fixtures/ai-reco.json', import.meta.url), 'utf8'));
const C = (name) => { const c = FX.cases[name]; return { ...c, candles: c.candles.map(([time, open, high, low, close]) => ({ time, open, high, low, close, volume: 0 })) }; };

/** The page pipeline for one request (instrument, style, timeframe, MARKET/LIMIT) on the given candles. */
function analyze(name, over = {}) {
  const c = { ...C(name), ...over };
  const closed = c.candles; const last = closed.at(-1); const nowMs = over.nowMs ?? (last.time + c.sec) * 1000 + 5000;
  const asset = c.type; const cost = costModel(asset, over.spreadPct ?? null);
  const v = validateCandles(closed, c.tf, { crypto: asset === 'crypto', now: nowMs });
  let rd = null; const reading = over.reading || (() => (rd ||= analyzeSmcIct(closed, { ...cleanInputs({ style: c.style, asset, execution: c.want, costPct: cost.totalPct }), symbol: c.sym, tfSec: c.sec, htf: null, news: null, htfMode: 'tiered', poiMaxAtr: EXEC.limitMaxAtr[c.style] })));
  const calendar = 'calendar' in over ? over.calendar : { events: [], at: nowMs, stale: false };
  const cfg = over.cfg || pageEngineCfg({ base: presetCfg('balanced'), style: c.style, costPct: cost.totalPct, risk: { dailyLossPct: RISK.dailyLossPct.def, pauseAfterLosses: RISK.pauseAfterLosses.def }, extra: extraGlobals({ validation: { ...v, n: closed.length }, open: over.open || [], riskPct: 1, asset }) });
  const multi = runAllStrategies({ symbol: c.sym, inst: over.inst || { symbol: c.sym, type: c.type, provider: 'twelvedata', precision: 2 }, tf: c.tf, tfSec: c.sec, candles: closed, mode: over.mode || 'live', htf: null, reading, calendar, peer: null, nowMs,
    spread: over.spreadPct != null ? { bidAskPct: over.spreadPct } : null, account: { todayLossPct: 0, recentResults: over.recentResults || [], openByStrategy: {} } }, cfg);
  const prep = prepare(closed, { tfSec: c.sec, asset });
  const quote = 'quote' in over ? over.quote : { price: last.close, at: nowMs };
  const ok = executeAll(multi.trades, { smcPlan: rd?.plan, want: c.want, style: c.style, asset, tf: c.tf, tfSec: c.sec, S: prep.S, atr: prep.S?.a?.[prep.S.i], price: last.close, live: quote, minRR: multi.minRR || 0, smcMinRR: STYLES[c.style].minRR, costPct: cost.totalPct, createdAt: last.time, nowMs });
  return { multi, ok, last, nowMs, c };
}
const levelsOk = (pl) => { const sg = pl.direction === 'long' ? 1 : -1; return (pl.entry - pl.stop) * sg > 0 && pl.targets.length === 3 && pl.targets.every((t, k) => (t - (k ? pl.targets[k - 1] : pl.entry)) * sg > 0); };

test('swing 1H / 4H / 1D and scalping 1M / 5M / 15M: each timeframe gives real trades with MARKET and with LIMIT', () => {
  const styles = { '1m': 'scalp', '5m': 'scalp', '15m': 'scalp', '1h': 'swing', '4h': 'swing', '1D': 'swing' };
  for (const tf of ['1m', '5m', '15m', '1h', '4h', '1D']) for (const want of ['market', 'limit']) {
    const r = analyze(`${tf}-${want}`);
    assert.equal(r.c.style, styles[tf]); assert.ok(STYLES[r.c.style].tfs.includes(tf), `${tf} belongs to ${r.c.style}`);
    assert.ok(r.ok.length >= 1, `${tf} ${want}: at least one executable recommendation`);
    for (const x of r.ok) {
      assert.ok(levelsOk(x.plan), `${tf} ${want} ${x.id}: stop and TP1–TP3 in order`);
      if (x.plan.execution === 'market') assert.equal(x.plan.entry, r.last.close, 'market = the current executable price');
      else { const long = x.plan.direction === 'long'; assert.ok(long ? x.plan.entry <= r.last.close : x.plan.entry >= r.last.close, 'a limit rests on the pullback side'); assert.ok(x.exec.exec.dist.atr <= EXEC.limitMaxAtr[r.c.style], 'nearby'); assert.ok(x.plan.validUntil > x.plan.createdAt); }
    }
    if (want === 'limit') assert.ok(r.ok.some((x) => x.plan.execution === 'limit') || r.ok.length, `${tf} limit request answered`);
  }
});

test('independent strategies: SMC, trend and mean reversion each qualify alone; several at once give separate trades', () => {
  for (const [name, id] of [['1h-market', 'smc'], ['only-mr', 'mean_reversion'], ['only-trend', 'trend']]) {
    const r = analyze(name); const ids = r.ok.map((x) => x.id);
    assert.ok(ids.includes(id), `${name}: ${id} qualified`);
    const others = r.multi.strategies.filter((s) => ['smc', 'trend', 'mean_reversion'].includes(s.id) && s.id !== id && s.status !== 'qualified');
    assert.ok(others.length >= 1, `${name}: ${id} published while another strategy did not qualify (no consensus needed)`);
  }
  const m = analyze('multi');
  assert.ok(m.ok.length >= 2, 'two strategies qualified → two recommendations');
  assert.equal(new Set(m.ok.map((x) => x.id)).size, m.ok.length, 'one per strategy, never merged');
  for (const x of m.ok) assert.ok(levelsOk(x.plan));
  // ICT: implemented inside the SMC / ICT strategy (kill zone, silver bullet, OTE, judas are its context) — there is no separate ICT engine
  assert.ok(m.multi.strategies.some((s) => s.id === 'smc'));
});

test('one strategy failing (even throwing) never blocks another', () => {
  const r = analyze('only-mr', { reading: () => { throw new Error('smc broke'); } });
  assert.ok(r.ok.some((x) => x.id === 'mean_reversion'));
});

test('no trade only when no strategy meets all of its own conditions — and the missing conditions are named', () => {
  const r = analyze('none');
  assert.equal(r.ok.length, 0);
  for (const s of r.multi.strategies.filter((x) => ['smc', 'trend', 'mean_reversion'].includes(x.id))) assert.ok(s.checks.some((c) => c.status !== 'pass'), `${s.id} says what is missing`);
});

test('ROOT CAUSE 1: an unavailable news calendar no longer blocks every strategy (a known high-impact event still does)', () => {
  const blocked = analyze('only-mr', { calendar: null, cfg: { ...presetCfg('balanced'), ai: true } });   // the old behaviour
  assert.equal(blocked.ok.length, 0); assert.equal(blocked.multi.globals.find((g) => g.id === 'news').status, 'unavailable');
  const fixed = analyze('only-mr', { calendar: null });
  assert.ok(fixed.ok.length >= 1, 'page config: calendar unavailable is a warning, the trade is still given');
  const stale = analyze('only-mr', { calendar: { events: [], at: Date.now() - 30 * 3600_000, stale: true } });
  assert.ok(stale.ok.length >= 1);
  const t = (C('only-mr').candles.at(-1).time + 3600) * 1000 + 5000;
  const news = analyze('only-mr', { calendar: { events: [{ title: 'FOMC', country: 'USD', impact: 'High', time: t + 10 * 60_000 }], at: t, stale: false } });
  assert.equal(news.ok.length, 0, 'high-impact event in 10 min → blocked');
});

test('ROOT CAUSE 2: the loss-streak pause expires (two old losses used to pause the engine for ever)', () => {
  const now = Date.now(); const h = (n) => Math.floor(now / 1000 - n * 3600);
  assert.deepEqual(recentResultsFor([{ resultR: -1, closedAt: h(30) }, { resultR: -1, closedAt: h(28) }], now, RISK.pauseHours), []);
  assert.deepEqual(recentResultsFor([{ resultR: -1, closedAt: h(3) }, { resultR: -1, closedAt: h(1) }], now, RISK.pauseHours), ['loss', 'loss']);
  assert.equal(analyze('only-mr', { recentResults: ['loss', 'loss'] }).ok.length, 0, 'inside the window the pause still protects');
  assert.ok(analyze('only-mr', { recentResults: recentResultsFor([{ resultR: -1, closedAt: h(30) }, { resultR: -1, closedAt: h(28) }], now) }).ok.length >= 1);
});

test('ROOT CAUSE 3: saved trades that can no longer be followed stop counting as open (they filled the limit for ever)', async () => {
  const { expireStale, listTrades } = await import('../src/services/assistTrades.js');
  const nowS = Math.floor(Date.now() / 1000);
  const tr = (id, over) => ({ id, symbol: 'XAUUSD', tf: '15m', style: 'scalp', mode: 'live', direction: 'long', entry: 1, stop: 0.9, targets: [1.1, 1.2, 1.3], hits: 0, savedAt: Date.now(), updatedAt: 0, ...over });
  localStorage.setItem('ata:assist-trades:guest', JSON.stringify([tr('a', { status: 'pending', createdAt: nowS - 7200, validUntil: nowS - 600 }), tr('b', { status: 'active', createdAt: nowS - 3 * 86400, filledAt: nowS - 3 * 86400 }), tr('c', { status: 'active', createdAt: nowS - 3600, filledAt: nowS - 3600 }), tr('d', { status: 'active', style: 'swing', createdAt: nowS - 3 * 86400, filledAt: nowS - 3 * 86400 })]));
  const before = listTrades().filter((x) => ['pending', 'active'].includes(x.status)).length;
  assert.equal(before, 4, 'four open saved trades');
  const changed = expireStale(Date.now(), RISK.maxHoldHours);
  assert.deepEqual(changed.map((x) => x.id).sort(), ['a', 'b']);
  const st = Object.fromEntries(listTrades().map((x) => [x.id, x.status]));
  assert.deepEqual([st.a, st.b, st.c, st.d], ['expired', 'expired', 'active', 'active']);
  // and the open-trade limit then lets new recommendations through
  const open = listTrades().filter((x) => ['pending', 'active'].includes(x.status));
  assert.ok(analyze('only-mr', { open }).ok.length >= 1);
  assert.equal(analyze('only-mr', { open: [...open, ...open, ...open] }).ok.length, 0, 'the real limit (3 open) still applies');
});

test('execution: valid / invalid market, nearby / distant limit, buy and sell, duplicates', () => {
  const S = { i: 0, e20: [99.6], bb: { lower: [99.5], upper: [100.5] } };
  const base = { id: 'trend', plan: { direction: 'long', entry: 100, stop: 99, targets: [101.5, 102, 103] }, style: 'scalp', asset: 'index', tf: '15m', tfSec: 900, S, atr: 1, price: 100, createdAt: 1000, costPct: 0, nowMs: 2_000_000 };
  const ok = executionPlan({ ...base, want: 'market', live: { price: 100.1, at: 2_000_000 } });
  assert.equal(ok.ok, true); assert.equal(ok.plan.execution, 'market'); assert.equal(ok.plan.entry, 100.1);
  const chase = executionPlan({ ...base, want: 'market', live: { price: 101, at: 2_000_000 } });
  assert.deepEqual([chase.ok, chase.reason], [false, 'chase'], 'an extended move is not chased (and its limit level is too far here)');
  const past = executionPlan({ ...base, want: 'market', live: { price: 98.5, at: 2_000_000 } });
  assert.equal(past.ok, false, 'past the stop → rejected');
  const near = executionPlan({ ...base, want: 'limit', live: { price: 100, at: 2_000_000 } });
  assert.equal(near.plan.execution, 'limit'); assert.equal(near.plan.entry, 99.6); assert.ok(near.exec.dist.atr <= EXEC.limitMaxAtr.scalp);
  const far = executionPlan({ ...base, S: { ...S, e20: [97.5] }, plan: { ...base.plan, stop: 96.5 }, want: 'limit', live: { price: 100, at: 2_000_000 } });
  assert.notEqual(far.plan?.execution, 'limit', 'a distant limit is refused');
  const sell = executionPlan({ ...base, id: 'mean_reversion', plan: { direction: 'short', entry: 100, stop: 101, targets: [99, 98.5, 98] }, want: 'market', live: { price: 100, at: 2_000_000 } });
  assert.equal(sell.ok, true); assert.ok(levelsOk(sell.plan));
  const items = [{ mode: 'live', status: 'active', symbol: 'US100', strategy: 'trend', direction: 'long', entry: 100 }];
  assert.equal(isDuplicate(items, { symbol: 'US100', strategy: 'trend', direction: 'long', entry: 100.1, atr: 1 }), true);
  assert.equal(isDuplicate(items, { symbol: 'US100', strategy: 'smc', direction: 'long', entry: 100.1, atr: 1 }), false, 'another strategy is another trade');
});

test('data failures: missing candles, stale prices, invalid symbol, API timeout (demo fallback), market closed, excessive spread', () => {
  const g = (r, id) => r.multi.globals.find((x) => x.id === id)?.status;
  assert.equal(g(analyze('only-mr', { candles: C('only-mr').candles.slice(-150) }), 'data'), 'fail');
  const late = analyze('only-mr', { nowMs: (C('only-mr').candles.at(-1).time + 3600 * 8) * 1000, quote: null });
  assert.equal(g(late, 'fresh'), 'fail'); assert.equal(late.ok.length, 0);
  assert.equal(g(analyze('only-mr', { inst: { symbol: 'NOPE', type: 'nope' } }), 'supported'), 'fail'); assert.equal(findInstrument('NOPE'), null);
  assert.equal(g(analyze('only-mr', { mode: 'demo' }), 'live'), 'fail', 'a timeout falls back to demo prices, which never trade');
  const eurCase = C('4h-market'); const sat = Date.UTC(2026, 10, 7, 12);   // a Saturday
  const closed = analyze('4h-market', { nowMs: sat, candles: eurCase.candles.map((c, k, a) => ({ ...c, time: Math.floor(sat / 1000) - (a.length - k + 1) * 14400 })) });
  assert.equal(g(closed, 'session'), 'fail'); assert.equal(closed.ok.length, 0);
  assert.equal(g(analyze('only-mr', { spreadPct: 0.5 }), 'spread'), 'fail');
});

test('instrument coverage: every requested market maps to a real provider symbol (unsupported ones are not pretended)', () => {
  const all = [...INSTRUMENTS, ...EXTRA_INSTRUMENTS];
  const has = (s) => all.find((i) => i.symbol === s);
  for (const s of ['US100', 'US30', 'SPX500', 'US2000', 'GER40', 'UK100', 'EU50', 'FRA40', 'SPAIN35', 'JP225', 'HK50', 'AUS200', 'XAUUSD', 'XAGUSD', 'XPTUSD', 'XPDUSD', 'USOIL', 'UKOIL', 'NATGAS', 'COPPER',
    'EURUSD', 'GBPUSD', 'USDJPY', 'USDCHF', 'USDCAD', 'AUDUSD', 'NZDUSD', 'EURJPY', 'GBPJPY', 'EURGBP', 'EURCHF', 'AUDJPY', 'CADJPY', 'BTCUSDT']) {
    const i = has(s); assert.ok(i, `${s} exists`);
    if (i.provider !== 'binance') assert.ok(YAHOO_SYMBOLS[s], `${s} has a real Yahoo Finance ticker`);
  }
  assert.ok(has('ETHUSDT'), 'the existing crypto universe is kept');
  assert.equal(has('VIX'), undefined, 'VIX is not a tradable instrument here → not offered');
  // the AI-only extras are not scanned by the channel / EDH
  for (const s of ['EURCHF', 'AUDJPY', 'CADJPY', 'US2000', 'XPDUSD']) assert.equal(INSTRUMENTS.some((i) => i.symbol === s), false, s);
});
