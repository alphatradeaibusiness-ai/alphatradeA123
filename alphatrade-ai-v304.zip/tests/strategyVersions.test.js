import test from 'node:test';
import assert from 'node:assert';
const mem = new Map();
globalThis.localStorage = { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };

test('strategy versions: new version only on trading changes, diff, restore keeps display options', async () => {
  const v = await import('../src/services/strategyVersions.js');
  const a = { strategy: 'edh', risk: { riskPct: 1 }, chartClean: true };
  assert.equal(v.recordVersion(a, { now: 1 }).n, 1);
  assert.equal(v.recordVersion({ ...a, chartClean: false }, { now: 2 }).n, 1);   // display only → same version
  const b = v.recordVersion({ ...a, risk: { riskPct: 2 } }, { now: 3 });
  assert.equal(b.n, 2); assert.deepEqual(b.changed, ['risk']);
  const r = v.restoreSettings(1, { ...a, risk: { riskPct: 2 }, chartClean: false, liqMap: true });
  assert.deepEqual(r, { strategy: 'edh', risk: { riskPct: 1 }, chartClean: false, liqMap: true });
  assert.equal(v.restoreSettings(99, a), null);
});
