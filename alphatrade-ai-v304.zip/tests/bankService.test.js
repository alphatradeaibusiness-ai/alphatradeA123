// Bank rules: deposits, withdrawals (limits, cooling-off, flags, separation of duties), KYC, card request, auto-invest.
import test from 'node:test';
import assert from 'node:assert/strict';
import { openDb } from '../server/bank/db.js';
import { createVault } from '../server/bank/vault.js';
import { createBank } from '../server/bank/service.js';

const OWNER = { uid: 'owner' };
const GOOD_IBAN = 'DE89370400440532013000';
const ADDR = { country: 'DE', region: 'BE', city: 'Berlin', postal: '10115', line1: 'Invalidenstrasse 1' };
function setup({ mode = 'sandbox', price = 50000, start = Date.UTC(2026, 9, 27, 12) } = {}) {
  let t = start; const db = openDb(':memory:');
  const bank = createBank({ db, vault: createVault({ secret: 'z'.repeat(40) }), mode, now: () => t, priceFn: async () => ({ price, ts: t }), config: { beneficiaryCooldown: 1000 } });
  return { db, bank, tick: (ms) => { t += ms; }, now: () => t };
}
const kyc = (b, uid, tier = 1, extra = {}) => {
  if (tier === 2 && b.kycStatus(uid).tier < 1) kyc(b, uid, 1);
  if (b.kycStatus(uid).tier >= tier) return;
  b.submitKyc(uid, { tier, fullName: 'Ada Lovelace', dob: '1990-05-05', nationality: 'DE', address: ADDR, idType: 'passport', idNumber: 'C' + Buffer.from(String(uid)).toString('hex').slice(0, 14), idExpiry: '2031-01-01', sourceOfFunds: 'salary', proofOfAddressRef: 'vend-123', ...extra });
  b.reviewKyc(OWNER, uid, 'approve');
};
const fund = (b, uid, cur, amt, k = `fund-${uid}-${cur}-${amt}`) => b.sandboxFund(uid, { currency: cur, amount: amt, idem: k });
const bal = (b, uid, cur) => b.wallet(uid).find((w) => w.currency === cur);
const code = (fn) => { try { fn(); } catch (e) { return e.code; } return 'NO_ERROR'; };

test('sandbox funds: capped, idempotent, never in live mode', () => {
  const { bank } = setup();
  fund(bank, 'u1', 'USD', '500'); fund(bank, 'u1', 'USD', '500');   // same idem key → one credit
  assert.equal(bal(bank, 'u1', 'USD').available, 50000);
  assert.equal(code(() => fund(bank, 'u1', 'USD', '10001', 'big-1234')), 'limit_exceeded');
  assert.equal(code(() => bank.sandboxFund('u1', { currency: 'USD', amount: '1', idem: 'short' })), 'idempotency_key_required');
  for (let i = 0; i < 9; i++) fund(bank, 'u1', 'USD', '10000', `more-${i}-abcd`);
  assert.equal(code(() => fund(bank, 'u1', 'USD', '10000', 'over-cap-1')), 'limit_exceeded');   // total cap 100k
  assert.equal(code(() => setup({ mode: 'live' }).bank.sandboxFund('u1', { currency: 'USD', amount: '1', idem: 'live-1234' })), 'not_available');
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
});

test('deposit: requested → owner confirms once; reference reuse, wrong amount, self-confirm and expiry are refused', () => {
  const { bank, tick } = setup({ mode: 'live' });
  assert.equal(code(() => bank.requestDeposit('u1', { currency: 'USD', amount: '100', idem: 'dep-key-1' })), 'kyc_required');
  kyc(bank, 'u1');
  const d = bank.requestDeposit('u1', { currency: 'USD', amount: '100', idem: 'dep-key-1' });
  assert.match(d.reference, /^ATB-[A-Z2-9]{8}$/); assert.equal(d.status, 'requested');
  assert.equal(bank.requestDeposit('u1', { currency: 'USD', amount: '100', idem: 'dep-key-1' }).id, d.id);       // replay
  assert.equal(code(() => bank.requestDeposit('u1', { currency: 'USD', amount: '101', idem: 'dep-key-1' })), 'idempotency_conflict');
  assert.equal(bal(bank, 'u1', 'USD').pendingDeposits, 10000); assert.equal(bal(bank, 'u1', 'USD').available, 0);   // nothing spendable yet
  assert.equal(code(() => bank.confirmDeposit({ uid: 'u1' }, d.id, { extRef: 'BANK-0001' })), 'self_action_not_allowed');
  assert.equal(code(() => bank.confirmDeposit(OWNER, d.id, { extRef: 'BANK-0001', received: '99' })), 'amount_mismatch');
  assert.equal(bank.confirmDeposit(OWNER, d.id, { extRef: 'BANK-0001' }).ok, true);
  assert.equal(bal(bank, 'u1', 'USD').available, 10000);
  assert.equal(code(() => bank.confirmDeposit(OWNER, d.id, { extRef: 'BANK-0002' })), 'bad_state');
  const d2 = bank.requestDeposit('u1', { currency: 'USD', amount: '50', idem: 'dep-key-2' });
  assert.equal(code(() => bank.confirmDeposit(OWNER, d2.id, { extRef: 'BANK-0001' })), 'duplicate_reference');   // same bank ref: never twice
  assert.equal(bal(bank, 'u1', 'USD').available, 10000);
  tick(8 * 86400_000); assert.equal(code(() => bank.confirmDeposit(OWNER, d2.id, { extRef: 'BANK-0003' })), 'expired');
  assert.equal(code(() => bank.requestDeposit('u1', { currency: 'BTC', amount: '1', idem: 'dep-key-3' })), 'bad_network');
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] }); assert.equal(bank.audit.verify().ok, true);
});

function wdSetup(mode = 'sandbox') {
  const s = setup({ mode }); kyc(s.bank, 'u1'); fund(s.bank, 'u1', 'USD', '5000');
  const ben = s.bank.addBeneficiary('u1', { currency: 'USD', label: 'Main', iban: GOOD_IBAN, holder: 'Ada Lovelace' });
  s.tick(2000);   // past the (test) cooling-off
  return { ...s, ben };
}

test('beneficiary: IBAN checked, stored encrypted, listed masked, cooling-off enforced, duplicates refused', () => {
  const { bank, db, tick } = setup(); kyc(bank, 'u1'); fund(bank, 'u1', 'USD', '100');
  assert.equal(code(() => bank.addBeneficiary('u1', { currency: 'USD', label: 'x', iban: 'DE00', holder: 'A B' })), 'bad_iban');
  assert.equal(code(() => bank.addBeneficiary('u2', { currency: 'USD', label: 'x', iban: GOOD_IBAN, holder: 'A B' })), 'kyc_required');
  const b = bank.addBeneficiary('u1', { currency: 'USD', label: 'Main', iban: GOOD_IBAN, holder: 'Ada L' });
  assert.equal(b.last4, '3000'); assert.deepEqual(Object.keys(b).sort(), ['createdAt', 'currency', 'id', 'kind', 'label', 'last4', 'status', 'usableAfter']);
  assert.ok(!JSON.stringify(db.prepare('SELECT * FROM beneficiaries').all()).includes('DE8937'));
  assert.equal(code(() => bank.addBeneficiary('u1', { currency: 'USD', label: 'Again', iban: 'de89 3704 0044 0532 0130 00', holder: 'A B' })), 'already_exists');
  assert.equal(code(() => bank.requestWithdrawal('u1', { currency: 'USD', amount: '20', beneficiaryId: b.id, idem: 'wd-cool-1' })), 'beneficiary_cooling_off');
  tick(2000); assert.equal(bank.requestWithdrawal('u1', { currency: 'USD', amount: '20', beneficiaryId: b.id, idem: 'wd-cool-1' }).status, 'requested');
  assert.equal(code(() => bank.removeBeneficiary('u2', b.id)), 'not_found');                // other users cannot touch it
  const c = bank.addBeneficiary('u1', { currency: 'USDT', label: 'Wallet', network: 'ERC20', address: '0x52908400098527886E0F7030069857D2E4169EE7' });
  assert.equal(c.kind, 'crypto'); assert.equal(code(() => bank.addBeneficiary('u1', { currency: 'USDT', label: 'Bad', network: 'TRC20', address: '0x52908400098527886E0F7030069857D2E4169EE7' })), 'bad_address');
});

test('withdrawal: hold → owner approve → owner completes (fee booked); user cannot approve own; wrong states refused', () => {
  const { bank, ben } = wdSetup();
  const w = bank.requestWithdrawal('u1', { currency: 'USD', amount: '100', beneficiaryId: ben.id, idem: 'wd-key-0001' });
  assert.deepEqual(bal(bank, 'u1', 'USD'), { currency: 'USD', available: 500000 - 10000 - 100, held: 10100, pendingDeposits: 0, pockets: 0, vault: 0 });
  assert.ok(w.flags.includes('first_withdrawal')); assert.ok(w.flags.includes('new_beneficiary'));
  assert.equal(bank.requestWithdrawal('u1', { currency: 'USD', amount: '100', beneficiaryId: ben.id, idem: 'wd-key-0001' }).id, w.id);   // replay: no second hold
  assert.equal(bal(bank, 'u1', 'USD').held, 10100);
  assert.equal(code(() => bank.requestWithdrawal('u1', { currency: 'USD', amount: '101', beneficiaryId: ben.id, idem: 'wd-key-0001' })), 'idempotency_conflict');
  assert.equal(code(() => bank.reviewWithdrawal({ uid: 'u1' }, w.id, 'approve')), 'self_action_not_allowed');
  assert.equal(code(() => bank.completeWithdrawal(OWNER, w.id, { extRef: 'PAYOUT-001' })), 'bad_state');   // not approved yet
  bank.reviewWithdrawal(OWNER, w.id, 'approve', 'checked');
  assert.equal(code(() => bank.cancelWithdrawal('u1', w.id)), 'bad_state');                               // approved: user can no longer cancel
  assert.equal(bank.completeWithdrawal(OWNER, w.id, { extRef: 'PAYOUT-001' }).ok, true);
  assert.deepEqual(bal(bank, 'u1', 'USD'), { currency: 'USD', available: 489900, held: 0, pendingDeposits: 0, pockets: 0, vault: 0 });
  assert.equal(bank.listWithdrawals('u1')[0].status, 'completed');
  assert.equal(code(() => bank.completeWithdrawal(OWNER, w.id, { extRef: 'PAYOUT-002' })), 'bad_state');
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
  const fees = bank.ledger.sys('fees', 'USD'); assert.equal(fees.id && bank.ledger.verify().ok, true);
});

test('withdrawal: reject and user-cancel return the exact hold; insufficient funds and limits are refused atomically', () => {
  const { bank, ben, tick } = wdSetup();
  const w1 = bank.requestWithdrawal('u1', { currency: 'USD', amount: '50', beneficiaryId: ben.id, idem: 'wd-key-0002' });
  bank.reviewWithdrawal(OWNER, w1.id, 'reject', 'suspicious');
  assert.equal(bal(bank, 'u1', 'USD').available, 500000); assert.equal(bank.listWithdrawals('u1')[0].note, 'suspicious');
  const w2 = bank.requestWithdrawal('u1', { currency: 'USD', amount: '50', beneficiaryId: ben.id, idem: 'wd-key-0003' });
  bank.cancelWithdrawal('u1', w2.id); assert.equal(bal(bank, 'u1', 'USD').available, 500000);
  assert.equal(code(() => bank.requestWithdrawal('u1', { currency: 'USD', amount: '1001', beneficiaryId: ben.id, idem: 'wd-key-0004' })), 'daily_limit_exceeded');   // tier 1: 1000 / day
  assert.equal(code(() => bank.requestWithdrawal('u1', { currency: 'USD', amount: '5', beneficiaryId: ben.id, idem: 'wd-key-0005' })), 'below_minimum');
  assert.equal(code(() => bank.requestWithdrawal('u1', { currency: 'USD', amount: '0.001', beneficiaryId: ben.id, idem: 'wd-key-0006' })), 'bad_amount');
  assert.equal(code(() => bank.requestWithdrawal('u1', { currency: 'USD', amount: '100', beneficiaryId: 'ben_nope', idem: 'wd-key-0007' })), 'beneficiary_not_found');
  assert.equal(code(() => bank.requestWithdrawal('u2', { currency: 'USD', amount: '100', beneficiaryId: ben.id, idem: 'wd-key-0008' })), 'kyc_required');
  kyc(bank, 'u2'); assert.equal(code(() => bank.requestWithdrawal('u2', { currency: 'USD', amount: '100', beneficiaryId: ben.id, idem: 'wd-key-0009' })), 'beneficiary_not_found');   // someone else's beneficiary
  void tick;
});

test('withdrawal: velocity limit and insufficient funds', () => {
  const { bank, ben } = wdSetup();
  for (let i = 0; i < 5; i++) bank.requestWithdrawal('u1', { currency: 'USD', amount: '10', beneficiaryId: ben.id, idem: `vel-${i}-abcdef` });
  assert.equal(code(() => bank.requestWithdrawal('u1', { currency: 'USD', amount: '10', beneficiaryId: ben.id, idem: 'vel-5-abcdef' })), 'velocity_limit');
  const s = setup(); kyc(s.bank, 'u3'); fund(s.bank, 'u3', 'USD', '5');
  const b3 = s.bank.addBeneficiary('u3', { currency: 'USD', label: 'x', iban: GOOD_IBAN, holder: 'A B' }); s.tick(2000);
  assert.equal(code(() => s.bank.requestWithdrawal('u3', { currency: 'USD', amount: '20', beneficiaryId: b3.id, idem: 'poor-1-abcdef' })), 'insufficient_funds');
  assert.equal(bal(s.bank, 'u3', 'USD').available, 500); assert.equal(s.bank.listWithdrawals('u3').length, 0);   // nothing half-written
});

test('withdrawal flags: fresh deposit passed straight through, large amounts', () => {
  const { bank, tick } = setup({ mode: 'live' }); kyc(bank, 'u1', 2);
  const ben = bank.addBeneficiary('u1', { currency: 'USD', label: 'x', iban: GOOD_IBAN, holder: 'A B' }); tick(2000);
  const d = bank.requestDeposit('u1', { currency: 'USD', amount: '900', idem: 'dep-fresh-1' }); bank.confirmDeposit(OWNER, d.id, { extRef: 'BANK-FRESH-1' });
  const w = bank.requestWithdrawal('u1', { currency: 'USD', amount: '850', beneficiaryId: ben.id, idem: 'wd-fresh-0001' });
  assert.ok(w.flags.includes('fresh_deposit')); assert.ok(!w.flags.includes('large'));   // tier 2 limit is 25 000
  const q = bank.adminQueue(); assert.equal(q.mode, 'live'); assert.deepEqual(q.withdrawals[0].flags, w.flags); assert.equal(q.ledger.ok, true); assert.equal(q.audit.ok, true);
});

test('KYC: validated, encrypted at rest, owner view is audited, blocked countries and minors refused, tier 2 needs tier 1', () => {
  const { bank, db } = setup();
  const base = { tier: 1, fullName: 'Ada Lovelace', dob: '1990-05-05', nationality: 'DE', address: ADDR, idType: 'passport', idNumber: 'C' + Buffer.from('u1').toString('hex').slice(0, 14), idExpiry: '2031-01-01' };
  assert.equal(code(() => bank.submitKyc('u1', { ...base, dob: '2012-01-01' })), 'under_age');
  assert.equal(code(() => bank.submitKyc('u1', { ...base, nationality: 'KP' })), 'not_available_in_region');
  assert.equal(code(() => bank.submitKyc('u1', { ...base, idExpiry: '2020-01-01' })), 'id_expired');
  assert.equal(code(() => bank.submitKyc('u1', { ...base, fullName: 'Ada <script>' })), 'bad_name');
  assert.equal(code(() => bank.submitKyc('u1', { ...base, tier: 2 })), 'kyc_tier1_first');
  assert.equal(bank.submitKyc('u1', base).status, 'pending');
  assert.equal(code(() => bank.submitKyc('u1', base)), 'already_pending');
  const raw = JSON.stringify(db.prepare('SELECT * FROM kyc').all()); assert.ok(!raw.includes('Lovelace') && !raw.includes(base.idNumber) && !raw.includes('Berlin'));
  assert.equal(code(() => bank.reviewKyc({ uid: 'u1' }, 'u1', 'approve')), 'self_action_not_allowed');
  assert.equal(bank.kycStatus('u1').tier, 0);
  bank.reviewKyc(OWNER, 'u1', 'approve'); assert.equal(bank.kycStatus('u1').tier, 1);
  assert.equal(bank.kycDetail(OWNER, 'u1').fullName, 'Ada Lovelace');
  assert.ok(bank.audit.recent(5).some((r) => r.action === 'kyc.view' && r.actor === 'owner'));
  assert.equal(JSON.stringify(bank.audit.recent(50)).includes('Lovelace'), false);          // audit never holds PII
  assert.equal(bank.submitKyc('u1', { ...base, tier: 2, sourceOfFunds: 'salary', proofOfAddressRef: 'vend-1' }).requestedTier, 2);
  bank.reviewKyc(OWNER, 'u1', 'reject', 'blurry'); assert.equal(bank.kycStatus('u1').tier, 1); assert.equal(bank.kycStatus('u1').reason, 'blurry');   // rejection keeps the old tier
});

test('card: tier 2 + consents + valid form; fee held from the wallet; one open request; lifecycle; refund on cancel/reject', () => {
  const { bank, db } = setup(); kyc(bank, 'u1', 1); fund(bank, 'u1', 'USD', '200');
  const form = { product: 'physical', shipping: 'express', dob: '1990-05-05', nameOnCard: 'ada lovelace', phone: '+49 30 1234567', address: ADDR, consents: { terms: true, fees: true, dataSharing: true }, idem: 'card-key-001' };
  assert.equal(code(() => bank.requestCard('u1', form)), 'kyc_required');
  kyc(bank, 'u1', 2);
  assert.equal(code(() => bank.requestCard('u1', { ...form, consents: { terms: true, fees: true } })), 'consent_required');
  assert.equal(code(() => bank.requestCard('u1', { ...form, nameOnCard: 'Ada 123' })), 'bad_card_name');
  assert.equal(code(() => bank.requestCard('u1', { ...form, address: { ...ADDR, country: 'KP' } })), 'not_available_in_region');
  assert.equal(code(() => bank.requestCard('u1', { ...form, shipping: 'drone' })), 'bad_shipping');
  const c = bank.requestCard('u1', form);
  assert.equal(c.status, 'requested'); assert.equal(c.fee, 3500); assert.equal(c.city, 'Berlin'); assert.equal(bal(bank, 'u1', 'USD').available, 20000 - 3500);
  assert.equal(bank.requestCard('u1', form).id, c.id); assert.equal(bal(bank, 'u1', 'USD').available, 16500);               // replay: no second fee
  assert.equal(code(() => bank.requestCard('u1', { ...form, idem: 'card-key-002' })), 'card_already_requested');
  const raw = JSON.stringify(db.prepare('SELECT * FROM cards').all()); assert.ok(!raw.includes('LOVELACE') && !raw.includes('Invalidenstrasse') && !raw.includes('1234567'));
  assert.equal(bank.cardDetail(OWNER, c.id).form.address.line1, 'Invalidenstrasse 1');
  assert.equal(code(() => bank.updateCard(OWNER, c.id, { status: 'shipped' })), 'bad_transition');
  for (const st of ['review', 'sent_to_issuer', 'produced']) bank.updateCard(OWNER, c.id, { status: st });
  bank.updateCard(OWNER, c.id, { status: 'shipped', tracking: 'DHL-123456' });
  assert.equal(code(() => bank.cancelCard('u1', c.id)), 'bad_state');
  assert.equal(code(() => bank.cardAction('u1', c.id, 'activate')), 'bad_state');
  bank.updateCard(OWNER, c.id, { status: 'delivered' });
  assert.equal(bank.cardAction('u1', c.id, 'activate').status, 'active'); assert.equal(bank.cardAction('u1', c.id, 'freeze').status, 'frozen'); assert.equal(bank.cardAction('u1', c.id, 'unfreeze').status, 'active');
  assert.equal(code(() => bank.cardAction('u2', c.id, 'freeze')), 'not_found');
  // refund paths
  fund(bank, 'u4', 'USD', '100'); kyc(bank, 'u4', 2);
  const c4 = bank.requestCard('u4', { ...form, idem: 'card-key-004' }); assert.equal(bal(bank, 'u4', 'USD').available, 6500);
  bank.cancelCard('u4', c4.id); assert.equal(bal(bank, 'u4', 'USD').available, 10000);
  const c5 = bank.requestCard('u4', { ...form, idem: 'card-key-005' }); bank.updateCard(OWNER, c5.id, { status: 'rejected' }); assert.equal(bal(bank, 'u4', 'USD').available, 10000);
  const v = bank.requestCard('u4', { product: 'virtual', dob: '1990-05-05', nameOnCard: 'ADA LOVELACE', phone: '+49 30 1234567', consents: form.consents, idem: 'card-key-006' }); assert.equal(v.fee, 0); assert.equal(v.city, null);
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
});

test('auto-invest (sandbox): paper buy at a fresh price, daily cap, insufficient funds skip then pause, no catch-up, stale price refused', async () => {
  const s = setup({ price: 50000 }); const { bank, tick } = s; fund(bank, 'u1', 'USDT', '100');
  assert.equal(code(() => bank.createPlan('u1', { asset: 'DOGE', amount: '20', every: 'daily' })), 'bad_asset');
  assert.equal(code(() => bank.createPlan('u1', { asset: 'BTC', amount: '1', every: 'daily' })), 'below_minimum');
  assert.equal(code(() => bank.createPlan('u1', { asset: 'BTC', amount: '20', every: 'hourly' })), 'bad_interval');
  const p = bank.createPlan('u1', { asset: 'BTC', amount: '20', every: 'daily', dailyCap: '30' });
  assert.equal(p.mode, 'paper'); assert.deepEqual(await bank.runDue(), []);          // not due yet
  tick(86400_000 + 1); let r = await bank.runDue();
  assert.equal(r[0].status, 'filled'); assert.equal(bal(bank, 'u1', 'USDT').available, 80_000_000);
  assert.deepEqual(bank.holdings('u1')[0], { asset: 'BTC', qty: 40000, cost: 20_000_000, mode: 'paper' });   // 20 / 50000 = 0.0004 BTC
  assert.deepEqual(await bank.runDue(), []);                                           // same instant: not run twice
  tick(3 * 86400_000);                                                                 // three days missed → exactly one order, no catch-up
  r = await bank.runDue(); assert.equal(r.length, 1); assert.equal(bank.listOrders('u1').filter((o) => o.status === 'filled').length, 2);
  fund(bank, 'u1', 'USDT', '1', 'tiny-0001-abc');
  const drain = bank.listPlans('u1')[0]; bank.setPlan('u1', drain.id, 'delete');
  const p2 = bank.createPlan('u1', { asset: 'ETH', amount: '70', every: 'daily', dailyCap: '1000' });
  for (let i = 0; i < 3; i++) { tick(86400_000 + 1); await bank.runDue(); }
  const orders = bank.listOrders('u1').filter((o) => o.asset === 'ETH'); assert.ok(orders.every((o) => o.status === 'skipped' && o.reason === 'insufficient_funds'));
  assert.equal(bank.listPlans('u1').find((x) => x.id === p2.id).status, 'paused');   // 3 fails → paused
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
  // stale price: refused, nothing spent
  const st = setup({ price: 50000 }); fund(st.bank, 'u1', 'USDT', '100');
  const bank2 = createBank({ db: st.db, vault: createVault({ secret: 'z'.repeat(40) }), mode: 'sandbox', now: st.now, priceFn: async () => ({ price: 50000, ts: st.now() - 120_000 }) });
  bank2.createPlan('u1', { asset: 'BTC', amount: '20', every: 'daily' }); st.tick(86400_000 + 1);
  const rr = await bank2.runDue(); assert.equal(rr[0].reason, 'no_fresh_price'); assert.equal(bal(bank2, 'u1', 'USDT').available, 100_000_000);
});

test('auto-invest (live): without a broker adapter nothing is bought and no money moves', async () => {
  const s = setup({ mode: 'live' }); const { bank, tick } = s; kyc(bank, 'u1');
  const d = bank.requestDeposit('u1', { currency: 'USDT', network: 'ERC20', amount: '100', idem: 'dep-live-usdt' }); bank.confirmDeposit(OWNER, d.id, { extRef: 'CUSTODY-TX-1' });
  const p = bank.createPlan('u1', { asset: 'BTC', amount: '20', every: 'daily' }); assert.equal(p.mode, 'broker');
  tick(86400_000 + 1); const r = await bank.runDue();
  assert.equal(r[0].status, 'skipped'); assert.equal(r[0].reason, 'no_broker'); assert.equal(bal(bank, 'u1', 'USDT').available, 100_000_000);
  assert.deepEqual(bank.holdings('u1'), []); assert.equal(bank.listPlans('u1')[0].status, 'active');   // stays active, waiting for a broker
});

test('isolation: one user never sees or touches another user\'s data', () => {
  const { bank } = wdSetup(); fund(bank, 'u9', 'USD', '10');
  assert.equal(bank.listBeneficiaries('u9').length, 0); assert.equal(bank.listWithdrawals('u9').length, 0); assert.equal(bank.history('u9').items.length, 1);
  assert.equal(bank.history('u1').items.every((t) => t.currency), true);
  const w = bank.listWithdrawals('u1')[0]; void w;
  assert.equal(code(() => bank.cancelWithdrawal('u9', 'wd_nope')), 'not_found');
});
