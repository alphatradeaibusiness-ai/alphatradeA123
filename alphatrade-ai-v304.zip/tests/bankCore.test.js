// Bank core: field encryption, double-entry ledger invariants, tamper-evident audit.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createVault } from '../server/bank/vault.js';
import { openDb } from '../server/bank/db.js';
import { createLedger, LedgerError } from '../server/bank/ledger.js';
import { createAudit } from '../server/bank/audit.js';
import { toMinor, fromMinor } from '../server/bank/money.js';
import { validIban, validCryptoAddress, adult } from '../server/bank/validate.js';

const SECRET = 'k'.repeat(40);

test('vault: round trip, bound to its aad, tamper-proof, no plaintext in the blob', () => {
  const v = createVault({ secret: SECRET });
  const blob = v.seal({ iban: 'DE89370400440532013000', n: 1 }, 'ben:u1');
  assert.deepEqual(v.open(blob, 'ben:u1'), { iban: 'DE89370400440532013000', n: 1 });
  assert.ok(!blob.includes('DE89') && !Buffer.from(blob.split('~')[3], 'base64').toString('latin1').includes('DE89'));
  assert.throws(() => v.open(blob, 'ben:u2'));                                  // copied to another user → fails
  const parts = blob.split('~'); const d = Buffer.from(parts[3].split('.')[2], 'base64'); d[0] ^= 1;
  const [iv, tag] = parts[3].split('.'); parts[3] = [iv, tag, d.toString('base64')].join('.');
  assert.throws(() => v.open(parts.join('~'), 'ben:u1'));                       // flipped bit → fails
  assert.notEqual(v.seal({ a: 1 }, 'x'), v.seal({ a: 1 }, 'x'));               // fresh data key + iv every time
  assert.equal(createVault({ secret: 'short' }).available, false);
  assert.equal(v.blind(' DE89 3704 ') , v.blind('de893704'));                  // blind index normalises
  assert.notEqual(v.blind('a'), createVault({ secret: 'j'.repeat(40) }).blind('a'));
});

test('vault: master key rotation keeps old data readable and rewrap moves it to the new key', () => {
  const oldV = createVault({ secret: SECRET }); const blob = oldV.seal({ x: 1 }, 'a');
  const newV = createVault({ secret: 'n'.repeat(40), previous: [SECRET] });
  assert.deepEqual(newV.open(blob, 'a'), { x: 1 });
  const re = newV.rewrap(blob, 'a'); assert.notEqual(re, blob); assert.deepEqual(newV.open(re, 'a'), { x: 1 });
  assert.throws(() => createVault({ secret: 'n'.repeat(40) }).open(blob, 'a'));   // old key dropped → old blobs unreadable
  assert.deepEqual(createVault({ secret: 'n'.repeat(40) }).open(re, 'a'), { x: 1 });
});

test('money: exact decimal parsing, no floats, no exponents, no excess precision', () => {
  assert.equal(toMinor('12.5', 'USD'), 1250); assert.equal(toMinor('0.00000001', 'BTC'), 1); assert.equal(toMinor(3, 'USD'), 300);
  for (const bad of ['0', '-1', '1e3', '1.001', '', 'abc', ' ', '1,5', '99999999999999999', NaN, Infinity, null, undefined, {}]) assert.equal(toMinor(bad, 'USD'), null, String(bad));
  assert.equal(toMinor('1', 'XXX'), null);
  assert.equal(fromMinor(1250, 'USD'), '12.50'); assert.equal(fromMinor(1, 'BTC'), '0.00000001'); assert.equal(fromMinor(-5, 'USD'), '-0.05');
});

test('validators: IBAN checksum, crypto address shapes, adult dob', () => {
  assert.equal(validIban('DE89 3704 0044 0532 0130 00'), 'DE89370400440532013000');
  assert.equal(validIban('DE89 3704 0044 0532 0130 01'), null); assert.equal(validIban('nope'), null);
  assert.ok(validCryptoAddress('ERC20', '0x52908400098527886E0F7030069857D2E4169EE7')); assert.equal(validCryptoAddress('ERC20', '0x123'), null);
  assert.ok(validCryptoAddress('TRC20', 'TLsV52sRDL79HXGGm9yzwKibb6BeruhUzy')); assert.equal(validCryptoAddress('TRC20', 'ERC...'), null);
  assert.ok(validCryptoAddress('BTC', 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq'));
  const now = Date.UTC(2026, 9, 27);
  assert.equal(adult('2000-01-01', now), '2000-01-01');
  assert.throws(() => adult('2010-01-01', now)); assert.throws(() => adult('2000-02-30', now)); assert.throws(() => adult('x', now));
});

test('ledger: balanced posts only, no negative user balance, idempotency, append-only entries, verify()', () => {
  const db = openDb(':memory:'); const L = createLedger(db);
  const ext = L.sys('external', 'USD'); const w = L.account('u1', 'USD', 'wallet'); const h = L.account('u1', 'USD', 'hold');
  const dep = () => L.post({ type: 'deposit', uid: 'u1', currency: 'USD', amount: 500, idem: 'k1', legs: [{ acc: ext, delta: -500 }, { acc: w, delta: 500 }] });
  const a = db.tx(dep); const b = db.tx(dep);
  assert.equal(a.replay, false); assert.equal(b.replay, true); assert.equal(a.id, b.id); assert.equal(L.balance('u1', 'USD').available, 500);
  assert.throws(() => db.tx(() => L.post({ type: 'deposit', uid: 'u1', currency: 'USD', amount: 999, idem: 'k1', legs: [{ acc: ext, delta: -999 }, { acc: w, delta: 999 }] })), (e) => e.code === 'idempotency_conflict');
  assert.throws(() => db.tx(() => L.post({ type: 'x', currency: 'USD', amount: 1, legs: [{ acc: ext, delta: -1 }, { acc: w, delta: 2 }] })), (e) => e instanceof LedgerError && e.code === 'unbalanced');
  assert.throws(() => db.tx(() => L.post({ type: 'x', uid: 'u1', currency: 'USD', amount: 600, legs: [{ acc: w, delta: -600 }, { acc: h, delta: 600 }] })), (e) => e.code === 'insufficient_funds');
  assert.equal(L.balance('u1', 'USD').available, 500);                                   // the failed post rolled back completely
  assert.equal(L.balance('u1', 'USD').held, 0);
  db.tx(() => L.post({ type: 'hold', uid: 'u1', currency: 'USD', amount: 200, legs: [{ acc: w, delta: -200 }, { acc: h, delta: 200 }] }));
  assert.deepEqual(L.balance('u1', 'USD'), { available: 300, held: 200 });
  assert.throws(() => db.exec('UPDATE entries SET delta = 99'), /append-only/); assert.throws(() => db.exec('DELETE FROM entries'), /append-only/);
  assert.deepEqual(L.verify(), { ok: true, problems: [] });
  db.exec('UPDATE accounts SET balance = balance + 1 WHERE id = \'' + w.id + '\'');          // simulate corruption
  assert.equal(L.verify().ok, false);
  assert.throws(() => db.exec(`UPDATE accounts SET balance = -1 WHERE id = '${w.id}'`));      // CHECK: wallets never negative
});

test('ledger: duplicate external reference can never credit twice', () => {
  const db = openDb(':memory:'); const L = createLedger(db); const ext = L.sys('external', 'USD'); const w = L.account('u1', 'USD', 'wallet');
  const dep = (u) => db.tx(() => L.post({ type: 'deposit', uid: u, currency: 'USD', amount: 100, extRef: 'BANK-123', legs: [{ acc: ext, delta: -100 }, { acc: L.account(u, 'USD', 'wallet'), delta: 100 }] }));
  dep('u1'); assert.throws(() => dep('u1'), (e) => e.code === 'duplicate_reference'); assert.throws(() => dep('u2'), (e) => e.code === 'duplicate_reference');
  assert.equal(L.balance('u1', 'USD').available, 100); assert.equal(L.balance('u2', 'USD').available, 0); void w;
});

test('ledger history: cursor paging, filters, signed effect on the user wallet', () => {
  const db = openDb(':memory:'); let t = 1000; const L = createLedger(db, () => t++); const ext = L.sys('external', 'USD'); const w = L.account('u1', 'USD', 'wallet'); const h = L.account('u1', 'USD', 'hold');
  for (let i = 0; i < 5; i++) db.tx(() => L.post({ type: 'deposit', uid: 'u1', currency: 'USD', amount: 10, legs: [{ acc: ext, delta: -10 }, { acc: w, delta: 10 }] }));
  db.tx(() => L.post({ type: 'withdrawal_hold', uid: 'u1', currency: 'USD', amount: 20, legs: [{ acc: w, delta: -20 }, { acc: h, delta: 20 }] }));
  const p1 = L.history('u1', { limit: 4 }); assert.equal(p1.items.length, 4); assert.ok(p1.next);
  const p2 = L.history('u1', { limit: 4, before: p1.next }); assert.equal(p2.items.length, 2); assert.equal(p2.next, null);
  assert.equal(new Set([...p1.items, ...p2.items].map((x) => x.id)).size, 6);
  assert.equal(p1.items[0].type, 'withdrawal_hold'); assert.equal(p1.items[0].effect, -20); assert.equal(p1.items[1].effect, 10);
  assert.equal(L.history('u1', { type: 'deposit' }).items.length, 5); assert.equal(L.history('u2').items.length, 0);
});

test('audit: hash chain detects edits and deletions; triggers refuse them anyway', () => {
  const db = openDb(':memory:'); const A = createAudit(db);
  for (let i = 0; i < 4; i++) db.tx(() => A.log('u', 'act', `t${i}`, { i }));
  assert.deepEqual(A.verify(), { ok: true, rows: 4 });
  assert.throws(() => db.exec("UPDATE audit SET actor = 'x' WHERE seq = 2"), /append-only/); assert.throws(() => db.exec('DELETE FROM audit WHERE seq = 2'), /append-only/);
  db.exec('DROP TRIGGER audit_no_update'); db.exec("UPDATE audit SET actor = 'evil' WHERE seq = 2");   // an attacker with raw DB access
  assert.deepEqual(A.verify(), { ok: false, brokenAt: 2, rows: 1 });
});
