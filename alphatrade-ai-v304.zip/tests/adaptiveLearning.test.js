// v250 hidden adaptive learning engine. The statistical tests use generated outcomes (fixed seed) — they test the machinery:
// one trade never changes anything, noise is not a pattern, a real repeating loss pattern is found, weights stay bounded,
// a pattern that does not hold out of sample is rejected, nothing goes live without shadow validation, Elite never feeds it.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const mem = new Map();
globalThis.localStorage = { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };
const A = await import('../src/services/adaptiveLearning.js');
const { AL, step, findPatterns, fitModel, decide, validate, diagnose, bh, pLower } = A;

let seed = 7; const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
const gauss = () => { const u = Math.max(1e-9, rnd()), v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
const SESS = ['asia', 'london', 'newyork']; const REG = ['trend', 'range'];
/** n outcomes; `bad(o)` marks the contexts that really lose (r ≈ −0.8) — elsewhere r ≈ +0.25 with noise. */
function gen(n, bad = () => false, t0 = Date.UTC(2026, 0, 1), strategies = ['smc', 'trend', 'mean_reversion']) {
  const out = [];
  for (let i = 0; i < n; i++) {
    const st = strategies[i % strategies.length]; const session = SESS[Math.floor(rnd() * 3)]; const regime = REG[Math.floor(rnd() * 2)];
    const o = { id: `o${t0}-${i}`, strategy: st, at: t0 + i * 3600_000, features: [`session=${session}`, `regime=${regime}`, `dir=${rnd() < 0.5 ? 'long' : 'short'}`], src: 'channel' };
    const loses = bad(o, i);
    o.r = +(loses ? -0.8 + 0.3 * gauss() : 0.25 + 0.9 * gauss()).toFixed(3); o.hits = o.r > 1 ? 3 : o.r > 0.3 ? 1 : 0; o.status = o.r < 0 ? 'sl' : 'tp';
    out.push(o);
  }
  return out;
}
const smcAsia = (o) => o.strategy === 'smc' && o.features.includes('session=asia');

test('statistics: Welch one-sided p and Benjamini–Hochberg behave', () => {
  assert.ok(pLower([-1, -0.9, -1.1, -0.8, -1], [0.5, 0.4, 0.6, 0.3, 0.5]) < 0.001);
  assert.ok(pLower([0.5, 0.4, 0.6], [-1, -1, -1]) > 0.99);
  assert.deepEqual([...bh([0.001, 0.5, 0.04, 0.9], 0.1)].sort(), [0, 2]);
  assert.equal(diagnose({ r: 1.2, hits: 3, status: 'tp3' }), 'full_target');
  assert.equal(diagnose({ r: 0.2, hits: 1 }), 'gave_back_after_tp');
  assert.equal(diagnose({ r: -1, hits: 0, durMs: 2 * 900_000, tfSec: 900 }), 'quick_stop');
  assert.equal(diagnose({ r: -1, hits: 0 }), 'stop_before_tp1');
});

test('one trade (or a handful) never changes anything', () => {
  let s = null;
  for (const o of gen(9, () => true)) s = step(s, o);
  assert.equal(s.candidate, null); assert.equal(s.active, null);
  assert.deepEqual(decide(s.active, 'smc', ['session=asia']), { ok: true, w: 1, rrAdd: 0 });
});

test('noise is not a pattern (false discoveries controlled)', () => {
  seed = 11; const noise = gen(300);
  assert.equal(findPatterns(noise).length, 0);
});

test('a real repeating loss pattern is found, with its reason; weights stay bounded and move one small step', () => {
  seed = 3; const data = gen(300, smcAsia);
  const pats = findPatterns(data);
  assert.ok(pats.some((p) => p.strategy === 'smc' && p.key === 'session=asia'), JSON.stringify(pats.slice(0, 3)));
  const p = pats.find((x) => x.key === 'session=asia'); assert.equal(p.reason, 'stop_before_tp1'); assert.ok(p.n >= AL.minGroupN);
  assert.ok(!pats.some((x) => x.strategy !== 'smc'), 'other strategies are not blamed');
  const m = fitModel(data);
  for (const st of AL.strategies) { assert.ok(m.weights[st] >= AL.weightMin && m.weights[st] <= AL.weightMax); assert.ok(Math.abs(m.weights[st] - 1) <= AL.weightStep + 1e-9, 'one step at most'); }
  const pen = m.penalties['smc|session=asia']; assert.ok(pen.m >= AL.penaltyMin && pen.m < 1);
  assert.equal(decide(m, 'smc', ['session=asia', 'regime=trend']).ok, false, 'the losing context is skipped');
  assert.equal(decide(m, 'smc', ['session=london']).ok, true); assert.equal(decide(m, 'trend', ['session=asia']).ok, true);
});

test('nothing goes live before out-of-sample + shadow validation; a real pattern is promoted after the shadow period', () => {
  seed = 5; let s = null;
  for (const o of gen(300, smcAsia)) s = step(s, o);
  for (const o of gen(120, smcAsia, Date.UTC(2026, 0, 14))) s = step(s, o);
  assert.ok(s.active, 'promoted after the shadow trades confirmed it');
  const order = [...s.log].reverse().map((e) => e.kind);
  assert.ok(order.indexOf('shadow_started') >= 0 && order.indexOf('shadow_started') < order.indexOf('promoted'), 'shadow first, then promotion');
  assert.ok(s.active.shadow.n >= AL.shadowMinN, 'promoted only after enough real outcomes in shadow');
  assert.ok(s.active.penalties['smc|session=asia']);
  assert.equal(decide(s.active, 'smc', ['session=asia']).ok, false);
});

test('a pattern that does not hold out of sample is never used (rejected or discarded in shadow)', () => {
  seed = 9; let s = null;
  const old = gen(200, smcAsia); const fresh = gen(150, (o) => o.strategy === 'smc' && o.features.includes('session=london'), Date.UTC(2026, 2, 1));   // the losses moved
  for (const o of [...old, ...fresh]) s = step(s, o);
  for (const o of gen(150, (o) => o.strategy === 'smc' && o.features.includes('session=london'), Date.UTC(2026, 5, 1))) s = step(s, o);
  const asiaLive = s.active?.penalties?.['smc|session=asia'];
  assert.ok(!asiaLive, 'the old Asia pattern is not live');
  // a clear pattern in the oldest 70 % that turns into WINS in the newest 30 %: the candidate must fail out of sample
  const flip = gen(420, (o, i) => smcAsia(o) && i < 294).map((o, i) => (i >= 294 && smcAsia(o) ? { ...o, r: 0.9 } : o));
  assert.ok(findPatterns(flip.slice(0, 294)).some((p) => p.key === 'session=asia'), 'the pattern is real in the training part');
  const v = validate(flip, null);
  assert.equal(v.pass, false, JSON.stringify(v)); assert.ok(v.reasons.includes('oos_skipped_were_winners') || v.reasons.includes('oos_worse'));
});

test('only regular recommendations: Elite / EDH / unknown strategies never feed it; through learning.js it stays hidden until promoted', async () => {
  let s = null; s = step(s, { id: 'e1', strategy: 'smc', r: -1, at: 1, features: [], src: 'elite' }); assert.equal(s.outcomes.length, 0);
  s = step(s, { id: 'x1', strategy: 'edh', r: -1, at: 1, features: [] }); assert.equal(s.outcomes.length, 0);
  const L = await import('../src/services/learning.js');
  L.resetLearning(); A.resetAdaptive();
  L.learnFromResult({ id: 'ai|t1', strategy: 'smc', symbol: 'XAUUSD', direction: 'long', ctx: { session: 'asia', regime: 'trend' }, r: -1, at: Math.floor(Date.now() / 1000), hits: 0, status: 'stopped', tf: '15m', openedAt: Math.floor(Date.now() / 1000) - 3 * 3600 });
  const st = A.adaptiveState(); assert.equal(st.outcomes.length, 1); assert.equal(st.outcomes[0].src, 'ai'); assert.equal(st.outcomes[0].reason, 'stop_before_tp1');
  assert.ok(st.outcomes[0].at > 1e12, 'seconds from saved AI trades are read as milliseconds');
  assert.ok(Math.abs(L.learnState().outcomes[0].at - Date.now()) < 120_000, 'the old learning store gets the right time too');
  assert.equal(L.learnCheck('smc', { session: 'asia' }, 3, 1.5).ok, true, 'no validated model → no change');
  assert.equal(L.learnWeight('smc', { session: 'asia' }), 1);
});

test('hidden: no interface code in the engine, and Elite never imports it', () => {
  const src = fs.readFileSync(new URL('../src/services/adaptiveLearning.js', import.meta.url), 'utf8');
  assert.equal(/document\.|innerHTML|window\./.test(src), false);
  for (const f of ['eliteEngine.js', 'eliteScanner.js', 'eliteFeed.js']) assert.equal(fs.readFileSync(new URL(`../src/services/${f}`, import.meta.url), 'utf8').includes('adaptiveLearning'), false, f);
  assert.equal(fs.readFileSync(new URL('../src/pages/elite.js', import.meta.url), 'utf8').includes('learning'), false);
});
