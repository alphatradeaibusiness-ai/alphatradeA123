// Owner dashboard over HTTP: 401 signed out, 403 for customers and for an unverified owner e-mail, counts that follow real activity,
// plans ordered cheapest → highest, and no e-mail / uid / IP of anyone in the answer.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';

test('server: /api/admin/dashboard — owners only, aggregates only, online / sign-ins / subscribers per plan', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-ad';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email, verified = true) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, email_verified: verified, firebase: { sign_in_provider: 'google.com' } }));
    return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'adsrv-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'b'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, ADMIN_EMAILS: 'boss@alpha.test', AI_TEST_CERTS_FILE: certFile }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, t, bridge, origin = true } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : JSON.stringify(body);
    const headers = { ...(method !== 'GET' && origin ? { origin: O } : {}), ...(d ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}), ...(bridge ? { 'x-bridge-token': bridge } : {}) };
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => { let j = null; try { j = JSON.parse(s); } catch { /* text */ } resolve({ status: res.statusCode, body: j, text: s, headers: res.headers }); }); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  try {
    for (let i = 0; i < 80; i++) { try { if ((await req('/api/health')).status === 200) break; } catch { /* starting */ } await new Promise((r) => setTimeout(r, 100)); }
    const boss = tok('boss', 'boss@alpha.test'); const fake = tok('fake', 'boss@alpha.test', false);
    const users = ['c1', 'c2', 'c3'].map((u) => tok(u, `${u}-secret@mail.test`));
    assert.equal((await req('/api/admin/dashboard')).status, 401);
    assert.equal((await req('/api/admin/dashboard', { t: users[0] })).status, 403, 'a customer is refused');
    assert.equal((await req('/api/admin/dashboard', { t: fake })).status, 403, 'an unverified owner e-mail is refused');
    // three customers sign in (members + sign-in log + online), one of them gets a quarterly subscription
    for (const t of users) assert.equal((await req('/api/me/signin', { method: 'POST', t, body: { device: 'iPhone · Safari', lang: 'ar' } })).status, 200);
    await req('/api/me/signin', { method: 'POST', t: boss, body: { device: 'Mac · Chrome', lang: 'ar' } });
    const now = Date.now();
    assert.equal((await req('/api/channel/grant', { method: 'POST', t: boss, body: { uid: 'c2', product: 'quarterly', paymentId: 'pi_test_1', startsAt: now - 1000, until: now + 80 * 86400000 } })).status, 200);
    const d = await req('/api/admin/dashboard', { t: boss });
    assert.equal(d.status, 200); if (process.env.DBG) console.log(JSON.stringify({ u: d.body.users, l: { today: d.body.logins.today, s: d.body.logins.signups, a: d.body.logins.active } }));
    assert.equal(d.body.users.members, 4); assert.equal(d.body.users.online, 4); assert.equal(d.body.users.offline, 0);
    assert.equal(d.body.logins.today, 4); assert.equal(d.body.logins.signups.today, 4); assert.equal(d.body.logins.devices.iPhone, 3);
    const plans = d.body.subscriptions.plans;
    assert.deepEqual(plans.map((p) => p.priceCents), [...plans.map((p) => p.priceCents)].sort((a, b) => a - b), 'cheapest plan first');
    assert.equal(plans.find((p) => p.id === 'quarterly').subscribers, 1);
    assert.equal(plans.find((p) => p.id === 'quarterly').mrrCents, Math.round(19000 / 3));
    assert.equal(d.body.subscriptions.subscribers, 1); assert.equal(d.body.subscriptions.conversionPct, 25);
    const raw = JSON.stringify(d.body);
    for (const leak of ['c1-secret@mail.test', 'boss@alpha.test', '"c2"', '127.0.0.1', 'pi_test_1']) assert.equal(raw.includes(leak), false, `no ${leak} in the answer`);
    assert.ok(d.body.logins.recent.every((r) => /\*\*\*@/.test(r.who)), 'recent sign-ins are masked');
    assert.equal(d.headers['cache-control'], 'no-store');
  } finally { child.kill(); }
});

test('dashboard math: subscribers per plan, monthly equivalent, live vs test revenue, add-ons, cheapest first', async () => {
  const { dashboardSnapshot, createPresence, ONLINE_MS } = await import('../server/adminDash.js');
  const t = Date.UTC(2026, 10, 15, 12); const pres = createPresence();
  pres.touch('a', t - 1000); pres.touch('b', t - ONLINE_MS - 1000); pres.touch('x', t);   // x is not a member
  const plans = [{ id: 'annual', kind: 'plan', cents: 65000, months: 12 }, { id: 'monthly', kind: 'plan', cents: 8000, months: 1 }, { id: 'channel', kind: 'plan', cents: 2500, months: 1 }, { id: 'signals25', kind: 'addon', cents: 1000, months: 0 }];
  const acct = (product, until = t + 86400000) => ({ subscription: { product, startsAt: t - 1000, until } });
  const accounts = { a: acct('monthly'), b: acct('monthly'), c: acct('annual'), d: acct('annual', t - 1) /* expired */ };
  const ledgerRows = [{ product: 'monthly', cents: 8000, live: true, at: t - 1000 }, { product: 'monthly', cents: 8000, live: true, at: Date.UTC(2026, 9, 3) },
    { product: 'annual', cents: 65000, live: true, at: t - 5000 }, { product: 'signals25', cents: 1000, live: true, at: t }, { product: 'annual', cents: 65000, live: false, at: t }];
  const activity = { members: 3, logins: {}, active: {}, signups: {}, series: [], devices: {}, langs: {}, recent: [] };
  const s = dashboardSnapshot({ t, presence: pres, activity, accounts, ledgerRows, plans, isMember: (u) => ['a', 'b', 'c'].includes(u) });
  assert.equal(s.users.online, 1); assert.equal(s.users.offline, 2);
  assert.deepEqual(s.subscriptions.plans.map((p) => p.id), ['channel', 'monthly', 'annual']);
  const m = s.subscriptions.plans.find((p) => p.id === 'monthly'); const a = s.subscriptions.plans.find((p) => p.id === 'annual');
  assert.equal(m.subscribers, 2); assert.equal(m.mrrCents, 16000); assert.equal(m.revenueCents, 16000); assert.equal(m.monthCents, 8000); assert.equal(m.payments, 2);
  assert.equal(a.subscribers, 1, 'expired subscription not counted'); assert.equal(a.mrrCents, Math.round(65000 / 12)); assert.equal(a.revenueCents, 65000);
  assert.equal(s.subscriptions.addons[0].revenueCents, 1000);
  assert.equal(s.subscriptions.totals.revenueCents, 16000 + 65000 + 1000);
  assert.deepEqual(s.subscriptions.test, { payments: 1, cents: 65000 }, 'Stripe test payments kept apart');
});
