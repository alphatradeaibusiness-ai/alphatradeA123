// AI signal page end to end: the exact requests the "AI signal" page sends (plan explanation + Alpha AI chat) go through
// server/index.js to a local mock that speaks the Anthropic wire format; checks model, prompts, context and the reply.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';



const PROJECT = 'alphatrade-test';
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const KID = 'test-kid-1';
const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
function token({ uid = 'owner-uid', email = 'shheahmad417@gmail.com', verified = true, aud = PROJECT, exp = 3600, key = privateKey, kid = KID } = {}) {
  const now = Math.floor(Date.now() / 1000);
  const h = b64u(JSON.stringify({ alg: 'RS256', kid, typ: 'JWT' }));
  const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${aud}`, aud, sub: uid, iat: now - 10, auth_time: now - 10, exp: now + exp, email, email_verified: verified, firebase: { sign_in_provider: 'google.com' } }));
  const sig = crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), key);
  return `${h}.${p}.${b64u(sig)}`;
}
const certs = { [KID]: publicKey.export({ type: 'spki', format: 'pem' }) };

import { fmtTz } from '../src/services/aiSignalUtil.js';

const listen = (srv) => new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv.address().port)));
const call = (port, p, { method = 'GET', tok, body } = {}) => new Promise((resolve, reject) => {
  const headers = { origin: `http://127.0.0.1:${port}`, host: `127.0.0.1:${port}`, 'content-type': 'application/json' };
  if (tok) headers.authorization = `Bearer ${tok}`;
  const r = http.request({ host: '127.0.0.1', port, path: p, method, headers }, (res) => { let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => { let j = null; try { j = JSON.parse(d); } catch { /* */ } resolve({ status: res.statusCode, body: j }); }); });
  r.on('error', reject); if (body !== undefined) r.write(JSON.stringify(body)); r.end();
});

test('AI signal page: plan explanation and Alpha AI chat reach Claude with the right model, prompts, trades and UTC+03:00', async () => {
  const seen = [];
  const mock = http.createServer((q, s) => { let d = ''; q.on('data', (c) => (d += c)); q.on('end', () => {
    const j = JSON.parse(d || '{}'); seen.push({ url: q.url, model: j.model, system: j.system || '', messages: j.messages || [] });
    s.writeHead(200, { 'content-type': 'application/json' });
    s.end(JSON.stringify({ model: j.model, content: [{ type: 'text', text: `reply from ${j.model}` }] }));
  }); });
  const mp = await listen(mock);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'aisg-'));
  const certFile = path.join(dir, 'certs.json'); fs.writeFileSync(certFile, JSON.stringify(certs));
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), ANTHROPIC_BASE_URL: `http://127.0.0.1:${mp}`, AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, AI_KEY_SECRET: 's'.repeat(48), SERVER_DATA_DIR: dir, ANTHROPIC_API_KEY: '', AI_USER_PER_MINUTE: '100', AI_IP_PER_MINUTE: '1000', AI_DAILY_PER_IP: '1000', AI_DAILY_LIMIT: '1000' }, stdio: 'ignore' });
  for (let i = 0; i < 60; i++) { try { await call(port, '/api/ai/health'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
  const owner = token(); const user = token({ uid: 'u-2', email: 'trader@example.com' });
  try {
    // the owner saves a key without choosing a model → the default model is used
    const saved = await call(port, '/api/ai/config', { method: 'PUT', tok: owner, body: { provider: 'anthropic', apiKey: 'sk-ant-api03-good-key-for-the-test-ZZ99' } });
    assert.equal(saved.body.ok, true);
    seen.length = 0;
    // 1) plan explanation, as aiSignal.js aiBrief() builds it
    const times = { now: fmtTz(1793430000, 'en'), lastCandle: fmtTz(1793429100, 'en'), validUntil: fmtTz(1793440800, 'en') };
    const brief = { symbol: 'XAUUSD', timeframe: '15m', mode: 'live', verdict: 'trade', direction: 'short', style: 'scalp', execution: 'limit',
      plan: { entry: 4517.54, stop: 4530.1, targets: [4500.2, 4488.6], rr: [1.38, 2.3], orderType: 'limit' }, checks: [], score: { passed: 11, total: 15 },
      orderNote: 'Pending limit order at 4517.54: it activates automatically when price reaches that level; no trade is open before that.', timezone: 'UTC+03:00', times };
    const smc = await call(port, '/api/ai/smc', { method: 'POST', tok: user, body: { context: brief, lang: 'ar' } });
    assert.equal(smc.status, 200); assert.equal(smc.body.reply, 'reply from claude-opus-5-5');
    const a = seen.at(-1);
    assert.equal(a.model, 'claude-opus-5-5');
    assert.match(a.system, /timezone/); assert.match(a.system, /Arabic/i);
    const sent = a.messages[0].content;
    for (const s of ['4517.54', '4530.1', 'Pending limit order', times.validUntil, 'UTC+03:00']) assert.ok(sent.includes(s), `missing ${s}`);
    // 2) Alpha AI chat with the user's trades (aiSignal.js chatContext())
    const ctx = { page: 'ai-trading-chat', timezone: 'UTC+03:00', now: times.now, mode: 'live', openTrades: 1,
      myTrades: [{ symbol: 'BTCUSDT', timeframe: '4h', style: 'swing', direction: 'long', status: 'active', targetsHit: 1, entry: 77270.63, stop: 77300.34, targets: [77201.95], resultR: null, saved: times.lastCandle, livePrice: 77250 }] };
    const chat = await call(port, '/api/ai/chat', { method: 'POST', tok: user, body: { messages: [{ role: 'user', content: 'شو وضع صفقاتي المفتوحة؟' }], context: ctx, lang: 'ar' } });
    assert.equal(chat.status, 200); assert.equal(chat.body.reply, 'reply from claude-opus-5-5');
    const b = seen.at(-1);
    assert.equal(b.model, 'claude-opus-5-5');
    assert.match(b.system, /myTrades/); assert.match(b.system, /UTC\+03:00/); assert.ok(b.system.includes('77270.63'));
    assert.equal(b.messages.at(-1).content, 'شو وضع صفقاتي المفتوحة؟');
    // without signing in the page gets a clear refusal, not an answer
    assert.equal((await call(port, '/api/ai/chat', { method: 'POST', body: { messages: [{ role: 'user', content: 'x' }] } })).status, 401);
  } finally { child.kill(); mock.close(); fs.rmSync(dir, { recursive: true, force: true }); }
});
