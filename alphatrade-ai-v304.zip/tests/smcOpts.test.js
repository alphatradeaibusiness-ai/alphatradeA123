import test from 'node:test';
import assert from 'node:assert/strict';
import { scoreSetup, SMC2_OPTS, SMC2_DEFAULTS } from '../src/services/smc2.js';
import { rulesFrom } from '../src/services/backtest.js';
import { getInstrument } from '../src/config/instruments.js';

const fake = (o, htf, setup = {}) => {
  const c = Array.from({ length: 5 }, (_, k) => ({ time: 1_700_000_000 + k * 900, open: 1, high: 1, low: 1, close: 1 }));
  const S = { c, tfSec: 900, o: { ...SMC2_DEFAULTS, ...SMC2_OPTS, ...o }, htf };
  const s = { direction: 'long', entry: 1, risk: 1, sweep: { type: 'swing' }, ob: { disp: 2.5, impFvg: true, bottom: 1, top: 1 }, choch: { strength: 0.5 }, fvg: { size: 0.5 }, ...setup };
  return { r: scoreSetup(S, 4, s, [2, 3, 4]), s };
};
const htf = (h4, d1) => ({ h4: () => h4, d1: () => d1 });

test('defaults keep the original strict rules', () => {
  assert.deepEqual([SMC2_OPTS.htfMode, SMC2_OPTS.reversal, SMC2_OPTS.minDisp, SMC2_OPTS.fvgMin, SMC2_OPTS.maxAfterTap, SMC2_OPTS.stopBufAtr, SMC2_OPTS.maxRiskAtr, SMC2_OPTS.rsiGate], ['both', false, 1, 0.1, 15, 0.2, 5, false]);
  const o = rulesFrom({ plan: {}, smc2: {}, zone: {}, risk: {} }, getInstrument('BTCUSDT')).smcOpts;
  assert.equal(o.htfMode, 'both'); assert.equal(o.reversal, false); assert.equal(o.maxAfterTap, 15);
});
test('htfMode: 4h and Daily disagree → "both" blocks, "h4" passes, "d1" blocks', () => {
  assert.equal(fake({}, htf('bull', 'bear')).r.gates.htf, false);
  assert.equal(fake({ htfMode: 'h4' }, htf('bull', 'bear')).r.gates.htf, true);
  assert.equal(fake({ htfMode: 'd1' }, htf('bull', 'bear')).r.gates.htf, false);
});
test('reversal rule: counter-trend only for a major sweep with strong displacement and CHoCH', () => {
  assert.equal(fake({ reversal: true }, htf('bear', 'bear')).r.gates.htf, true);                                         // allowed, flagged
  assert.equal(fake({ reversal: true }, htf('bear', 'bear'), { sweep: { type: 'inducement' } }).r.gates.htf, false);   // minor sweep: not a reversal
  assert.equal(fake({ reversal: true }, htf('bear', 'bear'), { ob: { disp: 1.2, impFvg: true, bottom: 1, top: 1 } }).r.gates.htf, false);
  assert.equal(fake({ reversal: false }, htf('bear', 'bear')).r.gates.htf, false);                                       // off by default
});
