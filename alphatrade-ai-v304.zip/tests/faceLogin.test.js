import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createFaceLogin, parseServiceAccount, customToken } from '../server/faceLogin.js';

// ── a tiny software authenticator (ES256, "none" attestation) ──
const cbor = (v) => {
  const head = (major, n) => (n < 24 ? Buffer.from([(major << 5) | n]) : n < 256 ? Buffer.from([(major << 5) | 24, n]) : Buffer.from([(major << 5) | 25, n >> 8, n & 255]));
  if (typeof v === 'number') return v >= 0 ? head(0, v) : head(1, -1 - v);
  if (Buffer.isBuffer(v)) return Buffer.concat([head(2, v.length), v]);
  if (typeof v === 'string') { const b = Buffer.from(v); return Buffer.concat([head(3, b.length), b]); }
  if (v instanceof Map) return Buffer.concat([head(5, v.size), ...[...v].flatMap(([k, x]) => [cbor(k), cbor(x)])]);
  throw new Error('cbor');
};
const RP = { rpId: 'site.example', origins: ['https://site.example'] };
function device() {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'P-256' });
  const jwk = publicKey.export({ format: 'jwk' }); const credId = crypto.randomBytes(16); let count = 0;
  const rpHash = (id) => crypto.createHash('sha256').update(id).digest();
  const cdj = (type, challenge, origin) => Buffer.from(JSON.stringify({ type, challenge, origin, crossOrigin: false }));
  return {
    id: credId.toString('base64url'),
    create(opts, { origin = RP.origins[0], uv = true } = {}) {
      const cose = cbor(new Map([[1, 2], [3, -7], [-1, 1], [-2, Buffer.from(jwk.x, 'base64url')], [-3, Buffer.from(jwk.y, 'base64url')]]));
      const ad = Buffer.concat([rpHash(opts.publicKey.rp.id), Buffer.from([0x41 | (uv ? 0x04 : 0)]), Buffer.alloc(4), Buffer.alloc(16), Buffer.from([0, credId.length]), credId, cose]);
      return { challengeId: opts.challengeId, name: 'Test phone', credential: { id: credId.toString('base64url'), rawId: credId.toString('base64url'), type: 'public-key', response: { clientDataJSON: cdj('webauthn.create', opts.publicKey.challenge, origin).toString('base64url'), attestationObject: cbor(new Map([['fmt', 'none'], ['attStmt', new Map()], ['authData', ad]])).toString('base64url') } } };
    },
    get(opts, { origin = RP.origins[0], handle = null, rpId = opts.publicKey.rpId } = {}) {
      count += 1; const ad = Buffer.concat([rpHash(rpId), Buffer.from([0x05]), Buffer.from([0, 0, 0, count])]);
      const c = cdj('webauthn.get', opts.publicKey.challenge, origin);
      const sig = crypto.sign('sha256', Buffer.concat([ad, crypto.createHash('sha256').update(c).digest()]), { key: privateKey, dsaEncoding: 'der' });
      return { challengeId: opts.challengeId, credential: { id: credId.toString('base64url'), type: 'public-key', response: { clientDataJSON: c.toString('base64url'), authenticatorData: ad.toString('base64url'), signature: sig.toString('base64url'), userHandle: handle } } };
    },
  };
}
const SA = (() => { const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 }); return { json: JSON.stringify({ client_email: 'svc@proj.iam.gserviceaccount.com', private_key: privateKey.export({ type: 'pkcs8', format: 'pem' }), project_id: 'proj' }), publicKey }; })();

test('face sign-in: enrol a device (face unlock required), sign in by face → Firebase custom token; clones, wrong site and replays are refused', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'face-'));
  const f = createFaceLogin({ dir, secret: 'f'.repeat(40), env: { FIREBASE_SERVICE_ACCOUNT: SA.json } });
  assert.equal(f.configured(), true);
  const user = { uid: 'ann', email: 'ann@x.co', name: 'Ann' }; const phone = device();
  const ro = f.registerOptions(user, RP);
  assert.equal(ro.publicKey.authenticatorSelection.authenticatorAttachment, 'platform'); assert.equal(ro.publicKey.authenticatorSelection.userVerification, 'required');
  assert.throws(() => f.register(user, phone.create(ro, { uv: false }), RP), /user_verification_required/, 'no face/biometric check → refused');
  const ro2 = f.registerOptions(user, RP); assert.equal(f.register(user, phone.create(ro2), RP).ok, true);
  assert.throws(() => f.register(user, phone.create(ro2), RP), /challenge_expired/, 'a challenge works once');
  assert.equal(f.status('ann').devices.length, 1); assert.equal(f.status('ann').devices[0].name, 'Test phone');
  // sign in with the face
  const lo = f.loginOptions(RP); assert.deepEqual(lo.publicKey.allowCredentials, []);
  const out = f.login(phone.get(lo), RP); assert.equal(out.uid, 'ann');
  const [h, b, s] = out.token.split('.'); const claims = JSON.parse(Buffer.from(b, 'base64url').toString());
  assert.equal(claims.uid, 'ann'); assert.equal(claims.iss, 'svc@proj.iam.gserviceaccount.com'); assert.match(claims.aud, /identitytoolkit/); assert.equal(claims.exp - claims.iat, 3600); assert.equal(claims.claims.via, 'face');
  assert.equal(crypto.verify('RSA-SHA256', Buffer.from(`${h}.${b}`), SA.publicKey, Buffer.from(s, 'base64url')), true, 'signed by the service account');
  // refusals
  assert.throws(() => f.login(phone.get(f.loginOptions(RP), { origin: 'https://evil.example' }), RP), /origin/);
  assert.throws(() => f.login(phone.get(f.loginOptions(RP), { rpId: 'evil.example' }), RP), /rp_mismatch/);
  assert.throws(() => f.login(device().get(f.loginOptions(RP)), RP), /unknown_credential/, 'a device that was never enrolled');
  const replay = phone.get(f.loginOptions(RP)); f.login(replay, RP); assert.throws(() => f.login(replay, RP), /challenge_expired/, 'a signed answer cannot be replayed');
  assert.equal(fs.readFileSync(path.join(dir, 'face-login.json'), 'utf8').includes('ann'), false, 'stored encrypted');
  // remove → face sign-in stops for that device
  assert.equal(f.remove('ann').removed, 1); assert.throws(() => f.login(phone.get(f.loginOptions(RP)), RP), /unknown_credential/);
});

test('face sign-in is off without a service account; bad service accounts are rejected', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'face2-'));
  const f = createFaceLogin({ dir, secret: 'f'.repeat(40), env: {} }); assert.equal(f.configured(), false);
  assert.throws(() => f.login({ challengeId: 'x' }, RP), /not_configured/);
  assert.equal(parseServiceAccount('{"client_email":"a"}'), null); assert.equal(parseServiceAccount('not json'), null);
  assert.ok(parseServiceAccount(Buffer.from(SA.json).toString('base64')), 'base64 form accepted');
  assert.equal(customToken(parseServiceAccount(SA.json), 'u', {}, 1000).split('.').length, 3);
});

import http from 'node:http';
import { spawn } from 'node:child_process';
test('server: face routes — fresh sign-in to enrol, sign-in without password returns a token, Origin and attempts limited', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-face';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (x) => Buffer.from(x).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email, ago = 10) => { const n = Math.floor(Date.now() / 1000); const hh = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - ago, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'password' } }));
    return `${hh}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${hh}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'faceh-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: certFile, FIREBASE_SERVICE_ACCOUNT: SA.json }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, t, origin = O } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { ...(method !== 'GET' && origin ? { origin } : {}), ...(d ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}) } }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => { let j = null; try { j = JSON.parse(s); } catch { /* */ } resolve({ status: res.statusCode, body: j }); }); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  const rpo = { rpId: '127.0.0.1', origins: [O] }; const phone = device();
  try {
    for (let i = 0; i < 80; i++) { try { await req('/api/health'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    assert.equal((await req('/api/face/register/options', { method: 'POST', t: tok('ann', 'ann@x.co', 3600), body: {} })).body.code, 'reauth_required');
    const ro = (await req('/api/face/register/options', { method: 'POST', t: tok('ann', 'ann@x.co'), body: {} })).body; assert.equal(ro.publicKey.rp.id, '127.0.0.1');
    const reg = phone.create(ro, { origin: O }); assert.equal((await req('/api/face/register', { method: 'POST', t: tok('ann', 'ann@x.co'), body: reg })).body.ok, true);
    assert.equal((await req('/api/face/status', { t: tok('ann', 'ann@x.co') })).body.devices.length, 1);
    assert.equal((await req('/api/face/login/options', { method: 'POST', origin: null, body: {} })).status, 403, 'needs our Origin');
    const lo = (await req('/api/face/login/options', { method: 'POST', body: {} })).body; assert.equal(lo.configured, true);
    const li = await req('/api/face/login', { method: 'POST', body: phone.get(lo, { origin: O, rpId: '127.0.0.1' }) });
    assert.equal(li.status, 200); assert.equal(JSON.parse(Buffer.from(li.body.token.split('.')[1], 'base64url')).uid, 'ann');
    for (let i = 0; i < 10; i++) await req('/api/face/login', { method: 'POST', body: { challengeId: 'nope', credential: { id: 'x' } } });
    assert.equal((await req('/api/face/login', { method: 'POST', body: { challengeId: 'nope' } })).status, 429, 'failed attempts are limited');
    assert.equal((await req('/api/face', { method: 'DELETE', t: tok('ann', 'ann@x.co'), body: {} })).body.removed, 1);
  } finally { child.kill(); }
});
