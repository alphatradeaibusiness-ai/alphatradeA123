import test from 'node:test';
import assert from 'node:assert/strict';
import { createMailer, renderMail } from '../server/mail.js';

test('mail: no key means nothing is sent', async () => {
  const m = createMailer({ env: {}, fetchImpl: () => { throw new Error('should not call'); } });
  assert.equal(m.configured(), false);
  assert.deepEqual(await m.onSignin({ uid: 'u1', email: 'a@b.co' }), { sent: false, reason: 'not_configured' });
});
test('mail: welcome first, then sign-in notice at most every 10 minutes', async () => {
  let t = 1_000_000; const calls = [];
  const fetchImpl = async (u, o) => { calls.push(JSON.parse(o.body)); return { ok: true }; };
  const m = createMailer({ env: { RESEND_API_KEY: 'k', PUBLIC_URL: 'https://x.test' }, fetchImpl, now: () => t });
  assert.equal((await m.onSignin({ uid: 'u1', email: 'a@b.co', name: 'Sam <b>' })).kind, 'welcome');
  assert.equal((await m.onSignin({ uid: 'u1', email: 'a@b.co' })).reason, 'recent');
  t += 11 * 60_000;
  assert.equal((await m.onSignin({ uid: 'u1', email: 'a@b.co' })).kind, 'signin');
  assert.deepEqual(calls[0].to, ['a@b.co']);
  assert.match(calls[0].from, /AlphaTrade AI/);
  assert.ok(!calls[0].html.includes('<b>'), 'name is escaped');
});
test('mail: provider failure does not mark the welcome as sent', async () => {
  const m = createMailer({ env: { RESEND_API_KEY: 'k' }, fetchImpl: async () => ({ ok: false, status: 403 }) });
  assert.equal((await m.onSignin({ uid: 'u2', email: 'a@b.co' })).sent, false);
  assert.equal(renderMail('welcome', { name: 'A' }).subject.includes('Welcome'), true);
});
