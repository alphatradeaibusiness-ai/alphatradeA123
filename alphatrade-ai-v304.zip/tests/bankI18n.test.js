// Every bank text exists in Arabic and English (same nested keys), and every key the bank page uses exists.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const { default: ar } = await import('../src/i18n/ar.js');
const { default: en } = await import('../src/i18n/en.js');
const flat = (o, p = '') => Object.entries(o).flatMap(([k, v]) => (v && typeof v === 'object' ? flat(v, `${p}${k}.`) : [`${p}${k}`]));

test('tools.bank: Arabic and English have exactly the same keys', () => {
  const a = new Set(flat(ar.tools.bank)); const e = new Set(flat(en.tools.bank));
  assert.deepEqual([...a].filter((k) => !e.has(k)), [], 'missing in English');
  assert.deepEqual([...e].filter((k) => !a.has(k)), [], 'missing in Arabic');
});
test('tools.bank: every static key used by the bank page exists', () => {
  const dir = new URL('../src/pages/tools/', import.meta.url);
  const files = ['bank.js', ...fs.readdirSync(new URL('bank/', dir)).map((f) => `bank/${f}`)];
  const keys = new Set(flat(en.tools.bank)); const missing = [];
  for (const f of files) for (const m of fs.readFileSync(new URL(f, dir), 'utf8').matchAll(/\bTx?\(\s*'([^'$]+)'/g)) {
    const k = m[1]; if (!keys.has(k) && !flat(en.tools.bank).some((x) => x.startsWith(`${k}.`))) missing.push(`${f}: ${k}`);
  }
  assert.deepEqual(missing, []);
});
test('tools.bank: every server error code has a message', () => {
  const codes = new Set();
  for (const f of fs.readdirSync(new URL('../server/bank/features/', import.meta.url))) for (const m of fs.readFileSync(new URL(`../server/bank/features/${f}`, import.meta.url), 'utf8').matchAll(/bad\('([a-z_]+)'/g)) codes.add(m[1]);
  for (const f of ['service.js', 'http.js']) for (const m of fs.readFileSync(new URL(`../server/bank/${f}`, import.meta.url), 'utf8').matchAll(/bad\('([a-z_]+)'|BankError\('([a-z_]+)'/g)) codes.add(m[1] || m[2]);
  const missing = [...codes].filter((c) => !en.tools.bank.err[c] && !c.startsWith('passkey_'));
  assert.deepEqual(missing, []);
});
