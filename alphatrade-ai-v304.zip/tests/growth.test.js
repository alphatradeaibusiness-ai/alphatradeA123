import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createChannelAccess } from '../server/channelAccess.js';
import { createLedger } from '../server/ledger.js';
import { createUserTrades } from '../server/userTrades.js';
import { createGrowth } from '../server/growth.js';

const DAY = 86_400_000;
function setup(extraEnv = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gr-'));
  const access = createChannelAccess(dir); const ledger = createLedger({ dir }); const ut = createUserTrades({ dir, secret: 's'.repeat(40) });
  let t = Date.UTC(2026, 9, 26, 9);   // a Monday
  const mails = []; const tg = []; const pushes = []; let updates = [];
  const fetchFn = async (url, o = {}) => {
    const u = String(url);
    if (u.startsWith('http://mail/')) { mails.push(JSON.parse(o.body)); return { ok: true, json: async () => ({ id: 'm' }) }; }
    if (u.includes('/getMe')) return { ok: true, json: async () => ({ ok: true, result: { username: 'AlphaBot' } }) };
    if (u.includes('/getUpdates')) { const r = updates; updates = []; return { ok: true, json: async () => ({ ok: true, result: r }) }; }
    if (u.includes('/sendMessage')) { tg.push(JSON.parse(o.body)); return { ok: true, json: async () => ({ ok: true }) }; }
    if (u.startsWith('http://cal/')) return { ok: true, json: async () => [{ title: 'CPI m/m', country: 'USD', impact: 'High', date: new Date(t + 15 * 60_000).toISOString() }, { title: 'Minor', country: 'EUR', impact: 'Low', date: new Date(t + 15 * 60_000).toISOString() }] };
    throw new Error(`unexpected ${u}`);
  };
  const g = createGrowth({ dir, secret: 'g'.repeat(40), access, ledger, userTrades: ut, env: { RESEND_API_KEY: 're_x', MAIL_FROM: 'A <a@b.co>', ...extraEnv }, fetchFn, now: () => t,
    pushTo: (uid, m) => { pushes.push({ uid, ...m }); return 1; }, telegram: () => '123:ABC', mailBase: 'http://mail', tgBase: 'http://tg', calendarUrl: 'http://cal/x', log: { error() {} } });
  return { g, access, ledger, ut, dir, mails, tg, pushes, setT: (v) => { t = v; }, getT: () => t, addUpdates: (u) => { updates = u; } };
}
const U = (uid, email, authTime) => ({ uid, email, name: uid, authTime });

test('sign-in alert: welcome on the first sign-in, then an alert on every new sign-in (not on refresh), new device flagged; message centre', async () => {
  const s = setup();
  let r = await s.g.signIn(U('u1', 'u1@x.co', 100), { device: 'iPhone · Safari', lang: 'ar' }, '10.1.2.3');
  assert.equal(r.fresh, true); assert.equal(s.mails.length, 1); assert.match(s.mails[0].subject, /أهلين/);
  assert.equal((await s.g.signIn(U('u1', 'u1@x.co', 100), { device: 'iPhone · Safari' })).duplicate, true, 'same sign-in (page refresh) is not alerted twice');
  r = await s.g.signIn(U('u1', 'u1@x.co', 200), { device: 'Windows · Chrome', lang: 'ar' }, '10.1.2.3');
  assert.equal(r.newDevice, true);
  const n = s.g.notices('u1'); assert.equal(n.unread, 2); assert.equal(n.items[0].kind, 'signin'); assert.match(n.items[0].title, /جهاز جديد/); assert.match(n.items[0].body, /Windows · Chrome/); assert.match(n.items[0].body, /10\.1\.2\.x/);
  assert.equal(s.pushes.at(-1).uid, 'u1'); assert.equal(s.mails.length, 2, 'sign-in e-mail sent');
  s.g.prefs('u1', { emailLogin: false });
  await s.g.signIn(U('u1', 'u1@x.co', 300), { device: 'Windows · Chrome' }); assert.equal(s.mails.length, 2, 'e-mail alert can be switched off');
  assert.match(s.g.notices('u1').items[0].title, /تسجيل دخول جديد/);
  s.g.markRead('u1'); assert.equal(s.g.notices('u1').unread, 0);
  assert.equal(fs.readFileSync(path.join(s.dir, 'growth.json'), 'utf8').includes('u1@x.co'), false, 'stored encrypted');
});

test('trial once per account and per e-mail; referral reward on the first payment; banked days', async () => {
  const s = setup(); const t0 = s.getT();
  await s.g.signIn(U('a', 'a@x.co', 1)); await s.g.signIn(U('b', 'b@x.co', 1));
  assert.equal(s.g.trialStatus('a', 'a@x.co').eligible, true);
  const tr = await s.g.startTrial(U('a', 'a@x.co')); assert.equal(tr.ok, true); assert.equal(s.access.subscription('a', t0).product, 'annual'); assert.equal(Math.round((tr.until - t0) / DAY), 7);
  assert.equal((await s.g.startTrial(U('a', 'a@x.co'))).error, 'trial_used');
  await s.g.signIn(U('a2', 'A@X.co', 1)); assert.equal((await s.g.startTrial(U('a2', 'A@X.co'))).error, 'trial_not_available', 'a new account with the same e-mail gets no second trial');
  const code = s.g.referral('a').code;
  assert.equal(s.g.claimReferral('a', code).error, 'bad_code', 'not your own code');
  assert.equal(s.g.claimReferral('b', code).ok, true); assert.equal(s.g.claimReferral('b', code).error, 'already_referred');
  assert.equal(s.g.referral('a').invited, 1);
  // b pays → both get 7 days (a has an active trial → extended; b → extends its new plan)
  s.access.grant('b', { product: 'monthly', paymentId: 'cs_b', startsAt: t0, until: t0 + 30 * DAY }, t0);
  const before = s.access.subscription('a', t0).until;
  const out = await s.g.onPaid('b'); assert.equal(out.referral, 7);
  assert.equal(s.access.subscription('a', t0).until - before, 7 * DAY); assert.equal(Math.round((s.access.subscription('b', t0).until - t0) / DAY), 37);
  assert.equal((await s.g.onPaid('b')).referral, undefined, 'only once');
  // banked days when there is no active plan
  await s.g.signIn(U('c', 'c@x.co', 1)); assert.equal(s.g.addDays('c', 5, 'x'), 'banked'); assert.equal(s.g.referral('c').creditDays, 5);
  s.access.grant('c', { product: 'monthly', paymentId: 'cs_c', startsAt: t0, until: t0 + 30 * DAY }, t0);
  assert.equal((await s.g.onPaid('c')).credit, 5); assert.equal(Math.round((s.access.subscription('c', t0).until - t0) / DAY), 35);
  // too late to claim a referral after 3 days
  s.setT(t0 + 4 * DAY); await s.g.signIn(U('d', 'd@x.co', 1)); s.setT(t0 + 8 * DAY); assert.equal(s.g.claimReferral('d', code).error, 'too_late');
});

test('Telegram: one-time deep link, /start links the chat, alerts go there, /stop unlinks', async () => {
  const s = setup();
  await s.g.signIn(U('t1', 't1@x.co', 1));
  const l = await s.g.tgLinkStart('t1'); assert.match(l.url, /^https:\/\/t\.me\/AlphaBot\?start=[A-Za-z0-9]+$/);
  const code = l.url.split('start=')[1];
  s.addUpdates([{ update_id: 5, message: { text: `/start ${code}`, chat: { id: 777, type: 'private' } } }]); await s.g.tgPoll();
  assert.equal(s.g.prefs('t1').telegram.linked, true); assert.equal(s.tg.at(-1).chat_id, 777);
  s.addUpdates([{ update_id: 6, message: { text: `/start ${code}`, chat: { id: 888, type: 'private' } } }]); await s.g.tgPoll();
  assert.match(s.tg.at(-1).text, /انتهى/, 'a link works once');
  await s.g.deliver('t1', { kind: 'x', title: 'T', body: 'B' }); assert.equal(s.tg.at(-1).chat_id, 777);
  s.addUpdates([{ update_id: 7, message: { text: '/stop', chat: { id: 777, type: 'private' } } }]); await s.g.tgPoll();
  assert.equal(s.g.prefs('t1').telegram.linked, false);
});

test('TradingView webhook, settings sync, broadcast', async () => {
  const s = setup();
  await s.g.signIn(U('v', 'v@x.co', 1), { lang: 'en' });
  const tok = s.g.tvToken('v');
  assert.equal((await s.g.tvHook('nope', 'x')).status, 404);
  assert.equal((await s.g.tvHook(tok, JSON.stringify({ ticker: 'BTCUSDT', message: 'Cross up 50k' }))).status, 200);
  assert.match(s.g.notices('v').items[0].title, /TradingView alert · BTCUSDT/); assert.equal(s.g.notices('v').items[0].body, 'Cross up 50k');
  const tok2 = s.g.tvToken('v', true); assert.notEqual(tok2, tok); assert.equal((await s.g.tvHook(tok, 'x')).status, 404, 'old URL stops working');
  for (let i = 0; i < 30; i++) await s.g.tvHook(tok2, `m${i}`);
  assert.equal((await s.g.tvHook(tok2, 'again')).status, 429);
  assert.equal(s.g.putSync('v', { settings: { a: 1 } }, 10).ok, true); assert.equal(s.g.putSync('v', { settings: { a: 0 } }, 5).stale, true); assert.deepEqual(s.g.getSync('v').data, { settings: { a: 1 } });
  assert.equal(s.g.putSync('v', { big: 'x'.repeat(60000) }, 20).error, 'too_large');
  const b = await s.g.broadcast({ title: 'New version', body: 'Faster charts' }); assert.equal(b.sent, 1);
  assert.equal(s.g.notices('v').broadcast.title, 'New version'); s.g.dismissBroadcast('v', b.id); assert.equal(s.g.notices('v').broadcast, null);
});

test('jobs: plan ending reminder once, high-impact news 15 min ahead for opted-in users, weekly report e-mail', async () => {
  const s = setup(); const t0 = s.getT();
  await s.g.signIn(U('j', 'j@x.co', 1)); await s.g.signIn(U('k', 'k@x.co', 1));
  s.access.grant('j', { product: 'monthly', paymentId: 'p', startsAt: t0 - 28 * DAY, until: t0 + 2 * DAY }, t0);
  s.g.prefs('j', { news: true, newsCcy: ['USD'] });
  s.ut.upsert('j', { id: 'tr_week01', symbol: 'BTCUSDT', tf: '1h', style: 'swing', direction: 'long', execution: 'market', account: 'spot', asset: 'crypto', status: 'done', entry: 100, stop: 95, risk: 5, targets: [110], rr: [2], createdAt: Math.floor(t0 / 1000) - 3 * 86400, savedAt: t0 - 3 * DAY, updatedAt: t0 - DAY, validUntil: null, filledAt: Math.floor(t0 / 1000) - 3 * 86400, closedAt: Math.floor(t0 / 1000) - 86400, hits: 1, resultR: 2, capital: null, riskPct: null, riskAmount: null, units: null, mode: 'live', costR: 0, tags: [], note: '' });
  const mailsBefore = s.mails.length;
  await s.g.runJobs();
  const nj = s.g.notices('j').items.map((x) => x.kind);
  assert.ok(nj.includes('expiry')); assert.ok(nj.includes('news')); assert.equal(s.g.notices('k').items.filter((x) => x.kind === 'news').length, 0, 'news only for opted-in users');
  assert.ok(s.mails.slice(mailsBefore).some((m) => /تقريرك الأسبوعي/.test(m.subject) && /1 صفقة/.test(m.text)));
  const count = s.g.notices('j').items.length; await s.g.runJobs(); assert.equal(s.g.notices('j').items.length, count, 'nothing sent twice');
});

test('contest: only trades saved on time and judged by the server count; nicknames unique; one prize a month', async () => {
  const s = setup(); const now = s.getT(); const sec = Math.floor(now / 1000);
  for (const uid of ['p1', 'p2']) await s.g.signIn(U(uid, `${uid}@x.co`, 1));
  assert.equal(s.g.contestJoin('p1', 'Falcon').ok, true); assert.equal(s.g.contestJoin('p2', 'falcon').error, 'nick_taken'); s.g.contestJoin('p2', 'Hawk');
  const mk = (uid, i, createdAt) => s.ut.upsert(uid, { id: `tr_${uid}_${i}x`, symbol: 'BTCUSDT', tf: '1h', style: 'swing', direction: 'long', execution: 'market', account: 'spot', asset: 'crypto', status: 'active', entry: 100, stop: 95, risk: 5, targets: [110], rr: [2], createdAt, savedAt: Date.now(), updatedAt: Date.now(), validUntil: null, filledAt: createdAt, closedAt: null, hits: 0, resultR: null, capital: null, riskPct: null, riskAmount: null, units: null, mode: 'live', costR: 0, tags: [], note: '' });
  for (let i = 0; i < 5; i++) { mk('p1', i, Math.floor(Date.now() / 1000)); s.ut.setOutcome('p1', `tr_p1_${i}x`, { status: 'done', hits: 1, filledAt: sec, closedAt: sec, resultR: 2 }); }
  for (let i = 0; i < 5; i++) { mk('p2', i, Math.floor(Date.now() / 1000) - 5 * 86400); s.ut.setOutcome('p2', `tr_p2_${i}x`, { status: 'done', hits: 1, filledAt: sec, closedAt: sec, resultR: 2 }); }   // back-dated: not fair
  // a "done" trade written by the browser itself never counts
  s.ut.upsert('p2', { id: 'tr_fake001', symbol: 'BTCUSDT', tf: '1h', style: 'swing', direction: 'long', execution: 'market', account: 'spot', asset: 'crypto', status: 'done', entry: 100, stop: 95, risk: 5, targets: [110], rr: [9], createdAt: sec, savedAt: now, updatedAt: now, validUntil: null, filledAt: sec, closedAt: sec, hits: 1, resultR: 9, capital: null, riskPct: null, riskAmount: null, units: null, mode: 'live', costR: 0, tags: [], note: '' });
  const lb = s.g.leaderboard('p1');
  assert.equal(lb.ranked.length, 1); assert.equal(lb.ranked[0].nick, 'Falcon'); assert.equal(lb.ranked[0].r, 10); assert.equal(lb.ranked[0].me, true); assert.equal(lb.pending, 1);
  s.access.grant('p1', { product: 'monthly', paymentId: 'pp', startsAt: now, until: now + 10 * DAY }, now);
  assert.equal((await s.g.contestAward(lb.ranked[0].ref, 30)).ok, true); assert.equal((await s.g.contestAward(lb.ranked[0].ref, 30)).error, 'already_awarded');
  assert.equal(Math.round((s.access.subscription('p1', now).until - now) / DAY), 40);
});

test('the site owner is told when a new member signs in (masked e-mail)', async () => {
  const s = setup();
  await s.g.signIn(U('boss', 'boss@x.co', 1), { owner: true });
  await s.g.signIn(U('newbie', 'newbie@mail.com', 1), { device: 'Android · Chrome' });
  const n = s.g.notices('boss').items.find((x) => x.kind === 'newmember');
  assert.ok(n); assert.match(n.body, /ne\*\*\*@mail\.com · Android · Chrome/); assert.equal(n.body.includes('newbie@'), false);
  await s.g.signIn(U('newbie', 'newbie@mail.com', 2)); assert.equal(s.g.notices('boss').items.filter((x) => x.kind === 'newmember').length, 1, 'only for new members');
});
