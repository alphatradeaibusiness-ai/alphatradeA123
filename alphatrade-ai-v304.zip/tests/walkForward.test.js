import test from 'node:test';
import assert from 'node:assert/strict';
import { generateDemoCandles } from '../src/services/market/demo.js';
import { foldStats, tStat, verdictOf, walkForward, MIN_TRADES_TOTAL } from '../src/services/walkForward.js';

const tr = (r, i = 0) => ({ r, points: r, openTime: i });

test('foldStats: totals, win rate and profit factor', () => {
  const s = foldStats([tr(1), tr(1), tr(-1), tr(2)]);
  assert.equal(s.n, 4); assert.equal(s.netR, 3); assert.equal(s.winRate, 75); assert.equal(s.pf, 4);
  assert.equal(foldStats([]).n, 0);
});

test('tStat: zero for tiny/flat samples, positive for a clear edge, negative for a loser', () => {
  assert.equal(tStat([1]), 0);
  assert.equal(tStat([1, 1, 1]), 0);                       // no variance → not claimed as significant
  assert.ok(tStat([1, 2, 1.5, 2, 1, 1.5, 2, 1]) > 2);
  assert.ok(tStat([-1, -2, -1.5, -1, -2]) < 0);
});

test('verdictOf rules', () => {
  const f = (netRs) => netRs.map((netR, k) => ({ k, n: 10, netR }));
  const base = { total: { n: 50, avgR: 0.2 }, tail: { netR: 1 }, t: 2.5 };
  assert.equal(verdictOf({ ...base, total: { n: 10, avgR: 1 }, folds: f([1, 1, 1, 1, 1]) }), 'insufficient');
  assert.equal(verdictOf({ ...base, total: { n: 50, avgR: -0.1 }, folds: f([1, 1, 1, 1, 1]) }), 'negative');
  assert.equal(verdictOf({ ...base, folds: f([3, 2, 1, 2, 1]) }), 'stable');
  assert.equal(verdictOf({ ...base, folds: f([6, -1, -1, 5, -2]) }), 'inconsistent');       // profitable in total, not in most periods
  assert.equal(verdictOf({ ...base, t: 1.2, folds: f([1, 1, 1, 1, 1]) }), 'inconsistent');   // not clearly above chance
  assert.equal(verdictOf({ ...base, tail: { netR: -2 }, folds: f([3, 2, 1, 2, 1]) }), 'inconsistent'); // recent half negative
  assert.ok(MIN_TRADES_TOTAL >= 30);
});

test('walkForward: null for too little data', () => {
  assert.equal(walkForward([], 'classic', {}), null);
  assert.equal(walkForward(Array.from({ length: 100 }, (_, i) => ({ time: i, open: 1, high: 1, low: 1, close: 1 })), 'classic', {}), null);
});

test('walkForward on a long candle series: folds partition every trade, totals match, verdict is valid', () => {
  const cs = generateDemoCandles('BTCUSDT', '1h', 1000);
  const rules = { pointSize: 0.1, volumeKind: 'synthetic', stopMode: 'atr', trendFilter: true, feePct: 0.1, tpGapPts: 0, tp3GapPts: 0 };
  for (const strat of ['classic', 'smc', 'zone']) {
    const r = walkForward(cs, strat, rules);
    assert.ok(r, strat);
    assert.equal(r.folds.length, 5);
    assert.equal(r.folds.reduce((a, f) => a + f.n, 0), r.total.n, `${strat}: every trade falls in exactly one period`);
    assert.ok(['stable', 'inconsistent', 'negative', 'insufficient'].includes(r.verdict));
    if (r.total.n < MIN_TRADES_TOTAL) assert.equal(r.verdict, 'insufficient');
  }
});
