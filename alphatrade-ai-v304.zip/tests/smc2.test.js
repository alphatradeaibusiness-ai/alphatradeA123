import assert from 'node:assert';
import { prepare, detect, evaluate, killZone, aggregate, structureTimeline, WEIGHTS } from '../src/services/smc2.js';
import { backtestSmc } from '../src/services/backtest.js';

// A hand-made textbook long: equal lows → sweep → displacement + FVG → return into the OB → CHoCH + FVG.
function textbook({ sweepClose = 100.4 } = {}) {
  const c = [];
  const push = (o, h, l, cl) => c.push({ time: 1_700_000_000 + c.length * 3600, open: o, high: h, low: l, close: cl, volume: 100 + (c.length % 7) });
  for (let k = 0; k < 100; k++) { const base = 102.6 + 1.1 * Math.sin(k / 3); const o = base; const cl = base + 0.35 * Math.cos(k / 2); push(o, Math.max(o, cl) + 0.3, Math.min(o, cl) - 0.3, cl); }
  c[95] = { ...c[95], low: 100.0 };
  const rows = [
    [103.0, 103.4, 102.6, 102.7], [102.7, 102.9, 102.2, 102.3], [102.3, 102.5, 101.7, 101.8], [101.8, 102.0, 101.2, 101.3], [101.3, 101.6, 100.9, 101.5],
    [101.5, 101.7, 100.02, 100.9], [100.9, 102.0, 100.8, 101.9], [101.9, 102.4, 101.6, 102.2], [102.2, 102.9, 102.0, 102.7], [102.7, 102.8, 102.1, 102.2],
    [102.2, 102.4, 101.7, 101.9], [101.9, 102.1, 101.4, 101.6], [101.6, 101.8, 101.2, 101.3], [101.3, 101.5, 100.8, 100.9], [100.9, 101.1, 100.4, 100.5],
    [100.5, 100.9, 100.3, 100.8], [100.8, 101.0, 100.5, 100.6], [100.6, 100.8, 100.2, 100.3], [100.3, 100.6, 100.1, 100.5], [100.5, 100.6, 100.1, 100.2],
    [100.7, 101.0, 99.8, sweepClose],                 // 120 sweep (wick under both equal lows, closes back above)
    [100.4, 103.2, 100.3, 103.1],                     // 121 displacement, closes above the last high (102.9)
    [103.1, 103.5, 102.9, 103.4], [103.4, 103.8, 103.1, 103.3], [103.3, 103.5, 102.4, 102.6],
    [102.6, 102.8, 100.9, 101.4],                     // 125 returns into the order block
    [101.4, 103.0, 101.3, 102.9],
    [103.0, 104.4, 103.0, 104.2],                     // 127 CHoCH (closes above 103.8) + fair value gap
  ];
  for (const r of rows) push(...r);
  return c;
}

const c = textbook();
const S = prepare(c, { htf: false, killZone: false, minScore: 0 });
const s = detect(S, c.length - 1, 'long');
assert(s, 'textbook setup must be detected');
assert.strictEqual(s.sweep.type, 'equal', 'sweep of equal lows');
assert(s.entry === 104.2 && s.stop < 99.8 && s.risk > 0);
assert.strictEqual(detect(S, c.length - 1, 'short'), null);
// the sweep is mandatory: without it (wick that never closes back inside) there is no setup
assert.strictEqual(detect(prepare(textbook({ sweepClose: 99.9 }), {}), c.length - 1, 'long'), null, 'no sweep → no setup');
// it is a market entry on the confirmation candle, never earlier
for (let i = 100; i < c.length - 1; i++) assert.strictEqual(detect(S, i, 'long'), null, `no setup before confirmation (candle ${i})`);

// scoring: 100-point scale, hard score gate
const ev = evaluate(S, c.length - 1);
assert(ev.setup && ev.setup.score > 0 && ev.setup.score <= 100);
assert.strictEqual(Object.values(WEIGHTS).reduce((a, v) => a + v, 0), 100);
const strict = prepare(c, { htf: false, killZone: false, minScore: 99.9 });
assert.strictEqual(evaluate(strict, c.length - 1).setup, null, 'score below the minimum → no signal');
assert.strictEqual(evaluate(strict, c.length - 1).rejected.reason, 'score');

// kill zones (New York time): 02:00–05:00 London, 07:00–10:00 New York, DST aware
const ts = (iso) => Date.parse(iso) / 1000;
assert.strictEqual(killZone(ts('2026-01-15T08:00:00Z')), 'london');   // 03:00 EST
assert.strictEqual(killZone(ts('2026-07-15T08:00:00Z')), 'london');   // 04:00 EDT
assert.strictEqual(killZone(ts('2026-07-15T12:00:00Z')), 'ny');       // 08:00 EDT
assert.strictEqual(killZone(ts('2026-01-15T12:00:00Z')), 'ny');       // 07:00 EST
assert.strictEqual(killZone(ts('2026-07-15T03:00:00Z')), null);       // Asian session
assert.strictEqual(killZone(ts('2026-07-15T16:00:00Z')), null);

// HTF structure: only closed bars count, no look-ahead
const up = []; for (let k = 0; k < 60; k++) up.push({ time: k * 14400, open: 100 + k, high: 101 + k + (k % 4 === 0 ? 2 : 0), low: 99 + k - (k % 4 === 2 ? 2 : 0), close: 100.5 + k, volume: 1 });
const tl = structureTimeline(up, 14400, 12);
assert.strictEqual(tl(up[59].time + 14400), 'bull');
assert.strictEqual(tl(up[3].time + 14400), null, 'too little history → no bias');
const agg = aggregate(Array.from({ length: 8 }, (_, k) => ({ time: k * 3600, open: 1, high: 2 + k, low: 0, close: 1, volume: 1 })), 14400);
assert.strictEqual(agg.length, 2); assert.strictEqual(agg[0].high, 5);

// backtest: runs, opens at market (no pending), and respects the gates
const r = backtestSmc(c.concat(c.slice(-1)), { stopMode: 'atr', atrMult: 2, tpR: [1, 2, 3.5], pointSize: 1, feePct: 0, smcHtf: false, smcKillZone: false, smcMinScore: 0, openOnLast: true, maxPerDay: 0, minRiskPct: 0 });
assert.strictEqual(r.pending, null);
console.log('smc2 ok');
