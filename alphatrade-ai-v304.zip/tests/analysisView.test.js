import test from 'node:test';
import assert from 'node:assert';
import { bollinger } from '../src/indicators/index.js';
import { analysisSteps, oteBand } from '../src/services/analysisSteps.js';
import { tickerItems, eventMoves, headlineMatches } from '../src/services/newsFeed.js';
import { aviewOn } from '../src/services/aview.js';

test('bollinger: SMA ± 2 population sd, null before the first full window', () => {
  const closes = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  const b = bollinger(closes, 5, 2);
  assert.strictEqual(b.mid[3], null);
  assert.strictEqual(b.mid[4], 3);
  const sd = Math.sqrt(2);   // population sd of 1..5
  assert(Math.abs(b.upper[4] - (3 + 2 * sd)) < 1e-9 && Math.abs(b.lower[4] - (3 - 2 * sd)) < 1e-9);
  const flat = bollinger(new Array(30).fill(10), 20, 2);
  assert.strictEqual(flat.upper[25], 10);
});

test('OTE band: 62%–79% retracement in the direction of the last break', () => {
  const r = { high: 200, low: 100 };
  const bull = oteBand(r, 'bull');   // retrace down from the high
  assert(Math.abs(bull.from - 121) < 1e-9 && Math.abs(bull.to - 138) < 1e-9);
  const bear = oteBand(r, 'bear');
  assert(Math.abs(bear.from - 162) < 1e-9 && Math.abs(bear.to - 179) < 1e-9);
  assert.strictEqual(oteBand(null, 'bull'), null);
  assert.strictEqual(oteBand(r, null), null);
});

const candles = Array.from({ length: 40 }, (_, i) => ({ time: 1_700_000_000 + i * 900, open: 100 + i, high: 101 + i, low: 99 + i, close: 100.5 + i, volume: 1 }));
test('analysis steps: values come from the analysis; missing parts are reported as n/a, never invented', () => {
  const ds = { symbol: 'BTCUSDT', tf: '15m', candles };
  const empty = analysisSteps({ symbol: 'BTCUSDT', mode: 'demo', rsi: [null, 55], plan: null, gate: { rejected: true, blockers: ['htf'] }, strategy: 'classic' }, ds, {});
  assert.deepStrictEqual(empty.map((s) => s.key), ['data', 'structure', 'blocks', 'ict', 'rsi', 'bb', 'plan']);
  assert.strictEqual(empty[0].p.mode, 'demo');
  for (const k of ['structure', 'blocks', 'ict', 'bb', 'plan']) assert.strictEqual(empty.find((s) => s.key === k).status, 'na', k);
  assert.deepStrictEqual(empty.at(-1).p.blockers, ['htf']);
  const full = analysisSteps({
    symbol: 'BTCUSDT', mode: 'live', rsi: [null, 72],
    liq: { trend: 'bull', recentEvents: [{ kind: 'BOS', dir: 'bull', level: 130 }], obs: [{ dir: 'bull', top: 120, bottom: 118, mitigated: false }, { dir: 'bear', top: 1, bottom: 0, mitigated: true }], fvgs: [{}], range: { high: 140, low: 100, eq: 120, zone: 'premium' }, bsl: [{ price: 141 }], ssl: [{ price: 99 }] },
    bb: { upper: new Array(40).fill(150), mid: new Array(40).fill(130), lower: new Array(40).fill(110) },
    plan: { direction: 'long', status: 'pending', entry: 120, stop: 115, targets: [125, 130, 140] }, strategy: 'smc',
  }, ds, { rsi: { overbought: 70, oversold: 30 } });
  const by = Object.fromEntries(full.map((s) => [s.key, s]));
  assert.strictEqual(by.structure.p.kind, 'BOS');
  assert.strictEqual(by.blocks.p.ob, 1);   // the mitigated block is not counted
  assert.strictEqual(by.ict.p.zone, 'premium');
  assert.strictEqual(by.ict.p.bsl, 141);
  assert.strictEqual(by.rsi.p.state, 'over');
  assert.strictEqual(by.bb.p.state, 'upper');   // last closed close 138.5 is inside the 110–150 band, upper half
  assert.deepStrictEqual(by.plan.p.targets, [125, 130, 140]);
});

test('news ticker: only High/Medium events inside the window that move the asset; headlines only when they concern it', () => {
  const now = Date.UTC(2026, 9, 8, 12, 0);
  const ev = (o) => ({ id: o.title, country: 'USD', impact: 'High', time: now + 3600e3, forecast: '', previous: '', actual: '', ...o });
  const events = [ev({ title: 'CPI' }), ev({ title: 'Low one', impact: 'Low' }), ev({ title: 'Too far', time: now + 30 * 3600e3 }), ev({ title: 'Old', time: now - 5 * 3600e3 }), ev({ title: 'EUR rate', country: 'EUR' }), ev({ title: 'Med', impact: 'Medium' })];
  const gold = tickerItems('XAUUSD', events, [], now).map((x) => x.title);
  assert.deepStrictEqual(gold, ['CPI', 'EUR rate', 'Med']);
  assert.deepStrictEqual(tickerItems('BTCUSDT', events, [], now).map((x) => x.title), ['CPI', 'Med']);
  assert.deepStrictEqual(tickerItems('EURUSD', events, [], now).map((x) => x.title), ['CPI', 'EUR rate', 'Med']);
  assert(eventMoves(ev({}), 'US30') && !eventMoves(ev({ country: 'GBP' }), 'US30'));
  const heads = [{ id: 1, title: 'Bitcoin ETF inflows jump' }, { id: 2, title: 'Gold climbs as safe haven demand rises' }, { id: 3, title: 'Local weather report' }];
  assert.deepStrictEqual(tickerItems('BTCUSDT', [], heads, now).map((x) => x.id), [1]);
  assert.deepStrictEqual(tickerItems('XAUUSD', [], heads, now).map((x) => x.id), [2]);
  assert(!headlineMatches('Local weather report', 'XAUUSD'));
  assert.deepStrictEqual(tickerItems('XAUUSD', null, null, now), []);
});

test('full-analysis view never applies on the EDH chart', () => {
  assert(aviewOn({ aview: true, strategy: 'smc' }));
  assert(!aviewOn({ aview: true, strategy: 'edh' }));
  assert(!aviewOn({ aview: false, strategy: 'smc' }));
});

import { reviewContext } from '../src/services/ai/reviewContext.js';
import { analyzeTrades } from '../src/services/tradeInsights.js';
test('review context: only computed statistics, nothing raw; empty input gives null', () => {
  assert.strictEqual(reviewContext(null), null);
  const trades = Array.from({ length: 24 }, (_, i) => ({ r: i % 3 === 0 ? -1 : 1.5, closeTime: 1_700_000_000_000 + i * 3_600_000, symbol: 'BTCUSDT', direction: i % 2 ? 'long' : 'short', hits: i % 3 === 0 ? 0 : 3, note: 'SECRET NOTE' }));
  const ctx = reviewContext(analyzeTrades(trades), { source: 'journal' });
  assert.strictEqual(ctx.overall.n, 24);
  assert(Number.isFinite(ctx.overall.avgR) && Number.isFinite(ctx.overall.maxDrawdownR));
  assert(!JSON.stringify(ctx).includes('SECRET'));
  assert(ctx.strengths.length <= 4 && ctx.weaknesses.length <= 4);
});
