// /api/me/phone: sign-in needed, the site's Origin needed, strict server-side validation, one account never sees another's number.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';

test('server: /api/me/phone re-validates every number and keeps it per account', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-ph';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'google.com' } }));
    return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'phsrv-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'b'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: certFile }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, t, bridge, origin = true } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : JSON.stringify(body);
    const headers = { ...(method !== 'GET' && origin ? { origin: O } : {}), ...(d ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}), ...(bridge ? { 'x-bridge-token': bridge } : {}) };
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => { let j = null; try { j = JSON.parse(s); } catch { /* text */ } resolve({ status: res.statusCode, body: j, text: s }); }); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  try {
    for (let i = 0; i < 80; i++) { try { if ((await req('/api/health')).status === 200) break; } catch { /* starting */ } await new Promise((r) => setTimeout(r, 100)); }
    const me = tok('p1', 'p1@example.com'); const other = tok('p2', 'p2@example.com');
    assert.equal((await req('/api/me/phone')).status, 401);
    assert.equal((await req('/api/me/phone', { method: 'PUT', t: me, origin: false, body: { phone: '+962791234567', country: 'JO' } })).status, 403, 'writes need the site Origin');
    for (const [phone, country, code] of [['+96279123', 'JO', 'phone_short'], ['+962791234567', 'IL', 'phone_prefix'], ['<script>', 'JO', 'phone_format'], ['+962811234567', 'JO', 'phone_format'], [123, 'JO', 'phone_format'], ['0791234567', 'JO', 'phone_format'], ['+962791234567', 'XX', 'phone_country']]) {
      const r = await req('/api/me/phone', { method: 'PUT', t: me, body: { phone, country } });
      assert.equal(r.status, 400, `${phone} ${country}`); assert.equal(r.body.code, code, `${phone} ${country}`);
    }
    const ok = await req('/api/me/phone', { method: 'PUT', t: me, body: { phone: '+962791234567', country: 'JO' } });
    assert.equal(ok.status, 200);
    assert.equal((await req('/api/me/phone', { t: me })).body.phone.e164, '+962791234567');
    assert.equal((await req('/api/me/phone', { t: other })).body.phone, null, 'another account sees nothing');
    const big = await req('/api/me/phone', { method: 'PUT', t: me, body: { phone: '1'.repeat(2000), country: 'JO' } }).catch((e) => ({ status: e.code }));
    assert.ok([400, 413, 'ECONNRESET', 'EPIPE'].includes(big.status), 'oversized body refused');
    assert.equal((await req('/api/me/phone', { t: me })).body.phone.e164, '+962791234567', 'unchanged');
  } finally { child.kill(); }
});
