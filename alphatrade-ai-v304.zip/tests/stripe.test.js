import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { createChannelAccess } from '../server/channelAccess.js';
import { createStripeBilling, verifySignature, CATALOGUE } from '../server/stripe.js';

const WH = 'whsec_testsecret0123456789abcdef';
const sign = (raw, t = Math.floor(Date.now() / 1000), secret = WH) => `t=${t},v1=${crypto.createHmac('sha256', secret).update(`${t}.${raw}`).digest('hex')}`;
const ENV = { STRIPE_SECRET_KEY: 'sk_test_abcdefghijklmnop123', STRIPE_WEBHOOK_SECRET: WH };
const session = (o = {}) => ({ id: `cs_test_${crypto.randomBytes(6).toString('hex')}`, object: 'checkout.session', mode: 'payment', payment_status: 'paid', client_reference_id: 'u1', metadata: { uid: 'u1', product: 'quarterly' }, currency: 'usd', amount_total: CATALOGUE.quarterly.cents, ...o });
const event = (s, o = {}) => JSON.stringify({ id: 'evt_1', type: 'checkout.session.completed', livemode: false, data: { object: s }, ...o });

test('signature: right secret and fresh time only', () => {
  const raw = '{"a":1}';
  assert.equal(verifySignature(Buffer.from(raw), sign(raw), WH), true);
  assert.equal(verifySignature(Buffer.from(raw), sign(raw, undefined, 'whsec_other0000000000'), WH), false);
  assert.equal(verifySignature(Buffer.from('{"a":2}'), sign(raw), WH), false);
  assert.equal(verifySignature(Buffer.from(raw), sign(raw, Math.floor(Date.now() / 1000) - 600), WH), false, 'replayed old event');
  assert.equal(verifySignature(Buffer.from(raw), undefined, WH), false);
});

test('webhook: paid session grants the plan once; same plan adds months; wrong amount, unpaid, test-in-live are refused', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'st-')); const access = createChannelAccess(dir);
  const b = createStripeBilling({ env: ENV, access, log: { error() {} } });
  assert.equal(b.configured, true);
  const off = createStripeBilling({ env: {}, access });
  assert.equal(off.configured, false); assert.equal((await off.webhook(Buffer.from('{}'), '')).status, 503);
  const s1 = session(); const raw = event(s1);
  assert.equal((await b.webhook(Buffer.from(raw), 'bad')).status, 400);
  let r = await b.webhook(Buffer.from(raw), sign(raw)); assert.equal(r.body.result, 'granted');
  const sub = access.subscription('u1'); assert.equal(sub.product, 'quarterly');
  const days = (sub.until - Date.now()) / 86_400_000; assert.ok(days > 90 && days < 92, String(days));
  r = await b.webhook(Buffer.from(raw), sign(raw)); assert.equal(r.body.result, 'duplicate', 'Stripe retries never double-grant');
  r = await b.webhook(Buffer.from(event(session())), sign(event(session())));   // signature over a different body
  assert.equal(r.status, 400);
  const s2 = session(); const raw2 = event(s2);
  assert.equal((await b.webhook(Buffer.from(raw2), sign(raw2))).body.result, 'granted');
  const days2 = (access.subscription('u1').until - Date.now()) / 86_400_000; assert.ok(days2 > 181 && days2 < 184, String(days2));
  const cheap = event(session({ amount_total: 100 })); assert.equal((await b.webhook(Buffer.from(cheap), sign(cheap))).body.result, 'amount_mismatch');
  const unpaid = event(session({ payment_status: 'unpaid' })); assert.equal((await b.webhook(Buffer.from(unpaid), sign(unpaid))).body.result, 'unpaid');
  const other = event(session({ metadata: { uid: 'u2', product: 'quarterly' } })); assert.equal((await b.webhook(Buffer.from(other), sign(other))).body.result, 'bad_session');
  const live = createStripeBilling({ env: { ...ENV, STRIPE_SECRET_KEY: 'sk_live_abcdefghijklmnop123' }, access });
  const tst = event(session()); assert.equal((await live.webhook(Buffer.from(tst), sign(tst))).body.result, 'wrong_mode');
  // add-on needs an active plan; then counts
  const add = event(session({ client_reference_id: 'u3', metadata: { uid: 'u3', product: 'signals50' }, amount_total: CATALOGUE.signals50.cents }));
  assert.match((await b.webhook(Buffer.from(add), sign(add))).body.result, /^error:active_subscription_required/);
  assert.equal((await b.webhook(Buffer.from(add), sign(add))).status, 500, 'Stripe will retry');
});

test('checkout: the server sets the price; add-ons need a plan', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'st2-')); const access = createChannelAccess(dir);
  let seen;
  const fetchFn = async (url, o) => { seen = { url, body: new URLSearchParams(o.body), auth: o.headers.authorization }; return { ok: true, json: async () => ({ url: 'https://checkout.stripe.com/c/pay/cs_test_1' }) }; };
  const b = createStripeBilling({ env: ENV, access, fetchFn, api: 'http://stripe.local' });
  const r = await b.checkout({ uid: 'u9', email: 'a@b.co', product: 'annual', origin: 'https://site.example' });
  assert.equal(r.status, 200); assert.equal(r.body.url, 'https://checkout.stripe.com/c/pay/cs_test_1');
  assert.equal(seen.url, 'http://stripe.local/v1/checkout/sessions'); assert.equal(seen.auth, `Bearer ${ENV.STRIPE_SECRET_KEY}`);
  assert.equal(seen.body.get('line_items[0][price_data][unit_amount]'), '65000');
  assert.equal(seen.body.get('line_items[0][quantity]'), '1');
  assert.equal(seen.body.get('client_reference_id'), 'u9'); assert.equal(seen.body.get('metadata[product]'), 'annual');
  assert.equal(seen.body.get('success_url'), 'https://site.example/#/app/pricing?paid=1');
  assert.equal((await b.checkout({ uid: 'u9', product: 'free-stuff', origin: 'https://site.example' })).status, 400);
  assert.equal((await b.checkout({ uid: 'u9', product: 'signals25', origin: 'https://site.example' })).body.code, 'active_subscription_required');
});

test('server: /api/billing routes (status, webhook without Origin, checkout needs sign-in)', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'st3-'));
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: 'p', ...ENV }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, headers = {} } = {}) => new Promise((resolve, reject) => {
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { ...(body ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(body) } : {}), ...headers } }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(s || 'null') })); });
    r.on('error', reject); if (body) r.write(body); r.end();
  });
  try {
    let st; for (let i = 0; i < 80; i++) { try { st = await req('/api/billing/status'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    assert.deepEqual([st.status, st.body.configured, st.body.mode], [200, true, 'test']);
    assert.equal(JSON.stringify(st.body).includes('sk_test'), false);
    const raw = event(session({ client_reference_id: 'zz', metadata: { uid: 'zz', product: 'monthly' }, amount_total: 8000 }));
    const w = await req('/api/billing/webhook', { method: 'POST', body: raw, headers: { 'stripe-signature': sign(raw) } });
    assert.equal(w.status, 200); assert.equal(w.body.result, 'granted');
    assert.equal(JSON.parse(fs.readFileSync(path.join(dir, 'channel-accounts.json'), 'utf8')).zz.subscription.product, 'monthly');
    assert.equal((await req('/api/billing/webhook', { method: 'POST', body: raw, headers: { 'stripe-signature': 't=1,v1=00' } })).status, 400);
    assert.equal((await req('/api/billing/checkout', { method: 'POST', body: '{"product":"monthly"}', headers: { origin: `http://127.0.0.1:${port}` } })).status, 401);
  } finally { child.kill(); }
});

test('owner pastes one Stripe key on the site: webhook is created, both secrets stored encrypted, payments work, others are refused', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-pay';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'password' } }));
    return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'st4-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  // mock Stripe API
  const calls = []; const SEC = 'whsec_fromstripe0123456789abcdef';
  const mock = http.createServer((q, r) => { let b = ''; q.on('data', (c) => (b += c)); q.on('end', () => {
    calls.push({ m: q.method, url: q.url, auth: q.headers.authorization, body: new URLSearchParams(b) });
    r.writeHead(q.headers.authorization === 'Bearer sk_test_wrongkey000000000' ? 401 : 200, { 'content-type': 'application/json' });
    r.end(JSON.stringify(q.url === '/v1/webhook_endpoints' ? { id: `we_${calls.length}`, secret: SEC } : { url: 'https://checkout.stripe.com/c/pay/x' })); }); });
  await new Promise((ok) => mock.listen(0, ok)); const mp = mock.address().port;
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: certFile, STRIPE_TEST_API: `http://127.0.0.1:${mp}`, STRIPE_SECRET_KEY: '', STRIPE_WEBHOOK_SECRET: '', PUBLIC_URL: 'https://shop.example' }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, t, origin = O, headers = {} } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : typeof body === 'string' ? body : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { ...(origin && method !== 'GET' ? { origin } : {}), ...(d ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}), ...headers } }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(s || 'null') })); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  const owner = tok('own', 'shheahmad417@gmail.com'); const bob = tok('bob', 'bob@example.com');
  try {
    for (let i = 0; i < 80; i++) { try { await req('/api/billing/status'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    assert.equal((await req('/api/billing/status')).body.configured, false);
    assert.equal((await req('/api/billing/config', { t: bob })).status, 403);
    assert.equal((await req('/api/billing/config', { method: 'PUT', t: bob, body: { secretKey: 'sk_test_abcdefghijklmnop' } })).status, 403);
    assert.equal((await req('/api/billing/config', { method: 'PUT', t: owner, body: { secretKey: 'pk_test_abcdefghijklmnop' } })).body.code, 'publishable_key');
    const bad = await req('/api/billing/config', { method: 'PUT', t: owner, body: { secretKey: 'sk_test_wrongkey000000000' } });
    assert.equal(bad.body.ok, false); assert.equal(bad.body.code, 'invalid_key');
    const good = await req('/api/billing/config', { method: 'PUT', t: owner, body: { secretKey: 'sk_test_goodkey1234567890' } });
    assert.equal(good.body.ok, true); assert.equal(good.body.status.configured, true); assert.equal(good.body.status.mode, 'test'); assert.equal(good.body.status.last4, '7890');
    const wh = calls.find((c) => c.url === '/v1/webhook_endpoints');
    assert.equal(wh.body.get('url'), 'https://shop.example/api/billing/webhook'); assert.equal(wh.body.get('enabled_events[0]'), 'checkout.session.completed');
    const file = fs.readFileSync(path.join(dir, 'billing-config.json'), 'utf8');
    assert.equal(/sk_test_goodkey|whsec_fromstripe/.test(file), false, 'stored encrypted');
    assert.equal(JSON.stringify((await req('/api/billing/config', { t: owner })).body).includes('sk_test'), false, 'never sent back');
    // the stored webhook secret verifies Stripe events
    const raw = JSON.stringify({ type: 'checkout.session.completed', livemode: false, data: { object: { id: 'cs_test_x1', object: 'checkout.session', mode: 'payment', payment_status: 'paid', client_reference_id: 'bob', metadata: { uid: 'bob', product: 'monthly' }, currency: 'usd', amount_total: 8000 } } });
    assert.equal((await req('/api/billing/webhook', { method: 'POST', body: raw, origin: null, headers: { 'stripe-signature': sign(raw, undefined, SEC) } })).body.result, 'granted');
    const co = await req('/api/billing/checkout', { method: 'POST', t: bob, body: { product: 'annual' } });
    assert.equal(co.body.url, 'https://checkout.stripe.com/c/pay/x');
    // replacing deletes the old webhook; disconnect removes everything
    await req('/api/billing/config', { method: 'PUT', t: owner, body: { secretKey: 'sk_test_goodkey1234567891' } });
    assert.ok(calls.some((c) => c.m === 'DELETE' && /^\/v1\/webhook_endpoints\/we_/.test(c.url)));
    assert.equal((await req('/api/billing/config', { method: 'DELETE', t: owner })).body.configured, false);
    assert.equal(fs.existsSync(path.join(dir, 'billing-config.json')), false);
  } finally { child.kill(); mock.close(); }
});
