// The bank over HTTP, against the real server: auth, isolation, step-up, idempotency, admin separation, SSE, no data leaks.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

const PROJECT = 'alphatrade-test'; const KID = 'k-bank';
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
function token({ uid = 'owner-uid', email = 'shheahmad417@gmail.com', verified = true, authAgoSec = 10, mfa = false } = {}) {
  const now = Math.floor(Date.now() / 1000);
  const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
  const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: now - 10, auth_time: now - authAgoSec, exp: now + 3600, email, email_verified: verified, firebase: { sign_in_provider: 'google.com', ...(mfa ? { sign_in_second_factor: 'phone' } : {}) } }));
  return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), privateKey))}`;
}
const certs = { [KID]: publicKey.export({ type: 'spki', format: 'pem' }) };
function call(port, p, { method = 'GET', tok, body, headers = {}, raw } = {}) {
  return new Promise((resolve, reject) => {
    const data = raw ?? (body === undefined ? null : JSON.stringify(body));
    const h = { origin: `http://127.0.0.1:${port}`, ...(data ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data) } : {}), ...(tok ? { authorization: `Bearer ${tok}` } : {}), ...headers };
    for (const k of Object.keys(h)) if (h[k] === null) delete h[k];   // null = do not send this header
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: h }, (res) => {
      let buf = ''; res.on('data', (c) => (buf += c)); res.on('end', () => { let j = null; try { j = JSON.parse(buf); } catch { /* not json */ } resolve({ status: res.statusCode, body: j, raw: buf, headers: res.headers }); });
    });
    r.on('error', reject); if (data) r.write(data); r.end();
  });
}
async function startServer(env) {
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; child.stdout.on('data', (c) => (log += c)); child.stderr.on('data', (c) => (log += c));
  for (let i = 0; i < 80; i++) { try { await call(port, '/api/bank/status'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
  return { port, child, log: () => log };
}
const GOOD_IBAN = 'DE89370400440532013000';
const KYC = { tier: 1, fullName: 'Ada Lovelace', dob: '1990-05-05', nationality: 'DE', address: { country: 'DE', region: 'BE', city: 'Berlin', postal: '10115', line1: 'Invalidenstrasse 1' }, idType: 'passport', idNumber: 'C01X00T47', idExpiry: '2031-01-01' };
let seq = 0; const key = () => `idem-${Date.now()}-${seq++}`;

test('bank is off (503) without BANK_MASTER_KEY and never exposes anything', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk0-'));
  const { port, child } = await startServer({ BANK_MASTER_KEY: '', SERVER_DATA_DIR: dir });
  try { const r = await call(port, '/api/bank/wallet'); assert.equal(r.status, 503); assert.equal(r.body.code, 'bank_disabled'); }
  finally { child.kill(); fs.rmSync(dir, { recursive: true, force: true }); }
});

test('sandbox bank end to end over HTTP: auth, isolation, KYC, wallet, withdrawal, admin separation, no leaks', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk1-')); const certFile = path.join(dir, 'certs.json'); fs.writeFileSync(certFile, JSON.stringify(certs));
  const { port, child, log } = await startServer({ BANK_MASTER_KEY: 'm'.repeat(48), BANK_MODE: 'sandbox', AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), ANTHROPIC_API_KEY: '', AI_IP_PER_MINUTE: '1000', AI_DAILY_PER_IP: '1000', AI_DAILY_LIMIT: '1000' });
  const owner = token(); const alice = token({ uid: 'alice', email: 'alice@example.com' }); const bob = token({ uid: 'bob', email: 'bob@example.com' });
  const unverified = token({ uid: 'eve', email: 'eve@example.com', verified: false });
  const all = []; const c = async (p, o) => { const r = await call(port, p, o); if (o?.tok !== owner) all.push(r.raw); return r; };   // responses seen by non-admins
  try {
    assert.equal((await c('/api/bank/status')).body.mode, 'sandbox');
    assert.equal((await c('/api/bank/wallet')).status, 401);                                             // no token
    assert.equal((await c('/api/bank/wallet', { tok: 'garbage.token.here' })).status, 401);
    assert.equal((await c('/api/bank/wallet', { tok: unverified })).status, 403);                        // email not verified
    assert.equal((await call(port, '/api/bank/wallet', { tok: alice, headers: { origin: 'https://evil.example' } })).status, 403);   // foreign origin
    // a same-origin browser GET carries no Origin header: allowed (the bearer token is the guard); a cross-site one is not
    assert.equal((await call(port, '/api/bank/wallet', { tok: alice, headers: { origin: null } })).status, 200);
    assert.equal((await call(port, '/api/bank/wallet', { tok: alice, headers: { origin: null, 'sec-fetch-site': 'cross-site' } })).status, 403);
    // writes always need an allowed Origin
    assert.equal((await call(port, '/api/bank/sandbox/fund', { method: 'POST', tok: alice, body: { currency: 'USD', amount: '5', idem: 'no-origin-1' }, headers: { origin: null } })).status, 403);
    assert.equal((await call(port, '/api/bank/sandbox/fund', { method: 'POST', tok: alice, body: { currency: 'USD', amount: '5', idem: 'evil-1' }, headers: { origin: 'https://evil.example' } })).status, 403);
    const w0 = (await c('/api/bank/wallet', { tok: alice })).body; assert.equal(w0.wallets.find((w) => w.currency === 'USD').available, 0); assert.equal(w0.kyc.tier, 0);

    // test funds need an idempotency key; a retry does not double-credit
    assert.equal((await c('/api/bank/sandbox/fund', { method: 'POST', tok: alice, body: { currency: 'USD', amount: '3000' } })).body.code, 'idempotency_key_required');
    const k1 = key(); const f = { method: 'POST', tok: alice, body: { currency: 'USD', amount: '3000' }, headers: { 'idempotency-key': k1 } };
    assert.equal((await c('/api/bank/sandbox/fund', f)).status, 200); assert.equal((await c('/api/bank/sandbox/fund', f)).body.replay, true);
    assert.equal((await c('/api/bank/wallet', { tok: alice })).body.wallets.find((w) => w.currency === 'USD').available, 300000);
    assert.equal((await c('/api/bank/wallet', { tok: bob })).body.wallets.find((w) => w.currency === 'USD').available, 0);   // isolation
    assert.equal((await c('/api/bank/history', { tok: bob })).body.items.length, 0);
    assert.equal((await c('/api/bank/sandbox/fund', { method: 'POST', tok: alice, raw: '{bad', headers: { 'idempotency-key': key() } })).body.code, 'bad_json');
    assert.equal((await call(port, '/api/bank/sandbox/fund', { method: 'POST', tok: alice, raw: 'x=1', headers: { 'content-type': 'text/plain', 'idempotency-key': key() } })).status, 415);
    { const r = await c('/api/bank/sandbox/fund', { method: 'POST', tok: alice, raw: JSON.stringify({ currency: 'USD', amount: '1', pad: 'x'.repeat(20000) }), headers: { 'idempotency-key': key() } }).catch((e) => ({ status: 'closed', e })); assert.ok(r.status === 413 || r.status === 'closed', String(r.status)); }   // oversize body: refused, connection dropped

    // KYC: submit, owner reviews (owner may not review themselves), personal data never leaks back to the user
    assert.equal((await c('/api/bank/kyc', { method: 'POST', tok: alice, body: KYC })).status, 200);
    const st = (await c('/api/bank/kyc', { tok: alice })).body; assert.equal(st.status, 'pending'); assert.ok(!JSON.stringify(st).includes('Lovelace'));
    assert.equal((await c('/api/bank/admin/queue', { tok: alice })).status, 403);                        // not the owner
    assert.equal((await c('/api/bank/admin/kyc/alice/approve', { method: 'POST', tok: bob, body: {} })).status, 403);
    const q = (await c('/api/bank/admin/queue', { tok: owner })).body; assert.equal(q.kyc[0].uid, 'alice'); assert.equal(q.ledger.ok, true); assert.equal(q.audit.ok, true);
    assert.equal((await c('/api/bank/admin/kyc/alice', { tok: owner })).body.fullName, 'Ada Lovelace');
    assert.equal((await c('/api/bank/admin/kyc/alice/approve', { method: 'POST', tok: owner, body: {} })).body.tier, 1);

    // beneficiary → cooling off → withdrawal needs the 24h wait: refused now
    const ben = (await c('/api/bank/beneficiaries', { method: 'POST', tok: alice, body: { currency: 'USD', label: 'Main', iban: GOOD_IBAN, holder: 'Ada Lovelace' } })).body;
    assert.equal(ben.last4, '3000'); assert.ok(!JSON.stringify((await c('/api/bank/beneficiaries', { tok: alice })).body).includes('DE89'));
    assert.equal((await c('/api/bank/beneficiaries', { tok: bob })).body.items.length, 0);
    const wd = await c('/api/bank/withdrawals', { method: 'POST', tok: alice, body: { currency: 'USD', amount: '100', beneficiaryId: ben.id }, headers: { 'idempotency-key': key() } });
    assert.equal(wd.body.code, 'beneficiary_cooling_off');
    assert.equal((await c(`/api/bank/beneficiaries/${ben.id}`, { method: 'DELETE', tok: bob })).body.code, 'not_found');   // another user's id

    // the owner has their own wallet too, and cannot approve their own withdrawal (separation of duties)
    assert.equal((await c('/api/bank/admin/withdrawals/wd_x/approve', { method: 'POST', tok: owner, body: {} })).body.code, 'not_found');

    // plans, cards need KYC tier 2
    assert.equal((await c('/api/bank/cards', { method: 'POST', tok: alice, body: { product: 'virtual' }, headers: { 'idempotency-key': key() } })).body.code, 'kyc_required');
    const plan = await c('/api/bank/plans', { method: 'POST', tok: alice, body: { asset: 'BTC', amount: '20', every: 'daily' } }); assert.equal(plan.body.mode, 'paper');
    assert.equal((await c('/api/bank/plans', { tok: bob })).body.items.length, 0);
    assert.equal((await c(`/api/bank/plans/${plan.body.id}/delete`, { method: 'POST', tok: bob, body: {} })).body.code, 'not_found');

    // history shows the credit with its effect; a bad cursor / limit cannot break the query
    assert.equal((await c('/api/bank/history?limit=1000&before=%27%3B%20DROP%20TABLE%20txns%3B--', { tok: alice })).status, 200);   // hostile cursor: parameters are bound, nothing runs
    const h = (await c('/api/bank/history?limit=1000', { tok: alice })).body; assert.equal(h.items[0].type, 'sandbox_credit'); assert.equal(h.items[0].effect, 300000);
    assert.equal((await c('/api/bank/nonsense', { tok: alice })).status, 404);

    // chain + ledger intact; responses and log carry no personal data or secrets
    const v = (await c('/api/bank/admin/verify', { tok: owner })).body; assert.equal(v.ledger.ok, true); assert.equal(v.audit.ok, true);
    const audit = JSON.stringify((await c('/api/bank/admin/audit', { tok: owner })).body); assert.ok(audit.includes('kyc.submit') && audit.includes('kyc.view') && !audit.includes('Lovelace') && !audit.includes('DE8937'));
    assert.ok(!all.join('').includes('C01X00T47') && !all.join('').includes('Lovelace') && !all.join('').includes(GOOD_IBAN), 'personal data leaked to a non-admin response');
    assert.ok(!log().includes('Lovelace') && !log().includes('C01X00T47') && !log().includes(GOOD_IBAN) && !log().includes('m'.repeat(48)), 'personal data or the master key reached the log');
    assert.equal(fs.readdirSync(path.join(dir, 'bank')).some((f) => f.startsWith('bank.db')), true);
    const dbBytes = fs.readFileSync(path.join(dir, 'bank', 'bank.db')).toString('latin1') + (fs.existsSync(path.join(dir, 'bank', 'bank.db-wal')) ? fs.readFileSync(path.join(dir, 'bank', 'bank.db-wal')).toString('latin1') : '');
    assert.ok(!dbBytes.includes('Lovelace') && !dbBytes.includes('C01X00T47') && !dbBytes.includes('Invalidenstrasse') && !dbBytes.includes(GOOD_IBAN), 'personal data stored unencrypted');
  } finally { child.kill(); fs.rmSync(dir, { recursive: true, force: true }); }
});

test('live mode: step-up (recent sign-in + second factor), no test funds, owner confirms deposits, full withdrawal lifecycle', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk2-')); const certFile = path.join(dir, 'certs.json'); fs.writeFileSync(certFile, JSON.stringify(certs));
  const { port, child } = await startServer({ BANK_MASTER_KEY: 'm'.repeat(48), BANK_MODE: 'live', BANK_REAUTH_MINUTES: '', BANK_REQUIRE_MFA: '', AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), AI_IP_PER_MINUTE: '1000', AI_DAILY_PER_IP: '1000', AI_DAILY_LIMIT: '1000' });
  const ownerMfa = token({ mfa: true }); const stale = token({ uid: 'alice', email: 'alice@example.com', authAgoSec: 3600, mfa: true });
  const noMfa = token({ uid: 'alice', email: 'alice@example.com' }); const good = token({ uid: 'alice', email: 'alice@example.com', mfa: true });
  const c = (p, o) => call(port, p, o);
  try {
    assert.equal((await c('/api/bank/status')).body.mode, 'live');
    // compose passes empty strings for unset variables: they must mean the safe live defaults, not "off"
    { const st = (await c('/api/bank/status')).body; assert.equal(st.reauthMinutes, 15); assert.equal(st.mfaRequired, true); }
    assert.equal((await c('/api/bank/sandbox/fund', { method: 'POST', tok: good, body: { currency: 'USD', amount: '10' }, headers: { 'idempotency-key': key() } })).body.code, 'not_available');
    assert.equal((await c('/api/bank/kyc', { method: 'POST', tok: stale, body: KYC })).body.code, 'reauth_required');   // signed in an hour ago
    assert.equal((await c('/api/bank/kyc', { method: 'POST', tok: noMfa, body: KYC })).body.code, 'mfa_required');
    assert.equal((await c('/api/bank/kyc', { method: 'POST', tok: good, body: KYC })).status, 200);
    assert.equal((await c('/api/bank/admin/queue', { tok: noMfa })).status, 403);   // non-owner
    assert.equal((await c('/api/bank/admin/queue', { tok: token() })).body.code, 'mfa_required');   // the owner needs the second factor too
    assert.equal((await c('/api/bank/admin/kyc/alice/approve', { method: 'POST', tok: ownerMfa, body: {} })).status, 200);
    const dep = (await c('/api/bank/deposits', { method: 'POST', tok: good, body: { currency: 'USD', amount: '500' }, headers: { 'idempotency-key': key() } })).body;
    assert.equal(dep.instructions, 'not_configured');                                    // no bank details invented
    assert.equal((await c('/api/bank/wallet', { tok: good })).body.wallets.find((w) => w.currency === 'USD').available, 0);
    assert.equal((await c(`/api/bank/admin/deposits/${dep.id}/confirm`, { method: 'POST', tok: ownerMfa, body: { extRef: 'BANK-STMT-0001' } })).status, 200);
    assert.equal((await c('/api/bank/wallet', { tok: good })).body.wallets.find((w) => w.currency === 'USD').available, 50000);
    // a second owner-style identity (another verified admin) is needed to approve the owner's own money; here: a normal user's withdrawal
    const ben = (await c('/api/bank/beneficiaries', { method: 'POST', tok: good, body: { currency: 'USD', label: 'Main', iban: GOOD_IBAN, holder: 'Ada L' } })).body;
    assert.equal(ben.status, 'active'); assert.ok(ben.usableAfter > Date.now() + 23 * 3600_000);   // 24 h cooling-off in live mode
    assert.equal((await c('/api/bank/withdrawals', { method: 'POST', tok: good, body: { currency: 'USD', amount: '50', beneficiaryId: ben.id }, headers: { 'idempotency-key': key() } })).body.code, 'beneficiary_cooling_off');
    assert.equal((await c('/api/bank/withdrawals', { method: 'POST', tok: good, body: { currency: 'USD', amount: '50', beneficiaryId: ben.id } })).body.code, 'idempotency_key_required');
  } finally { child.kill(); fs.rmSync(dir, { recursive: true, force: true }); }
});

test('live-stream: balance events arrive in real time and only for the signed-in user', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk3-')); const certFile = path.join(dir, 'certs.json'); fs.writeFileSync(certFile, JSON.stringify(certs));
  const { port, child } = await startServer({ BANK_MASTER_KEY: 'm'.repeat(48), BANK_MODE: 'sandbox', AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40) });
  const alice = token({ uid: 'alice', email: 'alice@example.com' }); const bob = token({ uid: 'bob', email: 'bob@example.com' });
  const events = (tok) => new Promise((resolve) => {
    const out = []; const r = http.request({ host: '127.0.0.1', port, path: '/api/bank/stream', headers: { origin: `http://127.0.0.1:${port}`, authorization: `Bearer ${tok}` } }, (res) => {
      assert.match(res.headers['content-type'], /text\/event-stream/); res.on('data', (d) => out.push(String(d)));
    }); r.end(); setTimeout(() => { r.destroy(); resolve(out.join('')); }, 1500);
  });
  try {
    const pa = events(alice); const pb = events(bob); await new Promise((r) => setTimeout(r, 400));
    await call(port, '/api/bank/sandbox/fund', { method: 'POST', tok: alice, body: { currency: 'USD', amount: '10' }, headers: { 'idempotency-key': key() } });
    const [a, b] = await Promise.all([pa, pb]);
    assert.equal((a.match(/event: balance/g) || []).length, 2);   // connect + the credit
    assert.equal((b.match(/event: balance/g) || []).length, 1);   // bob only got his own connect event
    assert.equal((await call(port, '/api/bank/stream')).status, 401);
  } finally { child.kill(); fs.rmSync(dir, { recursive: true, force: true }); }
});
