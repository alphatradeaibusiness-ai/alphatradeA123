// v280 voice call with an AI mentor: spoken text cleanup, per-mentor voice, server short-answer mode, page wiring.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
function fakeBrowser(script) {
  let round = 0; const spoken = [];
  class Rec { start() { const w = script[round++] ?? 'silence'; setTimeout(() => { if (w !== 'silence') this.onresult?.({ resultIndex: 0, results: [Object.assign([{ transcript: w }], { isFinal: true })] }); this.onend?.(); }, 1); } stop() { this.onend?.(); } }
  const voices = [{ lang: 'ar-SA', name: 'A' }, { lang: 'ar-EG', name: 'B' }, { lang: 'en-US', name: 'E' }];
  globalThis.window = { SpeechRecognition: Rec, speechSynthesis: {} };
  globalThis.speechSynthesis = { cancel() {}, getVoices: () => voices, speak(u) { spoken.push(u); setTimeout(() => u.onend?.(), 1); } };
  globalThis.SpeechSynthesisUtterance = class { constructor(t) { this.text = t; } };
  return { spoken };
}
const load = () => import(`../src/services/voice.js?${Math.random()}`);

test('spokenText strips markdown, links, bullets and emoji', async () => {
  fakeBrowser([]); const { spokenText } = await load();
  assert.equal(spokenText('**الذهب** _فوق_ الدعم 🚀\n- نقطة أولى\n# عنوان\nشوف https://x.com/a هون'), 'الذهب فوق الدعم\nنقطة أولى\nعنوان\nشوف هون');
  assert.equal(spokenText('```js\ncode\n``` done'), 'done');
});

test('conversation speaks with the mentor voice options (pitch, rate, chosen device voice)', async () => {
  const { spoken } = fakeBrowser(['سلام']); const { conversation } = await load();
  const c = conversation(() => 'ar', { voice: { pitch: 0.8, rate: 0.9, pick: 1 }, onAsk: async () => 'أهلين' });
  await wait(60); c.stop();
  assert.equal(spoken[0].text, 'أهلين'); assert.equal(spoken[0].pitch, 0.8); assert.equal(spoken[0].rate, 0.9); assert.equal(spoken[0].voice.name, 'B');
});

test('speak without options keeps the old defaults', async () => {
  const { spoken } = fakeBrowser([]); const { speak } = await load();
  speak('hi', 'en'); assert.equal(spoken[0].pitch, 1); assert.equal(spoken[0].rate, 1); assert.equal(spoken[0].voice.name, 'E');
});

test('server: mentor voice mode asks for short spoken answers, text mode unchanged', () => {
  const s = fs.readFileSync(new URL('../server/index.js', import.meta.url), 'utf8');
  assert.match(s, /const voice = p\.voice === true;/);
  assert.match(s, /LIVE VOICE CALL/); assert.match(s, /maxTokens: voice \? 350 : 900/);
  assert.match(s, /education only, no personal financial advice, no profit promises/);
});

test('mentors page: call button per mentor, per-mentor voices, ends on leaving the page', () => {
  const s = fs.readFileSync(new URL('../src/pages/mentors.js', import.meta.url), 'utf8');
  assert.match(s, /data-call="\$\{m\.id\}"/g);
  for (const id of ['sara-smc', 'khaled-gold', 'leo-crypto', 'nora-macro', 'omar-risk', 'zen-mind']) assert.ok(s.includes(`'${id}': { pitch`), id);
  assert.match(s, /onUnmount\(root, \(\) => \{ call\?\.stop\(\)/);
  assert.match(s, /voiceSupported\(\) \?/);
});
