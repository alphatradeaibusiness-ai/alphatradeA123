// v152 bank hardening: authenticator-app 2FA (TOTP), fraud/risk scoring, automatic compliance reports, duplicate-ID check, key re-wrap.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { openDb } from '../server/bank/db.js';
import { createVault } from '../server/bank/vault.js';
import { createBank } from '../server/bank/service.js';
import { decryptPayload } from '../server/bank/webpush.js';
import { makeAuthenticator } from './helpers/fakeAuthenticator.js';

const OWNER = { uid: 'owner' };
const DAY = 86400_000;
const GOOD_IBAN = 'DE89370400440532013000';
const GB_IBAN = 'GB82WEST12345698765432';
const ADDR = { country: 'DE', region: 'BE', city: 'Berlin', postal: '10115', line1: 'Invalidenstrasse 1' };
const RP = { rpId: 'localhost', origins: ['http://localhost'] };

function setup({ mode = 'sandbox', start = Date.UTC(2026, 9, 27, 12), ...extra } = {}) {
  let t = start; const db = openDb(':memory:'); const pushes = [];
  const bank = createBank({
    db, vault: createVault({ secret: 'z'.repeat(40) }), mode, now: () => t,
    priceFn: async () => ({ price: 50000, ts: t }),
    rateFn: async () => ({ usdPer: { USD: 1, EUR: 1.1, USDT: 1, BTC: 50000 }, ts: t, sources: {} }),
    pushSender: async (sub, payload) => { pushes.push({ sub, payload }); return { ok: true }; },
    config: { beneficiaryCooldown: 1000 }, ...extra,
  });
  return { db, bank, pushes, tick: (ms) => { t += ms; }, now: () => t };
}
const kyc = (b, uid, tier = 1) => {
  if (tier === 2 && b.kycStatus(uid).tier < 1) kyc(b, uid, 1);
  if (b.kycStatus(uid).tier >= tier) return;
  b.submitKyc(uid, { tier, fullName: 'Ada Lovelace', dob: '1990-05-05', nationality: 'DE', address: ADDR, idType: 'passport', idNumber: 'C' + Buffer.from(String(uid)).toString('hex').slice(0, 14), idExpiry: '2031-01-01', sourceOfFunds: 'salary', proofOfAddressRef: 'vend-123' });
  b.reviewKyc(OWNER, uid, 'approve');
};
let n = 0; const k = () => `key-${++n}-abcdef`;
const fund = (b, uid, cur, amt) => b.sandboxFund(uid, { currency: cur, amount: amt, idem: k() });
const bal = (b, uid, cur) => b.wallet(uid).find((w) => w.currency === cur);
const code = (fn) => { try { fn(); } catch (e) { return e.code; } return 'NO_ERROR'; };
const acode = async (fn) => { try { await fn(); } catch (e) { return e.code; } return 'NO_ERROR'; };
const deposit = (b, uid, cur, amt) => { const d = b.requestDeposit(uid, { currency: cur, amount: amt, idem: k() }); b.confirmDeposit(OWNER, d.id, { extRef: `BANK-${k()}`, received: amt }); };
const ok = (bank) => assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });


import { hotp, totpAt, base32, unbase32 } from '../server/bank/features/totp.js';
import { csvCell } from '../server/bank/features/compliance.js';

test('TOTP: RFC 6238 vector; enrol → confirm → codes are single-use; backup codes work once; lockout after 5 wrong codes', () => {
  assert.equal(hotp(Buffer.from('12345678901234567890'), 1), '287082');          // RFC 6238 appendix B, t = 59 s
  assert.deepEqual(unbase32(base32(Buffer.from('hello world'))), Buffer.from('hello world'));
  const { bank, db, tick, now } = setup(); kyc(bank, 'u1', 1);
  assert.equal(bank.totp.enabled('u1'), false);
  assert.equal(code(() => bank.totp.confirm('u1', '123456')), 'totp_not_started');
  const e = bank.totp.enroll('u1', 'ada@example.com');
  assert.match(e.secret, /^[A-Z2-7]{32}$/); assert.ok(e.uri.startsWith('otpauth://totp/AlphaTrade:') && e.uri.includes(`secret=${e.secret}`));
  assert.ok(!JSON.stringify(db.prepare('SELECT * FROM totp').all()).includes(e.secret), 'secret is sealed at rest');
  assert.equal(bank.totp.enabled('u1'), false);                                  // not active until a code proves the app works
  assert.equal(code(() => bank.totp.confirm('u1', '000000')), 'totp_invalid');
  const sec = unbase32(e.secret);
  const { backupCodes } = bank.totp.confirm('u1', totpAt(sec, now()));
  assert.equal(bank.totp.enabled('u1'), true); assert.equal(backupCodes.length, 8);
  assert.ok(!JSON.stringify(db.prepare('SELECT * FROM totp_backup').all()).includes(backupCodes[0].replace('-', '')), 'backup codes are stored hashed');
  assert.equal(code(() => bank.totp.confirm('u1', '1')), 'totp_exists');
  // the code that just confirmed cannot be replayed, the next window's can
  assert.equal(code(() => bank.totp.require('u1', totpAt(sec, now()))), 'totp_invalid');
  tick(30_000); assert.equal(bank.totp.require('u1', totpAt(sec, now())), true);
  assert.equal(code(() => bank.totp.require('u1', '')), 'totp_required');
  // backup code: once
  assert.equal(bank.totp.require('u1', backupCodes[0]), true);
  assert.equal(code(() => bank.totp.require('u1', backupCodes[0])), 'totp_invalid');
  assert.equal(bank.totp.status('u1').backupLeft, 7);
  // lockout: 5 failures in 10 min stop even a correct code
  tick(11 * 60_000); for (let i = 0; i < 4; i++) assert.equal(code(() => bank.totp.require('u1', '999999')), 'totp_invalid');
  assert.equal(code(() => bank.totp.require('u1', '999999')), 'totp_invalid');
  assert.equal(code(() => bank.totp.require('u1', totpAt(sec, now()))), 'too_many_attempts');
  tick(11 * 60_000); assert.equal(bank.totp.require('u1', totpAt(sec, now())), true);
  // disable needs a valid code
  assert.equal(code(() => bank.totp.disable('u1', '111111')), 'totp_invalid');
  tick(30_000); assert.deepEqual(bank.totp.disable('u1', totpAt(sec, now())), { ok: true });
  assert.equal(bank.totp.enabled('u1'), false); assert.equal(bank.totp.require('u1', ''), false);
  ok(bank); assert.deepEqual(bank.audit.verify().ok, true);
});

test('risk: a deposit-and-run withdrawal to a new account is blocked and recorded; a mild one is flagged for review', async () => {
  const { bank, tick } = setup(); kyc(bank, 'u1', 1); fund(bank, 'u1', 'USD', '1000');
  const ben = bank.addBeneficiary('u1', { currency: 'USD', label: 'me', iban: GOOD_IBAN, holder: 'Ada' }); tick(2000);
  const w = bank.requestWithdrawal('u1', { currency: 'USD', amount: '100', beneficiaryId: ben.id, idem: k() });
  assert.ok(w.flags.includes('risk_review'), 'first withdrawal + new beneficiary + new account → review');
  assert.equal(bank.risk.list({ level: 'review' }).length, 1);
  assert.equal(bank.risk.list({ level: 'review' })[0].ref, w.id);
  assert.ok(bank.risk.list({})[0].reasons.some((r) => r.why === 'new_beneficiary'));
  assert.equal(code(() => bank.risk.review('u1', bank.risk.list({})[0].id)), 'self_action_not_allowed');
  assert.deepEqual(bank.risk.review('owner', bank.risk.list({})[0].id, 'looks fine'), { ok: true });
  assert.equal(bank.risk.list({ open: true }).length, 0);
  // a brand-new account: real deposit, then straight out near the daily limit to a new beneficiary → blocked, nothing moves
  kyc(bank, 'u3', 1); deposit(bank, 'u3', 'USD', '1000');
  const ben3 = bank.addBeneficiary('u3', { currency: 'USD', label: 'x', iban: GB_IBAN, holder: 'X' }); tick(2000);
  const avail = bal(bank, 'u3', 'USD').available;
  assert.equal(code(() => bank.requestWithdrawal('u3', { currency: 'USD', amount: '950', beneficiaryId: ben3.id, idem: k() })), 'risk_blocked');
  assert.equal(bal(bank, 'u3', 'USD').available, avail, 'no money moved');
  assert.ok(bank.risk.list({ level: 'block' }).some((r) => r.uid === 'u3' && r.reasons.some((x) => x.why === 'fresh_deposit')));
  assert.ok(bank.risk.forUser('u3').length >= 1); ok(bank);
});

test('risk: card testing (repeated declines) declines the next attempt, freezes only that card and alerts the owner', () => {
  const { bank, pushes } = setup(); kyc(bank, 'u1', 2); fund(bank, 'u1', 'USD', '500');
  const c = bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'web' });
  const other = bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'other' });
  for (let i = 0; i < 4; i++) { try { bank.vcards.simulate('u1', c.id, { merchant: `Shop${i}`, amount: '5000', category: 'shopping' }); } catch { /* declined */ } }
  let last; try { last = bank.vcards.simulate('u1', c.id, { merchant: 'Tiny', amount: '1', category: 'shopping' }); } catch (e) { last = { error: e.code }; }
  const cards = bank.vcards.list('u1');
  assert.equal(cards.find((x) => x.id === c.id).status, 'frozen');
  assert.equal(cards.find((x) => x.id === other.id).status, 'active', 'other cards are untouched');
  assert.ok(bank.risk.list({ level: 'block' }).some((r) => r.kind === 'card' && r.ref === c.id));
  assert.ok(JSON.stringify(last).includes('risk_card_testing') || JSON.stringify(last).includes('declined') || last.error, 'the attempt did not go through');
  ok(bank);
});

test('compliance: reports are built from the ledger, stored once per period, exported as safe CSV, and include integrity checks', async () => {
  const { bank, tick } = setup({ config: { beneficiaryCooldown: 1000, compliance: { largeUsd: 500 } } }); kyc(bank, 'u1', 2); deposit(bank, 'u1', 'USD', '800'); kyc(bank, 'u2', 1); deposit(bank, 'u2', 'EUR', '50');
  tick(DAY + 5000);
  const made = await bank.compliance.runDue(); assert.equal(made.length, 2);
  assert.equal((await bank.compliance.runDue())[0], made[0], 'one report per period');
  assert.equal(bank.compliance.list().length, 2);
  const daily = bank.compliance.get(made[0]);
  assert.equal(daily.data.volumes.deposits.USD.count, 1); assert.equal(daily.data.volumes.deposits.USD.total, 80000);
  assert.equal(daily.data.volumes.deposits.EUR.count, 1);
  assert.equal(daily.data.largeTransactions.length, 1); assert.equal(daily.data.largeTransactions[0].usd, 800);
  assert.equal(daily.data.integrity.audit.ok, true); assert.equal(daily.data.integrity.ledger.ok, true);
  const csv = bank.compliance.toCsv(daily); assert.ok(csv.startsWith('section,key,value')); assert.ok(csv.includes('large,'));
  assert.equal(csvCell('=HYPERLINK("x")'), `"'=HYPERLINK(""x"")"`); assert.equal(csvCell('+1'), "'+1"); assert.equal(csvCell('a,b'), '"a,b"');
  assert.equal(await acode(() => bank.compliance.adhoc(10, 5)), 'bad_range');
  assert.equal((await bank.compliance.adhoc(0, 300 * DAY)).period, 'adhoc');
});

test('identity: the same ID document cannot back two accounts (generic error, risk event); an ID about to expire is refused', () => {
  const { bank } = setup();
  const base = { tier: 1, fullName: 'Ada Lovelace', dob: '1990-05-05', nationality: 'DE', address: ADDR, idType: 'passport', idNumber: 'P12345678', idExpiry: '2031-01-01' };
  assert.equal(bank.submitKyc('u1', base).status, 'pending');
  assert.equal(code(() => bank.submitKyc('u2', { ...base, idNumber: 'p 1234 5678' })), 'verification_failed');   // spacing/case do not dodge it
  assert.ok(bank.risk.list({}).some((r) => r.uid === 'u2' && r.kind === 'kyc'));
  assert.equal(code(() => bank.submitKyc('u3', { ...base, idNumber: 'Q99999999', idExpiry: new Date(Date.UTC(2026, 9, 28) + 10 * DAY).toISOString().slice(0, 10) })), 'id_expiring');
});

test('key rotation: rewrapAll moves every sealed record to the new master key and is idempotent', () => {
  const oldV = createVault({ secret: 'z'.repeat(40) }); const db = openDb(':memory:'); let t = Date.UTC(2026, 9, 27, 12);
  const mkBank = (vault) => createBank({ db, vault, mode: 'sandbox', now: () => t, rateFn: async () => ({ usdPer: { USD: 1, EUR: 1.1, USDT: 1, BTC: 50000 }, ts: t, sources: {} }), config: { beneficiaryCooldown: 1000 } });
  const a = mkBank(oldV); kyc(a, 'u1', 2); fund(a, 'u1', 'USD', '100');
  const card = a.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'w' }); const pan = a.vcards.reveal('u1', card.id).pan;
  const e = a.totp.enroll('u1', 'a@b.c');
  const newV = createVault({ secret: 'n'.repeat(40), previous: ['z'.repeat(40)] }); const b = mkBank(newV);
  const r = b.rewrapAll('owner'); assert.ok(r.rewrapped >= 3 && r.skipped === 0);
  assert.equal(b.rewrapAll('owner').rewrapped, 0);
  const only = mkBank(createVault({ secret: 'n'.repeat(40) }));              // old key dropped
  assert.equal(only.vcards.reveal('u1', card.id).pan, pan);
  assert.equal(only.kycDetail({ uid: 'owner' }, 'u1').fullName, 'Ada Lovelace');
  assert.ok(e.secret);
});

// ── over HTTP: the real gate ──
import http from 'node:http';
import { spawn } from 'node:child_process';
const PROJECT = 'alphatrade-test'; const KID = 'k-bank';
const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
function tok(uid, email) {
  const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
  const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'password' } }));
  return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`;
}
const call = (port, p, { method = 'GET', t, body } = {}) => new Promise((resolve, reject) => {
  const data = body === undefined ? null : JSON.stringify(body);
  const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { origin: `http://127.0.0.1:${port}`, ...(data ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}) } },
    (res) => { let buf = ''; res.on('data', (c) => (buf += c)); res.on('end', () => { let j = null; try { j = JSON.parse(buf); } catch { /* */ } resolve({ status: res.statusCode, body: j, raw: buf }); }); });
  r.on('error', reject); if (data) r.write(data); r.end();
});

test('TOTP over HTTP: a gated action asks for the code, accepts it once, then backup codes; /status shows totp; owner sees risk + compliance endpoints', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk6-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), BANK_MASTER_KEY: 'm'.repeat(48), BANK_MODE: 'sandbox', AI_TEST_CERTS_FILE: certFile, FIREBASE_PROJECT_ID: PROJECT, SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), ANTHROPIC_API_KEY: '' }, stdio: 'ignore' });
  const c = (p, o) => call(port, p, o); const owner = tok('owner-uid', 'shheahmad417@gmail.com'); const bob = tok('bob', 'bob@example.com');
  try {
    for (let i = 0; i < 80; i++) { try { await c('/api/bank/status'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    const KY = { tier: 1, fullName: 'Bob Builder', dob: '1990-05-05', nationality: 'DE', address: { country: 'DE', region: 'BE', city: 'Berlin', postal: '10115', line1: 'Invalidenstrasse 1' }, idType: 'passport', idNumber: 'B7654321', idExpiry: '2031-01-01' };
    assert.equal((await c('/api/bank/kyc', { method: 'POST', t: bob, body: KY })).status, 200);
    await c('/api/bank/admin/kyc/bob/approve', { method: 'POST', t: owner, body: {} });
    assert.equal((await c('/api/bank/status', { t: bob })).body.totp, false);
    const en = await c('/api/bank/totp/enroll', { method: 'POST', t: bob, body: {} }); assert.equal(en.status, 200, en.raw);
    const sec = unbase32(en.body.secret);
    assert.equal((await c('/api/bank/totp/confirm', { method: 'POST', t: bob, body: { code: '000000' } })).body.code, 'totp_invalid');
    const cf = await c('/api/bank/totp/confirm', { method: 'POST', t: bob, body: { code: totpAt(sec, Date.now()) } }); assert.equal(cf.status, 200, cf.raw);
    assert.equal(cf.body.backupCodes.length, 8); assert.equal((await c('/api/bank/status', { t: bob })).body.totp, true);
    const ben = { currency: 'USD', label: 'me', iban: GOOD_IBAN, holder: 'Bob' };
    assert.equal((await c('/api/bank/beneficiaries', { method: 'POST', t: bob, body: ben })).body.code, 'totp_required');
    assert.equal((await c('/api/bank/beneficiaries', { method: 'POST', t: bob, body: { ...ben, passkey: '123456' } })).body.code, 'totp_invalid');
    const good = await c('/api/bank/beneficiaries', { method: 'POST', t: bob, body: { ...ben, passkey: totpAt(sec, Date.now() + 30_000) } });
    assert.equal(good.status, 200, good.raw);
    const again = await c('/api/bank/beneficiaries', { method: 'POST', t: bob, body: { ...ben, label: 'two', passkey: totpAt(sec, Date.now() + 30_000) } });
    assert.equal(again.body.code, 'totp_invalid', 'same code cannot be replayed');
    assert.equal((await c('/api/bank/beneficiaries', { method: 'POST', t: bob, body: { ...ben, iban: GB_IBAN, label: 'three', passkey: cf.body.backupCodes[0] } })).status, 200);
    // owner endpoints; a normal user cannot reach them
    assert.equal((await c('/api/bank/admin/risk', { t: bob })).status, 403);
    assert.equal((await c('/api/bank/admin/risk', { t: owner })).status, 200);
    assert.equal((await c('/api/bank/admin/compliance/run', { method: 'POST', t: owner, body: { from: Date.now() - 86400_000, to: Date.now() } })).status, 200);
    assert.equal((await c('/api/bank/admin/rewrap', { method: 'POST', t: owner, body: {} })).status, 200);
    // once the owner turns on an authenticator app, the admin console needs one code per unlock window
    const oe = await c('/api/bank/totp/enroll', { method: 'POST', t: owner, body: {} }); const osec = unbase32(oe.body.secret);
    assert.equal((await c('/api/bank/totp/confirm', { method: 'POST', t: owner, body: { code: totpAt(osec, Date.now()) } })).status, 200);
    assert.equal((await c('/api/bank/admin/risk', { t: owner })).body.code, 'totp_required');
    assert.equal((await c('/api/bank/admin/unlock', { method: 'POST', t: owner, body: { code: '000000' } })).body.code, 'totp_invalid');
    assert.equal((await c('/api/bank/admin/risk', { t: owner })).body.code, 'totp_required');
    const un = await c('/api/bank/admin/unlock', { method: 'POST', t: owner, body: { code: totpAt(osec, Date.now() + 30_000) } });
    assert.equal(un.status, 200, un.raw); assert.ok(un.body.until > Date.now());
    assert.equal((await c('/api/bank/admin/risk', { t: owner })).status, 200);
    assert.equal((await c('/api/bank/admin/unlock', { method: 'POST', t: bob, body: { code: '123456' } })).status, 403);
    assert.equal((await c('/api/bank/admin/lock', { method: 'POST', t: owner, body: {} })).status, 200);
    assert.equal((await c('/api/bank/admin/risk', { t: owner })).body.code, 'totp_required');
  } finally { child.kill(); }
});
