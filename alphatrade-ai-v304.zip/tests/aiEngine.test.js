import assert from 'node:assert';
import { aiAnalyze, auc, barrier } from '../src/services/aiEngine.js';

function rng(s) { return () => { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; }; }
function series(seed, n, k) {
  const r = rng(seed); let p = 100; let m = 0; const c = [];
  for (let i = 0; i < n; i++) {
    const o = p; m = 0.9 * m + (r() - 0.5) * 0.01; p *= 1 + m * k + (r() - 0.5) * 0.004;
    c.push({ time: i * 3600, open: o, high: Math.max(o, p) * 1.002, low: Math.min(o, p) * 0.998, close: p, volume: 1 });
  }
  return c;
}

// helpers
assert.strictEqual(auc([0.9, 0.8, 0.2, 0.1], [1, 1, 0, 0]), 1);
assert.strictEqual(auc([0.1, 0.2, 0.8, 0.9], [1, 1, 0, 0]), 0);
const bc = [{ close: 100, high: 100, low: 100 }, { close: 100, high: 103, low: 99.5 }];
assert.strictEqual(barrier(bc.concat(new Array(60).fill({ close: 100, high: 100, low: 100 })), 0, 'long', 2, 1), 1);
assert.strictEqual(barrier([{ close: 100, high: 100, low: 100 }, { close: 100, high: 103, low: 97 }, ...new Array(60).fill({ close: 100, high: 100, low: 100 })], 0, 'long', 2, 1), 0, 'stop and target in one candle = loss');

// too little data → honest "not ready"
assert.strictEqual(aiAnalyze(series(1, 200, 0), { key: 'short' }).ready, false);

// pure noise → the engine must NOT claim an edge
let false_edges = 0;
for (let s = 1; s <= 4; s++) {
  const a = aiAnalyze(series(s * 11, 2500, 0), { key: `n${s}` });
  assert(a.ready);
  for (const side of [a.long, a.short]) { if (side?.edge) false_edges++; if (side) assert(side.p >= 0.15 && side.p <= 0.88); }
  if (a.forecast?.edge) false_edges++;
  assert(!a.long?.edge ? Math.abs(a.long.p - a.long.base) < 1e-9 : true, 'no edge → probability is the plain base rate');
}
assert.strictEqual(false_edges, 0, 'false edges on random data');

// real planted structure → detected, out-of-sample
let found = 0;
for (let s = 1; s <= 4; s++) {
  const a = aiAnalyze(series(s * 13, 2500, 1.5), { key: `p${s}` });
  if (a.long?.edge || a.short?.edge || a.forecast?.edge) found++;
}
assert(found >= 3, `planted edge found ${found}/4`);

// no look-ahead: the forming (last) candle is ignored
const base = series(5, 2500, 1.5);
const x = aiAnalyze(base, { key: 'la1' });
const alt = base.slice(); alt[alt.length - 1] = { ...alt.at(-1), close: alt.at(-1).close * 1.2, high: alt.at(-1).close * 1.25 };
const y = aiAnalyze(alt, { key: 'la2' });
assert.strictEqual(x.long?.p, y.long?.p);
// indicators: six readings with real counts, and the combined number is the base rate when nothing is proven
const nz = aiAnalyze(series(21, 2500, 0), { key: 'ind1', volumeKind: 'estimated' });
for (const side of [nz.long, nz.short]) {
  assert.strictEqual(side.indicators.length, 8);
  assert(side.indicators.every((i) => i.n >= 0 && (i.rate == null || (i.rate >= 0 && i.rate <= 1))));
  assert(!side.edge && Math.abs(side.p - side.base) < 1e-9, 'noise: combined = base rate');
  assert(side.indicators.filter((i) => i.proven).length <= 1, 'noise: indicators must not look proven');
}
assert.strictEqual(aiAnalyze(series(21, 2500, 0), { key: 'ind2', volumeKind: 'none' }).long.indicators.find((i) => i.key === 'pressure').available, false);
const pl = aiAnalyze(series(13, 2500, 1.5), { key: 'ind3', volumeKind: 'estimated' });
assert(pl.long.indOos && pl.long.indP != null);
console.log('ai engine ok');
