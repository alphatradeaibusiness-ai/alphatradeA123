import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeTrades, statsR, sessionOf } from '../src/services/tradeInsights.js';

const H = 3600e3;
const base = Date.UTC(2026, 8, 1, 0);
// Longs win (+1.5R), shorts lose (−1R); BTC good, SOL bad; 40 trades.
const trades = Array.from({ length: 40 }, (_, i) => {
  const long = i % 2 === 0;
  const sym = i % 4 < 2 ? 'BTCUSDT' : 'SOLUSDT';
  const r = long ? (sym === 'BTCUSDT' ? 1.8 : 0.6) : (sym === 'BTCUSDT' ? -0.4 : -1);
  return { symbol: sym, tf: '1h', strategy: 'smc', direction: long ? 'long' : 'short', openTime: base + i * 5 * H, closeTime: base + i * 5 * H + 2 * H, r, hits: r < 0 ? 0 : r > 1 ? 3 : 1 };
});

test('statsR: win rate, net, profit factor, drawdown', () => {
  const s = statsR([{ r: 1, closeTime: 1 }, { r: -1, closeTime: 2 }, { r: -1, closeTime: 3 }, { r: 2, closeTime: 4 }]);
  assert.equal(s.winRate, 50); assert.equal(s.netR, 1); assert.equal(s.pf, 1.5); assert.equal(s.maxDD, 2); assert.equal(s.lossStreak, 2);
});

test('sessions by UTC hour', () => {
  assert.equal(sessionOf(Date.UTC(2026, 0, 1, 3)), 'asia');
  assert.equal(sessionOf(Date.UTC(2026, 0, 1, 9)), 'london');
  assert.equal(sessionOf(Date.UTC(2026, 0, 1, 14)), 'overlap');
  assert.equal(sessionOf(Date.UTC(2026, 0, 1, 18)), 'newyork');
});

test('analyzeTrades finds the strong and the weak groups and a better what-if', () => {
  const res = analyzeTrades(trades);
  assert.equal(res.overall.n, 40);
  assert.ok(res.strengths.some((g) => g.dim === 'direction' && g.key === 'long'));
  assert.ok(res.weaknesses.some((g) => g.dim === 'direction' && g.key === 'short'));
  assert.ok(res.whatIf && res.whatIf.after.netR > res.whatIf.before.netR);
  assert.ok(['A', 'B', 'C', 'D', 'F'].includes(res.grade));
  assert.equal(res.hours.length, 24);
});
