import test from 'node:test';
import assert from 'node:assert/strict';
import { supportResistance, confluence } from '../src/indicators/levels.js';
import { biasOf } from '../src/services/radarScore.js';

// Price oscillating between ~100 (support) and ~110 (resistance), ending near 104.
const candles = Array.from({ length: 400 }, (_, i) => {
  const c = 105 + 5 * Math.sin(i / 8) + (i === 399 ? -1 : 0);
  return { time: i * 3600, open: c, high: c + 0.3, low: c - 0.3, close: c, volume: 10 };
});

test('supportResistance finds the range floor and ceiling', () => {
  const sr = supportResistance(candles);
  assert.ok(sr.supports.length && sr.resistances.length);
  assert.ok(Math.abs(sr.supports[0].price - 99.7) < 0.6, `support ${sr.supports[0].price}`);
  assert.ok(Math.abs(sr.resistances[0].price - 110.3) < 0.6, `resistance ${sr.resistances[0].price}`);
  assert.ok(sr.supports[0].touches >= 5 && sr.supports[0].strength >= 4);
  assert.ok(sr.supports.every((l) => l.price < sr.price) && sr.resistances.every((l) => l.price > sr.price));
});

test('confluence marks levels found on two timeframes', () => {
  const a = supportResistance(candles); const b = supportResistance(candles.filter((_, i) => i % 2 === 0));
  confluence({ '1h': a, '2h': b });
  assert.ok(a.supports[0].tfs.length === 2);
});

test('biasOf: strong uptrend is positive, downtrend negative', () => {
  const up = Array.from({ length: 300 }, (_, i) => { const c = 100 + i * 0.5 + Math.sin(i) ; return { time: i, open: c - 0.2, high: c + 0.5, low: c - 0.5, close: c, volume: 1 }; });
  const down = up.map((c, i) => ({ ...c, open: 400 - c.open, high: 400 - c.low, low: 400 - c.high, close: 400 - c.close }));
  assert.ok(biasOf(up).bias > 0.3);
  assert.ok(biasOf(down).bias < -0.3);
});
