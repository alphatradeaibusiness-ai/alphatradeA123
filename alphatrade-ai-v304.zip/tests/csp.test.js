// The Content-Security-Policy must allow every script host the app loads at runtime, or sign-in breaks in production.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (p) => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
const scriptSrc = (txt) => (txt.match(/script-src ([^;]+);/) || [])[1] || '';

test('CSP script-src allows the Firebase CDN (and not TradingView) on the Node server and on Netlify', () => {
  const fbHost = new URL(read('src/services/auth/firebaseAuth.js').match(/const CDN = `(https:\/\/[^/`]+)/)[1]).origin;
  for (const file of ['server/index.js', 'netlify.toml']) {
    const src = scriptSrc(read(file));
    assert.ok(src.includes(fbHost), `${file}: script-src must include ${fbHost}`);
    // Google sign-in (popup) loads gapi from apis.google.com; blocking it gives auth/internal-error.
    assert.ok(src.includes('https://apis.google.com'), `${file}: script-src must include apis.google.com for Google sign-in`);
    assert.ok(!src.includes('tradingview.com'), `${file}: no TradingView`);
    assert.ok(!/unsafe-eval/.test(src), `${file}: no unsafe-eval`);
  }
});
