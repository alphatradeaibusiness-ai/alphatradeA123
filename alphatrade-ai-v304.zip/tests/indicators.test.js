import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  ema, rsi, fibLevels, fibZones, autoFibAnchors, volumeProfile, pressureSeries, pressureTotals, momentumScore, tradingPlan,
} from '../src/indicators/index.js';
import { INSTRUMENTS, STOP_LOSS_POINTS, TARGET_POINTS } from '../src/config/instruments.js';
import { generateDemoCandles } from '../src/services/market/demo.js';

const close = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) < eps, `${a} ≈ ${b}`);

test('EMA seeds with SMA and follows the formula', () => {
  const out = ema([1, 2, 3, 4, 5], 3);
  assert.equal(out[1], null);
  close(out[2], 2);
  close(out[3], 3);
  close(out[4], 4);
});

test('RSI is 100 for only-rising and 0 for only-falling closes, ~50 for alternating', () => {
  const up = Array.from({ length: 30 }, (_, i) => 100 + i);
  const down = Array.from({ length: 30 }, (_, i) => 100 - i);
  assert.equal(rsi(up, 14).at(-1), 100);
  assert.equal(rsi(down, 14).at(-1), 0);
  const alt = Array.from({ length: 60 }, (_, i) => (i % 2 ? 101 : 100));
  const v = rsi(alt, 14).at(-1);
  assert.ok(v > 45 && v < 55, `alternating RSI ${v}`);
  assert.equal(rsi(up, 14)[13], null);
});

test('Wilder RSI matches a known reference value', () => {
  // Classic Wilder example closes (StockCharts RSI table). With these 2-decimal closes:
  // avg gain = 3.34/14, avg loss = 1.40/14 → RS = 2.3857 → RSI = 70.46
  // (the published 70.53 comes from unrounded source prices).
  const c = [44.34, 44.09, 44.15, 43.61, 44.33, 44.83, 45.10, 45.42, 45.84, 46.08, 45.89, 46.03, 45.61, 46.28, 46.28];
  close(rsi(c, 14)[14], 70.464, 0.001);
});

test('Fibonacci levels: 0 = high, 1 = low', () => {
  const lv = fibLevels(200, 100);
  close(lv.find((l) => l.ratio === 0).price, 200);
  close(lv.find((l) => l.ratio === 1).price, 100);
  close(lv.find((l) => l.ratio === 0.618).price, 138.2);
  assert.deepEqual(fibLevels(100, 200), []);
  const z = fibZones(200, 100);
  close(z.sell.bottom, 176.4);
  close(z.buy.top, 121.4);
});

test('auto Fibonacci anchors find the extremes in the lookback window', () => {
  const candles = [
    { time: 1, high: 500, low: 10 },
    { time: 2, high: 120, low: 90 },
    { time: 3, high: 150, low: 80 },
    { time: 4, high: 130, low: 95 },
  ];
  assert.deepEqual(autoFibAnchors(candles, 3), { high: 150, highTime: 3, low: 80, lowTime: 3 });
});

test('volume profile conserves volume and puts POC where volume concentrates', () => {
  const candles = [
    { time: 1, open: 10, high: 11, low: 10, close: 11, volume: 100 },
    { time: 2, open: 11, high: 20, low: 11, close: 12, volume: 10 },
    { time: 3, open: 10, high: 11, low: 10, close: 10, volume: 100 },
  ];
  const vp = volumeProfile(candles, { rows: 10 });
  close(vp.total, 210, 1e-6);
  assert.ok(vp.poc < 12, `POC ${vp.poc}`);
  const buy = vp.bins.reduce((a, b) => a + b.buy, 0);
  const sell = vp.bins.reduce((a, b) => a + b.sell, 0);
  close(buy + sell, 210, 1e-6);
  // Fixed range: only the middle candle
  const fr = volumeProfile(candles, { rows: 10, from: 1, to: 1 });
  close(fr.total, 10, 1e-6);
  assert.equal(fr.count, 1);
});

test('volume profile returns null when there is no volume', () => {
  assert.equal(volumeProfile([{ time: 1, open: 1, high: 2, low: 1, close: 2, volume: null }]), null);
});

test('pressure uses taker volume when present and is null without volume', () => {
  const cs = [{ time: 1, open: 1, high: 2, low: 1, close: 2, volume: 10, buyVolume: 7 }];
  const s = pressureSeries(cs, 'taker');
  close(s[0].buy, 7);
  close(s[0].sell, 3);
  close(s[0].delta, 4);
  const tot = pressureTotals(s, 10);
  close(tot.buyPct, 70);
  assert.equal(pressureSeries(cs, 'none'), null);
  const est = pressureSeries([{ time: 1, open: 1, high: 2, low: 1, close: 1.75, volume: 100 }], 'estimated');
  close(est[0].buy, 75);
});

test('stop loss is exactly 30 points on the opposite side, for every instrument', () => {
  assert.equal(STOP_LOSS_POINTS, 30);
  for (const inst of INSTRUMENTS) {
    const entry = inst.demoSeed;
    const long = tradingPlan({ entry, direction: 'long', pointSize: inst.pointSize, slPoints: STOP_LOSS_POINTS });
    close(entry - long.stop, 30 * inst.pointSize, 1e-9);
    assert.ok(long.targets.every((tp) => tp > entry));
    const short = tradingPlan({ entry, direction: 'short', pointSize: inst.pointSize, slPoints: STOP_LOSS_POINTS });
    close(short.stop - entry, 30 * inst.pointSize, 1e-9);
    assert.ok(short.targets.every((tp) => tp < entry));
  }
});

test('targets are 50 / 80 / 130 points from entry (TP2 = TP1 + 30, TP3 = TP2 + 50)', () => {
  assert.deepEqual(TARGET_POINTS, [50, 80, 130]);
  assert.equal(TARGET_POINTS[1] - TARGET_POINTS[0], 30);
  assert.equal(TARGET_POINTS[2] - TARGET_POINTS[1], 50);
  for (const inst of INSTRUMENTS) {
    const ps = inst.pointSize;
    const entry = inst.demoSeed;
    const long = tradingPlan({ entry, direction: 'long', pointSize: ps, slPoints: STOP_LOSS_POINTS, tpPoints: TARGET_POINTS });
    const short = tradingPlan({ entry, direction: 'short', pointSize: ps, slPoints: STOP_LOSS_POINTS, tpPoints: TARGET_POINTS });
    [50, 80, 130].forEach((pts, k) => {
      close(long.targets[k] - entry, pts * ps, 1e-9);   // long: above entry
      close(entry - short.targets[k], pts * ps, 1e-9);  // short: below entry
    });
    close(entry - long.stop, 30 * ps, 1e-9);
    close(short.stop - entry, 30 * ps, 1e-9);
    // Not multiples of the stop distance (that would be 30/60/90 points).
    assert.notEqual(Math.round((long.targets[0] - entry) / ps), 30);
  }
});

test('worked examples: BTC long, gold short, ETH long', () => {
  const btc = tradingPlan({ entry: 68400, direction: 'long', pointSize: 1, tpPoints: TARGET_POINTS });
  assert.deepEqual([btc.stop, ...btc.targets], [68370, 68450, 68480, 68530]);
  const xau = tradingPlan({ entry: 2387.45, direction: 'short', pointSize: 0.01, tpPoints: TARGET_POINTS });
  [2387.75, 2386.95, 2386.65, 2386.15].forEach((v, k) => close([xau.stop, ...xau.targets][k], v, 1e-9));
  const eth = tradingPlan({ entry: 3257.1, direction: 'long', pointSize: 0.1, tpPoints: TARGET_POINTS });
  [3254.1, 3262.1, 3265.1, 3270.1].forEach((v, k) => close([eth.stop, ...eth.targets][k], v, 1e-9));
});

test('point size changes every distance (gold: 0.01 vs 0.10)', () => {
  const a = tradingPlan({ entry: 2387.45, direction: 'long', pointSize: 0.01, tpPoints: TARGET_POINTS });
  const b = tradingPlan({ entry: 2387.45, direction: 'long', pointSize: 0.1, tpPoints: TARGET_POINTS });
  close(a.stop, 2387.15, 1e-9);
  close(b.stop, 2384.45, 1e-9);
  close(a.targets[2], 2387.45 + 1.3, 1e-9);
  close(b.targets[2], 2387.45 + 13, 1e-9);
});

test('momentum score is in range and reacts to trend', () => {
  const up = generateDemoCandles('BTCUSDT', '4h', 300).map((c, i) => ({ ...c, close: 100 + i, open: 99 + i, high: 101 + i, low: 98 + i }));
  const m = momentumScore({ candles: up, rsiValues: rsi(up.map((c) => c.close), 14), pressure: { buyPct: 70 } });
  assert.ok(m.score > 70 && m.score <= 100, `score ${m.score}`);
  assert.equal(m.label, 'positive');
});

test('demo data is deterministic, ordered and internally consistent', () => {
  const a = generateDemoCandles('ETHUSDT', '1h', 200);
  const b = generateDemoCandles('ETHUSDT', '1h', 200);
  assert.equal(a.length, 200);
  assert.deepEqual(a[10], b[10]);
  for (let i = 0; i < a.length; i++) {
    const c = a[i];
    assert.ok(c.high >= Math.max(c.open, c.close) && c.low <= Math.min(c.open, c.close));
    assert.ok(c.buyVolume >= 0 && c.buyVolume <= c.volume);
    if (i) assert.equal(c.time - a[i - 1].time, 3600);
  }
});
