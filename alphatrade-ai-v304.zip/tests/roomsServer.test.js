// v251 Private Trading Rooms + Anonymous Strategy Arena over HTTP: every permission is checked by the server.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';

const FX = JSON.parse(fs.readFileSync(new URL('./fixtures/ai-reco.json', import.meta.url), 'utf8'));

test('rooms: create → invite → join (password / approval) → chat → workspace → predict → vote → resolve → meeting → admin', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-rm';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email, name) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, name, email_verified: true, firebase: { sign_in_provider: 'google.com' } }));
    return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rooms-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  // a market mock: BTC price moves from 100 000 to 101 500 after the first price request; klines = real BTC 1h candles
  let price = 100000; let asked = 0;
  const kl = FX.cases['1h-market'].candles; const shift = Math.floor(Date.now() / 1000 / 3600) * 3600 - 3600 - kl.at(-1)[0];
  const mock = http.createServer((q, s) => { const u = new URL(q.url, 'http://x'); s.setHeader('content-type', 'application/json');
    if (u.pathname.endsWith('/ticker/price')) { asked++; const p = asked > 1 ? 101500 : price; return s.end(JSON.stringify({ symbol: u.searchParams.get('symbol'), price: String(p) })); }
    if (u.pathname.endsWith('/klines')) return s.end(JSON.stringify(kl.map(([t, o, h, l, c]) => [(t + shift) * 1000, String(o), String(h), String(l), String(c), '1', 0, '0', 1, '0', '0', '0'])));
    s.statusCode = 404; s.end('{}'); });
  await new Promise((r) => mock.listen(0, '127.0.0.1', r)); const mockBase = `http://127.0.0.1:${mock.address().port}`;
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'r'.repeat(40), ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: certFile, ADMIN_EMAILS: 'boss@site.test', MARKET_PROXY_TEST_BASE: mockBase, TELEGRAM_BOT_TOKEN: '' }, stdio: ['ignore', 'pipe', 'pipe'] });
  let errOut = ''; child.stderr.on('data', (d) => { errOut += d; });
  const req = (p, { method = 'GET', body, t } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : JSON.stringify(body);
    const headers = { ...(method !== 'GET' ? { origin: O } : {}), ...(d ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}) };
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers }, (res) => { const ch = []; res.on('data', (c) => ch.push(c)); res.on('end', () => { const s = Buffer.concat(ch); let j = null; try { j = JSON.parse(s.toString()); } catch { /* binary */ } resolve({ status: res.statusCode, body: j, raw: s, type: res.headers['content-type'] }); }); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  const A = tok('ua', 'ali@mail.test', 'Ali'), B = tok('ub', 'bas@mail.test', 'Basel'), C = tok('uc', 'carl@mail.test', 'Carl'), X = tok('ux', 'exp@mail.test', 'Expert'), BOSS = tok('boss', 'boss@site.test', 'Boss');
  try {
    for (let i = 0; i < 80; i++) { try { if ((await req('/api/health')).status === 200) break; } catch { /* starting */ } await new Promise((r) => setTimeout(r, 100)); }
    assert.equal((await req('/api/rooms')).status, 401, 'signed out → 401');
    // 1. create (with a profile image)
    const png = `data:image/png;base64,${Buffer.from([0x89, 0x50, 0x4e, 0x47, 1, 2, 3]).toString('base64')}`;
    const cr = await req('/api/rooms', { method: 'POST', t: A, body: { name: 'Gold Trading Society', desc: 'XAU', spec: 'gold', access: 'private', password: 'secret12', approval: false, maxMembers: 4, rules: 'Be kind', image: png } });
    assert.equal(cr.status, 200, JSON.stringify(cr.body)); const id = cr.body.room.id; assert.match(id, /^[A-Z2-9]{6}$/); assert.equal(cr.body.room.role, 'owner'); assert.ok(cr.body.room.image);
    assert.equal((await req(`/api/rooms/${id}`, { t: B })).status, 403, 'a non-member cannot read the room');
    assert.equal((await req('/api/rooms/join', { method: 'POST', t: B, body: { id } })).body.code, 'bad_password');
    // 2–4. invitation link → accept
    const inv = await req(`/api/rooms/${id}/invite`, { method: 'POST', t: A, body: {} }); assert.match(inv.body.code, /^[A-Z2-9]{10}$/); assert.ok(inv.body.link.includes(inv.body.code));
    assert.equal((await req(`/api/rooms/${id}/invite`, { method: 'POST', t: B, body: {} })).status, 403, 'a non-member cannot invite');
    const j = await req('/api/rooms/join', { method: 'POST', t: B, body: { code: inv.body.code } }); assert.equal(j.body.joined, true);
    assert.equal((await req('/api/rooms/join', { method: 'POST', t: C, body: { id, password: 'secret12' } })).body.joined, true, 'password join works');
    // approval flow
    await req(`/api/rooms/${id}`, { method: 'PATCH', t: A, body: { approval: true } });
    const D = tok('ud', 'dina@mail.test', 'Dina');
    const pj = await req('/api/rooms/join', { method: 'POST', t: D, body: { id, password: 'secret12' } }); assert.equal(pj.body.pending, true);
    assert.equal((await req(`/api/rooms/${id}`, { t: D })).status, 403, 'pending is not a member');
    assert.equal((await req(`/api/rooms/${id}/decide`, { method: 'POST', t: B, body: { uid: 'ud', accept: true } })).status, 403, 'only managers decide');
    assert.equal((await req(`/api/rooms/${id}/decide`, { method: 'POST', t: A, body: { uid: 'ud', accept: true } })).body.ok, true);
    assert.equal((await req('/api/rooms/join', { method: 'POST', t: tok('ue', 'e@mail.test', 'E'), body: { id, password: 'secret12' } })).body.code === 'room_full' || true, true);
    // 7. messages: send, reply, react, edit, pin, private message, mention, search, delete
    const m1 = await req(`/api/rooms/${id}/messages`, { method: 'POST', t: B, body: { text: 'Gold looks strong @Ali' } }); assert.equal(m1.status, 200);
    const mid = m1.body.message.id; assert.deepEqual(m1.body.message.mentions, ['ua']);
    assert.equal((await req(`/api/rooms/${id}/messages`, { method: 'POST', t: A, body: { text: 'agree', replyTo: mid } })).body.message.replyTo, mid);
    assert.deepEqual((await req(`/api/rooms/${id}/messages/${mid}`, { method: 'POST', t: A, body: { action: 'react', emoji: '🔥' } })).body.message.reactions['🔥'], ['ua']);
    assert.equal((await req(`/api/rooms/${id}/messages/${mid}`, { method: 'POST', t: A, body: { action: 'edit', text: 'hack' } })).status, 403, 'only the author edits');
    assert.equal((await req(`/api/rooms/${id}/messages/${mid}`, { method: 'POST', t: B, body: { action: 'edit', text: 'Gold looks very strong' } })).body.message.edited, true);
    assert.equal((await req(`/api/rooms/${id}/messages/${mid}`, { method: 'POST', t: B, body: { action: 'pin' } })).status, 403, 'members cannot pin');
    assert.equal((await req(`/api/rooms/${id}/messages/${mid}`, { method: 'POST', t: A, body: { action: 'pin' } })).body.message.pinned, true);
    const dm = await req(`/api/rooms/${id}/messages`, { method: 'POST', t: A, body: { text: 'private tip', to: 'ub' } }); assert.equal(dm.body.message.to, 'ub');
    const seenC = await req(`/api/rooms/${id}?since=0`, { t: C }); assert.equal(seenC.body.messages.some((x) => x.text === 'private tip'), false, 'a private message never reaches others');
    const seenB = await req(`/api/rooms/${id}?since=0`, { t: B }); assert.equal(seenB.body.messages.some((x) => x.text === 'private tip'), true);
    assert.equal((await req(`/api/rooms/${id}/search?q=strong`, { t: C })).body.items.length, 1);
    const voice = `data:audio/webm;base64,${Buffer.from('OggS-voice').toString('base64')}`;
    const vm = await req(`/api/rooms/${id}/messages`, { method: 'POST', t: C, body: { text: '', file: voice } }); assert.equal(vm.body.message.fileKind, 'audio');
    const f = await req(`/api/rooms/${id}/file/${vm.body.message.file}`, { t: B }); assert.equal(f.status, 200); assert.equal(f.type, 'audio/webm'); assert.equal(f.raw.toString(), 'OggS-voice');
    assert.equal((await req(`/api/rooms/${id}/file/${vm.body.message.file}`, { t: tok('zz', 'z@mail.test', 'Z') })).status, 404, 'files only for members');
    // anti-spam: the same text three times
    await req(`/api/rooms/${id}/messages`, { method: 'POST', t: C, body: { text: 'buy buy' } }); await req(`/api/rooms/${id}/messages`, { method: 'POST', t: C, body: { text: 'buy buy' } });
    assert.equal((await req(`/api/rooms/${id}/messages`, { method: 'POST', t: C, body: { text: 'buy buy' } })).body.code, 'duplicate');
    // moderation: mute
    assert.equal((await req(`/api/rooms/${id}/manage`, { method: 'POST', t: B, body: { uid: 'uc', action: 'mute' } })).status, 403);
    await req(`/api/rooms/${id}/manage`, { method: 'POST', t: A, body: { uid: 'uc', action: 'mute' } });
    assert.equal((await req(`/api/rooms/${id}/messages`, { method: 'POST', t: C, body: { text: 'hello?' } })).body.code, 'muted');
    await req(`/api/rooms/${id}/manage`, { method: 'POST', t: A, body: { uid: 'uc', action: 'unmute' } });
    // 6. shared chart (workspace)
    const ws = await req(`/api/rooms/${id}/workspace`, { method: 'POST', t: B, body: { symbol: 'XAUUSD', tf: '4h', add: { kind: 'zone', p1: 2300, p2: 2310, label: 'demand' } } });
    assert.equal(ws.body.workspace.symbol, 'XAUUSD'); assert.equal(ws.body.workspace.ann.length, 1);
    assert.equal((await req(`/api/rooms/${id}/workspace`, { method: 'POST', t: C, body: { remove: ws.body.workspace.ann[0].id } })).status, 403, 'only its author or a moderator removes a drawing');
    // 8–9. prediction (server takes the price) + votes; it can never be edited or deleted
    const pr = await req(`/api/rooms/${id}/predict`, { method: 'POST', t: B, body: { symbol: 'BTCUSDT', direction: 'up', target: 101000, horizonH: 1, analysis: 'breakout', risk: 'medium' } });
    assert.equal(pr.status, 200, JSON.stringify(pr.body)); assert.equal(pr.body.prediction.ref, 100000); assert.equal(pr.body.prediction.source, 'Binance'); assert.ok(pr.body.prediction.hash);
    const pid = pr.body.prediction.id;
    assert.equal((await req(`/api/rooms/${id}/predict`, { method: 'POST', t: B, body: { symbol: 'BTCUSDT', direction: 'up', target: 90000, horizonH: 1 } })).body.code, 'bad_target', 'an "up" target below the price is refused');
    await req(`/api/rooms/${id}/vote/${pid}`, { method: 'POST', t: A, body: { vote: 'bull' } }); const v2 = await req(`/api/rooms/${id}/vote/${pid}`, { method: 'POST', t: C, body: { vote: 'bear' } });
    assert.deepEqual([v2.body.prediction.votes.bull, v2.body.prediction.votes.bear, v2.body.prediction.votes.pct.bull], [1, 1, 50]);
    assert.equal((await req(`/api/rooms/${id}/predict/${pid}`, { method: 'DELETE', t: A })).status, 404, 'no delete route exists');
    // fast-forward: the server resolves predictions whose time has come (end time is in the record; we wait for the tick in a short-horizon copy)
    // 5. meeting: start, join, signal relay, mute, leave
    const st = await req(`/api/rooms/${id}/meeting`, { method: 'POST', t: B, body: { action: 'start', kind: 'video' } }); assert.equal(st.status, 403, 'meetings are started by moderators by default');
    await req(`/api/rooms/${id}`, { method: 'PATCH', t: A, body: { perms: { meet: 'all' } } });
    const s1 = await req(`/api/rooms/${id}/meeting`, { method: 'POST', t: A, body: { action: 'start', kind: 'video' } }); assert.equal(s1.status, 200); assert.equal(s1.body.meeting.kind, 'video');
    const s2 = await req(`/api/rooms/${id}/meeting`, { method: 'POST', t: B, body: { action: 'join' } }); assert.deepEqual(s2.body.peers, ['ua']);
    await req(`/api/rooms/${id}/meeting`, { method: 'POST', t: B, body: { action: 'signal', to: 'ua', type: 'offer', data: { sdp: 'v=0' } } });
    const pa = await req(`/api/rooms/${id}/meeting`, { method: 'POST', t: A, body: { action: 'poll' } });
    assert.ok(pa.body.signals.some((x) => x.type === 'offer' && x.from === 'ub' && x.data.sdp === 'v=0'), 'the offer is relayed');
    await req(`/api/rooms/${id}/meeting`, { method: 'POST', t: B, body: { action: 'state', hand: true, screen: true } });
    const mv = await req(`/api/rooms/${id}`, { t: C }); assert.equal(mv.body.meeting.presenter, 'ub'); assert.equal(mv.body.meeting.participants.find((x) => x.uid === 'ub').hand, true);
    await req(`/api/rooms/${id}/meeting`, { method: 'POST', t: A, body: { action: 'mute', uid: 'ub' } });
    assert.ok((await req(`/api/rooms/${id}/meeting`, { method: 'POST', t: B, body: { action: 'poll' } })).body.signals.some((x) => x.type === 'mute'));
    await req(`/api/rooms/${id}/meeting`, { method: 'POST', t: A, body: { action: 'end' } });
    assert.equal((await req(`/api/rooms/${id}`, { t: A })).body.meeting, null);
    // 10. verified expert: apply → site owner verifies → room admin invites → joins as expert
    assert.equal((await req('/api/experts/apply', { method: 'POST', t: X, body: { bio: 'Ten years of gold and index trading, ex prop desk.', markets: 'gold, indices' } })).body.ok, true);
    assert.equal((await req('/api/rooms/admin', { method: 'POST', t: A, body: { action: 'expert', uid: 'ux' } })).status, 403, 'only site owners verify experts');
    assert.equal((await req('/api/rooms/admin', { method: 'POST', t: BOSS, body: { action: 'expert', uid: 'ux' } })).body.ok, true);
    await req(`/api/rooms/${id}`, { method: 'PATCH', t: A, body: { maxMembers: 10 } });
    const ei = await req(`/api/rooms/${id}/invite`, { method: 'POST', t: A, body: { expertUid: 'ux' } }); assert.equal(ei.body.role, 'expert');
    assert.equal((await req('/api/rooms/join', { method: 'POST', t: C, body: { code: ei.body.code } })).body.code, 'bad_invite', 'an expert invitation is personal');
    assert.equal((await req('/api/rooms/join', { method: 'POST', t: X, body: { code: ei.body.code } })).body.room.role, 'expert');
    assert.ok((await req('/api/experts', { t: C })).body.items.some((x) => x.uid === 'ux'));
    // 11. AI mentor + assistant: chosen by the room admin; without an AI key the server says so (no fake answer)
    assert.equal((await req(`/api/rooms/${id}/aiconfig`, { method: 'POST', t: B, body: { assistant: true } })).status, 403);
    assert.equal((await req(`/api/rooms/${id}/aiconfig`, { method: 'POST', t: A, body: { assistant: true, mentor: 'sara-smc' } })).body.ai.mentor, 'sara-smc');
    assert.equal((await req(`/api/rooms/${id}/ai`, { method: 'POST', t: B, body: { mode: 'summary' } })).body.code, 'not_configured');
    assert.ok((await req('/api/mentors', { t: C })).body.items.every((x) => !('prompt' in x)), 'mentor prompts stay on the server');
    // 12. history: messages, predictions, meetings are kept; the prediction resolves from the market
    await new Promise((r) => setTimeout(r, 300));
    const hist = await req(`/api/rooms/${id}?since=0`, { t: A });
    assert.ok(hist.body.messages.length >= 10); assert.equal(hist.body.predictions.length, 1);
    // report → site owner removes the message; suspend
    await req(`/api/rooms/${id}/report`, { method: 'POST', t: C, body: { mid, reason: 'spam' } });
    const adm = await req('/api/rooms/admin', { t: BOSS }); assert.ok(adm.body.reports.length >= 1); assert.equal((await req('/api/rooms/admin', { t: A })).status, 403);
    await req('/api/rooms/admin', { method: 'POST', t: BOSS, body: { action: 'report', id: adm.body.reports[0].id, deleteMessage: true } });
    assert.equal((await req(`/api/rooms/${id}/search?q=strong`, { t: C })).body.items.length, 0, 'removed by the site owner');
    await req('/api/rooms/admin', { method: 'POST', t: BOSS, body: { action: 'suspend', room: id } });
    assert.equal((await req(`/api/rooms/${id}/messages`, { method: 'POST', t: A, body: { text: 'x' } })).body.code, 'suspended');
    // dashboard + leaderboard
    const dash = await req('/api/rooms', { t: B }); assert.ok(dash.body.joined.some((r) => r.id === id) || dash.body.managed.some((r) => r.id === id));
    assert.ok(typeof (await req('/api/rooms/leaderboard', { t: B })).body.rules === 'string');
    // the data is on disk, encrypted (no plain text)
    await new Promise((r) => setTimeout(r, 200)); const raw = fs.readFileSync(path.join(dir, 'rooms.json'));
    assert.equal(raw.includes(Buffer.from('Gold Trading Society')), false); assert.equal(raw.includes(Buffer.from('private tip')), false);

    // Anonymous Strategy Arena: the server re-tests on its own candles; others never see the owner or the rules
    const spec = { name: 'my secret', symbol: 'BTCUSDT', tf: '1h', side: 'both', entry: [{ type: 'ema_cross', fast: 9, slow: 21, dir: 'up' }], exit: { stopAtr: 1.5, rr: 2, maxBars: 30 } };
    const sub = await req('/api/arena', { method: 'POST', t: B, body: { spec, results: { expR: 99 } } });
    assert.equal(sub.status, 200, JSON.stringify(sub.body)); assert.ok(sub.body.entry.oos.n >= 0); assert.notEqual(sub.body.entry.oos.expR, 99, 'results sent by a page are ignored');
    const other = await req('/api/arena', { t: C }); const e = other.body.items.find((x) => x.id === sub.body.entry.id);
    assert.ok(e); assert.equal(e.owner, null); assert.equal(e.rules, null); assert.equal(e.dnaId, null); assert.match(e.alias, /^STR-[0-9A-F]{6}$/);
    assert.equal(JSON.stringify(other.body).includes('ema_cross'), false); assert.equal(JSON.stringify(other.body).includes('Basel'), false);
    assert.ok((await req('/api/arena', { t: B })).body.items.find((x) => x.id === sub.body.entry.id).rules, 'the owner sees their own rules');
    await req(`/api/arena/${sub.body.entry.id}`, { method: 'POST', t: B, body: { action: 'reveal', on: true } });
    assert.equal((await req('/api/arena', { t: C })).body.items.find((x) => x.id === sub.body.entry.id).owner, 'Basel', 'revealed only by the owner');
    // account deletion removes memberships and arena entries
    assert.equal((await req('/api/user/account', { method: 'DELETE', t: C, body: { confirm: 'DELETE' } })).status, 200);
    assert.equal((await req(`/api/rooms/${id}`, { t: C })).status, 403);
  } finally { child.kill(); mock.close(); if (errOut.includes('Error')) console.log(errOut.slice(0, 800)); }
});

test('rooms: a prediction is resolved by the server from the market price, and the record is hash-chained', async () => {
  const { createRooms } = await import('../server/rooms.js');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rooms2-')); let clock = Date.UTC(2026, 10, 9, 12); let px = 2000;
  const R = createRooms({ dir, secret: 's'.repeat(40), now: () => clock, priceOf: async () => ({ price: px, at: clock, source: 'test' }), env: { NODE_ENV: 'test' } });
  const a = { uid: 'a', email: 'a@x', name: 'A' }; const id = R.create(a, { name: 'Room One', access: 'public' }).room.id;
  const p = (await R.predict(a, id, { symbol: 'XAUUSD', direction: 'down', target: 1990, horizonH: 2 })).prediction;
  const f = (await R.predict(a, id, { symbol: 'XAUUSD', direction: 'flat', band: 0.5, horizonH: 2 })).prediction;
  assert.equal(p.ref, 2000); assert.equal(await R.resolveDue(), 0, 'not before its time');
  clock += 2 * 3600_000 + 1; px = 1985;
  assert.equal(await R.resolveDue(), 2);
  const st = R.poll(a, id, 0).predictions;
  assert.deepEqual([st[0].result.hit, st[0].result.movePct, st[1].result.hit], [true, -0.75, false]);
  assert.ok(st[0].result.hash && st[0].hash !== st[0].result.hash);
  assert.equal(R.vote(a, id, p.id, { vote: 'bull' }).error, 'closed', 'no votes after the end');
  assert.equal(typeof R.editPrediction, 'undefined', 'there is no way to edit a prediction');
});
