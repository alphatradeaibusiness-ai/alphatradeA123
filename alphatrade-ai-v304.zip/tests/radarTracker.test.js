import test from 'node:test';
import assert from 'node:assert/strict';
import { makeOpp, stepOpp, trackerStats, WAIT_BARS, OPEN_BARS } from '../src/services/radarTracker.js';

const T0 = 1_762_000_000; const NOW = T0 * 1000;
const k = (i, h, l, c = (h + l) / 2) => ({ time: T0 + i * 300, open: c, high: h, low: l, close: c });
const reading = (over = {}) => ({ symbol: 'BTCUSDT', tf: '5m', direction: 'long', price: 100, precision: 2, mode: 'live', score: 82, atrPct: 1, strategy: 'smc',
  setup: { direction: 'long', entry: 99, stop: 97, targets: [101, 103, 105], status: 'pending' }, ...over });

test('a limit opportunity waits, fills on a real touch, banks a third per target and moves the stop to entry after TP1', () => {
  const o = makeOpp(reading(), { score: 82, grade: 'strong', parts: [] }, NOW);
  assert.equal(o.status, 'waiting'); assert.equal(o.order, 'limit'); assert.equal(o.entry, 99);
  let s = stepOpp(o, [k(0, 100.5, 99.5), k(1, 100.2, 99.2)], NOW);
  assert.equal(s.opp.status, 'waiting', 'not touched yet — detection is not a fill');
  s = stepOpp(s.opp, [k(2, 100, 98.8)], NOW); assert.equal(s.opp.status, 'triggered'); assert.deepEqual(s.events, ['entry']);
  s = stepOpp(s.opp, [k(3, 101.3, 99.6)], NOW); assert.equal(s.opp.status, 'tp1'); assert.equal(s.opp.closed, false);
  s = stepOpp(s.opp, [k(4, 100.5, 98.9)], NOW);   // back to the entry after TP1: closed at entry, +1/3 R banked
  assert.equal(s.opp.closed, true); assert.equal(s.opp.status, 'tp1'); assert.equal(s.opp.r, 0.333); assert.deepEqual(s.events, ['stopAtEntry']);
});

test('stop first when a bar touches both; cancelled when the stop trades before the entry; expiries', () => {
  const m = makeOpp(reading({ setup: { direction: 'long', entry: 100, stop: 98, targets: [102, 104, 106], status: 'active' } }), null, NOW);
  assert.equal(m.status, 'triggered'); assert.equal(m.entry, 100, 'market entry at the detection price');
  const both = stepOpp(m, [k(1, 102.5, 97.5)], NOW);
  assert.equal(both.opp.status, 'sl'); assert.equal(both.opp.r, -1);
  const c = stepOpp(makeOpp(reading({ setup: { direction: 'long', entry: 99, stop: 97, targets: [101, 103, 105], status: 'pending' } }), null, NOW), [k(1, 99.5, 96.5)], NOW);
  // the bar reaches the entry AND the stop: the stop came first is assumed (cancelled, no trade, 0 R)
  assert.equal(c.opp.status, 'cancelled'); assert.equal(c.opp.r, 0);
  const w = makeOpp(reading(), null, NOW);
  const never = Array.from({ length: WAIT_BARS + 1 }, (_, i) => k(i + 1, 101, 99.6));
  const e = stepOpp(w, never, NOW); assert.equal(e.opp.status, 'expired'); assert.equal(e.opp.r, 0);
  const long = Array.from({ length: OPEN_BARS + 2 }, (_, i) => k(i + 1, 100.8, 99.4, 100.4));
  const x = stepOpp(m, long, NOW); assert.equal(x.opp.status, 'expired'); assert.equal(x.opp.r, 0.2, 'closed at the last price: +0.4 / 2 R');
});

test('a full run to TP3 and an invalid plan', () => {
  const m = makeOpp(reading({ setup: { direction: 'long', entry: 100, stop: 98, targets: [102, 104, 106], status: 'active' } }), null, NOW);
  const s = stepOpp(m, [k(1, 102.2, 99.5), k(2, 104.1, 101), k(3, 106.5, 103)], NOW);
  assert.equal(s.opp.status, 'tp3'); assert.equal(s.opp.r, 2); assert.equal(s.opp.closed, true);
  assert.equal(makeOpp(reading({ price: 102.5, setup: { direction: 'long', entry: 100, stop: 98, targets: [102, 104, 106], status: 'active' } }), null, NOW), null, 'TP1 already passed');
  assert.equal(makeOpp(reading({ setup: { direction: 'long', entry: 99, stop: 101, targets: [101, 103, 105], status: 'pending' } }), null, NOW), null, 'stop on the wrong side');
  const atr = makeOpp(reading({ setup: null }), null, NOW); assert.equal(atr.plan, 'atr'); assert.equal(atr.stop, 98.5);
});

test('statistics: win rate, average R, profit factor, max drawdown, per market — completed live records only', () => {
  const mk = (r, status, at, symbol = 'BTCUSDT') => ({ closed: true, r, status, closedAt: at, triggeredAt: at - 1, symbol, tf: '5m', plan: 'smc' });
  const st = trackerStats([mk(2, 'tp3', 1), mk(-1, 'sl', 2), mk(-1, 'sl', 3), mk(0.333, 'tp1', 4, 'ETHUSDT'), { closed: true, r: 0, status: 'cancelled', closedAt: 5 }, { closed: false, status: 'waiting' }]);
  assert.equal(st.total, 6); assert.equal(st.open, 1); assert.equal(st.completed, 4); assert.equal(st.cancelled, 1);
  assert.equal(st.wins, 2); assert.equal(st.losses, 2); assert.equal(st.winRate, 50);
  assert.equal(st.profitFactor, 1.167); assert.equal(st.maxDrawdownR, 2); assert.equal(st.avgR, 0.083);
  assert.equal(st.byMarket.find((g) => g.key === 'ETHUSDT').winRate, 100);
  assert.equal(trackerStats([]).winRate, null, 'no fabricated percentage when nothing finished');
});
