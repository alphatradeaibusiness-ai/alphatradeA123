// Alpha Elite Signals over HTTP (v247): 401 signed out; the Elite scanner's file (written by the 24/7 worker) becomes the shared
// feed (signals, market availability, summary), no personal data in the answer; every new signal reaches every member once.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';

test('server: /api/elite/feed — signed-in members, shared live feed from the Elite scanner', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-el';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'google.com' } }));
    return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'elsrv-')); const certFile = path.join(dir, 'certs.json');
  const wdir = path.join(dir, 'worker'); fs.mkdirSync(wdir);
  const now = Date.now();
  const sig = (id, symbol, status, over = {}) => ({ id, symbol, market: symbol, category: symbol === 'BTCUSDT' ? 'bitcoin' : 'metal', tf: '1h', strategy: 'trend', direction: 'long', entryType: 'market', entry: 100, stop: 98, targets: [102, 104, 106], status, hits: 0, createdAt: now - 30_000, ...over });
  fs.writeFileSync(path.join(wdir, 'elite-signals.json'), JSON.stringify({ signals: [sig('e1', 'XAUUSD', 'entry_hit'), sig('e2', 'BTCUSDT', 'tp3', { hits: 3, filledAt: now - 20_000, closedAt: now - 5000 }), sig('old', 'XAUUSD', 'sl', { createdAt: now - 20 * 86_400_000, closedAt: now - 19 * 86_400_000 })], markets: { XAUUSD: { state: 'live' } }, lastScan: now }));
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'b'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, WORKER_DATA_DIR: wdir, ELITE_TEST: '1', AI_TEST_CERTS_FILE: certFile }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, t, bridge, origin = true } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : JSON.stringify(body);
    const headers = { ...(method !== 'GET' && origin ? { origin: O } : {}), ...(d ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}), ...(bridge ? { 'x-bridge-token': bridge } : {}) };
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => { let j = null; try { j = JSON.parse(s); } catch { /* text */ } resolve({ status: res.statusCode, body: j, text: s }); }); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  try {
    for (let i = 0; i < 80; i++) { try { if ((await req('/api/health')).status === 200) break; } catch { /* starting */ } await new Promise((r) => setTimeout(r, 100)); }
    assert.equal((await req('/api/elite/feed')).status, 401);
    const me = tok('m1', 'm1-private@mail.test');
    await new Promise((r) => setTimeout(r, 700));   // the server's own 20 s tick (500 ms in tests) runs without any visitor
    const f = await req('/api/elite/feed', { t: me });
    assert.equal(f.status, 200); assert.equal(f.body.configured, true);
    assert.deepEqual(f.body.signals.map((x) => x.id), ['e1', 'e2'], 'active + last 7 days of history');
    assert.equal(f.body.summary.open, 1); assert.equal(f.body.summary.closed, 1);
    const vix = f.body.markets.find((m) => m.id === 'VIX'); assert.equal(vix.state, 'unavailable'); assert.equal(vix.reason, 'not_tradable');
    assert.equal(f.body.markets.find((m) => m.id === 'XAUUSD').state, 'live');
    assert.equal(f.body.markets.some((m) => m.id === 'ETHUSDT'), false);
    assert.equal(JSON.stringify(f.body).includes('m1-private'), false);
  } finally { child.kill(); }
});

test('server v247: every new Elite signal is sent to every member automatically (notice + push / Telegram), once', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-el';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'google.com' } }));
    return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'elsrv-')); const certFile = path.join(dir, 'certs.json');
  const wdir = path.join(dir, 'worker'); fs.mkdirSync(wdir);
  const now = Date.now();
  const sig = (id, symbol) => ({ id, symbol, market: symbol, category: 'metal', tf: '1h', strategy: 'smc', direction: 'long', entryType: 'market', entry: 100, stop: 98, targets: [102, 104, 106], status: 'entry_hit', hits: 0, createdAt: Date.now() + 2000 });
  fs.writeFileSync(path.join(wdir, 'elite-signals.json'), JSON.stringify({ signals: [] }));
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'b'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, WORKER_DATA_DIR: wdir, ELITE_TEST: '1', AI_TEST_CERTS_FILE: certFile }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, t, bridge, origin = true } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : JSON.stringify(body);
    const headers = { ...(method !== 'GET' && origin ? { origin: O } : {}), ...(d ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}), ...(bridge ? { 'x-bridge-token': bridge } : {}) };
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => { let j = null; try { j = JSON.parse(s); } catch { /* text */ } resolve({ status: res.statusCode, body: j, text: s }); }); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  try {
    for (let i = 0; i < 80; i++) { try { if ((await req('/api/health')).status === 200) break; } catch { /* starting */ } await new Promise((r) => setTimeout(r, 100)); }
    const me = tok('m1', 'm1-private@mail.test');
    assert.equal((await req('/api/me/signin', { method: 'POST', t: me, body: { lang: 'ar' } })).status, 200, 'member signs in before any pick');
    await new Promise((r) => setTimeout(r, 2200));
    fs.writeFileSync(path.join(wdir, 'elite-signals.json'), JSON.stringify({ signals: [sig('n1', 'XAUUSD'), sig('n2', 'XAGUSD')] }));   // the scanner publishes
    await new Promise((r) => setTimeout(r, 1500));
    const f = await req('/api/elite/feed', { t: me }); const n = await req('/api/me/notices', { t: me });
    const elites = (n.body?.items || n.body?.notices || []).filter((x) => x.kind === 'elite');
    assert.equal(f.body.signals.length, 2); assert.equal(elites.length, 2, 'one notice per new signal');
    for (const x of elites) { assert.equal(x.title, 'Alpha Elite Signals'); assert.match(x.body, /^\u2068.+\u2069 · (شراء|بيع) · دخول \u2068/); assert.match(x.body, /الأهداف \u2068TP1 102\u2069 · \u2068TP2 104\u2069 · \u2068TP3 106\u2069$/); assert.equal(x.url, '/#/app/elite'); }
    await new Promise((r) => setTimeout(r, 1200));
    const n2 = await req('/api/me/notices', { t: me });
    assert.equal((n2.body?.items || n2.body?.notices || []).filter((x) => x.kind === 'elite').length, elites.length, 'never sent twice');
  } finally { child.kill(); }
});
