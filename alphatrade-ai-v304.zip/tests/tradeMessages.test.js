import { test } from 'node:test';
import assert from 'node:assert/strict';
import { tradeAlert, pairName, priceText, movePct } from '../src/services/tradeMessages.js';
import { alertParams } from '../server/tradeWatch.js';

const strip = (s) => s.replace(/[⁦⁩]/g, '');

test('pair names and prices', () => {
  assert.equal(pairName('XAUUSD'), 'XAU/USD');
  assert.equal(pairName('BTCUSDT'), 'BTC/USDT');
  assert.equal(pairName('EURJPY'), 'EUR/JPY');
  assert.equal(pairName('NATGAS'), 'NATGAS');
  assert.equal(pairName('GER40'), 'GER40');
  assert.equal(priceText('XAUUSD', 3926.92, 2), '$3,926.92');
  assert.equal(priceText('GER40', 18000.5, 1), '18,000.5');
  assert.equal(movePct('long', 100, 101.92), '+1.92%');
  assert.equal(movePct('short', 100, 101), '−1.00%');
});

test('TP1 alert says the stop moved to the entry (English, like the requested style)', () => {
  const m = tradeAlert('tp', { symbol: 'XAUUSD', direction: 'short', n: 1, price: 3926.92, entry: 3964.63545, precision: 2 }, 'en');
  assert.equal(m.title, 'Take Profit 1 Smashed! 🎯');
  assert.equal(strip(m.body), 'XAU/USD hit TP1 ($3,926.92)! Stop Loss moved to Entry ($3,964.64) — trade is now Risk-Free.');
});

test('final target shows the move from the entry', () => {
  const m = tradeAlert('final', { symbol: 'XAUUSD', direction: 'short', n: 3, price: 3888.62965, entry: 3964.63545, precision: 2 }, 'en');
  assert.equal(m.title, 'Target Smashed! 🚀');
  assert.match(strip(m.body), /^XAU\/USD hit its profit target at \$3,888\.63\. You secured a \+1\.92% move from entry!$/);
});

test('Arabic, stop, breakeven and trailing', () => {
  assert.equal(tradeAlert('tp', { symbol: 'BTCUSDT', direction: 'long', n: 1, price: 70030, entry: 70000 }, 'ar').title, 'تحقق الهدف 1! 🎯');
  assert.match(strip(tradeAlert('sl', { symbol: 'BTCUSDT', direction: 'long', entry: 70000, stop: 69940 }, 'ar').body), /69,940\.00 \(−0\.09%/);
  assert.match(tradeAlert('be', { symbol: 'BTCUSDT', direction: 'long', n: 2, entry: 70000 }, 'ar').body, /TP2/);
  assert.match(strip(tradeAlert('trail', { symbol: 'BTCUSDT', direction: 'long', price: 70100, entry: 70000 }, 'en').body), /\+0\.14% from entry/);
});

test('missing data falls back (null)', () => {
  assert.equal(tradeAlert('tp', { symbol: 'XAUUSD', n: 1, price: 1 }, 'en'), null);
  assert.equal(tradeAlert('nope', { symbol: 'XAUUSD', entry: 1, price: 1 }, 'en'), null);
});

test('server trade watch passes the hit level', () => {
  const x = { direction: 'long', entry: 100, stop: 99, targets: [101, 102, 103] };
  assert.equal(alertParams(x, { hits: 1 }, { kind: 'trade_target', n: 1 }).price, 101);
  assert.equal(alertParams(x, { hits: 3 }, { kind: 'trade_done' }).price, 103);
  assert.equal(alertParams(x, { hits: 1 }, { kind: 'trade_breakeven' }).price, undefined);
});
