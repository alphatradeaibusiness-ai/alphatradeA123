import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { createChannelAccess } from '../server/channelAccess.js';
import { createEntitlements } from '../server/entitlements.js';
import { createLedger } from '../server/ledger.js';

const DAY = 86_400_000;
test('entitlements: off by default; enforced → plan needed, monthly AI allowance with carry-over, channel-only has no AI', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'en-')); const access = createChannelAccess(dir);
  let t = Date.UTC(2026, 2, 15);
  const off = createEntitlements({ dir, access, env: {}, now: () => t });
  assert.equal(off.checkAi({ uid: 'a' }), null); assert.equal(off.canTradeAlerts('a'), true);
  const e = createEntitlements({ dir, access, env: { ENFORCE_PLANS: '1' }, now: () => t });
  assert.equal(e.checkAi({ uid: 'a' }), 'plan_required'); assert.equal(e.canTradeAlerts('a'), false);
  assert.equal(e.checkAi({ uid: 'a' }, { owner: true }), null); assert.equal(e.checkAi({ uid: 'a' }, { support: true }), null);
  access.grant('a', { product: 'quarterly', paymentId: 'p1', startsAt: t - DAY, until: t + 90 * DAY }, t);   // 60 / month, carry 1 month
  assert.equal(e.checkAi({ uid: 'a' }), null); assert.equal(e.aiAllowance('a').total, 60 + 60);   // nothing used last month → full carry
  for (let i = 0; i < 120; i++) e.countAi('a');
  assert.equal(e.checkAi({ uid: 'a' }), 'ai_quota');
  t = Date.UTC(2026, 3, 2);   // new month: last month fully used → no carry
  assert.equal(e.aiAllowance('a').total, 60); assert.equal(e.checkAi({ uid: 'a' }), null);
  access.grant('c', { product: 'channel', paymentId: 'p2', startsAt: t - DAY, until: t + 30 * DAY }, t);
  assert.equal(e.checkAi({ uid: 'c' }), 'platform_plan_required'); assert.equal(e.canTradeAlerts('c'), true);
  assert.equal(access.remove('a'), true); assert.equal(access.subscription('a', t), null);
  assert.equal(access.grant('a', { product: 'monthly', paymentId: 'p1', startsAt: t, until: t + DAY }, t).duplicate, true, 'used payment refs survive deletion');
});

test('ledger: one row per payment, masked e-mail, anonymised on deletion', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lg-')); const l = createLedger({ dir });
  assert.equal(l.add({ id: 'cs_1', uid: 'u', product: 'monthly', cents: 8000, email: 'someone@example.com', at: 1 }), true);
  assert.equal(l.add({ id: 'cs_1', uid: 'u', product: 'monthly', cents: 8000, at: 1 }), false);
  assert.equal(l.forUser('u')[0].email, 'so***@example.com'); assert.equal('uid' in l.forUser('u')[0], false);
  assert.equal(l.anonymise('u'), 1); assert.equal(l.forUser('u').length, 0); assert.equal(l.all()[0].cents, 8000); assert.equal(l.all()[0].uid, 'deleted');
});

test('server: AI needs a paid plan when enforced; a Stripe payment unlocks it; my subscription, export and account deletion', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-acc';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email, authAgo = 10) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - authAgo, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'password' } }));
    return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'acc-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const WH = 'whsec_testsecret0123456789abcdef';
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: certFile, ENFORCE_PLANS: '1', STRIPE_SECRET_KEY: 'sk_test_abcdefghijklmnop123', STRIPE_WEBHOOK_SECRET: WH }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, t, headers = {} } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : typeof body === 'string' ? body : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { ...(method !== 'GET' && !headers['stripe-signature'] ? { origin: O } : {}), ...(d ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}), ...headers } }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => { let j = null; try { j = JSON.parse(s); } catch { /* */ } resolve({ status: res.statusCode, body: j }); }); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  const ann = tok('ann', 'ann@example.com'); const owner = tok('own', 'shheahmad417@gmail.com');
  const chat = (t) => req('/api/ai/chat', { method: 'POST', t, body: { messages: [{ role: 'user', content: 'hi' }] } });
  try {
    for (let i = 0; i < 80; i++) { try { await req('/api/billing/status'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    let r = await chat(ann); assert.equal(r.status, 403); assert.equal(r.body.code, 'plan_required');
    assert.equal((await req('/api/ai/support', { method: 'POST', t: ann, body: { messages: [{ role: 'user', content: 'how much?' }] } })).body.code, 'not_configured', 'the help chat stays open');
    assert.equal((await chat(owner)).body.code, 'not_configured', 'owner is never limited');
    let me = (await req('/api/billing/me', { t: ann })).body; assert.equal(me.plan, null); assert.equal(me.enforce, true); assert.equal(me.payments.length, 0);
    // pay through Stripe (signed webhook)
    const raw = JSON.stringify({ type: 'checkout.session.completed', livemode: false, data: { object: { id: 'cs_test_acc1', object: 'checkout.session', mode: 'payment', payment_status: 'paid', client_reference_id: 'ann', metadata: { uid: 'ann', product: 'monthly' }, currency: 'usd', amount_total: 8000, customer_details: { email: 'ann@example.com' } } } });
    const ts = Math.floor(Date.now() / 1000); const sig = `t=${ts},v1=${crypto.createHmac('sha256', WH).update(`${ts}.${raw}`).digest('hex')}`;
    assert.equal((await req('/api/billing/webhook', { method: 'POST', body: raw, headers: { 'stripe-signature': sig } })).body.result, 'granted');
    r = await chat(ann); assert.equal(r.body.code, 'not_configured', 'past the plan gate');
    me = (await req('/api/billing/me', { t: ann })).body;
    assert.equal(me.plan, 'monthly'); assert.ok(me.subscription.until > Date.now() + 29 * DAY); assert.equal(me.ai.total, 30);
    assert.equal(me.payments.length, 1); assert.equal(me.payments[0].cents, 8000); assert.equal(me.payments[0].email, 'an***@example.com');
    const sum = (await req('/api/billing/admin/summary', { t: owner })).body; assert.equal(sum.test.total, 8000); assert.equal(sum.activeTotal, 1); assert.equal(sum.active.monthly, 1);
    assert.equal((await req('/api/billing/admin/summary', { t: ann })).status, 403);
    const ex = await req('/api/user/export', { t: ann }); assert.equal(ex.status, 200); assert.equal(ex.body.account.uid, 'ann'); assert.equal(ex.body.payments.length, 1); assert.equal(ex.body.subscription.subscription.product, 'monthly');
    // delete: needs the word, a fresh sign-in, and never the owner
    assert.equal((await req('/api/user/account', { method: 'DELETE', t: ann, body: {} })).body.code, 'confirm_required');
    assert.equal((await req('/api/user/account', { method: 'DELETE', t: tok('ann', 'ann@example.com', 3600), body: { confirm: 'DELETE' } })).body.code, 'reauth_required');
    assert.equal((await req('/api/user/account', { method: 'DELETE', t: owner, body: { confirm: 'DELETE' } })).body.code, 'owner_account');
    const del = await req('/api/user/account', { method: 'DELETE', t: ann, body: { confirm: 'DELETE' } }); assert.equal(del.body.ok, true); assert.equal(del.body.kept.paymentsAnonymised, 1);
    me = (await req('/api/billing/me', { t: ann })).body; assert.equal(me.plan, null); assert.equal(me.payments.length, 0);
    assert.equal((await chat(ann)).body.code, 'plan_required');
    assert.equal((await req('/api/billing/admin/summary', { t: owner })).body.test.total, 8000, 'amounts kept for bookkeeping');
  } finally { child.kill(); }
});
