// v260 Alpha Partner Club → Telegram: owner posts + pins the club button in the channel and sets the bot menu button.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';

test('HTTP: /api/partners/admin/telegram posts the button, pins it, sets the menu; owners only; token never leaks', async () => {
  const calls = []; let pendingStart = null; let member = false; let pendingJoin = null;
  const tg = http.createServer((q, s) => { let b = ''; q.on('data', (c) => (b += c)); q.on('end', () => { const m = q.url.split('/').pop().split('?')[0]; calls.push({ url: q.url, m, body: (() => { try { return JSON.parse(b || '{}'); } catch { return {}; } })() }); s.setHeader('content-type', 'application/json');
    if (m === 'createChatInviteLink') return s.end(JSON.stringify({ ok: true, result: { invite_link: 'https://t.me/+ApproveMe' } }));
    if (m === 'getMe') return s.end(JSON.stringify({ ok: true, result: { username: 'alpha_test_bot' } }));
    if (m.startsWith('getUpdates')) { const out = pendingStart ? [{ update_id: 1, message: { text: `/start ${pendingStart}`, chat: { id: 555, type: 'private' } } }] : pendingJoin ? [{ update_id: 2, chat_join_request: { chat: { id: -100555 }, from: { id: pendingJoin }, user_chat_id: pendingJoin } }] : []; pendingStart = null; pendingJoin = null; return s.end(JSON.stringify({ ok: true, result: out })); }
    if (m === 'getChatMember') return s.end(JSON.stringify({ ok: true, result: { status: JSON.parse(b).user_id === 555 && member ? 'member' : 'left' } }));
    if (m === 'pinChatMessage' && calls.filter((c) => c.m === 'pinChatMessage').length > 1) return s.end(JSON.stringify({ ok: false, description: 'Bad Request: not enough rights to pin a message' }));
    s.end(JSON.stringify({ ok: true, result: m === 'sendMessage' ? { message_id: 77 } : true })); }); }).listen(0);
  const tport = tg.address().port;
  const PROJECT = 'alphatrade-test'; const KID = 'k-tg'; const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const pl = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'password' } }));
    return `${h}.${pl}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${pl}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pct-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const port = 20000 + Math.floor(Math.random() * 20000); const TOKEN = '123456:SECRETbotTOKENvalue';
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: certFile, ADMIN_EMAILS: 'boss@site.test', TELEGRAM_BOT_TOKEN: TOKEN, TELEGRAM_CHAT_ID: '-100555', NOTIFY_TEST_TELEGRAM_BASE: `http://127.0.0.1:${tport}`, PUBLIC_URL: 'https://alphatrade.example', GROWTH_TEST: '1' }, stdio: 'ignore' });
  const origin = `http://127.0.0.1:${port}`;
  const req = (p, { method = 'GET', body, who } = {}) => new Promise((resolve, reject) => { const b = body == null ? null : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { origin, ...(who ? { authorization: `Bearer ${who}` } : {}), ...(b ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(b) } : {}) } }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(s || 'null'), raw: s })); });
    r.on('error', reject); if (b) r.write(b); r.end(); });
  try {
    for (let i = 0; i < 80; i++) { try { await req('/api/billing/status'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    assert.equal((await req('/api/partners/admin/telegram', { method: 'POST', who: tok('x', 'x@mail.test'), body: {} })).status, 403);
    const r = await req('/api/partners/admin/telegram', { method: 'POST', who: tok('boss', 'boss@site.test'), body: { lang: 'ar' } });
    assert.equal(r.status, 200); assert.deepEqual([r.body.post.ok, r.body.post.messageId, r.body.pin.ok, r.body.menu.ok], [true, 77, true, true]);
    const send = calls.find((c) => c.m === 'sendMessage'); assert.equal(send.body.chat_id, '-100555');
    assert.deepEqual(send.body.reply_markup.inline_keyboard[0][0], { text: '🏆 ALPHA PARTNER CLUB', url: 'https://alphatrade.example/#/app/partners' });
    assert.match(send.body.text, /ما في دخل مضمون/);
    assert.equal(calls.find((c) => c.m === 'pinChatMessage').body.message_id, 77);
    assert.deepEqual(calls.find((c) => c.m === 'setChatMenuButton').body.menu_button, { type: 'web_app', text: 'ALPHA PARTNER CLUB', web_app: { url: 'https://alphatrade.example/#/app/partners' } });
    const r2 = await req('/api/partners/admin/telegram', { method: 'POST', who: tok('boss', 'boss@site.test'), body: { lang: 'en', menu: false } });
    assert.equal(r2.body.pin.ok, false); assert.match(r2.body.pin.error, /not enough rights/); assert.equal(r2.raw.includes('SECRETbot'), false);
    assert.equal(calls.filter((c) => c.m === 'setChatMenuButton').length, 1, 'menu skipped when asked');
    const adm = await req('/api/partners/admin', { who: tok('boss', 'boss@site.test') }); assert.equal(adm.body.config.telegram.messageId, 77);
    // v261 gate: the club (menu + API) only for members of the Telegram channel
    const CU = tok('cu', 'cu@mail.test'); const BOSS = tok('boss', 'boss@site.test');
    await req('/api/partners/admin/config', { method: 'POST', who: BOSS, body: { enabled: true, gate: { telegram: true, inviteUrl: 'https://t.me/alpha_channel' } } });
    assert.equal((await req('/api/partners/admin/config', { method: 'POST', who: BOSS, body: { gate: { inviteUrl: 'https://evil.example/x' } } })).status, 409, 'invite must be a t.me link');
    let a = (await req('/api/partners/access', { who: CU })).body; assert.deepEqual([a.allowed, a.reason, a.inviteUrl], [false, 'tg_not_linked', 'https://t.me/alpha_channel']);
    assert.equal((await req('/api/partners/me', { who: CU })).body.gated, true);
    assert.equal((await req('/api/partners/join', { method: 'POST', who: CU })).body.code, 'telegram_required');
    const link = (await req('/api/me/telegram/link', { method: 'POST', who: CU })).body; pendingStart = new URL(link.url).searchParams.get('start');
    for (let i = 0; i < 40 && pendingStart; i++) await new Promise((r) => setTimeout(r, 100)); await new Promise((r) => setTimeout(r, 300));
    a = (await req('/api/partners/access?fresh=1', { who: CU })).body; assert.deepEqual([a.allowed, a.reason], [false, 'not_member'], 'linked but not in the channel');
    member = true; a = (await req('/api/partners/access?fresh=1', { who: CU })).body; assert.equal(a.allowed, true);
    assert.equal((await req('/api/partners/join', { method: 'POST', who: CU })).status, 200);
    assert.equal((await req('/api/partners/access', { who: BOSS })).body.allowed, true, 'owners always');
    // v262 channel gate through the real bot loop: a linked user WITHOUT a subscription asks to join → declined + told to subscribe
    assert.equal((await req('/api/tg-gate/admin', { who: CU })).status, 403);
    assert.equal((await req('/api/tg-gate/admin', { method: 'PUT', who: BOSS, body: { enabled: true } })).status, 200);
    assert.equal((await req('/api/tg-gate/admin/invite', { method: 'POST', who: BOSS, body: {} })).body.inviteLink, 'https://t.me/+ApproveMe');
    let me = (await req('/api/tg-gate/me', { who: CU })).body; assert.deepEqual([me.enabled, me.linked, me.active, me.inviteLink], [true, true, false, null]);
    pendingJoin = 555; for (let i = 0; i < 40 && !calls.some((c) => c.m === 'declineChatJoinRequest'); i++) await new Promise((r) => setTimeout(r, 100));
    assert.ok(calls.some((c) => c.m === 'declineChatJoinRequest' && c.body.user_id === 555), 'no subscription → declined');
    assert.ok(calls.some((c) => c.m === 'sendMessage' && c.body.chat_id === 555 && /pricing/.test(c.body.text)), 'told to subscribe');
    const st = (await req('/api/tg-gate/admin', { who: BOSS })).body; assert.equal(st.events.find((e) => e.type === 'declined').why, 'subscribe_first'); assert.equal(st.bot.canInvite, false, 'mock bot has no rights → shown');
  } finally { child.kill(); tg.close(); }
});
