import test from 'node:test';
import assert from 'node:assert/strict';
import { candleDelta, cvdSeries, flowRead, zScoreSeries, zPoints, classifyRegime, trailUpdate, returnCorrelation, correlatedExposure, efficiency } from '../src/services/quant.js';

const mk = (i, o, h, l, c, v = 100, bv = 50) => ({ time: 1000 + i * 60, open: o, high: h, low: l, close: c, volume: v, buyVolume: bv });

test('delta is buy minus sell volume, null without a split', () => {
  assert.equal(candleDelta(mk(0, 1, 1, 1, 1, 100, 70)), 40);
  assert.equal(candleDelta({ time: 1, open: 1, high: 1, low: 1, close: 1, volume: 5 }), null);
});

test('cvd accumulates delta', () => {
  const c = [mk(0, 1, 1, 1, 1, 100, 70), mk(1, 1, 1, 1, 1, 100, 30), mk(2, 1, 1, 1, 1, 100, 60)];
  assert.deepEqual(cvdSeries(c), [40, 0, 20]);
});

test('flowRead: absorption and cvd divergence on a long at a demand zone', () => {
  const c = [];
  // 15 candles drifting down, sellers aggressive (delta negative), CVD falling
  for (let i = 0; i < 15; i++) c.push(mk(i, 100 - i, 100.5 - i, 99 - i, 99.5 - i, 100, 40));
  // candle 15: new low, but buyers step in aggressively: closes high in range, delta positive -> cvd higher than the 12-candle min? make delta mildly positive
  c.push(mk(15, 85, 85.5, 83, 85.2, 100, 90));
  const cvd = cvdSeries(c);
  const r = flowRead(c, cvd, 15, 'long');
  assert.equal(r.ok, true);
  assert.ok(r.kinds.includes('cvdDiv'), 'new low with higher CVD');
  assert.ok(r.kinds.includes('imbalance'), 'strong buy delta');
  assert.ok(r.points >= 12 && r.points <= 15);
  // same candle read as a short finds nothing
  assert.equal(flowRead(c, cvd, 15, 'short').points, 0);
});

test('flowRead reports not available without taker volume', () => {
  const c = Array.from({ length: 30 }, (_, i) => ({ time: i, open: 1, high: 2, low: 0.5, close: 1.5, volume: 10 }));
  assert.equal(flowRead(c, cvdSeries(c), 20, 'long').ok, false);
});

test('z-score and points', () => {
  const closes = Array.from({ length: 60 }, (_, i) => 100 + Math.sin(i / 3));
  closes[59] = 90;
  const z = zScoreSeries(closes, 50);
  assert.ok(z[59] < -2);
  assert.equal(zPoints(z[59], 'long'), 10);
  assert.equal(zPoints(z[59], 'short'), 0);
  assert.equal(zPoints(null, 'long'), 0);
});

test('regime: trend, range and spike', () => {
  const n = 120;
  const trend = Array.from({ length: n }, (_, i) => mk(i, 100 + i, 100.6 + i, 99.8 + i, 100.5 + i));
  const closes = trend.map((x) => x.close);
  const atr = trend.map(() => 1);
  assert.equal(classifyRegime(trend, atr, closes, 100), 'trend');
  const range = Array.from({ length: n }, (_, i) => mk(i, 100, 100.6, 99.4, 100 + (i % 2 ? 0.3 : -0.3)));
  assert.equal(classifyRegime(range, atr, range.map((x) => x.close), 100), 'range');
  const spike = range.map((x) => ({ ...x }));
  spike[100] = mk(100, 100, 110, 99, 109);
  assert.equal(classifyRegime(spike, atr, spike.map((x) => x.close), 100), 'spike');
  assert.ok(efficiency(closes, 100) > 0.9);
});

test('ATR trail follows price after TP1 and never moves back', () => {
  const t = { direction: 'long', entry: 100, stop: 100, risk: 3, atrE: 2, hits: 1 };
  const o = { trailAtr: 1.5 };
  assert.equal(trailUpdate(t, { high: 106, low: 104 }, o), false);
  assert.equal(t.stop, 103); // 106 - 1.5*2
  trailUpdate(t, { high: 105, low: 104 }, o);
  assert.equal(t.stop, 103); // no retreat
  assert.equal(trailUpdate(t, { high: 107, low: 104.5 }, o), false);
  assert.equal(t.stop, 104);
  // same candle also reaches the new stop: assume stopped
  assert.equal(trailUpdate(t, { high: 110, low: 106.5 }, o), true);
  // short
  const s = { direction: 'short', entry: 100, stop: 100, risk: 3, atrE: 2, hits: 1 };
  trailUpdate(s, { high: 96, low: 94 }, o);
  assert.equal(s.stop, 97);
  // off by default / before TP1
  const f = { direction: 'long', entry: 100, stop: 97, risk: 3, atrE: 2, hits: 0 };
  assert.equal(trailUpdate(f, { high: 110, low: 100 }, o), false);
  assert.equal(f.stop, 97);
  assert.equal(trailUpdate({ ...t, hits: 1 }, { high: 120, low: 119 }, { trailAtr: 0 }), false);
});

test('correlation of two aligned series and the exposure check', () => {
  const a = []; const b = []; const c = [];
  let pa = 100; let pb = 50; let pc = 80;
  for (let i = 0; i < 120; i++) {
    const r = Math.sin(i * 1.3) * 0.01;
    pa *= 1 + r; pb *= 1 + r * 0.9; pc *= 1 - r;
    a.push({ time: i, close: pa }); b.push({ time: i, close: pb }); c.push({ time: i, close: pc });
  }
  assert.ok(returnCorrelation(a, b) > 0.95);
  assert.ok(returnCorrelation(a, c) < -0.95);
  const corr = (x, y) => (x === 'A' && y === 'B') || (x === 'B' && y === 'A') ? 0.9 : (x === 'A' && y === 'C') ? -0.9 : 0.1;
  const active = [{ symbol: 'B', direction: 'long' }];
  assert.ok(correlatedExposure({ symbol: 'A', direction: 'long' }, active, corr));
  assert.equal(correlatedExposure({ symbol: 'A', direction: 'short' }, active, corr), null);
  assert.ok(correlatedExposure({ symbol: 'A', direction: 'short' }, [{ symbol: 'C', direction: 'long' }], corr)); // negative corr, opposite direction
  assert.equal(correlatedExposure({ symbol: 'A', direction: 'long' }, [{ symbol: 'A', direction: 'long' }], corr), null);
});
