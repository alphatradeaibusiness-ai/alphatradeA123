// The app shell finds a route's hub from hubMap.js without loading hub.js; both must list the same tabs and aliases.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { HUB_TABS, hubOf } from '../src/pages/tools/hubMap.js';

test('hubMap matches the HUBS block of hub.js (every hub, every tab id, in order)', () => {
  const src = fs.readFileSync(new URL('../src/pages/tools/hub.js', import.meta.url), 'utf8');
  const block = src.slice(src.indexOf('export const HUBS = {'), src.indexOf('const TAB_OF'));
  const found = {}; let cur = null;
  for (const line of block.split('\n')) {
    const h = /^  (\w+): \{ icon:/.exec(line); if (h) { cur = h[1]; found[cur] = []; continue; }
    const tab = /^    \{ id: '([\w-]+)'/.exec(line); if (tab && cur) found[cur].push(tab[1]);
  }
  assert.deepEqual(found, HUB_TABS);
  assert.ok(Object.keys(found).length >= 5);
});
test('hubOf resolves ids and old aliases', () => {
  assert.deepEqual(hubOf('radar-heat'), { hub: 'radar', id: 'radar' }, 'removed tab opens the radar');
  assert.deepEqual(hubOf('performance'), { hub: 'lab', id: 'lab' });
  assert.equal(hubOf('bank'), null);
});
