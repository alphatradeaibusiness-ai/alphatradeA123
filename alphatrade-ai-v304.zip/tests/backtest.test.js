import { test } from 'node:test';
import assert from 'node:assert/strict';
import { backtestClassic, backtestSmc, summarize } from '../src/services/backtest.js';
import { generateDemoCandles } from '../src/services/market/demo.js';

const bar = (time, o, h, l, c) => ({ time, open: o, high: h, low: l, close: c, volume: 1, buyVolume: 0.5 });

test('summarize: wins, losses, months and points', () => {
  const t = (closeTime, hits, points, outcome = hits ? 'tp1' : 'sl') => ({ closeTime, hits, points, outcome });
  const jan = Date.UTC(2026, 0, 15) / 1000;
  const feb = Date.UTC(2026, 1, 10) / 1000;
  const s = summarize([t(jan, 0, -30), t(jan, 1, 16.7, 'be'), t(feb, 3, 86.7, 'tp3'), t(feb, 0, 12, 'reversed')]);
  assert.equal(s.total.trades, 4);
  assert.equal(s.total.wins, 3); // a win = net profit after fees
  assert.equal(s.total.losses, 1);
  assert.equal(s.months[0].month, '2026-02');
  assert.equal(s.months[1].wins, 1);
  assert.ok(Math.abs(s.total.points - 85.4) < 1e-9);
  assert.equal(s.equity.at(-1).value, s.total.points);
});

test('classic trade management: stop first, breakeven after TP1, thirds per target', () => {
  // Flat warm-up then a clean rally: the first long trade should reach TP3.
  const cs = [];
  let p = 100;
  for (let i = 0; i < 260; i++) { p += (i % 2 ? 0.3 : -0.3); cs.push(bar(i * 60, p, p + 0.5, p - 0.5, p)); }
  for (let i = 260; i < 340; i++) { p += 3; cs.push(bar(i * 60, p - 3, p + 0.5, p - 3.2, p)); }
  const { trades } = backtestClassic(cs, { pointSize: 0.1, volumeKind: 'synthetic', stopMode: 'points', trendFilter: false, tpGapPts: 0, tp3GapPts: 0 });
  assert.ok(trades.length > 0);
  for (const tr of trades) {
    if (tr.outcome === 'sl') assert.ok(Math.abs(tr.points + 30) < 1e-6, 'a stop before TP1 loses exactly 30 points');
    if (tr.outcome === 'tp3') assert.ok(Math.abs(tr.points - (50 + 80 + 130) / 3) < 1e-6);
    if (tr.outcome === 'be') assert.ok(tr.points > 0);
  }
  assert.ok(trades.some((tr) => tr.outcome === 'tp3'));
});

test('backtests run on demo history and give consistent summaries', () => {
  const cs = generateDemoCandles('BTCUSDT', '1h', 900, Date.UTC(2026, 5, 1));
  const t0 = Date.now();
  const a = backtestClassic(cs, { pointSize: 1, volumeKind: 'synthetic' });
  const b = backtestSmc(cs, { pointSize: 1 });
  const ms = Date.now() - t0;
  for (const r of [a, b]) {
    const s = summarize(r.trades);
    assert.equal(s.total.wins + s.total.losses, s.total.trades);
    assert.equal(s.months.reduce((x, m) => x + m.trades, 0), s.total.trades);
    for (const tr of r.trades) assert.ok(tr.closeTime >= tr.openTime);
  }
  assert.ok(b.trades.every((tr) => tr.strategy === 'smc'));
  console.log(`classic ${a.trades.length} trades, smc ${b.trades.length} trades, ${ms} ms for 900 bars`);
});

test('ATR mode: stop is atrMult x ATR and targets are R multiples; trades only on signals', () => {
  const cs = generateDemoCandles('BTCUSDT', '1h', 900, Date.UTC(2026, 5, 1));
  const { trades } = backtestClassic(cs, { pointSize: 1, volumeKind: 'synthetic', feePct: 0, tpGapPts: 0, tp3GapPts: 0 });
  const hi = backtestClassic(cs, { pointSize: 1, volumeKind: 'synthetic', feePct: 0, firstTargetR: 0.35, tpGapPts: 0, tp3GapPts: 0 }).trades;
  assert.ok(hi.every((tr) => Math.abs(Math.abs(tr.targets[0] - tr.entry) - 0.35 * tr.risk) < 1e-6));
  assert.ok(summarize(hi).total.winRate >= summarize(trades).total.winRate);
  assert.ok(trades.length > 0);
  for (const tr of trades) {
    const s = tr.direction === 'long' ? 1 : -1;
    [1, 2, 3.5].forEach((m, k) => assert.ok(Math.abs((tr.targets[k] - tr.entry) * s - m * tr.risk) < 1e-6));
    assert.ok(Math.abs((tr.entry - tr.initialStop) * s - tr.risk) < 1e-6);
    if (tr.outcome === 'sl') assert.ok(Math.abs(tr.r + 1) < 1e-9, 'a full stop loses 1R');
  }
  // fees reduce every trade by the same percentage of price
  const f = backtestClassic(cs, { pointSize: 1, volumeKind: 'synthetic', feePct: 0.1, tpGapPts: 0, tp3GapPts: 0 }).trades;
  assert.equal(f.length, trades.length);
  assert.ok(Math.abs((trades[0].points - f[0].points) - 0.001 * trades[0].entry) < 1e-6);
});

test('openOnLast=false never opens a trade on the forming candle', () => {
  const cs = generateDemoCandles('ETHUSDT', '15m', 600, Date.UTC(2026, 5, 1));
  for (let n = 400; n < 600; n += 7) {
    const r = backtestClassic(cs.slice(0, n), { pointSize: 0.1, volumeKind: 'synthetic', openOnLast: false });
    if (r.open) assert.ok(r.open.openTime < cs[n - 1].time);
  }
});

test('htfTrend uses only closed higher-timeframe bars (no look-ahead)', async () => {
  const { htfTrend } = await import('../src/services/backtest.js');
  const cs = generateDemoCandles('BTCUSDT', '1h', 800, Date.UTC(2026, 5, 1));
  const full = htfTrend(cs, 4, 50);
  // Changing future candles must not change earlier values.
  const cut = 600;
  const altered = cs.slice(0, cut).concat(cs.slice(cut).map((c) => ({ ...c, close: c.close * 3, high: c.high * 3, low: c.low * 3 })));
  const b = htfTrend(altered, 4, 50);
  for (let i = 0; i < cut; i++) assert.equal(b[i], full[i]);
});

test('Target 2 sits 50 points beyond Target 1 and Target 3 30 points beyond Target 2 (applyTpGap)', async () => {
  const { applyTpGap, backtestClassic, backtestEdh, DEFAULT_RULES } = await import('../src/services/backtest.js');
  assert.equal(DEFAULT_RULES.tpGapPts, 50); assert.equal(DEFAULT_RULES.tp3GapPts, 30);
  // long: TP3 keeps its own distance beyond TP2 (here 300 > 50)
  assert.deepEqual(applyTpGap('long', [1000, 1200, 1500], 1), [1000, 1050, 1080]);        // 50 then 30
  assert.deepEqual(applyTpGap('long', [1000, 1200, 1500], 1, 50, 0), [1000, 1050, 1350]);  // TP3 gap off: keeps its own distance
  // short and a pointSize of 0.1: 50 points = 5 price units; TP3 never closer than the same gap
  const s = applyTpGap('short', [100, 98, 97.9], 0.1);
  assert.ok(Math.abs(s[1] - 95) < 1e-9 && s[0] === 100 && Math.abs(s[2] - 92) < 1e-9);
  assert.deepEqual(applyTpGap('long', [1000, 1200, 1500], 1, 0, 0), [1000, 1200, 1500]);   // both 0 = off
  // classic ATR mode on a real run
  const cs = generateDemoCandles('BTCUSDT', '1h', 900, Date.UTC(2026, 5, 1));
  const { trades } = backtestClassic(cs, { pointSize: 1, volumeKind: 'synthetic', feePct: 0 });
  assert.ok(trades.length > 0);
  for (const tr of trades) { const s2 = tr.direction === 'long' ? 1 : -1; assert.ok(Math.abs((tr.targets[1] - tr.targets[0]) * s2 - 50) < 1e-6); assert.ok(Math.abs((tr.targets[2] - tr.targets[1]) * s2 - 30) < 1e-6); }
});
