// v253 live liquidity map engine: local order book sync, bucketing, wall tracking, anomaly radar (real candles).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { LocalBook, niceStep, bucket, imbalance, WallTracker, anomalyOf } from '../src/services/orderBook.js';

test('local book: snapshot + diffs, old events ignored, a sequence gap asks for a resync', () => {
  const b = new LocalBook();
  b.apply({ U: 99, u: 101, b: [['100', '1']], a: [] });                       // buffered before the snapshot
  assert.equal(b.snapshot({ lastUpdateId: 100, bids: [['99', '2'], ['98', '1']], asks: [['101', '3']] }), true);
  assert.equal(b.bids.get(100), 1);                                            // the buffered event (u 101 > 100) was replayed
  assert.equal(b.apply({ U: 50, u: 60, b: [['97', '9']], a: [] }), true); assert.equal(b.bids.has(97), false);
  assert.equal(b.apply({ U: 102, u: 103, b: [['99', '0']], a: [['101', '5']] }), true);
  assert.equal(b.bids.has(99), false); assert.equal(b.asks.get(101), 5);
  assert.deepEqual(b.best(), { bid: 100, ask: 101 });
  assert.equal(b.apply({ U: 110, u: 111, b: [], a: [] }), false); assert.equal(b.ready, false);
});

test('bucketing and imbalance', () => {
  assert.equal(niceStep(80000, 2), 20); assert.equal(niceStep(1.1, 2), 0.0002);
  const book = { bids: new Map([[99.95, 2], [99.91, 6], [90, 100]]), asks: new Map([[100.05, 1], [100.06, 4]]) };
  const r = bucket(book, 100, 0.1, 2);
  assert.equal(r.bins.get(99.9).bid, 8); assert.equal(r.bins.get(100).ask, 5); assert.equal([...r.bins.keys()].includes(90), false);
  const im = imbalance(book, 100, 1); assert.ok(im.imb > 0 && im.bid > im.ask);
});

test('wall tracker: refill, absorption by real trades, then broken vs pulled', () => {
  const mk = (bidWall, askWall) => { const bins = new Map(); for (let i = -10; i <= 10; i++) { const p = 100 + i; bins.set(p, { bid: i < 0 ? 1 : 0, ask: i > 0 ? 1 : 0 }); } if (bidWall != null) bins.get(95).bid = bidWall; if (askWall != null) bins.get(105).ask = askWall; return { bins, step: 1 }; };
  const w = new WallTracker({ mult: 4 }); let t = 0;
  w.update(mk(20, 30), 100, (t += 1000));
  assert.equal(w.list().active.length, 2);
  w.update(mk(10, 30), 100, (t += 1000)); w.update(mk(20, 30), 100, (t += 1000));   // dropped then came back
  const bidW = w.list().active.find((x) => x.side === 'bid'); assert.equal(bidW.refills, 1);
  w.trade({ price: 105.5, qty: 3, buy: true }); w.trade({ price: 105.5, qty: 2, buy: false });   // only the aggressive buy hits an ask wall
  assert.equal(w.list().active.find((x) => x.side === 'ask').absorbed, 3); assert.equal(w.absorbed.buy, 3);
  w.update(mk(20, null), 106.5, (t += 5000));                                    // price went through the ask wall → broken
  w.update(mk(null, null), 100, (t += 5000));                                     // bid wall vanished while price was far → pulled
  const s = w.list().stats; assert.equal(s.broken, 1); assert.equal(s.pulled, 1); assert.equal(w.list().active.length, 0);
});

test('anomaly radar on real candles: a normal candle scores low, a forced shock scores high', () => {
  const FX = JSON.parse(fs.readFileSync(new URL('./fixtures/lab-real.json', import.meta.url), 'utf8'));
  const c = FX.btc1h.slice(-120).map(([time, open, high, low, close]) => ({ time, open, high, low, close, volume: 0 }));
  const base = anomalyOf(c); assert.ok(base && base.score >= 0 && base.score <= 100); assert.equal(base.volZ, null);
  const last = c.at(-1); const shock = [...c.slice(0, -1), { ...last, high: last.open * 1.06, low: last.open * 0.97, close: last.open * 1.05 }];
  const a = anomalyOf(shock); assert.ok(a.score > base.score && a.score >= 60, `${a.score}`); assert.ok(a.rangeZ > 3);
  assert.equal(anomalyOf(c.slice(0, 30)), null);
});

import { orderFlowRead, SetupTracker } from '../src/services/orderBook.js';
test('order-flow read: buy setup only when the wall is stable, defended, buyers lead and there is room', () => {
  const now = 1_000_000; const mid = 100; const step = 0.01;
  const cols = Array.from({ length: 60 }, (_, i) => ({ t: now - (60 - i) * 1000, cvd: i * 2, buy: 3, sell: 1 }));
  const bidWall = { side: 'bid', price: 99.8, step, first: now - 60_000, last: now, absorbed: 5, refills: 1, size: 50 };
  const askWall = { side: 'ask', price: 101, step, first: now - 60_000, last: now, absorbed: 0, refills: 0, size: 40 };
  const base = { mid, step, cols, im: { imb: 0.2 }, spread: 0.01, spreadMed: 0.01, now };
  const r = orderFlowRead({ ...base, walls: { active: [bidWall, askWall], done: [] } });
  assert.equal(r.state, 'buy_setup'); assert.ok(r.best.stop < 99.8 && r.best.target < 101 && r.best.rr >= 1.5);
  // the same, but the wall is fresh (10 s) → no stable support
  assert.notEqual(orderFlowRead({ ...base, walls: { active: [{ ...bidWall, first: now - 10_000 }, askWall], done: [] } }).state, 'buy_setup');
  // sellers lead (CVD falling) → not a buy
  assert.notEqual(orderFlowRead({ ...base, cols: cols.map((c, i) => ({ ...c, cvd: -i })), walls: { active: [bidWall, askWall], done: [] } }).state, 'buy_setup');
  // spread blow-out → no trade whatever the rest says
  const nt = orderFlowRead({ ...base, spread: 0.05, walls: { active: [bidWall, askWall], done: [] } }); assert.equal(nt.state, 'no_trade'); assert.ok(nt.blockers.length);
  assert.equal(orderFlowRead({ ...base, cols: cols.slice(0, 10), walls: { active: [], done: [] } }).state, 'collecting');
  // a bid wall broke 20 s ago → condition 6 fails
  const rb = orderFlowRead({ ...base, walls: { active: [bidWall, askWall], done: [{ side: 'bid', status: 'broken', end: now - 20_000 }] } });
  assert.equal(rb.long.checks.find((c) => c.id === 'nobreak').ok, false);
});
test('setup tracker: stop wins a tie, target counts, one open idea per side', () => {
  const t = new SetupTracker(); const read = { best: { dir: 1, stop: 99, target: 102, rr: 2 } };
  assert.ok(t.add(read, 100, 1)); assert.equal(t.add(read, 100, 2), null);
  t.price(98.9, 102.5, 3); assert.equal(t.items[0].result.kind, 'stop');
  t.add(read, 100, 4); t.price(100, 102.1, 5); assert.equal(t.items[0].result.kind, 'target');
  assert.deepEqual([t.stats().wins, t.stats().losses], [1, 1]);
});
