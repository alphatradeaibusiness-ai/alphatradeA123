// v150 bank features at the service level: pockets, labels, vault, freeze, passkeys, co-signers, virtual cards and their
// authorisation, budgets, saving rules, subscriptions, rewards, conversion, cross-border, open banking, insights, tax,
// support, notifications and Web Push encryption. Every test ends with the ledger check.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { openDb } from '../server/bank/db.js';
import { createVault } from '../server/bank/vault.js';
import { createBank } from '../server/bank/service.js';
import { decryptPayload } from '../server/bank/webpush.js';
import { makeAuthenticator } from './helpers/fakeAuthenticator.js';

const OWNER = { uid: 'owner' };
const DAY = 86400_000;
const GOOD_IBAN = 'DE89370400440532013000';
const GB_IBAN = 'GB82WEST12345698765432';
const ADDR = { country: 'DE', region: 'BE', city: 'Berlin', postal: '10115', line1: 'Invalidenstrasse 1' };
const RP = { rpId: 'localhost', origins: ['http://localhost'] };

function setup({ mode = 'sandbox', start = Date.UTC(2026, 9, 27, 12), ...extra } = {}) {
  let t = start; const db = openDb(':memory:'); const pushes = [];
  const bank = createBank({
    db, vault: createVault({ secret: 'z'.repeat(40) }), mode, now: () => t,
    priceFn: async () => ({ price: 50000, ts: t }),
    rateFn: async () => ({ usdPer: { USD: 1, EUR: 1.1, USDT: 1, BTC: 50000 }, ts: t, sources: {} }),
    pushSender: async (sub, payload) => { pushes.push({ sub, payload }); return { ok: true }; },
    config: { beneficiaryCooldown: 1000 }, ...extra,
  });
  return { db, bank, pushes, tick: (ms) => { t += ms; }, now: () => t };
}
const kyc = (b, uid, tier = 1) => {
  if (tier === 2 && b.kycStatus(uid).tier < 1) kyc(b, uid, 1);
  if (b.kycStatus(uid).tier >= tier) return;
  b.submitKyc(uid, { tier, fullName: 'Ada Lovelace', dob: '1990-05-05', nationality: 'DE', address: ADDR, idType: 'passport', idNumber: 'C' + Buffer.from(String(uid)).toString('hex').slice(0, 14), idExpiry: '2031-01-01', sourceOfFunds: 'salary', proofOfAddressRef: 'vend-123' });
  b.reviewKyc(OWNER, uid, 'approve');
};
let n = 0; const k = () => `key-${++n}-abcdef`;
const fund = (b, uid, cur, amt) => b.sandboxFund(uid, { currency: cur, amount: amt, idem: k() });
const bal = (b, uid, cur) => b.wallet(uid).find((w) => w.currency === cur);
const code = (fn) => { try { fn(); } catch (e) { return e.code; } return 'NO_ERROR'; };
const acode = async (fn) => { try { await fn(); } catch (e) { return e.code; } return 'NO_ERROR'; };
const ok = (bank) => assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });

test('migration: a v149 database (accounts without sub/pocket kinds) is rebuilt with every balance intact', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bank-mig-'));
  const old = new DatabaseSync(`${dir}/bank.db`);
  old.exec(`CREATE TABLE accounts (id TEXT PRIMARY KEY, owner TEXT NOT NULL, currency TEXT NOT NULL, kind TEXT NOT NULL CHECK (kind IN ('wallet','hold','system')),
    balance INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, UNIQUE (owner, currency, kind), CHECK (kind = 'system' OR balance >= 0));
    CREATE TABLE txns (id TEXT PRIMARY KEY, type TEXT NOT NULL, status TEXT NOT NULL, uid TEXT, currency TEXT NOT NULL, amount INTEGER NOT NULL, idem TEXT, ext_ref TEXT, meta TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
    CREATE TABLE entries (id INTEGER PRIMARY KEY AUTOINCREMENT, txn_id TEXT NOT NULL REFERENCES txns(id), account_id TEXT NOT NULL REFERENCES accounts(id), delta INTEGER NOT NULL);
    INSERT INTO accounts VALUES ('a1','u1','USD','wallet',700,1),('a2','platform:sandbox','USD','system',-700,1);
    INSERT INTO txns VALUES ('t1','sandbox_credit','completed','u1','USD',700,NULL,NULL,'{}',1,1);
    INSERT INTO entries (txn_id, account_id, delta) VALUES ('t1','a2',-700),('t1','a1',700);`);
  old.close();
  const db = openDb(dir);
  assert.equal(db.prepare('PRAGMA user_version').get().user_version, 4);
  assert.ok(db.prepare('PRAGMA table_info(accounts)').all().some((c) => c.name === 'sub'));
  const bank = createBank({ db, vault: createVault({ secret: 'z'.repeat(40) }) });
  assert.equal(bal(bank, 'u1', 'USD').available, 700); ok(bank);
  const p = bank.pockets.createPocket('u1', { name: 'Trip', currency: 'USD' });
  bank.pockets.movePocket('u1', { pocketId: p.id, direction: 'in', amount: '3', idem: k() }); ok(bank);
  db.close(); fs.rmSync(dir, { recursive: true, force: true });
});

test('pockets: create, move in/out, spendable excludes pockets, cannot overdraw, cannot delete when not empty', () => {
  const { bank } = setup(); fund(bank, 'u1', 'USD', '100');
  const p = bank.pockets.createPocket('u1', { name: 'Holiday', currency: 'USD', goal: '500', color: 'teal' });
  bank.pockets.movePocket('u1', { pocketId: p.id, direction: 'in', amount: '40', idem: k() });
  assert.equal(bal(bank, 'u1', 'USD').available, 6000); assert.equal(bal(bank, 'u1', 'USD').pockets, 4000);
  assert.equal(code(() => bank.pockets.movePocket('u1', { pocketId: p.id, direction: 'out', amount: '41', idem: k() })), 'insufficient_funds');
  assert.equal(code(() => bank.pockets.deletePocket('u1', p.id)), 'pocket_not_empty');
  assert.equal(code(() => bank.pockets.movePocket('u2', { pocketId: p.id, direction: 'out', amount: '1', idem: k() })), 'pocket_not_found');   // isolation
  bank.pockets.movePocket('u1', { pocketId: p.id, direction: 'out', amount: '40', idem: k() });
  assert.deepEqual(bank.pockets.deletePocket('u1', p.id), { ok: true });
  for (let i = 0; i < 10; i++) bank.pockets.createPocket('u1', { name: `P${i}`, currency: 'EUR' });
  assert.equal(code(() => bank.pockets.createPocket('u1', { name: 'one more', currency: 'EUR' })), 'too_many_pockets');
  ok(bank);
});

test('labels: category, tags and an encrypted note; filter by category; nobody else can label my transaction', () => {
  const { bank, db } = setup(); const f = fund(bank, 'u1', 'USD', '10');
  bank.pockets.setLabel('u1', f.txn, { category: 'income', tags: ['test', 'gift'], note: 'from grandma — secret note' });
  const h = bank.history('u1', { category: 'income' });
  assert.equal(h.items.length, 1); assert.equal(h.items[0].label.note, 'from grandma — secret note'); assert.deepEqual(h.items[0].label.tags, ['test', 'gift']);
  assert.equal(bank.history('u1', { category: 'dining' }).items.length, 0);
  assert.equal(bank.history('u1', { tag: 'gift' }).items.length, 1);
  assert.ok(!JSON.stringify(db.prepare('SELECT * FROM txn_labels').all()).includes('grandma'));
  assert.equal(code(() => bank.pockets.setLabel('u2', f.txn, { category: 'other' })), 'not_found');
  assert.equal(code(() => bank.pockets.setLabel('u1', f.txn, { tags: ['<script>'] })), 'bad_tag');
});

test('vault: in instantly, out only after the 24 h lock; cancel works; a frozen account keeps the lock', () => {
  const { bank, tick } = setup(); fund(bank, 'u1', 'USDT', '100');
  bank.pockets.vaultDeposit('u1', { currency: 'USDT', amount: '80', idem: k() });
  assert.equal(bal(bank, 'u1', 'USDT').vault, 80e6); assert.equal(bal(bank, 'u1', 'USDT').available, 20e6);
  const r = bank.pockets.vaultRelease('u1', { currency: 'USDT', amount: '50' });
  assert.equal(r.status, 'locked');
  assert.equal(code(() => bank.pockets.vaultRelease('u1', { currency: 'USDT', amount: '31' })), 'insufficient_funds');   // 50 already releasing of 80
  bank.runDue(); assert.equal(bal(bank, 'u1', 'USDT').available, 20e6);   // still locked
  tick(DAY + 1000); bank.security.setFrozen('u1', true); bank.runDue();
  assert.equal(bal(bank, 'u1', 'USDT').available, 20e6);   // frozen → stays locked
  bank.security.setFrozen('u1', false); bank.runDue();
  assert.equal(bal(bank, 'u1', 'USDT').available, 70e6); assert.equal(bal(bank, 'u1', 'USDT').vault, 30e6);
  const r2 = bank.pockets.vaultRelease('u1', { currency: 'USDT', amount: '10' });
  bank.pockets.cancelVaultRelease('u1', r2.id); tick(2 * DAY); bank.runDue();
  assert.equal(bal(bank, 'u1', 'USDT').vault, 30e6);
  ok(bank);
});

test('freeze: blocks withdrawals, card purchases, plans and rules; unfreezing restores them', async () => {
  const { bank } = setup(); kyc(bank, 'u1', 2); fund(bank, 'u1', 'USD', '500');
  const ben = bank.addBeneficiary('u1', { currency: 'USD', label: 'me', iban: GOOD_IBAN, holder: 'Ada' });
  const card = bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'web' });
  bank.security.setFrozen('u1', true);
  assert.equal(bank.vcards.list('u1')[0].status, 'frozen');
  assert.equal(code(() => bank.requestWithdrawal('u1', { currency: 'USD', amount: '20', beneficiaryId: ben.id, idem: k() })), 'account_frozen');
  bank.security.setFrozen('u1', false);
  bank.vcards.action('u1', card.id, 'unfreeze');
  const s = bank.vcards.simulate('u1', card.id, { merchant: 'Shop', amount: '5', category: 'shopping' });
  assert.equal(s.approved, true);
  ok(bank);
});

test('passkeys: register, then sensitive actions need an assertion bound to the exact action (no replay, no other site, no tampering)', () => {
  const { bank } = setup(); const P = bank.security.passkeys; const a = makeAuthenticator();
  assert.deepEqual(P.verifyStep('u1', 'withdraw', { amount: 1 }, null, RP), { used: false });   // no passkey yet → caller uses sign-in step-up
  const reg = P.registrationOptions('u1', { email: 'u1@x.io', rpId: 'localhost' });
  assert.equal(reg.publicKey.authenticatorSelection.userVerification, 'required');
  P.register('u1', { challengeId: reg.challengeId, credential: a.register(reg), name: 'Phone' }, RP);
  assert.equal(P.count('u1'), 1);
  assert.equal(code(() => P.register('u1', { challengeId: reg.challengeId, credential: a.register(reg) }, RP)), 'passkey_challenge_expired');   // single use
  const params = { currency: 'USD', amount: 2000, beneficiaryId: 'ben_1' };
  assert.equal(code(() => P.verifyStep('u1', 'withdraw', params, null, RP)), 'passkey_required');
  let o = P.assertionOptions('u1', 'withdraw', params, RP);
  assert.deepEqual(P.verifyStep('u1', 'withdraw', params, a.assert(o), RP), { used: true });
  o = P.assertionOptions('u1', 'withdraw', params, RP);
  assert.equal(code(() => P.verifyStep('u1', 'withdraw', { ...params, amount: 999999 }, a.assert(o), RP)), 'passkey_binding_mismatch');   // signed 20 USD, asked 9999
  o = P.assertionOptions('u1', 'withdraw', params, RP); const once = a.assert(o);
  P.verifyStep('u1', 'withdraw', params, once, RP);
  assert.equal(code(() => P.verifyStep('u1', 'withdraw', params, once, RP)), 'passkey_challenge_expired');   // replay
  o = P.assertionOptions('u1', 'withdraw', params, RP);
  assert.equal(code(() => P.verifyStep('u1', 'withdraw', params, a.assert(o, { originOverride: 'https://evil.example' }), RP)), 'passkey_origin_mismatch');
  o = P.assertionOptions('u1', 'withdraw', params, RP);
  assert.equal(code(() => P.verifyStep('u1', 'withdraw', params, a.assert(o, { rp: 'evil.example' }), RP)), 'passkey_rp_mismatch');
  o = P.assertionOptions('u1', 'withdraw', params, RP);
  assert.equal(code(() => P.verifyStep('u1', 'withdraw', params, a.assert(o, { tamper: true }), RP)), 'passkey_bad_signature');
  o = P.assertionOptions('u1', 'withdraw', params, RP);
  assert.equal(code(() => P.verifyStep('u1', 'withdraw', params, a.assert(o, { uv: false }), RP)), 'passkey_user_verification_required');
  o = P.assertionOptions('u1', 'withdraw', params, RP); P.verifyStep('u1', 'withdraw', params, a.assert(o), RP);   // counter n stored
  o = P.assertionOptions('u1', 'withdraw', params, RP);
  assert.equal(code(() => P.verifyStep('u1', 'withdraw', params, a.assert(o, { keepCounter: true }), RP)), 'passkey_counter_replay');   // n again = cloned key
  const b2 = makeAuthenticator(); const reg2 = P.registrationOptions('u2', { rpId: 'localhost' }); P.register('u2', { challengeId: reg2.challengeId, credential: b2.register(reg2) }, RP);
  o = P.assertionOptions('u1', 'withdraw', params, RP);
  assert.equal(code(() => P.verifyStep('u2', 'withdraw', params, a.assert(o), RP)), 'passkey_challenge_expired');   // someone else's challenge
  o = P.assertionOptions('u2', 'withdraw', params, RP);
  assert.equal(code(() => P.verifyStep('u2', 'withdraw', params, a.assert(o), RP)), 'passkey_unknown');   // u1's key on u2's account
  assert.equal(bank.rewards.balance('u1'), 50);   // first passkey reward
  assert.equal(code(() => P.register('u1', { challengeId: P.registrationOptions('u1', { rpId: 'localhost' }).challengeId, credential: a.register(reg, { uv: false }) }, RP)), 'passkey_challenge_mismatch');
});

test('co-signers: withdrawals above the threshold wait for M approvals; a rejection or expiry returns the money', () => {
  const { bank, tick } = setup(); kyc(bank, 'alice'); kyc(bank, 'bob'); kyc(bank, 'carol');
  fund(bank, 'alice', 'USD', '1000');
  const ben = bank.addBeneficiary('alice', { currency: 'USD', label: 'me', iban: GOOD_IBAN, holder: 'Alice' }); tick(2000);
  assert.equal(code(() => bank.security.setPolicy('alice', { enabled: true, needed: 1, threshold: { USD: '100' } })), 'no_approvers');
  const inv = bank.security.invite('alice', 'Bob');
  assert.equal(code(() => bank.security.acceptInvite('alice', inv.code)), 'self_action_not_allowed');
  bank.security.acceptInvite('bob', inv.code);
  assert.equal(code(() => bank.security.acceptInvite('carol', inv.code)), 'invite_invalid');   // single use
  bank.security.acceptInvite('carol', bank.security.invite('alice', 'Carol').code);
  assert.equal(code(() => bank.security.setPolicy('alice', { enabled: true, needed: 3, threshold: { USD: '100' } })), 'bad_needed');
  bank.security.setPolicy('alice', { enabled: true, needed: 2, threshold: { USD: '100' } });
  const small = bank.requestWithdrawal('alice', { currency: 'USD', amount: '50', beneficiaryId: ben.id, idem: k() });
  assert.equal(small.status, 'requested');   // below threshold
  const big = bank.requestWithdrawal('alice', { currency: 'USD', amount: '200', beneficiaryId: ben.id, idem: k() });
  assert.equal(big.status, 'awaiting_approvals');
  assert.ok(!bank.adminQueue().withdrawals.some((w) => w.id === big.id));   // owner does not see it yet
  const pend = bank.security.pendingForMe('bob'); assert.equal(pend.length, 1); assert.equal(pend[0].amount, 20000);
  assert.equal(code(() => bank.security.vote('alice', pend[0].id, 'approve')), 'not_an_approver');
  assert.deepEqual(bank.security.vote('bob', pend[0].id, 'approve'), { ok: true, result: null });
  assert.equal(code(() => bank.security.vote('bob', pend[0].id, 'approve')), 'already_voted');
  assert.deepEqual(bank.security.vote('carol', pend[0].id, 'approve'), { ok: true, result: 'approved' });
  assert.ok(bank.adminQueue().withdrawals.some((w) => w.id === big.id));
  // rejection path
  const w2 = bank.requestWithdrawal('alice', { currency: 'USD', amount: '150', beneficiaryId: ben.id, idem: k() });
  const before = bal(bank, 'alice', 'USD').available;
  bank.security.vote('bob', bank.security.pendingForMe('bob')[0].id, 'reject');
  assert.equal(bank.listWithdrawals('alice').find((w) => w.id === w2.id).status, 'rejected');
  assert.equal(bal(bank, 'alice', 'USD').available, before + 15100);
  // expiry path
  const w3 = bank.requestWithdrawal('alice', { currency: 'USD', amount: '120', beneficiaryId: ben.id, idem: k() });
  tick(49 * 3600_000); bank.runDue();
  assert.equal(bank.listWithdrawals('alice').find((w) => w.id === w3.id).status, 'rejected');
  ok(bank);
});

test('virtual cards: issued only at KYC 2; every control is enforced at authorisation; hold → settle → refund keeps the ledger whole', () => {
  const { bank, now } = setup(); kyc(bank, 'u1', 1); fund(bank, 'u1', 'USD', '300');
  assert.equal(code(() => bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'web' })), 'kyc_required');
  kyc(bank, 'u1', 2);
  const c = bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'web', limitTx: '100', limitDay: '150', limitMonth: '1000' });
  assert.match(c.last4, /^\d{4}$/); assert.equal(c.issuer, 'sandbox');
  const sim = (amount, merchant = 'Coffee Corner', category = 'dining') => bank.vcards.simulate('u1', c.id, { merchant, amount, category });
  assert.equal(sim('120').reason, 'over_tx_limit');
  assert.equal(sim('90').approved, true);
  assert.equal(sim('70').reason, 'over_day_limit');
  bank.vcards.block('u1', 'Shady Shop', true);
  assert.equal(sim('5', 'shady-shop').reason, 'merchant_blocked');   // merchant names are normalised
  bank.planning.setBudget('u1', { category: 'dining', amount: '95', block: true });
  assert.equal(sim('10').reason, 'budget_exceeded');
  assert.equal(bal(bank, 'u1', 'USD').available, 21000);   // 300 − 90 (virtual cards have no fee)
  const one = bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'once', kind: 'single_use' });
  assert.equal(bank.vcards.simulate('u1', one.id, { merchant: 'Hotel', amount: '20', category: 'travel' }).approved, true);
  assert.equal(bank.vcards.simulate('u1', one.id, { merchant: 'Hotel', amount: '1', category: 'travel' }).reason, 'card_inactive');   // closed after first use
  const lock = bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'netflix', kind: 'merchant_locked', merchant: 'Streamflix' });
  assert.equal(bank.vcards.simulate('u1', lock.id, { merchant: 'Other', amount: '1' }).reason, 'merchant_not_allowed');
  const paid = bank.vcards.simulate('u1', lock.id, { merchant: 'STREAMFLIX', amount: '9.99', category: 'subscriptions' });
  assert.equal(paid.approved, true);
  bank.vcards.simulateRefund('u1', paid.auth.id);
  assert.equal(bank.vcards.purchases('u1').find((p) => p.id === paid.auth.id).status, 'refunded');
  assert.equal(code(() => bank.vcards.create('u2', { label: 'x' })), 'kyc_required');
  assert.ok(now());
  ok(bank);
});

test('saving rules: round-ups of card purchases, a share of deposits, a fixed amount on schedule — with cap and floor', () => {
  const { bank, tick } = setup(); kyc(bank, 'u1', 2); fund(bank, 'u1', 'USD', '100');
  const p = bank.pockets.createPocket('u1', { name: 'Spare change', currency: 'USD' });
  bank.planning.createRule('u1', { kind: 'roundup', pocketId: p.id, roundTo: 1 });
  bank.planning.createRule('u1', { kind: 'percent', pocketId: p.id, pct: 10 });
  bank.planning.createRule('u1', { kind: 'fixed', pocketId: p.id, amount: '5', every: 'daily', floor: '50' });
  const c = bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'web' });
  bank.vcards.simulate('u1', c.id, { merchant: 'Bakery', amount: '3.40', category: 'groceries' });
  assert.equal(bank.pockets.listPockets('u1')[0].balance, 60);   // 0.60 rounded up
  fund(bank, 'u1', 'USD', '200');                                  // 10% of incoming
  assert.equal(bank.pockets.listPockets('u1')[0].balance, 60 + 2000);
  tick(DAY + 1); bank.runDue();
  assert.equal(bank.pockets.listPockets('u1')[0].balance, 60 + 2000 + 500);
  assert.equal(code(() => bank.planning.createRule('u1', { kind: 'percent', pocketId: p.id, pct: 80 })), 'bad_percent');
  const eurP = bank.pockets.createPocket('u1', { name: 'eur', currency: 'EUR' });
  assert.equal(code(() => bank.planning.createRule('u1', { kind: 'roundup', pocketId: eurP.id })), 'pocket_currency_must_be_usd');
  ok(bank);
});

test('budgets alert at 80% and 100% once per month; subscriptions are detected from repeated charges and can be blocked', () => {
  const { bank } = setup(); kyc(bank, 'u1', 2); fund(bank, 'u1', 'USD', '500');
  bank.planning.setBudget('u1', { category: 'groceries', amount: '100' });
  const c = bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'web' });
  bank.vcards.simulate('u1', c.id, { merchant: 'Market', amount: '85', category: 'groceries' });
  bank.vcards.simulate('u1', c.id, { merchant: 'Market', amount: '1', category: 'groceries' });
  bank.vcards.simulate('u1', c.id, { merchant: 'Market', amount: '20', category: 'groceries' });
  const kinds = bank.notifications.list('u1').items.map((x) => x.kind);
  assert.equal(kinds.filter((x) => x === 'budget_80').length, 1); assert.equal(kinds.filter((x) => x === 'budget_100').length, 1);
  assert.equal(bank.planning.budgets('u1').items[0].pct, 106);
  bank.vcards.simulate('u1', c.id, { merchant: 'Musicly', amount: '9.99', category: 'subscriptions', daysAgo: 30 });
  bank.vcards.simulate('u1', c.id, { merchant: 'Musicly', amount: '10.99', category: 'subscriptions', daysAgo: 0 });
  const subs = bank.vcards.listSubs('u1'); assert.equal(subs.length, 1);
  assert.equal(subs[0].every, 'monthly'); assert.equal(subs[0].priceUp, true);
  bank.vcards.setSub('u1', subs[0].id, 'block');
  assert.equal(bank.vcards.simulate('u1', c.id, { merchant: 'Musicly', amount: '10.99' }).reason, 'merchant_blocked');
  assert.ok(bank.insights.insights('u1').items.some((i) => i.kind === 'sub_price_up'));
  ok(bank);
});

test('rewards: points for card spend, identity check and first passkey; cashback 1000 → 5 USD; refunds claw back; points expire after 12 months', () => {
  const { bank, tick } = setup(); kyc(bank, 'u1', 2); fund(bank, 'u1', 'USD', '2000');
  assert.equal(bank.rewards.balance('u1'), 300);   // kyc1 100 + kyc2 200
  const c = bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'web', limitTx: '1000', limitDay: '2000', limitMonth: '5000' });
  const p = bank.vcards.simulate('u1', c.id, { merchant: 'Store', amount: '750.50' });
  assert.equal(bank.rewards.balance('u1'), 1050);
  bank.rewards.redeem('u1', { points: 1000 });
  assert.equal(bank.rewards.balance('u1'), 50); assert.equal(bal(bank, 'u1', 'USD').available, 200000 - 75050 + 500);
  assert.equal(code(() => bank.rewards.redeem('u1', { points: 1000 })), 'insufficient_points');
  assert.equal(code(() => bank.rewards.redeem('u1', { points: 999 })), 'bad_points');
  bank.vcards.simulateRefund('u1', p.auth.id);
  assert.equal(bank.rewards.balance('u1'), 0);   // claw back what is left
  bank.vcards.simulate('u1', c.id, { merchant: 'Store', amount: '40' });
  assert.equal(bank.rewards.balance('u1'), 40);
  tick(366 * DAY); bank.runDue();
  assert.equal(bank.rewards.balance('u1'), 0);
  assert.equal(bank.history('u1').items.some((x) => x.currency === 'PTS'), false);   // points never in the money history
  ok(bank);
  const live = setup({ mode: 'live' }).bank;
  assert.equal(code(() => live.rewards.redeem('u1', { points: 1000 })), 'cashback_not_available');
});

test('conversion and cross-border: reference rate minus spread, both legs balanced; quote expiry; live mode needs a partner', async () => {
  const { bank, tick } = setup(); kyc(bank, 'u1'); fund(bank, 'u1', 'USD', '1000');
  const calc = await bank.fx.calc({ from: 'USD', to: 'EUR', amount: '110' });
  assert.equal(calc.result, 10000); assert.equal(calc.indicative, true);
  const cv = await bank.fx.convert('u1', { from: 'USD', to: 'EUR', amount: '110', idem: 'conv-key-0001' });
  assert.equal(cv.receive, Math.floor(10000 * 0.995));
  const again = await bank.fx.convert('u1', { from: 'USD', to: 'EUR', amount: '110', idem: 'conv-key-0001' });
  assert.equal(again.replay, true); assert.equal(bal(bank, 'u1', 'USD').available, 100000 - 11000);
  assert.equal(await acode(() => bank.fx.convert('u1', { from: 'USD', to: 'USD', amount: '1', idem: k() })), 'same_currency');
  const ben = bank.addBeneficiary('u1', { currency: 'EUR', label: 'mum', iban: GOOD_IBAN, holder: 'Mum' }); tick(2000);
  const usdBen = bank.addBeneficiary('u1', { currency: 'USD', label: 'me', iban: GB_IBAN, holder: 'Me' }); tick(2000);
  assert.equal(await acode(() => bank.fx.quoteIntl('u1', { from: 'USD', amount: '100', beneficiaryId: usdBen.id })), 'use_normal_withdrawal');
  const q = await bank.fx.quoteIntl('u1', { from: 'USD', amount: '100', beneficiaryId: ben.id });
  assert.equal(q.to, 'EUR'); assert.equal(q.fee, 200); assert.equal(q.receive, Math.floor(9090.909 * 0.995));
  const r = bank.fx.confirmIntl('u1', { quoteId: q.id, idem: k() });
  assert.ok(r.withdrawal.flags.includes('cross_border')); assert.equal(r.withdrawal.intl.to, 'EUR');
  assert.equal(bank.withdrawalDestination(OWNER, r.withdrawal.id).intl.receive, q.receive);
  const q2 = await bank.fx.quoteIntl('u1', { from: 'USD', amount: '100', beneficiaryId: ben.id }); tick(61_000);
  assert.equal(code(() => bank.fx.confirmIntl('u1', { quoteId: q2.id, idem: k() })), 'quote_expired');
  ok(bank);
  const live = setup({ mode: 'live' }).bank;
  assert.equal(await acode(() => live.fx.convert('u1', { from: 'USD', to: 'EUR', amount: '1', idem: k() })), 'no_fx_provider');
  assert.equal(code(() => live.ob.link('u1', { institution: 'Demo Bank A' })), 'no_open_banking_provider');
  assert.equal(code(() => live.vcards.create('u1', {})), 'no_card_issuer');
});

test('open banking (demo provider): link, demo flag on every account, refresh, revoke deletes the copy', () => {
  const { bank, db } = setup();
  assert.equal(code(() => bank.ob.link('u1', { institution: 'Real Bank' })), 'bad_institution');
  const l = bank.ob.link('u1', { institution: 'Demo Bank A' });
  assert.equal(l.accounts.length, 2); assert.ok(l.accounts.every((a) => a.demo === true));
  assert.ok(bank.ob.txns('u1', l.accounts[0].id).length > 10);
  assert.equal(bank.ob.txns('u2', l.accounts[0].id).length, 0);   // isolation
  bank.ob.refresh('u1', l.id); bank.ob.revoke('u1', l.id);
  assert.equal(db.prepare('SELECT COUNT(*) c FROM ob_txns').get().c, 0); assert.equal(bank.ob.links('u1').length, 0);
});

test('investments: sell (paper) and the FIFO tax report; CSV cells cannot start a formula', async () => {
  const { bank, tick, db } = setup(); fund(bank, 'u1', 'USDT', '1000');
  bank.createPlan('u1', { asset: 'BTC', amount: '100', every: 'daily' }); tick(DAY + 1); await bank.runDue();
  db.prepare("UPDATE orders SET price = 40000, qty = 250000 WHERE uid = 'u1'").run();   // pretend the first buy was at 40k: 0.0025 BTC for 100 USDT
  db.prepare("UPDATE holdings SET qty = 250000 WHERE uid = 'u1'").run();
  const s = await bank.insights.sell('u1', { asset: 'BTC', all: true, idem: k() });
  assert.equal(s.proceeds, 125e6);   // 0.0025 × 50,000
  const year = new Date(Date.UTC(2026, 9, 29)).getUTCFullYear();
  const tr = bank.insights.taxReport('u1', year);
  assert.equal(tr.sales.length, 1); assert.equal(tr.sales[0].costBasis, 100e6); assert.equal(tr.realizedGainUsdt, 25e6);
  const csv = bank.insights.taxCsv('u1', year);
  assert.ok(csv.includes('25.000000')); assert.ok(!/(^|,)[=+@]/m.test(csv));
  assert.equal(await acode(() => bank.insights.sell('u1', { asset: 'BTC', all: true, idem: k() })), 'nothing_to_sell');
  ok(bank);
});

test('support: encrypted tickets, owner desk without text, audited view, reply notifies, no self-service on own ticket', () => {
  const { bank, db } = setup();
  const t = bank.support.create('u1', { topic: 'card', subject: 'Card declined at hotel', body: 'My IBAN is DE89 3704 0044 0532 0130 00' });
  assert.ok(!JSON.stringify(db.prepare('SELECT * FROM tickets').all()).includes('hotel'));
  assert.ok(!JSON.stringify(db.prepare('SELECT * FROM ticket_msgs').all()).includes('DE89'));
  assert.equal(bank.support.adminList()[0].subject, undefined);
  assert.equal(bank.support.adminView(OWNER, t.id).messages[0].body.includes('DE89'), true);
  assert.equal(code(() => bank.support.adminView({ uid: 'u1' }, t.id)), 'self_action_not_allowed');
  bank.support.adminReply(OWNER, t.id, { body: 'Please try again now.' });
  assert.equal(bank.support.view('u1', t.id).messages.at(-1).author, 'support');
  assert.ok(bank.notifications.list('u1').items.some((x) => x.kind === 'ticket_reply'));
  assert.equal(code(() => bank.support.view('u2', t.id)), 'not_found');
});

test('notifications: centre + preferences (security always on) + Web Push encrypted for the device only; dead subscriptions are dropped', async () => {
  const { bank, pushes } = setup();
  const ua = crypto.createECDH('prime256v1'); ua.generateKeys(); const auth = crypto.randomBytes(16);
  const sub = { endpoint: 'https://fcm.googleapis.com/fcm/send/abc123', keys: { p256dh: ua.getPublicKey().toString('base64url'), auth: auth.toString('base64url') } };
  assert.equal(code(() => bank.notifications.subscribe('u1', { ...sub, endpoint: 'https://evil.example/push' })), 'bad_subscription');
  assert.equal(code(() => bank.notifications.subscribe('u1', { ...sub, endpoint: 'http://fcm.googleapis.com/x' })), 'bad_subscription');
  bank.notifications.subscribe('u1', sub);
  bank.notifications.setPrefs('u1', { groups: { money: false, security: false }, hideAmounts: true, lang: 'en' });
  fund(bank, 'u1', 'USD', '10'); bank.security.setFrozen('u1', true);
  const kinds = bank.notifications.list('u1').items.map((x) => x.kind);
  assert.ok(kinds.includes('frozen'));   // security cannot be switched off
  await new Promise((r) => setTimeout(r, 20));
  assert.equal(pushes.length, 1); assert.equal(pushes[0].payload.body, 'Your account is frozen');
  // real encryption round trip with the device's keys
  const { encryptPayload } = await import('../server/bank/webpush.js');
  const body = encryptPayload(JSON.stringify({ hello: 'world' }), sub);
  assert.equal(decryptPayload(body, ua.getPrivateKey(), ua.getPublicKey(), auth), '{"hello":"world"}');
  assert.equal(bank.notifications.list('u1').unread > 0, true); bank.notifications.markRead('u1'); assert.equal(bank.notifications.list('u1').unread, 0);
  assert.match(bank.notifications.vapidPublicKey(), /^[A-Za-z0-9_-]{87}$/);
});
