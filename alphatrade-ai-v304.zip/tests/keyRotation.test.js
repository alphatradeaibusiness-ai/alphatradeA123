// v236: AI_KEY_SECRET rotation (security/rotate-ai-key.mjs): every store written with the old secret is readable with the new one
// after the tool ran, the live folder is never touched, and a wrong old secret stops the tool without writing anything.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { rotate } from '../security/rotate-ai-key.mjs';
import { createStore } from '../server/aiGateway.js';
import { createUserTrades } from '../server/userTrades.js';
import { createMt5Bridge } from '../server/mt5Bridge.js';
import { createCommunity } from '../server/community.js';

const OLD = 'o'.repeat(40), NEW = 'n'.repeat(40);
const trade = (id) => ({ id, symbol: 'BTCUSDT', tf: '1h', style: 'swing', direction: 'long', execution: 'market', account: 'demo', asset: 'crypto', entry: 100, stop: 90, risk: 10, targets: [110], rr: [1], status: 'active', hits: 0, savedAt: 1_793_000_000_000, updatedAt: 1_793_000_000_000, createdAt: 1_793_000_000, mode: 'live' });

test('rotation: all stores re-encrypted, verified, live folder untouched', () => {
  const data = fs.mkdtempSync(path.join(os.tmpdir(), 'rot-data-')); const out = path.join(os.tmpdir(), `rot-out-${process.pid}-${Date.now()}`);
  createStore({ dir: data, secret: OLD }).save({ provider: 'anthropic', model: 'm', apiKey: 'sk-test-key-1234' });
  createStore({ dir: data, secret: OLD, name: 'market-config.json' }).save({ provider: 'twelvedata', apiKey: 'td-key-5678' });
  const ut = createUserTrades({ dir: data, secret: OLD }); assert.ok(!ut.upsert('u-1', trade('tradeAAA1')).error);
  // members file in createGrowth's exact format (AES-256-GCM, AAD 'growth'): it also tells the tool which accounts exist
  const gk = crypto.scryptSync(OLD, 'alphatrade-growth-v1', 32); const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', gk, iv); c.setAAD(Buffer.from('growth'));
  const gdata = Buffer.concat([c.update(JSON.stringify({ users: { 'u-1': { name: 'A' } } })), c.final()]);
  fs.writeFileSync(path.join(data, 'growth.json'), JSON.stringify({ v: 1, iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: gdata.toString('base64') }));
  const mt = createMt5Bridge({ dir: data, secret: OLD }); const link = mt.createLink('u-1', { account: '1234567', server: 'Demo' }); assert.ok(link.link);
  const cm = createCommunity({ dir: data, secret: OLD }); assert.ok(!cm.submitFeedback({ uid: 'u-1', name: 'A' }, { kind: 'bug', text: 'hello rotation' }).error);
  return new Promise((done) => setTimeout(() => {   // let write-behind stores flush
  const before = Object.fromEntries(fs.readdirSync(data, { recursive: true }).map((f) => [f, fs.statSync(path.join(data, f)).isFile() ? fs.readFileSync(path.join(data, f)).toString('base64') : 'dir']));
    const r = rotate({ data, out, oldSecret: OLD, newSecret: NEW });
    assert.ok(r.done.length >= 4, JSON.stringify(r));
    const after = Object.fromEntries(fs.readdirSync(data, { recursive: true }).map((f) => [f, fs.statSync(path.join(data, f)).isFile() ? fs.readFileSync(path.join(data, f)).toString('base64') : 'dir']));
    assert.deepEqual(after, before, 'the live folder is unchanged');
    assert.equal(createStore({ dir: out, secret: NEW }).load().apiKey, 'sk-test-key-1234');
    assert.equal(createStore({ dir: out, secret: NEW, name: 'market-config.json' }).load().apiKey, 'td-key-5678');
    const ge = JSON.parse(fs.readFileSync(path.join(out, 'growth.json'), 'utf8')); const gd = crypto.createDecipheriv('aes-256-gcm', crypto.scryptSync(NEW, 'alphatrade-growth-v1', 32), Buffer.from(ge.iv, 'base64')); gd.setAAD(Buffer.from('growth')); gd.setAuthTag(Buffer.from(ge.tag, 'base64'));
    assert.equal(JSON.parse(Buffer.concat([gd.update(Buffer.from(ge.data, 'base64')), gd.final()]).toString()).users['u-1'].name, 'A', 'members file re-encrypted');
    assert.equal(createUserTrades({ dir: out, secret: NEW }).list('u-1')[0]?.id, 'tradeAAA1', 'trade file renamed and re-encrypted for the new secret');
    assert.equal(createStore({ dir: out, secret: OLD }).load(), null, 'the old secret no longer opens the new copy');
    assert.equal(createCommunity({ dir: out, secret: NEW }).listFeedback({ uid: 'u-1' }, false).items[0]?.text, 'hello rotation');
    assert.equal(createMt5Bridge({ dir: out, secret: NEW }).list('u-1').links?.length ?? createMt5Bridge({ dir: out, secret: NEW }).list('u-1').length, 1);
    assert.throws(() => rotate({ data, out: `${out}-2`, oldSecret: 'w'.repeat(40), newSecret: NEW }), /Unsupported state|auth|verification/i, 'a wrong old secret stops');
    done();
  }, 300));
});

test('rotation: refuses weak / equal secrets and a non-empty target', () => {
  const data = fs.mkdtempSync(path.join(os.tmpdir(), 'rot-d2-')); fs.writeFileSync(path.join(data, 'growth.json'), '{}');
  assert.throws(() => rotate({ data, out: path.join(data, 'x'), oldSecret: OLD, newSecret: 'short' }), /32/);
  assert.throws(() => rotate({ data, out: path.join(data, 'x'), oldSecret: OLD, newSecret: OLD }), /equals/);
  assert.throws(() => rotate({ data, out: data, oldSecret: OLD, newSecret: NEW }), /empty/);
});
