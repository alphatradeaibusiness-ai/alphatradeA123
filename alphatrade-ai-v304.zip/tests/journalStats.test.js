import test from 'node:test';
import assert from 'node:assert';
import { journalStats } from '../src/services/journalStats.js';

test('journalStats: win rate, profit factor, drawdown in closing order, per strategy', () => {
  const rows = [
    { usd: 100, closedAt: 1, strategy: 'smc', r: 1 }, { usd: -50, closedAt: 2, strategy: 'smc', r: -1 },
    { usd: -70, closedAt: 3, strategy: 'edh', r: -1 }, { usd: 200, closedAt: 4, strategy: 'edh', r: 2 },
  ];
  const s = journalStats(rows);
  assert.equal(s.n, 4); assert.equal(s.winRate, 50); assert.equal(s.net, 180);
  assert.equal(s.profitFactor, 300 / 120);
  assert.equal(s.maxDrawdown, 120);   // peak +100, then −50 and −70 → −20: a 120 fall
  assert.equal(s.maxDrawdownPct, 120);
  assert.deepEqual(s.byStrategy.map((x) => [x.strategy, x.net]), [['edh', 130], ['smc', 50]]);
  assert.equal(journalStats([]).n, 0); assert.equal(journalStats([]).profitFactor, null);
});
