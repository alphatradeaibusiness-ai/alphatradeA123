import test from 'node:test';
import assert from 'node:assert/strict';
import { featuresOf, outcomeR, analyse, check, LEARN } from '../src/services/learning.js';

const DAY = 86_400_000; const NOW = Date.UTC(2026, 10, 2, 12);
const sig = (over) => ({ entry: 100, stop: 98, targets: [102, 104, 106], direction: 'long', hits: 0, status: 'sl', ...over });
const o = (strategy, features, r, ageDays = 1) => ({ strategy, features, r, at: NOW - ageDays * DAY });

test('outcome in R follows the channel management (a third per target, stop to entry after TP1)', () => {
  assert.equal(outcomeR(sig({ status: 'sl' })), -1);
  assert.equal(outcomeR(sig({ status: 'be', hits: 1 })), 1 / 3);
  assert.equal(outcomeR(sig({ status: 'tp3', hits: 3 })), (1 + 2 + 3) / 3);
  assert.equal(+outcomeR(sig({ status: 'expired', hits: 0, price: 99 })).toFixed(2), -0.5);
  assert.equal(outcomeR(sig({ status: 'active' })), null);
  assert.equal(outcomeR({ entry: 1, stop: 1, targets: [2, 3, 4], status: 'sl' }), null);
});

test('context features are bucketed', () => {
  const f = featuresOf({ session: 'asia', regime: 'ranging', adx: 17, rsi: 72, atrPct: 0.3, direction: 'short', hour: 5, symbol: 'BTCUSDT', htf: 'long' });
  assert.deepEqual(f, ['session=asia', 'regime=ranging', 'adx=15-20', 'rsi=70+', 'vol=low', 'dir=short', 'hour=4-8', 'market=BTCUSDT', 'htf=against']);
});

test('a context that keeps losing is blocked for that strategy only; one bad trade changes nothing', () => {
  const good = Array.from({ length: 12 }, (_, i) => o('trend', ['session=london'], 0.8, i));
  const one = analyse([...good, o('trend', ['session=asia'], -1)], {}, NOW);
  assert.deepEqual(Object.keys(one.blocks), []);
  const bad = Array.from({ length: 12 }, (_, i) => o('trend', ['session=asia'], -1, i));
  const s = analyse([...good, ...bad, ...Array.from({ length: 12 }, (_, i) => o('smc', ['session=asia'], 0.5, i))], {}, NOW);
  assert.ok(s.blocks['trend|session=asia']);
  assert.equal(s.blocks['smc|session=asia'], undefined);
  assert.equal(check(s, 'trend', { session: 'asia' }, 2).ok, false);
  assert.equal(check(s, 'trend', { session: 'london' }, 2).ok, true);
  assert.equal(check(s, 'edh', { session: 'asia' }, 2).ok, true, 'EDH is never touched');
  assert.ok(s.deviations[0].dev < 0 && s.deviations[0].feature === 'session=asia');
});

test('old losses fade (half-life) and a block gets a probation after 7 days', () => {
  const bad = Array.from({ length: 12 }, (_, i) => o('trend', ['regime=ranging'], -1, i * 0.1));
  const s1 = analyse(bad, {}, NOW);
  assert.ok(s1.blocks['trend|regime=ranging']);
  const later = NOW + (LEARN.probationDays + 1) * DAY;
  const s2 = analyse(bad, s1, later);
  assert.equal(s2.blocks['trend|regime=ranging'], undefined);
  assert.ok(s2.probation['trend|regime=ranging']);
  const s3 = analyse([{ strategy: 'trend', features: ['regime=ranging'], r: -1, at: later + 1000 }, ...bad], s2, later + 2000);
  assert.ok(s3.blocks['trend|regime=ranging'], 'a new loss on probation blocks it again');
  const s4 = analyse(bad, s2, later + 2000);
  assert.equal(s4.blocks['trend|regime=ranging'], undefined, 'no new loss → stays allowed');
});

test('reward-to-risk is raised after recent losses and relaxed after recovery, within limits', () => {
  const losses = Array.from({ length: 20 }, (_, i) => o('mean_reversion', [], -0.6, i * 0.01));
  let st = analyse(losses, {}, NOW);
  assert.equal(st.adj.mean_reversion, LEARN.rrStep);
  for (let i = 0; i < 5; i++) st = analyse(losses, st, NOW);
  assert.equal(st.adj.mean_reversion, LEARN.rrMax);
  assert.equal(check(st, 'mean_reversion', {}, 1.6, 1.35).ok, false);
  assert.equal(check(st, 'mean_reversion', {}, 1.9, 1.35).ok, true);
  const wins = Array.from({ length: 20 }, (_, i) => o('mean_reversion', [], 0.9, i * 0.01));
  const back = analyse(wins, st, NOW);
  assert.equal(back.adj.mean_reversion, +(LEARN.rrMax - LEARN.rrStep).toFixed(2));
  assert.equal(analyse(wins, { adj: { mean_reversion: 0 } }, NOW).adj.mean_reversion, 0, 'never below the engine value');
});
