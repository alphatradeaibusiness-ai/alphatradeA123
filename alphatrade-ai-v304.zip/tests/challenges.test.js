// v281 funded-trader challenges: rules engine, simulated broker on server prices, phases, funding review, payouts, Stripe hook.
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createChallenges, evaluate, cleanPayout, equityOf } from '../server/challenges.js';
import { PROGRAMS, CHALLENGE_PRODUCTS, parseProduct, pnlUsd, marginUsd, productId } from '../src/config/challenges.js';
import { createChannelAccess } from '../server/channelAccess.js';
import { createStripeBilling, CATALOGUE } from '../server/stripe.js';

const SECRET = 'x'.repeat(40);
const user = (uid = 'u1', email = 'trader@example.com') => ({ uid, email, emailVerified: true, name: 'Trader One' });
const OWNER = { uid: 'own', email: 'boss@site.test', emailVerified: true };
function setup(px = { BTCUSDT: 50000, XAUUSD: 2000, EURUSD: 1.1, USDJPY: 150 }) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ch-')); let t = Date.UTC(2026, 10, 9, 10); const notes = [];
  const prices = { ...px };
  const c = createChallenges({ dir, secret: SECRET, env: { NODE_ENV: 'test' }, now: () => t, priceOf: async (s) => (prices[s] ? { price: prices[s], at: t } : null), isOwnerEmail: (u) => u?.email === OWNER.email, notify: (uid, title) => notes.push([uid, title]), log: { error() {} } });
  return { c, dir, prices, notes, at: () => t, set: (v) => { t = v; }, add: (ms) => { t += ms; } };
}

test('catalogue: 4 programs × 6 sizes, ids round-trip, all in the Stripe catalogue as challenges', () => {
  assert.equal(PROGRAMS.length, 4); assert.equal(CHALLENGE_PRODUCTS.length, 24);
  for (const p of CHALLENGE_PRODUCTS) { assert.deepEqual(parseProduct(p.id).size, p.size); assert.equal(CATALOGUE[p.id].kind, 'challenge'); assert.equal(CATALOGUE[p.id].cents, p.price * 100); assert.ok(p.price > 0 && p.price < 2000); }
  assert.equal(parseProduct('ch-step2-7k'), null); assert.equal(parseProduct('ch-evil-10k'), null); assert.equal(parseProduct('../x'), null);
  assert.equal(productId('step2', 100000), 'ch-step2-100k');
});

test('contracts: P&L and margin in USD', () => {
  assert.equal(pnlUsd('XAUUSD', 'buy', 1, 2000, 2010), 1000);          // 100 oz × $10
  assert.equal(pnlUsd('EURUSD', 'sell', 1, 1.1, 1.099), 100.00000000000655 > 99.99 ? pnlUsd('EURUSD', 'sell', 1, 1.1, 1.099) : 0);
  assert.ok(Math.abs(pnlUsd('EURUSD', 'sell', 1, 1.1, 1.099) - 100) < 1e-6);
  assert.ok(Math.abs(pnlUsd('USDJPY', 'buy', 1, 150, 151) - 100000 / 151) < 1e-6);   // JPY P&L converted to USD
  assert.equal(pnlUsd('BTCUSDT', 'sell', 0.5, 50000, 49000), 500);
  assert.equal(marginUsd('XAUUSD', 1, 2000, PROGRAMS[1]), 2000);       // 200 000 notional / 100
  assert.equal(marginUsd('BTCUSDT', 1, 50000, PROGRAMS[1]), 25000);    // crypto 1:2
});

test('payout details: valid methods only, never card numbers', () => {
  assert.deepEqual(cleanPayout('paypal', { email: 'A@B.co' }), { method: 'paypal', email: 'a@b.co' });
  assert.equal(cleanPayout('card', { email: 'a@b.co', number: '4111111111111111' }).error, 'no_card_numbers');
  assert.equal(cleanPayout('bank', { iban: 'JO94 CBJO 0010 0000 0000 0131 0003 02', holder: 'Ali Ahmad' }).iban, 'JO94CBJO0010000000000131000302');
  assert.equal(cleanPayout('bank', { iban: 'nope', holder: 'Ali' }).error, 'bad_iban');
  assert.equal(cleanPayout('usdt', { network: 'trc20', address: 'TXYZabcdefghijkmnopqrstuvwxyz12345' }).network, 'trc20');
  assert.equal(cleanPayout('usdt', { network: 'erc20', address: '0x123' }).error, 'bad_address');
  assert.equal(cleanPayout('western', {}).error, 'bad_method');
});

test('purchase is idempotent on the payment id; only the owner of an account can see or trade it', async () => {
  const { c } = setup();
  const r = c.purchase({ uid: 'u1', email: 'trader@example.com', product: 'ch-step2-10k', paymentId: 'cs_1' }); assert.ok(r.ok);
  assert.equal(c.purchase({ uid: 'u1', product: 'ch-step2-10k', paymentId: 'cs_1' }).duplicate, true);
  assert.equal(c.purchase({ uid: 'u1', product: 'ch-bad-10k', paymentId: 'cs_2' }).error, 'bad_product');
  assert.equal(c.list(user()).items.length, 1);
  assert.equal((await c.view(user('u2', 'x@y.z'), r.id)).error, 'not_found');
  assert.equal((await c.order(user('u2', 'x@y.z'), r.id, { sym: 'BTCUSDT', side: 'buy', lots: 0.01 })).error, 'not_found');
  assert.ok((await c.view(OWNER, r.id)).account, 'the site owner can look at any account');
  assert.equal((await c.view(user(), '../../etc')).error, 'not_found');
});

test('orders: server price only, validation, margin, market closed', async () => {
  const s = setup(); const { c } = s; const id = c.purchase({ uid: 'u1', product: 'ch-step2-10k', paymentId: 'p' }).id; const u = user();
  for (const [b, e] of [[{ sym: 'FAKE', side: 'buy', lots: 1 }, 'bad_symbol'], [{ sym: 'XAUUSD', side: 'long', lots: 1 }, 'bad_side'], [{ sym: 'XAUUSD', side: 'buy', lots: 0 }, 'bad_lots'],
    [{ sym: 'XAUUSD', side: 'buy', lots: 0.001 }, 'bad_lots'], [{ sym: 'XAUUSD', side: 'buy', lots: 51 }, 'bad_lots'], [{ sym: 'XAUUSD', side: 'buy', lots: '1' }, 'bad_lots'],
    [{ sym: 'XAUUSD', side: 'buy', lots: 0.1, sl: 2001 }, 'bad_sl'], [{ sym: 'XAUUSD', side: 'sell', lots: 0.1, tp: 2001 }, 'bad_tp'], [{ sym: 'XAUUSD', side: 'buy', lots: 0.1, sl: -5 }, 'bad_levels'],
    [{ sym: 'XAUUSD', side: 'buy', lots: 10 }, 'margin']]) assert.equal((await c.order(u, id, b)).error, e, JSON.stringify(b));
  const r = await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.5, price: 1, entry: 1 });   // a price from the browser is ignored
  assert.ok(r.ok); assert.equal(r.position.entry, 2000);
  delete s.prices.EURUSD; assert.equal((await c.order(u, id, { sym: 'EURUSD', side: 'buy', lots: 0.1 })).error, 'market_closed');
});

test('daily loss: from the higher of balance / equity at the start of the UTC day; breach closes everything and fails', async () => {
  const s = setup(); const { c } = s; const id = c.purchase({ uid: 'u1', product: 'ch-step2-10k', paymentId: 'p' }).id; const u = user();
  assert.ok((await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.2 })).ok);       // $20 per $1
  s.prices.XAUUSD = 1980; s.add(5000); let v = (await c.view(u, id)).account; assert.equal(v.equity, 9600); assert.equal(v.progress.dailyUsed, 400); assert.equal(v.status, 'active');
  s.prices.XAUUSD = 1975; s.add(5000); v = (await c.view(u, id)).account;                                // −$500 = 5 % daily
  assert.equal(v.status, 'failed'); assert.equal(v.failReason, 'daily_loss'); assert.equal(v.positions.length, 0); assert.equal(v.balance, 9500);
  assert.equal((await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.1 })).error, 'account_closed');
});

test('max loss (static) across days, and day roll-over resets the daily reference', async () => {
  const s = setup(); const { c } = s; const id = c.purchase({ uid: 'u1', product: 'ch-step2-10k', paymentId: 'p' }).id; const u = user();
  await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.2 }); s.prices.XAUUSD = 1980; s.add(5000); await c.tick();
  const p = (await c.view(u, id)).account.positions[0]; await c.close(u, id, p.id);                 // −400 today
  s.add(86_400_000); await c.tick(); let v = (await c.view(u, id)).account; assert.equal(v.progress.dayRef, 9600); assert.equal(v.progress.dailyUsed, 0);
  await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.2 }); s.prices.XAUUSD = 1960; s.add(5000); await c.tick();   // −400 more (−800 total, 4 % today)
  v = (await c.view(u, id)).account; assert.equal(v.status, 'active');
  s.add(86_400_000); s.prices.XAUUSD = 1945; s.add(5000); await c.tick();                                          // equity 8900 → max loss 10 % = floor 9000
  v = (await c.view(u, id)).account; assert.equal(v.status, 'failed'); assert.equal(v.failReason, 'max_loss');
});

test('two phases → owner review → funded → payout request → owner pays → balance back to start', async () => {
  const s = setup(); const { c, notes } = s; const u = user(); const id1 = c.purchase({ uid: 'u1', email: 'trader@example.com', product: 'ch-step2-10k', paymentId: 'p' }).id;
  const win = async (id, to) => { await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.1 }); s.prices.XAUUSD = to; s.add(5000); const pos = (await c.view(u, id)).account.positions[0]; await c.close(u, id, pos.id); };
  s.prices.XAUUSD = 2000; s.add(5000); await win(id1, 2090);                                                       // +900 (target 800) but 1 day only
  let v = (await c.view(u, id1)).account; assert.equal(v.status, 'active', 'minimum trading days not met yet'); assert.equal(v.progress.days, 1);
  for (let d = 0; d < 2; d++) { s.add(86_400_000); s.prices.XAUUSD = 2000; s.add(5000); await win(id1, 2001); }
  v = (await c.view(u, id1)).account; assert.equal(v.status, 'passed'); assert.ok(v.next);
  const id2 = v.next; const p2 = (await c.view(u, id2)).account; assert.equal(p2.phase, 2); assert.equal(p2.rules.target, 500);
  for (let d = 0; d < 3; d++) { s.add(86_400_000); s.prices.XAUUSD = 2000; s.add(5000); await win(id2, d === 0 ? 2060 : 2001); }
  v = (await c.view(u, id2)).account; assert.equal(v.status, 'review');
  assert.equal(c.adminAct(u, { action: 'review_approve', id: id2 }).error, 'forbidden', 'only the owner approves');
  const adm = c.admin(OWNER); assert.equal(adm.reviews.length, 1);
  const f = c.adminAct(OWNER, { action: 'review_approve', id: id2 }); assert.ok(f.ok);
  const fid = f.id; let fv = (await c.view(u, fid)).account; assert.equal(fv.phase, 'funded'); assert.equal(fv.status, 'funded'); assert.equal(fv.rules.target, null);
  s.add(86_400_000); s.prices.XAUUSD = 2000; s.add(5000); await win(fid, 2050);                                    // +500 funded profit
  fv = (await c.view(u, fid)).account; assert.equal(fv.funded.reward, 400); assert.equal(fv.funded.canRequest, false, 'too early');
  const KYC = { fullName: 'Trader One Example', country: 'JO', adult: true, terms: true };
  assert.equal(c.requestPayout(u, fid, { method: 'paypal', details: { email: 'me@pp.com' }, kyc: KYC }).error, 'too_early');
  s.add(14 * 86_400_000);
  assert.equal(c.requestPayout(u, fid, { method: 'paypal', details: { email: 'me@pp.com' }, kyc: { ...KYC, adult: false } }).error, 'bad_kyc');
  const w = c.requestPayout(u, fid, { method: 'paypal', details: { email: 'me@pp.com' }, kyc: KYC }); assert.ok(w.ok); assert.equal(w.payout.amount, 400);
  assert.equal((await c.order(u, fid, { sym: 'XAUUSD', side: 'buy', lots: 0.1 })).error, 'payout_pending');
  assert.equal(c.adminAct(OWNER, { action: 'payout_paid', id: w.payout.id }).error, 'reference_required');
  assert.ok(c.adminAct(OWNER, { action: 'payout_paid', id: w.payout.id, reference: 'PP-123' }).ok);
  fv = (await c.view(u, fid)).account; assert.equal(fv.balance, 10000); assert.equal(fv.funded.paidTotal, 400); assert.equal(fv.funded.payoutPending, false);
  assert.equal(c.myPayouts(u).items[0].state, 'paid'); assert.equal(c.myPayouts(u).items[0].details, undefined, 'own details not echoed back');
  assert.ok(notes.some(([, t]) => /تحويل/.test(t)));
});

test('SL / TP fill at the market price on the live check', async () => {
  const s = setup(); const { c } = s; const id = c.purchase({ uid: 'u1', product: 'ch-step1-25k', paymentId: 'p' }).id; const u = user();
  await c.order(u, id, { sym: 'BTCUSDT', side: 'buy', lots: 0.1, sl: 49000, tp: 52000 });
  s.prices.BTCUSDT = 48800; s.add(5000); await c.tick(); const v = (await c.view(u, id)).account;
  assert.equal(v.positions.length, 0); assert.equal(v.history[0].reason, 'sl'); assert.equal(v.history[0].exit, 48800); assert.equal(v.balance, 24880);
});

test('store is encrypted at rest and reloads', async () => {
  const s = setup(); const id = s.c.purchase({ uid: 'u1', email: 'secret-mail@example.com', product: 'ch-flex-5k', paymentId: 'p' }).id;
  const raw = fs.readFileSync(path.join(s.dir, 'challenges.json')); assert.equal(raw.includes('secret-mail'), false); assert.equal(raw.includes(id), false);
  const c2 = createChallenges({ dir: s.dir, secret: SECRET, env: { NODE_ENV: 'test' } }); assert.equal(c2.list(user()).items[0].id, id);
});

test('Stripe: a paid challenge session creates the account once; plans are not touched', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chs-')); const access = createChannelAccess(dir); const made = [];
  const b = createStripeBilling({ env: { STRIPE_SECRET_KEY: 'sk_test_abcdefghijklmnop123', STRIPE_WEBHOOK_SECRET: 'whsec_testsecret0123456789abcdef' }, access, log: { error() {} },
    onChallenge: (x) => { if (made.some((m) => m.paymentId === x.paymentId)) return { duplicate: true }; made.push(x); return { ok: true }; } });
  const s = { id: 'cs_test_ch1', object: 'checkout.session', mode: 'payment', payment_status: 'paid', client_reference_id: 'u1', metadata: { uid: 'u1', product: 'ch-step2-50k' }, currency: 'usd', amount_subtotal: CATALOGUE['ch-step2-50k'].cents, amount_total: CATALOGUE['ch-step2-50k'].cents, customer_details: { email: 'a@b.co' } };
  assert.equal(b.apply(s), 'granted'); assert.equal(b.apply(s), 'duplicate'); assert.equal(made.length, 1); assert.equal(made[0].product, 'ch-step2-50k');
  assert.equal(access.subscription('u1'), null, 'a challenge is not a site plan');
  assert.equal(b.apply({ ...s, id: 'cs_test_ch2', amount_subtotal: 100, amount_total: 100 }), 'amount_mismatch');
  const off = createStripeBilling({ env: { STRIPE_SECRET_KEY: 'sk_test_abcdefghijklmnop123', STRIPE_WEBHOOK_SECRET: 'whsec_testsecret0123456789abcdef' }, access, log: { error() {} } });
  assert.match(off.apply({ ...s, id: 'cs_test_ch3' }), /^error:/, 'no challenge store → Stripe retries later');
});

test('equityOf uses last known price when a quote is missing', () => {
  const a = { balance: 1000, positions: [{ sym: 'XAUUSD', side: 'buy', lots: 0.1, entry: 2000, last: 2010 }] };
  assert.deepEqual(equityOf(a, () => null), { floating: 100, equity: 1100 });
  assert.equal(typeof crypto.randomUUID, 'function');
});

test('owner grant by e-mail, admin actions validate ids', () => {
  const { c } = setup();
  const find = (e) => (e === 'trader@example.com' ? { uid: 'u9', email: e, name: 'T' } : null);
  assert.equal(c.adminAct(OWNER, { action: 'grant', email: 'nobody@x.y', program: 'step2', size: 10000 }, find).error, 'user_not_found');
  assert.equal(c.adminAct(OWNER, { action: 'grant', email: 'trader@example.com', program: 'step2', size: 12345 }, find).error, 'bad_product');
  assert.ok(c.adminAct(OWNER, { action: 'grant', email: 'trader@example.com', program: 'flex', size: 5000 }, find).ok);
  assert.equal(c.adminAct(OWNER, { action: 'payout_paid', id: '../x', reference: 'abc' }).error, 'not_found');
  assert.equal(c.adminAct(OWNER, { action: 'nuke' }).error, 'bad_action');
  assert.equal(c.admin(user()).error, 'forbidden');
});

test('evaluate is a no-op on closed accounts', () => {
  const a = { status: 'failed', positions: [], balance: 1 }; assert.deepEqual(evaluate(a, () => 1, Date.now()), []);
});

test('refund / chargeback of the fee closes the account and the phases that grew out of it', () => {
  const { c } = setup(); const id = c.purchase({ uid: 'u1', product: 'ch-step2-10k', paymentId: 'cs_9', paymentIntent: 'pi_9' }).id;
  assert.equal(c.onRefund('pi_other'), null);
  assert.equal(c.onRefund('pi_9'), 'closed_1');
  assert.equal(c.list(user()).items.find((a) => a.id === id).status, 'failed');
});

test('Instant: no target — funded from day one, only the loss limit; first payout needs the minimum trading days', async () => {
  const s = setup(); const { c } = s; const u = user();
  assert.equal(PROGRAMS.find((p) => p.id === 'instant').phases.length, 0); assert.equal(CHALLENGE_PRODUCTS.length, 24); assert.equal(CATALOGUE['ch-instant-50k'].kind, 'challenge');
  const id = c.purchase({ uid: 'u1', email: 'trader@example.com', product: 'ch-instant-10k', paymentId: 'pi' }).id;
  let v = (await c.view(u, id)).account; assert.equal(v.phase, 'funded'); assert.equal(v.status, 'funded'); assert.equal(v.rules.target, null); assert.equal(v.rules.daily, null); assert.equal(v.rules.floor, 9400);
  await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.1 }); s.prices.XAUUSD = 2080; s.add(5000);   // +$800: way past any "target", still just funded
  let pos = (await c.view(u, id)).account.positions[0]; await c.close(u, id, pos.id);
  v = (await c.view(u, id)).account; assert.equal(v.status, 'funded'); assert.equal(v.profit, 800); assert.equal(v.funded.reward, 560);
  s.add(15 * 86_400_000);
  const KYC = { fullName: 'Trader One Example', country: 'JO', adult: true, terms: true };
  assert.equal(c.requestPayout(u, id, { method: 'paypal', details: { email: 'me@pp.com' }, kyc: KYC }).error, 'min_days', '1 trading day < 5');
  for (let d = 0; d < 4; d++) { s.add(86_400_000); s.prices.XAUUSD = 2000; s.add(5000); await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.01 }); pos = (await c.view(u, id)).account.positions[0]; await c.close(u, id, pos.id); }
  assert.ok(c.requestPayout(u, id, { method: 'usdt', details: { network: 'trc20', address: 'TXYZabcdefghijkmnopqrstuvwxyz12345' }, kyc: KYC }).ok);
  // only rule: max loss 6 %
  const id2 = c.purchase({ uid: 'u1', product: 'ch-instant-10k', paymentId: 'pi2' }).id;
  s.prices.XAUUSD = 2000; s.add(5000); await c.order(u, id2, { sym: 'XAUUSD', side: 'buy', lots: 0.2 });
  s.prices.XAUUSD = 1975; s.add(5000); v = (await c.view(u, id2)).account; assert.equal(v.status, 'funded', '−$500 in a day is fine: no daily limit');
  s.prices.XAUUSD = 1969; s.add(5000); v = (await c.view(u, id2)).account; assert.equal(v.status, 'failed'); assert.equal(v.failReason, 'max_loss');
});

test('quantity: several challenge accounts from one signed payment; never for plans; amount must be price × quantity', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chq-')); const access = createChannelAccess(dir);
  const { c } = setup(); const sent = [];
  const env = { STRIPE_SECRET_KEY: 'sk_test_abcdefghijklmnop123', STRIPE_WEBHOOK_SECRET: 'whsec_testsecret0123456789abcdef' };
  const fetchFn = async (url, o) => { sent.push(new URLSearchParams(o.body)); return { ok: true, json: async () => ({ url: 'https://checkout.stripe.com/c/x' }) }; };
  const b = createStripeBilling({ env, access, log: { error() {} }, fetchFn, onChallenge: (x) => c.purchase(x), onChallengeRefund: (pi) => c.onRefund(pi) });
  assert.equal((await b.checkout({ uid: 'u1', product: 'ch-step1-10k', origin: 'https://site.test', quantity: 3 })).status, 200);
  const f = sent[0]; assert.equal(f.get('line_items[0][quantity]'), '3'); assert.equal(f.get('metadata[qty]'), '3');
  await b.checkout({ uid: 'u1', product: 'monthly', origin: 'https://site.test', quantity: 3 }); assert.equal(sent[1].get('line_items[0][quantity]'), '1', 'plans: always one');
  await b.checkout({ uid: 'u1', product: 'ch-step1-10k', origin: 'https://site.test', quantity: 99 }); assert.equal(sent[2].get('line_items[0][quantity]'), '5', 'capped at 5');
  const md = Object.fromEntries([...f.entries()].filter(([k]) => k.startsWith('metadata[')).map(([k, v]) => [k.slice(9, -1), v]));
  const unit = CATALOGUE['ch-step1-10k'].cents;
  const s = { id: 'cs_test_q1', object: 'checkout.session', mode: 'payment', payment_status: 'paid', client_reference_id: 'u1', metadata: md, currency: 'usd', amount_subtotal: unit * 3, amount_total: unit * 3, payment_intent: 'pi_q1' };
  assert.equal(b.apply({ ...s, amount_subtotal: unit, amount_total: unit }), 'amount_mismatch', 'paid for one, asked for three');
  assert.equal(b.apply({ ...s, metadata: { ...md, qty: '5' } }), 'bad_session', 'quantity is signed');
  assert.equal(b.apply(s), 'granted'); assert.equal(b.apply(s), 'duplicate');
  assert.equal(c.list(user()).items.length, 3);
  assert.equal(c.onRefund('pi_q1'), 'closed_3');
});

/* ───────── v285: pending orders, warnings, daily summary, stats, retry discount, leaderboard ───────── */
import { statsOf, RETRY_PCT } from '../server/challenges.js';

test('pending orders: level must wait on the right side, fills at the market when reached, cancel works', async () => {
  const s = setup(); const { c } = s; const u = user(); const id = c.purchase({ uid: 'u1', product: 'ch-step2-10k', paymentId: 'p' }).id;
  for (const [b, e] of [[{ type: 'limit', side: 'buy', price: 2010 }, 'bad_price'], [{ type: 'stop', side: 'buy', price: 1990 }, 'bad_price'], [{ type: 'limit', side: 'sell', price: 1990 }, 'bad_price'],
    [{ type: 'limit', side: 'buy', price: 1990, sl: 1995 }, 'bad_sl'], [{ type: 'limit', side: 'buy', price: 1990, tp: 1985 }, 'bad_tp'], [{ type: 'iceberg', side: 'buy', price: 1990 }, 'bad_type'], [{ type: 'limit', side: 'buy' }, 'bad_price']])
    assert.equal((await c.order(u, id, { sym: 'XAUUSD', lots: 0.1, ...b })).error, e, JSON.stringify(b));
  const o = await c.order(u, id, { sym: 'XAUUSD', side: 'buy', type: 'limit', lots: 0.1, price: 1990, sl: 1980, tp: 2020 }); assert.ok(o.ok && o.pending.id);
  const o2 = await c.order(u, id, { sym: 'XAUUSD', side: 'sell', type: 'stop', lots: 0.1, price: 1950 });
  let v = (await c.view(u, id)).account; assert.equal(v.pending.length, 2); assert.equal(v.positions.length, 0); assert.equal(v.progress.days, 0, 'a waiting order is not a trading day');
  assert.equal(c.cancel(user('u2', 'x@y.z'), id, o2.pending.id).error, 'not_found'); assert.ok(c.cancel(u, id, o2.pending.id).ok);
  s.prices.XAUUSD = 1988; s.add(5000); await c.tick(); v = (await c.view(u, id)).account;
  assert.equal(v.pending.length, 0); assert.equal(v.positions.length, 1); assert.equal(v.positions[0].entry, 1988, 'filled at the market, not at a made-up price'); assert.equal(v.positions[0].sl, 1980); assert.equal(v.progress.days, 1);
  assert.ok(s.notes.some(([, t]) => /المعلّق/.test(t)));
});

test('pending order without margin at fill time is cancelled, and a failed account drops its pending orders', async () => {
  const s = setup(); const { c } = s; const u = user(); const id = c.purchase({ uid: 'u1', product: 'ch-step2-10k', paymentId: 'p' }).id;
  await c.order(u, id, { sym: 'XAUUSD', side: 'buy', type: 'limit', lots: 6, price: 1999 });   // 6 lots needs ~$12k margin > $10k equity
  s.prices.XAUUSD = 1998; s.add(5000); await c.tick(); let v = (await c.view(u, id)).account; assert.equal(v.pending.length, 0); assert.equal(v.positions.length, 0);
  await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.2 }); await c.order(u, id, { sym: 'XAUUSD', side: 'buy', type: 'limit', lots: 0.1, price: 1900 });
  s.prices.XAUUSD = 1972; s.add(5000); await c.tick(); v = (await c.view(u, id)).account; assert.equal(v.status, 'failed'); assert.equal(v.pending.length, 0);
});

test('warnings at 70 % and 90 % of a loss limit: once per level, daily resets next day', async () => {
  const s = setup(); const { c, notes } = s; const u = user(); const id = c.purchase({ uid: 'u1', product: 'ch-step2-10k', paymentId: 'p' }).id;
  const warns = () => notes.filter(([, t]) => /تنبيه حد الخسارة|قريب كتير/.test(t)).length;
  await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.2 });           // $20 per $1; daily limit $500
  s.prices.XAUUSD = 1990; s.add(5000); await c.tick(); assert.equal(warns(), 0, '−$200 = 40 %');
  s.prices.XAUUSD = 1982; s.add(5000); await c.tick(); assert.equal(warns(), 1, '−$360 = 72 %');
  s.prices.XAUUSD = 1981; s.add(5000); await c.tick(); assert.equal(warns(), 1, 'same level: no repeat');
  s.prices.XAUUSD = 1977; s.add(5000); await c.tick(); assert.equal(warns(), 2, '−$460 = 92 %');
  assert.equal((await c.view(u, id)).account.status, 'active');
  s.prices.XAUUSD = 1990; s.add(86_400_000); await c.tick();                  // new day: reference resets
  s.prices.XAUUSD = 1982; s.add(5000); await c.tick(); assert.equal(warns(), 3, 'new day: 72 % again → warned again');
});

test('daily summary only for days the account traded', async () => {
  const s = setup(); const { c, notes } = s; const u = user(); const id = c.purchase({ uid: 'u1', product: 'ch-step2-10k', paymentId: 'p' }).id;
  const sums = () => notes.filter(([, t]) => /ملخص يومك/.test(t)).length;
  s.add(86_400_000); await c.tick(); assert.equal(sums(), 0, 'no trades, no summary');
  await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.1 }); s.prices.XAUUSD = 2010; s.add(5000);
  const pos = (await c.view(u, id)).account.positions[0]; await c.close(u, id, pos.id);
  s.add(86_400_000); await c.tick(); assert.equal(sums(), 1);
  s.add(86_400_000); await c.tick(); assert.equal(sums(), 1);
});

test('statsOf: win rate, averages, profit factor, per symbol — from real closed trades', () => {
  assert.deepEqual(statsOf([]), { trades: 0 });
  const h = [{ sym: 'XAUUSD', pnl: 100, openAt: 0, closeAt: 600000 }, { sym: 'XAUUSD', pnl: -50, openAt: 0, closeAt: 600000 }, { sym: 'BTCUSDT', pnl: 300, openAt: 0, closeAt: 1800000 }, { sym: 'EURUSD', pnl: -150, openAt: 0, closeAt: 600000 }];
  const st = statsOf(h);
  assert.equal(st.trades, 4); assert.equal(st.winRate, 50); assert.equal(st.avgWin, 200); assert.equal(st.avgLoss, 100); assert.equal(st.profitFactor, 2); assert.equal(st.net, 200);
  assert.equal(st.best, 300); assert.equal(st.worst, -150); assert.equal(st.avgHoldMin, 15); assert.equal(st.bySymbol[0].sym, 'BTCUSDT');
  assert.equal(statsOf([{ sym: 'X', pnl: 5, openAt: 0, closeAt: 1 }]).profitFactor, null, 'no losses: no made-up factor');
});

test('retry discount: only the owner of a failed account, once, signed in the payment; leaderboard shows real passes without names by default', async () => {
  const s = setup(); const { c } = s; const u = user(); const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chr-')); const access = createChannelAccess(dir); const sent = [];
  const env = { STRIPE_SECRET_KEY: 'sk_test_abcdefghijklmnop123', STRIPE_WEBHOOK_SECRET: 'whsec_testsecret0123456789abcdef' };
  const b = createStripeBilling({ env, access, log: { error() {} }, fetchFn: async (url, o) => { sent.push(new URLSearchParams(o.body)); return { ok: true, json: async () => ({ url: 'https://checkout.stripe.com/c/x' }) }; }, onChallenge: (x) => c.purchase(x) });
  const id = c.purchase({ uid: 'u1', email: 'trader@example.com', name: 'Sami Haddad', product: 'ch-step1-10k', paymentId: 'p' }).id;
  assert.equal(c.retryQuote(u, id).error, 'not_eligible', 'still active');
  await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.3 }); s.prices.XAUUSD = 1980; s.add(5000); await c.tick();
  let v = (await c.view(u, id)).account; assert.equal(v.status, 'failed'); assert.deepEqual(v.retry, { pct: RETRY_PCT });
  assert.equal(c.retryQuote(user('u2', 'x@y.z'), id).error, 'not_found');
  const q = c.retryQuote(u, id); assert.equal(q.product, 'ch-step1-10k');
  assert.equal((await b.checkout({ uid: 'u1', product: q.product, origin: 'https://site.test', quantity: 5, coupon: 'X', retry: { account: q.account, pct: q.pct } })).status, 200);
  const f = sent[0]; const unit = CATALOGUE['ch-step1-10k'].cents; const price = unit - Math.round(unit * RETRY_PCT / 100);
  assert.equal(f.get('line_items[0][price_data][unit_amount]'), String(price)); assert.equal(f.get('line_items[0][quantity]'), '1'); assert.equal(f.get('metadata[retry]'), id); assert.ok(f.get('expires_at'));
  assert.equal(c.retryQuote(u, id).error, 'retry_open', 'one checkout at a time');
  const md = Object.fromEntries([...f.entries()].filter(([k]) => k.startsWith('metadata[')).map(([k, x]) => [k.slice(9, -1), x]));
  const sess = { id: 'cs_test_r1', object: 'checkout.session', mode: 'payment', payment_status: 'paid', client_reference_id: 'u1', metadata: md, currency: 'usd', amount_subtotal: price, amount_total: price, customer_details: { email: 'trader@example.com', name: 'Sami Haddad' } };
  assert.equal(b.apply({ ...sess, metadata: { ...md, retry: 'AT-AAAAAAAA' } }), 'bad_session', 'the retry account is signed');
  assert.equal(b.apply(sess), 'granted');
  assert.equal(c.list(u).items.length, 2); assert.equal(c.retryQuote(u, id).error, 'retry_used'); assert.equal((await c.view(u, id)).account.retry, null);
  assert.equal((await b.checkout({ uid: 'u1', product: 'monthly', origin: 'https://site.test', retry: { account: id, pct: 20 } })).status, 400, 'never on plans');
  // leaderboard
  assert.deepEqual(c.leaderboard().items, [], 'nothing passed yet → empty, never invented');
  const id2 = c.list(u).items.find((a) => a.id !== id).id;
  for (let d = 0; d < 3; d++) { s.add(86_400_000); s.prices.XAUUSD = 2000; s.add(5000); await c.order(u, id2, { sym: 'XAUUSD', side: 'buy', lots: 0.2 }); s.prices.XAUUSD = d ? 2001 : 2060; s.add(5000); const pp = (await c.view(u, id2)).account.positions[0]; await c.close(u, id2, pp.id); }
  assert.equal((await c.view(u, id2)).account.status, 'review');
  c.adminAct(OWNER, { action: 'review_approve', id: id2 });
  let lb = c.leaderboard().items; assert.equal(lb.length, 1); assert.equal(lb[0].who, null); assert.equal(lb[0].tag, id2.slice(-4)); assert.equal(JSON.stringify(lb).includes('trader@example.com'), false);
  assert.ok(c.setPublic(u, id2, { show: true }).ok); lb = c.leaderboard().items; assert.equal(lb[0].who, 'Sami', 'first name only, and only after opting in');
});

/* ───────── v286 audit fixes ───────── */
test('audit: when the live price fetch fails, orders and manual closes never fill on an old cached price', async () => {
  const s = setup(); const { c } = s; const u = user(); const id = c.purchase({ uid: 'u1', product: 'ch-step2-10k', paymentId: 'p' }).id;
  const o = await c.order(u, id, { sym: 'BTCUSDT', side: 'buy', lots: 0.01 }); assert.ok(o.ok);   // caches BTC at 50 000
  delete s.prices.BTCUSDT; s.add(60_000);                                                         // feed down for a minute; the market may have moved
  assert.equal((await c.order(u, id, { sym: 'BTCUSDT', side: 'sell', lots: 0.01 })).error, 'market_closed');
  assert.equal((await c.close(u, id, o.position.id)).error, 'market_closed');
  s.prices.BTCUSDT = 50500; s.add(1000); assert.ok((await c.close(u, id, o.position.id)).ok, 'works again once a fresh price arrives');
});

test('audit: two retry requests at the same moment open only one discounted checkout', async () => {
  const s = setup(); const { c } = s; const u = user(); const id = c.purchase({ uid: 'u1', product: 'ch-step1-10k', paymentId: 'p' }).id;
  await c.order(u, id, { sym: 'XAUUSD', side: 'buy', lots: 0.3 }); s.prices.XAUUSD = 1980; s.add(5000); await c.tick();
  const a = c.retryQuote(u, id); const b = c.retryQuote(u, id);
  assert.ok(a.product); assert.equal(b.error, 'retry_open', 'the first quote reserves the discount');
  c.retryRelease(u, id); assert.ok(c.retryQuote(u, id).product, 'a failed checkout gives the reservation back');
});

test('audit: the live check does not rewrite the store every few seconds when nothing important changed', async () => {
  const s = setup(); const { c } = s; const u = user(); const id = c.purchase({ uid: 'u1', product: 'ch-step2-10k', paymentId: 'p' }).id;
  await c.order(u, id, { sym: 'BTCUSDT', side: 'buy', lots: 0.01 });
  const file = path.join(s.dir, 'challenges.json'); const m0 = fs.statSync(file).mtimeMs; const before = fs.readFileSync(file);
  for (let i = 0; i < 5; i++) { s.prices.BTCUSDT = 50000 + i; s.add(5000); await c.tick(); }   // 25 s, no events, no new minute snapshot
  assert.ok(fs.readFileSync(file).equals(before), 'no rewrite inside the same minute');
  s.add(60_000); await c.tick(); assert.equal(fs.readFileSync(file).equals(before), false, 'the minute snapshot is saved'); assert.ok(m0 > 0);
});
