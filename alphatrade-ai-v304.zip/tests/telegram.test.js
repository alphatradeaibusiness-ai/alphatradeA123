import test from 'node:test';
import assert from 'node:assert/strict';
import { sendTelegram, telegramPayload, telegramConfigured } from '../server/telegram.js';

test('payload is plain text with title and body', () => {
  const p = telegramPayload('42', 'New signal', 'BTCUSDT BUY');
  assert.equal(p.chat_id, '42'); assert.match(p.text, /New signal\nBTCUSDT BUY/); assert.equal(p.parse_mode, undefined);
});
test('not configured → no request', async () => {
  let called = false;
  const r = await sendTelegram({ token: '', chatId: '1', title: 'x', body: 'y', fetchImpl: () => { called = true; } });
  assert.equal(r.ok, false); assert.equal(called, false);
  assert.equal(telegramConfigured({}), false); assert.equal(telegramConfigured({ TELEGRAM_BOT_TOKEN: 'a', TELEGRAM_CHAT_ID: 'b' }), true);
});
test('posts to the bot API and reports status', async () => {
  let url, init;
  const r = await sendTelegram({ token: 'T0K', chatId: '7', title: 'a', body: 'b', fetchImpl: async (u, i) => { url = u; init = i; return { ok: true, status: 200 }; } });
  assert.deepEqual(r, { ok: true, status: 200 });
  assert.equal(url, 'https://api.telegram.org/botT0K/sendMessage'); assert.equal(JSON.parse(init.body).chat_id, '7');
});
test('errors never expose the token and never throw', async () => {
  const r = await sendTelegram({ token: 'SECRET123', chatId: '7', title: 'a', body: 'b', fetchImpl: async () => { throw new Error('connect failed to https://api.telegram.org/botSECRET123/sendMessage'); } });
  assert.equal(r.ok, false); assert.ok(!String(r.status).includes('SECRET123'));
});
