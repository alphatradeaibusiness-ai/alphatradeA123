// v255 Alpha Partner Club — engine + HTTP (signed Stripe webhooks, owner-only admin, attribution, commissions, payouts).
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { createPartners, normEmail } from '../server/partners.js';
import { RANKS, PRICE_TIERS, defaultLevels, rankOfLevel } from '../src/config/partnerRanks.js';
import { CATALOGUE } from '../server/stripe.js';

const SECRET = 's'.repeat(40);
// a catalogue with all seven price points (the real one has 4 plans; owners can set prices in the plans editor)
const CAT = { p80: { id: 'p80', kind: 'plan', cents: 8000 }, p190: { id: 'p190', kind: 'plan', cents: 19000 }, p350: { id: 'p350', kind: 'plan', cents: 35000 }, p650: { id: 'p650', kind: 'plan', cents: 65000 },
  p750: { id: 'p750', kind: 'plan', cents: 75000 }, p850: { id: 'p850', kind: 'plan', cents: 85000 }, p1000: { id: 'p1000', kind: 'plan', cents: 100000 }, odd: { id: 'odd', kind: 'plan', cents: 12300 }, addon: { id: 'addon', kind: 'addon', cents: 1000 } };
const mk = (o = {}) => { const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-')); let t = Date.UTC(2026, 10, 9, 12); const sent = []; const paid = new Set();
  const p = createPartners({ dir, secret: SECRET, now: () => t, deliver: async (uid, n) => sent.push({ uid, ...n }), hasPaid: (uid) => paid.has(uid), catalogue: CAT, ...o });
  return { p, dir, sent, paid, adv: (ms) => { t += ms; }, at: () => t }; };
const U = (uid, email = `${uid}@mail.test`) => ({ uid, email, name: uid });
const MATRIX = () => { const m = {}; RANKS.forEach((r, i) => { m[r.id] = {}; for (const t of PRICE_TIERS) m[r.id][t] = { newPct: 10 + i, newFixedCents: 0, renPct: 4 + i / 2, renFixedCents: 0 }; }); return m; };
let pay = 0; const payment = (uid, product) => ({ paymentId: `cs_${++pay}`, pi: `pi_${pay}`, uid, product, listCents: CAT[product].cents, collectedCents: CAT[product].cents });

test('100 levels, 9 rank groups, strictly increasing requirements on the brief milestones', () => {
  const l = defaultLevels(); assert.equal(l.length, 100); assert.equal(new Set(l.map((x) => x.level)).size, 100);
  for (let i = 1; i < 100; i++) assert.ok(l[i].req > l[i - 1].req, `level ${i + 1}`);
  const first = (id) => l.find((x) => x.rank === id).req;
  assert.deepEqual(RANKS.map((r) => first(r.id)), [0, 10, 20, 40, 70, 100, 150, 250, 500]);
  assert.deepEqual(RANKS.map((r) => [r.from, r.to]), [[1, 10], [11, 20], [21, 35], [36, 50], [51, 65], [66, 80], [81, 90], [91, 99], [100, 100]]);
  assert.equal(rankOfLevel(100).id, 'legend'); assert.equal(rankOfLevel(1).id, 'core');
});

test('off by default, no commission numbers by default; config is validated (renewal must stay lower than new)', () => {
  const { p } = mk();
  assert.equal(p.join(U('a')).error, 'program_disabled');
  const cfg = p.adminView().config; assert.equal(cfg.enabled, false);
  assert.ok(Object.values(cfg.matrix).every((r) => Object.values(r).every((c) => c.newPct === 0 && c.renPct === 0 && c.newFixedCents === 0)));
  assert.equal(p.setConfig({ matrix: { core: { 8000: { newPct: 10, renPct: 10 } } } }).error, 'invalid_config');
  const bad = p.setConfig({ levels: defaultLevels().map((x, i) => ({ ...x, req: i === 50 ? 0 : x.req })) }); assert.equal(bad.error, 'invalid_config'); assert.ok(bad.details.includes('level_51_not_increasing'));
  const ok = p.setConfig({ enabled: true, matrix: MATRIX() }); assert.equal(ok.ok, true);
});

test('attribution: codes, self-referral, same e-mail (gmail dots/+), existing customer, duplicate registration, same network', () => {
  const { p, paid } = mk(); p.setConfig({ enabled: true, matrix: MATRIX() });
  const part = p.join(U('pa', 'john.doe@gmail.com'), { ipHash: 'netA' }).partner; assert.match(part.code, /^ALPHA-CORE-\d{5}$/);
  assert.equal(p.attach(U('pa', 'john.doe@gmail.com'), part.code).error, 'self_referral');
  assert.equal(p.attach(U('x1', 'johndoe+promo@gmail.com'), part.code).error, 'self_referral');
  assert.equal(normEmail('J.o.h.n.Doe+x@googlemail.com'), 'johndoe@gmail.com');
  paid.add('old'); assert.equal(p.attach(U('old'), part.code).error, 'existing_customer');
  assert.equal(p.attach(U('c1'), 'ALPHA-NOPE-1').error, 'bad_code');
  assert.equal(p.attach(U('c1'), part.code).ok, true);
  assert.equal(p.attach(U('c1'), part.code).already, true);
  const other = p.join(U('pb')).partner; assert.equal(p.attach(U('c1'), other.code).error, 'already_referred');
  assert.equal(p.attach(U('c1b', 'c1@mail.test'), other.code).error, 'duplicate_registration');
  assert.deepEqual(p.attach(U('c2'), part.code, { ipHash: 'netA' }).flags, ['same_network']);
  const c = p.click(part.code, 'h1'); assert.equal(c.counted, true); assert.equal(p.click(part.code, 'h1').counted, false); assert.equal(p.click(part.code, 'netA').counted, false, 'own clicks ignored');
});

test('commissions: new vs renewal for all seven plans, rank multiplier, idempotent webhooks, renewal never counted again', () => {
  const { p, sent } = mk(); p.setConfig({ enabled: true, matrix: MATRIX() });
  const part = p.join(U('pa')).partner;
  for (const [i, prod] of ['p80', 'p190', 'p350', 'p650', 'p750', 'p850', 'p1000'].entries()) {
    const uid = `n${i}`; p.attach(U(uid), part.code);
    const ev = payment(uid, prod);
    assert.equal(p.onPayment(ev), 'new:pending'); assert.equal(p.onPayment(ev), 'duplicate', 'Stripe retry');
    const c = p._db().commissions[0]; assert.equal(c.kind, 'new'); assert.equal(c.amountCents, Math.round(CAT[prod].cents * 0.10)); assert.equal(c.tier, CAT[prod].cents);
    const r = payment(uid, prod); assert.equal(p.onPayment(r), 'renewal:pending');
    const cr = p._db().commissions[0]; assert.equal(cr.kind, 'renewal'); assert.equal(cr.amountCents, Math.round(CAT[prod].cents * 0.04)); assert.ok(cr.amountCents < c.amountCents);
  }
  const me = p.me(U('pa')); assert.equal(me.qualified, 7, 'renewals do not count'); assert.equal(me.referral.paying, 7);
  assert.ok(sent.some((n) => n.title.includes('أول إحالة') || n.title.includes('first referral')));
  assert.equal(p.onPayment(payment('stranger', 'p80')), 'no_referral');
  p.attach(U('ad'), part.code); assert.equal(p.onPayment(payment('ad', 'addon')), 'not_commissionable');
  p.attach(U('od'), part.code); assert.equal(p.onPayment(payment('od', 'odd')), 'new:review', 'price not in the 7-point matrix → review');
  // the multiplier is a benefit: core has none; give gold a 1.5× and check it applies only with the benefit on
  const { p: q } = mk(); q.setConfig({ enabled: true, matrix: MATRIX(), ranks: { core: { multiplier: 3 } } });
  const qp = q.join(U('qa')).partner; q.attach(U('z1'), qp.code); q.onPayment(payment('z1', 'p80'));
  assert.equal(q._db().commissions[0].amountCents, 800, 'core has no multiplier benefit → 1×');
  q.setConfig({ ranks: { core: { benefits: ['dashboard', 'link', 'coupon', 'commission', 'stats_basic', 'multiplier'] } } });
  q.attach(U('z2'), qp.code); q.onPayment(payment('z2', 'p80')); assert.equal(q._db().commissions[0].amountCents, 2400);
});

test('financial protection: a commission that breaks the margin or a cap is held for review, amount unchanged, numbers explained', () => {
  const { p } = mk(); const m = MATRIX(); m.core[8000] = { newPct: 60, newFixedCents: 0, renPct: 10, renFixedCents: 0 };
  p.setConfig({ enabled: true, matrix: m, finance: { taxPct: 10, feePct: 2.9, feeFixedCents: 30, minMarginPct: 50, maxCommissionPct: 50 } });
  const part = p.join(U('pa')).partner; p.attach(U('c'), part.code);
  assert.equal(p.onPayment(payment('c', 'p80')), 'new:review');
  const c = p._db().commissions[0]; assert.equal(c.amountCents, 4800);
  assert.equal(c.taxCents, 800); assert.equal(c.feeCents, 232 + 30); assert.equal(c.netCents, 8000 - 800 - 262); assert.equal(c.appRemainCents, c.netCents - 4800);
  assert.deepEqual(c.issues.map((x) => x.code).sort(), ['max_pct', 'min_margin']);
  assert.ok(c.issues[0].ar && c.issues[0].en);
});

test('holding period → approved; refunds reverse unpaid and claw back paid; payouts need approval and a typed reference', () => {
  const { p, adv, sent } = mk(); p.setConfig({ enabled: true, matrix: MATRIX(), finance: { holdDays: 14 }, payout: { minPayoutCents: 1000 } });
  const part = p.join(U('pa')).partner; for (const u of ['a', 'b', 'c']) { p.attach(U(u), part.code); p.onPayment(payment(u, 'p650')); }
  assert.equal(p.me(U('pa')).earnings.pending, 3 * 6500); assert.equal(p.tick(), 0);
  adv(15 * 86_400_000); assert.equal(p.tick(), 3); assert.equal(p.me(U('pa')).earnings.available, 19500);
  const refunded = p._db().commissions.find((c) => c.customer && c.status === 'approved');
  assert.equal(p.onRefund({ pi: refunded.pi }), 'reversed'); assert.equal(p.onRefund({ pi: refunded.pi }), 'duplicate');
  assert.equal(p.me(U('pa')).earnings.available, 13000); assert.equal(p.me(U('pa')).qualified, 2, 'refunded customer no longer counts');
  assert.equal(p.requestPayout(U('pa'), { method: 'paypal', account: 'x' }).error, 'payout_details');
  const po = p.requestPayout(U('pa'), { method: 'paypal', account: 'pa@paypal.test' }).payout; assert.equal(po.cents, 13000);
  assert.equal(p.requestPayout(U('pa'), { method: 'paypal', account: 'pa@paypal.test' }).error, 'payout_open');
  assert.equal(p.adminAct({ action: 'payout_paid', id: po.id, reference: 'TX1' }).error, 'bad_state', 'cannot mark paid before approval');
  assert.equal(p.adminAct({ action: 'payout_approve', id: po.id }).ok, true); assert.ok(sent.some((n) => /payout|سحب/i.test(n.title)));
  assert.equal(p.adminAct({ action: 'payout_paid', id: po.id, reference: '' }).error, 'reference_required');
  assert.equal(p.adminAct({ action: 'payout_paid', id: po.id, reference: 'PAYPAL-7781' }).ok, true);
  const e = p.me(U('pa')).earnings; assert.equal(e.paid, 13000); assert.equal(e.available, 0);
  const paidOne = p._db().commissions.find((c) => c.status === 'paid'); assert.equal(p.onRefund({ paymentId: paidOne.paymentId, kind: 'chargeback' }), 'reversed');
  assert.equal(p.me(U('pa')).earnings.available, -6500, 'clawback nets against future earnings');
  assert.equal(p.requestPayout(U('pa'), { method: 'bank', account: 'IBAN123' }).error, 'below_minimum');
});

test('ranks: level-up from verified customers, rank bonus once, benefits change real behaviour (hold days, min payout, coupon discount)', () => {
  const { p, sent } = mk(); p.setConfig({ enabled: true, matrix: MATRIX(), coupon: { discountPct: 5 }, ranks: { bronze: { bonusCents: 2500, holdDays: 3 } } });
  const part = p.join(U('pa')).partner;
  for (let i = 0; i < 10; i++) { p.attach(U(`b${i}`), part.code); p.onPayment(payment(`b${i}`, 'p80')); }
  const me = p.me(U('pa')); assert.equal(me.level, 11); assert.equal(me.rank, 'bronze'); assert.equal(me.qualified, 10);
  assert.equal(p._db().commissions.filter((c) => c.kind === 'rank_bonus').length, 1); assert.equal(p._db().commissions.find((c) => c.kind === 'rank_bonus').amountCents, 2500);
  assert.ok(sent.some((n) => /Bronze|برونزي/.test(n.title)));
  assert.equal(me.benefits.holdDays, 30, 'bronze does not have the shorter_hold benefit');
  p.setConfig({ ranks: { bronze: { benefits: [...me.benefits.unlocked, 'shorter_hold', 'coupon_discount'], couponDiscountPct: 15 } } });
  assert.equal(p.me(U('pa')).benefits.holdDays, 3); assert.equal(p.quote(part.code, 'p80', 8000, 'newbie').discountCents, 1200);
  // refund one: back to level 10 (core); getting back to bronze does not pay the bonus twice
  p.onRefund({ paymentId: p._db().commissions.find((c) => c.kind === 'new').paymentId }); assert.equal(p.me(U('pa')).rank, 'core');
  p.attach(U('b10'), part.code); p.onPayment(payment('b10', 'p80')); assert.equal(p.me(U('pa')).rank, 'bronze');
  assert.equal(p._db().commissions.filter((c) => c.kind === 'rank_bonus').length, 1);
  assert.equal(p.quote(part.code, 'p80', 8000, 'pa').error, 'self_referral');
});

test('audit log is hash-chained (tampering is detected); CSV export; suspended partners earn nothing', () => {
  const { p } = mk(); p.setConfig({ enabled: true, matrix: MATRIX() });
  const part = p.join(U('pa')).partner; p.attach(U('c'), part.code); p.onPayment(payment('c', 'p190'));
  assert.equal(p.verifyAudit().ok, true); const db = p._db(); db.audit[1].data.partner = 'evil'; assert.equal(p.verifyAudit().ok, false); db.audit[1].data.partner = 'pa'; assert.equal(p.verifyAudit().ok, true);
  const csv = p.exportCsv('commissions'); assert.match(csv.split('\n')[0], /commission_cents,app_remaining_cents,margin_pct/); assert.equal(csv.split('\n').length, 2);
  assert.match(p.exportCsv('monthly'), /2026-11,pa,1900,0/);
  assert.equal(p.adminAct({ action: 'reject', id: p._db().commissions[0].id, reason: '' }).error, 'reason_required');
  p.adminAct({ action: 'suspend', uid: 'pa', reason: 'fraud' }); p.attach(U('d'), part.code);
  assert.equal(p.attach(U('e'), part.code).error, 'partner_inactive');
  assert.equal(p.click(part.code, 'zz').ok, false);
});

// ── HTTP: real server, forged Firebase tokens, signed Stripe webhooks ──
test('HTTP: owner-only admin, partner join/attach, signed webhook → commission, refund event, no client-side trust', async () => {
  const PROJECT = 'alphatrade-test'; const KID = 'k-pc'; const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const tok = (uid, email) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const pl = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, name: uid, email_verified: true, firebase: { sign_in_provider: 'password' } }));
    return `${h}.${pl}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${pl}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pch-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const WH = 'whsec_testsecret0123456789abcdef'; const sign = (raw) => { const t = Math.floor(Date.now() / 1000); return `t=${t},v1=${crypto.createHmac('sha256', WH).update(`${t}.${raw}`).digest('hex')}`; };
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: certFile, ADMIN_EMAILS: 'boss@site.test', STRIPE_SECRET_KEY: 'sk_test_abcdefghijklmnop123', STRIPE_WEBHOOK_SECRET: WH }, stdio: 'ignore' });
  const origin = `http://127.0.0.1:${port}`;
  const req = (p, { method = 'GET', body, who, headers = {} } = {}) => new Promise((resolve, reject) => {
    const b = body == null ? null : typeof body === 'string' ? body : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { origin, ...(who ? { authorization: `Bearer ${who}` } : {}), ...(b ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(b) } : {}), ...headers } }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => { let j = null; try { j = JSON.parse(s); } catch { j = s; } resolve({ status: res.statusCode, body: j }); }); });
    r.on('error', reject); if (b) r.write(b); r.end();
  });
  const BOSS = tok('boss', 'boss@site.test'), PA = tok('pa', 'partner@mail.test'), CU = tok('cu', 'cust@mail.test'), EVIL = tok('evil', 'evil@mail.test');
  try {
    for (let i = 0; i < 80; i++) { try { await req('/api/billing/status'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    assert.equal((await req('/api/partners/me')).status, 401);
    assert.equal((await req('/api/partners/admin', { who: EVIL })).status, 403, 'not an owner');
    assert.equal((await req('/api/partners/admin/config', { method: 'POST', who: EVIL, body: { enabled: true } })).status, 403);
    assert.equal((await req('/api/partners/join', { method: 'POST', who: PA })).body.code, 'telegram_required', 'channel-members-only by default');
    const m = MATRIX(); assert.equal((await req('/api/partners/admin/config', { method: 'POST', who: BOSS, body: { enabled: true, matrix: m, gate: { telegram: false } } })).status, 200);
    const j = await req('/api/partners/join', { method: 'POST', who: PA }); assert.equal(j.status, 200); const code = j.body.partner.code;
    assert.equal((await req('/api/partners/click', { method: 'POST', body: { code } })).body.counted, false, 'a click from the partner\'s own network is not counted');
    // a customer cannot claim to be someone else: the uid always comes from the verified token
    assert.equal((await req('/api/partners/attach', { method: 'POST', who: CU, body: { code, uid: 'pa' } })).body.ok, true);
    assert.equal((await req('/api/partners/attach', { method: 'POST', who: PA, body: { code } })).body.code, 'self_referral');
    // a forged "payment" from the page does nothing — only the signed webhook counts
    assert.equal((await req('/api/partners/payment', { method: 'POST', who: CU, body: { amount: 100000 } })).status, 404);
    const sess = { id: 'cs_test_pc1', object: 'checkout.session', mode: 'payment', payment_status: 'paid', payment_intent: 'pi_pc1', client_reference_id: 'cu', metadata: { uid: 'cu', product: 'annual' }, currency: 'usd', amount_total: CATALOGUE.annual.cents };
    const raw = JSON.stringify({ id: 'evt_1', type: 'checkout.session.completed', livemode: false, data: { object: sess } });
    assert.equal((await req('/api/billing/webhook', { method: 'POST', body: raw, headers: { 'stripe-signature': 'bad' } })).status, 400);
    assert.equal((await req('/api/billing/webhook', { method: 'POST', body: raw, headers: { 'stripe-signature': sign(raw) } })).body.result, 'granted');
    assert.equal((await req('/api/billing/webhook', { method: 'POST', body: raw, headers: { 'stripe-signature': sign(raw) } })).body.result, 'duplicate');
    let me = (await req('/api/partners/me', { who: PA })).body; assert.equal(me.qualified, 1); assert.equal(me.earnings.pending, 6500); assert.equal(me.history.length, 1); assert.equal(me.history[0].kind, 'new');
    assert.match(me.history[0].customer, /^C-[0-9A-F]{6}$/); assert.equal(JSON.stringify(me).includes('cust@mail.test'), false, 'no customer e-mail');
    const refund = JSON.stringify({ id: 'evt_2', type: 'charge.refunded', livemode: false, data: { object: { object: 'charge', payment_intent: 'pi_pc1', refunded: true, amount_refunded: 65000 } } });
    assert.equal((await req('/api/billing/webhook', { method: 'POST', body: refund, headers: { 'stripe-signature': sign(refund) } })).body.result, 'partners:reversed');
    me = (await req('/api/partners/me', { who: PA })).body; assert.equal(me.qualified, 0); assert.equal(me.earnings.pending, 0);
    const adm = (await req('/api/partners/admin', { who: BOSS })).body; assert.equal(adm.totals.partners, 1); assert.equal(adm.audit.check.ok, true);
    const csv = await req('/api/partners/admin/export?type=commissions', { who: BOSS }); assert.equal(csv.status, 200); assert.match(String(csv.body), /^id,created,partner/);
    assert.equal((await req('/api/partners/admin/export?type=commissions', { who: EVIL })).status, 403);
    assert.equal(fs.readFileSync(path.join(dir, 'partners.json')).includes(Buffer.from('partner@mail.test')), false, 'stored encrypted');
  } finally { child.kill(); }
});
