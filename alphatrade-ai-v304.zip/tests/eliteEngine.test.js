// v247 Alpha Elite Signals — engine, markets, entries, risk levels, statuses and the scanner (spec items 1–13).
// Real candles: tests/fixtures/elite-btc-1h.json (Twelve Data BTC/USD 1h), cut at moments where one strategy qualified.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { ELITE_MARKETS, resolveEliteMarket, eliteAvailability } from '../src/config/eliteMarkets.js';
import { findInstrument, INSTRUMENTS } from '../src/config/instruments.js';
import { evaluateMarket, trackSignal, markConflicts, practicalLimit, limitCap, levelsValid, isEliteDuplicate, ELITE_STRATEGIES, eliteSummary } from '../src/services/eliteEngine.js';
import { createEliteScanner } from '../src/services/eliteScanner.js';

const FX = JSON.parse(fs.readFileSync(new URL('./fixtures/elite-btc-1h.json', import.meta.url), 'utf8'));
const candles = (k) => FX.cases[k].map(([time, open, high, low, close]) => ({ time, open, high, low, close, volume: 0 }));
const BTC = ELITE_MARKETS.find((m) => m.id === 'BTCUSDT'); const BTCI = eliteAvailability(BTC).inst;
const atCase = (k, over = {}) => {
  const cs = candles(k); const last = cs.at(-1); const nowMs = (last.time + 3600) * 1000 + 5000;
  return { market: BTC, inst: BTCI, tf: '1h', ds: { mode: 'live', candles: cs, source: 'Twelve Data' }, htf: null, calendar: { events: [], at: nowMs, stale: false }, quote: { price: last.close, at: nowMs }, nowMs, signals: [], ...over };
};

test('1–3: every strategy can publish on its own — no consensus, no SMC confirmation, nothing waits for the others', () => {
  assert.deepEqual(ELITE_STRATEGIES.sort(), ['mean_reversion', 'smc', 'trend']);
  for (const k of ['smc', 'mean_reversion', 'trend']) {
    const r = evaluateMarket(atCase(k));
    assert.equal(r.state, 'ok', `${k}: published`);
    assert.deepEqual(r.signals.map((s) => s.strategy), [k], `${k}: only the strategy that qualified`);
    const others = ELITE_STRATEGIES.filter((x) => x !== k);
    for (const o of others) assert.ok(r.rejected.some((x) => x.strategy === o), `${k}: ${o} did not qualify and did not block it`);
    const s = r.signals[0];
    assert.equal(s.category, 'bitcoin'); assert.equal(s.tf, '1h'); assert.ok(['market', 'limit'].includes(s.entryType));
    assert.ok(s.reasons.length > 0 && s.explanation.ar && s.explanation.en, 'strategy-specific reasons and an explanation');
    assert.ok(s.expiresAt > s.createdAt);
  }
});

test('2b: a trend signal is published while SMC fails (injected engine result: one qualified trade only)', () => {
  const base = atCase('trend'); const real = evaluateMarket(base); const tr = real.signals[0];
  // the engine reports SMC not qualified and only the trend trade: the Elite layer must still publish trend
  const run = () => ({ strategies: [{ id: 'trend', status: 'qualified', checks: [{ id: 'x', label: { ar: 'شرط', en: 'check' }, status: 'pass' }] }, { id: 'smc', status: 'not_qualified', checks: [] }, { id: 'mean_reversion', status: 'not_qualified', checks: [] }],
    trades: [{ id: 'trend', direction: tr.direction, plan: { direction: tr.direction, entry: tr.entry, stop: tr.initialStop, targets: tr.targets } }], minRR: 0, globals: [] });
  const r = evaluateMarket({ ...base, run });
  assert.equal(r.signals.length, 1); assert.equal(r.signals[0].strategy, 'trend');
});

test('4: no signal when a strategy\'s own conditions are incomplete (or no strategy qualifies)', () => {
  const r = evaluateMarket(atCase('none'));
  assert.equal(r.signals.length, 0); assert.equal(r.state, 'no_trade');
  const run = () => ({ strategies: [{ id: 'smc', status: 'not_qualified', checks: [{ id: 'a', label: { ar: '', en: '' }, status: 'fail' }] }], trades: [], globals: [], reason: 'no_strategy' });
  assert.equal(evaluateMarket({ ...atCase('smc'), run }).signals.length, 0);
});

test('5: every requested market maps to the platform\'s real symbol, in its own category', () => {
  const want = { index: ['US100', 'US30', 'SPX500', 'US2000', 'UK100', 'GER40', 'FRA40', 'EU50', 'JP225', 'HK50', 'AUS200', 'CH20', 'SPA35', 'NETH25'], metal: ['XAUUSD', 'XAGUSD', 'XPTUSD', 'XPDUSD'], commodity: ['COPPER', 'WTI', 'BRENT'], bitcoin: ['BTCUSDT'] };
  for (const [cat, ids] of Object.entries(want)) for (const id of ids) {
    const m = ELITE_MARKETS.find((x) => x.id === id); assert.ok(m, id); assert.equal(m.cat, cat, id);
    const a = eliteAvailability(m); assert.equal(a.ok, true, `${id} available`); assert.equal(a.inst.symbol, m.symbol);
  }
  for (const [name, sym] of [['NAS100', 'US100'], ['Nasdaq 100', 'US100'], ['US500', 'SPX500'], ['S&P 500', 'SPX500'], ['Dow Jones', 'US30'], ['DAX 40', 'GER40'], ['CH20', 'SWISS20'], ['SPA35', 'SPAIN35'], ['NETH25', 'NED25'], ['BTCUSD', 'BTCUSDT'], ['WTI', 'USOIL'], ['Brent Crude Oil', 'UKOIL'], ['Russell 2000', 'US2000'], ['XPDUSD', 'XPDUSD']]) assert.equal(resolveEliteMarket(name)?.symbol, sym, name);
  // the extra Elite instruments are not added to the channel / EDH market list
  assert.equal(INSTRUMENTS.some((i) => ['US2000', 'XPDUSD'].includes(i.symbol)), false);
  // Bitcoin only: no other crypto, no forex
  assert.equal(ELITE_MARKETS.filter((m) => m.cat === 'bitcoin').length, 1);
  for (const x of ['ETHUSDT', 'SOL', 'XRP', 'PEPE', 'EURUSD']) assert.equal(resolveEliteMarket(x), null, x);
});

test('6: unsupported symbols are handled safely (never a substitute instrument)', () => {
  const vix = ELITE_MARKETS.find((m) => m.id === 'VIX');
  assert.deepEqual([eliteAvailability(vix).ok, eliteAvailability(vix).reason], [false, 'not_tradable']);
  assert.equal(findInstrument('NOPE'), null);
  assert.equal(eliteAvailability(null).ok, false);
  assert.equal(eliteAvailability({ id: 'X', symbol: 'NOPE', cat: 'index', names: [] }).reason, 'no_instrument');
  assert.equal(evaluateMarket({ market: vix, inst: null, tf: '1h', ds: null }).state, 'unavailable');
});

test('7: demo, missing, stale or corrupt data never produce a signal', () => {
  assert.equal(evaluateMarket(atCase('smc', { ds: { mode: 'demo', candles: candles('smc') } })).reason, 'demo_data');
  assert.equal(evaluateMarket(atCase('smc', { ds: null })).state, 'unavailable');
  const late = atCase('smc'); late.nowMs += 6 * 3600_000; late.quote.at = late.nowMs;
  const r = evaluateMarket(late); assert.ok(['stale', 'closed'].includes(r.state)); assert.equal(r.signals.length, 0);
  const bad = candles('smc'); bad[bad.length - 5] = { ...bad.at(-5), high: 1, low: 2 };
  assert.equal(evaluateMarket(atCase('smc', { ds: { mode: 'live', candles: bad } })).reason, 'bad_data');
  assert.equal(evaluateMarket(atCase('smc', { ds: { mode: 'live', candles: candles('smc').slice(-100) } })).state, 'insufficient');
});

test('8: duplicates are refused (same market, strategy, direction and setup)', () => {
  const a = evaluateMarket(atCase('smc')); assert.equal(a.signals.length, 1);
  const b = evaluateMarket(atCase('smc', { signals: a.signals }));
  assert.equal(b.signals.length, 0);
  const s = a.signals[0];
  assert.equal(isEliteDuplicate(a.signals, { ...s }, 100, s.createdAt), true);
  assert.equal(isEliteDuplicate(a.signals, { ...s, direction: s.direction === 'long' ? 'short' : 'long' }, 100, s.createdAt), false, 'the other direction is a different setup');
});

test('9: opposite directions on one market are both kept and flagged as a conflict', () => {
  const mk = (id, direction, strategy) => ({ id, symbol: 'US100', strategy, direction, status: 'entry_hit', entry: 100, stop: direction === 'long' ? 99 : 101, targets: direction === 'long' ? [101, 102, 103] : [99, 98, 97] });
  const list = markConflicts([mk('a', 'long', 'trend'), mk('b', 'short', 'smc'), { ...mk('c', 'long', 'trend'), symbol: 'GER40' }]);
  assert.deepEqual(list.map((x) => x.conflict), [true, true, false]);
});

test('10–11: market vs limit, instrument- and strategy-specific distance limits, far limits refused', () => {
  const s = evaluateMarket(atCase('trend')).signals[0];
  if (s.entryType === 'market') assert.ok(Math.abs(s.entry - atCase('trend').quote.price) <= 0.01 * s.entry, 'a market entry is the current price');
  // caps differ per market category and per strategy, and swing allows more than scalp
  assert.ok(limitCap('index', 'swing', 'smc').pct < limitCap('bitcoin', 'swing', 'smc').pct);
  assert.ok(limitCap('index', 'scalp', 'smc').atr < limitCap('index', 'swing', 'smc').atr);
  assert.ok(limitCap('metal', 'swing', 'trend').atr < limitCap('metal', 'swing', 'smc').atr);
  assert.equal(practicalLimit({ entry: 99.5, price: 100, atr: 1, cat: 'index', style: 'swing', strategy: 'smc' }).ok, true);
  assert.equal(practicalLimit({ entry: 98, price: 100, atr: 1, cat: 'index', style: 'swing', strategy: 'smc' }).reason, 'too_far_atr');
  assert.equal(practicalLimit({ entry: 99, price: 100, atr: 10, cat: 'index', style: 'swing', strategy: 'smc' }).reason, 'too_far_pct');
  // a far pending entry from the engine is not published (injected: the strategy level is 3 ATR away)
  const base = atCase('trend'); const last = base.ds.candles.at(-1); const far = last.close * 0.97;
  const run = () => ({ strategies: [{ id: 'smc', status: 'qualified', checks: [] }], trades: [{ id: 'smc', direction: 'long', plan: { direction: 'long', entry: far, stop: far * 0.99, targets: [far * 1.02, far * 1.03, far * 1.05] } }], minRR: 0, globals: [] });
  const r = evaluateMarket({ ...base, run });
  assert.equal(r.signals.length, 0, 'not published as an active trade');
  // an unfilled limit expires; price running to TP1 first cancels it
  const lim = { id: 'l', symbol: 'US100', style: 'swing', direction: 'long', status: 'active', entry: 100, stop: 98, targets: [103, 105, 108], hits: 0, createdAt: 0, expiresAt: 10 * 60_000 };
  trackSignal(lim, [{ time: 600, open: 101, high: 101.5, low: 100.5, close: 101 }], { nowMs: 11 * 60_000 + 61_000 });
  assert.equal(lim.status, 'expired');
  const run1 = { ...lim, status: 'active', expiresAt: 3600_000, checkedTo: undefined };
  trackSignal(run1, [{ time: 60, open: 101, high: 103.2, low: 100.6, close: 103 }], { nowMs: 200_000 });
  assert.deepEqual([run1.status, run1.closeReason], ['cancelled', 'tp1_before_entry']);
});

test('12: stop and targets are valid for every published signal; invalid levels are refused', () => {
  for (const k of ['smc', 'mean_reversion', 'trend']) {
    const s = evaluateMarket(atCase(k)).signals[0]; assert.ok(levelsValid(s), k);
    const sg = s.direction === 'long' ? 1 : -1;
    assert.ok((s.entry - s.stop) * sg > 0 && (s.targets[0] - s.entry) * sg > 0 && (s.targets[2] - s.targets[1]) * sg > 0);
  }
  assert.equal(levelsValid({ direction: 'long', entry: 100, stop: 101, targets: [102, 103, 104] }), false);
  assert.equal(levelsValid({ direction: 'long', entry: 100, stop: 99, targets: [102, 101, 104] }), false);
  assert.equal(levelsValid({ direction: 'short', entry: 100, stop: 101, targets: [99, 98] }), false);
  assert.equal(levelsValid({ direction: 'long', entry: NaN, stop: 99, targets: [101, 102, 103] }), false);
});

test('13: status transitions — ACTIVE → ENTRY HIT → TP1 (stop to entry) → TP2 → TP3, stops, same-candle rule', () => {
  const c = (i, o, h, l, cl) => ({ time: i * 60, open: o, high: h, low: l, close: cl });
  const s = { id: 's', symbol: 'XAUUSD', style: 'scalp', direction: 'long', status: 'active', entry: 100, stop: 98, targets: [102, 104, 106], hits: 0, createdAt: 0, expiresAt: 3600_000 };
  trackSignal(s, [c(1, 101, 101, 99.8, 100.2)], { nowMs: 130_000 }); assert.equal(s.status, 'entry_hit'); assert.ok(s.filledAt);
  trackSignal(s, [c(2, 100.2, 102.4, 100, 102)], { nowMs: 190_000 }); assert.deepEqual([s.status, s.hits, s.stop], ['tp1', 1, 100]);
  trackSignal(s, [c(3, 102, 104.5, 101.5, 104)], { nowMs: 250_000 }); assert.equal(s.status, 'tp2');
  trackSignal(s, [c(4, 104, 106.2, 103.5, 106)], { nowMs: 310_000 }); assert.equal(s.status, 'tp3'); assert.ok(s.closedAt);
  const t = { id: 't', symbol: 'XAUUSD', style: 'scalp', direction: 'short', status: 'entry_hit', entry: 100, stop: 102, targets: [98, 96, 94], hits: 0, createdAt: 0, filledAt: 0, expiresAt: 3600_000 };
  trackSignal(t, [c(1, 100, 102.5, 97.5, 99)], { nowMs: 130_000 });
  assert.deepEqual([t.status, t.closeReason], ['sl', 'stop'], 'stop and target in one candle: the stop counts first');
  const u = { ...t, id: 'u', status: 'entry_hit', stop: 102, hits: 0, closedAt: null, closeReason: null, checkedTo: undefined };
  trackSignal(u, [c(1, 100, 100.5, 97.8, 98)], { nowMs: 130_000 }); assert.equal(u.status, 'tp1');
  trackSignal(u, [c(2, 98, 100.3, 97.9, 100.2)], { nowMs: 190_000 }); assert.deepEqual([u.status, u.closeReason], ['sl', 'stop_at_entry']);
  const v = { ...t, id: 'v', status: 'entry_hit', stop: 102, hits: 0, closedAt: null, closeReason: null, checkedTo: undefined, expiresAt: 100_000 };
  trackSignal(v, [c(1, 100, 100.5, 99.5, 100)], { nowMs: 400_000 }); assert.equal(v.status, 'expired');
  const sum = eliteSummary([s, t, u, v]); assert.equal(sum.closed, 4); assert.equal(sum.tp1Rate, 50);
});

test('scanner: one failing market never stops the others; demo data publishes nothing; each candle is evaluated once', async () => {
  const fixture = candles('smc'); const last = fixture.at(-1);
  let clock = (last.time + 3600) * 1000 + 5000; let calls = 0;
  const deps = {
    getHistory: async (sym, tf) => { calls++; if (sym === 'US100') throw new Error('provider down'); if (sym === 'XAUUSD') return { mode: 'demo', candles: [] }; if (sym === 'BTCUSDT' && tf === '1h') return { mode: 'live', candles: fixture, source: 'Twelve Data' }; return { mode: 'live', candles: [] }; },
    quote: async (sym) => (sym === 'BTCUSDT' ? { price: last.close, at: clock } : null),
    prefetchHtf: async () => false, htfCandles: () => null, calendar: async () => ({ events: [], at: clock, stale: false }),
  };
  const saved = []; const scanner = createEliteScanner({ deps, store: { load: () => null, save: (s) => saved.push(JSON.parse(JSON.stringify(s))) }, log: { warn: () => {} }, now: () => clock, tfs: ['1h'] });
  const added = await scanner.scanOnce();
  assert.deepEqual(added.map((s) => `${s.symbol}|${s.strategy}`), ['BTCUSDT|smc']);
  const st = scanner.state();
  assert.equal(st.markets.VIX.state, 'unavailable');
  assert.equal(st.markets.XAUUSD.state, 'unavailable'); assert.equal(st.markets.XAUUSD.reason, 'demo_data');
  assert.ok(st.errors.some((e) => e.where.startsWith('US100')), 'the failure is logged');
  assert.ok(saved.length >= 1);
  const n = calls; assert.equal((await scanner.scanOnce()).length, 0); assert.ok(calls < n * 2, 'the same closed candle is not re-evaluated');
  clock += 3600_000; await scanner.scanOnce();
  assert.equal(scanner.state().signals.filter((s) => s.strategy === 'smc').length, 1, 'no duplicate on the next candle');
});
