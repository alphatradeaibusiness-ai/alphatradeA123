import fs from 'node:fs';
import assert from 'node:assert';
// A repeated top-level key silently replaces the earlier block (this once wiped the assistant's texts).
for (const f of ['ar', 'en']) {
  const src = fs.readFileSync(new URL(`../src/i18n/${f}.js`, import.meta.url), 'utf8');
  const seen = new Map();
  for (const m of src.matchAll(/^ {2}([A-Za-z0-9_]+): [{\[]/gm)) seen.set(m[1], (seen.get(m[1]) || 0) + 1);
  const dup = [...seen].filter(([, n]) => n > 1).map(([k]) => k);
  assert.deepStrictEqual(dup, [], `${f}.js has duplicate top-level keys: ${dup}`);
}
const { default: ar } = await import('../src/i18n/ar.js');
const { default: en } = await import('../src/i18n/en.js');
for (const ns of ['ai', 'aie', 'zs', 'smcv2', 'guard', 'fs', 'rg', 'dv', 'qn', 'ent', 'mo', 'au', 'real', 'ex', 'ed', 'rf', 'm5', 'ap', 'nt', 'mkey', 'ntf', 'sa']) {
  assert.deepStrictEqual(Object.keys(ar[ns] || {}).sort(), Object.keys(en[ns] || {}).sort(), `${ns} keys differ between ar and en`);
}
assert(ar.ai.welcome && ar.aie.probTitle);
console.log('i18n ok');
