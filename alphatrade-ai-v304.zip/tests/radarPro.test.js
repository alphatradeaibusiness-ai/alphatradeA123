import test from 'node:test';
import assert from 'node:assert/strict';
import { validateCandles, cleanCandles, macd, smartMoneyFlow, mtfAlignment, qualityScore, gradeOf, correlate, quickBiasOf } from '../src/services/radarPro.js';

const T0 = 1_762_000_000; // fixed epoch seconds
const bar = (i, o, h, l, c, step = 300) => ({ time: T0 + i * step, open: o, high: h, low: l, close: c, volume: 10 });
/** deterministic wave around a drift (no randomness) */
const series = (n, { drift = 0.05, amp = 1.5, period = 18, base = 100, step = 300 } = {}) => Array.from({ length: n }, (_, i) => {
  const mid = base + i * drift + Math.sin(i / period * Math.PI * 2) * amp; const o = mid - 0.1, c = mid + 0.1;
  return bar(i, o, Math.max(o, c) + 0.25, Math.min(o, c) - 0.25, c, step);
});

test('data quality: duplicates, gaps, bad prices, stale vs closed market', () => {
  const s = series(50);
  const now = (s.at(-1).time + 300) * 1000;
  assert.equal(validateCandles(s, '5m', { crypto: true, now }).state, 'live');
  const dup = [...s.slice(0, 10), s[9], ...s.slice(10)];
  assert.ok(validateCandles(dup, '5m', { crypto: true, now }).issues.includes('duplicates'));
  assert.equal(cleanCandles(dup).length, s.length, 'cleaned');
  const gap = [...s.slice(0, 20), ...s.slice(25)];
  assert.equal(validateCandles(gap, '5m', { crypto: true, now }).gaps, 5, '5 candles removed → 5 missing');
  assert.equal(validateCandles([...s.slice(0, 5), { ...s[5], high: 1, low: 2 }], '5m', { now }).state, 'bad');
  const later = now + 3600 * 1000;   // 1 h later on a weekday → stale, never "live"
  const wk = validateCandles(s, '5m', { crypto: true, now: Date.UTC(2026, 10, 4, 12) });
  assert.equal(wk.state, 'stale'); assert.equal(wk.live, false);
  assert.equal(validateCandles(s, '5m', { crypto: false, now: Date.UTC(2026, 10, 7, 12) }).state, 'closed', 'forex on a Saturday is closed, not stale');
  assert.ok(later > now);
});

test('MACD is positive on a rising series and negative on a falling one', () => {
  const up = series(120, { drift: 0.3, amp: 0.2 }).map((x) => x.close);
  const down = series(120, { drift: -0.3, amp: 0.2 }).map((x) => x.close);
  assert.ok(macd(up).line.at(-1) > 0); assert.ok(macd(down).line.at(-1) < 0);
  assert.ok(Number.isFinite(macd(up).hist.at(-1)));
});

test('smart money flow: equal highs become buy-side liquidity, a wick through them that closes back is a sweep', () => {
  const c = series(150, { drift: 0, amp: 2, period: 30 });
  // plant two equal swing highs at 103.0 and a later sweep candle (high 103.6, close back at 102.2)
  const peakAt = (i, h) => { c[i] = bar(i, h - 0.6, h, h - 1, h - 0.4); c[i - 1] = bar(i - 1, h - 1.4, h - 0.8, h - 1.8, h - 0.9); c[i + 1] = bar(i + 1, h - 0.9, h - 0.7, h - 1.9, h - 1.5); };
  peakAt(100, 103); peakAt(118, 103.01);
  for (let i = 121; i < 140; i++) c[i] = bar(i, 101, 101.6, 100.4, 101.2);
  c[140] = bar(140, 101.5, 103.6, 101.3, 102.2);
  for (let i = 141; i < 150; i++) c[i] = bar(i, 102, 102.4, 101.5, 101.8);
  const f = smartMoneyFlow(c);
  const eq = f.pools.find((p) => p.side === 'buy' && p.equal && Math.abs(p.price - 103.01) < 0.05);
  assert.ok(eq, 'equal highs found'); assert.equal(eq.taken, true); assert.equal(eq.swept, true);
  assert.ok(f.sweeps.some((s) => s.side === 'buy' && s.dir === 'bear'), 'buy-side sweep → bearish reaction');
  assert.ok(['bear', 'bull', 'neutral'].includes(f.bias));
  assert.ok(f.scenarios.length >= 1 && f.scenarios.every((s) => s.key));
});

test('timeframe alignment: real score, conflicts, higher timeframe against', () => {
  const all = mtfAlignment({ '5m': 0.6, '15m': 0.5, '1h': 0.7, '4h': 0.4, '1D': 0.1 }, '15m');
  assert.equal(all.dir, 'buy'); assert.equal(all.conflict, false); assert.equal(all.htfAgainst, false); assert.ok(all.score >= 80, `score ${all.score}`);   // a neutral daily frame counts half
  const against = mtfAlignment({ '5m': 0.5, '15m': 0.6, '1h': 0.3, '4h': -0.6, '1D': -0.5 }, '15m');
  assert.equal(against.htfAgainst, true); assert.equal(against.conflict, true); assert.ok(against.score < 60);
  assert.equal(mtfAlignment({ '15m': 0.6 }, '15m').score, null, 'one frame is not an alignment');
});

test('quality score: 8 parts, grades, capped when higher timeframes contradict', () => {
  const c = series(260, { drift: 0.08, amp: 0.6 });
  const r = { direction: 'long', trend: 1, rsi: 60, momentum: 62, atrPct: 0.4, filters: { unstable: [], weak: [] }, trades: 40, winRate: 64 };
  const smf = smartMoneyFlow(c.slice(0, -1));
  const good = qualityScore({ r, candles: c.slice(0, -1), smf, mtf: mtfAlignment({ '5m': 0.5, '15m': 0.6, '1h': 0.6, '4h': 0.5, '1D': 0.4 }, '15m') });
  assert.equal(good.parts.length, 8); assert.equal(good.parts.reduce((s, p) => s + p.max, 0), 100);
  assert.ok(good.parts.every((p) => p.why.length >= 1 && p.pts >= 0 && p.pts <= p.max));
  const capped = qualityScore({ r, candles: c.slice(0, -1), smf, mtf: mtfAlignment({ '5m': 0.5, '15m': 0.6, '1h': -0.4, '4h': -0.6, '1D': -0.5 }, '15m') });
  assert.ok(capped.score <= 59); assert.ok(capped.caps.includes('htfAgainst')); assert.equal(capped.grade, 'weak');
  assert.deepEqual([95, 85, 75, 65, 40].map(gradeOf), ['exceptional', 'strong', 'good', 'moderate', 'weak']);
});

test('correlation: positive, negative, insufficient, breakdown and divergence on aligned timestamps', () => {
  const a = series(260, { amp: 2, period: 12 });
  const same = a.map((x) => ({ ...x, close: x.close * 2 }));
  const inv = a.map((x) => ({ ...x, close: 400 - x.close }));
  assert.equal(correlate(a, same).sign, 'positive'); assert.ok(correlate(a, same).r > 0.99);
  assert.equal(correlate(a, inv).sign, 'negative'); assert.ok(correlate(a, inv).r < -0.99);
  assert.equal(correlate(a.slice(0, 30), same.slice(0, 30)).insufficient, true);
  const shifted = same.map((x) => ({ ...x, time: x.time + 1 }));   // no shared timestamps → never compared blindly
  assert.equal(correlate(a, shifted).insufficient, true);
  // last 50 bars move opposite: the relationship breaks down and the pair diverges
  const brk = same.map((x, i) => (i > 210 ? { ...x, close: 2 * (400 - a[i].close) - 400 } : x));
  const k = correlate(a, brk); assert.equal(k.breakdown, true); assert.equal(k.divergence, true);
});

test('quick bias uses only the candles it is given (no look-ahead)', () => {
  const c = series(400, { drift: 0.05 });
  const at = 300; const past = c.slice(0, at + 1);
  const future = [...past, ...series(100, { drift: -2, base: 50 }).map((x, i) => ({ ...x, time: c[at].time + (i + 1) * 300 }))];
  assert.equal(quickBiasOf(past), quickBiasOf(future.slice(0, at + 1)));
  assert.equal(quickBiasOf(c.slice(0, 100)), null, 'not enough history → no reading');
});
