import test from 'node:test';
import assert from 'node:assert/strict';
import { fibBreaks, strongZones } from '../src/services/fibSignals.js';

const mk = (closes, spread = 0.4) => closes.map((c, i) => ({ time: 1_700_000_000 + i * 900, open: i ? closes[i - 1] : c, high: Math.max(c, i ? closes[i - 1] : c) + spread, low: Math.min(c, i ? closes[i - 1] : c) - spread, close: c, volume: 100 }));
const LEVEL = [{ ratio: 0.5, price: 100 }];
const flat = (n, v) => Array.from({ length: n }, (_, i) => v + (i % 2 ? 0.2 : -0.2));

test('a close below the line is a SELL break, a close above is a BUY break', () => {
  const down = fibBreaks(mk([...flat(60, 103), 101, 99, 98.5, 98]), LEVEL);
  assert.equal(down.length, 1); assert.equal(down[0].dir, 'sell');
  const up = fibBreaks(mk([...flat(60, 97), 99, 101, 101.5, 102]), LEVEL);
  assert.equal(up.length, 1); assert.equal(up[0].dir, 'buy');
});

test('a wick through the line without a close beyond it is not a break', () => {
  const c = mk([...flat(60, 103), 102, 101.5, 101.2, 101.4]);
  c[c.length - 2].low = 98; // wick pierces 100, close stays above
  assert.equal(fibBreaks(c, LEVEL).length, 0);
});

test('a close only a hair beyond the line (inside 0.1 ATR) does not count', () => {
  assert.equal(fibBreaks(mk([...flat(60, 103), 101, 100.02, 100.03, 100.01], 0.4), LEVEL).length, 0);
});

test('the break disappears once price closes back on the other side', () => {
  assert.equal(fibBreaks(mk([...flat(60, 103), 99, 98.5, 100.03, 100.04]), LEVEL).length, 0, 'back above the line only by a hair: the sell is no longer valid and no buy is confirmed');
  const flipped = fibBreaks(mk([...flat(60, 103), 99, 98.5, 101, 102]), LEVEL);
  assert.equal(flipped.length, 1); assert.equal(flipped[0].dir, 'buy');
});

test('a break on the forming (last) candle is marked live', () => {
  const r = fibBreaks(mk([...flat(60, 103), 102, 101, 101.5, 99]), LEVEL);
  assert.equal(r[0].index, 63);
  assert.equal(r[0].live, true);
  const old = fibBreaks(mk([...flat(60, 103), 99, 98.5, 98.2, 98]), LEVEL);
  assert.equal(old[0].live, false);
});

test('an old break (more than 40 candles ago) is no longer shown', () => {
  assert.equal(fibBreaks(mk([...flat(60, 103), 99, ...flat(60, 98)]), LEVEL).length, 0);
});

test('htf alignment is reported per break', () => {
  const c = mk([...flat(60, 103), 101, 99, 98.5, 98]);
  const htfDown = new Array(c.length).fill(-1); const htfUp = new Array(c.length).fill(1);
  assert.equal(fibBreaks(c, LEVEL, { htf: htfDown })[0].htfAgrees, true);
  assert.equal(fibBreaks(c, LEVEL, { htf: htfUp })[0].htfAgrees, false);
});

test('strong zone: a Fibonacci line that sits on the volume POC and a swing the price reacted at twice', () => {
  // price oscillates around 100 for a long time (POC ~100, repeated swing highs/lows at ~100.6 / ~99.4)
  const closes = Array.from({ length: 260 }, (_, i) => 100 + Math.sin(i / 3) * 0.6);
  const c = mk(closes, 0.15);
  const z = strongZones(c, [{ ratio: 0.5, price: 100.7 }, { ratio: 0.236, price: 130 }]);
  assert.equal(z.length, 1);
  assert.equal(z[0].ratio, 0.5);
  assert.ok(z[0].kinds.includes('poc') || z[0].kinds.includes('hvn'));
  assert.ok(z[0].strength >= 2);
});

test('no strong zone for a line far from every other level', () => {
  const c = mk(Array.from({ length: 260 }, (_, i) => 100 + Math.sin(i / 3) * 0.6), 0.15);
  assert.equal(strongZones(c, [{ ratio: 0.382, price: 140 }]).length, 0);
});
