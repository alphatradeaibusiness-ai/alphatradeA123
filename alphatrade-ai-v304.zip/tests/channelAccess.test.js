import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createChannelAccess } from '../server/channelAccess.js';
import { channelPeriod } from '../src/config/channelPlans.js';
const now=Date.UTC(2026,0,31,12), until=Date.UTC(2027,0,31,12);
const setup=t=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'channel-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return {dir,access:createChannelAccess(dir)};};
const signals=(n,at=now)=>Array.from({length:n},(_,i)=>({id:`s${i}`,createdAt:at+i,status:'active',direction:'long',entry:100,stop:90,targets:[110,120,130],score:91,confirm:{score:95},evidence:{bars:[],zones:[{label:'OB'}]}}));
test('billing boundaries retain the original UTC day and time across February',()=>{
 assert.equal(channelPeriod(now,Date.UTC(2026,1,28,12)).end,Date.UTC(2026,2,31,12));
 assert.equal(channelPeriod(now,Date.UTC(2026,1,28,11,59)).end,Date.UTC(2026,1,28,12));
 assert.equal(channelPeriod(now,now-1),null);
});
test('no subscription sees no recommendations; grants cannot leak across accounts',t=>{
 const {access}=setup(t);const rows=signals(40);
 assert.equal(access.feed('a',rows,{now:now+100}).signals.length,0);
 access.grant('a',{product:'monthly',paymentId:'p1',startsAt:now,until},now);
 const r=access.feed('a',rows,{now:now+100});assert.equal(r.signals.length,30);assert.equal(r.allowance.used,30);assert.equal(r.allowance.remaining,0);
 assert.equal(r.signals[0].score,null);assert.deepEqual(r.signals[0].evidence.zones,[]);
 assert.equal(access.feed('b',rows,{now:now+100}).signals.length,0);
 assert.equal(access.feed('a',rows,{now:now+100}).allowance.used,30);
});
test('top-ups require a subscription, persist across restart and are idempotent per payment',t=>{
 const {dir,access}=setup(t);assert.throws(()=>access.grant('a',{product:'signals25',paymentId:'x'},now),/active_subscription/);
 access.grant('a',{product:'channel',paymentId:'p1',startsAt:now,until},now);
 access.grant('a',{product:'signals25',paymentId:'x'},now+100);
 assert.equal(access.grant('a',{product:'signals25',paymentId:'x'},now+100).duplicate,true);
 assert.equal(access.grant('b',{product:'annual',paymentId:'p1',startsAt:now,until},now).duplicate,true);
 const r=createChannelAccess(dir).feed('a',signals(70),{now:now+1000});assert.equal(r.allowance.total,55);assert.equal(r.signals.length,55);
 const next=Date.UTC(2026,1,28,12);
 const n=access.feed('a',signals(5,next).map(s=>({...s,id:'next'+s.id})),{now:next+100});assert.equal(n.allowance.total,30);assert.equal(n.allowance.used,5);
});
test('old granted trades remain trackable after expiry, new ones stay private',t=>{
 const {access}=setup(t);access.grant('a',{product:'quarterly',paymentId:'p',startsAt:now,until:now+1000},now);
 const rows=signals(2);access.feed('a',rows,{now:now+10});rows[0].status='sl';
 const r=access.feed('a',[...rows,...signals(4,now+2000).map(s=>({...s,id:'new'+s.id}))],{now:now+3000});
 assert.equal(r.allowance.active,false);assert.equal(r.signals.length,2);assert.equal(r.signals.find(s=>s.id==='s0').status,'sl');assert.equal(access.feed('a',[],{now:now+3001}).signals.length,2);
});
test('unfilled limit cancellation refunds once; activated limit loss is counted',t=>{
 const {access}=setup(t);access.grant('a',{product:'monthly',paymentId:'p',startsAt:now,until},now);
 const rows=signals(31).map(s=>({...s,order:'limit',status:'pending'}));access.feed('a',rows,{now:now+100});
 rows[0].status='cancelled';const r=access.feed('a',rows,{now:now+100});assert.equal(r.allowance.used,30);assert.equal(r.signals.length,31);
 const again=access.feed('a',rows,{now:now+100});assert.equal(again.allowance.used,30);
 rows[1].status='sl';rows[1].activatedAt=now+20;assert.equal(access.feed('a',rows,{now:now+100}).allowance.used,30);
});
test('cycle renewal does not count the same recommendation twice and plan changes require explicit replacement',t=>{
 const {access}=setup(t);access.grant('a',{product:'monthly',paymentId:'p',startsAt:now,until},now);
 access.feed('a',signals(40),{now:now+100});
 assert.throws(()=>access.grant('a',{product:'channel',paymentId:'p2',startsAt:now,until},now),/replacement/);
 const next=Date.UTC(2026,1,28,12);const r=access.feed('a',signals(40),{now:next+100});assert.equal(r.allowance.used,0);assert.equal(r.signals.length,30);
});
