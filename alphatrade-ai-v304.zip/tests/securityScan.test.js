// v235: the offline secret / risky-code scanner finds what it must find, and the project itself is clean (no high/critical).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { scan } from '../security/scan.mjs';

test('scanner: planted secrets and dangerous patterns are reported', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'scan-'));
  const k = (a, b) => a + b;   // built at run time so this test file itself holds no secret-looking literal
  fs.mkdirSync(path.join(dir, 'src'));
  fs.writeFileSync(path.join(dir, 'src', 'leak.js'), [
    `const a = '${k('sk-ant-api03-', 'A'.repeat(40))}';`, `const s = '${k('sk_live_', 'b'.repeat(30))}';`, `const w = '${k('whsec_', 'c'.repeat(30))}';`,
    `const g = '${k('ghp_', 'd'.repeat(36))}';`, `const p = '${k('-----BEGIN RSA ', 'PRIVATE KEY-----')}';`, 'eval(userInput);', "fetch(u, { agent: new https.Agent({ rejectUnauthorized: false }) });",
    `const x = import.meta.env.${k('VITE_ANTHROPIC', '_KEY')};`,
  ].join('\n'));
  const f = scan([dir]); const ids = new Set(f.map((x) => x.id));
  for (const id of ['anthropic-key', 'stripe-live-secret', 'stripe-webhook-secret', 'github-token', 'private-key', 'eval', 'tls-off', 'vite-secret']) assert.ok(ids.has(id), `missing ${id}`);
  assert.ok(f.every((x) => !/A{20}|b{20}|c{20}/.test(x.text)), 'secret values are redacted in the output');
});

test('scanner: the project has no high / critical finding', () => {
  const f = scan().filter((x) => ['high', 'critical'].includes(x.severity));
  assert.deepEqual(f.map((x) => `${x.id} ${x.file}:${x.line}`), []);
});
