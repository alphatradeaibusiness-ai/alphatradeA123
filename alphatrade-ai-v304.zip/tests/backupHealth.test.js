import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { createBackups } from '../server/backup.js';

test('backups: one per day, files copied as-is, old days pruned, backups never back up themselves', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk-'));
  fs.writeFileSync(path.join(dir, 'ai-config.json'), '{"enc":"x"}');
  fs.mkdirSync(path.join(dir, 'user-trades')); fs.writeFileSync(path.join(dir, 'user-trades', 'a.json'), '{"enc":"y"}');
  fs.writeFileSync(path.join(dir, 'ignore.tmp'), 'no');
  let t = Date.UTC(2026, 0, 1, 12); let snaps = 0;
  const b = createBackups({ dataDir: dir, env: { BACKUP_KEEP_DAYS: '3' }, now: () => t, snapshotBank: (f) => { snaps++; fs.writeFileSync(f, 'db'); }, log: { error() {} } });
  const r = b.run(); assert.equal(r.ok, true); assert.equal(r.files, 2); assert.equal(r.bank, true);
  assert.equal(b.run().skipped, 'exists'); assert.equal(snaps, 1);
  const day = path.join(dir, 'backups', '2026-01-01');
  assert.equal(fs.readFileSync(path.join(day, 'data', 'user-trades', 'a.json'), 'utf8'), '{"enc":"y"}');
  assert.equal(fs.existsSync(path.join(day, 'data', 'ignore.tmp')), false);
  assert.equal(fs.readFileSync(path.join(day, 'bank.db'), 'utf8'), 'db');
  for (let i = 1; i <= 4; i++) { t += 86_400_000; assert.equal(b.run().ok, true); }
  assert.deepEqual(fs.readdirSync(path.join(dir, 'backups')).sort(), ['2026-01-03', '2026-01-04', '2026-01-05']);
  assert.equal(fs.existsSync(path.join(dir, 'backups', '2026-01-05', 'data', 'backups')), false);
  const st = b.status(); assert.equal(st.count, 3); assert.equal(st.stale, false); assert.equal(st.keep, 3);
  // a failing snapshot leaves no half-written day behind
  t += 86_400_000;
  const bad = createBackups({ dataDir: dir, env: {}, now: () => t, snapshotBank: () => { throw new Error('disk full'); }, log: { error() {} } });
  assert.equal(bad.run().ok, false); assert.equal(fs.existsSync(path.join(dir, 'backups', '2026-01-06')), false);
  assert.equal(createBackups({ dataDir: dir, env: { BACKUP_DISABLED: '1' } }).run().skipped, 'disabled');
});

const req = (port, p, { method = 'GET', body, headers = {} } = {}) => new Promise((resolve, reject) => {
  const data = body === undefined ? null : (typeof body === 'string' ? body : JSON.stringify(body));
  const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { ...(data ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data) } : {}), ...headers } },
    (res) => { let buf = ''; res.on('data', (c) => (buf += c)); res.on('end', () => { let j = null; try { j = JSON.parse(buf); } catch { /* */ } resolve({ status: res.statusCode, body: j }); }); });
  r.on('error', reject); if (data) r.write(data); r.end();
});

test('server: /api/health reports bank + backups, the bank DB is snapshotted, client errors are scrubbed and rate-limited', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'hl-'));
  const port = 20000 + Math.floor(Math.random() * 20000);
  let log = '';
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), BANK_MASTER_KEY: 'm'.repeat(48), BANK_MODE: 'sandbox', SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), ANTHROPIC_API_KEY: '', BACKUP_TEST: '1' }, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.on('data', (d) => (log += d)); child.stderr.on('data', (d) => (log += d));
  try {
    let h;
    for (let i = 0; i < 80; i++) { try { h = await req(port, '/api/health'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    assert.equal(h.status, 200); assert.equal(h.body.ok, true); assert.equal(h.body.bank, 'sandbox');
    assert.equal(h.body.backups.enabled, true); assert.equal(h.body.backups.count, 1); assert.equal(h.body.backups.stale, false);
    const days = fs.readdirSync(path.join(dir, 'backups'));
    const db = path.join(dir, 'backups', days[0], 'bank.db');
    assert.ok(fs.statSync(db).size > 1000, 'bank snapshot written');
    const { DatabaseSync } = await import('node:sqlite');
    const s = new DatabaseSync(db, { readOnly: true }); assert.ok(s.prepare("SELECT count(*) n FROM sqlite_master WHERE type='table'").get().n > 5); s.close();
    assert.equal(JSON.stringify(h.body).includes(dir), false, 'no paths leaked');
    const e = await req(port, '/api/client-error', { method: 'POST', body: { kind: 'error', message: 'boom for ali@example.com token eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ4In0.sig card 4111111111111111', at: '/assets/x.js:1:2', where: '/?q=secret#/app' } });
    assert.equal(e.status, 204);
    assert.equal((await req(port, '/api/client-error', { method: 'POST', body: 'not json' })).status, 400);
    await new Promise((r) => setTimeout(r, 150));
    assert.match(log, /\[client-error\].*boom for \[email\] token \[token\] card \[number\]/);
    assert.equal(/ali@example|4111111111111111|secret/.test(log), false);
    let last;
    for (let i = 0; i < 12; i++) last = await req(port, '/api/client-error', { method: 'POST', body: { message: `x${i}` } });
    assert.equal(last.status, 429);
  } finally { child.kill(); }
});
