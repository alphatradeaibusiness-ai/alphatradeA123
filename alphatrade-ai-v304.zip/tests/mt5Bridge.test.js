import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createMt5Bridge, cleanOrder, commandLines, cleanAccount, cleanServer } from '../server/mt5Bridge.js';

const mk = () => createMt5Bridge({ dir: fs.mkdtempSync(path.join(os.tmpdir(), 'mt5-')), secret: 'test-secret-that-is-long-enough-32+chars' });
const hello = (over = {}) => ({ account: '5012345', server: 'MetaQuotes-Demo', company: 'MetaQuotes', build: 4500, balance: 1000, equity: 1000, currency: 'USD', leverage: 100, allowTrading: true, maxLot: 0.1, positions: [], ...over });

test('pairing: token shown once, stored hashed, bound to the account number and server', () => {
  const b = mk();
  const r = b.createLink('u1', { account: '5012345', server: 'MetaQuotes-Demo' });
  assert.match(r.token, /^mt5_[0-9a-f]{48}$/);
  assert.equal(JSON.stringify(b.list('u1')).includes(r.token), false);
  assert.equal(b.hello('mt5_' + '0'.repeat(48), hello()).error, 'bad_token');
  assert.equal(b.hello(r.token, hello({ account: '999' })).error, 'account_mismatch');
  assert.equal(b.hello(r.token, hello({ server: 'Other-Live' })).error, 'server_mismatch');
  assert.equal(b.hello(r.token, hello()).ok, true);
  assert.equal(b.list('u1').links[0].connected, true);
  assert.equal(b.list('u2').links.length, 0);   // another customer never sees it
});

test('no password field is accepted or stored', () => {
  const b = mk();
  const r = b.createLink('u1', { account: '5012345', server: 'MetaQuotes-Demo', password: 'secret!' });
  assert.equal(JSON.stringify(b.list('u1')).includes('secret!'), false);
  assert.ok(r.token);
});

test('orders: only to a connected terminal with trading enabled; picked up once; result documented', () => {
  const b = mk();
  const { token, link } = b.createLink('u1', { account: '5012345', server: 'MetaQuotes-Demo' });
  assert.equal(b.queueOrder('u1', link.id, { side: 'buy', symbol: 'EURUSD', volume: 0.01 }).error, 'terminal_offline');
  b.hello(token, hello({ allowTrading: false }));
  assert.equal(b.queueOrder('u1', link.id, { side: 'buy', symbol: 'EURUSD', volume: 0.01 }).error, 'trading_disabled');
  b.hello(token, hello());
  assert.equal(b.queueOrder('u2', link.id, { side: 'buy', symbol: 'EURUSD', volume: 0.01 }).error, 'not_found');
  const q = b.queueOrder('u1', link.id, { side: 'buy', symbol: 'EURUSD', volume: 0.01, sl: 1.05, tp: 1.2 });
  assert.equal(q.command.status, 'queued');
  const p1 = b.poll(token, hello());
  assert.equal(p1.commands.length, 1);
  assert.equal(b.poll(token, hello()).commands.length, 0);   // never delivered twice
  assert.equal(b.ack(token, { id: q.command.id, ok: true, ticket: '123456', retcode: 10009, price: 1.1 }).ok, true);
  const log = b.list('u1').links[0].log;
  assert.equal(log[0].status, 'done'); assert.equal(log[0].ticket, '123456');
});

test('validation of accounts, servers, orders and the EA line format', () => {
  assert.equal(cleanAccount('12ab'), null); assert.equal(cleanAccount(' 5012345 '), '5012345');
  assert.equal(cleanServer('Bad|Server'), null); assert.equal(cleanServer('ICMarketsSC-Demo'), 'ICMarketsSC-Demo');
  assert.equal(cleanOrder({ side: 'hold', symbol: 'EURUSD', volume: 1 }).error, 'bad_side');
  assert.equal(cleanOrder({ side: 'buy', symbol: 'EUR USD;', volume: 1 }).error, 'bad_symbol');
  assert.equal(cleanOrder({ side: 'buy', symbol: 'EURUSD', volume: 0 }).error, 'bad_volume');
  assert.equal(cleanOrder({ side: 'buy', symbol: 'EURUSD', volume: 1, sl: -1 }).error, 'bad_levels');
  const line = commandLines([{ id: 'c1', action: 'buy', symbol: 'XAUUSD', volume: 0.02, sl: 1, tp: 2, comment: 'a|b' }]);
  assert.equal(line, 'c1|buy|XAUUSD|0.02|1|2||a b');
});

test('the store is encrypted on disk', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mt5-'));
  const b = createMt5Bridge({ dir, secret: 'another-test-secret-long-enough-xx' });
  b.createLink('u1', { account: '5012345', server: 'MetaQuotes-Demo' });
  await new Promise((r) => setTimeout(r, 450));
  const raw = fs.readFileSync(path.join(dir, 'mt5-bridge.json'), 'utf8');
  assert.equal(raw.includes('5012345'), false);
  assert.equal(createMt5Bridge({ dir, secret: 'another-test-secret-long-enough-xx' }).list('u1').links.length, 1);
});

test('one-click apply: symbol mapping and the orders a recommendation becomes', async () => {
  const { mt5Symbol, ordersFor } = await import('../src/services/mt5Apply.js');
  assert.equal(mt5Symbol('BTCUSDT'), 'BTCUSD'); assert.equal(mt5Symbol('XAUUSD'), 'XAUUSD'); assert.equal(mt5Symbol('US30'), 'US30');
  const s = { symbol: 'ETHUSDT', direction: 'short', stop: 3520, targets: [3480, 3460, 3440], strategy: 'smc' };
  const one = ordersFor(s, 0.01);
  assert.equal(one.length, 1); assert.deepEqual([one[0].side, one[0].symbol, one[0].volume, one[0].sl, one[0].tp], ['sell', 'ETHUSD', 0.01, 3520, 3460]);
  const three = ordersFor(s, 0.1);
  assert.equal(three.length, 3);
  assert.deepEqual(three.map((o) => o.tp), [3480, 3460, 3440]);
  assert.equal(Math.round(three.reduce((a, o) => a + o.volume, 0) * 100) / 100, 0.1);
  assert.ok(three.every((o) => o.volume >= 0.01));
});
