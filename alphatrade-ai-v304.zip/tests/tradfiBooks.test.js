// v279 liquidity map: metals / energy / indices / stocks from real public order books (Binance TradFi perps + Hyperliquid xyz).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { LocalBook } from '../src/services/orderBook.js';
import { classify, pickTradfi, pickHl, hlToSnap, hlTrade, venueOf, rawOf, VALID_ID } from '../src/services/market/tradfiBooks.js';

test('futures diff stream: first event straddles the snapshot, then each pu must equal the previous u', () => {
  const b = new LocalBook();
  assert.equal(b.snapshot({ lastUpdateId: 100, bids: [['99', '1']], asks: [['101', '1']] }), true);
  assert.equal(b.apply({ U: 90, u: 95, pu: 89, b: [['98', '7']], a: [] }), true); assert.equal(b.bids.has(98), false);   // older
  assert.equal(b.apply({ U: 97, u: 105, pu: 96, b: [['99', '3']], a: [] }), true); assert.equal(b.bids.get(99), 3);       // straddles 100
  assert.equal(b.apply({ U: 120, u: 130, pu: 105, b: [], a: [['101', '0']] }), true); assert.equal(b.asks.has(101), false); // U jumps but pu chains
  assert.equal(b.apply({ U: 140, u: 150, pu: 131, b: [], a: [] }), false); assert.equal(b.ready, false);                   // broken chain
});

test('futures stream: a first event that starts after the snapshot is a gap', () => {
  const b = new LocalBook(); b.snapshot({ lastUpdateId: 100, bids: [], asks: [] });
  assert.equal(b.apply({ U: 103, u: 110, pu: 102, b: [], a: [] }), false);
});

test('spot stream behaviour is unchanged (no pu field)', () => {
  const b = new LocalBook(); b.snapshot({ lastUpdateId: 100, bids: [], asks: [] });
  assert.equal(b.apply({ U: 101, u: 102, b: [['5', '1']], a: [] }), true);
  assert.equal(b.apply({ U: 110, u: 111, b: [], a: [] }), false);
});

test('classify: metals, energy, indices, stocks', () => {
  assert.equal(classify('XAU'), 'metal'); assert.equal(classify('xag'), 'metal'); assert.equal(classify('COPPER'), 'metal');
  assert.equal(classify('CL'), 'energy'); assert.equal(classify('NATGAS'), 'energy');
  assert.equal(classify('SP500'), 'index'); assert.equal(classify('XYZ100'), 'index');
  assert.equal(classify('TSLA'), 'stock'); assert.equal(classify('NVDA'), 'stock');
});

test('pickTradfi keeps only trading TradFi perps (not the SPX6900 coin perp) and sorts by volume', () => {
  const info = { symbols: [
    { symbol: 'XAUUSDT', baseAsset: 'XAU', quoteAsset: 'USDT', contractType: 'TRADIFI_PERPETUAL', status: 'TRADING' },
    { symbol: 'TSLAUSDT', baseAsset: 'TSLA', quoteAsset: 'USDT', contractType: 'TRADIFI_PERPETUAL', status: 'TRADING' },
    { symbol: 'SPXUSDT', baseAsset: 'SPX', quoteAsset: 'USDT', contractType: 'PERPETUAL', status: 'TRADING' },
    { symbol: 'XPTUSDT', baseAsset: 'XPT', quoteAsset: 'USDT', contractType: 'TRADIFI_PERPETUAL', status: 'SETTLING' },
  ] };
  const l = pickTradfi(info, [{ symbol: 'XAUUSDT', quoteVolume: '5' }, { symbol: 'TSLAUSDT', quoteVolume: '9' }]);
  assert.deepEqual(l.map((x) => x.id), ['F:TSLAUSDT', 'F:XAUUSDT']);
  assert.equal(l[1].cls, 'metal'); assert.equal(l[0].cls, 'stock');
});

test('pickHl keeps indices and commodities of the dex, drops stocks and delisted', () => {
  const resp = [{ universe: [{ name: 'xyz:SP500' }, { name: 'xyz:TSLA' }, { name: 'xyz:GOLD' }, { name: 'xyz:XYZ100' }, { name: 'xyz:OLD', isDelisted: true }] },
    [{ dayNtlVlm: '1' }, { dayNtlVlm: '99' }, { dayNtlVlm: '3' }, { dayNtlVlm: '7' }, {}]];
  const l = pickHl(resp);
  assert.deepEqual(l.map((x) => x.id), ['H:xyz:XYZ100', 'H:xyz:GOLD', 'H:xyz:SP500']);
  assert.ok(l.every((x) => VALID_ID.test(x.id)));
});

test('Hyperliquid book and trade mapping', () => {
  const s = hlToSnap({ time: 5, levels: [[{ px: '100.5', sz: '2', n: 1 }], [{ px: '101', sz: '3', n: 2 }]] });
  assert.deepEqual(s, { lastUpdateId: 5, bids: [[100.5, 2]], asks: [[101, 3]] });
  const b = new LocalBook(); b.replace(s); assert.deepEqual(b.best(), { bid: 100.5, ask: 101 });
  assert.deepEqual(hlTrade({ tid: 7, px: '1', sz: '2', time: 3, side: 'B' }), { id: 7, price: 1, qty: 2, time: 3, buy: true });
  assert.equal(hlTrade({ side: 'A', px: '1', sz: '1', time: 1 }).buy, false);
});

test('ids: venue routing and validation', () => {
  assert.equal(venueOf('BTCUSDT'), 'spot'); assert.equal(venueOf('F:XAUUSDT'), 'fut'); assert.equal(venueOf('H:xyz:SP500'), 'hl');
  assert.equal(rawOf('H:xyz:SP500'), 'xyz:SP500'); assert.equal(rawOf('F:XAUUSDT'), 'XAUUSDT');
  for (const ok of ['BTCUSDT', 'F:XAGUSDT', 'H:xyz:SP500']) assert.ok(VALID_ID.test(ok), ok);
  for (const bad of ['<x>', 'F:xau', 'H:xyz:<b>', 'H:SP500']) assert.equal(VALID_ID.test(bad), false, bad);
});

test('liquidity page wires the TradFi venues', () => {
  const page = fs.readFileSync(new URL('../src/pages/liquidity.js', import.meta.url), 'utf8');
  assert.match(page, /fetchTradfiFutures/); assert.match(page, /fetchHlMarkets/); assert.match(page, /optgroup/); assert.match(page, /lqmarkets\.css/);
});
