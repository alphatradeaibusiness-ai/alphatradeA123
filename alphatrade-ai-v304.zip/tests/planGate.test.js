import test from 'node:test';
import assert from 'node:assert/strict';
import { TIERS, PLAN_ORDER, FREE_PAGES, canNav, setVerifiedPlan, setEnforce, lockPlan } from '../src/config/entitlements.js';

test('plan gate: free plan opens only the signal channel, AI recommendations and account pages', () => {
  setEnforce(true); setVerifiedPlan('free');
  for (const id of ['signals', 'ai-signal', 'pricing', 'billing', 'profile']) assert.equal(canNav(id), true, id);
  for (const id of ['home', 'markets', 'radar', 'studio', 'council', 'liquidity', 'mt5', 'lab', 'journal', 'rooms', 'bank', 'alpha', 'indicators']) assert.equal(canNav(id), false, id);
});
test('plan gate: every paid plan opens its own pages and none above', () => {
  setEnforce(true);
  const need = { radar: 'quarterly', lab: 'semiannual', mt5: 'annual', studio: 'prime', council: 'apex', liquidity: 'max' };
  for (const [page, plan] of Object.entries(need)) {
    for (const p of PLAN_ORDER) { setVerifiedPlan(p); assert.equal(canNav(page), TIERS[p].rank >= TIERS[plan].rank, `${p} → ${page}`); }
  }
  setVerifiedPlan('monthly'); assert.equal(canNav('home'), true); assert.equal(canNav('markets'), true);
});
test('plan gate: channel-only plan counts as free, locked pages name a plan', () => {
  setEnforce(true); setVerifiedPlan('channel'); assert.equal(canNav('markets'), false); assert.equal(canNav('signals'), true);
  assert.ok(PLAN_ORDER.includes(lockPlan('markets'))); assert.ok(FREE_PAGES.has('ai-signal'));
});
