import test from 'node:test';
import assert from 'node:assert';
import { evaluateCombo, MIN_TRADES } from '../src/services/signals.js';

const mkTrades = (n, winEvery, win, loss) => Array.from({ length: n }, (_, i) => {
  const w = i % winEvery !== 0; const pts = w ? win : loss;
  return { closeTime: 1000 + i * 60, points: pts, r: pts / 10, hits: w ? 1 : 0, direction: 'long', outcome: w ? 'tp3' : 'sl' };
});

test('a 70% win rate with a negative net R does not qualify', () => {
  const r = evaluateCombo(mkTrades(60, 4, 2, -40)); // 75% wins but losses are 20x bigger
  assert.equal(r.qualified, false);
});
test('too few trades never qualifies, enough profitable trades do', () => {
  assert.equal(evaluateCombo(mkTrades(MIN_TRADES - 1, 5, 30, -20)).qualified, false);
  assert.equal(evaluateCombo(mkTrades(60, 4, 30, -20)).qualified, true);
});

test('summarize reports the fee cost per trade in R and total fees', async () => {
  const { summarize } = await import('../src/services/backtest.js');
  const s = summarize([{ closeTime: 1, points: -3, r: -0.3, fee: 2, feeR: 0.2, hits: 0 }, { closeTime: 2, points: 5, r: 0.5, fee: 2, feeR: 0.2, hits: 1 }]).total;
  assert.equal(s.fees, 4);
  assert.ok(Math.abs(s.feeR - 0.2) < 1e-9);
  assert.ok(Math.abs(s.expectancy - 0.1) < 1e-9);
});

test('monthly cap: a trade is refused when realised loss + its worst case would pass the cap', async () => {
  const { monthBlocks } = await import('../src/services/backtest.js');
  const t0 = Date.UTC(2026, 4, 10) / 1000; // May 2026
  const o = { monthlyCapPts: 1000, pointSize: 1, feePct: 0 };
  const lost = [{ closeTime: t0, points: -600 }];
  assert.equal(monthBlocks(lost, { time: t0 + 86400 }, o, 400, 50000), false); // 600 + 400 = cap → allowed
  assert.equal(monthBlocks(lost, { time: t0 + 86400 }, o, 401, 50000), true); // would pass the cap
  assert.equal(monthBlocks(lost, { time: Date.UTC(2026, 5, 1) / 1000 }, o, 900, 50000), false); // new month: counter resets
  assert.equal(monthBlocks([], { time: t0 }, { ...o, monthlyCapPts: 0 }, 99999, 1), false); // cap off
  // the fee is part of the worst case
  assert.equal(monthBlocks([], { time: t0 }, { ...o, feePct: 0.1 }, 950, 100000), true); // 950 + 100 fee > 1000
});

test('live guard: monthly cap blocks a signal that could pass it', async () => {
  const { guardCheck } = await import('../src/services/riskGuard.js');
  const now = Date.UTC(2026, 4, 20);
  const sig = { symbol: 'BTCUSDT', direction: 'long', entry: 100000, stop: 99400, targets: [100600, 101200, 102100], status: 'sl', hits: 0, closedAt: now - 86400_000 * 2 };
  const base = { signals: [sig], now, cfg: { monthlyLossPts: 1000, dailyLossPct: 0, streakPause: 0, derivFilter: false, newsMinutes: 0, maxActive: 0 } };
  assert.equal(guardCheck({ ...base, candidate: { symbol: 'BTCUSDT', direction: 'long', riskPts: 300 } }).ok, true); // 600 + 300 ≤ 1000
  const r = guardCheck({ ...base, candidate: { symbol: 'BTCUSDT', direction: 'long', riskPts: 500 } });
  assert.equal(r.ok, false); assert.equal(r.key, 'monthly');
});

test('daily points cap: backtest refuses a trade that could pass the cap, live guard blocks too', async () => {
  const { dayBlocks } = await import('../src/services/backtest.js');
  const day = 1_700_000_000 - (1_700_000_000 % 86400);
  const trades = [{ closeTime: day + 100, points: -300 }];
  const o = { dailyCapPts: 500, pointSize: 1, feePct: 0 };
  assert.equal(dayBlocks(trades, { time: day + 200 }, o, 150, 100), false);
  assert.equal(dayBlocks(trades, { time: day + 200 }, o, 250, 100), true);
  assert.equal(dayBlocks(trades, { time: day + 86400 + 5 }, o, 250, 100), false);
  const { guardCheck } = await import('../src/services/riskGuard.js');
  const now = Date.now();
  const sig = { status: 'sl', symbol: 'BTCUSDT', direction: 'long', entry: 100, sl: 70, closedAt: now, closePrice: 70, pointSize: 1 };
  const r = guardCheck({ signals: [sig], candidate: { symbol: 'BTCUSDT', direction: 'long', riskPts: 250 }, cfg: { dailyLossPts: 200, dailyLossPct: 0, dailyLossR: 0, pointSizeOf: () => 1 }, now });
  assert.ok(r.ok === false ? r.key === 'dailyPts' : true);
});

test('execution filters: killzone, ATR band, level sweep, CVD divergence, void, DOM wall', async () => {
  const X = await import('../src/services/execFilters.js');
  const x = X.normalizeExec({ killzone: true });
  const day = Math.floor(1_700_000_000 / 86400) * 86400;
  assert.equal(X.inKillzone(day + 8 * 3600, x), true);
  assert.equal(X.inKillzone(day + 11 * 3600, x), false);
  assert.equal(X.inKillzone(day + 13 * 3600, x), true);
  assert.deepEqual([3, 10, 14].map((h) => X.inSilverBullet(Date.UTC(2026, 6, 1, h + 4) / 1000)), [true, true, true]); // EDT = UTC-4
  assert.equal(X.execActive(X.normalizeExec({})), false);
  // ATR band
  const A = new Array(60).fill(1); A[50] = 0.5; A[51] = 4; A[52] = 1.2;
  assert.ok(X.atrRatio(A, 50) < 0.7); assert.ok(X.atrRatio(A, 51) > 3); assert.ok(X.atrRatio(A, 52) > 0.7 && X.atrRatio(A, 52) < 3);
  // sweep of the previous day low then close back above it => long bias only
  const C = []; const t0 = day - 86400;
  for (let k = 0; k < 288 * 2; k++) { const t = t0 + k * 300; const base = 100; C.push({ time: t, open: base, high: base + 1, low: base - 1, close: base, volume: 10, buyVolume: 5 }); }
  const i = 288 + 100; C[i - 3] = { ...C[i - 3], low: 97 };               // wick under PDL (99)
  const Xp = X.prepareExec(C, { sweep: true });
  assert.equal(X.execBlock(Xp, i, 'long', 100), null);
  assert.equal(X.execBlock(Xp, i, 'short', 100), 'sweep');
  // CVD divergence: price higher high, CVD lower high blocks a buy
  const D = []; let price = 100;
  for (let k = 0; k < 40; k++) { const up = k % 10 < 5; price += up ? 1 : -1; const hi = price + 0.5; D.push({ time: k * 300, open: price, high: hi + (k > 20 ? 1 : 0), low: price - 0.5, close: price, volume: 10, buyVolume: k > 20 ? (up ? 5.2 : 3) : (up ? 8 : 3) }); }
  const Xc = X.prepareExec(D, { cvd: true });
  // deterministic divergence: swing highs at bars 10 (110) and 22 (112); CVD 500 then 300
  const P = []; for (let k = 0; k < 30; k++) { const h = k === 10 ? 110 : k === 22 ? 112 : 100 + (k % 3) * 0.1; P.push({ time: k * 300, open: 100, high: h, low: 99, close: 100, volume: 10, buyVolume: 5 }); }
  const cv = P.map((_, k) => (k < 10 ? 100 : k < 22 ? 500 : 300));
  const Xd = { x: X.normalizeExec({ cvd: true, cvdBars: 29 }), candles: P, cvd: cv, flow: true, A: [] };
  assert.equal(X.cvdDivergence(Xd, 29, 'long'), 'bearish');
  assert.equal(X.cvdDivergence({ ...Xd, cvd: cv.map((v, k) => (k >= 22 ? 900 : v)) }, 29, 'long'), null);
  const Pl = P.map((c, k) => ({ ...c, high: 101, low: k === 10 ? 90 : k === 22 ? 88 : 99 }));
  assert.equal(X.cvdDivergence({ ...Xd, candles: Pl, cvd: cv.map((v, k) => (k >= 22 ? 800 : v)) }, 29, 'short'), 'bullish');
  // no taker volume => the filter never blocks
  const Xn = X.prepareExec(D.map((c) => ({ ...c, buyVolume: null })), { cvd: true });
  assert.equal(X.execBlock(Xn, 39, 'long', 100), null);
  // DOM wall in front of a long
  const book = { asks: [[101, 1], [101.5, 1], [102, 1], [102.5, 1], [103, 40]], bids: [[99, 1]] };
  assert.ok(X.domWall(book, 'long', 100, 4));
  assert.equal(X.domWall(book, 'long', 100, 1), null);
  assert.equal(X.domWall(book, 'short', 100, 4), null);
});

test('legAnchors: Fibonacci follows the newest swing leg and extends to the newest extreme', async () => {
  const { legAnchors } = await import('../src/services/fibSignals.js');
  // up to a high at bar 40 (130), down to a low at bar 70 (100), then a bounce and a new lower low on the forming candle
  const C = [];
  for (let k = 0; k < 100; k++) {
    const p = k <= 40 ? 100 + k * 0.75 : k <= 70 ? 130 - (k - 40) : 100 + (k - 70) * 0.2;
    C.push({ time: 1000 + k * 300, open: p, high: p + 0.6, low: p - 0.6, close: p, volume: 10 });
  }
  const a = legAnchors(C, 120);
  assert.ok(a, 'a leg is found');
  assert.ok(a.high > 129 && a.high < 132 && a.low < 100 && a.low > 98);
  const D = C.slice(); D.push({ time: 1000 + 100 * 300, open: 104, high: 104.5, low: 95, close: 96, volume: 10 }); // forming candle prints a new low
  const b = legAnchors(D, 120);
  assert.equal(b.low, 95);
  assert.equal(b.high, a.high);
  assert.equal(legAnchors(C.slice(0, 30), 120), null);
});

test('aiProposal: entry, stop and targets from the AI side, only when no plan is open', async () => {
  const { aiProposal } = await import('../src/services/aiLive.js');
  const C = []; for (let k = 0; k < 120; k++) { const p = 100 + Math.sin(k / 5) * 3; C.push({ time: 1000 + k * 300, open: p, high: p + 1, low: p - 1, close: p, volume: 10 }); }
  const ds = { candles: C };
  const ai = { ready: true, side: 'short', riskAtr: 2, rrs: [1, 2, 3.5], tp: [{ p: 0.5 }, { p: 0.3 }, null], m: { edge: true } };
  const pr = aiProposal(ds, { ai, plan: null, rules: {} });
  assert.equal(pr.direction, 'short'); assert.equal(pr.entry, C.at(-2).close);
  assert.ok(pr.stop > pr.entry && pr.targets[0] < pr.entry && pr.targets[2] < pr.targets[1]);
  assert.ok(Math.abs((pr.stop - pr.entry) * 3.5 - (pr.entry - pr.targets[2])) < 1e-9);
  assert.deepEqual(pr.probs, [0.5, 0.3, null]);
  assert.equal(aiProposal(ds, { ai, plan: { entry: 1 }, rules: {} }), null);
  assert.equal(aiProposal(ds, { ai: { ready: false }, plan: null }), null);
});

test('stickyProposal: stays fixed while the candle moves, renews on side flip / stop / target / age', async () => {
  const { aiProposal, stickyProposal } = await import('../src/services/aiLive.js');
  const C = []; for (let k = 0; k < 120; k++) { const p = 100 + Math.sin(k / 5) * 3; C.push({ time: 1000 + k * 300, open: p, high: p + 1, low: p - 1, close: p, volume: 10 }); }
  const ai = { ready: true, side: 'long', riskAtr: 2, rrs: [1, 2, 3.5], tp: [{ p: 0.5 }, { p: 0.3 }, { p: 0.2 }], m: { edge: true } };
  const first = aiProposal({ candles: C }, { ai, plan: null, rules: {} });
  const C2 = C.map((c) => ({ ...c })); C2.at(-1).close += 0.4; C2.at(-1).high += 0.4; // forming candle moves a little
  const fresh = aiProposal({ candles: C2 }, { ai, plan: null, rules: {} });
  const kept = stickyProposal(first, fresh, C2);
  assert.equal(kept.entry, first.entry); assert.deepEqual(kept.targets, first.targets); assert.equal(kept.stop, first.stop);
  assert.notEqual(stickyProposal(first, { ...fresh, direction: 'short' }, C2).entry, undefined);
  assert.equal(stickyProposal(first, { ...fresh, direction: 'short' }, C2).direction, 'short');
  const C3 = C2.map((c) => ({ ...c })); C3.at(-1).low = first.stop - 1; // stop touched -> new proposal
  assert.equal(stickyProposal(first, fresh, C3), fresh);
  assert.equal(stickyProposal(null, fresh, C2), fresh);
  assert.equal(stickyProposal(first, null, C2), null);
});

test('execution filters: 4h order block + anomaly rejection', async () => {
  const X = await import('../src/services/execFilters.js');
  // 15m candles: flat drift, then a 4h bearish candle followed by a strong 4h displacement up => bullish OB
  const C = []; const t0 = Math.floor(1_700_000_000 / 14400) * 14400;
  for (let b = 0; b < 40; b++) for (let k = 0; k < 16; k++) {
    const t = t0 + b * 14400 + k * 900; let o = 100 + (b % 2) * 0.2, c = o + 0.05;
    let hi = Math.max(o, c) + 0.3, lo = Math.min(o, c) - 0.3;
    if (b === 30) { o = 101; c = 100.2; hi = 101.3; lo = 99.9; }                // bearish candle = the OB (low 99.9 high 101.3 in 4h terms)
    if (b === 31) { o = 100.3; c = k === 15 ? 106 : 100.3 + k * 0.38; hi = Math.max(o, c) + 0.2; lo = Math.min(o, c) - 0.2; }   // displacement
    C.push({ time: t, open: o, high: hi, low: lo, close: c, volume: 10 });
  }
  const x = X.normalizeExec({ htfOb: true });
  const P = X.prepareExec(C, { htfOb: true });
  assert.ok(P.obs.length >= 1, 'an order block was found');
  const ob = P.obs.find((o) => o.dir === 'long');
  assert.ok(ob && ob.lo < ob.hi);
  const iAfter = C.length - 1, t = C[iAfter].time;
  assert.ok(X.obAt(P, t, 'long', (ob.lo + ob.hi) / 2));
  assert.equal(X.obAt(P, t, 'short', (ob.lo + ob.hi) / 2), null);
  assert.equal(X.obAt(P, t, 'long', ob.hi + 10), null);
  assert.equal(X.execBlock(P, iAfter, 'long', ob.hi + 10), 'ob');
  // anomaly: long upper wick against a long, news spike, weak volume
  const mk = (o, h, l, c, v = 10) => ({ time: 0, open: o, high: h, low: l, close: c, volume: v });
  const base = Array.from({ length: 40 }, (_, k) => ({ time: k * 300, open: 100, high: 100.5, low: 99.5, close: 100.1, volume: 10 }));
  const t1 = (cand) => { const D = base.concat([{ ...cand, time: 40 * 300 }]); return X.anomaly(X.prepareExec(D, { anomaly: true }), 40, 'long'); };
  assert.equal(t1(mk(100, 101.5, 99.9, 100.2)), 'wick');
  assert.equal(t1(mk(100, 100.9, 99.9, 100.8, 4)), 'weakVol');
  assert.equal(t1(mk(100, 100.8, 99.8, 100.7, 12)), null);
  assert.equal(t1(mk(100, 106, 99.9, 105.9, 12)), 'spike');
  assert.equal(t1(mk(100.8, 100.9, 99.9, 100.0, 20)), 'opposingVol');
});

test('EDH: 5-minute close beyond the previous day high/low, T1/T2 in pips, BE after T1', async () => {
  const { backtestEdh, edhLevels } = await import('../src/services/backtest.js');
  const DAY = 86400, base = Math.floor(Date.UTC(2025, 0, 6) / 1000);
  const c = [];
  // Day 1 (Mon): range 100..110 on 5m candles; day 2: drifts inside, then closes above 110 and runs to the targets.
  for (let i = 0; i < 288; i++) { const m = 105 + Math.sin(i / 20) * 5; c.push({ time: base + i * 300, open: m, high: Math.min(110, m + 1), low: Math.max(100, m - 1), close: m, volume: 1 }); }
  for (let i = 0; i < 100; i++) { const t = base + DAY + i * 300; c.push({ time: t, open: 105, high: 106, low: 104, close: 105, volume: 1 }); }
  const t = base + DAY + 100 * 300;
  c.push({ time: t, open: 105, high: 111.5, low: 105, close: 111, volume: 1 });
  for (let k = 1; k <= 12; k++) c.push({ time: t + k * 300, open: 111 + k * 10, high: 111 + k * 10 + 5, low: 111 + k * 10 - 1, close: 111 + k * 10 + 4, volume: 1 });
  const lv = edhLevels(c.slice(0, 289));
  assert.equal(lv.high, 110); assert.equal(lv.low, 100);
  const r = backtestEdh(c, { tpGapPts: 0, tp3GapPts: 0, pointSize: 1, edhPipPts: 1, fee: 0, feePct: 0, minRiskPct: 0, edh: { m5: { t1Pips: 30, t2Pips: 75, slPips: 30 }, m1: { t1Pips: 30, t2Pips: 75, slPips: 30 } } });
  const all = [...r.trades, ...(r.open ? [r.open] : [])];
  assert.equal(all.length, 1);
  assert.equal(all[0].direction, 'long'); assert.equal(all[0].entry, 111);
  assert.equal(all[0].targets[0], 141); assert.equal(all[0].targets[1], 186);
  assert.equal(all[0].initialStop, 81);
  // T1 clamped to >= 30, T2 clamped to 70-80
  const r2 = backtestEdh(c, { tpGapPts: 0, tp3GapPts: 0, pointSize: 1, edhPipPts: 1, fee: 0, feePct: 0, minRiskPct: 0, edh: { m5: { t1Pips: 5, t2Pips: 200, slPips: 30 } } });
  const a2 = [...r2.trades, ...(r2.open ? [r2.open] : [])][0];
  assert.equal(a2.targets[0], 141); assert.equal(a2.targets[1], 191);
});

test('EDH zones: a swing high wicked and rejected is a sell sweep; an impulse after a down candle leaves a bullish OB', async () => {
  const { edhZones } = await import('../src/services/edhZones.js');
  const c = []; let t = 1_700_000_000;
  const add = (o, h, l, cl) => { c.push({ time: t, open: o, high: h, low: l, close: cl, volume: 1 }); t += 300; };
  for (let i = 0; i < 30; i++) add(100, 101, 99, 100.2 + (i % 2) * 0.1);
  add(100, 103, 100, 102);                              // swing high 103
  for (let i = 0; i < 8; i++) add(101, 102, 100, 101);
  add(101, 104, 101, 102.5);                            // wicks above 103, closes back below
  for (let i = 0; i < 6; i++) add(101, 102, 100, 101);
  add(101, 101.2, 99.5, 99.8);                          // last down candle
  add(99.8, 106, 99.8, 105.5);                          // displacement
  for (let i = 0; i < 4; i++) add(105, 106, 104.5, 105.5);
  const z = edhZones(c);
  assert.ok(z.sweeps.some((s) => s.dir === 'sell' && s.price === 103 && s.extreme === 104));
  assert.ok(z.obs.some((o) => o.dir === 'bull' && o.top === 101.2 && o.bottom === 99.5));
});

test('aiContext builds the rule text for the EDH strategy without throwing', async () => {
  const { aiContext } = await import('../src/services/analysis.js');
  const an = { symbol: 'BTCUSDT', tf: '5m', precision: 2, strategy: 'edh', rules: { edh: { slPips: 30, t1Pips: 30, t2Pips: 75 } }, plan: { stopMode: 'points', tpR: [1, 2, 3] }, rsi: [], last: { close: 1 }, momentum: {}, strength: {}, pressureTotals: {}, hasVolume: false };
  try { aiContext(an); } catch (e) { assert.ok(!/rules is not defined|Can't find variable/.test(e.message), e.message); }
});

test('EDH on 1m data: Target 2 needs a 5-minute close beyond it, a wick does not count', async () => {
  const { backtestEdh } = await import('../src/services/backtest.js');
  const base = Math.floor(Date.UTC(2025, 0, 6) / 1000);
  const mk = (confirmWick) => {
    const c = [];
    for (let i = 0; i < 1440; i++) { const m = 105 + Math.sin(i / 60) * 4; c.push({ time: base + i * 60, open: m, high: Math.min(110, m + 0.5), low: Math.max(100, m - 0.5), close: m, volume: 1 }); }
    const d2 = base + 86400;
    for (let i = 0; i < 300; i++) c.push({ time: d2 + i * 60, open: 105, high: 105.5, low: 104.5, close: 105, volume: 1 });
    // 5m slot starting at d2+300*60: its last minute closes above 110 -> breakout
    for (let k = 0; k < 5; k++) c.push({ time: d2 + (300 + k) * 60, open: 105 + k * 1.2, high: 106 + k * 1.2, low: 105 + k * 1.2, close: k === 4 ? 111 : 105 + k * 1.2 + 1, volume: 1 });
    // next minutes: touch T1 (141), wick through T2 (186) but close the slot below it
    const t0 = d2 + 305 * 60;
    for (let k = 0; k < 5; k++) c.push({ time: t0 + k * 60, open: 115, high: k === 1 ? 142 : k === 2 ? (confirmWick ? 190 : 150) : k === 4 && confirmWick ? 188 : 120, low: 113, close: k === 4 ? (confirmWick ? 187 : 130) : 120, volume: 1 });
    for (let k = 5; k < 8; k++) c.push({ time: t0 + k * 60, open: 130, high: 131, low: 129, close: 130, volume: 1 });
    return c;
  };
  const opts = (confirm5) => ({ tpGapPts: 0, tp3GapPts: 0, pointSize: 1, edhPipPts: 1, fee: 0, feePct: 0, minRiskPct: 0, edh: { m1: { t1Pips: 30, t2Pips: 75, slPips: 30 }, confirm5 } });
  const wick = backtestEdh(mk(false), opts(true));
  const a = [...wick.trades, ...(wick.open ? [wick.open] : [])][0];
  assert.ok(a && a.hits === 1, 'T1 only on a wick');
  const free = backtestEdh(mk(false), opts(false));
  assert.ok(free.trades.length + (free.open ? 1 : 0) >= 1);
  const ok = backtestEdh(mk(true), opts(true));
  const b = ok.trades[0];
  assert.ok(b && b.hits === 3, 'T2 on a confirmed 5m close beyond it');
});

test('EDH zones: a sweep is only reported after the candle that swept the swing', async () => {
  const { edhTimeline } = await import('../src/services/edhZones.js');
  const c = []; let t = 1_700_000_000;
  const add = (o, h, l, cl) => { c.push({ time: t, open: o, high: h, low: l, close: cl, volume: 1 }); t += 300; };
  for (let i = 0; i < 30; i++) add(100, 101, 99, 100.2 + (i % 2) * 0.1);
  add(100, 103, 100, 102);
  for (let i = 0; i < 8; i++) add(101, 102, 100, 101);
  add(101, 104, 101, 102.5);
  for (let i = 0; i < 12; i++) add(101, 102, 100, 101);
  const T = edhTimeline(c);
  const s = T.sweeps.find((x) => x.dir === 'sell');
  assert.ok(s);
  assert.ok(s.idx >= 39, 'the sweep belongs to the candle that wicked past the swing high, not earlier');
});

test('EDH trend filter: a long break below the 200h-style EMA is skipped, with the trend it is taken', async () => {
  const { backtestEdh, rulesFrom, EDH_DEFAULTS } = await import('../src/services/backtest.js');
  const k = []; const add = (t, o, h, l, cl) => k.push({ time: t, open: o, high: h, low: l, close: cl, volume: 1 });
  const d = 86400;
  for (let i = 0; i < 288; i++) add(i * 300, 110, 110.2, 109.8, 110);                                // day 0: a high plateau (the EMA remembers it)
  for (let i = 0; i < 576; i++) add(d + i * 300, 100, 101, 99, 100 + (i % 2 ? 0.2 : -0.2));       // days 1-2: 99 - 101
  for (let i = 0; i < 40; i++) add(3 * d + i * 300, 100, 100.3, 99.7, 100);                          // day 3 before the break
  add(3 * d + 40 * 300, 100, 101.6, 99.9, 101.4);                                                    // 5m close above yesterday's high
  for (let i = 41; i < 60; i++) add(3 * d + i * 300, 101.4, 101.6, 101.2, 101.5);
  const run = (trendHours) => {
    const r = backtestEdh(k, { ...rulesFrom({}, { type: 'crypto', symbol: 'X', pointSize: 0.01 }), pointSize: 0.01, edhPipPts: 10, feePct: 0, forced: 'long', edh: { ...EDH_DEFAULTS, trendHours }, openOnLast: false });
    return { n: r.trades.length + (r.open ? 1 : 0), rejects: r.rejects };
  };
  assert.equal(run(0).n, 1);                   // filter off: taken
  assert.equal(run(2).n, 1);                   // a fast EMA (~100) is below the price: with the trend
  const slow = run(72);                        // the slow EMA still remembers 110: this long is against the trend
  assert.equal(slow.n, 0);
  assert.ok(slow.rejects.trend >= 1);
});

test('EDH: distinct targets per timeframe, and daily candles supply yesterday high/low on a short 1m history', async () => {
  const { edhTargets, edhLevels } = await import('../src/services/backtest.js');
  const a = edhTargets({ m1: { t1Pips: 30, t2Pips: 70, slPips: 30 }, m5: { t1Pips: 45, t2Pips: 80, slPips: 40 } }, 60);
  const b = edhTargets({ m1: { t1Pips: 30, t2Pips: 70, slPips: 30 }, m5: { t1Pips: 45, t2Pips: 80, slPips: 40 } }, 300);
  assert.deepEqual(a, { t1: 30, t2: 70, sl: 30 }); assert.deepEqual(b, { t1: 45, t2: 80, sl: 40 });
  assert.equal(edhTargets({ m1: { t1Pips: 5, t2Pips: 999 } }, 60).t1, 30); assert.equal(edhTargets({ m1: { t1Pips: 5, t2Pips: 999 } }, 60).t2, 80);
  const day = Math.floor(Date.UTC(2025, 0, 7) / 1000);
  const m1 = Array.from({ length: 120 }, (_, i) => ({ time: day + 3600 * 10 + i * 60, open: 100, high: 101, low: 99, close: 100, volume: 1 }));
  assert.equal(edhLevels(m1), null);
  const lv = edhLevels(m1, [{ time: day - 86400, open: 1, high: 120, low: 90, close: 100 }]);
  assert.equal(lv.high, 120); assert.equal(lv.low, 90);
});

test('AlphaRadar filters: stretched RSI, thin volume, ATR spike and a flipping bias are graded weak/unstable', async () => {
  const { radarFilters, radarVerdict } = await import('../src/services/radarFilters.js');
  const mk = (n, f) => Array.from({ length: n }, (_, i) => f(i));
  // steady uptrend, normal volume
  const up = mk(300, (i) => { const p = 100 + i * 0.3 + Math.sin(i / 3); return { time: i * 900, open: p - 0.2, high: p + 0.6, low: p - 0.6, close: p, volume: 100 + (i % 5) }; });
  const f = radarFilters(up, 'long');
  assert.ok(f && f.hasVolume && f.stable && !f.unstable.length);
  assert.ok(Number.isFinite(f.atrRatio) && f.atrRatio > 0.5 && f.atrRatio < 2.2);
  // thin volume on the last 3 closed candles
  const thin = up.map((c, i) => (i >= 296 ? { ...c, volume: 10 } : c));
  assert.ok(radarFilters(thin, 'long').weak.includes('volThin'));
  assert.equal(radarVerdict(radarFilters(thin, 'long'), 90), 'weak');
  // ATR spike on the last closed candle
  const spike = up.map((c, i) => (i === 298 ? { ...c, high: c.close + 25, low: c.close - 25 } : c));
  const fs = radarFilters(spike, 'long');
  assert.ok(fs.unstable.includes('atrSpike')); assert.equal(radarVerdict(fs, 90), 'unstable');
  // no volume feed: the volume check is skipped, not failed
  const nov = up.map((c) => ({ ...c, volume: undefined }));
  const fn = radarFilters(nov, 'long'); assert.equal(fn.hasVolume, false); assert.ok(!fn.weak.includes('volThin'));
  // a strong, clean reading with a good score is "strong"
  assert.equal(radarVerdict(f, 80), f.weak.length ? 'weak' : 'strong');
});

test('watch tier: positive but below the full bar is "watch", never "qualified"; losing combos are neither', () => {
  const w = evaluateCombo(mkTrades(24, 3, 30, -20)); // ~67% over 24 trades: below MIN_TRADES
  assert.equal(w.qualified, false);
  assert.equal(w.watch, true);
  assert.equal(evaluateCombo(mkTrades(60, 4, 30, -20)).watch, false); // fully qualified is not "watch"
  assert.equal(evaluateCombo(mkTrades(40, 4, 2, -40)).watch, false); // negative R
  assert.equal(evaluateCombo(mkTrades(10, 3, 30, -20)).watch, false); // too few trades
});

test('liveEntry: a recommendation is only sent while it is still valid at the live price', async () => {
  const { liveEntry } = await import('../src/services/signals.js');
  const long = { direction: 'long', entry: 100, stop: 98, targets: [102, 104, 106], order: 'market' };
  assert.equal(liveEntry(long, 100.5, { reprice: true }).entry, 100.5);   // AI engine: enters at the live price
  assert.equal(liveEntry(long, 100.5).entry, 100);                        // EDH / LBR: their own entry is kept
  assert.equal(liveEntry(long, 97.9), null);                              // already beyond the stop
  assert.equal(liveEntry(long, 102.1), null);                             // already past target 1
  assert.equal(liveEntry(long, 101.5, { reprice: true }), null);          // reward to TP2 below 1R from the live price
  const short = { direction: 'short', entry: 100, stop: 102, targets: [98, 96, 94], order: 'market' };
  assert.equal(liveEntry(short, 99.6, { reprice: true }).entry, 99.6);
  assert.equal(liveEntry(short, 102.5), null);
  const lim = { ...long, order: 'limit', status: 'pending' };
  assert.equal(liveEntry(lim, 103), lim);                                 // a limit order keeps its price
  assert.equal(liveEntry(long, NaN), null);
});
