// Shared cache in front of the public market-data upstreams (Binance, Yahoo, Forex Factory) — v229, from the load test.
// Without it every visitor's chart / scanner request was forwarded 1:1, so 1 000 visitors meant 1 000× the upstream calls from
// ONE server IP: slow under load and a sure way to get the IP rate-limited or banned by the exchange.
//  • micro-cache: identical requests inside a short window share one answer (1–2 s for live prices, longer for slow data)
//  • request coalescing: while one upstream call is in flight, identical requests wait for it instead of firing their own
//  • bounded upstream concurrency (queue with a deadline) so a spike cannot open thousands of outbound sockets
//  • stale-if-error: if the upstream fails or times out, a recent answer (≤ 60 s) is served, marked X-Cache: STALE
//  • bounded memory (entries + bytes); only 200 answers are cached for long, errors only for 1 s
export function createProxyCache({ maxEntries = 1000, maxBytes = 64 * 1024 * 1024, maxUpstream = 48, queueMs = 8000, staleMs = 60_000, fetchImpl = fetch } = {}) {
  const cache = new Map();   // key → { at, ttl, status, type, body }
  const pending = new Map(); // key → Promise<entry>
  let bytes = 0; let active = 0; const waiters = [];
  const stats = { hit: 0, miss: 0, coalesced: 0, stale: 0, upstream: 0, upstreamErrors: 0, queued: 0, rejected: 0 };

  const evict = () => {
    for (const [k, v] of cache) { if (cache.size <= maxEntries && bytes <= maxBytes) break; cache.delete(k); bytes -= v.body.length; }
  };
  const put = (key, e) => { const old = cache.get(key); if (old) { bytes -= old.body.length; cache.delete(key); } cache.set(key, e); bytes += e.body.length; evict(); };
  const slot = () => new Promise((resolve, reject) => {
    if (active < maxUpstream) { active++; return resolve(); }
    if (waiters.length > maxUpstream * 20) { stats.rejected++; return reject(new Error('busy')); }
    stats.queued++;
    const w = { resolve, timer: setTimeout(() => { const i = waiters.indexOf(w); if (i >= 0) waiters.splice(i, 1); stats.rejected++; reject(new Error('busy')); }, queueMs) };
    waiters.push(w);
  });
  const release = () => { const w = waiters.shift(); if (w) { clearTimeout(w.timer); w.resolve(); } else active--; };

  async function fetchUpstream(target, headers, timeoutMs, ttl) {
    await slot();
    stats.upstream++;
    try {
      const r = await fetchImpl(target, { headers, signal: AbortSignal.timeout(timeoutMs) });
      const body = Buffer.from(await r.arrayBuffer());
      return { at: Date.now(), ttl: r.status === 200 ? ttl : Math.min(ttl, 1000), status: r.status, type: r.headers.get('content-type') || 'application/json; charset=utf-8', body };
    } finally { release(); }
  }

  /** → { status, type, body, cache: 'HIT' | 'MISS' | 'COALESCED' | 'STALE' } or throws when there is nothing to serve. */
  async function get(target, { ttl = 2000, headers = {}, timeoutMs = 10_000 } = {}) {
    const now = Date.now(); const hit = cache.get(target);
    if (hit && now - hit.at < hit.ttl) { stats.hit++; return { ...hit, cache: 'HIT' }; }
    const inflight = pending.get(target);
    if (inflight) { stats.coalesced++; try { return { ...(await inflight), cache: 'COALESCED' }; } catch (e) { if (hit && now - hit.at < staleMs && hit.status === 200) { stats.stale++; return { ...hit, cache: 'STALE' }; } throw e; } }
    stats.miss++;
    const p = fetchUpstream(target, headers, timeoutMs, ttl);
    pending.set(target, p);
    try {
      const e = await p;
      if (e.status >= 500 && hit && hit.status === 200 && now - hit.at < staleMs) { stats.stale++; return { ...hit, cache: 'STALE' }; }
      put(target, e); return { ...e, cache: 'MISS' };
    } catch (err) {
      stats.upstreamErrors++;
      if (hit && hit.status === 200 && Date.now() - hit.at < staleMs) { stats.stale++; return { ...hit, cache: 'STALE' }; }
      throw err;
    } finally { pending.delete(target); }
  }
  return { get, stats: () => ({ ...stats, entries: cache.size, bytes, active, waiting: waiters.length }), clear: () => { cache.clear(); bytes = 0; } };
}

/** How long a market answer may be shared. Live prices: 1–2 s (charts poll every few seconds); slow data longer. */
export function marketTtl(target) {
  if (/exchangeInfo/.test(target)) return 10 * 60_000;
  if (/\/depth/.test(target)) return 1000;
  if (/ticker/.test(target)) return 1000;   // v243: prices every second (shared by everyone: still one upstream call a second)
  const iv = /[?&]interval=([0-9]+)([mhdwM])/.exec(target);
  if (iv) { const unit = { m: 60, h: 3600, d: 86400, w: 604800, M: 2592000 }[iv[2]] * Number(iv[1]); return unit <= 300 ? 2000 : unit <= 3600 ? 5000 : 15_000; }
  if (/finance\/chart/.test(target)) return 5000;   // Yahoo
  return 2000;
}
