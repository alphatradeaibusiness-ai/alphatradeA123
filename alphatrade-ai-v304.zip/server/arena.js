// v251 Anonymous Strategy Arena — users submit rule-based strategies (built in the Strategy Studio); the SERVER re-tests every
// one on the same market data (it fetches the candles itself — a page can never send results), then keeps following it on
// new candles after the submission (a true forward test). Leaderboards show an alias, the DNA family and the numbers only:
// never the owner and never the rules. The owner may reveal their name on their own entry.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { writeBehind } from './writeBehind.js';
import { cleanSpec, splitTest, backtest, strategyDna, arenaScore } from '../src/services/strategyLab.js';

export function createArena({ dir, secret, now = Date.now, candlesOf = async () => null, env = process.env } = {}) {
  const key = secret && String(secret).length >= 32 ? crypto.scryptSync(String(secret), 'alphatrade-arena-v1', 32) : null;
  const file = path.join(dir, 'arena.json'); let db = null;
  const enc = (buf) => { const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from('arena')); const d = Buffer.concat([c.update(buf), c.final()]); return Buffer.concat([iv, c.getAuthTag(), d]); };
  const dec = (buf) => { const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12)); d.setAAD(Buffer.from('arena')); d.setAuthTag(buf.subarray(12, 28)); return Buffer.concat([d.update(buf.subarray(28)), d.final()]); };
  const load = () => { if (db) return db; db = { entries: [] }; if (key) { try { db = { ...db, ...JSON.parse(dec(fs.readFileSync(file)).toString('utf8')) }; } catch { /* first start */ } } return db; };
  const writer = writeBehind(() => { if (!key || !db) return; fs.mkdirSync(dir, { recursive: true, mode: 0o700 }); const tmp = `${file}.${process.pid}.tmp`; fs.writeFileSync(tmp, enc(Buffer.from(JSON.stringify(db))), { mode: 0o600 }); fs.renameSync(tmp, file); }, { delayMs: env.NODE_ENV === 'test' ? 0 : 400 });
  const alias = () => `STR-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
  const view = (e, uid) => ({ id: e.id, alias: e.alias, owner: e.reveal ? e.revealName : null, mine: e.uid === uid, symbol: e.spec.symbol, tf: e.spec.tf, family: e.dna.family, familyName: e.dna.familyName, vector: e.dna.vector, dnaId: e.uid === uid ? e.dna.id : null,
    submittedAt: e.at, is: e.is, oos: e.oos, fwd: e.fwd, score: e.score, rules: e.uid === uid ? e.spec : null, checkedAt: e.checkedAt, status: e.status });
  async function evaluate(e) {
    const c = await candlesOf(e.spec.symbol, e.spec.tf, 1000); if (!c || c.length < 200) return false;
    const t = splitTest(e.spec, c); e.is = t.is; e.oos = t.oos;
    const from = c.findIndex((k) => k.time * 1000 > e.at);
    e.fwd = from > 0 && from < c.length - 2 ? backtest(e.spec, c, { from }).metrics : { n: 0, expR: 0, pf: 0, maxDdR: 0, totalR: 0 };
    e.score = arenaScore(e.oos, e.fwd); e.checkedAt = now(); e.status = 'ranked'; return true;
  }
  async function submit(u, b = {}) {
    if (!key) return { error: 'no_secret' };
    const spec = cleanSpec(b.spec || {}); if (spec.error) return { error: `spec_${spec.error}` };
    const d = load(); if (d.entries.filter((e) => e.uid === u.uid && e.status !== 'withdrawn').length >= 5) return { error: 'entry_limit' };
    const e = { id: `e${crypto.randomBytes(6).toString('hex')}`, uid: u.uid, alias: alias(), spec, dna: strategyDna(spec), at: now(), status: 'pending', reveal: false, revealName: null };
    if (!(await evaluate(e))) return { error: 'no_data' };
    e.dna = strategyDna(spec, e.oos);
    d.entries.unshift(e); writer.schedule(); return { entry: view(e, u.uid) };
  }
  function list(u, { symbol = null, tf = null } = {}) {
    const items = load().entries.filter((e) => e.status === 'ranked' && (!symbol || e.spec.symbol === symbol) && (!tf || e.spec.tf === tf)).map((e) => view(e, u.uid));
    items.sort((a, b) => (b.score?.score ?? -1e9) - (a.score?.score ?? -1e9));
    return { items: items.slice(0, 100), rules: 'Ranked by out-of-sample (last 30 % of the server\'s candles) plus forward results after submission; at least 10 trades. score = 30 × (clamp(expectancy R, −1, 1) + 1) + 25 × min(profit factor, 3) / 3 − 15 × drawdown share. Costs included; a candle touching stop and target counts as the stop.' };
  }
  function act(u, id, b = {}) {
    const e = load().entries.find((x) => x.id === id); if (!e || e.uid !== u.uid) return { error: 'not_found' };
    if (b.action === 'withdraw') e.status = 'withdrawn';
    else if (b.action === 'reveal') { e.reveal = Boolean(b.on); e.revealName = e.reveal ? String(u.name || String(u.email || '').split('@')[0]).slice(0, 40) : null; }
    else return { error: 'bad_action' };
    writer.schedule(); return { entry: view(e, u.uid) };
  }
  let busy = false;
  async function refresh(maxAgeMs = 30 * 60_000) {
    if (busy) return 0; busy = true; let n = 0;
    try { for (const e of load().entries) if (e.status === 'ranked' && now() - (e.checkedAt || 0) > maxAgeMs) { if (await evaluate(e).catch(() => false)) n++; } if (n) writer.schedule(); } finally { busy = false; }
    return n;
  }
  const forgetUser = (uid) => { const d = load(); d.entries = d.entries.filter((e) => e.uid !== uid); writer.schedule(); };
  return { submit, list, act, refresh, forgetUser, flush: () => writer.flush() };
}
