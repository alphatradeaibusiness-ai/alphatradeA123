// Members features that live on the server (v171):
//   • sign-in alerts — every new sign-in becomes a message in the app (bell), a push, a Telegram message and an e-mail
//   • notices (the in-app message centre) and owner broadcasts
//   • 7-day free trial (once per account and per e-mail), referral links with reward days, Telegram linking per user
//   • e-mails (Resend): welcome, sign-in alert, plan ending in 3 days, weekly trade report
//   • high-impact news alerts 15 minutes ahead, TradingView webhooks per user, monthly contest on server-judged trades,
//     and settings sync between devices.
// Everything personal is kept in one file encrypted with AES-256-GCM (key from AI_KEY_SECRET).
//   RESEND_API_KEY / MAIL_FROM   e-mail sending (optional; without it the other channels still work)
//   GROWTH_TRIAL_DAYS            free trial length (default 7, 0 = off)   GROWTH_REFERRAL_DAYS  reward days (default 7)
import crypto from 'node:crypto';
import fs from 'node:fs';
import { writeBehind } from './writeBehind.js';
import path from 'node:path';

const DAY = 86_400_000;
const MAX_NOTICES = 60;
const clip = (s, n) => String(s ?? '').replace(/[\u0000-\u0008\u000b-\u001f]/g, ' ').slice(0, n);
const maskIp = (ip) => { const s = String(ip || ''); if (s.includes(':')) return `${s.split(':').slice(0, 3).join(':')}:…`; const p = s.split('.'); return p.length === 4 ? `${p[0]}.${p[1]}.${p[2]}.x` : ''; };
const maskEmail = (e) => { const [a, d] = String(e || '').split('@'); return a && d ? `${a.slice(0, 2)}***@${d}` : '—'; };
const emailHash = (e) => crypto.createHash('sha256').update(String(e || '').trim().toLowerCase()).digest('hex').slice(0, 32);

/* Server-side texts (the person's language). Kept short: they also go to lock screens and Telegram. */
const TX = {
  ar: {
    signin_t: 'تسجيل دخول جديد لحسابك', signin_b: 'انعمل تسجيل دخول من {device} (⁦{ip}⁩) الساعة ⁦{time}⁩ UTC. إذا مش إنت، غيّر كلمة المرور فورًا.',
    face_t: 'تفعّل الدخول بالوجه', face_b: 'انضاف جهاز ({device}) للدخول بالوجه. إذا مش إنت، غيّر كلمة المرور وشيله من الملف الشخصي فورًا.', signin_new_t: 'تسجيل دخول من جهاز جديد', member_t: 'عضو جديد سجّل دخول 🎉', member_b: '{who} · {device}', welcome_t: 'أهلين بـ AlphaTrade AI', welcome_b: 'حسابك جاهز. ابدأ تجربتك المجانية من صفحة «اشتراكي» وجرّب كل الأدوات.',
    trial_t: 'بلّشت تجربتك المجانية', trial_b: 'عندك الخطة الكاملة لمدة {days} أيام، لحد {date}.',
    expiry_t: 'اشتراكك بيخلص قريب', expiry_b: 'خطتك بتخلص بـ {date}. جدّد من صفحة الاشتراكات حتى ما تنقطع.',
    ref_t: 'كسبت أيام مجانية', ref_b: 'انضافلك {days} أيام لأنه حدا اشترك عن طريق رابطك (أو برابط صاحبك).',
    week_t: 'تقريرك الأسبوعي', week_b: 'هالأسبوع: {n} صفقة مسكّرة، {w} رابحة، المجموع {r}R. مش نصيحة مالية.',
    news_t: 'خبر قوي بعد {m} دقيقة', news_b: '{ccy}: {title} — انتبه لتقلبات قوية وقت الخبر.',
    tv_t: 'تنبيه من TradingView', tg_linked: '✅ انربط حسابك بـ AlphaTrade AI. رح توصلك التنبيهات هون. اكتب /stop لإيقافها.', tg_unlinked: 'وقّفت التنبيهات على تليغرام.',
    tg_bad: 'الرابط انتهى أو مش صحيح. ارجع للموقع واكبس «اربط تليغرام» من جديد.', contest_t: 'ربحت مسابقة الشهر 🏆', contest_b: 'انضافلك {days} يوم على اشتراكك. مبروك!',
  },
  en: {
    signin_t: 'New sign-in to your account', signin_b: 'Signed in from {device} ({ip}) at {time} UTC. If this was not you, change your password now.',
    face_t: 'Face sign-in turned on', face_b: 'A device ({device}) was added for face sign-in. If this was not you, change your password and remove it in Profile now.', signin_new_t: 'Sign-in from a new device', member_t: 'A new member signed in 🎉', member_b: '{who} · {device}', welcome_t: 'Welcome to AlphaTrade AI', welcome_b: 'Your account is ready. Start your free trial on “My subscription” and try every tool.',
    trial_t: 'Your free trial has started', trial_b: 'You have the full plan for {days} days, until {date}.',
    expiry_t: 'Your plan ends soon', expiry_b: 'Your plan ends on {date}. Renew on the Plans page to keep access.',
    ref_t: 'You earned free days', ref_b: '{days} days were added because someone subscribed through your link (or your friend’s).',
    week_t: 'Your weekly report', week_b: 'This week: {n} closed trades, {w} winners, total {r}R. Not financial advice.',
    news_t: 'High-impact news in {m} min', news_b: '{ccy}: {title} — expect sharp moves around the release.',
    tv_t: 'TradingView alert', tg_linked: '✅ Your AlphaTrade AI account is linked. Alerts will arrive here. Send /stop to turn them off.', tg_unlinked: 'Telegram alerts are off.',
    tg_bad: 'That link expired or is wrong. Go back to the site and press “Link Telegram” again.', contest_t: 'You won this month’s contest 🏆', contest_b: '{days} days were added to your plan. Congratulations!',
  },
};
const tx = (lang, k, p = {}) => String((TX[lang] || (lang === 'ar' || !lang ? TX.ar : TX.en))[k] || k).replace(/\{(\w+)\}/g, (_, x) => (p[x] ?? ''));
const isoDay = (ms) => new Date(ms).toISOString().slice(0, 10);

export function createGrowth({ dir, secret, access, ent = null, ledger = null, userTrades = null, pushTo = null, telegram = () => null, env = process.env, fetchFn = fetch, now = Date.now, log = console,
  mailBase = 'https://api.resend.com', tgBase = 'https://api.telegram.org', calendarUrl = '', publicUrl = '', writeDelayMs = 0, onTgUpdate = null } = {}) {
  const key = secret && String(secret).length >= 32 ? crypto.scryptSync(String(secret), 'alphatrade-growth-v1', 32) : null;
  const file = path.join(dir, 'growth.json');
  const trialDays = Math.max(0, Math.min(30, env.GROWTH_TRIAL_DAYS === undefined ? 7 : Number(env.GROWTH_TRIAL_DAYS) || 0));
  const refDays = Math.max(0, Math.min(60, Number(env.GROWTH_REFERRAL_DAYS) || 7));
  const mailKey = String(env.RESEND_API_KEY || ''); const mailFrom = String(env.MAIL_FROM || '');
  let db = null;

  /* ── encrypted store ── */
  function load() {
    if (db) return db;
    db = { users: {}, trialEmails: [], codes: {}, broadcasts: [], newsSent: [], contestAwards: {} };
    if (!key) return db;
    try {
      const e = JSON.parse(fs.readFileSync(file, 'utf8'));
      const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(e.iv, 'base64')); d.setAAD(Buffer.from('growth')); d.setAuthTag(Buffer.from(e.tag, 'base64'));
      db = { ...db, ...JSON.parse(Buffer.concat([d.update(Buffer.from(e.data, 'base64')), d.final()]).toString('utf8')) };
    } catch { /* first start, or another secret */ }
    return db;
  }
  function writeFile() {
    if (!key) return;
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from('growth'));
    const data = Buffer.concat([c.update(JSON.stringify(db), 'utf8'), c.final()]);
    const tmp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify({ v: 1, iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: data.toString('base64') }), { mode: 0o600 });
    fs.renameSync(tmp, file);
  }
  // v229 (load test): every sign-in / sync / read-mark re-encrypted and rewrote the WHOLE members file — the cost grows with
  // the number of members and blocked the server for everyone. Now changes inside a short window are written once.
  const writer = writeBehind(writeFile, { delayMs: Number(writeDelayMs) || 0 });
  const save = () => writer.schedule();
  const saveNow = () => { writer.schedule(); writer.flush(); };   // credits, trials, referrals, prizes, deletion
  const refCode = (uid) => crypto.createHmac('sha256', key || 'k').update(`ref:${uid}`).digest('base64url').replace(/[-_]/g, '').slice(0, 8).toUpperCase();
  function user(uid, create = true) {
    const d = load(); let u = d.users[uid];
    if (!u && create) {
      u = d.users[uid] = { createdAt: now(), email: '', name: '', lang: 'ar', logins: [], devices: [], notices: [], prefs: { emailLogin: true, emailWeekly: true, emailExpiry: true, news: false, newsCcy: [] },
        tg: null, tvToken: null, ref: { code: refCode(uid), by: null, rewarded: false, invited: 0, earnedDays: 0 }, creditDays: 0, trialUsed: false, contest: null, sync: null, reminded: null, weekSent: null };
      d.codes[u.ref.code] = uid;
    }
    return u || null;
  }

  /* ── delivery: in-app notice + push + Telegram + e-mail (each optional, never throws) ── */
  async function sendMail(to, subject, text) {
    if (!mailKey || !mailFrom || !to) return false;
    try {
      const html = `<div style="font-family:system-ui,sans-serif;font-size:15px;line-height:1.7;color:#1b1535"><h2 style="margin:0 0 8px">${subject.replace(/</g, '&lt;')}</h2><p>${text.replace(/</g, '&lt;').replace(/\n/g, '<br>')}</p>${publicUrl ? `<p><a href="${publicUrl}/#/app">AlphaTrade AI</a></p>` : ''}<p style="color:#888;font-size:12px">AlphaTrade AI — analysis tools, not financial advice.</p></div>`;
      const r = await fetchFn(`${mailBase}/emails`, { method: 'POST', headers: { authorization: `Bearer ${mailKey}`, 'content-type': 'application/json' }, body: JSON.stringify({ from: mailFrom, to: [to], subject, text, html }), signal: AbortSignal.timeout(10_000) });
      return r.ok;
    } catch { return false; }
  }
  async function sendTg(chatId, title, body) {
    const token = telegram(); if (!token || !chatId) return false;
    try { const r = await fetchFn(`${tgBase}/bot${token}/sendMessage`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: chatId, text: `${title}\n${body}`.slice(0, 3800), disable_web_page_preview: true }), signal: AbortSignal.timeout(10_000) }); return r.ok; } catch { return false; }
  }
  /** One message to one person on every channel they have. `email` is a pref name (or true to force). */
  async function deliver(uid, { kind, title, body, url = '/#/app', email = null, push = true, tg = true, tag = null, icon = null, tgBody = null }) {
    const u = user(uid, false); if (!u) return null;
    const n = { id: `n${crypto.randomBytes(5).toString('hex')}`, kind, title: clip(title, 120), body: clip(body, 600), url, at: now(), read: false };
    u.notices.unshift(n); u.notices.length = Math.min(u.notices.length, MAX_NOTICES); save();
    const out = { notice: true, push: false, telegram: false, email: false };
    try { if (push && pushTo) out.push = Boolean(await pushTo(uid, { title: n.title, body: n.body, url, tag: tag || kind, ...(icon ? { icon } : {}) })); } catch { /* */ }
    if (tg && u.tg?.chatId) out.telegram = await sendTg(u.tg.chatId, n.title, tgBody ? clip(tgBody, 1000) : n.body);
    if (email && u.email && (email === true || u.prefs[email] !== false)) out.email = await sendMail(u.email, n.title, n.body);
    return out;
  }

  /* ── sign-in ── */
  /** Called by the page right after a sign-in. Dedupes by the token's sign-in time, so a refresh is not a new sign-in. */
  async function signIn(authUser, { device = '', lang = 'ar', owner = false } = {}, ip = '') {
    const d = load(); if (owner) d.ownerUid = authUser.uid; const fresh = !d.users[authUser.uid]; const u = user(authUser.uid);
    u.email = String(authUser.email || u.email || '').slice(0, 200); u.name = clip(authUser.name || u.name, 80); u.lang = ['ar', 'en', 'he', 'es', 'zh'].includes(lang) ? lang : 'ar';
    const at = Number(authUser.authTime) || 0;
    if (u.logins[0]?.authTime === at && at) { save(); return { duplicate: true, fresh: false }; }
    const dev = clip(device, 80) || 'Browser'; const dh = crypto.createHash('sha256').update(dev).digest('hex').slice(0, 12);
    const newDevice = !fresh && !u.devices.includes(dh);
    if (!u.devices.includes(dh)) { u.devices.unshift(dh); u.devices.length = Math.min(u.devices.length, 20); }
    const rec = { authTime: at, at: now(), device: dev, ip: maskIp(ip), newDevice };
    u.logins.unshift(rec); u.logins.length = Math.min(u.logins.length, 20); u.lastLogin = now(); save();
    const time = new Date(rec.at).toISOString().slice(11, 16);
    // the site owner hears about every new member (masked e-mail, no other details)
    if (fresh && d.ownerUid && d.ownerUid !== authUser.uid) { const o = user(d.ownerUid, false); if (o) await deliver(d.ownerUid, { kind: 'newmember', title: tx(o.lang, 'member_t'), body: tx(o.lang, 'member_b', { who: maskEmail(u.email), device: dev }), url: '/#/app/payments', email: null }); }
    if (fresh) await deliver(authUser.uid, { kind: 'welcome', title: tx(u.lang, 'welcome_t'), body: tx(u.lang, 'welcome_b'), url: '/#/app/billing', email: true, tg: false });
    else await deliver(authUser.uid, { kind: 'signin', title: tx(u.lang, newDevice ? 'signin_new_t' : 'signin_t'), body: tx(u.lang, 'signin_b', { device: dev, ip: rec.ip || '—', time }), url: '/#/app/connect', email: 'emailLogin' });
    return { duplicate: false, fresh, newDevice };
  }

  /* ── notices ── */
  const notices = (uid) => { const u = user(uid, false); const items = u?.notices || []; return { items: items.slice(0, 40), unread: items.filter((x) => !x.read).length, broadcast: latestBroadcast(uid) }; };
  const markRead = (uid, id = null) => { const u = user(uid, false); if (!u) return { ok: true }; for (const n of u.notices) if (!id || n.id === id) n.read = true; save(); return { ok: true }; };
  function latestBroadcast(uid) { const d = load(); const b = d.broadcasts[0]; if (!b || now() - b.at > 14 * DAY) return null; const u = user(uid, false); return u?.dismissed === b.id ? null : b; }
  const dismissBroadcast = (uid, id) => { const u = user(uid); u.dismissed = String(id).slice(0, 20); save(); return { ok: true }; };
  async function broadcast({ title, body, push = false }) {
    const d = load(); const b = { id: `b${crypto.randomBytes(4).toString('hex')}`, title: clip(title, 120), body: clip(body, 600), at: now() };
    d.broadcasts.unshift(b); d.broadcasts.length = Math.min(d.broadcasts.length, 10); save();
    let n = 0;
    for (const uid of Object.keys(d.users)) { await deliver(uid, { kind: 'broadcast', title: b.title, body: b.body, push, tg: push, email: null }); n++; }
    return { ok: true, sent: n, id: b.id };
  }

  /* ── plan days (trial, referral rewards, contest prizes) ── */
  function addDays(uid, days, ref) {
    const t = now(); const cur = access.subscription(uid, t);
    if (cur) { access.grant(uid, { product: cur.product, paymentId: ref, startsAt: cur.startsAt, until: cur.until + days * DAY, replace: true }, t); return 'extended'; }
    const u = user(uid); u.creditDays = (u.creditDays || 0) + days; saveNow(); return 'banked';   // used at the next payment
  }
  function trialStatus(uid, email) {
    const d = load(); const u = user(uid, false);
    const paidBefore = Boolean(ledger?.forUser(uid).length);
    const eligible = trialDays > 0 && !u?.trialUsed && !d.trialEmails.includes(emailHash(email)) && !access.subscription(uid, now()) && !paidBefore;
    return { days: trialDays, eligible, used: Boolean(u?.trialUsed) };
  }
  async function startTrial(authUser) {
    const st = trialStatus(authUser.uid, authUser.email); if (!st.eligible) return { error: st.used ? 'trial_used' : 'trial_not_available' };
    const d = load(); const u = user(authUser.uid); const t = now(); const until = t + trialDays * DAY;
    access.grant(authUser.uid, { product: 'annual', paymentId: `trial:${authUser.uid}`, startsAt: t, until, replace: true }, t);
    u.trialUsed = true; d.trialEmails.push(emailHash(authUser.email)); saveNow();
    await deliver(authUser.uid, { kind: 'trial', title: tx(u.lang, 'trial_t'), body: tx(u.lang, 'trial_b', { days: trialDays, date: isoDay(until) }), url: '/#/app/billing', email: true, tg: true });
    return { ok: true, until };
  }

  /* ── referrals ── */
  function claimReferral(uid, code) {
    const d = load(); const u = user(uid); const c = String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
    const owner = d.codes[c];
    if (!owner || owner === uid) return { error: 'bad_code' };
    if (u.ref.by) return { error: 'already_referred' };
    if (now() - u.createdAt > 3 * DAY || ledger?.forUser(uid).length) return { error: 'too_late' };   // only for new accounts
    u.ref.by = owner; user(owner).ref.invited += 1; saveNow();
    return { ok: true };
  }
  /** Billing calls this after every confirmed payment: banked days + the referral reward on the first payment. */
  async function onPaid(uid) {
    const u = user(uid); const out = {};
    if (u.creditDays > 0) { const days = u.creditDays; u.creditDays = 0; saveNow(); addDays(uid, days, `credit:${uid}:${now()}`); out.credit = days; }
    if (u.ref.by && !u.ref.rewarded && refDays > 0) {
      u.ref.rewarded = true; saveNow();
      const ref = u.ref.by; const r = user(ref, false);
      addDays(uid, refDays, `refin:${uid}`); addDays(ref, refDays, `refout:${uid}`);
      if (r) { r.ref.earnedDays += refDays; saveNow(); }
      await deliver(uid, { kind: 'referral', title: tx(u.lang, 'ref_t'), body: tx(u.lang, 'ref_b', { days: refDays }), url: '/#/app/billing', email: true });
      if (r) await deliver(ref, { kind: 'referral', title: tx(r.lang, 'ref_t'), body: tx(r.lang, 'ref_b', { days: refDays }), url: '/#/app/billing', email: true });
      out.referral = refDays;
    }
    return out;
  }
  const referral = (uid) => { const u = user(uid); return { code: u.ref.code, invited: u.ref.invited, earnedDays: u.ref.earnedDays, creditDays: u.creditDays || 0, referredBy: Boolean(u.ref.by), rewardDays: refDays }; };

  /* ── Telegram linking (deep link + polling, so no public webhook URL is needed) ── */
  const links = new Map();   // code → { uid, exp }
  let botName = null; let botFor = null; let tgOffset = 0; let polling = false;
  async function bot() {
    const token = telegram(); if (!token) return null;
    if (botName && botFor === token) return botName;
    try { const r = await fetchFn(`${tgBase}/bot${token}/getMe`, { signal: AbortSignal.timeout(8000) }); const j = await r.json(); if (j?.ok && j.result?.username) { botName = j.result.username; botFor = token; } } catch { /* */ }
    return botName;
  }
  async function tgLinkStart(uid) {
    const name = await bot(); if (!name) return { error: 'telegram_not_configured' };
    for (const [c, v] of links) if (v.exp < now()) links.delete(c);
    const code = crypto.randomBytes(9).toString('base64url').replace(/[-_]/g, 'x');
    links.set(code, { uid, exp: now() + 15 * 60_000 });
    return { url: `https://t.me/${name}?start=${code}`, bot: name, expiresIn: 900 };
  }
  const tgUnlink = (uid) => { const u = user(uid); u.tg = null; save(); return { ok: true }; };
  async function tgPoll() {
    const token = telegram(); if (!token || polling) return;
    polling = true;
    try {
      const r = await fetchFn(`${tgBase}/bot${token}/getUpdates?timeout=0&offset=${tgOffset}&allowed_updates=${encodeURIComponent(onTgUpdate ? '["message","chat_join_request","chat_member"]' : '["message"]')}`, { signal: AbortSignal.timeout(10_000) });
      const j = await r.json(); if (!j?.ok) return;
      for (const up of j.result || []) {
        tgOffset = Math.max(tgOffset, up.update_id + 1);
        if (!up.message) { if (onTgUpdate) { try { await onTgUpdate(up); } catch { /* the gate logs its own errors */ } } continue; }
        const m = up.message; const text = String(m?.text || ''); const chat = m?.chat?.id; if (!chat || m.chat.type !== 'private') continue;
        const start = /^\/start\s+([A-Za-z0-9]{6,20})$/.exec(text.trim());
        if (start) {
          const l = links.get(start[1]); links.delete(start[1]);
          if (!l || l.exp < now()) { await sendTg(chat, 'AlphaTrade AI', tx('ar', 'tg_bad')); continue; }
          const d = load(); for (const x of Object.values(d.users)) if (x.tg?.chatId === chat) x.tg = null;   // one chat → one account
          const u = user(l.uid); u.tg = { chatId: chat, at: now() }; save();
          await sendTg(chat, 'AlphaTrade AI', tx(u.lang, 'tg_linked'));
        } else if (/^\/stop\b/.test(text.trim())) {
          const d = load(); for (const x of Object.values(d.users)) if (x.tg?.chatId === chat) { x.tg = null; await sendTg(chat, 'AlphaTrade AI', tx(x.lang, 'tg_unlinked')); }
          save();
        }
      }
    } catch { /* network */ } finally { polling = false; }
  }

  /* ── TradingView webhooks ── */
  function tvToken(uid, regenerate = false) {
    const d = load(); const u = user(uid);
    if (!u.tvToken || regenerate) { if (u.tvToken) delete d.codes[`tv:${u.tvToken}`]; u.tvToken = crypto.randomBytes(18).toString('base64url'); d.codes[`tv:${u.tvToken}`] = uid; save(); }
    return u.tvToken;
  }
  const tvHits = new Map();
  async function tvHook(token, raw) {
    const d = load(); const uid = d.codes[`tv:${String(token || '')}`]; if (!uid) return { status: 404, body: { code: 'not_found' } };
    const t = now(); const arr = (tvHits.get(uid) || []).filter((x) => t - x < 60_000); arr.push(t); tvHits.set(uid, arr);
    if (arr.length > 30) return { status: 429, body: { code: 'rate_limited' } };
    let msg = String(raw || ''); let title = '';
    try { const j = JSON.parse(msg); if (j && typeof j === 'object') { title = clip(j.title || j.ticker || j.symbol || '', 60); msg = clip(j.message || j.text || j.alert || JSON.stringify(j), 500); } } catch { msg = clip(msg, 500); }
    if (!msg.trim()) return { status: 400, body: { code: 'empty' } };
    const u = user(uid);
    await deliver(uid, { kind: 'tradingview', title: `${tx(u.lang, 'tv_t')}${title ? ` · ${title}` : ''}`, body: msg, url: '/#/app', email: null });
    return { status: 200, body: { ok: true } };
  }

  /* ── settings sync between devices ── */
  const SYNC_MAX = 48 * 1024;
  const getSync = (uid) => user(uid, false)?.sync || null;
  function putSync(uid, data, ts) {
    const s = JSON.stringify(data ?? null); if (s.length > SYNC_MAX) return { error: 'too_large' };
    if (!data || typeof data !== 'object' || Array.isArray(data)) return { error: 'bad_data' };
    const u = user(uid); const at = Number(ts) || now();
    if (u.sync && u.sync.ts > at) return { stale: true, sync: u.sync };
    u.sync = { ts: at, data }; save(); return { ok: true };
  }

  /* ── preferences, login history ── */
  function prefs(uid, patch = null) {
    const u = user(uid);
    if (patch && typeof patch === 'object') {
      for (const k of ['emailLogin', 'emailWeekly', 'emailExpiry', 'news']) if (typeof patch[k] === 'boolean') u.prefs[k] = patch[k];
      if (Array.isArray(patch.newsCcy)) u.prefs.newsCcy = patch.newsCcy.filter((c) => /^[A-Z]{3}$/.test(c)).slice(0, 12);
      save();
    }
    return { prefs: u.prefs, email: Boolean(u.email), mail: Boolean(mailKey && mailFrom), telegram: { linked: Boolean(u.tg?.chatId), configured: Boolean(telegram()) }, logins: u.logins.slice(0, 10).map(({ authTime: _a, ...x }) => x) };
  }

  /* ── monthly contest on trades the SERVER judged (saved right away, real prices) ── */
  const monthStart = (t) => { const d = new Date(t); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1); };
  function contestJoin(uid, nick) {
    const n = clip(nick, 20).trim(); if (n.length < 2) return { error: 'bad_nick' };
    const d = load(); if (Object.entries(d.users).some(([k, v]) => k !== uid && v.contest?.nick?.toLowerCase() === n.toLowerCase())) return { error: 'nick_taken' };
    user(uid).contest = { nick: n, at: now() }; save(); return { ok: true };
  }
  const contestLeave = (uid) => { const u = user(uid); u.contest = null; save(); return { ok: true }; };
  function leaderboard(viewer = null) {
    const d = load(); const from = monthStart(now()); const rows = [];
    for (const [uid, u] of Object.entries(d.users)) {
      if (!u.contest || !userTrades) continue;
      const tr = userTrades.list(uid).filter((x) => x._srv?.judged && x._srv?.fair && ['done', 'stopped', 'breakeven'].includes(x.status) && (x.closedAt || 0) * 1000 >= from && Number.isFinite(x.resultR));
      const r = tr.reduce((a, x) => a + Math.max(-1.5, Math.min(10, x.resultR)), 0);
      rows.push({ nick: u.contest.nick, n: tr.length, wins: tr.filter((x) => x.resultR > 0).length, r: Math.round(r * 100) / 100, me: uid === viewer, ref: uid.slice(0, 6) });
    }
    const ranked = rows.filter((x) => x.n >= 5).sort((a, b) => b.r - a.r || b.wins / b.n - a.wins / a.n);
    return { month: isoDay(from).slice(0, 7), minTrades: 5, ranked: ranked.slice(0, 50), pending: rows.filter((x) => x.n < 5).length, joined: Boolean(viewer && d.users[viewer]?.contest), nick: viewer ? d.users[viewer]?.contest?.nick || null : null };
  }
  async function contestAward(ref, days = 30) {
    const d = load(); const uid = Object.keys(d.users).find((k) => k.startsWith(String(ref)) && d.users[k].contest); if (!uid) return { error: 'not_found' };
    const month = isoDay(monthStart(now())).slice(0, 7); if (d.contestAwards[month]) return { error: 'already_awarded' };
    d.contestAwards[month] = uid; saveNow(); addDays(uid, days, `contest:${month}`);
    const u = user(uid); await deliver(uid, { kind: 'contest', title: tx(u.lang, 'contest_t'), body: tx(u.lang, 'contest_b', { days }), url: '/#/app/billing', email: true });
    return { ok: true };
  }

  /* ── scheduled jobs: plan ending, weekly report, news ── */
  let calCache = null; let calAt = 0;
  async function calendar() {
    if (!calendarUrl) return [];
    if (calCache && now() - calAt < 10 * 60_000) return calCache;
    try { const r = await fetchFn(calendarUrl, { headers: { 'User-Agent': 'Mozilla/5.0 (AlphaTrade AI)' }, signal: AbortSignal.timeout(10_000) }); const j = await r.json(); calCache = Array.isArray(j) ? j : []; calAt = now(); } catch { calCache ||= []; }
    return calCache;
  }
  async function runJobs() {
    const d = load(); const t = now(); let sent = 0;
    for (const [uid, u] of Object.entries(d.users)) {
      // plan ends within 3 days (once per end date)
      const s = access.subscription(uid, t);
      if (s && s.until - t < 3 * DAY && u.reminded !== s.until) { u.reminded = s.until; save(); await deliver(uid, { kind: 'expiry', title: tx(u.lang, 'expiry_t'), body: tx(u.lang, 'expiry_b', { date: isoDay(s.until) }), url: '/#/app/pricing', email: 'emailExpiry' }); sent++; }
      // weekly report: Mondays, once per ISO week, only when there were closed trades
      const wd = new Date(t).getUTCDay(); const wk = isoDay(t - ((wd + 6) % 7) * DAY);
      if (wd === 1 && u.weekSent !== wk && userTrades && u.email && u.prefs.emailWeekly !== false) {
        const since = t - 7 * DAY; const tr = userTrades.list(uid).filter((x) => ['done', 'stopped', 'breakeven'].includes(x.status) && (x.closedAt || 0) * 1000 >= since);
        u.weekSent = wk; save();
        if (tr.length) { const r = tr.reduce((a, x) => a + (x.resultR || 0), 0); await sendMail(u.email, tx(u.lang, 'week_t'), tx(u.lang, 'week_b', { n: tr.length, w: tr.filter((x) => x.resultR > 0).length, r: r.toFixed(2) })); sent++; }
      }
    }
    // high-impact news 10–20 minutes ahead
    const ev = (await calendar()).filter((e) => String(e.impact).toLowerCase() === 'high');
    for (const e of ev) {
      const at = Date.parse(e.date); const mins = Math.round((at - t) / 60_000); const id = `${e.country}|${e.title}|${e.date}`;
      if (!(mins >= 10 && mins <= 20) || d.newsSent.includes(id)) continue;
      d.newsSent.unshift(id); d.newsSent.length = Math.min(d.newsSent.length, 200); save();
      for (const [uid, u] of Object.entries(d.users)) {
        if (!u.prefs.news || (u.prefs.newsCcy.length && !u.prefs.newsCcy.includes(e.country))) continue;
        if (ent && !ent.canTradeAlerts(uid)) continue;
        await deliver(uid, { kind: 'news', title: tx(u.lang, 'news_t', { m: mins }), body: tx(u.lang, 'news_b', { ccy: e.country, title: clip(e.title, 80) }), url: '/#/app', email: null }); sent++;
      }
    }
    return { sent };
  }
  function start({ jobsMs = 5 * 60_000, pollMs = 4000 } = {}) {
    const a = setInterval(() => { runJobs().catch((e) => log.error?.('[growth] jobs:', String(e?.message || e).slice(0, 80))); }, jobsMs); a.unref?.();
    const b = setInterval(() => { tgPoll(); }, pollMs); b.unref?.();
    return () => { clearInterval(a); clearInterval(b); };
  }
  /** The member's phone number, already validated by the caller (E.164 + country); kept in this encrypted store only. */
  function setPhone(uid, { e164, iso }) { const u = user(uid); u.phone = { e164, iso, at: now() }; save(); return { ok: true, phone: { e164, iso } }; }
  const getPhone = (uid) => { const p = user(uid, false)?.phone; return p ? { e164: p.e164, iso: p.iso } : null; };
  function forget(uid) { const d = load(); const u = d.users[uid]; if (!u) return; delete d.codes[u.ref?.code]; if (u.tvToken) delete d.codes[`tv:${u.tvToken}`]; delete d.users[uid]; saveNow(); }
  const exportUser = (uid) => { const u = user(uid, false); if (!u) return null; const { devices: _d, ...rest } = u; return rest; };

  /** A message from the texts above, in the person's language. */
  const deliverKey = (uid, kind, tKey, bKey, params = {}, opts = {}) => { const u = user(uid); return deliver(uid, { kind, title: tx(u.lang, tKey, params), body: tx(u.lang, bKey, params), ...opts }); };
  /** Members for the owners' analytics: id, e-mail, name, language, first and last sign-in (nothing else). */
  /** v230 owner dashboard: sign-in activity as aggregates only (no e-mails, IPs or ids leave here; the recent list is masked). */
  function activity(t = now(), days = 14) {
    const DAYMS = 86_400_000; const dayKey = (ms) => new Date(ms).toISOString().slice(0, 10);
    const today0 = Date.UTC(new Date(t).getUTCFullYear(), new Date(t).getUTCMonth(), new Date(t).getUTCDate());
    const series = new Map(); for (let i = days - 1; i >= 0; i--) series.set(dayKey(today0 - i * DAYMS), { day: dayKey(today0 - i * DAYMS), logins: 0, users: 0, signups: 0 });
    const out = { members: 0, signups: { today: 0, d7: 0, d30: 0 }, logins: { today: 0, d7: 0, d30: 0 }, active: { d1: 0, d7: 0, d30: 0 }, devices: {}, langs: {}, recent: [] };
    const recent = [];
    for (const u of Object.values(load().users)) {
      out.members++;
      const c = Number(u.createdAt) || 0;
      if (c >= today0) out.signups.today++; if (t - c < 7 * DAYMS) out.signups.d7++; if (t - c < 30 * DAYMS) out.signups.d30++;
      const sd = series.get(dayKey(c)); if (sd) sd.signups++;
      const last = Number(u.lastLogin) || 0;
      if (t - last < DAYMS) out.active.d1++; if (t - last < 7 * DAYMS) out.active.d7++; if (t - last < 30 * DAYMS) out.active.d30++;
      out.langs[u.lang || 'ar'] = (out.langs[u.lang || 'ar'] || 0) + 1;
      const seenDay = new Set();
      for (const l of u.logins || []) {
        const at = Number(l.at) || 0; if (!at) continue;
        if (at >= today0) out.logins.today++; if (t - at < 7 * DAYMS) out.logins.d7++; if (t - at < 30 * DAYMS) out.logins.d30++;
        const k = dayKey(at); const sl = series.get(k); if (sl) { sl.logins++; if (!seenDay.has(k)) { seenDay.add(k); sl.users++; } }
        if (t - at < 30 * DAYMS) { const os = String(l.device || 'Browser').split(' · ')[0].slice(0, 20) || 'Browser'; out.devices[os] = (out.devices[os] || 0) + 1; }
        if (t - at < 7 * DAYMS) recent.push({ at, who: maskEmail(u.email), device: String(l.device || '').slice(0, 40), newDevice: Boolean(l.newDevice) });
      }
    }
    out.series = [...series.values()];
    out.recent = recent.sort((a, b) => b.at - a.at).slice(0, 12);
    return out;
  }
  const members = () => Object.entries(load().users).map(([uid, u]) => ({ uid, email: u.email || '', name: u.name || '', lang: u.lang || 'ar', createdAt: u.createdAt || 0, lastLogin: u.lastLogin || 0 }));
  return { emailOf: (uid) => user(uid, false)?.email || '', uidByTg: (tgId) => { const d = load(); for (const [uid, x] of Object.entries(d.users)) if (x.tg?.chatId === tgId) return uid; return null; }, tgOf: (uid) => user(uid, false)?.tg?.chatId || null, langOf: (uid) => user(uid, false)?.lang || 'ar', members, canSave: () => Boolean(key), signIn, deliver, deliverKey, notices, markRead, dismissBroadcast, broadcast, trialStatus, startTrial, claimReferral, onPaid, referral,
    tgLinkStart, tgUnlink, tgPoll, tvToken, tvHook, getSync, putSync, prefs, contestJoin, contestLeave, leaderboard, contestAward, runJobs, start, forget, exportUser, addDays, sendMail, setPhone, getPhone, activity, isMember: (uid) => Object.hasOwn(load().users, uid) };
}
