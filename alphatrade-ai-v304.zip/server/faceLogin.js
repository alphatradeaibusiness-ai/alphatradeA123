// Face sign-in (v172) with passkeys (WebAuthn, device-bound, user verification required).
// The face scan itself happens on the phone or laptop (Face ID, Android face unlock, Windows Hello face) — the site never
// receives or stores a face picture or face data. The server stores only a public key per device; to sign in, the device
// signs a one-time challenge after the face scan, the server checks the signature and hands back a Firebase custom token.
//   FIREBASE_SERVICE_ACCOUNT   service-account JSON (or base64 of it) from Firebase → Project settings → Service accounts
//   FACE_RP_ID                 optional fixed relying-party id (your domain); default: the request's host
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { verifyRegistration, verifyAssertion, b64u, WebAuthnError } from './bank/webauthn.js';

const AUD = 'https://identitytoolkit.googleapis.com/google.identity.identitytoolkit.v1.IdentityToolkit';
const CHALLENGE_MS = 5 * 60_000;
const MAX_PER_USER = 10;

export function parseServiceAccount(raw) {
  if (!raw) return null;
  let s = String(raw).trim();
  if (!s.startsWith('{')) { try { s = Buffer.from(s, 'base64').toString('utf8'); } catch { return null; } }
  try { const j = JSON.parse(s); if (j.client_email && j.private_key) { crypto.createPrivateKey(j.private_key); return { email: j.client_email, key: j.private_key, projectId: j.project_id || null }; } } catch { /* bad JSON or key */ }
  return null;
}
/** Firebase custom token (RS256 JWT signed by the service account), valid one hour; the page exchanges it with signInWithCustomToken. */
export function customToken(sa, uid, claims = {}, nowSec = Math.floor(Date.now() / 1000)) {
  const enc = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
  const head = enc({ alg: 'RS256', typ: 'JWT' });
  const body = enc({ iss: sa.email, sub: sa.email, aud: AUD, iat: nowSec, exp: nowSec + 3600, uid, claims });
  const sig = crypto.sign('RSA-SHA256', Buffer.from(`${head}.${body}`), sa.key).toString('base64url');
  return `${head}.${body}.${sig}`;
}

export function createFaceLogin({ dir, secret, env = process.env, now = Date.now }) {
  const key = secret && String(secret).length >= 32 ? crypto.scryptSync(String(secret), 'alphatrade-face-login-v1', 32) : null;
  const file = path.join(dir, 'face-login.json');
  const sa = parseServiceAccount(env.FIREBASE_SERVICE_ACCOUNT);
  const challenges = new Map();   // id → { kind, uid?, challenge, exp }
  let db = null;
  const load = () => {
    if (db) return db; db = { creds: {} };
    if (!key) return db;
    try { const e = JSON.parse(fs.readFileSync(file, 'utf8')); const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(e.iv, 'base64')); d.setAAD(Buffer.from('face')); d.setAuthTag(Buffer.from(e.tag, 'base64')); db = JSON.parse(Buffer.concat([d.update(Buffer.from(e.data, 'base64')), d.final()]).toString('utf8')); } catch { /* none yet */ }
    db.creds ||= {}; return db;
  };
  const save = () => {
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from('face'));
    const data = Buffer.concat([c.update(JSON.stringify(db), 'utf8'), c.final()]);
    const tmp = `${file}.${process.pid}.tmp`; fs.writeFileSync(tmp, JSON.stringify({ v: 1, iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: data.toString('base64') }), { mode: 0o600 }); fs.renameSync(tmp, file);
  };
  const userHandle = (uid) => b64u(crypto.createHmac('sha256', key || 'k').update(`login:${uid}`).digest().subarray(0, 32));
  const newChallenge = (kind, uid = null) => {
    for (const [k, v] of challenges) if (v.exp < now()) challenges.delete(k);
    if (challenges.size > 5000) challenges.clear();
    const id = crypto.randomBytes(12).toString('base64url'); const challenge = b64u(crypto.randomBytes(32));
    challenges.set(id, { kind, uid, challenge, exp: now() + CHALLENGE_MS }); return { id, challenge };
  };
  const take = (id, kind) => { const c = challenges.get(String(id || '')); challenges.delete(String(id || '')); if (!c || c.kind !== kind || c.exp < now()) throw new WebAuthnError('challenge_expired'); return c; };
  const mine = (uid) => Object.entries(load().creds).filter(([, c]) => c.uid === uid);

  return {
    configured: () => Boolean(key && sa),
    status(uid) { return { configured: Boolean(key && sa), devices: mine(uid).map(([id, c]) => ({ id: id.slice(0, 10), name: c.name, createdAt: c.createdAt, lastUsed: c.lastUsed || null })) }; },
    /** Signed-in + fresh sign-in (checked by the route). Platform authenticator only: the phone / laptop itself, with a face (or its own unlock). */
    registerOptions(user, rp) {
      if (!key) throw new WebAuthnError('not_configured');
      if (mine(user.uid).length >= MAX_PER_USER) throw new WebAuthnError('too_many');
      const { id, challenge } = newChallenge('reg', user.uid);
      return { challengeId: id, publicKey: {
        challenge, rp: { id: rp.rpId, name: 'AlphaTrade AI' }, timeout: 120000, attestation: 'none',
        user: { id: userHandle(user.uid), name: String(user.email || 'user').slice(0, 64), displayName: String(user.name || user.email || 'AlphaTrade').slice(0, 64) },
        pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
        authenticatorSelection: { authenticatorAttachment: 'platform', residentKey: 'required', requireResidentKey: true, userVerification: 'required' },
        excludeCredentials: mine(user.uid).map(([cid]) => ({ type: 'public-key', id: cid })),
      } };
    },
    register(user, body, rp) {
      const c = take(body?.challengeId, 'reg'); if (c.uid !== user.uid) throw new WebAuthnError('challenge_expired');
      const v = verifyRegistration(body.credential, { challenge: c.challenge, origins: rp.origins, rpId: rp.rpId });
      const d = load(); if (d.creds[v.id]) throw new WebAuthnError('already_registered');
      const name = String(body.name || 'Device').replace(/[\u0000-\u001f]/g, ' ').slice(0, 40);
      d.creds[v.id] = { uid: user.uid, jwk: v.jwk, alg: v.alg, signCount: v.signCount, name, createdAt: now(), handle: userHandle(user.uid) }; save();
      return { ok: true, id: v.id.slice(0, 10) };
    },
    loginOptions(rp) {
      const { id, challenge } = newChallenge('login');
      return { challengeId: id, publicKey: { challenge, rpId: rp.rpId, timeout: 120000, userVerification: 'required', allowCredentials: [] } };
    },
    /** Checks the face-unlocked signature and returns { token, uid } — the token signs the person in to Firebase. */
    login(body, rp) {
      if (!sa) throw new WebAuthnError('not_configured');
      const c = take(body?.challengeId, 'login');
      const cred = body?.credential; const stored = load().creds[String(cred?.id || '')];
      if (!stored) throw new WebAuthnError('unknown_credential');
      if (cred.response?.userHandle && cred.response.userHandle !== stored.handle) throw new WebAuthnError('user_mismatch');
      const r = verifyAssertion(cred, stored, { challenge: c.challenge, origins: rp.origins, rpId: rp.rpId });
      stored.signCount = r.signCount; stored.lastUsed = now(); save();
      return { token: customToken(sa, stored.uid, { via: 'face' }), uid: stored.uid };
    },
    remove(uid, shortId) { const d = load(); let n = 0; for (const [id, c] of Object.entries(d.creds)) if (c.uid === uid && (!shortId || id.startsWith(String(shortId)))) { delete d.creds[id]; n++; } if (n) save(); return { ok: true, removed: n }; },
  };
}
