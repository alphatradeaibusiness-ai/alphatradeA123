// v251 Private Trading Rooms — server side. Every rule is enforced HERE (the page only shows what the server allows).
//  • rooms: unique 6-character id, profile image, description, specialization, language, rules, max members, public / private,
//    password (scrypt hash), invitation-only, approval, optional price (shown; joining a paid room always goes through the
//    owner's approval — automatic charging needs payouts to room owners, which the platform's payment setup does not have)
//  • members & roles: owner · admin · mod · expert · member; mute, remove, block, promote; who may share / upload / predict /
//    start meetings (all members or moderators)
//  • chat: messages, replies, reactions, images, voice notes, edit, delete, search, pins, @mentions (notified), private messages
//    (only sender and recipient ever receive them), anti-spam limits, reports to the site owners
//  • meetings: WebRTC voice / video / screen share between members (mesh, up to 8); this server only relays the set-up
//    messages (kept in memory) — audio and video go browser to browser, encrypted (DTLS-SRTP); raise hand, host mute
//  • shared workspace: the asset and timeframe the room analyses together, shared drawings (levels, zones, trend lines)
//  • predictions: the reference price is taken by the SERVER at publication; votes bull / bear / neutral; at the end the server
//    takes the market price again and records the result. Records can never be edited or deleted (hash-chained)
//  • AI: the room assistant (summaries, disagreements, questions) and one AI mentor, through the site's own AI connection
//  • verified experts (verified by the site owners), weekly / monthly room leaderboard with published rules, owner admin panel
// Storage: one AES-256-GCM encrypted file (key from AI_KEY_SECRET) + encrypted image / voice files.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { writeBehind } from './writeBehind.js';
import { MENTORS, mentorById, mentorSystem, ROOM_ASSISTANT_SYSTEM } from '../src/config/mentors.js';

const DAY = 86_400_000;
const ID_ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const clip = (s, n) => String(s ?? '').replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, ' ').trim().slice(0, n);
const hex = (n = 6) => crypto.randomBytes(n).toString('hex');
const code = (n) => Array.from(crypto.randomBytes(n), (b) => ID_ABC[b % ID_ABC.length]).join('');
export const SPECS = ['crypto', 'forex', 'gold', 'indices', 'stocks', 'mixed'];
export const ROLES = ['owner', 'admin', 'mod', 'expert', 'member'];
const STAFF = new Set(['owner', 'admin', 'mod']);
const MANAGERS = new Set(['owner', 'admin']);
export const REACTIONS = ['👍', '🔥', '🎯', '😂', '😮', '👀', '📈', '📉'];
const IMG_RE = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/;
const AUD_RE = /^data:audio\/(webm|ogg|mp4|mpeg)(?:;codecs=[a-z0-9.]+)?;base64,([A-Za-z0-9+/=]+)$/;
const MAX_IMG = 1_500_000, MAX_AUD = 1_000_000;
const ROOM_RE = /^[A-Z2-9]{6}$/;
export const LIMITS_DEFAULT = { maxRoomsPerUser: 5, maxMembersCap: 200, aiEnabled: true, meetingMax: 8 };

export function createRooms({ dir, secret, now = Date.now, growth = null, isOwnerEmail = () => false, priceOf = async () => null, aiAsk = async () => ({ error: 'not_configured' }), env = process.env, log = console } = {}) {
  const key = secret && String(secret).length >= 32 ? crypto.scryptSync(String(secret), 'alphatrade-rooms-v1', 32) : null;
  const file = path.join(dir, 'rooms.json'); const fdir = path.join(dir, 'rooms-files');
  const enc = (buf, aad) => { const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from(aad)); const d = Buffer.concat([c.update(buf), c.final()]); return Buffer.concat([iv, c.getAuthTag(), d]); };
  const dec = (buf, aad) => { const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12)); d.setAAD(Buffer.from(aad)); d.setAuthTag(buf.subarray(12, 28)); return Buffer.concat([d.update(buf.subarray(28)), d.final()]); };
  let db = null;
  function load() {
    if (db) return db;
    db = { rooms: {}, experts: {}, expertRequests: [], reports: [], favs: {}, limits: { ...LIMITS_DEFAULT }, chainHead: '0' };
    if (!key) return db;
    try { db = { ...db, ...JSON.parse(dec(fs.readFileSync(file), 'rooms').toString('utf8')) }; } catch { /* first start */ }
    return db;
  }
  const writer = writeBehind(() => {
    if (!key || !db) return;
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    const tmp = `${file}.${process.pid}.tmp`; fs.writeFileSync(tmp, enc(Buffer.from(JSON.stringify(db)), 'rooms'), { mode: 0o600 }); fs.renameSync(tmp, file);
  }, { delayMs: env.NODE_ENV === 'test' ? 0 : 400, maxWaitMs: 1500 });
  const save = () => writer.schedule();
  const notify = (uid, title, body, url, kind = 'room') => growth?.deliver?.(uid, { kind, title, body, url, push: true, tg: false, email: null })?.catch?.(() => null);
  const nameOf = (u) => clip(u.name || String(u.email || '').split('@')[0] || 'Trader', 40);
  const isSiteOwner = (u) => Boolean(isOwnerEmail(u));

  /* ───────── files (images / voice), encrypted ───────── */
  function putFile(raw, roomId) {
    const s = String(raw || ''); let m = IMG_RE.exec(s); let kind = 'image', max = MAX_IMG;
    if (!m) { m = AUD_RE.exec(s); kind = 'audio'; max = MAX_AUD; }
    if (!m) return { error: 'bad_file' };
    const buf = Buffer.from(m[2], 'base64'); if (!buf.length || buf.length > max) return { error: 'file_too_large' };
    const id = `x${hex(6)}`; fs.mkdirSync(fdir, { recursive: true, mode: 0o700 });
    fs.writeFileSync(path.join(fdir, `${id}.bin`), enc(Buffer.concat([Buffer.from(`${kind}/${m[1]}\n`), buf]), `file:${roomId}:${id}`), { mode: 0o600 });
    return { id, kind };
  }
  function getFile(u, roomId, fid) {
    if (!/^x[0-9a-f]{12}$/.test(fid) || !ROOM_RE.test(roomId)) return null;
    const r = load().rooms[roomId]; if (!r) return null;
    const pub = r.image === fid;   // the room picture is visible to anyone who can see the room card
    if (!pub) {
      if (!r.members[u.uid] && !isSiteOwner(u)) return null;
      const msg = r.messages.find((x) => x.file === fid);
      if (!msg || (msg.to && msg.uid !== u.uid && msg.to !== u.uid)) return null;   // a private message's file: only its two people
    } else if (r.access === 'private' && !r.members[u.uid] && !isSiteOwner(u)) return null;
    try { const buf = dec(fs.readFileSync(path.join(fdir, `${fid}.bin`)), `file:${roomId}:${fid}`); const nl = buf.indexOf(10); return { type: buf.subarray(0, nl).toString(), data: buf.subarray(nl + 1) }; } catch { return null; }
  }

  /* ───────── helpers ───────── */
  const room = (id) => (ROOM_RE.test(String(id)) ? load().rooms[id] || null : null);
  const roleOf = (r, uid) => r?.members?.[uid]?.role || null;
  const can = (r, uid, perm) => { const role = roleOf(r, uid); if (!role) return false; if (MANAGERS.has(role)) return true; const p = r.perms?.[perm] || 'all'; return p === 'all' || (p === 'mods' && (STAFF.has(role) || role === 'expert')); };
  const bump = (r) => { r.rev = (r.rev || 0) + 1; r.updatedAt = now(); return r.rev; };
  const sys = (r, text, extra = {}) => { const m = { id: `m${hex(6)}`, uid: null, name: 'System', role: 'system', kind: 'system', text: clip(text, 300), at: now(), rev: 0, ...extra }; m.rev = bump(r); r.messages.push(m); trim(r); return m; };
  const trim = (r) => { if (r.messages.length > 1500) r.messages.splice(0, r.messages.length - 1500); };
  const pwHash = (pw, salt = hex(8)) => `${salt}:${crypto.scryptSync(String(pw), `room:${salt}`, 32).toString('hex')}`;
  const pwOk = (pw, stored) => { if (!stored) return true; const [salt, h] = stored.split(':'); const x = crypto.scryptSync(String(pw || ''), `room:${salt}`, 32); return crypto.timingSafeEqual(x, Buffer.from(h, 'hex')); };
  const card = (r, uid = null) => ({ id: r.id, name: r.name, desc: r.desc, spec: r.spec, lang: r.lang, image: r.image || null, access: r.access, hasPassword: Boolean(r.password), inviteOnly: r.inviteOnly, approval: r.approval,
    price: r.price || null, maxMembers: r.maxMembers, members: Object.keys(r.members).length, online: online(r), createdAt: r.createdAt, suspended: Boolean(r.suspended), archived: Boolean(r.archived),
    meeting: r.meeting ? { kind: r.meeting.kind, n: Object.keys(r.meeting.participants).length, startedAt: r.meeting.startedAt } : null, role: uid ? roleOf(r, uid) : null, fav: uid ? (load().favs[uid] || []).includes(r.id) : false,
    pending: uid ? r.pending.some((p) => p.uid === uid) : false, ai: { assistant: Boolean(r.ai?.assistant), mentor: r.ai?.mentor || null } });
  const online = (r) => Object.values(r.members).filter((m) => now() - (m.seen || 0) < 60_000).length;
  const memberView = (r, uid, m) => ({ uid, name: m.name, role: m.role, muted: Boolean(m.muted), online: now() - (m.seen || 0) < 60_000, seen: m.seen || null, joinedAt: m.joinedAt, expert: Boolean(load().experts[uid]) });
  const msgView = (m, viewer) => (m.to && m.uid !== viewer && m.to !== viewer ? null : { id: m.id, uid: m.uid, name: m.name, role: m.role, kind: m.kind, text: m.deleted ? '' : m.text, deleted: Boolean(m.deleted), edited: Boolean(m.edited), at: m.at, rev: m.rev,
    replyTo: m.replyTo || null, reactions: m.reactions || {}, file: m.deleted ? null : m.file || null, fileKind: m.fileKind || null, to: m.to || null, pinned: Boolean(m.pinned), mentions: m.mentions || [], ai: m.ai || null, expert: Boolean(m.uid && load().experts[m.uid]) });
  const touch = (r, uid) => { const m = r.members[uid]; if (m) m.seen = now(); };

  /* ───────── create / settings ───────── */
  function cleanSettings(b, base = {}) {
    const out = { ...base };
    if (b.name != null) { const n = clip(b.name, 60); if (n.length < 3) return { error: 'name_short' }; out.name = n; }
    if (b.desc != null) out.desc = clip(b.desc, 600);
    if (b.spec != null) { if (!SPECS.includes(b.spec)) return { error: 'bad_spec' }; out.spec = b.spec; }
    if (b.lang != null) out.lang = /^[a-z]{2}$/.test(b.lang) ? b.lang : 'ar';
    if (b.rules != null) out.rules = clip(b.rules, 1500);
    if (b.maxMembers != null) { const n = Math.round(Number(b.maxMembers)); if (!(n >= 2 && n <= load().limits.maxMembersCap)) return { error: 'bad_max' }; out.maxMembers = n; }
    if (b.access != null) { if (!['public', 'private'].includes(b.access)) return { error: 'bad_access' }; out.access = b.access; }
    if (b.inviteOnly != null) out.inviteOnly = Boolean(b.inviteOnly);
    if (b.approval != null) out.approval = Boolean(b.approval);
    if (b.price !== undefined) {
      if (b.price === null || b.price === '' || Number(b.price?.amount) === 0) out.price = null;
      else { const a = Number(b.price?.amount); const per = ['month', 'year', 'once'].includes(b.price?.period) ? b.price.period : 'month'; if (!(a > 0 && a <= 10000)) return { error: 'bad_price' }; out.price = { amount: Math.round(a * 100) / 100, period: per, currency: 'USD' }; }
    }
    if (b.perms != null && typeof b.perms === 'object') { out.perms = { ...(base.perms || {}) }; for (const k of ['share', 'upload', 'predict', 'meet']) if (['all', 'mods'].includes(b.perms[k])) out.perms[k] = b.perms[k]; }
    return out;
  }
  function create(u, b = {}) {
    if (!key) return { error: 'no_secret' };
    const d = load();
    const mine = Object.values(d.rooms).filter((r) => r.ownerUid === u.uid && !r.archived).length;
    if (mine >= d.limits.maxRoomsPerUser && !isSiteOwner(u)) return { error: 'room_limit' };
    const s = cleanSettings({ spec: 'mixed', lang: 'ar', maxMembers: 50, access: 'private', inviteOnly: false, approval: false, ...b }, { perms: { share: 'all', upload: 'all', predict: 'all', meet: 'mods' } });
    if (s.error) return s; if (!s.name) return { error: 'name_short' };
    let id; do id = code(6); while (d.rooms[id]);
    const r = { id, ...s, password: b.password ? pwHash(clip(b.password, 64)) : null, ownerUid: u.uid, createdAt: now(), updatedAt: now(), rev: 0,
      members: { [u.uid]: { name: nameOf(u), role: 'owner', joinedAt: now(), seen: now(), lastRead: 0 } }, banned: [], pending: [], invites: [], messages: [], predictions: [], meetings: [], meeting: null,
      workspace: { symbol: 'BTCUSDT', tf: '1h', ann: [], rev: 0, by: null }, ai: { assistant: false, mentor: null }, image: null, stats: { messages: 0 } };
    if (b.image) { const f = putFile(b.image, id); if (f.error) return f; if (f.kind !== 'image') return { error: 'bad_file' }; r.image = f.id; }
    d.rooms[id] = r; sys(r, `🔑 ${nameOf(u)} أنشأ الغرفة`); save();
    return { room: card(r, u.uid) };
  }
  function updateSettings(u, id, b = {}) {
    const r = room(id); if (!r) return { error: 'not_found' }; if (!MANAGERS.has(roleOf(r, u.uid))) return { error: 'forbidden' };
    const s = cleanSettings(b, r); if (s.error) return s; Object.assign(r, s);
    if (b.password !== undefined) r.password = b.password ? pwHash(clip(b.password, 64)) : null;
    if (b.image) { const f = putFile(b.image, id); if (f.error) return f; r.image = f.id; }
    if (b.archived != null && roleOf(r, u.uid) === 'owner') r.archived = Boolean(b.archived);
    bump(r); save(); return { room: card(r, u.uid) };
  }

  /* ───────── join / invites / approval ───────── */
  function invite(u, id, b = {}) {
    const r = room(id); if (!r) return { error: 'not_found' }; if (!STAFF.has(roleOf(r, u.uid)) && !(r.access === 'public' && !r.inviteOnly && roleOf(r, u.uid))) return { error: 'forbidden' };
    const inv = { code: code(10), by: u.uid, at: now(), uses: 0, max: Math.min(100, Math.max(1, Math.round(Number(b.max) || 20))), expires: now() + Math.min(30, Math.max(1, Number(b.days) || 7)) * DAY, toUid: null, role: 'member' };
    if (b.expertUid) { if (!MANAGERS.has(roleOf(r, u.uid))) return { error: 'forbidden' }; const ex = load().experts[String(b.expertUid)]; if (!ex) return { error: 'not_expert' }; inv.toUid = String(b.expertUid); inv.role = 'expert'; inv.max = 1;
      notify(inv.toUid, `دعوة لغرفة ${r.name} / Room invitation`, `${nameOf(u)} دعاك كخبير موثّق / invited you as a verified expert`, `/#/app/rooms?join=${inv.code}`, 'room_invite'); }
    r.invites = r.invites.filter((x) => x.expires > now()).slice(-50); r.invites.push(inv); save();
    return { code: inv.code, link: `/#/app/rooms?join=${inv.code}`, expires: inv.expires, role: inv.role };
  }
  function findInvite(c) { for (const r of Object.values(load().rooms)) { const inv = r.invites.find((x) => x.code === c); if (inv) return { r, inv }; } return null; }
  function preview(u, b = {}) {
    let r = null;
    if (b.code) { const f = findInvite(String(b.code).toUpperCase()); if (!f || f.inv.expires < now() || f.inv.uses >= f.inv.max || (f.inv.toUid && f.inv.toUid !== u.uid)) return { error: 'bad_invite' }; r = f.r; }
    else { r = room(String(b.id || '').toUpperCase()); if (!r || (r.access === 'private' && !r.members[u.uid])) return { error: 'not_found' }; }
    if (r.suspended) return { error: 'suspended' };
    return { room: { ...card(r, u.uid), rules: r.rules } };
  }
  function join(u, b = {}) {
    const d = load(); let r = null; let inv = null;
    if (b.code) { const f = findInvite(String(b.code).toUpperCase()); if (!f) return { error: 'bad_invite' }; ({ r, inv } = f); if (inv.expires < now() || inv.uses >= inv.max || (inv.toUid && inv.toUid !== u.uid)) return { error: 'bad_invite' }; }
    else { r = room(String(b.id || '').toUpperCase()); if (!r || (r.access === 'private' && !r.password)) return { error: 'not_found' }; if (r.inviteOnly) return { error: 'invite_only' }; }
    if (r.suspended || r.archived) return { error: 'suspended' };
    if (r.members[u.uid]) return { room: card(r, u.uid), joined: true };
    if (r.banned.includes(u.uid)) return { error: 'banned' };
    if (Object.keys(r.members).length >= r.maxMembers) return { error: 'room_full' };
    if (!inv && r.password && !pwOk(b.password, r.password)) return { error: 'bad_password' };
    // an invitation from the staff skips approval; a paid room is always approved by its owner (payment confirmed outside)
    if (!inv && (r.approval || r.price)) {
      if (!r.pending.some((p) => p.uid === u.uid)) { r.pending.push({ uid: u.uid, name: nameOf(u), at: now(), note: clip(b.note, 200) }); for (const [mu, m] of Object.entries(r.members)) if (MANAGERS.has(m.role)) notify(mu, `طلب انضمام لـ ${r.name} / Join request`, nameOf(u), `/#/app/rooms/${r.id}`, 'room_request'); save(); }
      return { pending: true, room: card(r, u.uid) };
    }
    if (inv) inv.uses += 1;
    r.members[u.uid] = { name: nameOf(u), role: inv?.role === 'expert' && d.experts[u.uid] ? 'expert' : 'member', joinedAt: now(), seen: now(), lastRead: 0 };
    sys(r, `${nameOf(u)} انضم للغرفة${r.members[u.uid].role === 'expert' ? ' كخبير موثّق ✔' : ''}`); save();
    return { room: card(r, u.uid), joined: true };
  }
  function decide(u, id, b = {}) {
    const r = room(id); if (!r) return { error: 'not_found' }; if (!MANAGERS.has(roleOf(r, u.uid))) return { error: 'forbidden' };
    const p = r.pending.find((x) => x.uid === b.uid); if (!p) return { error: 'not_found' };
    r.pending = r.pending.filter((x) => x !== p);
    if (b.accept) {
      if (Object.keys(r.members).length >= r.maxMembers) return { error: 'room_full' };
      r.members[p.uid] = { name: p.name, role: 'member', joinedAt: now(), seen: 0, lastRead: 0 }; sys(r, `${p.name} انضم للغرفة (موافقة ${nameOf(u)})`);
      notify(p.uid, `تم قبولك بـ ${r.name} / Accepted`, r.name, `/#/app/rooms/${r.id}`, 'room');
    }
    save(); return { ok: true };
  }
  function leave(u, id) {
    const r = room(id); if (!r || !r.members[u.uid]) return { error: 'not_found' };
    if (r.members[u.uid].role === 'owner') return { error: 'owner_cannot_leave' };
    delete r.members[u.uid]; leaveMeeting(r, u.uid); sys(r, `${nameOf(u)} غادر الغرفة`); save(); return { ok: true };
  }
  function manage(u, id, b = {}) {
    const r = room(id); if (!r) return { error: 'not_found' }; const me = roleOf(r, u.uid); const t = r.members[b.uid]; const tr = t?.role;
    if (!STAFF.has(me) || !t || b.uid === u.uid) return { error: 'forbidden' };
    const rank = (x) => ROLES.indexOf(x); if (tr === 'owner' || (me !== 'owner' && rank(tr) <= rank(me))) return { error: 'forbidden' };
    if (b.action === 'mute') { t.muted = true; sys(r, `🔇 ${t.name} انكتم`); }
    else if (b.action === 'unmute') { t.muted = false; sys(r, `🔊 ${t.name} رجع يقدر يحكي`); }
    else if (b.action === 'remove' || b.action === 'block') { delete r.members[b.uid]; leaveMeeting(r, b.uid); if (b.action === 'block') r.banned.push(b.uid); sys(r, `${t.name} ${b.action === 'block' ? 'انحظر' : 'انشال'} من الغرفة`); }
    else if (b.action === 'role') { if (!MANAGERS.has(me)) return { error: 'forbidden' }; const nr = ['admin', 'mod', 'member', 'expert'].includes(b.role) ? b.role : null; if (!nr || (nr === 'admin' && me !== 'owner') || (nr === 'expert' && !load().experts[b.uid])) return { error: 'bad_role' }; t.role = nr; sys(r, `⭐ ${t.name} صار ${nr}`); }
    else return { error: 'bad_action' };
    save(); return { ok: true };
  }

  /* ───────── chat ───────── */
  const spam = new Map();
  function spamCheck(uid, rid, text) {
    const k = `${rid}|${uid}`; const s = spam.get(k) || { t: [], last: '', rep: 0 }; const t = now(); s.t = s.t.filter((x) => t - x < 30_000);
    if (s.t.length >= 20) return 'slow_down';
    if (text && text === s.last) { s.rep += 1; if (s.rep >= 2) return 'duplicate'; } else s.rep = 0;
    s.t.push(t); s.last = text; spam.set(k, s); if (spam.size > 20000) spam.clear(); return null;
  }
  function post(u, id, b = {}) {
    const r = room(id); if (!r) return { error: 'not_found' }; const me = r.members[u.uid]; if (!me) return { error: 'forbidden' };
    if (r.suspended || r.archived) return { error: 'suspended' }; if (me.muted) return { error: 'muted' };
    const text = clip(b.text, 2000); if (!text && !b.file) return { error: 'empty' };
    const s = spamCheck(u.uid, id, text); if (s) return { error: s };
    let file = null, fileKind = null;
    if (b.file) { if (!can(r, u.uid, 'upload')) return { error: 'forbidden' }; const f = putFile(b.file, id); if (f.error) return f; file = f.id; fileKind = f.kind; }
    const to = b.to && r.members[b.to] && b.to !== u.uid ? String(b.to) : null;
    const replyTo = b.replyTo && r.messages.some((x) => x.id === b.replyTo && !(x.to && x.uid !== u.uid && x.to !== u.uid)) ? b.replyTo : null;
    const low = text.toLowerCase(); const mentions = to ? [] : Object.entries(r.members).filter(([uid, m]) => uid !== u.uid && low.includes(`@${String(m.name).toLowerCase()}`)).map(([uid]) => uid).slice(0, 10);
    const m = { id: `m${hex(6)}`, uid: u.uid, name: me.name, role: me.role, kind: 'msg', text, at: now(), replyTo, reactions: {}, file, fileKind, to, mentions };
    m.rev = bump(r); r.messages.push(m); trim(r); r.stats.messages = (r.stats.messages || 0) + 1; touch(r, u.uid);
    for (const mu of mentions) notify(mu, `${me.name} ذكرك بـ ${r.name}`, text.slice(0, 120), `/#/app/rooms/${r.id}`, 'room_mention');
    if (to) notify(to, `رسالة خاصة من ${me.name}`, text.slice(0, 120) || '📎', `/#/app/rooms/${r.id}`, 'room_dm');
    save(); return { message: msgView(m, u.uid) };
  }
  function editMsg(u, id, mid, b = {}) {
    const r = room(id); if (!r || !r.members[u.uid]) return { error: 'not_found' }; const m = r.messages.find((x) => x.id === mid); if (!m || m.deleted) return { error: 'not_found' };
    const staff = STAFF.has(roleOf(r, u.uid));
    if (b.action === 'edit') { if (m.uid !== u.uid) return { error: 'forbidden' }; const t = clip(b.text, 2000); if (!t) return { error: 'empty' }; m.text = t; m.edited = true; }
    else if (b.action === 'delete') { if (m.uid !== u.uid && !(staff && !m.to)) return { error: 'forbidden' }; m.deleted = true; m.text = ''; m.pinned = false; }
    else if (b.action === 'react') { if (!REACTIONS.includes(b.emoji) || (m.to && m.uid !== u.uid && m.to !== u.uid)) return { error: 'bad_emoji' }; const l = new Set(m.reactions[b.emoji] || []); l.has(u.uid) ? l.delete(u.uid) : l.add(u.uid); m.reactions[b.emoji] = [...l]; if (!l.size) delete m.reactions[b.emoji]; }
    else if (b.action === 'pin' || b.action === 'unpin') { if (!staff || m.to) return { error: 'forbidden' }; m.pinned = b.action === 'pin'; }
    else return { error: 'bad_action' };
    m.rev = bump(r); save(); return { message: msgView(m, u.uid) };
  }
  /** Everything changed since `since` (room revision) that this member may see. */
  function poll(u, id, since = 0) {
    const r = room(id); if (!r) return { error: 'not_found' };
    const member = r.members[u.uid]; const owner = isSiteOwner(u);
    if (!member && !owner) return { error: 'forbidden' };
    if (member) touch(r, u.uid);
    const s = Math.max(0, Number(since) || 0);
    const msgs = r.messages.filter((m) => m.rev > s).map((m) => msgView(m, u.uid)).filter(Boolean).slice(-300);
    const out = { rev: r.rev, room: { ...card(r, u.uid), rules: r.rules, perms: r.perms }, messages: msgs,
      members: Object.entries(r.members).map(([uid, m]) => memberView(r, uid, m)).sort((a, b) => ROLES.indexOf(a.role) - ROLES.indexOf(b.role) || Number(b.online) - Number(a.online)),
      workspace: r.workspace, predictions: r.predictions.slice(-60).map((p) => predView(p, u.uid)), meeting: meetingView(r), me: member ? { uid: u.uid, role: member.role, muted: Boolean(member.muted) } : { uid: u.uid, role: null, siteOwner: true },
      pending: member && MANAGERS.has(member.role) ? r.pending : [], unread: member ? r.messages.filter((m) => m.rev > (member.lastRead || 0) && m.uid !== u.uid && (!m.to || m.to === u.uid)).length : 0 };
    if (member) member.lastRead = r.rev;
    return out;
  }
  function search(u, id, q) {
    const r = room(id); if (!r || !r.members[u.uid]) return { error: 'forbidden' }; const s = clip(q, 80).toLowerCase(); if (s.length < 2) return { items: [] };
    return { items: r.messages.filter((m) => !m.deleted && m.kind !== 'system' && String(m.text).toLowerCase().includes(s)).map((m) => msgView(m, u.uid)).filter(Boolean).slice(-50) };
  }
  function report(u, id, b = {}) {
    const r = room(id); if (!r || !r.members[u.uid]) return { error: 'forbidden' }; const m = r.messages.find((x) => x.id === b.mid); if (!m || (m.to && m.to !== u.uid && m.uid !== u.uid)) return { error: 'not_found' };
    const d = load(); if (d.reports.filter((x) => x.by === u.uid && now() - x.at < DAY).length >= 20) return { error: 'too_many' };
    d.reports.unshift({ id: `p${hex(6)}`, roomId: r.id, mid: m.id, text: String(m.text).slice(0, 300), author: m.name, authorUid: m.uid, by: u.uid, reason: clip(b.reason, 300), at: now(), status: 'open' }); d.reports.length = Math.min(d.reports.length, 2000); save();
    return { ok: true };
  }

  /* ───────── shared workspace ───────── */
  function workspace(u, id, b = {}) {
    const r = room(id); if (!r) return { error: 'not_found' }; if (!can(r, u.uid, 'share')) return { error: 'forbidden' };
    const w = r.workspace; const staff = STAFF.has(roleOf(r, u.uid));
    if (b.symbol != null) { if (!/^[A-Z0-9]{3,12}$/.test(b.symbol)) return { error: 'bad_symbol' }; w.symbol = b.symbol; }
    if (b.tf != null) { if (!['1m', '5m', '15m', '1h', '4h', '1D'].includes(b.tf)) return { error: 'bad_tf' }; w.tf = b.tf; }
    if (b.add) {
      const a = b.add; const kind = ['level', 'zone', 'trend', 'entry', 'target', 'stop'].includes(a.kind) ? a.kind : null; const p1 = Number(a.p1), p2 = a.p2 == null ? null : Number(a.p2);
      if (!kind || !(p1 > 0) || (p2 != null && !(p2 > 0))) return { error: 'bad_annotation' };
      if (w.ann.length >= 80) return { error: 'too_many' };
      w.ann.push({ id: `a${hex(4)}`, kind, p1, p2, t1: Number(a.t1) || null, t2: Number(a.t2) || null, label: clip(a.label, 40), color: /^#[0-9a-f]{6}$/i.test(a.color) ? a.color : null, by: u.uid, name: r.members[u.uid].name, at: now() });
    }
    if (b.remove) { const a = w.ann.find((x) => x.id === b.remove); if (!a) return { error: 'not_found' }; if (a.by !== u.uid && !staff) return { error: 'forbidden' }; w.ann = w.ann.filter((x) => x !== a); }
    if (b.clear) { if (!staff) return { error: 'forbidden' }; w.ann = []; }
    w.rev = (w.rev || 0) + 1; w.by = r.members[u.uid].name; bump(r); save(); return { workspace: w };
  }

  /* ───────── predictions (immutable, hash-chained) ───────── */
  const predView = (p, uid) => { const v = Object.values(p.votes || {}); const c = (k) => v.filter((x) => x === k).length; const n = v.length || 1;
    return { id: p.id, uid: p.uid, name: p.name, symbol: p.symbol, direction: p.direction, target: p.target, band: p.band ?? null, ref: p.ref, refAt: p.refAt, source: p.source, horizonH: p.horizonH, endsAt: p.endsAt, analysis: p.analysis, risk: p.risk, at: p.at,
      votes: { bull: c('bull'), bear: c('bear'), neutral: c('neutral'), total: v.length, pct: { bull: Math.round((c('bull') / n) * 100), bear: Math.round((c('bear') / n) * 100), neutral: Math.round((c('neutral') / n) * 100) } }, myVote: p.votes?.[uid] || null, result: p.result || null, hash: p.hash }; };
  const chain = (rec) => { const d = load(); const h = crypto.createHash('sha256').update(`${d.chainHead}|${JSON.stringify(rec)}`).digest('hex'); d.chainHead = h; return h; };
  async function predict(u, id, b = {}) {
    const r = room(id); if (!r) return { error: 'not_found' }; if (!can(r, u.uid, 'predict')) return { error: 'forbidden' }; if (r.suspended || r.archived) return { error: 'suspended' };
    if (r.predictions.filter((p) => p.uid === u.uid && now() - p.at < DAY).length >= 10) return { error: 'too_many' };
    const symbol = String(b.symbol || '').toUpperCase(); if (!/^[A-Z0-9]{3,12}$/.test(symbol)) return { error: 'bad_symbol' };
    const direction = ['up', 'down', 'flat'].includes(b.direction) ? b.direction : null; if (!direction) return { error: 'bad_direction' };
    const horizonH = Math.round(Number(b.horizonH)); if (!(horizonH >= 1 && horizonH <= 720)) return { error: 'bad_horizon' };
    const q = await priceOf(symbol); if (!q || !(q.price > 0)) return { error: 'no_price' };
    let target = null, band = null;
    if (direction === 'flat') { band = Number(b.band); if (!(band >= 0.1 && band <= 10)) return { error: 'bad_band' }; }
    else { target = Number(b.target); if (!(target > 0) || (direction === 'up' ? target <= q.price : target >= q.price) || Math.abs(target / q.price - 1) > 0.5) return { error: 'bad_target' }; }
    const rec = { id: `q${hex(6)}`, uid: u.uid, name: r.members[u.uid].name, symbol, direction, target, band, ref: q.price, refAt: q.at || now(), source: q.source || null, horizonH, endsAt: now() + horizonH * 3600_000,
      analysis: clip(b.analysis, 1000), risk: ['low', 'medium', 'high'].includes(b.risk) ? b.risk : 'medium', at: now(), votes: {}, result: null };
    rec.hash = chain({ room: r.id, ...rec, votes: undefined });
    r.predictions.push(rec); sys(r, `📊 ${rec.name} نشر توقع ${symbol} ${direction === 'up' ? '⬆' : direction === 'down' ? '⬇' : '↔'}`, { pred: rec.id }); save();
    return { prediction: predView(rec, u.uid) };
  }
  function vote(u, id, pid, b = {}) {
    const r = room(id); if (!r || !r.members[u.uid]) return { error: 'forbidden' }; const p = r.predictions.find((x) => x.id === pid); if (!p) return { error: 'not_found' };
    if (p.result || now() >= p.endsAt) return { error: 'closed' }; if (!['bull', 'bear', 'neutral'].includes(b.vote)) return { error: 'bad_vote' };
    p.votes[u.uid] = b.vote; bump(r); save(); return { prediction: predView(p, u.uid) };
  }
  let resolving = false;
  async function resolveDue() {
    if (resolving) return 0; resolving = true; let n = 0;
    try {
      for (const r of Object.values(load().rooms)) for (const p of r.predictions) {
        if (p.result || now() < p.endsAt) continue;
        const q = await priceOf(p.symbol).catch(() => null); if (!q || !(q.price > 0)) continue;
        const movePct = ((q.price - p.ref) / p.ref) * 100;
        const hit = p.direction === 'up' ? q.price >= p.target : p.direction === 'down' ? q.price <= p.target : Math.abs(movePct) <= p.band;
        p.result = { price: q.price, at: q.at || now(), source: q.source || null, movePct: +movePct.toFixed(3), hit };
        p.result.hash = chain({ room: r.id, id: p.id, result: { ...p.result } });
        sys(r, `${hit ? '✅' : '❌'} توقع ${p.name} على ${p.symbol}: ${hit ? 'تحقق' : 'ما تحقق'} (${movePct >= 0 ? '+' : ''}${movePct.toFixed(2)}%)`, { pred: p.id }); n++;
      }
      if (n) save();
    } finally { resolving = false; }
    return n;
  }

  /* ───────── meetings (signalling only, in memory) ───────── */
  const meetingView = (r) => (r.meeting ? { id: r.meeting.id, kind: r.meeting.kind, by: r.meeting.by, startedAt: r.meeting.startedAt, presenter: r.meeting.presenter || null,
    participants: Object.entries(r.meeting.participants).map(([uid, p]) => ({ uid, name: p.name, mic: p.mic, cam: p.cam, screen: p.screen, hand: p.hand, speaking: p.speaking, joinedAt: p.joinedAt })) } : null);
  function sweepMeeting(r) {
    const m = r.meeting; if (!m) return;
    for (const [uid, p] of Object.entries(m.participants)) if (now() - p.seen > 25_000) leaveMeeting(r, uid, true);
  }
  function leaveMeeting(r, uid, quiet = false) {
    const m = r.meeting; if (!m || !m.participants[uid]) return;
    delete m.participants[uid]; delete m.queues[uid]; if (m.presenter === uid) m.presenter = null;
    for (const q of Object.values(m.queues)) q.push({ from: uid, type: 'leave', at: now() });
    if (!Object.keys(m.participants).length) { r.meetings.unshift({ id: m.id, kind: m.kind, startedAt: m.startedAt, endedAt: now(), by: m.byName, peak: m.peak }); r.meetings.length = Math.min(r.meetings.length, 50); r.meeting = null; if (!quiet) sys(r, '📴 انتهى الاجتماع'); save(); }
  }
  function meeting(u, id, b = {}) {
    const r = room(id); if (!r || !r.members[u.uid]) return { error: 'forbidden' }; sweepMeeting(r); const me = r.members[u.uid]; const lim = load().limits.meetingMax;
    if (b.action === 'start') {
      if (!can(r, u.uid, 'meet')) return { error: 'forbidden' }; if (r.suspended || r.archived) return { error: 'suspended' };
      if (!r.meeting) { r.meeting = { id: `g${hex(4)}`, kind: b.kind === 'video' ? 'video' : 'voice', by: u.uid, byName: me.name, startedAt: now(), participants: {}, queues: {}, peak: 0, presenter: null };
        sys(r, `🎙️ ${me.name} بلّش ${r.meeting.kind === 'video' ? 'اجتماع فيديو' : 'اجتماع صوتي'}`);
        for (const mu of Object.keys(r.members)) if (mu !== u.uid) notify(mu, `اجتماع مباشر بـ ${r.name} / Live meeting`, `${me.name}`, `/#/app/rooms/${r.id}`, 'room_meeting'); }
      b = { ...b, action: 'join' };
    }
    const m = r.meeting; if (!m) return { error: 'no_meeting' };
    if (b.action === 'join') {
      if (!m.participants[u.uid] && Object.keys(m.participants).length >= lim) return { error: 'meeting_full' };
      if (!m.participants[u.uid]) { for (const q of Object.values(m.queues)) q.push({ from: u.uid, type: 'join', at: now() }); m.participants[u.uid] = { name: me.name, mic: !me.muted, cam: m.kind === 'video', screen: false, hand: false, speaking: false, joinedAt: now(), seen: now() }; m.queues[u.uid] = []; m.peak = Math.max(m.peak, Object.keys(m.participants).length); }
      save(); return { meeting: meetingView(r), peers: Object.keys(m.participants).filter((x) => x !== u.uid) };
    }
    const p = m.participants[u.uid]; if (!p) return { error: 'not_in_meeting' };
    p.seen = now();
    if (b.action === 'leave') { leaveMeeting(r, u.uid); return { ok: true }; }
    if (b.action === 'state') {
      for (const k of ['mic', 'cam', 'hand', 'speaking']) if (b[k] != null) p[k] = Boolean(b[k]);
      if (me.muted) p.mic = false;
      if (b.screen != null) { if (b.screen && !can(r, u.uid, 'share')) return { error: 'forbidden' }; p.screen = Boolean(b.screen); m.presenter = p.screen ? u.uid : (m.presenter === u.uid ? null : m.presenter); }
      return { meeting: meetingView(r) };
    }
    if (b.action === 'signal') {
      const to = String(b.to || ''); if (!m.participants[to] || !['offer', 'answer', 'ice'].includes(b.type)) return { error: 'bad_signal' };
      const data = JSON.stringify(b.data ?? null); if (data.length > 64_000) return { error: 'too_large' };
      const q = m.queues[to]; if (q.length > 400) q.splice(0, q.length - 400); q.push({ from: u.uid, type: b.type, data: b.data, at: now() }); return { ok: true };
    }
    if (b.action === 'mute') { if (!STAFF.has(roleOf(r, u.uid)) && m.by !== u.uid) return { error: 'forbidden' }; const t = m.participants[b.uid]; if (!t) return { error: 'not_found' }; t.mic = false; m.queues[b.uid]?.push({ from: u.uid, type: 'mute', at: now() }); return { ok: true }; }
    if (b.action === 'end') { if (!STAFF.has(roleOf(r, u.uid)) && m.by !== u.uid) return { error: 'forbidden' }; for (const uid of Object.keys(m.participants)) leaveMeeting(r, uid, true); if (r.meeting) r.meeting = null; sys(r, '📴 انتهى الاجتماع'); save(); return { ok: true }; }
    if (b.action === 'poll') { const q = m.queues[u.uid] || []; m.queues[u.uid] = []; return { meeting: meetingView(r), signals: q }; }
    return { error: 'bad_action' };
  }

  /* ───────── AI assistant & mentor ───────── */
  const aiHits = new Map();
  async function ai(u, id, b = {}) {
    const r = room(id); if (!r || !r.members[u.uid]) return { error: 'forbidden' }; if (!load().limits.aiEnabled) return { error: 'ai_off' };
    const mode = ['ask', 'summary', 'disagreements', 'mentor'].includes(b.mode) ? b.mode : 'ask';
    if (mode === 'mentor' ? !r.ai?.mentor : !r.ai?.assistant) return { error: 'ai_disabled' };
    const t = now(); const h = (aiHits.get(r.id) || []).filter((x) => t - x < 60_000); if (h.length >= 6) return { error: 'slow_down' }; h.push(t); aiHits.set(r.id, h);
    const recent = r.messages.filter((m) => !m.to && !m.deleted && m.kind !== 'system').slice(-40).map((m) => `${m.name}${m.kind === 'ai' ? ' (AI)' : ''}: ${m.text}`).join('\n');
    const preds = r.predictions.slice(-8).map((p) => `${p.name}: ${p.symbol} ${p.direction}${p.target ? ` → ${p.target}` : ''} (ref ${p.ref} @ ${new Date(p.refAt).toISOString()}, source ${p.source || 'n/a'}) votes ${JSON.stringify(predView(p).votes.pct)}${p.result ? ` RESULT ${p.result.hit ? 'hit' : 'miss'} at ${p.result.price}` : ''}`).join('\n');
    const ask = clip(b.text, 1500);
    const task = mode === 'summary' ? 'Summarize today\'s discussion in this room: main topics, trade ideas, predictions and decisions. Bullet points.'
      : mode === 'disagreements' ? 'List where members agree and where they disagree, with each side\'s argument. Do not take sides.' : ask || 'Answer the last question in the room.';
    const system = mode === 'mentor' ? mentorSystem(r.ai.mentor) : ROOM_ASSISTANT_SYSTEM;
    const content = `Room: ${r.name} (${r.spec}). Rules: ${r.rules || '—'}\nRecent messages:\n${recent || '(none)'}\nPredictions:\n${preds || '(none)'}\n\nTask from ${r.members[u.uid].name}: ${task}`;
    const out = await aiAsk(u, system, [{ role: 'user', content: content.slice(0, 12000) }]);
    if (out.error) return out;
    const mt = mode === 'mentor' ? mentorById(r.ai.mentor) : null;
    const m = { id: `m${hex(6)}`, uid: null, name: mt ? mt.name.ar.split(' — ')[0] : 'Alpha AI', role: 'ai', kind: 'ai', text: clip(out.text, 4000), at: now(), reactions: {}, ai: { mode, mentor: mt?.id || null, askedBy: r.members[u.uid].name, model: out.model || null } };
    m.rev = bump(r); r.messages.push(m); trim(r); save(); return { message: msgView(m, u.uid) };
  }
  function setAi(u, id, b = {}) {
    const r = room(id); if (!r) return { error: 'not_found' }; if (!MANAGERS.has(roleOf(r, u.uid))) return { error: 'forbidden' };
    if (b.assistant != null) r.ai.assistant = Boolean(b.assistant);
    if (b.mentor !== undefined) { if (b.mentor && !mentorById(b.mentor)) return { error: 'bad_mentor' }; r.ai.mentor = b.mentor || null; if (b.mentor) sys(r, `🎓 المرشد ${mentorById(b.mentor).name.ar} انضم للغرفة`); }
    bump(r); save(); return { ai: r.ai };
  }

  /* ───────── experts ───────── */
  function applyExpert(u, b = {}) { const d = load(); if (d.experts[u.uid]) return { error: 'already' }; const bio = clip(b.bio, 600); if (bio.length < 20) return { error: 'bio_short' };
    d.expertRequests = d.expertRequests.filter((x) => x.uid !== u.uid); d.expertRequests.unshift({ uid: u.uid, name: nameOf(u), bio, markets: clip(b.markets, 120), at: now() }); save(); return { ok: true }; }
  function verifyExpert(admin, b = {}) {
    if (!isSiteOwner(admin)) return { error: 'forbidden' }; const d = load(); const req = d.expertRequests.find((x) => x.uid === b.uid);
    if (b.revoke) { delete d.experts[b.uid]; for (const r of Object.values(d.rooms)) if (r.members[b.uid]?.role === 'expert') r.members[b.uid].role = 'member'; save(); return { ok: true }; }
    if (!req) return { error: 'not_found' };
    d.experts[req.uid] = { name: req.name, bio: req.bio, markets: req.markets, verifiedAt: now() }; d.expertRequests = d.expertRequests.filter((x) => x !== req);
    notify(req.uid, 'تم توثيقك كخبير ✔ / Verified expert', 'AlphaTrade AI', '/#/app/rooms', 'room'); save(); return { ok: true };
  }
  /** Experts with their REAL platform record: predictions they published in rooms that were resolved by the server. */
  function experts() {
    const d = load(); const stat = {};
    for (const r of Object.values(d.rooms)) for (const p of r.predictions) if (p.result && d.experts[p.uid]) { const s = (stat[p.uid] ||= { n: 0, hits: 0 }); s.n++; if (p.result.hit) s.hits++; }
    return { items: Object.entries(d.experts).map(([uid, e]) => ({ uid, name: e.name, bio: e.bio, markets: e.markets, verifiedAt: e.verifiedAt, record: stat[uid] || { n: 0, hits: 0 } })) };
  }

  /* ───────── leaderboard (transparent rules) ───────── */
  const wilson = (k, n, z = 1.64) => { if (!n) return 0; const p = k / n; return (p + z * z / (2 * n) - z * Math.sqrt((p * (1 - p) + z * z / (4 * n)) / n)) / (1 + z * z / n); };
  function leaderboard(period = 'week') {
    const since = now() - (period === 'month' ? 30 : 7) * DAY; const items = [];
    for (const r of Object.values(load().rooms)) {
      if (r.suspended || r.archived || Object.keys(r.members).length < 3) continue;
      const preds = r.predictions.filter((p) => p.result && p.result.at >= since); const hits = preds.filter((p) => p.result.hit).length;
      const msgs = r.messages.filter((m) => m.kind === 'msg' && m.at >= since); const active = new Set(msgs.map((m) => m.uid)).size;
      const meetings = r.meetings.filter((m) => m.startedAt >= since).length;
      const acc = wilson(hits, preds.length);
      const score = preds.length >= 5 ? Math.round(100 * (0.6 * acc + 0.25 * Math.min(1, active / 10) + 0.15 * Math.min(1, msgs.length / 300))) : null;
      items.push({ id: r.access === 'public' ? r.id : null, name: r.name, spec: r.spec, access: r.access, predictions: preds.length, hits, accuracy: preds.length ? Math.round((hits / preds.length) * 100) : null, active, messages: msgs.length, meetings, score });
    }
    items.sort((a, b) => (b.score ?? -1) - (a.score ?? -1) || b.active - a.active);
    return { period, since, items: items.slice(0, 50), rules: 'score = 100 × (0.6 × Wilson lower bound (90 %) of the prediction hit rate + 0.25 × min(1, active members / 10) + 0.15 × min(1, messages / 300)); ranked with ≥ 5 resolved predictions in the period; results are taken by the server from market prices.' };
  }

  /* ───────── dashboard ───────── */
  function dashboard(u) {
    const d = load(); const mine = [], managed = [], joined = [], meetings = [], pending = [], activity = []; const favs = d.favs[u.uid] || [];
    for (const r of Object.values(d.rooms)) {
      const m = r.members[u.uid];
      if (m) {
        const c = { ...card(r, u.uid), unread: r.messages.filter((x) => x.rev > (m.lastRead || 0) && x.uid !== u.uid && (!x.to || x.to === u.uid)).length };
        const res = r.predictions.filter((p) => p.result); c.performance = { predictions: res.length, hits: res.filter((p) => p.result.hit).length };
        (m.role === 'owner' ? mine : MANAGERS.has(m.role) || m.role === 'mod' ? managed : joined).push(c);
        if (r.meeting) meetings.push(c);
        const lastMsg = r.messages.filter((x) => x.kind !== 'system' && (!x.to || x.to === u.uid || x.uid === u.uid)).at(-1); if (lastMsg) activity.push({ room: r.id, roomName: r.name, at: lastMsg.at, name: lastMsg.name, text: lastMsg.deleted ? '' : String(lastMsg.text).slice(0, 80), kind: lastMsg.kind });
      }
      for (const inv of r.invites) if (inv.toUid === u.uid && inv.uses < inv.max && inv.expires > now() && !m) pending.push({ code: inv.code, room: card(r, u.uid), role: inv.role, expires: inv.expires });
    }
    const recommended = Object.values(d.rooms).filter((r) => r.access === 'public' && !r.suspended && !r.archived && !r.members[u.uid]).map((r) => ({ ...card(r, u.uid), act: r.messages.filter((m) => now() - m.at < 7 * DAY).length })).sort((a, b) => b.act - a.act).slice(0, 12);
    return { mine, managed, joined, favorites: [...mine, ...managed, ...joined].filter((x) => favs.includes(x.id)), meetings, pending, recommended, activity: activity.sort((a, b) => b.at - a.at).slice(0, 15), limits: { maxRooms: d.limits.maxRoomsPerUser, owned: mine.length }, expert: Boolean(d.experts[u.uid]) };
  }
  function directory(u, q = '') { const s = clip(q, 60).toLowerCase(); return { items: Object.values(load().rooms).filter((r) => r.access === 'public' && !r.suspended && !r.archived && (!s || r.name.toLowerCase().includes(s) || r.id === s.toUpperCase())).slice(0, 60).map((r) => card(r, u.uid)) }; }
  function fav(u, id, on) { const r = room(id); if (!r || !r.members[u.uid]) return { error: 'forbidden' }; const d = load(); const l = new Set(d.favs[u.uid] || []); on ? l.add(id) : l.delete(id); d.favs[u.uid] = [...l]; save(); return { ok: true }; }

  /* ───────── site owners ───────── */
  function admin(u) {
    if (!isSiteOwner(u)) return { error: 'forbidden' }; const d = load();
    return { rooms: Object.values(d.rooms).map((r) => ({ ...card(r), owner: r.members[r.ownerUid]?.name || '—', messages: r.stats.messages || 0, predictions: r.predictions.length, reports: d.reports.filter((x) => x.roomId === r.id && x.status === 'open').length })),
      reports: d.reports.slice(0, 200), expertRequests: d.expertRequests, experts: experts().items, limits: d.limits, mentors: MENTORS.map((m) => ({ id: m.id, name: m.name })) };
  }
  function adminAct(u, b = {}) {
    if (!isSiteOwner(u)) return { error: 'forbidden' }; const d = load();
    if (b.action === 'suspend' || b.action === 'unsuspend') { const r = room(b.room); if (!r) return { error: 'not_found' }; r.suspended = b.action === 'suspend'; if (r.suspended) { r.meeting = null; sys(r, '⛔ الغرفة موقوفة من إدارة المنصة'); } bump(r); save(); return { ok: true }; }
    if (b.action === 'report') { const x = d.reports.find((p) => p.id === b.id); if (!x) return { error: 'not_found' }; x.status = b.status === 'dismiss' ? 'dismissed' : 'resolved';
      if (b.deleteMessage) { const r = room(x.roomId); const m = r?.messages.find((y) => y.id === x.mid); if (m) { m.deleted = true; m.text = ''; m.rev = bump(r); } } save(); return { ok: true }; }
    if (b.action === 'limits') { const l = b.limits || {}; const n = (v, lo, hi, def) => { const x = Math.round(Number(v)); return Number.isFinite(x) ? Math.min(hi, Math.max(lo, x)) : def; };
      d.limits = { maxRoomsPerUser: n(l.maxRoomsPerUser, 1, 100, d.limits.maxRoomsPerUser), maxMembersCap: n(l.maxMembersCap, 2, 1000, d.limits.maxMembersCap), meetingMax: n(l.meetingMax, 2, 12, d.limits.meetingMax), aiEnabled: l.aiEnabled == null ? d.limits.aiEnabled : Boolean(l.aiEnabled) }; save(); return { limits: d.limits }; }
    if (b.action === 'expert') return verifyExpert(u, b);
    return { error: 'bad_action' };
  }
  /** Account deletion: memberships, favourites, expert status and pending requests go; messages stay as "deleted user" (others' context). */
  function forgetUser(uid) {
    const d = load(); delete d.favs[uid]; delete d.experts[uid]; d.expertRequests = d.expertRequests.filter((x) => x.uid !== uid);
    for (const r of Object.values(d.rooms)) {
      if (r.members[uid]) { if (r.members[uid].role === 'owner') { r.archived = true; } delete r.members[uid]; if (r.meeting) leaveMeeting(r, uid, true); }
      r.pending = r.pending.filter((x) => x.uid !== uid);
      for (const m of r.messages) if (m.uid === uid) { m.name = 'deleted user'; m.uid = null; if (m.to) { m.deleted = true; m.text = ''; } }
      for (const p of r.predictions) if (p.uid === uid) { p.name = 'deleted user'; p.uid = null; }
    }
    save();
  }
  return { create, updateSettings, invite, preview, join, decide, leave, manage, post, editMsg, poll, search, report, workspace, predict, vote, resolveDue, meeting, ai, setAi,
    applyExpert, verifyExpert, experts, leaderboard, dashboard, directory, fav, admin, adminAct, forgetUser, getFile, canSave: () => Boolean(key), flush: () => writer.flush(), _db: load };
}
