// Telegram alerts for the headless worker. The bot token stays on the server (environment only); it is never
// sent to the website, never logged, and error messages are stripped of it.
//   TELEGRAM_BOT_TOKEN  token from @BotFather
//   TELEGRAM_CHAT_ID    your chat id (or a channel id such as -100…)

export const telegramConfigured = (env = process.env) => Boolean(env.TELEGRAM_BOT_TOKEN && env.TELEGRAM_CHAT_ID);

/** The message body Telegram receives (plain text, so prices and symbols are never parsed as markup). */
export function telegramPayload(chatId, title, body) {
  const text = `AlphaTrade AI · ${String(title || '').slice(0, 200)}\n${String(body || '').slice(0, 3500)}`;
  return { chat_id: chatId, text, disable_web_page_preview: true };
}

/** Sends one message. Resolves { ok, status }; never throws and never exposes the token. */
export async function sendTelegram({ token, chatId, title, body, fetchImpl = fetch, timeoutMs = 10_000, base = 'https://api.telegram.org' }) {
  if (!token || !chatId) return { ok: false, status: 'not-configured' };
  const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetchImpl(`${base}/bot${token}/sendMessage`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(telegramPayload(chatId, title, body)), signal: ctrl.signal,
    });
    return { ok: Boolean(res.ok), status: res.status };
  } catch (err) {
    return { ok: false, status: String(err?.name === 'AbortError' ? 'timeout' : err?.message || 'error').split(token).join('***') };
  } finally { clearTimeout(timer); }
}
