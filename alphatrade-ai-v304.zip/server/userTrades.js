// The user's own assistant trade history, one encrypted file per signed-in user (AES-256-GCM, key from AI_KEY_SECRET,
// file name = keyed hash of the uid, the uid bound as AAD so one user's file can never be read as another's).
// Validation is strict: a trade is a small flat record of known fields; anything else is rejected.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export const MAX_TRADES = 500;
const SYMBOL = /^[A-Z0-9]{2,15}$/;
const ID = /^[A-Za-z0-9_-]{6,40}$/;
const TF_SEC = { '1m': 60, '5m': 300, '15m': 900, '1h': 3600, '4h': 14400, '1D': 86400 };
const STATUS = ['pending', 'active', 'done', 'stopped', 'breakeven', 'expired', 'missed', 'cancelled'];
const fin = (v) => typeof v === 'number' && Number.isFinite(v);
const pos = (v) => fin(v) && v > 0 && v < 1e12;

/** A clean copy of one trade, or { error }. */
export function cleanTrade(x) {
  if (!x || typeof x !== 'object' || Array.isArray(x)) return { error: 'bad_trade' };
  const t = {};
  if (!ID.test(String(x.id || ''))) return { error: 'bad_id' };
  t.id = String(x.id);
  if (!SYMBOL.test(String(x.symbol || ''))) return { error: 'bad_symbol' };
  t.symbol = String(x.symbol);
  if (!['1m', '5m', '15m', '1h', '4h', '1D'].includes(x.tf)) return { error: 'bad_tf' };
  t.tf = x.tf;
  for (const [k, list] of [['style', ['swing', 'scalp']], ['direction', ['long', 'short']], ['execution', ['market', 'limit']], ['account', ['spot', 'margin', 'prop', 'demo']], ['asset', ['crypto', 'forex', 'metal', 'index', 'energy', 'stock']], ['status', STATUS]]) {
    if (!list.includes(x[k])) return { error: `bad_${k}` };
    t[k] = x[k];
  }
  for (const k of ['entry', 'stop', 'risk']) { if (!pos(x[k])) return { error: `bad_${k}` }; t[k] = x[k]; }
  if (!Array.isArray(x.targets) || !x.targets.length || x.targets.length > 3 || !x.targets.every(pos)) return { error: 'bad_targets' };
  if (!Array.isArray(x.rr) || x.rr.length !== x.targets.length || !x.rr.every((v) => fin(v) && v >= 0 && v < 1000)) return { error: 'bad_rr' };
  t.targets = x.targets; t.rr = x.rr;
  const dirOk = x.direction === 'long' ? x.stop < x.entry && x.targets.every((v) => v > x.entry) : x.stop > x.entry && x.targets.every((v) => v < x.entry);
  if (!dirOk) return { error: 'bad_levels' };
  for (const k of ['createdAt', 'savedAt', 'updatedAt']) { if (!(Number.isSafeInteger(x[k]) && x[k] > 1e9 && x[k] < 1e13)) return { error: `bad_${k}` }; t[k] = x[k]; }
  for (const k of ['validUntil', 'filledAt', 'closedAt']) { if (x[k] == null) t[k] = null; else if (Number.isSafeInteger(x[k]) && x[k] > 1e9 && x[k] < 1e13) t[k] = x[k]; else return { error: `bad_${k}` }; }
  if (!(Number.isInteger(x.hits) && x.hits >= 0 && x.hits <= 3)) return { error: 'bad_hits' };
  t.hits = x.hits;
  t.resultR = x.resultR == null ? null : fin(x.resultR) && Math.abs(x.resultR) < 1000 ? x.resultR : undefined;
  if (t.resultR === undefined) return { error: 'bad_resultR' };
  for (const k of ['capital', 'riskPct', 'riskAmount', 'units']) { if (x[k] == null) t[k] = null; else if (fin(x[k]) && x[k] >= 0 && x[k] < 1e13) t[k] = x[k]; else return { error: `bad_${k}` }; }
  t.mode = x.mode === 'live' ? 'live' : 'demo';
  t.costR = x.costR == null ? 0 : fin(x.costR) && x.costR >= 0 && x.costR < 100 ? x.costR : undefined;
  if (t.costR === undefined) return { error: 'bad_costR' };
  if (x.tags != null && (!Array.isArray(x.tags) || x.tags.length > 12 || !x.tags.every((g) => typeof g === 'string' && /^[a-z_]{2,20}$/.test(g)))) return { error: 'bad_tags' };
  t.tags = x.tags || [];
  t.note = typeof x.note === 'string' ? x.note.replace(/[\u0000-\u001f]/g, ' ').slice(0, 200) : '';
  t.strategy = ['smc', 'trend', 'mean_reversion'].includes(x.strategy) ? x.strategy : 'smc';
  // v234 («توصية AI»): why a pending order was cancelled, and a short time line of status changes (each with its reason)
  const REASON = /^[a-z_]{2,24}$/;
  t.cancelReason = REASON.test(String(x.cancelReason || '')) ? String(x.cancelReason) : null;
  t.history = Array.isArray(x.history) ? x.history.slice(-20).filter((h) => h && Number.isSafeInteger(h.at) && h.at > 1e9 && h.at < 1e13 && STATUS.includes(h.status))
    .map((h) => ({ at: h.at, status: h.status, hits: Number.isInteger(h.hits) && h.hits >= 0 && h.hits <= 3 ? h.hits : 0, reason: REASON.test(String(h.reason || '')) ? String(h.reason) : null })) : [];
  if (typeof x.engine === 'string' && /^[\w .()-]{1,40}$/.test(x.engine)) t.engine = x.engine;
  // market context at issue time (the learning engine groups results by it): only short known fields, numbers clipped
  if (x.ctx && typeof x.ctx === 'object') {
    const c = x.ctx, n = (v) => (Number.isFinite(Number(v)) ? Math.round(Number(v) * 1000) / 1000 : null), w = (v) => (/^[a-z_]{1,20}$/.test(String(v || '')) ? String(v) : null);
    t.ctx = { session: w(c.session), regime: w(c.regime), htf: w(c.htf), adx: n(c.adx), rsi: n(c.rsi), atrPct: n(c.atrPct), hour: Number.isInteger(c.hour) && c.hour >= 0 && c.hour < 24 ? c.hour : null };
  }
  return { value: t };
}

export function createUserTrades({ dir, secret }) {
  const folder = path.join(dir, 'user-trades');
  const key = secret && String(secret).length >= 32 ? crypto.scryptSync(String(secret), 'alphatrade-user-trades-v1', 32) : null;
  const nameKey = key ? crypto.createHash('sha256').update(key).update('names').digest() : null;
  const fileOf = (uid) => path.join(folder, `${crypto.createHmac('sha256', nameKey).update(String(uid)).digest('hex').slice(0, 40)}.json`);
  const read = (uid) => {
    try {
      const e = JSON.parse(fs.readFileSync(fileOf(uid), 'utf8'));
      const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(e.iv, 'base64'));
      d.setAAD(Buffer.from(`trades:${uid}`)); d.setAuthTag(Buffer.from(e.tag, 'base64'));
      const items = JSON.parse(Buffer.concat([d.update(Buffer.from(e.data, 'base64')), d.final()]).toString('utf8'));
      return Array.isArray(items) ? items : [];
    } catch { return []; }   // no file yet (or written with another secret)
  };
  const write = (uid, items) => {
    fs.mkdirSync(folder, { recursive: true, mode: 0o700 });
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from(`trades:${uid}`));
    const data = Buffer.concat([c.update(JSON.stringify(items), 'utf8'), c.final()]);
    const file = fileOf(uid); const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify({ v: 1, iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: data.toString('base64') }), { mode: 0o600 });
    fs.renameSync(tmp, file);   // atomic: a crash never leaves half a file
  };
  // Encrypted list of the users who have open (pending / active) trades, so the server-side watcher knows whom to check.
  const OPEN = ['pending', 'active'];
  const indexFile = () => path.join(folder, 'open-index.json');
  const readIndex = () => {
    try {
      const e = JSON.parse(fs.readFileSync(indexFile(), 'utf8'));
      const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(e.iv, 'base64'));
      d.setAAD(Buffer.from('trades:index')); d.setAuthTag(Buffer.from(e.tag, 'base64'));
      const uids = JSON.parse(Buffer.concat([d.update(Buffer.from(e.data, 'base64')), d.final()]).toString('utf8'));
      return new Set(Array.isArray(uids) ? uids.filter((u) => typeof u === 'string') : []);
    } catch { return new Set(); }
  };
  const writeIndex = (set) => {
    fs.mkdirSync(folder, { recursive: true, mode: 0o700 });
    const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from('trades:index'));
    const data = Buffer.concat([c.update(JSON.stringify([...set]), 'utf8'), c.final()]);
    const tmp = `${indexFile()}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify({ v: 1, iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: data.toString('base64') }), { mode: 0o600 });
    fs.renameSync(tmp, indexFile());
  };
  const reindex = (uid, items) => {
    const set = readIndex(); const has = items.some((x) => OPEN.includes(x.status));
    if (has === set.has(uid)) return;
    if (has) set.add(uid); else set.delete(uid);
    writeIndex(set);
  };
  return {
    canSave: () => Boolean(key),
    /** uids that currently have at least one open trade (for the server-side watcher). */
    openOwners: () => (key ? [...readIndex()] : []),
    openTrades: (uid) => read(uid).filter((x) => OPEN.includes(x.status)),
    /** Server-side outcome update (status, hits, times, result). Only open trades change; the record is re-validated. */
    setOutcome(uid, id, r) {
      const items = read(uid); const i = items.findIndex((x) => x.id === id);
      if (i < 0 || !OPEN.includes(items[i].status)) return null;
      const c = cleanTrade({ ...items[i], status: r.status, hits: r.hits, filledAt: r.filledAt, closedAt: r.closedAt, resultR: r.resultR, updatedAt: Date.now() });
      if (c.error) return null;
      c.value._srv = { ...(items[i]._srv || {}), judged: true };
      items[i] = c.value; write(uid, items); reindex(uid, items);
      return c.value;
    },
    list: (uid) => read(uid).sort((a, b) => b.savedAt - a.savedAt),
    /** Insert or replace by id (the newer updatedAt wins). Returns { item } or { error }. */
    upsert(uid, raw) {
      const c = cleanTrade(raw); if (c.error) return c;
      const items = read(uid);
      const i = items.findIndex((x) => x.id === c.value.id);
      if (i >= 0) {
        if (items[i].updatedAt > c.value.updatedAt) return { item: items[i], stale: true };
        // an outcome already judged (here or by another device) is never reopened by an older copy; notes and tags still update
        const prev = items[i]; const rank = (x) => (OPEN.includes(x.status) ? (x.status === 'active' ? 1 : 0) : 2) * 10 + x.hits;
        if (rank(prev) > rank(c.value)) for (const k of ['status', 'hits', 'filledAt', 'closedAt', 'resultR']) c.value[k] = prev[k];
        c.value._srv = prev._srv;   // server-only facts (when it arrived, who judged it) never come from the browser
        items[i] = c.value;
      }
      else {
        if (items.length >= MAX_TRADES) items.sort((a, b) => b.savedAt - a.savedAt).length = MAX_TRADES - 1;
        // "fair" = sent to the server right when the plan was made (not back-dated after the price already moved)
        const at = Date.now(); c.value._srv = { receivedAt: at, fair: ['pending', 'active'].includes(c.value.status) && at - c.value.createdAt * 1000 <= Math.max(2 * (TF_SEC[c.value.tf] || 3600), 600) * 1000 };
        items.push(c.value);
      }
      write(uid, items); reindex(uid, items);
      return { item: c.value };
    },
    /** Account deletion: the user's whole trade file and their entry in the open-trades index. */
    removeAll(uid) { try { fs.rmSync(fileOf(uid), { force: true }); } catch { /* none */ } reindex(uid, []); return true; },
    remove(uid, id) {
      const items = read(uid); const next = items.filter((x) => x.id !== id);
      if (next.length === items.length) return false;
      write(uid, next); reindex(uid, next); return true;
    },
  };
}
