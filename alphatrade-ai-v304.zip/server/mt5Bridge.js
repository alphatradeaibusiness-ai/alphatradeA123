// MetaTrader 5 bridge (v216): links a customer's MT5 terminal (the AlphaTradeBridge Expert Advisor, public/mt5/) to this server.
//
// Security model
//   • The EA runs INSIDE the customer's MT5 terminal, which is already logged in to the broker. The broker password is therefore
//     never needed and never accepted here: the link is a random pairing token created on the website (shown once, stored
//     only as an HMAC hash) plus the MT5 account number and server name, which the EA checks against the terminal itself.
//   • A token is bound to ONE account number + server. A terminal logged in to another account is refused.
//   • Orders from the website are only queued; the EA executes them only when the customer enabled "Allow trading" in the EA's
//     inputs (off by default) and they respect its maximum lot. A queued order that is not picked up within 60 s expires.
//   • Every command and every result (ticket, retcode, message) is documented in a log here and in a CSV file on the terminal.
//   • Stored with AES-256-GCM (key derived from AI_KEY_SECRET), like the other private stores of this server.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export const ONLINE_MS = 15_000;          // a terminal that reported within 15 s is "connected"
export const COMMAND_TTL_MS = 60_000;     // a queued order expires if the EA does not pick it up in time
const MAX_LINKS = 3, MAX_LOG = 300, MAX_QUEUE = 20;
const SYMBOL_RE = /^[A-Za-z0-9._#\-]{2,24}$/;
const SERVER_RE = /^[\p{L}\p{N} ._\-]{2,64}$/u;
const TOKEN_RE = /^mt5_[0-9a-f]{48}$/;
const rid = (p) => `${p}${crypto.randomBytes(6).toString('hex')}`;
const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);
const clip = (s, n) => String(s ?? '').replace(/[\u0000-\u001f|\u007f]/g, ' ').trim().slice(0, n);

export function cleanAccount(v) { const s = String(v ?? '').trim(); return /^\d{3,15}$/.test(s) ? s : null; }
export function cleanServer(v) { const s = String(v ?? '').trim(); return SERVER_RE.test(s) ? s : null; }

/** Validates an order request from the website. Returns { order } or { error }. */
export function cleanOrder(b) {
  const action = ['buy', 'sell'].includes(b?.side) ? b.side : null;
  if (!action) return { error: 'bad_side' };
  const symbol = String(b.symbol || '').trim();
  if (!SYMBOL_RE.test(symbol)) return { error: 'bad_symbol' };
  const volume = num(b.volume);
  if (!(volume > 0 && volume <= 100)) return { error: 'bad_volume' };
  const sl = b.sl === '' || b.sl == null ? 0 : num(b.sl), tp = b.tp === '' || b.tp == null ? 0 : num(b.tp);
  if (sl == null || tp == null || sl < 0 || tp < 0) return { error: 'bad_levels' };
  return { order: { action, symbol, volume: Math.round(volume * 100) / 100, sl, tp, comment: clip(b.comment || 'AlphaTrade AI', 24) } };
}

export function createMt5Bridge({ dir, secret }) {
  const file = path.join(dir, 'mt5-bridge.json');
  // Same rule as the other private stores: no key (feature off, 503 no_secret) unless AI_KEY_SECRET is a strong secret.
  const key = secret && String(secret).length >= 32 ? crypto.scryptSync(String(secret), 'alphatrade-mt5-bridge-v1', 32) : null;
  const hmac = (t) => crypto.createHmac('sha256', key || 'x').update(t).digest('hex');
  let db = { links: {} };   // id → { id, uid, account, server, tokenHash, createdAt, lastSeen, terminal, queue:[], log:[] }

  const load = () => {
    if (!key) return;
    try {
      const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
      const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(raw.iv, 'base64'));
      d.setAuthTag(Buffer.from(raw.tag, 'base64'));
      db = JSON.parse(Buffer.concat([d.update(Buffer.from(raw.data, 'base64')), d.final()]).toString('utf8'));
    } catch { /* first run, or unreadable → start empty */ }
  };
  let timer = null;
  const save = () => {
    if (!key || timer) return;
    timer = setTimeout(() => {
      timer = null;
      const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv);
      const data = Buffer.concat([c.update(JSON.stringify(db), 'utf8'), c.final()]);
      fs.mkdirSync(dir, { recursive: true });
      const tmp = `${file}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify({ iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: data.toString('base64') }), { mode: 0o600 });
      fs.renameSync(tmp, file);
    }, 300);
  };
  load();

  const log = (L, entry) => { L.log.unshift({ at: Date.now(), ...entry }); L.log = L.log.slice(0, MAX_LOG); };
  const expire = (L, now = Date.now()) => {
    for (const c of L.queue) if (c.status === 'queued' && now - c.at > COMMAND_TTL_MS) { c.status = 'expired'; log(L, { id: c.id, action: c.action, symbol: c.symbol, status: 'expired', message: 'not picked up by the terminal within 60 s' }); }
    L.queue = L.queue.filter((c) => ['queued', 'sent'].includes(c.status) && now - c.at < 10 * 60_000);
  };
  const view = (L, now = Date.now()) => ({
    id: L.id, account: L.account, server: L.server, createdAt: L.createdAt, lastSeen: L.lastSeen || null,
    connected: Boolean(L.lastSeen && now - L.lastSeen < ONLINE_MS), terminal: L.terminal || null,
    queue: L.queue.map((c) => ({ id: c.id, action: c.action, symbol: c.symbol, volume: c.volume, status: c.status, at: c.at })),
    log: L.log.slice(0, 50),
  });
  const mine = (uid, id) => { const L = db.links[id]; return L && L.uid === uid ? L : null; };
  const byToken = (token) => {
    if (!TOKEN_RE.test(String(token || ''))) return null;
    const h = hmac(token);
    return Object.values(db.links).find((L) => L.tokenHash.length === h.length && crypto.timingSafeEqual(Buffer.from(L.tokenHash), Buffer.from(h))) || null;
  };

  return {
    canSave: () => Boolean(key),
    // ── website (signed-in customer) ──
    list(uid) { const now = Date.now(); return { links: Object.values(db.links).filter((L) => L.uid === uid).map((L) => { expire(L, now); return view(L, now); }) }; },
    createLink(uid, b) {
      const account = cleanAccount(b?.account), server = cleanServer(b?.server);
      if (!account) return { error: 'bad_account' };
      if (!server) return { error: 'bad_server' };
      if (Object.values(db.links).filter((L) => L.uid === uid).length >= MAX_LINKS) return { error: 'too_many_links' };
      const token = `mt5_${crypto.randomBytes(24).toString('hex')}`;
      const L = { id: rid('m'), uid, account, server, tokenHash: hmac(token), createdAt: Date.now(), lastSeen: 0, terminal: null, queue: [], log: [] };
      log(L, { action: 'link', status: 'created', message: `account ${account} @ ${server}` });
      db.links[L.id] = L; save();
      return { link: view(L), token };   // the token is shown once; only its hash is kept
    },
    removeLink(uid, id) { if (!mine(uid, id)) return { error: 'not_found' }; delete db.links[id]; save(); return { ok: true }; },
    // v235: account deletion — every link of this account goes (its pairing tokens stop working at once)
    removeAll(uid) { let n = 0; for (const [id, L] of Object.entries(db.links)) if (L.uid === uid) { delete db.links[id]; n += 1; } if (n) save(); return { removed: n }; },
    queueOrder(uid, id, b) {
      const L = mine(uid, id); if (!L) return { error: 'not_found' };
      if (!(L.lastSeen && Date.now() - L.lastSeen < ONLINE_MS)) return { error: 'terminal_offline' };
      if (!L.terminal?.allowTrading) return { error: 'trading_disabled' };
      expire(L);
      if (L.queue.length >= MAX_QUEUE) return { error: 'queue_full' };
      let cmd;
      if (b?.type === 'close') {
        const ticket = String(b.ticket || '').trim(); if (!/^\d{1,20}$/.test(ticket)) return { error: 'bad_ticket' };
        cmd = { id: rid('c'), action: 'close', ticket, symbol: '', volume: 0, sl: 0, tp: 0, comment: '' };
      } else {
        const r = cleanOrder(b); if (r.error) return r;
        cmd = { id: rid('c'), ...r.order };
      }
      cmd.at = Date.now(); cmd.status = 'queued';
      L.queue.push(cmd);
      log(L, { id: cmd.id, action: cmd.action, symbol: cmd.symbol || cmd.ticket, volume: cmd.volume, status: 'queued' });
      save();
      return { command: { id: cmd.id, status: cmd.status } };
    },
    // ── Expert Advisor (pairing token) ──
    hello(token, b) {
      const L = byToken(token); if (!L) return { error: 'bad_token' };
      if (cleanAccount(b?.account) !== L.account) { log(L, { action: 'hello', status: 'refused', message: `wrong account ${clip(b?.account, 20)}` }); save(); return { error: 'account_mismatch' }; }
      if (String(b?.server || '').trim().toLowerCase() !== L.server.toLowerCase()) { log(L, { action: 'hello', status: 'refused', message: `wrong server ${clip(b?.server, 64)}` }); save(); return { error: 'server_mismatch' }; }
      this.heartbeat(L, b);
      log(L, { action: 'hello', status: 'connected', message: `${clip(b.company, 40)} · build ${clip(b.build, 8)} · trading ${b.allowTrading ? 'on' : 'off'}` });
      save();
      return { ok: true, link: L.id };
    },
    heartbeat(L, b) {
      L.lastSeen = Date.now();
      const pos = Array.isArray(b?.positions) ? b.positions.slice(0, 50).map((p) => ({ ticket: clip(p.ticket, 20), symbol: clip(p.symbol, 24), type: p.type === 'sell' ? 'sell' : 'buy', volume: num(p.volume), price: num(p.price), sl: num(p.sl), tp: num(p.tp), profit: num(p.profit) })) : [];
      L.terminal = { company: clip(b?.company, 60), currency: clip(b?.currency, 8), balance: num(b?.balance), equity: num(b?.equity), margin: num(b?.margin), leverage: num(b?.leverage), allowTrading: Boolean(b?.allowTrading), maxLot: num(b?.maxLot), terminalTrade: Boolean(b?.terminalTrade), positions: pos, at: L.lastSeen };
    },
    poll(token, b) {
      const L = byToken(token); if (!L) return { error: 'bad_token' };
      if (cleanAccount(b?.account) !== L.account) return { error: 'account_mismatch' };
      this.heartbeat(L, b); expire(L);
      const out = L.queue.filter((c) => c.status === 'queued');
      for (const c of out) c.status = 'sent';
      if (out.length) save();
      return { commands: out };
    },
    ack(token, b) {
      const L = byToken(token); if (!L) return { error: 'bad_token' };
      const c = L.queue.find((x) => x.id === String(b?.id || ''));
      if (!c) return { error: 'not_found' };
      c.status = b.ok ? 'done' : 'failed';
      log(L, { id: c.id, action: c.action, symbol: c.symbol || c.ticket, volume: c.volume, status: c.status, ticket: clip(b.ticket, 20), price: num(b.price), retcode: num(b.retcode), message: clip(b.message, 160) });
      L.queue = L.queue.filter((x) => x !== c);
      save();
      return { ok: true };
    },
  };
}

/** The EA's line format (easy and safe to parse in MQL5): id|action|symbol|volume|sl|tp|ticket|comment, one per line. */
export function commandLines(cmds) {
  return cmds.map((c) => [c.id, c.action, c.symbol || '', c.volume || 0, c.sl || 0, c.tp || 0, c.ticket || '', String(c.comment || '').replace(/\|/g, ' ')].join('|')).join('\n');
}
