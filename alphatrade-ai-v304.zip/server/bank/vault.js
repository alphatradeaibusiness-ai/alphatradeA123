// Field-level envelope encryption for personal data (KYC, addresses, IBANs, crypto addresses, card delivery).
// Every record gets its own random data key (DEK); the DEK is wrapped by a master key derived from BANK_MASTER_KEY
// (separate from AI_KEY_SECRET). Both layers are AES-256-GCM and bound to an "aad" string (user + field), so a blob copied
// to another user or field fails to decrypt. A key id is stored with the blob, so the master key can be rotated:
// set BANK_MASTER_KEY to the new value and BANK_MASTER_KEY_PREV to the old one, then call rewrap() on stored blobs.
import crypto from 'node:crypto';

const SALT = 'alphatrade-bank-vault-v1';
const derive = (secret, purpose) => crypto.hkdfSync('sha256', crypto.scryptSync(String(secret), SALT, 32), SALT, purpose, 32);
const kidOf = (key) => crypto.createHash('sha256').update(Buffer.from(key)).digest('hex').slice(0, 8);

export function createVault({ secret, previous = [] } = {}) {
  const ok = (s) => typeof s === 'string' && s.length >= 32;
  if (!ok(secret)) return { available: false };
  const mk = (s) => { const key = Buffer.from(derive(s, 'wrap')); return { key, kid: kidOf(key), blind: Buffer.from(derive(s, 'blind')) }; };
  const macKeys = new Map();
  const cur = mk(secret); const olds = previous.filter(ok).map(mk);
  const byKid = new Map([cur, ...olds].map((k) => [k.kid, k]));
  const b = (x) => Buffer.from(x).toString('base64');
  const gcm = (key, plain, aad) => {
    const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from(aad));
    const ct = Buffer.concat([c.update(plain), c.final()]); return [b(iv), b(c.getAuthTag()), b(ct)].join('.');
  };
  const ungcm = (key, s, aad) => {
    const [iv, tag, ct] = s.split('.').map((x) => Buffer.from(x, 'base64'));
    const d = crypto.createDecipheriv('aes-256-gcm', key, iv); d.setAAD(Buffer.from(aad)); d.setAuthTag(tag);
    return Buffer.concat([d.update(ct), d.final()]);
  };
  return {
    available: true,
    kid: cur.kid,
    /** value (any JSON) → opaque string. aad e.g. `kyc:${uid}`. */
    seal(value, aad) {
      const dek = crypto.randomBytes(32);
      return ['v1', cur.kid, gcm(cur.key, dek, aad), gcm(dek, Buffer.from(JSON.stringify(value)), aad)].join('~');
    },
    open(blob, aad) {
      const [v, kid, wrapped, data] = String(blob).split('~');
      const k = byKid.get(kid);
      if (v !== 'v1' || !k || !wrapped || !data) throw new Error('vault:bad-blob');
      return JSON.parse(ungcm(ungcmKey(k, wrapped, aad), data, aad).toString('utf8'));
    },
    /** Re-wraps the data key under the current master key (no need to touch the data). */
    rewrap(blob, aad) {
      const [v, kid, wrapped, data] = String(blob).split('~');
      const k = byKid.get(kid); if (v !== 'v1' || !k) throw new Error('vault:bad-blob');
      if (kid === cur.kid) return blob;
      return ['v1', cur.kid, gcm(cur.key, ungcmKey(k, wrapped, aad), aad), data].join('~');
    },
    /** Keyed HMAC for derived values that must never be stored (e.g. a card's CVV). `purpose` separates the keys. */
    mac(purpose, value) { if (!macKeys.has(purpose)) macKeys.set(purpose, Buffer.from(derive(secret, `mac:${purpose}`))); return crypto.createHmac('sha256', macKeys.get(purpose)).update(String(value)).digest(); },
    /** Deterministic HMAC for lookups ("is this IBAN already used?") without storing the value. */
    blind(value) { return crypto.createHmac('sha256', cur.blind).update(String(value).trim().toLowerCase().replace(/\s+/g, '')).digest('hex'); },
  };
  function ungcmKey(k, wrapped, aad) { return ungcm(k.key, wrapped, aad); }
}
