// Passkeys (step-up by fingerprint / face), M-of-N co-signing ("multi-signature" at the application level) and the
// freeze-everything switch. Passkey challenges are BOUND to the exact action (amount, destination...): a signature made to
// approve one withdrawal cannot be replayed for another.
import crypto from 'node:crypto';
import { bad, str, oneOf } from '../validate.js';
import { CURRENCIES, toMinor } from '../money.js';
import { verifyRegistration, verifyAssertion, WebAuthnError, b64u } from '../webauthn.js';

const DAY = 86400_000;
export const PASSKEY_PURPOSES = ['withdraw', 'beneficiary_add', 'beneficiary_remove', 'vault_release', 'intl_transfer', 'approval_vote', 'passkey_add', 'passkey_remove',
  'card_reveal', 'vcard_create', 'card_limits', 'policy_set', 'unfreeze', 'approver_remove', 'redeem', 'ob_link'];
/** Canonical, order-independent fingerprint of what is being authorised. */
export function bindingOf(purpose, params = {}) {
  const keys = Object.keys(params || {}).filter((k) => params[k] != null && params[k] !== '').sort();
  const canon = keys.map((k) => [k, typeof params[k] === 'object' ? JSON.stringify(params[k]) : String(params[k])]);
  return crypto.createHash('sha256').update(JSON.stringify([purpose, canon])).digest('hex');
}

export function createSecurity(ctx) {
  const { db, A, now, rid, commit, cfg } = ctx;
  const wa = (fn) => { try { return fn(); } catch (e) { if (e instanceof WebAuthnError) bad(`passkey_${e.code}`, 401); throw e; } };

  /* ── passkeys ── */
  const count = (uid) => db.prepare('SELECT COUNT(*) c FROM passkeys WHERE uid = ?').get(uid).c;
  const list = (uid) => db.prepare('SELECT id, name, created_at, last_used FROM passkeys WHERE uid = ? ORDER BY created_at').all(uid)
    .map((p) => ({ id: p.id, name: p.name, createdAt: p.created_at, lastUsed: p.last_used }));
  function newChallenge(uid, purpose, binding) {
    const id = rid('wch'); const challenge = b64u(crypto.randomBytes(32));
    db.prepare('DELETE FROM webauthn_challenges WHERE expires_at < ? OR (uid = ? AND used = 1)').run(now(), uid);
    if (db.prepare('SELECT COUNT(*) c FROM webauthn_challenges WHERE uid = ?').get(uid).c >= 20) bad('too_many_challenges', 429);
    db.prepare('INSERT INTO webauthn_challenges (id, uid, challenge, purpose, binding, expires_at) VALUES (?,?,?,?,?,?)').run(id, uid, challenge, purpose, binding, now() + 2 * 60_000);
    return { id, challenge };
  }
  function takeChallenge(uid, id, purpose, binding) {
    const c = db.prepare('SELECT * FROM webauthn_challenges WHERE id = ? AND uid = ?').get(String(id || ''), uid);
    if (!c || c.used || c.expires_at < now()) bad('passkey_challenge_expired', 401);
    if (c.purpose !== purpose || c.binding !== binding) bad('passkey_binding_mismatch', 401);
    const r = db.prepare('UPDATE webauthn_challenges SET used = 1 WHERE id = ? AND used = 0').run(c.id);
    if (!r.changes) bad('passkey_challenge_expired', 401);
    return c;
  }
  function registrationOptions(uid, { email, rpId, rpName = 'AlphaTrade AI' }) {
    if (count(uid) >= 10) bad('too_many_passkeys', 429);
    const { id, challenge } = newChallenge(uid, 'passkey_register', '');
    return {
      challengeId: id,
      publicKey: {
        challenge, rp: { id: rpId, name: rpName }, timeout: 120000, attestation: 'none',
        user: { id: b64u(crypto.createHash('sha256').update(`bank-user:${uid}`).digest().subarray(0, 32)), name: String(email || 'user').slice(0, 64), displayName: String(email || 'AlphaTrade').slice(0, 64) },
        pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
        authenticatorSelection: { userVerification: 'required', residentKey: 'preferred' },
        excludeCredentials: db.prepare('SELECT id FROM passkeys WHERE uid = ?').all(uid).map((p) => ({ type: 'public-key', id: p.id })),
      },
    };
  }
  /** First passkey: the HTTP layer requires a fresh sign-in. Any further passkey: an assertion by an existing one ("passkey_add"). */
  function register(uid, i, { origins, rpId }) {
    const name = str(i.name ?? 'Passkey', { max: 40, code: 'bad_name' });
    const c = takeChallenge(uid, i.challengeId, 'passkey_register', '');   // single use, even when verification fails
    const v = wa(() => verifyRegistration(i.credential, { challenge: c.challenge, origins, rpId }));
    const out = commit(() => {
      if (db.prepare('SELECT 1 FROM passkeys WHERE id = ?').get(v.id)) bad('passkey_exists', 409);
      db.prepare('INSERT INTO passkeys (id, uid, jwk, alg, sign_count, name, created_at) VALUES (?,?,?,?,?,?,?)').run(v.id, uid, JSON.stringify(v.jwk), v.alg, v.signCount, name, now());
      A.log(uid, 'passkey.add', v.id.slice(0, 16), { alg: v.alg });
      return { ok: true, first: count(uid) === 1 };
    });
    ctx.notify(uid, 'passkey_added'); ctx.emit('passkey.added', { uid, first: out.first });
    return { ok: true, passkeys: list(uid) };
  }
  function assertionOptions(uid, purpose, params, { rpId }) {
    oneOf(purpose, PASSKEY_PURPOSES, 'bad_purpose');
    const creds = db.prepare('SELECT id FROM passkeys WHERE uid = ?').all(uid); if (!creds.length) bad('no_passkey', 409);
    const { id, challenge } = newChallenge(uid, purpose, bindingOf(purpose, params));
    return { challengeId: id, publicKey: { challenge, rpId, timeout: 60000, userVerification: 'required', allowCredentials: creds.map((p) => ({ type: 'public-key', id: p.id })) } };
  }
  /**
   * Gate for sensitive actions. Users with no passkey: returns { used:false } (the HTTP layer then applies the sign-in step-up).
   * Users with a passkey: a valid assertion over a challenge bound to exactly these params is REQUIRED.
   */
  function verifyStep(uid, purpose, params, pk, { origins, rpId }) {
    if (!count(uid)) return { used: false };
    if (!pk || typeof pk !== 'object') bad('passkey_required', 401);
    const binding = bindingOf(purpose, params);
    const c = takeChallenge(uid, pk.challengeId, purpose, binding);   // single use, even when verification fails
    const stored = db.prepare('SELECT * FROM passkeys WHERE id = ? AND uid = ?').get(String(pk.id || ''), uid) ?? bad('passkey_unknown', 401);
    const r = wa(() => verifyAssertion(pk, { jwk: JSON.parse(stored.jwk), alg: stored.alg, signCount: stored.sign_count }, { challenge: c.challenge, origins, rpId }));
    return commit(() => {
      db.prepare('UPDATE passkeys SET sign_count = ?, last_used = ? WHERE id = ?').run(r.signCount, now(), stored.id);
      A.log(uid, 'passkey.use', purpose, {});
      return { used: true };
    });
  }
  function removePasskey(uid, id) {
    commit(() => {
      const r = db.prepare('DELETE FROM passkeys WHERE id = ? AND uid = ?').run(String(id || ''), uid);
      if (!r.changes) bad('not_found', 404);
      A.log(uid, 'passkey.remove', String(id).slice(0, 16), {});
    });
    ctx.notify(uid, 'passkey_removed');
    return { ok: true, passkeys: list(uid) };
  }

  /* ── freeze ── */
  const isFrozen = (uid) => Boolean(db.prepare('SELECT frozen FROM user_flags WHERE uid = ?').get(uid)?.frozen);
  const assertNotFrozen = (uid) => { if (isFrozen(uid)) bad('account_frozen', 423); };
  function setFrozen(uid, on) {
    commit(() => {
      db.prepare('INSERT INTO user_flags (uid, frozen, frozen_at) VALUES (?,?,?) ON CONFLICT(uid) DO UPDATE SET frozen = excluded.frozen, frozen_at = excluded.frozen_at').run(uid, on ? 1 : 0, on ? now() : null);
      if (on) db.prepare("UPDATE vcards SET status = 'frozen', updated_at = ? WHERE uid = ? AND status = 'active'").run(now(), uid);
      A.log(uid, on ? 'account.freeze' : 'account.unfreeze', uid, {});
    }, uid);
    ctx.notify(uid, on ? 'frozen' : 'unfrozen');
    return { frozen: on };
  }

  /* ── co-signers (M of N) ── */
  function policy(uid) {
    let p = null; try { p = JSON.parse(db.prepare('SELECT policy FROM user_flags WHERE uid = ?').get(uid)?.policy || 'null'); } catch { p = null; }
    const n = db.prepare('SELECT COUNT(*) c FROM approvers WHERE owner_uid = ?').get(uid).c;
    return { enabled: Boolean(p?.enabled && n > 0), needed: Math.min(p?.needed || 1, Math.max(n, 1)), threshold: p?.threshold || {}, approvers: n };
  }
  function setPolicy(uid, i) {
    const n = db.prepare('SELECT COUNT(*) c FROM approvers WHERE owner_uid = ?').get(uid).c;
    const enabled = i.enabled === true;
    if (enabled && n === 0) bad('no_approvers', 409);
    const needed = enabled ? Number(i.needed) : 1;
    if (enabled && (!Number.isInteger(needed) || needed < 1 || needed > n)) bad('bad_needed');
    const threshold = {};
    for (const c of Object.keys(CURRENCIES)) if (i.threshold?.[c] != null && i.threshold[c] !== '') threshold[c] = toMinor(i.threshold[c], c) ?? bad('bad_amount');
    if (enabled && !Object.keys(threshold).length) bad('threshold_required');
    commit(() => {
      db.prepare('INSERT INTO user_flags (uid, policy) VALUES (?,?) ON CONFLICT(uid) DO UPDATE SET policy = excluded.policy').run(uid, JSON.stringify({ enabled, needed, threshold }));
      A.log(uid, 'policy.set', uid, { enabled, needed });
    });
    ctx.notify(uid, 'policy_changed');
    return policy(uid);
  }
  const needsApproval = (uid, currency, amount) => { const p = policy(uid); return p.enabled && p.threshold[currency] != null && amount >= p.threshold[currency] ? p.needed : 0; };
  function invite(uid, label) {
    const l = str(label ?? 'Co-signer', { max: 30, code: 'bad_label' });
    if (db.prepare('SELECT COUNT(*) c FROM approver_invites WHERE owner_uid = ? AND used = 0 AND expires_at > ?').get(uid, now()).c >= 5) bad('too_many_invites', 429);
    const code = Array.from(crypto.randomBytes(10), (b) => 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'[b % 31]).join('');
    commit(() => { db.prepare('INSERT INTO approver_invites (code_hash, owner_uid, label, expires_at) VALUES (?,?,?,?)').run(hashCode(code), uid, l, now() + 2 * DAY); A.log(uid, 'approver.invite', '', {}); });
    return { code, expiresAt: now() + 2 * DAY };
  }
  const hashCode = (c) => crypto.createHash('sha256').update(`approver:${String(c).toUpperCase().replace(/[^A-Z0-9]/g, '')}`).digest('hex');
  function acceptInvite(uid, code) {
    let owner;
    commit(() => {
      const inv = db.prepare('SELECT * FROM approver_invites WHERE code_hash = ?').get(hashCode(code));
      if (!inv || inv.used || inv.expires_at < now()) bad('invite_invalid', 404);
      if (inv.owner_uid === uid) bad('self_action_not_allowed', 403);
      if (ctx.tier(uid) < 1) bad('kyc_required', 403);
      if (db.prepare('SELECT COUNT(*) c FROM approvers WHERE owner_uid = ?').get(inv.owner_uid).c >= 5) bad('too_many_approvers', 429);
      db.prepare('UPDATE approver_invites SET used = 1 WHERE code_hash = ?').run(inv.code_hash);
      db.prepare('INSERT OR IGNORE INTO approvers (owner_uid, approver_uid, label, created_at) VALUES (?,?,?,?)').run(inv.owner_uid, uid, inv.label, now());
      A.log(uid, 'approver.accept', inv.owner_uid, {}); owner = inv.owner_uid;
    });
    ctx.notify(owner, 'approver_added');
    return { ok: true };
  }
  function removeApprover(uid, approverRef) {
    commit(() => {
      const rows = db.prepare('SELECT approver_uid FROM approvers WHERE owner_uid = ?').all(uid);
      const hit = rows.find((r) => short(r.approver_uid) === approverRef) ?? bad('not_found', 404);
      db.prepare('DELETE FROM approvers WHERE owner_uid = ? AND approver_uid = ?').run(uid, hit.approver_uid);
      const p = policy(uid); if (p.approvers === 0 || p.needed > p.approvers) db.prepare("UPDATE user_flags SET policy = json_set(COALESCE(policy,'{}'), '$.enabled', json('false')) WHERE uid = ?").run(uid);
      A.log(uid, 'approver.remove', '', {});
    });
    ctx.notify(uid, 'policy_changed');
    return { ok: true };
  }
  const short = (u) => crypto.createHash('sha256').update(String(u)).digest('hex').slice(0, 10);   // never expose another user's id
  function approvers(uid) {
    return {
      signers: db.prepare('SELECT approver_uid, label, created_at FROM approvers WHERE owner_uid = ?').all(uid).map((r) => ({ ref: short(r.approver_uid), label: r.label, since: r.created_at })),
      iApproveFor: db.prepare('SELECT owner_uid, label, created_at FROM approvers WHERE approver_uid = ?').all(uid).map((r) => ({ ref: short(r.owner_uid), label: r.label, since: r.created_at })),
      policy: policy(uid),
    };
  }
  /** Inside the caller's transaction. */
  function openApproval(ownerUid, kind, targetId, currency, amount, needed) {
    const id = rid('apr'); const t = now();
    db.prepare('INSERT INTO approvals (id, owner_uid, kind, target_id, currency, amount, needed, status, expires_at, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
      .run(id, ownerUid, kind, targetId, currency, amount, needed, 'pending', t + cfg.approvalTtl, t, t);
    A.log(ownerUid, 'approval.open', id, { kind, needed });
    return id;
  }
  const approverUids = (ownerUid) => db.prepare('SELECT approver_uid FROM approvers WHERE owner_uid = ?').all(ownerUid).map((r) => r.approver_uid);
  const apView = (a) => ({ id: a.id, kind: a.kind, currency: a.currency, amount: a.amount, needed: a.needed, status: a.status, expiresAt: a.expires_at, createdAt: a.created_at,
    approvals: db.prepare("SELECT COUNT(*) c FROM approval_votes WHERE approval_id = ? AND decision = 'approve'").get(a.id).c });
  function pendingForMe(uid) {
    return db.prepare(`SELECT a.*, ap.label FROM approvals a JOIN approvers ap ON ap.owner_uid = a.owner_uid AND ap.approver_uid = ?
      WHERE a.status = 'pending' AND a.expires_at > ? AND NOT EXISTS (SELECT 1 FROM approval_votes v WHERE v.approval_id = a.id AND v.approver_uid = ?) ORDER BY a.created_at`).all(uid, now(), uid)
      .map((a) => ({ ...apView(a), from: a.label }));
  }
  const myApprovals = (uid) => db.prepare('SELECT * FROM approvals WHERE owner_uid = ? ORDER BY created_at DESC LIMIT 30').all(uid).map(apView);
  function vote(uid, id, decision, usedPasskey) {
    oneOf(decision, ['approve', 'reject'], 'bad_decision');
    let result = null; let owner;
    commit(() => {
      const a = db.prepare('SELECT * FROM approvals WHERE id = ?').get(String(id || '')) ?? bad('not_found', 404);
      owner = a.owner_uid;
      if (!db.prepare('SELECT 1 FROM approvers WHERE owner_uid = ? AND approver_uid = ?').get(a.owner_uid, uid)) bad('not_an_approver', 403);
      if (a.status !== 'pending' || a.expires_at < now()) bad('bad_state', 409);
      if (db.prepare('SELECT 1 FROM approval_votes WHERE approval_id = ? AND approver_uid = ?').get(a.id, uid)) bad('already_voted', 409);
      db.prepare('INSERT INTO approval_votes (approval_id, approver_uid, decision, passkey, at) VALUES (?,?,?,?,?)').run(a.id, uid, decision, usedPasskey ? 1 : 0, now());
      A.log(uid, `approval.${decision}`, a.id, { passkey: Boolean(usedPasskey) });
      const yes = db.prepare("SELECT COUNT(*) c FROM approval_votes WHERE approval_id = ? AND decision = 'approve'").get(a.id).c;
      if (decision === 'reject') result = 'rejected'; else if (yes >= a.needed) result = 'approved';
      if (result) {
        db.prepare('UPDATE approvals SET status = ?, updated_at = ? WHERE id = ?').run(result, now(), a.id);
        ctx.approvalTargets[a.kind][result === 'approved' ? 'approved' : 'rejected'](a);
      }
    });
    if (result) { ctx.notify(owner, 'approval_result', { result }); ctx.ping(owner); }
    return { ok: true, result };
  }
  function expireApprovals() {
    const due = db.prepare("SELECT * FROM approvals WHERE status = 'pending' AND expires_at < ?").all(now());
    for (const a of due) {
      commit(() => {
        const cur = db.prepare("SELECT * FROM approvals WHERE id = ? AND status = 'pending'").get(a.id); if (!cur) return;
        db.prepare("UPDATE approvals SET status = 'expired', updated_at = ? WHERE id = ?").run(now(), a.id);
        ctx.approvalTargets[a.kind].rejected(cur); A.log('system', 'approval.expire', a.id, {});
      }, a.owner_uid);
      ctx.notify(a.owner_uid, 'approval_result', { result: 'expired' });
    }
  }
  /** Inside the caller's transaction: cancels the approval of a target the owner cancelled. */
  const cancelApprovalFor = (kind, targetId) => db.prepare("UPDATE approvals SET status = 'cancelled', updated_at = ? WHERE kind = ? AND target_id = ? AND status = 'pending'").run(now(), kind, targetId);

  return {
    passkeys: { count, list, registrationOptions, register, assertionOptions, verifyStep, remove: removePasskey },
    isFrozen, assertNotFrozen, setFrozen,
    policy, setPolicy, needsApproval, invite, acceptInvite, removeApprover, approvers, openApproval, approverUids, pendingForMe, myApprovals, vote, expireApprovals, cancelApprovalFor,
  };
}
