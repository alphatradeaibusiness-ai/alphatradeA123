// Loyalty points. Points are a separate ledger unit (PTS) — never money, never shown as a balance — earned for card spending
// and for securing the account (identity check, first passkey). There are NO points for trading volume, on purpose: a reward
// must not push anyone to take more risk. Points expire 12 months after they were earned (oldest first) and can be turned
// into cashback (1,000 points = 5 USD), paid from the platform's rewards account. In live mode cashback stays off until the
// owner funds that account and sets BANK_REWARDS_CASHBACK=1.
import { bad } from '../validate.js';

const DAY = 86400_000;

export function createRewards(ctx) {
  const { db, L, A, now, rid, commit, cfg } = ctx;
  const balance = (uid) => L.account(uid, 'PTS', 'points').balance;

  /** Inside the caller's commit. Duplicate (uid, reason, ref) = ignored, so an event can never pay twice. */
  function earnRaw(uid, pts, reason, ref) {
    if (!(pts > 0)) return 0;
    const r = db.prepare('INSERT OR IGNORE INTO points_lots (id, uid, amount, remaining, reason, ref, earned_at) VALUES (?,?,?,?,?,?,?)').run(rid('lot'), uid, pts, pts, reason, String(ref), now());
    if (!r.changes) return 0;
    L.post({ type: 'points_earn', uid, currency: 'PTS', amount: pts, meta: { reason, ref: String(ref).slice(0, 40) },
      legs: [{ acc: L.sys('rewards', 'PTS'), delta: -pts }, { acc: L.account(uid, 'PTS', 'points'), delta: pts }] });
    A.log('system', 'points.earn', uid, { pts, reason });
    return pts;
  }
  function earn(uid, pts, reason, ref) {
    let got = 0; try { got = commit(() => earnRaw(uid, pts, reason, ref)); } catch { got = 0; }
    if (got && reason !== 'card') ctx.notify(uid, 'points_earned', { pts: got });   // card points show on the Rewards tab, not one alert per purchase
    return got;
  }
  /** Takes up to `pts` from the oldest lots (inside commit). Returns how many were taken. */
  function consume(uid, pts) {
    let left = pts;
    for (const l of db.prepare('SELECT * FROM points_lots WHERE uid = ? AND remaining > 0 ORDER BY earned_at, id').all(uid)) {
      if (!left) break;
      const take = Math.min(left, l.remaining);
      db.prepare('UPDATE points_lots SET remaining = remaining - ? WHERE id = ?').run(take, l.id); left -= take;
    }
    return pts - left;
  }
  function clawback(uid, reason, ref) {
    try {
      commit(() => {
        const lot = db.prepare('SELECT * FROM points_lots WHERE uid = ? AND reason = ? AND ref = ?').get(uid, reason, String(ref)); if (!lot) return;
        const take = Math.min(lot.amount, balance(uid)); if (!take) return;
        consume(uid, take);
        L.post({ type: 'points_clawback', uid, currency: 'PTS', amount: take, idem: `pcb:${lot.id}`, meta: { reason },
          legs: [{ acc: L.account(uid, 'PTS', 'points'), delta: -take }, { acc: L.sys('rewards', 'PTS'), delta: take }] });
        A.log('system', 'points.clawback', uid, { take });
      });
    } catch { /* */ }
  }
  ctx.on('card.settled', ({ uid, auth }) => earn(uid, Math.floor((auth.amount / 100) * cfg.rewards.perUsd), 'card', auth.id));
  ctx.on('card.refunded', ({ uid, auth }) => clawback(uid, 'card', auth.id));
  ctx.on('kyc.approved', ({ uid, tier }) => earn(uid, tier === 2 ? cfg.rewards.kyc2 : cfg.rewards.kyc1, 'kyc', tier));
  ctx.on('passkey.added', ({ uid, first }) => { if (first) earn(uid, cfg.rewards.passkey, 'passkey', 'first'); });

  function summary(uid) {
    const t = now();
    const expiring = db.prepare('SELECT COALESCE(SUM(remaining),0) s FROM points_lots WHERE uid = ? AND remaining > 0 AND earned_at < ?').get(uid, t - (cfg.rewards.ttl - 30 * DAY)).s;
    return {
      points: balance(uid), expiringIn30Days: expiring, rate: { points: cfg.rewards.redeemUnit, usd: cfg.rewards.redeemUsd / 100 },
      cashbackAvailable: ctx.sandbox || cfg.rewards.cashbackLive,
      earnRules: { perUsd: cfg.rewards.perUsd, kyc1: cfg.rewards.kyc1, kyc2: cfg.rewards.kyc2, passkey: cfg.rewards.passkey },
      history: db.prepare("SELECT type, amount, meta, created_at FROM txns WHERE uid = ? AND currency = 'PTS' ORDER BY created_at DESC LIMIT 30").all(uid).map((r) => ({ type: r.type, amount: r.amount, reason: JSON.parse(r.meta || '{}').reason || null, at: r.created_at })),
    };
  }
  function redeem(uid, i) {
    if (!(ctx.sandbox || cfg.rewards.cashbackLive)) bad('cashback_not_available', 403);
    const pts = Number(i.points);
    if (!Number.isInteger(pts) || pts < cfg.rewards.redeemUnit || pts % cfg.rewards.redeemUnit) bad('bad_points');
    const usd = (pts / cfg.rewards.redeemUnit) * cfg.rewards.redeemUsd;
    const out = commit(() => {
      if (balance(uid) < pts) bad('insufficient_points', 409);
      consume(uid, pts);
      L.post({ type: 'points_redeem', uid, currency: 'PTS', amount: pts, meta: { usd },
        legs: [{ acc: L.account(uid, 'PTS', 'points'), delta: -pts }, { acc: L.sys('rewards', 'PTS'), delta: pts }] });
      const tx = L.post({ type: 'cashback', uid, currency: 'USD', amount: usd, meta: { points: pts },
        legs: [{ acc: L.sys('rewards', 'USD'), delta: -usd }, { acc: L.account(uid, 'USD', 'wallet'), delta: usd }] });
      A.log(uid, 'points.redeem', tx.id, { pts, usd });
      return { ok: true, usd, points: balance(uid) };
    }, uid);
    ctx.notify(uid, 'points_redeemed', { pts });
    return out;
  }
  function runExpiry() {
    const t = now();
    for (const u of db.prepare('SELECT DISTINCT uid FROM points_lots WHERE remaining > 0 AND earned_at < ?').all(t - cfg.rewards.ttl)) {
      try {
        commit(() => {
          const old = db.prepare('SELECT * FROM points_lots WHERE uid = ? AND remaining > 0 AND earned_at < ?').all(u.uid, t - cfg.rewards.ttl);
          const pts = Math.min(old.reduce((s, l) => s + l.remaining, 0), balance(u.uid)); if (!pts) return;
          for (const l of old) db.prepare('UPDATE points_lots SET remaining = 0 WHERE id = ?').run(l.id);
          L.post({ type: 'points_expire', uid: u.uid, currency: 'PTS', amount: pts, meta: {},
            legs: [{ acc: L.account(u.uid, 'PTS', 'points'), delta: -pts }, { acc: L.sys('rewards', 'PTS'), delta: pts }] });
          A.log('system', 'points.expire', u.uid, { pts });
        });
      } catch { /* */ }
    }
    // one warning per user per week for points that expire within the next 7 days
    const week = Math.floor(t / (7 * DAY));
    for (const u of db.prepare("SELECT uid, SUM(remaining) s FROM points_lots WHERE remaining > 0 AND earned_at BETWEEN ? AND ? GROUP BY uid").all(t - cfg.rewards.ttl, t - cfg.rewards.ttl + 7 * DAY)) {
      const r = db.prepare('INSERT OR IGNORE INTO meta (k, v) VALUES (?, ?)').run(`pexp:${u.uid}:${week}`, '1');
      if (r.changes) ctx.notify(u.uid, 'points_expiring', { pts: u.s });
    }
  }
  return { balance, summary, redeem, earn, runExpiry };
}
