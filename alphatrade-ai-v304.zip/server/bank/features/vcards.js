// Virtual Visa cards. A REAL card number is created and held by the card issuer (processor + sponsor bank under a Visa programme):
// no number we invent can be used at a shop. We keep the issuer's card reference, the last 4 digits and the controls, and we DECIDE
// every purchase: the issuer asks (signed webhook) and gets approve/decline within its time limit.
// In sandbox mode a built-in "sandbox issuer" stands in. It makes a unique 16-digit TEST number (Luhn-valid, reserved test BIN 400000,
// not chargeable anywhere) per card. The number is stored only envelope-encrypted (vault.js, AAD bound to the card) with a blind hash
// that keeps every number unique. The 3-digit CVV is never stored: it is derived on demand with a keyed HMAC of the number and expiry
// (how real issuers compute CVV2). 1,000 CVV values exist, so a CVV is unique per card number, not across all cards.
// Details are shown only after step-up (passkey/MFA), rate-limited, audit-logged and answered with no-store.
// Also here: merchant blocks and subscription detection (both read card purchases).
import crypto from 'node:crypto';
import { bad, str, oneOf } from '../validate.js';
import { toMinor } from '../money.js';
import { CATEGORIES } from './pockets.js';

const DAY = 86400_000;
export const merchantKey = (m) => String(m || '').toLowerCase().normalize('NFKD').replace(/[^\p{L}\p{N}]+/gu, '').replace(/\d{3,}$/, '').slice(0, 40) || 'unknown';
const monthStart = (t) => { const d = new Date(t); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1); };

const luhnDigit = (body) => { let sum = 0; for (let i = 0; i < body.length; i++) { let d = Number(body[body.length - 1 - i]); if (i % 2 === 0) { d *= 2; if (d > 9) d -= 9; } sum += d; } return String((10 - (sum % 10)) % 10); };
/** A unique-looking 16-digit TEST number: reserved test BIN 400000 + 9 random digits + Luhn check digit. */
export function testPan() { let b = '400000'; for (let i = 0; i < 9; i++) b += String(crypto.randomInt(10)); return b + luhnDigit(b); }
export const luhnOk = (pan) => /^\d{13,19}$/.test(pan) && luhnDigit(pan.slice(0, -1)) === pan.slice(-1);
export const ART_COLORS = ['alpha', 'graphite', 'sand', 'sage', 'slate', 'plum', 'dusk'];
export const ART_PATTERNS = ['tree', 'lines', 'dots', 'waves', 'grid', 'plain'];
const clean = (s) => String(s || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/[^\p{L} ]/gu, ' ').replace(/\s+/g, ' ').trim();

/** Built-in sandbox issuer. A real adapter implements the same calls against the provider's API (it never hands us a number to keep). */
export const sandboxIssuer = {
  name: 'sandbox',
  create() { return { pan: testPan(), ref: `sbx_${crypto.randomBytes(9).toString('base64url')}`, last4: 'TEST', exp: (() => { const d = new Date(Date.now() + 3 * 365 * DAY); return `${String(d.getUTCMonth() + 1).padStart(2, '0')}/${String(d.getUTCFullYear()).slice(2)}`; })() }; },
  reveal() { return { sandbox: true }; },   // a real issuer returns a short-lived token for its own secure iframe
  setStatus() { return true; },
};

export function createVcards(ctx) {
  const { db, L, A, now, rid, commit, cfg, sandbox, vault } = ctx;
  const DAY_REVEALS = 10; const FAIL_LIMIT = 5;
  const usd = (n) => toMinor(String(n), 'USD');

  const view = (c) => ({ id: c.id, label: c.label, art: c.art || 'graphite:lines', holder: c.holder || null, hasDetails: Boolean(c.pan_enc), kind: c.kind, last4: c.last4, exp: c.exp, status: c.status, merchantLock: c.merchant_lock, pocketId: c.pocket_id,
    limits: { tx: c.limit_tx, day: c.limit_day, month: c.limit_month }, issuer: c.issuer, createdAt: c.created_at,
    spent: { day: spentSince(c.id, now() - DAY), month: spentSince(c.id, monthStart(now())) } });
  const spentSince = (cardId, t) => db.prepare("SELECT COALESCE(SUM(amount),0) s FROM card_auths WHERE card_id = ? AND status IN ('approved','settled') AND created_at >= ?").get(cardId, t).s;
  const list = (uid) => db.prepare("SELECT * FROM vcards WHERE uid = ? AND status != 'closed' ORDER BY created_at DESC").all(uid).map(view);
  const get = (uid, id) => db.prepare("SELECT * FROM vcards WHERE id = ? AND uid = ? AND status != 'closed'").get(String(id || ''), uid) ?? bad('card_not_found', 404);
  const limitsFrom = (i, cur = {}) => {
    const tx = i.limitTx != null && i.limitTx !== '' ? usd(i.limitTx) ?? bad('bad_amount') : cur.limit_tx ?? cfg.vcard.tx;
    const day = i.limitDay != null && i.limitDay !== '' ? usd(i.limitDay) ?? bad('bad_amount') : cur.limit_day ?? cfg.vcard.day;
    const month = i.limitMonth != null && i.limitMonth !== '' ? usd(i.limitMonth) ?? bad('bad_amount') : cur.limit_month ?? cfg.vcard.month;
    if (tx > cfg.vcard.maxTx || day > cfg.vcard.maxDay || month > cfg.vcard.maxMonth || tx > day || day > month) bad('bad_limits');
    return { tx, day, month };
  };

  const artOf = (v, cur = 'alpha:tree') => {
    if (v == null || v === '') return cur;
    const [c, p] = String(v).split(':'); if (!ART_COLORS.includes(c) || !ART_PATTERNS.includes(p)) bad('bad_art'); return `${c}:${p}`;
  };
  /** The card request form is checked against the KYC the owner approved: name on card and date of birth must match. Generic error, counted, locked after 5 misses/hour. */
  function verifyHolder(uid, i) {
    const fails = db.prepare("SELECT COUNT(*) c FROM audit WHERE actor = ? AND action = 'vcard.verify_fail' AND ts > ?").get(uid, now() - 3600_000).c;
    if (fails >= FAIL_LIMIT) bad('too_many_attempts', 429);
    const k = db.prepare('SELECT data FROM kyc WHERE uid = ?').get(uid);
    let kyc = null; try { kyc = k?.data ? ctx.open(k.data, `kyc:${uid}`) : null; } catch { kyc = null; }
    const holder = clean(str(String(i.holder ?? ''), { min: 3, max: 26, code: 'bad_holder' }));
    const dob = String(i.dob ?? '').trim();
    const have = clean(kyc?.fullName).split(' ').filter(Boolean); const want = holder.split(' ').filter(Boolean);
    const nameOk = Boolean(kyc) && want.length >= 2 && want.every((w) => have.includes(w)) && want[0] === have[0] && want.at(-1) === have.at(-1);
    if (!nameOk || !kyc || dob !== kyc.dob) { db.tx(() => A.log(uid, 'vcard.verify_fail', uid, {})); bad('verification_failed', 403); }
    return holder;
  }
  function create(uid, i) {
    if (!ctx.issuer) bad('no_card_issuer', 503);
    ctx.needTier(uid, 2); ctx.security.assertNotFrozen(uid);
    const label = str(i.label ?? 'Virtual card', { max: 30, code: 'bad_label' });
    const kind = oneOf(i.kind ?? 'standard', ['standard', 'single_use', 'merchant_locked'], 'bad_kind');
    const lock = kind === 'merchant_locked' ? merchantKey(str(i.merchant, { max: 40, code: 'bad_merchant' })) : null;
    const holder = verifyHolder(uid, i); const art = artOf(i.art);
    const lim = limitsFrom(i);
    let pocketId = null;
    if (i.pocketId) { const p = ctx.pockets.getPocket(uid, i.pocketId); if (p.currency !== 'USD') bad('pocket_currency_must_be_usd'); pocketId = p.id; }
    if (db.prepare("SELECT COUNT(*) c FROM vcards WHERE uid = ? AND status IN ('active','frozen')").get(uid).c >= cfg.vcard.maxCards) bad('too_many_cards', 429);
    const issued = ctx.issuer.create({ uid, label });
    return commit(() => {
      const id = rid('vc'); const t = now();
      let panEnc = null; let panHash = null;
      if (issued.pan && vault?.available) { panEnc = ctx.seal({ pan: issued.pan }, `vcpan:${id}`); panHash = vault.blind(issued.pan); if (db.prepare('SELECT 1 FROM vcards WHERE pan_hash = ?').get(panHash)) bad('card_number_collision', 409); }
      db.prepare('INSERT INTO vcards (id, uid, issuer, issuer_ref, last4, exp, kind, merchant_lock, label, status, limit_tx, limit_day, limit_month, pocket_id, created_at, updated_at, art, holder, pan_enc, pan_hash) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(id, uid, ctx.issuer.name, issued.ref, panEnc ? issued.pan.slice(-4) : issued.last4, issued.exp, kind, lock, label, 'active', lim.tx, lim.day, lim.month, pocketId, t, t, art, holder, panEnc, panHash);
      A.log(uid, 'vcard.create', id, { kind, issuer: ctx.issuer.name });
      return view(db.prepare('SELECT * FROM vcards WHERE id = ?').get(id));
    });
  }
  function update(uid, id, i) {
    return commit(() => {
      const c = get(uid, id);
      const lim = limitsFrom(i, c); const label = i.label != null ? str(i.label, { max: 30, code: 'bad_label' }) : c.label;
      db.prepare('UPDATE vcards SET label = ?, limit_tx = ?, limit_day = ?, limit_month = ?, art = ?, updated_at = ? WHERE id = ?').run(label, lim.tx, lim.day, lim.month, artOf(i.art, c.art), now(), c.id);
      A.log(uid, 'vcard.update', c.id, {}); return view(db.prepare('SELECT * FROM vcards WHERE id = ?').get(c.id));
    });
  }
  function action(uid, id, act) {
    oneOf(act, ['freeze', 'unfreeze', 'close'], 'bad_action');
    if (act === 'unfreeze') ctx.security.assertNotFrozen(uid);
    return commit(() => {
      const c = get(uid, id);
      const to = { freeze: ['active', 'frozen'], unfreeze: ['frozen', 'active'], close: [c.status, 'closed'] }[act];
      if (c.status !== to[0]) bad('bad_state', 409);
      ctx.issuer?.setStatus?.(c.issuer_ref, to[1]);
      db.prepare('UPDATE vcards SET status = ?, updated_at = ? WHERE id = ?').run(to[1], now(), c.id);
      A.log(uid, `vcard.${act}`, c.id, {}); return { ok: true, status: to[1] };
    }, uid);
  }
  const cvvOf = (pan, exp) => String(vault.mac('cvv', `${pan}|${exp}`).readUInt32BE(0) % 1000).padStart(3, '0');
  /** Full number + CVV for the owner's own screen (sandbox test numbers). Real issuers return a token for their own secure frame instead. */
  function reveal(uid, id) {
    const c = get(uid, id);
    if (c.status !== 'active' && c.status !== 'frozen') bad('bad_state', 409);
    const used = db.prepare("SELECT COUNT(*) c FROM audit WHERE actor = ? AND action = 'vcard.reveal' AND ts > ?").get(uid, now() - 3600_000).c;
    if (used >= DAY_REVEALS) bad('too_many_reveals', 429);
    db.tx(() => A.log(uid, 'vcard.reveal', c.id, {}));
    const r = ctx.issuer?.reveal?.(c.issuer_ref) || {};
    const out = { id: c.id, last4: c.last4, exp: c.exp, holder: c.holder, sandbox: c.issuer === 'sandbox', issuerToken: r.token || null, showSeconds: 30 };
    if (c.pan_enc && c.issuer === 'sandbox') { const { pan } = ctx.open(c.pan_enc, `vcpan:${c.id}`); out.pan = pan; out.cvv = cvvOf(pan, c.exp); }
    return out;
  }
  /** Apple Pay push provisioning. Needs Apple's approval for the app AND an issuer that supports it; the sandbox has neither. */
  const b64 = (v, max, code) => str(String(v ?? ''), { min: 8, max, re: /^[A-Za-z0-9+/=_-]+$/, code });
  function appleWallet(uid, id, i) {
    const c = get(uid, id);
    if (!ctx.issuer?.provisionApplePay) bad('apple_pay_unavailable', 501);
    if (c.status !== 'active') bad('bad_state', 409);
    const certs = Array.isArray(i.certificates) && i.certificates.length >= 1 && i.certificates.length <= 3 ? i.certificates.map((x) => b64(x, 8192, 'bad_certificate')) : bad('bad_certificate');
    const out = ctx.issuer.provisionApplePay(c.issuer_ref, { certificates: certs, nonce: b64(i.nonce, 512, 'bad_nonce'), nonceSignature: b64(i.nonceSignature, 1024, 'bad_nonce') });
    db.tx(() => A.log(uid, 'vcard.apple_wallet', c.id, {}));
    return { encryptedPassData: out.encryptedPassData, activationData: out.activationData, ephemeralPublicKey: out.ephemeralPublicKey };
  }
  const applePay = () => Boolean(ctx.issuer?.provisionApplePay);

  /* ── merchants ── */
  const blocked = (uid) => db.prepare('SELECT merchant_key, created_at FROM blocked_merchants WHERE uid = ? ORDER BY created_at DESC').all(uid);
  function block(uid, merchant, on) {
    const key = merchantKey(str(merchant, { max: 40, code: 'bad_merchant' }));
    return commit(() => {
      if (on) db.prepare('INSERT OR IGNORE INTO blocked_merchants (uid, merchant_key, created_at) VALUES (?,?,?)').run(uid, key, now());
      else db.prepare('DELETE FROM blocked_merchants WHERE uid = ? AND merchant_key = ?').run(uid, key);
      A.log(uid, on ? 'merchant.block' : 'merchant.unblock', key, {}); return { ok: true, merchantKey: key };
    });
  }

  /* ── authorization: the one place a card purchase is decided ── */
  const authView = (a) => ({ id: a.id, cardId: a.card_id, merchant: a.merchant, category: a.category, amount: a.amount, currency: a.currency, status: a.status, reason: a.reason, createdAt: a.created_at });
  function fundingAccount(c) { return c.pocket_id ? L.account(c.uid, 'USD', 'pocket', c.pocket_id) : L.account(c.uid, 'USD', 'wallet'); }
  /** Returns { approved, reason, auth }. Must not throw for business declines (the issuer needs an answer). */
  function authorize({ card, merchant, category, amount, currency = 'USD', eventId = null, at = null }) {
    const t = at ?? now(); const mk = merchantKey(merchant); const cat = CATEGORIES.includes(category) ? category : 'other';
    let reason = null; let riskWhy = null;
    if (currency !== 'USD') reason = 'currency_not_supported';
    else if (!(amount > 0)) reason = 'bad_amount';
    else if (card.status !== 'active') reason = card.status === 'frozen' ? 'card_frozen' : 'card_inactive';
    else if (ctx.security.isFrozen(card.uid)) reason = 'account_frozen';
    else if (card.merchant_lock && card.merchant_lock !== mk) reason = 'merchant_not_allowed';
    else if (db.prepare('SELECT 1 FROM blocked_merchants WHERE uid = ? AND merchant_key = ?').get(card.uid, mk)) reason = 'merchant_blocked';
    else if (amount > card.limit_tx) reason = 'over_tx_limit';
    else if (spentSince(card.id, t - DAY) + amount > card.limit_day) reason = 'over_day_limit';
    else if (spentSince(card.id, monthStart(t)) + amount > card.limit_month) reason = 'over_month_limit';
    else if ((riskWhy = ctx.risk.checkCard(card, { amount, merchantKey: mk, at: t }))) reason = riskWhy;
    else if (ctx.planning.budgetBlocks(card.uid, cat, amount, t)) reason = 'budget_exceeded';
    else if (fundingAccount(card).balance < amount) reason = 'insufficient_funds';
    const id = rid('auth');
    let holdTxn = null;
    if (!reason) {
      const fund = fundingAccount(card);
      holdTxn = L.post({ type: 'card_hold', uid: card.uid, currency: 'USD', amount, at: t, meta: { cardId: card.id, authId: id, merchant: String(merchant).slice(0, 40), category: cat },
        legs: [{ acc: fund, delta: -amount }, { acc: L.account(card.uid, 'USD', 'hold'), delta: amount }] }).id;
    }
    db.prepare('INSERT INTO card_auths (id, uid, card_id, issuer_event, merchant, merchant_key, category, amount, currency, status, reason, hold_txn, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(id, card.uid, card.id, eventId, String(merchant).slice(0, 40), mk, cat, amount, currency, reason ? 'declined' : 'approved', reason, holdTxn, t, t);
    if (!reason && card.kind === 'single_use') db.prepare("UPDATE vcards SET status = 'closed', updated_at = ? WHERE id = ?").run(t, card.id);
    A.log('issuer', reason ? 'card.decline' : 'card.approve', id, { reason });
    if (riskWhy) ctx.risk.cardIncident(card, riskWhy);
    return { approved: !reason, reason, auth: db.prepare('SELECT * FROM card_auths WHERE id = ?').get(id) };
  }
  function settleRaw(a, at = null) {
    if (a.status !== 'approved') bad('bad_state', 409);
    const tx = L.post({ type: 'card_purchase', uid: a.uid, currency: 'USD', amount: a.amount, at: at ?? now(), meta: { cardId: a.card_id, authId: a.id, merchant: a.merchant, category: a.category },
      legs: [{ acc: L.account(a.uid, 'USD', 'hold'), delta: -a.amount }, { acc: L.sys('card_network', 'USD'), delta: a.amount }] });
    db.prepare("UPDATE card_auths SET status = 'settled', settle_txn = ?, updated_at = ? WHERE id = ?").run(tx.id, now(), a.id);
    return db.prepare('SELECT * FROM card_auths WHERE id = ?').get(a.id);
  }
  function refundRaw(a) {
    const card = db.prepare('SELECT * FROM vcards WHERE id = ?').get(a.card_id);
    const fund = card ? fundingAccount(card) : L.account(a.uid, 'USD', 'wallet');
    if (a.status === 'approved') L.post({ type: 'card_release', uid: a.uid, currency: 'USD', amount: a.amount, idem: `cr:${a.id}`, meta: { authId: a.id, merchant: a.merchant },
      legs: [{ acc: L.account(a.uid, 'USD', 'hold'), delta: -a.amount }, { acc: fund, delta: a.amount }] });
    else if (a.status === 'settled') L.post({ type: 'card_refund', uid: a.uid, currency: 'USD', amount: a.amount, idem: `cf:${a.id}`, meta: { authId: a.id, merchant: a.merchant, category: a.category },
      legs: [{ acc: L.sys('card_network', 'USD'), delta: -a.amount }, { acc: fund, delta: a.amount }] });
    else bad('bad_state', 409);
    db.prepare("UPDATE card_auths SET status = ?, updated_at = ? WHERE id = ?").run(a.status === 'approved' ? 'reversed' : 'refunded', now(), a.id);
    A.log('issuer', 'card.refund', a.id, {});
  }
  function afterAuth(r) {
    const a = r.auth;
    if (!r.approved) { ctx.notify(a.uid, 'card_declined', { merchant: a.merchant }); return; }
    if (a.status === 'settled') {
      ctx.notify(a.uid, 'card_purchase', { amount: a.amount, currency: 'USD', merchant: a.merchant });
      ctx.emit('card.settled', { uid: a.uid, auth: a });
    }
  }

  /** Sandbox only: a purchase from the simulator (authorize + settle). daysAgo back-dates it so subscriptions/budgets can be tried. */
  function simulate(uid, id, i) {
    if (!sandbox) bad('not_available', 403);
    const amount = usd(i.amount) ?? bad('bad_amount'); const merchant = str(i.merchant, { max: 40, code: 'bad_merchant' });
    const days = Number(i.daysAgo || 0); if (!Number.isInteger(days) || days < 0 || days > 400) bad('bad_days');
    const at = now() - days * DAY;
    const r = commit(() => {
      const card = db.prepare('SELECT * FROM vcards WHERE id = ? AND uid = ?').get(String(id || ''), uid) ?? bad('card_not_found', 404);
      const out = authorize({ card, merchant, category: i.category, amount, at });
      if (out.approved) out.auth = settleRaw(out.auth, at);
      return out;
    }, uid);
    afterAuth(r);
    return { approved: r.approved, reason: r.reason, auth: authView(r.auth) };
  }
  function simulateRefund(uid, authId) {
    if (!sandbox) bad('not_available', 403);
    let a;
    commit(() => { a = db.prepare('SELECT * FROM card_auths WHERE id = ? AND uid = ?').get(String(authId || ''), uid) ?? bad('not_found', 404); refundRaw(a); }, uid);
    ctx.notify(uid, 'card_refund', { amount: a.amount, currency: 'USD', merchant: a.merchant });
    ctx.emit('card.refunded', { uid, auth: a });
    return { ok: true };
  }
  /**
   * Issuer webhook (already signature-checked by the HTTP layer). Generic event shape — an adapter maps the provider's payload to it:
   * { type: 'authorization.request'|'transaction.settled'|'transaction.reversed', eventId, cardRef, authEventId?, merchant, category, amount, currency }
   */
  function issuerEvent(ev) {
    const type = oneOf(ev?.type, ['authorization.request', 'transaction.settled', 'transaction.reversed'], 'bad_event');
    const eventId = str(String(ev.eventId || ''), { min: 6, max: 80, re: /^[A-Za-z0-9_.:-]+$/, code: 'bad_event' });
    if (type === 'authorization.request') {
      const prev = db.prepare('SELECT * FROM card_auths WHERE issuer_event = ?').get(eventId);
      if (prev) return { approved: prev.status !== 'declined', reason: prev.reason, authId: prev.id, replay: true };
      const card = db.prepare('SELECT * FROM vcards WHERE issuer_ref = ?').get(String(ev.cardRef || ''));
      if (!card) return { approved: false, reason: 'card_not_found' };
      const amount = usd(ev.amount); if (!amount) return { approved: false, reason: 'bad_amount' };
      const r = commit(() => authorize({ card, merchant: str(String(ev.merchant || 'unknown'), { max: 40, code: 'bad_merchant' }), category: ev.category, amount, currency: ev.currency || 'USD', eventId }), card.uid);
      afterAuth(r);
      return { approved: r.approved, reason: r.reason, authId: r.auth.id };
    }
    const a = db.prepare('SELECT * FROM card_auths WHERE issuer_event = ?').get(String(ev.authEventId || '')) ?? bad('not_found', 404);
    if (type === 'transaction.settled') {
      if (a.status === 'settled') return { ok: true, replay: true };
      const s = commit(() => settleRaw(a), a.uid);
      ctx.notify(a.uid, 'card_purchase', { amount: a.amount, currency: 'USD', merchant: a.merchant }); ctx.emit('card.settled', { uid: a.uid, auth: s });
      return { ok: true };
    }
    if (a.status === 'reversed' || a.status === 'refunded') return { ok: true, replay: true };
    commit(() => refundRaw(a), a.uid); ctx.emit('card.refunded', { uid: a.uid, auth: a });
    return { ok: true };
  }
  const purchases = (uid, { limit = 50, cardId = null } = {}) => db.prepare(`SELECT * FROM card_auths WHERE uid = ? ${cardId ? 'AND card_id = ?' : ''} ORDER BY created_at DESC LIMIT ?`)
    .all(...[uid, ...(cardId ? [cardId] : []), Math.min(100, limit)]).map(authView);

  /* ── subscriptions ── */
  const PERIODS = [['weekly', 7, 5, 9], ['monthly', 30, 26, 35], ['yearly', 365, 355, 375]];
  const subView = (s) => ({ id: s.id, merchant: s.merchant, amount: s.amount, currency: s.currency, every: s.every, nextDue: s.next_due, source: s.source, status: s.status, lastAmount: s.last_amount, priceUp: s.last_amount != null && s.amount > s.last_amount * 1.05 });
  function detect(uid, mk) {
    const rows = db.prepare("SELECT amount, merchant, created_at FROM card_auths WHERE uid = ? AND merchant_key = ? AND status = 'settled' AND created_at > ? ORDER BY created_at").all(uid, mk, now() - 400 * DAY);
    if (rows.length < 2) return;
    const a = rows.at(-2); const b = rows.at(-1); const gap = (b.created_at - a.created_at) / DAY;
    const p = PERIODS.find(([, , lo, hi]) => gap >= lo && gap <= hi); if (!p) return;
    if (Math.abs(b.amount - a.amount) > a.amount * 0.25) return;
    const ex = db.prepare('SELECT * FROM subscriptions WHERE uid = ? AND merchant_key = ?').get(uid, mk);
    const next = b.created_at + p[1] * DAY;
    if (ex) db.prepare('UPDATE subscriptions SET amount = ?, last_amount = ?, every = ?, next_due = ?, updated_at = ? WHERE id = ?').run(b.amount, a.amount, p[0], next, now(), ex.id);
    else db.prepare('INSERT INTO subscriptions (id, uid, merchant, merchant_key, amount, currency, every, next_due, source, status, last_amount, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(rid('sub'), uid, b.merchant, mk, b.amount, 'USD', p[0], next, 'detected', 'active', a.amount, now(), now());
  }
  ctx.on('card.settled', ({ uid, auth }) => detect(uid, auth.merchant_key));
  const listSubs = (uid) => db.prepare("SELECT * FROM subscriptions WHERE uid = ? AND status != 'deleted' ORDER BY next_due").all(uid).map(subView);
  function addSub(uid, i) {
    const merchant = str(i.merchant, { max: 40, code: 'bad_merchant' }); const currency = oneOf(i.currency ?? 'USD', ['USD', 'EUR'], 'bad_currency');
    const amount = toMinor(i.amount, currency) ?? bad('bad_amount'); const every = oneOf(i.every, ['weekly', 'monthly', 'yearly'], 'bad_interval');
    const nd = typeof i.nextDue === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(i.nextDue) ? Date.parse(`${i.nextDue}T00:00:00Z`) : now() + 30 * DAY;
    return commit(() => {
      if (db.prepare("SELECT COUNT(*) c FROM subscriptions WHERE uid = ? AND status != 'deleted'").get(uid).c >= 50) bad('too_many', 429);
      const mk = merchantKey(merchant);
      db.prepare(`INSERT INTO subscriptions (id, uid, merchant, merchant_key, amount, currency, every, next_due, source, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(uid, merchant_key) DO UPDATE SET amount = excluded.amount, every = excluded.every, next_due = excluded.next_due, status = 'active', updated_at = excluded.updated_at`)
        .run(rid('sub'), uid, merchant, mk, amount, currency, every, nd, 'manual', 'active', now(), now());
      return subView(db.prepare('SELECT * FROM subscriptions WHERE uid = ? AND merchant_key = ?').get(uid, mk));
    });
  }
  function setSub(uid, id, act) {
    oneOf(act, ['block', 'unblock', 'ignore', 'delete'], 'bad_action');
    return commit(() => {
      const s = db.prepare("SELECT * FROM subscriptions WHERE id = ? AND uid = ? AND status != 'deleted'").get(String(id || ''), uid) ?? bad('not_found', 404);
      const st = { block: 'blocked', unblock: 'active', ignore: 'ignored', delete: 'deleted' }[act];
      db.prepare('UPDATE subscriptions SET status = ?, updated_at = ? WHERE id = ?').run(st, now(), s.id);
      if (act === 'block') db.prepare('INSERT OR IGNORE INTO blocked_merchants (uid, merchant_key, created_at) VALUES (?,?,?)').run(uid, s.merchant_key, now());
      if (act === 'unblock' || act === 'delete') db.prepare('DELETE FROM blocked_merchants WHERE uid = ? AND merchant_key = ?').run(uid, s.merchant_key);
      A.log(uid, `subscription.${act}`, s.id, {}); return { ok: true, status: st };
    });
  }
  const PERIOD_MS = { weekly: 7 * DAY, monthly: 30 * DAY, yearly: 365 * DAY };
  function runSubs() {
    const t = now();
    for (const s of db.prepare("SELECT * FROM subscriptions WHERE status = 'active' AND next_due IS NOT NULL AND next_due < ?").all(t - 3 * DAY)) {
      let n = s.next_due; while (n < t - 3 * DAY) n += PERIOD_MS[s.every];
      db.prepare('UPDATE subscriptions SET next_due = ? WHERE id = ?').run(n, s.id);
    }
    for (const s of db.prepare("SELECT * FROM subscriptions WHERE status = 'active' AND next_due BETWEEN ? AND ? AND (reminded_for IS NULL OR reminded_for != next_due)").all(t, t + 3 * DAY)) {
      db.prepare('UPDATE subscriptions SET reminded_for = next_due WHERE id = ?').run(s.id);
      ctx.notify(s.uid, 'subscription_due', { merchant: s.merchant, amount: s.amount, currency: s.currency });
    }
  }

  return { list, create, update, action, reveal, appleWallet, applePay, verifyHolder, blocked, block, simulate, simulateRefund, issuerEvent, purchases, listSubs, addSub, setSub, runSubs, authView };
}
