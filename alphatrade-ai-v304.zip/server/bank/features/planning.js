// Budgets and automatic saving rules. Budgets read spending (card purchases + labelled outgoing payments, USD) and can, if
// the user asks, decline card purchases over the monthly limit of a category. Saving rules move money from the wallet into a
// pocket: round-ups of card purchases, a fixed amount on a schedule, or a share of each incoming deposit. Every rule has a
// daily cap and a floor (the wallet never drops below it because of a rule), and every move is an ordinary ledger transaction.
import { bad, oneOf } from '../validate.js';
import { toMinor, CURRENCIES } from '../money.js';
import { CATEGORIES } from './pockets.js';

const DAY = 86400_000;
const EVERY = { daily: DAY, weekly: 7 * DAY, monthly: 30 * DAY };
export const monthStart = (t) => { const d = new Date(t); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1); };
const monthKey = (t) => new Date(t).toISOString().slice(0, 7);

export function createPlanning(ctx) {
  const { db, L, A, now, rid, commit, cfg } = ctx;

  /** USD spent per category since `from` (card purchases + labelled outgoing payments that are not card transactions). */
  function spentByCategory(uid, from = monthStart(now()), to = now() + 1) {
    const out = {};
    for (const r of db.prepare("SELECT category, SUM(amount) s FROM card_auths WHERE uid = ? AND status IN ('approved','settled') AND created_at >= ? AND created_at < ? GROUP BY category").all(uid, from, to)) out[r.category] = (out[r.category] || 0) + r.s;
    const labelled = db.prepare(`SELECT l.category, t.id, (SELECT COALESCE(SUM(e.delta),0) FROM entries e JOIN accounts a ON a.id = e.account_id WHERE e.txn_id = t.id AND a.owner = t.uid AND a.kind = 'wallet') eff
      FROM txns t JOIN txn_labels l ON l.txn_id = t.id WHERE t.uid = ? AND t.currency = 'USD' AND t.type NOT LIKE 'card_%' AND t.type NOT IN ('pocket_in','pocket_out','vault_in','vault_out','fx_out','fx_in','auto_save')
      AND l.category IS NOT NULL AND t.created_at >= ? AND t.created_at < ?`).all(uid, from, to);
    for (const r of labelled) if (r.eff < 0) out[r.category] = (out[r.category] || 0) - r.eff;
    return out;
  }
  const budgetView = (b, spent) => ({ category: b.category, amount: b.amount, block: Boolean(b.block), spent: spent[b.category] || 0, pct: b.amount ? Math.round(((spent[b.category] || 0) / b.amount) * 100) : 0 });
  function budgets(uid) {
    const spent = spentByCategory(uid);
    return { month: monthKey(now()), items: db.prepare('SELECT * FROM budgets WHERE uid = ? ORDER BY category').all(uid).map((b) => budgetView(b, spent)), spent };
  }
  function setBudget(uid, i) {
    const category = oneOf(i.category, CATEGORIES, 'bad_category'); const amount = toMinor(i.amount, 'USD') ?? bad('bad_amount');
    return commit(() => {
      if (db.prepare('SELECT COUNT(*) c FROM budgets WHERE uid = ?').get(uid).c >= CATEGORIES.length) bad('too_many', 429);
      db.prepare('INSERT INTO budgets (uid, category, amount, block) VALUES (?,?,?,?) ON CONFLICT(uid, category) DO UPDATE SET amount = excluded.amount, block = excluded.block').run(uid, category, amount, i.block === true ? 1 : 0);
      A.log(uid, 'budget.set', category, { amount }); return budgets(uid);
    });
  }
  function deleteBudget(uid, category) { db.prepare('DELETE FROM budgets WHERE uid = ? AND category = ?').run(uid, String(category || '')); return budgets(uid); }
  /** Called from card authorization: true = decline because the user asked to block over-budget spending in this category. */
  function budgetBlocks(uid, category, amount, t) {
    const b = db.prepare('SELECT * FROM budgets WHERE uid = ? AND category = ? AND block = 1').get(uid, category); if (!b) return false;
    const spent = spentByCategory(uid, monthStart(t), t + 1)[category] || 0;
    return spent + amount > b.amount;
  }
  function budgetAlerts(uid, category) {
    const b = db.prepare('SELECT * FROM budgets WHERE uid = ? AND category = ?').get(uid, category); if (!b || !b.amount) return;
    const spent = spentByCategory(uid)[category] || 0; const mk = monthKey(now());
    const level = spent >= b.amount ? 100 : spent >= b.amount * 0.8 ? 80 : 0; if (!level) return;
    const tag = `${mk}:${level}`;
    if (b.alerted === tag || (level === 80 && b.alerted === `${mk}:100`)) return;
    db.prepare('UPDATE budgets SET alerted = ? WHERE uid = ? AND category = ?').run(tag, uid, category);
    ctx.notify(uid, level === 100 ? 'budget_100' : 'budget_80', { category });
  }
  ctx.on('card.settled', ({ uid, auth }) => budgetAlerts(uid, auth.category));

  /* ── saving rules ── */
  const ruleView = (r) => ({ id: r.id, kind: r.kind, pocketId: r.pocket_id, currency: r.currency, amount: r.amount, pctBp: r.pct_bp, roundTo: r.round_to, every: r.every, nextRun: r.next_run,
    dailyCap: r.daily_cap, floor: r.floor, status: r.status, savedToday: savedSince(r.id, now() - DAY) });
  const savedSince = (ruleId, t) => db.prepare("SELECT COALESCE(SUM(amount),0) s FROM txns WHERE type = 'auto_save' AND json_extract(meta, '$.ruleId') = ? AND created_at > ?").get(ruleId, t).s;
  const listRules = (uid) => db.prepare("SELECT * FROM save_rules WHERE uid = ? AND status != 'deleted' ORDER BY created_at").all(uid).map(ruleView);
  function createRule(uid, i) {
    const kind = oneOf(i.kind, ['roundup', 'fixed', 'percent'], 'bad_kind');
    const p = ctx.pockets.getPocket(uid, i.pocketId); const c = p.currency;
    if (kind === 'roundup' && c !== 'USD') bad('pocket_currency_must_be_usd');
    const roundTo = kind === 'roundup' ? oneOf(Number(i.roundTo ?? 1), [1, 2, 5, 10], 'bad_round') * 10 ** CURRENCIES[c].decimals : null;
    const amount = kind === 'fixed' ? toMinor(i.amount, c) ?? bad('bad_amount') : null;
    const pct = kind === 'percent' ? Math.round(Number(i.pct) * 100) : null; if (kind === 'percent' && !(pct >= 100 && pct <= 5000)) bad('bad_percent');
    const every = kind === 'fixed' ? oneOf(i.every, Object.keys(EVERY), 'bad_interval') : null;
    const cap = i.dailyCap != null && i.dailyCap !== '' ? toMinor(i.dailyCap, c) ?? bad('bad_amount') : cfg.saveRules.dailyCap[c];
    const floor = i.floor != null && i.floor !== '' ? (i.floor === '0' || i.floor === 0 ? 0 : toMinor(i.floor, c) ?? bad('bad_amount')) : 0;
    return commit(() => {
      if (db.prepare("SELECT COUNT(*) c FROM save_rules WHERE uid = ? AND status != 'deleted'").get(uid).c >= 10) bad('too_many', 429);
      const id = rid('rul');
      db.prepare('INSERT INTO save_rules (id, uid, kind, pocket_id, currency, amount, pct_bp, round_to, every, next_run, daily_cap, floor, status, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(id, uid, kind, p.id, c, amount, pct, roundTo, every, every ? now() + EVERY[every] : null, cap, floor, 'active', now());
      A.log(uid, 'rule.create', id, { kind }); return ruleView(db.prepare('SELECT * FROM save_rules WHERE id = ?').get(id));
    });
  }
  function setRule(uid, id, act) {
    oneOf(act, ['pause', 'resume', 'delete'], 'bad_action');
    return commit(() => {
      const r = db.prepare("SELECT * FROM save_rules WHERE id = ? AND uid = ? AND status != 'deleted'").get(String(id || ''), uid) ?? bad('not_found', 404);
      const st = { pause: 'paused', resume: 'active', delete: 'deleted' }[act];
      db.prepare('UPDATE save_rules SET status = ?, next_run = ? WHERE id = ?').run(st, act === 'resume' && r.every ? now() + EVERY[r.every] : r.next_run, r.id);
      A.log(uid, `rule.${act}`, r.id, {}); return { ok: true };
    });
  }
  /** Moves `amount` for rule r (inside commit). Returns the reason it was skipped, or null. */
  function applyRule(r, amount, key) {
    if (!(amount > 0)) return 'zero';
    if (ctx.security.isFrozen(r.uid)) return 'frozen';
    const p = db.prepare("SELECT * FROM pockets WHERE id = ? AND status = 'active'").get(r.pocket_id); if (!p) return 'pocket_gone';
    if (savedSince(r.id, now() - DAY) + amount > r.daily_cap) return 'daily_cap';
    if (L.account(r.uid, r.currency, 'wallet').balance - amount < r.floor) return 'floor';
    const w = L.account(r.uid, r.currency, 'wallet'); const k = L.account(r.uid, r.currency, 'pocket', p.id);
    const tx = L.post({ type: 'auto_save', uid: r.uid, currency: r.currency, amount, idem: key, meta: { ruleId: r.id, pocketId: p.id, kind: r.kind },
      legs: [{ acc: w, delta: -amount }, { acc: k, delta: amount }] });
    if (!tx.replay) A.log('system', 'rule.saved', r.id, { amount });
    return null;
  }
  function onSettled({ uid, auth }) {
    for (const r of db.prepare("SELECT * FROM save_rules WHERE uid = ? AND kind = 'roundup' AND status = 'active'").all(uid)) {
      const up = Math.ceil(auth.amount / r.round_to) * r.round_to - auth.amount;
      try { commit(() => applyRule(r, up, `ru:${auth.id}:${r.id}`), uid); } catch { /* a rule never breaks a purchase */ }
    }
  }
  function onCredit({ uid, currency, amount, txn }) {
    for (const r of db.prepare("SELECT * FROM save_rules WHERE uid = ? AND kind = 'percent' AND status = 'active' AND currency = ?").all(uid, currency)) {
      const part = Math.floor((amount * r.pct_bp) / 10000);
      try { commit(() => applyRule(r, part, `pc:${txn}:${r.id}`), uid); } catch { /* */ }
    }
  }
  ctx.on('card.settled', onSettled);
  ctx.on('deposit.credited', onCredit);
  function runRules() {
    for (const r of db.prepare("SELECT * FROM save_rules WHERE kind = 'fixed' AND status = 'active' AND next_run <= ? LIMIT 200").all(now())) {
      let skipped = null;
      try {
        commit(() => {
          const cur = db.prepare("SELECT * FROM save_rules WHERE id = ? AND status = 'active' AND next_run <= ?").get(r.id, now()); if (!cur) return;
          let next = cur.next_run; while (next <= now()) next += EVERY[cur.every];
          skipped = applyRule(cur, cur.amount, `fx:${cur.id}:${cur.next_run}`);
          db.prepare('UPDATE save_rules SET next_run = ? WHERE id = ?').run(next, cur.id);
        }, r.uid);
      } catch { skipped = 'error'; }
      if (skipped && skipped !== 'zero') ctx.notify(r.uid, 'save_skipped');
    }
  }

  return { spentByCategory, budgets, setBudget, deleteBudget, budgetBlocks, listRules, createRule, setRule, runRules };
}
