// Fraud / risk scoring. Rule-based and explainable on purpose: every point in a score has a named reason that is stored,
// shown to the operator, and tested. Not a trained model — thresholds are config (cfg.risk) and should be tuned on real data.
//   score < review → allow · review ≤ score < block → allow but flag for the operator · score ≥ block → refuse + notify.
// Card testing (many small / declined authorisations in a few minutes) freezes the card, not the whole account.
import crypto from 'node:crypto';
import { bad } from '../validate.js';

const MIN = 60_000; const HOUR = 3600_000; const DAY = 86400_000;
export const RISK_DEFAULTS = { review: 40, block: 85, cardTestDeclines: 4, cardTestWindow: 10 * MIN, cardBurst: 6, cardBurstWindow: 5 * MIN, newAccountDays: 3 };

export function createRisk(ctx) {
  const { db, A, now } = ctx;
  const cfg = () => ({ ...RISK_DEFAULTS, ...(ctx.cfg.risk || {}) });
  const recent = (uid, actions, since) => db.prepare(`SELECT COUNT(*) c FROM audit WHERE actor = ? AND action IN (${actions.map(() => '?').join(',')}) AND ts > ?`).get(uid, ...actions, since).c;

  function record(uid, kind, ref, score, level, reasons) {
    const id = ctx.rid('risk');
    db.prepare('INSERT INTO risk_events (id, uid, kind, ref, score, level, reasons, created_at) VALUES (?,?,?,?,?,?,?,?)').run(id, uid, kind, ref, score, level, JSON.stringify(reasons), now());
    A.log('risk', `risk.${level}`, id, { uid, kind, score, reasons });
    return id;
  }
  const levelOf = (score) => (score >= cfg().block ? 'block' : score >= cfg().review ? 'review' : 'allow');

  /** Scores a withdrawal request. `usd` is the amount in USD (null when rates are unavailable → we score on the ratio only). */
  function scoreWithdrawal(uid, { currency, amount, flags = [], limit = 0, usd = null }) {
    const t = now(); const c = cfg(); const reasons = []; let score = 0;
    const add = (pts, why) => { score += pts; reasons.push({ why, pts }); };
    if (flags.includes('first_withdrawal')) add(15, 'first_withdrawal');
    if (flags.includes('new_beneficiary')) add(20, 'new_beneficiary');
    if (flags.includes('fresh_deposit')) add(25, 'fresh_deposit');       // deposit-and-run pattern
    if (flags.includes('cross_border')) add(5, 'cross_border');
    if (limit > 0) { const r = amount / limit; if (r >= 0.9) add(25, 'near_daily_limit'); else if (r >= 0.5) add(10, 'large_vs_limit'); }
    const avg = db.prepare("SELECT AVG(amount) a, COUNT(*) n FROM withdrawals WHERE uid = ? AND currency = ? AND status = 'completed'").get(uid, currency);
    if (avg.n >= 3 && amount > avg.a * 5) add(20, 'unusual_amount');
    const acct = db.prepare('SELECT MIN(ts) t FROM audit WHERE actor = ?').get(uid)?.t;
    if (acct && t - acct < c.newAccountDays * DAY) add(15, 'new_account');
    if (recent(uid, ['passkey.remove', 'totp.disable', 'security.policy'], t - DAY) > 0) add(25, 'recent_security_change');
    if (recent(uid, ['totp.fail', 'passkey.fail', 'stepup.fail'], t - HOUR) >= 3) add(20, 'failed_step_ups');
    if (db.prepare("SELECT COUNT(*) c FROM withdrawals WHERE uid = ? AND created_at > ?").get(uid, t - HOUR).c >= 3) add(15, 'rapid_requests');
    if (usd != null && usd >= 10_000) add(10, 'high_value');
    score = Math.min(100, score);
    return { score, level: levelOf(score), reasons };
  }
  /** Called inside the withdrawal transaction. Blocks (throws) or returns the flag to add. */
  function checkWithdrawal(uid, wdId, input) {
    const r = scoreWithdrawal(uid, input);
    if (r.level === 'allow') return { flags: [], ...r };
    if (r.level === 'block') { record(uid, 'withdrawal', null, r.score, 'block', r.reasons); return { blocked: true, ...r }; }
    record(uid, 'withdrawal', wdId, r.score, 'review', r.reasons);
    return { flags: ['risk_review'], ...r };
  }

  /** Card authorisation: returns a decline reason or null. Pure reads, so it is safe to call inside authorize(). */
  function checkCard(card, { amount, merchantKey, at }) {
    const c = cfg(); const t = at ?? now();
    const declines = db.prepare("SELECT COUNT(*) c FROM card_auths WHERE card_id = ? AND status = 'declined' AND created_at > ? AND reason NOT IN ('insufficient_funds','budget_exceeded')").get(card.id, t - c.cardTestWindow).c;
    if (declines >= c.cardTestDeclines) return 'risk_card_testing';
    const burst = db.prepare("SELECT COUNT(*) c FROM card_auths WHERE card_id = ? AND created_at > ?").get(card.id, t - c.cardBurstWindow).c;
    if (burst >= c.cardBurst) return 'risk_velocity';
    const small = db.prepare("SELECT COUNT(DISTINCT merchant_key) m FROM card_auths WHERE card_id = ? AND amount <= 200 AND created_at > ?").get(card.id, t - c.cardBurstWindow).m;
    if (small >= 4 && amount <= 200 && merchantKey) return 'risk_card_testing';
    return null;
  }
  /** After a risk decline: freeze that card (the owner unfreezes it) and tell the owner. Runs inside the authorise transaction. */
  function cardIncident(card, reason) {
    try {
      db.prepare("UPDATE vcards SET status = 'frozen', updated_at = ? WHERE id = ? AND status = 'active'").run(now(), card.id);
      record(card.uid, 'card', card.id, reason === 'risk_card_testing' ? 90 : 60, reason === 'risk_card_testing' ? 'block' : 'review', [{ why: reason, pts: 0 }]);
      ctx.notify(card.uid, 'fraud_alert');
    } catch (e) { console.error('[bank] risk incident failed:', e?.code || e?.name); }
  }

  const view = (r) => ({ id: r.id, uid: r.uid, kind: r.kind, ref: r.ref, score: r.score, level: r.level, reasons: JSON.parse(r.reasons || '[]'), createdAt: r.created_at, reviewedBy: r.reviewed_by, reviewedAt: r.reviewed_at });
  const list = ({ level = null, open = false, limit = 100 } = {}) => {
    const q = ['1=1']; const a = [];
    if (level) { q.push('level = ?'); a.push(level); }
    if (open) q.push('reviewed_at IS NULL');
    return db.prepare(`SELECT * FROM risk_events WHERE ${q.join(' AND ')} ORDER BY created_at DESC LIMIT ?`).all(...a, Math.min(500, limit)).map(view);
  };
  const forUser = (uid) => db.prepare('SELECT * FROM risk_events WHERE uid = ? ORDER BY created_at DESC LIMIT 20').all(uid).map(view);
  function review(actor, id, note = '') {
    const r = db.prepare('SELECT * FROM risk_events WHERE id = ?').get(id) ?? bad('not_found', 404);
    if (r.uid === actor) bad('self_action_not_allowed', 403);
    db.tx(() => { db.prepare('UPDATE risk_events SET reviewed_by = ?, reviewed_at = ? WHERE id = ?').run(actor, now(), id); A.log(actor, 'risk.reviewed', id, { note: String(note).slice(0, 200) }); });
    return { ok: true };
  }
  const summary = (since) => ({
    byLevel: Object.fromEntries(db.prepare('SELECT level, COUNT(*) c FROM risk_events WHERE created_at >= ? GROUP BY level').all(since).map((x) => [x.level, x.c])),
    open: db.prepare("SELECT COUNT(*) c FROM risk_events WHERE reviewed_at IS NULL AND level != 'allow' AND created_at >= ?").get(since).c,
  });
  return { scoreWithdrawal, checkWithdrawal, checkCard, cardIncident, list, forUser, review, summary, record };
}
