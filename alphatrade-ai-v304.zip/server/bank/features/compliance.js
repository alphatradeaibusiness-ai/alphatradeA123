// Automatic compliance reports. Built only from data this ledger actually holds; every number is reproducible from the
// tables. What it is NOT: a regulator filing. It is the operator's working report (KYC mix, volumes, large-value and
// travel-rule candidates, risk events, freezes, integrity checks) that a compliance officer reviews and files from.
// Reports are generated per day / month by runDue, stored once per period (UNIQUE), and exportable as JSON or CSV.
import { bad } from '../validate.js';
import { CURRENCIES } from '../money.js';

const DAY = 86400_000;
export const COMPLIANCE_DEFAULTS = { largeUsd: 10_000, travelRuleUsd: 1_000, keepDays: 400 };
const startOfDayUtc = (t) => Math.floor(t / DAY) * DAY;
const pad = (n) => String(n).padStart(2, '0');
const ymd = (t) => { const d = new Date(t); return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`; };
const ym = (t) => ymd(t).slice(0, 7);
/** CSV cell safe against spreadsheet formula injection (=, +, -, @, tab, CR) and quotes. */
export const csvCell = (v) => { let s = v == null ? '' : String(v); if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };

export function createCompliance(ctx) {
  const { db, A, now, sandbox } = ctx;
  const cfg = () => ({ ...COMPLIANCE_DEFAULTS, ...(ctx.cfg.compliance || {}) });
  const usdOf = (minor, c, usdPer) => (usdPer ? (minor / 10 ** CURRENCIES[c].decimals) * usdPer[c] : null);

  async function build(from, to) {
    let usdPer = null; try { usdPer = (await ctx.fx.rates()).usdPer; } catch { /* rates optional: USD figures become null */ }
    const c = cfg(); const cur = Object.keys(CURRENCIES);
    const sum = (type) => Object.fromEntries(cur.map((k) => {
      const r = db.prepare("SELECT COUNT(*) n, COALESCE(SUM(amount),0) s FROM txns WHERE type = ? AND currency = ? AND created_at >= ? AND created_at < ?").get(type, k, from, to);
      return [k, { count: r.n, total: r.s }];
    }));
    const large = [];
    for (const r of db.prepare("SELECT id, uid, type, currency, amount, created_at FROM txns WHERE type IN ('deposit','withdrawal_hold') AND created_at >= ? AND created_at < ? ORDER BY created_at").all(from, to)) {
      const u = usdOf(r.amount, r.currency, usdPer);
      if (u != null && u >= c.largeUsd) large.push({ id: r.id, uid: r.uid, type: r.type, currency: r.currency, amount: r.amount, usd: Math.round(u * 100) / 100, at: r.created_at });
    }
    const travel = [];
    for (const r of db.prepare("SELECT i.id, i.uid, i.to_cur, i.receive, i.created_at, w.currency, w.amount FROM intl_transfers i JOIN withdrawals w ON w.id = i.withdrawal_id WHERE i.created_at >= ? AND i.created_at < ?").all(from, to)) {
      const u = usdOf(r.amount, r.currency, usdPer);
      if (u != null && u >= c.travelRuleUsd) travel.push({ id: r.id, uid: r.uid, currency: r.currency, amount: r.amount, toCurrency: r.to_cur, usd: Math.round(u * 100) / 100, at: r.created_at });
    }
    const kyc = Object.fromEntries(db.prepare('SELECT tier, COUNT(*) n FROM kyc GROUP BY tier').all().map((r) => [`tier${r.tier}`, r.n]));
    const kycPending = db.prepare("SELECT COUNT(*) c FROM kyc WHERE status = 'pending'").get().c;
    const act = (a) => db.prepare('SELECT COUNT(*) c FROM audit WHERE action = ? AND ts >= ? AND ts < ?').get(a, from, to).c;
    const risk = {
      byLevel: Object.fromEntries(db.prepare('SELECT level, COUNT(*) c FROM risk_events WHERE created_at >= ? AND created_at < ? GROUP BY level').all(from, to).map((x) => [x.level, x.c])),
      unreviewed: db.prepare("SELECT COUNT(*) c FROM risk_events WHERE reviewed_at IS NULL AND level != 'allow'").get().c,
    };
    const wd = db.prepare("SELECT status, COUNT(*) n FROM withdrawals WHERE created_at >= ? AND created_at < ? GROUP BY status").all(from, to);
    const blocked = new Set(c.blockedCountries || ctx.cfg.blockedCountries || []);
    return {
      period: { from, to }, currencies: cur, usdAvailable: Boolean(usdPer), thresholds: { largeUsd: c.largeUsd, travelRuleUsd: c.travelRuleUsd },
      kyc: { ...kyc, pending: kycPending, approved: act('kyc.approve'), rejected: act('kyc.reject') },
      volumes: { deposits: sum('deposit'), withdrawals: sum('withdrawal_hold'), sandboxCredits: sandbox ? sum('sandbox_credit') : undefined },
      withdrawalsByStatus: Object.fromEntries(wd.map((r) => [r.status, r.n])),
      largeTransactions: large, travelRuleCandidates: travel, risk,
      freezes: { frozen: act('account.freeze'), unfrozen: act('account.unfreeze') },
      cards: { declined: act('card.decline'), approved: act('card.approve') },
      security: { totpEnabled: act('totp.enable'), totpFailures: act('totp.fail') },
      blockedCountries: [...blocked],
      integrity: { audit: A.verify(), ledger: ctx.L.verify() },
    };
  }

  async function generate(kind, from, to, period) {
    const prev = db.prepare('SELECT id FROM compliance_reports WHERE period = ?').get(period);
    if (prev) return prev.id;
    const data = await build(from, to);
    const id = ctx.rid('cr');
    try {
      db.tx(() => { db.prepare('INSERT INTO compliance_reports (id, period, kind, from_ts, to_ts, data, created_at) VALUES (?,?,?,?,?,?,?)').run(id, period, kind, from, to, JSON.stringify(data), now()); A.log('system', 'compliance.report', id, { period, large: data.largeTransactions.length, travel: data.travelRuleCandidates.length }); });
    } catch (e) { if (!/UNIQUE/i.test(String(e?.message))) throw e; return db.prepare('SELECT id FROM compliance_reports WHERE period = ?').get(period).id; }
    return id;
  }
  /** Generates yesterday's daily report and, on/after the 1st, last month's. Idempotent: a period is stored once. Called by runDue. */
  async function runDue() {
    const t = now(); const today = startOfDayUtc(t); const made = [];
    made.push(await generate('daily', today - DAY, today, `d:${ymd(today - DAY)}`));
    const d = new Date(today); const mStart = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1); const pStart = Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 1, 1);
    made.push(await generate('monthly', pStart, mStart, `m:${ym(pStart)}`));
    db.prepare('DELETE FROM compliance_reports WHERE created_at < ?').run(t - cfg().keepDays * DAY);
    return made;
  }
  /** On-demand report for an arbitrary window (not stored). */
  async function adhoc(from, to) {
    if (!Number.isSafeInteger(from) || !Number.isSafeInteger(to) || to <= from || to - from > 366 * DAY) bad('bad_range');
    return { id: null, period: 'adhoc', kind: 'adhoc', data: await build(from, to) };
  }
  const meta = (r) => ({ id: r.id, period: r.period, kind: r.kind, from: r.from_ts, to: r.to_ts, createdAt: r.created_at });
  const list = (limit = 60) => db.prepare('SELECT id, period, kind, from_ts, to_ts, created_at FROM compliance_reports ORDER BY from_ts DESC LIMIT ?').all(Math.min(200, limit)).map(meta);
  const get = (id) => { const r = db.prepare('SELECT * FROM compliance_reports WHERE id = ?').get(String(id)) ?? bad('not_found', 404); return { ...meta(r), data: JSON.parse(r.data) }; };
  /** Flat CSV: section,key,value rows + the large / travel-rule tables. */
  function toCsv(rep) {
    const rows = [['section', 'key', 'value']]; const d = rep.data;
    const flat = (sec, o, pre = '') => { for (const [k, v] of Object.entries(o || {})) { if (v && typeof v === 'object' && !Array.isArray(v)) flat(sec, v, `${pre}${k}.`); else if (!Array.isArray(v)) rows.push([sec, pre + k, v]); } };
    for (const s of ['kyc', 'volumes', 'withdrawalsByStatus', 'risk', 'freezes', 'cards', 'security', 'integrity']) flat(s, d[s]);
    rows.push([], ['large_transactions', 'id', 'uid', 'type', 'currency', 'amount', 'usd', 'at']);
    for (const r of d.largeTransactions) rows.push(['large', r.id, r.uid, r.type, r.currency, r.amount, r.usd, new Date(r.at).toISOString()]);
    rows.push([], ['travel_rule', 'id', 'uid', 'currency', 'amount', 'to', 'usd', 'at']);
    for (const r of d.travelRuleCandidates) rows.push(['travel', r.id, r.uid, r.currency, r.amount, r.toCurrency, r.usd, new Date(r.at).toISOString()]);
    return rows.map((r) => r.map(csvCell).join(',')).join('\n');
  }
  return { build, generate, runDue, adhoc, list, get, toCsv };
}
