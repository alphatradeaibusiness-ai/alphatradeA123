// Exchange rates, the converter, conversions between the user's own wallets, and cross-border transfers.
// Rates are REFERENCE rates (ECB daily for EUR, Binance for BTC; USDT is taken as 1 USD and labelled so). A real conversion
// or cross-border payout needs a liquidity / transfer partner: in live mode both stay off until one is connected. In sandbox
// mode they run against test funds at the reference rate minus a visible spread, so the flow can be tried end to end.
import { bad, oneOf, idem as idemOk } from '../validate.js';
import { CURRENCIES, toMinor } from '../money.js';

const MONEY = Object.keys(CURRENCIES);

export function createFx(ctx) {
  const { db, L, A, now, rid, commit, cfg, sandbox } = ctx;
  let cache = null;
  /** { usdPer: {USD, EUR, USDT, BTC}, ts, sources } — usdPer[c] = USD value of one unit of c. */
  async function rates({ fresh = false } = {}) {
    if (!fresh && cache && now() - cache.fetchedAt < cfg.fx.cacheMs) return cache.value;
    if (!ctx.rateFn) bad('rates_unavailable', 503);
    let v; try { v = await ctx.rateFn(); } catch { v = null; }
    if (!v || !v.usdPer || !MONEY.every((c) => v.usdPer[c] > 0)) { if (cache) return cache.value; bad('rates_unavailable', 503); }
    cache = { value: v, fetchedAt: now() };
    return v;
  }
  const raw = (amountMinor, from, to, r) => (amountMinor / 10 ** CURRENCIES[from].decimals) * (r.usdPer[from] / r.usdPer[to]) * 10 ** CURRENCIES[to].decimals;
  async function calc(i) {
    const from = oneOf(i.from, MONEY, 'bad_currency'); const to = oneOf(i.to, MONEY, 'bad_currency');
    const amount = toMinor(i.amount, from) ?? bad('bad_amount'); const r = await rates();
    return { from, to, amount, result: Math.floor(raw(amount, from, to, r)), rate: r.usdPer[from] / r.usdPer[to], ts: r.ts, sources: r.sources, indicative: true };
  }
  const fresh = (r) => { if (now() - r.ts > cfg.fx.maxStaleMs) bad('rates_stale', 503); };

  async function convert(uid, i) {
    if (!sandbox && !ctx.fxProvider) bad('no_fx_provider', 503);
    const from = oneOf(i.from, MONEY, 'bad_currency'); const to = oneOf(i.to, MONEY, 'bad_currency'); if (from === to) bad('same_currency');
    const amount = toMinor(i.amount, from) ?? bad('bad_amount'); const key = idemOk(i.idem);
    const r = await rates(); fresh(r);
    const receive = Math.floor(raw(amount, from, to, r) * (1 - cfg.fx.spreadBp / 10000));
    if (receive <= 0) bad('amount_too_small');
    const out = commit(() => {
      const prev = db.prepare("SELECT id, meta FROM txns WHERE uid = ? AND idem = ?").get(uid, `${key}:o`);
      if (prev) return { replay: true, ...JSON.parse(prev.meta) };
      const conv = rid('cnv');
      L.post({ type: 'fx_out', uid, currency: from, amount, idem: `${key}:o`, meta: { convId: conv, from, to, amount, receive, rate: r.usdPer[from] / r.usdPer[to] },
        legs: [{ acc: L.account(uid, from, 'wallet'), delta: -amount }, { acc: L.sys('fx', from), delta: amount }] });
      L.post({ type: 'fx_in', uid, currency: to, amount: receive, idem: `${key}:i`, meta: { convId: conv, from, to, amount, receive },
        legs: [{ acc: L.sys('fx', to), delta: -receive }, { acc: L.account(uid, to, 'wallet'), delta: receive }] });
      A.log(uid, 'fx.convert', conv, { from, to, amount, receive });
      return { convId: conv, from, to, amount, receive, spreadBp: cfg.fx.spreadBp };
    }, uid);
    if (!out.replay) ctx.notify(uid, 'converted', { amount: receive, currency: to });
    return out;
  }

  /* ── cross-border ── */
  const quoteView = (q) => ({ id: q.id, from: q.from_cur, to: q.to_cur, amount: q.amount, fee: q.fee, rate: q.rate, receive: q.receive, beneficiaryId: q.beneficiary_id, expiresAt: q.expires_at });
  async function quoteIntl(uid, i) {
    if (!sandbox && !ctx.fxProvider) bad('no_transfer_provider', 503);
    ctx.security.assertNotFrozen(uid); if (ctx.tier(uid) < 1) bad('kyc_required', 403);
    const from = oneOf(i.from, MONEY, 'bad_currency'); const amount = toMinor(i.amount, from) ?? bad('bad_amount');
    const ben = db.prepare("SELECT * FROM beneficiaries WHERE id = ? AND uid = ? AND status = 'active'").get(String(i.beneficiaryId || ''), uid) ?? bad('beneficiary_not_found', 404);
    if (ben.currency === from) bad('use_normal_withdrawal');
    if (CURRENCIES[ben.currency].kind !== 'fiat' || CURRENCIES[from].kind === 'crypto') bad('cross_border_fiat_only');
    const r = await rates(); fresh(r);
    const rate = (r.usdPer[from] / r.usdPer[ben.currency]) * (1 - cfg.fx.spreadBp / 10000);
    const receive = Math.floor(raw(amount, from, ben.currency, r) * (1 - cfg.fx.spreadBp / 10000));
    const fee = cfg.intl.fee[from] ?? bad('bad_currency');
    const id = rid('qte');
    db.prepare('INSERT INTO quotes (id, uid, kind, from_cur, to_cur, amount, rate, fee, receive, beneficiary_id, expires_at, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(id, uid, 'intl', from, ben.currency, amount, rate, fee, receive, ben.id, now() + cfg.intl.quoteTtl, now());
    return quoteView(db.prepare('SELECT * FROM quotes WHERE id = ?').get(id));
  }
  function confirmIntl(uid, i) {
    const key = idemOk(i.idem);
    const q = db.prepare('SELECT * FROM quotes WHERE id = ? AND uid = ?').get(String(i.quoteId || ''), uid) ?? bad('quote_not_found', 404);
    const prev = db.prepare('SELECT * FROM intl_transfers WHERE quote_id = ?').get(q.id);
    if (prev) return { replay: true, withdrawalId: prev.withdrawal_id };
    if (q.used || q.expires_at < now()) bad('quote_expired', 409);
    const w = ctx.withdrawals.create(uid, { currency: q.from_cur, amount: q.amount, beneficiaryId: q.beneficiary_id, idem: key, fee: q.fee, crossBorder: { quoteId: q.id, to: q.to_cur, receive: q.receive, rate: q.rate } });
    return { ok: true, withdrawal: w, receive: q.receive, to: q.to_cur };
  }
  /** Called inside the withdrawal's commit. */
  function recordIntl(uid, withdrawalId, cb) {
    const q = db.prepare('SELECT * FROM quotes WHERE id = ? AND uid = ? AND used = 0').get(cb.quoteId, uid) ?? bad('quote_expired', 409);
    if (q.expires_at < now()) bad('quote_expired', 409);
    db.prepare('UPDATE quotes SET used = 1 WHERE id = ?').run(q.id);
    db.prepare('INSERT INTO intl_transfers (id, uid, quote_id, withdrawal_id, to_cur, receive, rate, created_at) VALUES (?,?,?,?,?,?,?,?)').run(rid('itl'), uid, q.id, withdrawalId, q.to_cur, q.receive, q.rate, now());
  }
  const intlFor = (withdrawalId) => { const t = db.prepare('SELECT to_cur, receive, rate FROM intl_transfers WHERE withdrawal_id = ?').get(withdrawalId); return t ? { to: t.to_cur, receive: t.receive, rate: t.rate } : null; };
  return { rates, calc, convert, quoteIntl, confirmIntl, recordIntl, intlFor };
}
