// Sub-wallets ("pockets"), the time-locked vault and transaction labels. Pockets and the vault are ledger accounts of the
// same user, so moving money between them is a normal balanced transaction (no fees, no rounding, fully audited).
// The vault is NOT custody: real cold storage of crypto needs a licensed custodian. Here it is a savings lock — leaving it
// takes a passkey (when the user has one) and a 24 h wait that can be cancelled, plus co-signers if the policy says so.
import { bad, str, oneOf, idem as idemOk } from '../validate.js';
import { CURRENCIES, toMinor } from '../money.js';

export const CATEGORIES = ['groceries', 'dining', 'transport', 'shopping', 'bills', 'subscriptions', 'entertainment', 'travel', 'health', 'education', 'transfers', 'savings', 'investing', 'fees', 'income', 'other'];
const COLORS = ['violet', 'blue', 'teal', 'green', 'amber', 'rose', 'slate'];
const MONEY = Object.keys(CURRENCIES);

export function createPockets(ctx) {
  const { db, L, A, now, rid, commit, seal, open, cfg } = ctx;

  /* ── pockets ── */
  const pocketView = (p) => ({ id: p.id, name: p.name, currency: p.currency, goal: p.goal, color: p.color, balance: L.account(p.uid, p.currency, 'pocket', p.id).balance, createdAt: p.created_at });
  const listPockets = (uid) => db.prepare("SELECT * FROM pockets WHERE uid = ? AND status = 'active' ORDER BY created_at").all(uid).map(pocketView);
  const getPocket = (uid, id) => db.prepare("SELECT * FROM pockets WHERE id = ? AND uid = ? AND status = 'active'").get(String(id || ''), uid) ?? bad('pocket_not_found', 404);
  function createPocket(uid, i) {
    const name = str(i.name, { max: 30, code: 'bad_name' }); const currency = oneOf(i.currency, MONEY, 'bad_currency');
    const goal = i.goal == null || i.goal === '' ? null : (toMinor(i.goal, currency) ?? bad('bad_amount'));
    const color = COLORS.includes(i.color) ? i.color : 'violet';
    return commit(() => {
      if (db.prepare("SELECT COUNT(*) c FROM pockets WHERE uid = ? AND status = 'active'").get(uid).c >= cfg.maxPockets) bad('too_many_pockets', 429);
      const id = rid('pkt');
      db.prepare('INSERT INTO pockets (id, uid, currency, name, goal, color, status, created_at) VALUES (?,?,?,?,?,?,?,?)').run(id, uid, currency, name, goal, color, 'active', now());
      A.log(uid, 'pocket.create', id, { currency });
      return pocketView(db.prepare('SELECT * FROM pockets WHERE id = ?').get(id));
    });
  }
  function updatePocket(uid, id, i) {
    return commit(() => {
      const p = getPocket(uid, id);
      const name = i.name != null ? str(i.name, { max: 30, code: 'bad_name' }) : p.name;
      const goal = i.goal === undefined ? p.goal : i.goal === null || i.goal === '' ? null : (toMinor(i.goal, p.currency) ?? bad('bad_amount'));
      const color = COLORS.includes(i.color) ? i.color : p.color;
      db.prepare('UPDATE pockets SET name = ?, goal = ?, color = ? WHERE id = ?').run(name, goal, color, p.id);
      return pocketView(db.prepare('SELECT * FROM pockets WHERE id = ?').get(p.id));
    });
  }
  function deletePocket(uid, id) {
    return commit(() => {
      const p = getPocket(uid, id);
      if (L.account(uid, p.currency, 'pocket', p.id).balance !== 0) bad('pocket_not_empty', 409);
      if (db.prepare("SELECT 1 FROM save_rules WHERE pocket_id = ? AND status != 'deleted'").get(p.id)) bad('pocket_has_rules', 409);
      if (db.prepare("SELECT 1 FROM vcards WHERE pocket_id = ? AND status != 'closed'").get(p.id)) bad('pocket_has_cards', 409);
      db.prepare("UPDATE pockets SET status = 'deleted' WHERE id = ?").run(p.id);
      A.log(uid, 'pocket.delete', p.id, {}); return { ok: true };
    });
  }
  /** wallet ⇄ pocket. Inside or outside a transaction (inner=true when called from another commit). */
  function movePocketRaw(uid, p, direction, amount, key, meta = {}) {
    const w = L.account(uid, p.currency, 'wallet'); const k = L.account(uid, p.currency, 'pocket', p.id);
    return L.post({ type: direction === 'in' ? 'pocket_in' : 'pocket_out', uid, currency: p.currency, amount, idem: key, meta: { pocketId: p.id, ...meta },
      legs: direction === 'in' ? [{ acc: w, delta: -amount }, { acc: k, delta: amount }] : [{ acc: k, delta: -amount }, { acc: w, delta: amount }] });
  }
  function movePocket(uid, i) {
    const direction = oneOf(i.direction, ['in', 'out'], 'bad_direction'); const key = idemOk(i.idem);
    return commit(() => {
      const p = getPocket(uid, i.pocketId);
      const amount = toMinor(i.amount, p.currency) ?? bad('bad_amount');
      const tx = movePocketRaw(uid, p, direction, amount, key);
      if (!tx.replay) A.log(uid, `pocket.${direction}`, p.id, { amount });
      return { txn: tx.id, pocket: pocketView(p) };
    }, uid);
  }

  /* ── vault (time-locked) ── */
  const vaultBalance = (uid, c) => L.account(uid, c, 'vault').balance;
  const openReleases = (uid, c) => db.prepare("SELECT COALESCE(SUM(amount),0) s FROM vault_releases WHERE uid = ? AND currency = ? AND status IN ('awaiting_approvals','locked')").get(uid, c).s;
  const relView = (r) => ({ id: r.id, currency: r.currency, amount: r.amount, status: r.status, unlockAt: r.unlock_at, createdAt: r.created_at });
  function vault(uid) {
    return { balances: MONEY.map((c) => ({ currency: c, balance: vaultBalance(uid, c), releasing: openReleases(uid, c) })), delayHours: cfg.vaultDelay / 3600_000,
      releases: db.prepare('SELECT * FROM vault_releases WHERE uid = ? ORDER BY created_at DESC LIMIT 20').all(uid).map(relView) };
  }
  function vaultDeposit(uid, i) {
    const currency = oneOf(i.currency, MONEY, 'bad_currency'); const key = idemOk(i.idem);
    const amount = toMinor(i.amount, currency) ?? bad('bad_amount');
    return commit(() => {
      const tx = L.post({ type: 'vault_in', uid, currency, amount, idem: key, meta: {},
        legs: [{ acc: L.account(uid, currency, 'wallet'), delta: -amount }, { acc: L.account(uid, currency, 'vault'), delta: amount }] });
      if (!tx.replay) A.log(uid, 'vault.in', tx.id, { currency, amount });
      return { txn: tx.id };
    }, uid);
  }
  function vaultRelease(uid, i) {
    const currency = oneOf(i.currency, MONEY, 'bad_currency');
    const amount = toMinor(i.amount, currency) ?? bad('bad_amount');
    ctx.security.assertNotFrozen(uid);
    let needed = 0;
    const out = commit(() => {
      if (openReleases(uid, currency) + amount > vaultBalance(uid, currency)) bad('insufficient_funds', 409);
      if (db.prepare("SELECT COUNT(*) c FROM vault_releases WHERE uid = ? AND status IN ('awaiting_approvals','locked')").get(uid).c >= 5) bad('too_many_releases', 429);
      const id = rid('vrl'); const t = now();
      needed = ctx.security.needsApproval(uid, currency, amount);
      const status = needed ? 'awaiting_approvals' : 'locked';
      const apr = needed ? ctx.security.openApproval(uid, 'vault_release', id, currency, amount, needed) : null;
      db.prepare('INSERT INTO vault_releases (id, uid, currency, amount, status, unlock_at, approval_id, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(id, uid, currency, amount, status, t + cfg.vaultDelay, apr, t, t);
      A.log(uid, 'vault.release_request', id, { currency, amount, needed });
      return relView(db.prepare('SELECT * FROM vault_releases WHERE id = ?').get(id));
    }, uid);
    ctx.notify(uid, 'vault_release_started', { amount, currency });
    if (needed) for (const a of ctx.security.approverUids(uid)) ctx.notify(a, 'approval_needed');
    return out;
  }
  function cancelVaultRelease(uid, id) {
    return commit(() => {
      const r = db.prepare('SELECT * FROM vault_releases WHERE id = ? AND uid = ?').get(String(id || ''), uid) ?? bad('not_found', 404);
      if (!['awaiting_approvals', 'locked'].includes(r.status)) bad('bad_state', 409);
      db.prepare("UPDATE vault_releases SET status = 'cancelled', updated_at = ? WHERE id = ?").run(now(), r.id);
      ctx.security.cancelApprovalFor('vault_release', r.id);
      A.log(uid, 'vault.release_cancel', r.id, {}); return { ok: true };
    }, uid);
  }
  ctx.approvalTargets.vault_release = {
    approved: (a) => db.prepare("UPDATE vault_releases SET status = 'locked', unlock_at = ?, updated_at = ? WHERE id = ? AND status = 'awaiting_approvals'").run(now() + cfg.vaultDelay, now(), a.target_id),
    rejected: (a) => db.prepare("UPDATE vault_releases SET status = 'rejected', updated_at = ? WHERE id = ? AND status = 'awaiting_approvals'").run(now(), a.target_id),
  };
  function runVault() {
    const due = db.prepare("SELECT * FROM vault_releases WHERE status = 'locked' AND unlock_at <= ? LIMIT 100").all(now());
    for (const r of due) {
      if (ctx.security.isFrozen(r.uid)) continue;   // frozen accounts keep the lock until unfrozen
      let ok = false;
      try {
        commit(() => {
          const cur = db.prepare("SELECT * FROM vault_releases WHERE id = ? AND status = 'locked'").get(r.id); if (!cur) return;
          const tx = L.post({ type: 'vault_out', uid: r.uid, currency: r.currency, amount: r.amount, idem: `vr:${r.id}`, meta: { releaseId: r.id },
            legs: [{ acc: L.account(r.uid, r.currency, 'vault'), delta: -r.amount }, { acc: L.account(r.uid, r.currency, 'wallet'), delta: r.amount }] });
          db.prepare("UPDATE vault_releases SET status = 'released', txn_id = ?, updated_at = ? WHERE id = ?").run(tx.id, now(), r.id);
          A.log('system', 'vault.released', r.id, {}); ok = true;
        }, r.uid);
      } catch { db.prepare("UPDATE vault_releases SET status = 'failed', updated_at = ? WHERE id = ? AND status = 'locked'").run(now(), r.id); }
      if (ok) ctx.notify(r.uid, 'vault_released', { amount: r.amount, currency: r.currency });
    }
  }

  /* ── labels ── */
  function setLabel(uid, txnId, i) {
    const t = db.prepare('SELECT id FROM txns WHERE id = ? AND uid = ?').get(String(txnId || ''), uid) ?? bad('not_found', 404);
    const category = i.category == null || i.category === '' ? null : CATEGORIES.includes(i.category) ? i.category : str(i.category, { max: 24, re: /^[\p{L}\p{N} _-]+$/u, code: 'bad_category' });
    const tags = Array.isArray(i.tags) ? [...new Set(i.tags.map((x) => str(String(x), { max: 24, re: /^[\p{L}\p{N}_-]+$/u, code: 'bad_tag' })))].slice(0, 5) : [];
    const note = i.note == null || i.note === '' ? null : str(i.note, { max: 200, code: 'bad_note' });
    return commit(() => {
      if (!category && !tags.length && !note) db.prepare('DELETE FROM txn_labels WHERE txn_id = ? AND uid = ?').run(t.id, uid);
      else db.prepare(`INSERT INTO txn_labels (txn_id, uid, category, tags, note, updated_at) VALUES (?,?,?,?,?,?)
        ON CONFLICT(txn_id) DO UPDATE SET category = excluded.category, tags = excluded.tags, note = excluded.note, updated_at = excluded.updated_at`)
        .run(t.id, uid, category, JSON.stringify(tags), note ? seal(note, `note:${uid}`) : null, now());
      return { ok: true, label: { category, tags, note } };
    });
  }
  /** history() with the user's own notes decrypted (only ever for that user). */
  const openNote = (uid, sealed) => { try { return sealed ? open(sealed, `note:${uid}`) : null; } catch { return null; } };

  return { listPockets, createPocket, updatePocket, deletePocket, movePocket, movePocketRaw, getPocket, vault, vaultDeposit, vaultRelease, cancelVaultRelease, runVault, setLabel, openNote, vaultBalance };
}
