// Tamper-evident audit trail: every row's hash covers the previous row's hash, so editing or removing a row breaks the chain.
// (SQL triggers also refuse UPDATE/DELETE.) Details are small, non-sensitive facts: never put PII or secrets in them.
import crypto from 'node:crypto';

const h = (prev, row) => crypto.createHash('sha256').update(prev).update('\n').update(JSON.stringify(row)).digest('hex');
const clip = (v, n) => String(v ?? '').slice(0, n);

export function createAudit(db, now = Date.now) {
  const last = db.prepare('SELECT hash FROM audit ORDER BY seq DESC LIMIT 1');
  const ins = db.prepare('INSERT INTO audit (ts, actor, action, target, detail, prev, hash) VALUES (?,?,?,?,?,?,?)');
  return {
    /** Must run inside the caller's transaction when it records a money/state change (so both commit or neither). */
    log(actor, action, target = '', detail = {}) {
      const prev = last.get()?.hash || 'GENESIS';
      const row = { ts: now(), actor: clip(actor, 128), action: clip(action, 64), target: clip(target, 128), detail: clip(JSON.stringify(detail), 1000) };
      ins.run(row.ts, row.actor, row.action, row.target, row.detail, prev, h(prev, row));
    },
    verify() {
      let prev = 'GENESIS'; let n = 0;
      for (const r of db.prepare('SELECT * FROM audit ORDER BY seq').all()) {
        const row = { ts: r.ts, actor: r.actor, action: r.action, target: r.target, detail: r.detail };
        if (r.prev !== prev || r.hash !== h(prev, row)) return { ok: false, brokenAt: r.seq, rows: n };
        prev = r.hash; n++;
      }
      return { ok: true, rows: n };
    },
    recent: (limit = 100) => db.prepare('SELECT seq, ts, actor, action, target, detail FROM audit ORDER BY seq DESC LIMIT ?').all(Math.min(500, limit)),
  };
}
