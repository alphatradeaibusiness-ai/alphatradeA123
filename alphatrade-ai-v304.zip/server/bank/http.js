// HTTP API of the bank. Every route: same-origin check, rate limit, verified Firebase user with a verified email, strict JSON,
// per-user data isolation (the user id comes from the verified token, never from the request). Money-moving and personal-data
// routes also need a recent sign-in (step-up) and, in live mode, a second factor. Admin routes: the verified site owner only.
import crypto from 'node:crypto';
import { BankError } from './validate.js';
import { toMinor, CURRENCIES } from './money.js';
import { validIban } from './validate.js';

const LIMITS = { ip: 600, user: 300, write: 60 };   // per minute (the bank page makes several reads per tab)

export function createBankHttp({ bank, requireUser, isOwner, originOk, send, readBody, clientIp, env = process.env, now = Date.now }) {
  const live = bank.mode === 'live';
  // An empty or invalid value (e.g. compose passing "") means "use the safe default", never "off".
  const envStr = (k) => String(env[k] ?? '').trim();
  const reauthRaw = envStr('BANK_REAUTH_MINUTES'); const reauthNum = Number(reauthRaw);
  const reauthMin = reauthRaw !== '' && Number.isFinite(reauthNum) && reauthNum >= 0 ? reauthNum : (live ? 15 : 0);   // 0 = off (sandbox default)
  const mfaRaw = envStr('BANK_REQUIRE_MFA');
  const needMfa = mfaRaw === '1' || mfaRaw === '0' ? mfaRaw === '1' : live;
  const hits = new Map();
  const limited = (key, max) => {
    const t = now(); const arr = (hits.get(key) || []).filter((x) => t - x < 60_000);
    if (arr.length >= max) { hits.set(key, arr); return true; }
    arr.push(t); hits.set(key, arr); if (hits.size > 5000) for (const [k, v] of hits) if (!v.length || t - v.at(-1) > 60_000) hits.delete(k);
    return false;
  };
  const stepUp = (user) => {
    if (reauthMin > 0 && (!user.authTime || now() / 1000 - user.authTime > reauthMin * 60)) throw new BankError('reauth_required', 401);
    if (needMfa && !user.mfa) throw new BankError('mfa_required', 403);
  };
  const body = async (req) => {
    if (!/^application\/json/i.test(req.headers['content-type'] || '')) throw new BankError('json_required', 415);
    try { const b = JSON.parse(await readBody(req, 16 * 1024)); if (!b || typeof b !== 'object' || Array.isArray(b)) throw 0; return b; }
    catch (e) { if (e instanceof BankError) throw e; throw new BankError(/large/i.test(String(e?.message)) ? 'too_large' : 'bad_json', /large/i.test(String(e?.message)) ? 413 : 400); }
  };
  const streams = new Map();

  /* ── passkeys: relying party from the (already origin-checked) request, or fixed by env ── */
  const rp = (req) => {
    const origin = String(req.headers.origin || ''); let host = ''; try { host = new URL(origin).hostname; } catch { /* none */ }
    const rpId = envStr('BANK_RP_ID') || host || String(req.headers.host || '').split(':')[0];
    const origins = envStr('BANK_ORIGINS') ? envStr('BANK_ORIGINS').split(',').map((x) => x.trim()).filter(Boolean) : origin ? [origin] : [];
    return { rpId, origins };
  };
  const minor = (v, c) => (CURRENCIES[c] ? toMinor(v, c) : null);
  /** What a passkey signature is bound to, per purpose — the SAME function builds it for the challenge and for the action. */
  const paramsFor = (purpose, b = {}) => ({
    withdraw: () => ({ currency: b.currency, amount: minor(b.amount, b.currency), beneficiaryId: b.beneficiaryId }),
    beneficiary_add: () => ({ currency: b.currency, iban: b.iban ? validIban(b.iban) || String(b.iban) : null, address: b.address, network: b.network }),
    beneficiary_remove: () => ({ id: b.id }),
    vault_release: () => ({ currency: b.currency, amount: minor(b.amount, b.currency) }),
    intl_transfer: () => ({ quoteId: b.quoteId }),
    approval_vote: () => ({ id: b.id, decision: b.decision }),
    passkey_add: () => ({}), passkey_remove: () => ({ id: b.id }), card_reveal: () => ({ id: b.id }),
    vcard_create: () => ({ kind: b.kind || 'standard', merchant: b.merchant, pocketId: b.pocketId }),
    card_limits: () => ({ id: b.id, tx: b.limitTx, day: b.limitDay, month: b.limitMonth }),
    policy_set: () => ({ enabled: b.enabled === true, needed: b.needed, threshold: b.threshold || {} }),
    unfreeze: () => ({}), approver_remove: () => ({ ref: b.ref }), redeem: () => ({ points: b.points }), ob_link: () => ({ institution: b.institution }),
  }[purpose] || (() => { throw new BankError('bad_purpose'); }))();
  /** Sensitive action: a passkey assertion when the user has passkeys (that IS the strong factor), else the sign-in step-up. */
  /** Authenticator-app code (or a backup code) for users who have TOTP and no passkey. Passkeys, when present, take priority. */
  const totpGate = (user, b) => {
    if (bank.security.passkeys.count(user.uid) || !bank.totp.enabled(user.uid)) return false;
    if (reauthMin > 0 && (!user.authTime || now() / 1000 - user.authTime > reauthMin * 60)) throw new BankError('reauth_required', 401);
    return bank.totp.require(user.uid, typeof b?.passkey === 'string' ? b.passkey : (typeof b?.totp === 'string' ? b.totp : ''));
  };
  /** Owner console: with an authenticator app on, one code unlocks the admin routes for ADMIN_UNLOCK_MIN minutes (in memory only). */
  const adminUnlock = new Map();
  const unlockMs = Math.max(1, Math.min(60, Number(env.BANK_ADMIN_UNLOCK_MIN) || 15)) * 60_000;
  const adminTotp = (uid) => {
    if (!bank.totp.enabled(uid)) return;
    const until = adminUnlock.get(uid) || 0;
    if (until > now()) return;
    adminUnlock.delete(uid);
    throw new BankError('totp_required', 401);
  };
  const gate = (req, user, purpose, b) => {
    if (totpGate(user, b)) return true;
    const r = bank.security.passkeys.verifyStep(user.uid, purpose, paramsFor(purpose, b), b.passkey, rp(req));
    if (!r.used) stepUp(user);
    return r.used;
  };
  /** Card issuer webhook signature: header `x-issuer-signature: t=<unix seconds>,v1=<hex HMAC-SHA256(secret, "<t>.<raw body>")>`. */
  async function issuerWebhook(req, res) {
    const secret = envStr('BANK_ISSUER_WEBHOOK_SECRET');
    if (secret.length < 32) return send(res, 404, { error: 'not_found', code: 'not_found' });
    if (req.method !== 'POST') return send(res, 405, { error: 'method_not_allowed', code: 'method_not_allowed' });
    if (limited(`wh:${clientIp(req)}`, 600)) return send(res, 429, { error: 'rate_limited', code: 'rate_limited' });
    const raw = await readBody(req, 16 * 1024);
    const sig = String(req.headers['x-issuer-signature'] || ''); const t = Number((/t=(\d+)/.exec(sig) || [])[1]); const v1 = (/v1=([0-9a-f]{64})/.exec(sig) || [])[1];
    if (!t || !v1 || Math.abs(now() / 1000 - t) > 300) return send(res, 401, { error: 'bad_signature', code: 'bad_signature' });
    const want = crypto.createHmac('sha256', secret).update(`${t}.${raw}`).digest('hex');
    if (!crypto.timingSafeEqual(Buffer.from(want), Buffer.from(v1))) return send(res, 401, { error: 'bad_signature', code: 'bad_signature' });
    let ev; try { ev = JSON.parse(raw); } catch { return send(res, 400, { error: 'bad_json', code: 'bad_json' }); }
    return send(res, 200, bank.vcards.issuerEvent(ev));
  }

  /** @returns {Promise<boolean>} true when the request was a bank route (and has been answered). */
  return async function handle(req, res, pathname, qs) {
    if (!pathname.startsWith('/api/bank/')) return false;
    const route = pathname.slice('/api/bank'.length);
    try {
      if (route === '/issuer/webhook') return await issuerWebhook(req, res), true;
      if (route === '/status' && req.method === 'GET') {
        let user = null; try { user = await softUser(req); } catch { /* anonymous */ }
        return send(res, 200, { enabled: true, mode: bank.mode, reauthMinutes: reauthMin, mfaRequired: needMfa, owner: Boolean(user && isOwner(user)),
          passkeys: user ? bank.security.passkeys.count(user.uid) : 0, totp: user ? bank.totp.enabled(user.uid) : false, frozen: user ? bank.security.isFrozen(user.uid) : false,
          features: { issuer: bank.issuerName(), openBanking: bank.ob.institutions().provider, openBankingDemo: bank.ob.institutions().demo, cashback: bank.rewards.summary(user?.uid || '-').cashbackAvailable, push: true } }), true;
      }
      // Reads: same-origin browser GETs carry no Origin header, so only a present Origin is checked (the bearer token is the
      // real guard — it is never sent automatically by a browser). Writes always need an allowed Origin (or the access token).
      const safeMethod = req.method === 'GET' || req.method === 'HEAD';
      if (safeMethod && req.headers['sec-fetch-site'] === 'cross-site' && !req.headers.origin) return send(res, 403, { error: 'Origin not allowed' }), true;
      if (safeMethod ? (req.headers.origin && !originOk(req, res)) : !originOk(req, res)) return true;
      if (limited(`ip:${clientIp(req)}`, LIMITS.ip)) return send(res, 429, { error: 'rate_limited', code: 'rate_limited' }), true;
      const user = await requireUser(req, res); if (!user) return true;
      if (!user.emailVerified) return send(res, 403, { error: 'email_not_verified', code: 'email_not_verified' }), true;
      if (limited(`u:${user.uid}`, LIMITS.user)) return send(res, 429, { error: 'rate_limited', code: 'rate_limited' }), true;
      const uid = user.uid; const m = req.method; const ok = (v) => send(res, 200, v);
      const write = () => { if (limited(`w:${uid}`, LIMITS.write)) throw new BankError('rate_limited', 429); };
      const optBody = async () => (/json/i.test(req.headers['content-type'] || '') ? body(req) : {});
      const withIdem = async () => { const b = await body(req); return { ...b, idem: req.headers['idempotency-key'] ?? b.idem }; };   // header preferred, body field accepted
      let r;

      /* ── admin: the verified site owner only, always with step-up ── */
      if (route.startsWith('/admin/')) {
        if (!isOwner(user)) throw new BankError('not_owner', 403);
        stepUp(user); if (m !== 'GET') write();
        const actor = { uid, email: user.email };
        if (route === '/admin/unlock' && m === 'POST') {
          const b = await body(req); const code = typeof b.code === 'string' ? b.code : '';
          if (!bank.totp.enabled(uid)) return ok({ ok: true, until: null }), true;
          bank.totp.require(uid, code); const until = now() + unlockMs; adminUnlock.set(uid, until);
          return ok({ ok: true, until }), true;
        }
        if (route === '/admin/lock' && m === 'POST') { adminUnlock.delete(uid); return ok({ ok: true }), true; }
        adminTotp(uid);
        if ((r = /^\/admin\/(queue|audit|verify)$/.exec(route)) && m === 'GET') {
          if (r[1] === 'queue') return ok(bank.adminQueue()), true;
          if (r[1] === 'audit') return ok({ rows: bank.audit.recent(Number(qs.get('limit')) || 100) }), true;
          return ok({ ledger: bank.ledger.verify(), audit: bank.audit.verify() }), true;
        }
        if ((r = /^\/admin\/deposits\/([\w-]+)\/(confirm|reject)$/.exec(route)) && m === 'POST') {
          const b = await body(req);
          return ok(r[2] === 'confirm' ? bank.confirmDeposit(actor, r[1], { extRef: b.extRef, received: b.received }) : bank.rejectDeposit(actor, r[1], b.reason)), true;
        }
        if ((r = /^\/admin\/withdrawals\/([\w-]+)\/(approve|reject|complete)$/.exec(route)) && m === 'POST') {
          const b = await body(req);
          return ok(r[2] === 'complete' ? bank.completeWithdrawal(actor, r[1], { extRef: b.extRef }) : bank.reviewWithdrawal(actor, r[1], r[2], b.note)), true;
        }
        if ((r = /^\/admin\/withdrawals\/([\w-]+)\/destination$/.exec(route)) && m === 'GET') return ok(bank.withdrawalDestination(actor, r[1])), true;
        if ((r = /^\/admin\/kyc\/([\w-]+)$/.exec(route)) && m === 'GET') return ok(bank.kycDetail(actor, r[1])), true;
        if ((r = /^\/admin\/kyc\/([\w-]+)\/(approve|reject)$/.exec(route)) && m === 'POST') { const b = await body(req); return ok(bank.reviewKyc(actor, r[1], r[2], b.reason)), true; }
        if ((r = /^\/admin\/cards\/([\w-]+)$/.exec(route)) && m === 'GET') return ok(bank.cardDetail(actor, r[1])), true;
        if ((r = /^\/admin\/cards\/([\w-]+)\/update$/.exec(route)) && m === 'POST') { const b = await body(req); return ok(bank.updateCard(actor, r[1], { status: b.status, tracking: b.tracking })), true; }
        if (route === '/admin/rewrap' && m === 'POST') { const b = await body(req); totpGate(user, b); return ok(bank.rewrapAll(uid)), true; }
        if (route === '/admin/risk' && m === 'GET') return ok({ items: bank.risk.list({ level: qs.get('level') || null, open: qs.get('open') === '1' }) }), true;
        if ((r = /^\/admin\/risk\/([\w-]+)\/review$/.exec(route)) && m === 'POST') { const b = await body(req); return ok(bank.risk.review(uid, r[1], b.note)), true; }
        if (route === '/admin/compliance' && m === 'GET') return ok({ items: bank.compliance.list() }), true;
        if (route === '/admin/compliance/run' && m === 'POST') { const b = await body(req); return ok(await bank.compliance.adhoc(Number(b.from), Number(b.to))), true; }
        if ((r = /^\/admin\/compliance\/([\w-]+)(\.csv)?$/.exec(route)) && m === 'GET') {
          const rep = bank.compliance.get(r[1]);
          if (!r[2]) return ok(rep), true;
          res.writeHead(200, { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="compliance-${rep.period.replace(/[^\w-]/g, '_')}.csv"`, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
          return res.end(bank.compliance.toCsv(rep)), true;
        }
        if (route === '/admin/dashboard' && m === 'GET') return ok(bank.insights.ownerDashboard()), true;
        if (route === '/admin/tickets' && m === 'GET') return ok({ items: bank.support.adminList() }), true;
        if ((r = /^\/admin\/tickets\/([\w-]+)$/.exec(route)) && m === 'GET') return ok(bank.support.adminView(actor, r[1])), true;
        if ((r = /^\/admin\/tickets\/([\w-]+)\/reply$/.exec(route)) && m === 'POST') return ok(bank.support.adminReply(actor, r[1], await body(req))), true;
        return send(res, 404, { error: 'not_found', code: 'not_found' }), true;
      }

      /* ── the signed-in user's own data ── */
      if (route === '/wallet' && m === 'GET') return ok({ mode: bank.mode, wallets: bank.wallet(uid), kyc: bank.kycStatus(uid) }), true;
      if (route === '/history' && m === 'GET') return ok(bank.history(uid, { limit: Number(qs.get('limit')) || 30, before: qs.get('before'), type: qs.get('type'), currency: qs.get('currency') })), true;
      if (route === '/stream' && m === 'GET') return openStream(req, res, uid, user), true;

      if (route === '/sandbox/fund' && m === 'POST') { write(); return ok(bank.sandboxFund(uid, await withIdem())), true; }
      if (route === '/deposits') { if (m === 'GET') return ok({ items: bank.listDeposits(uid) }), true; if (m === 'POST') { write(); return ok(bank.requestDeposit(uid, await withIdem())), true; } }

      if (route === '/beneficiaries') {
        if (m === 'GET') return ok({ items: bank.listBeneficiaries(uid) }), true;
        if (m === 'POST') { write(); const b = await body(req); gate(req, user, 'beneficiary_add', b); return ok(bank.addBeneficiary(uid, b)), true; }
      }
      if ((r = /^\/beneficiaries\/([\w-]+)$/.exec(route)) && m === 'DELETE') { write(); const b = await optBody(); gate(req, user, 'beneficiary_remove', { ...b, id: r[1] }); return ok(bank.removeBeneficiary(uid, r[1])), true; }

      if (route === '/withdrawals') {
        if (m === 'GET') return ok({ items: bank.listWithdrawals(uid) }), true;
        if (m === 'POST') { write(); const b = await withIdem(); gate(req, user, 'withdraw', b); return ok(bank.requestWithdrawal(uid, b)), true; }
      }
      if ((r = /^\/withdrawals\/([\w-]+)\/cancel$/.exec(route)) && m === 'POST') { write(); return ok(bank.cancelWithdrawal(uid, r[1])), true; }

      if (route === '/kyc') {
        if (m === 'GET') return ok(bank.kycStatus(uid)), true;
        if (m === 'POST') { write(); stepUp(user); const b = await body(req); totpGate(user, b); return ok(bank.submitKyc(uid, b)), true; }
      }
      if (route === '/cards') {
        if (m === 'GET') return ok({ items: bank.listCards(uid) }), true;
        if (m === 'POST') { write(); stepUp(user); const b = await withIdem(); totpGate(user, b); return ok(bank.requestCard(uid, b)), true; }
      }
      if ((r = /^\/cards\/([\w-]+)\/(activate|freeze|unfreeze|cancel)$/.exec(route)) && m === 'POST') {
        write(); if (r[2] !== 'cancel') { stepUp(user); totpGate(user, await optBody()); }
        return ok(r[2] === 'cancel' ? bank.cancelCard(uid, r[1]) : bank.cardAction(uid, r[1], r[2])), true;
      }

      if (route === '/plans') {
        if (m === 'GET') return ok({ items: bank.listPlans(uid), mode: bank.mode }), true;
        if (m === 'POST') { write(); return ok(bank.createPlan(uid, await body(req))), true; }
      }
      if ((r = /^\/plans\/([\w-]+)\/(pause|resume|delete)$/.exec(route)) && m === 'POST') { write(); return ok(bank.setPlan(uid, r[1], r[2])), true; }
      if (route === '/orders' && m === 'GET') return ok({ items: bank.listOrders(uid) }), true;
      if (route === '/holdings' && m === 'GET') return ok({ items: bank.holdings(uid), mode: bank.mode }), true;
      if (route === '/holdings/sell' && m === 'POST') { write(); return ok(await bank.insights.sell(uid, await withIdem())), true; }

      /* ── v150: pockets, vault, labels ── */
      const P = bank.pockets; const S = bank.security; const V = bank.vcards; const N = bank.notifications;
      if (route === '/pockets') { if (m === 'GET') return ok({ items: P.listPockets(uid) }), true; if (m === 'POST') { write(); return ok(P.createPocket(uid, await body(req))), true; } }
      if (route === '/pockets/move' && m === 'POST') { write(); return ok(P.movePocket(uid, await withIdem())), true; }
      if ((r = /^\/pockets\/([\w-]+)$/.exec(route))) { if (m === 'POST') { write(); return ok(P.updatePocket(uid, r[1], await body(req))), true; } if (m === 'DELETE') { write(); return ok(P.deletePocket(uid, r[1])), true; } }
      if (route === '/vault' && m === 'GET') return ok(P.vault(uid)), true;
      if (route === '/vault/deposit' && m === 'POST') { write(); return ok(P.vaultDeposit(uid, await withIdem())), true; }
      if (route === '/vault/release' && m === 'POST') { write(); const b = await body(req); gate(req, user, 'vault_release', b); return ok(P.vaultRelease(uid, b)), true; }
      if ((r = /^\/vault\/releases\/([\w-]+)\/cancel$/.exec(route)) && m === 'POST') { write(); return ok(P.cancelVaultRelease(uid, r[1])), true; }
      if ((r = /^\/history\/([\w-]+)\/label$/.exec(route)) && m === 'POST') { write(); return ok(P.setLabel(uid, r[1], await body(req))), true; }

      /* ── passkeys, freeze, co-signers ── */
      if (route === '/passkeys' && m === 'GET') return ok({ items: S.passkeys.list(uid) }), true;
      if (route === '/passkeys/register-options' && m === 'POST') { write(); return ok(S.passkeys.registrationOptions(uid, { email: user.email, rpId: rp(req).rpId })), true; }
      if (route === '/passkeys/register' && m === 'POST') {
        write(); const b = await body(req);
        if (S.passkeys.count(uid)) gate(req, user, 'passkey_add', b); else stepUp(user);   // adding a 2nd passkey needs the 1st
        return ok(S.passkeys.register(uid, b, rp(req))), true;
      }
      if (route === '/passkeys/challenge' && m === 'POST') { write(); const b = await body(req); return ok(S.passkeys.assertionOptions(uid, b.purpose, paramsFor(String(b.purpose || ''), b.params || {}), rp(req))), true; }
      if ((r = /^\/passkeys\/([\w-]+)$/.exec(route)) && m === 'DELETE') { write(); const b = await optBody(); gate(req, user, 'passkey_remove', { ...b, id: r[1] }); return ok(S.passkeys.remove(uid, r[1])), true; }
      /* ── authenticator-app two-factor (TOTP) + risk view ── */
      if (route === '/totp' && m === 'GET') return ok(bank.totp.status(uid)), true;
      if (route === '/totp/enroll' && m === 'POST') { write(); stepUp(user); return ok(bank.totp.enroll(uid, user.email)), true; }
      if (route === '/totp/confirm' && m === 'POST') { write(); stepUp(user); return ok(bank.totp.confirm(uid, (await body(req)).code)), true; }
      if (route === '/totp/disable' && m === 'POST') { write(); stepUp(user); const b = await body(req); return ok(bank.totp.disable(uid, b.code ?? b.passkey)), true; }
      if (route === '/totp/backup-codes' && m === 'POST') { write(); stepUp(user); const b = await body(req); return ok(bank.totp.newBackupCodes(uid, b.code ?? b.passkey)), true; }
      if (route === '/risk' && m === 'GET') return ok({ items: bank.risk.forUser(uid).map(({ id, kind, level, createdAt }) => ({ id, kind, level, createdAt })) }), true;
      if (route === '/freeze' && m === 'POST') { write(); const b = await body(req); if (b.on === false) gate(req, user, 'unfreeze', b); return ok(S.setFrozen(uid, b.on !== false)), true; }
      if (route === '/approvals' && m === 'GET') return ok({ ...S.approvers(uid), pending: S.pendingForMe(uid), requests: S.myApprovals(uid) }), true;
      if (route === '/approvals/policy' && m === 'POST') { write(); const b = await body(req); gate(req, user, 'policy_set', b); return ok(S.setPolicy(uid, b)), true; }
      if (route === '/approvals/invite' && m === 'POST') { write(); stepUp(user); const b = await body(req); totpGate(user, b); return ok(S.invite(uid, b.label)), true; }
      if (route === '/approvals/accept' && m === 'POST') { write(); return ok(S.acceptInvite(uid, (await body(req)).code)), true; }
      if ((r = /^\/approvals\/approvers\/([0-9a-f]{10})$/.exec(route)) && m === 'DELETE') { write(); const b = await optBody(); gate(req, user, 'approver_remove', { ...b, ref: r[1] }); return ok(S.removeApprover(uid, r[1])), true; }
      if ((r = /^\/approvals\/([\w-]+)\/vote$/.exec(route)) && m === 'POST') { write(); const b = await body(req); const used = gate(req, user, 'approval_vote', { ...b, id: r[1] }); return ok(S.vote(uid, r[1], b.decision, used)), true; }

      /* ── virtual cards, merchants, subscriptions ── */
      if (route === '/vcards') {
        if (m === 'GET') return ok({ items: V.list(uid), issuer: bank.issuerName(), applePay: V.applePay() }), true;
        if (m === 'POST') { write(); const b = await body(req); gate(req, user, 'vcard_create', b); return ok(V.create(uid, b)), true; }
      }
      if (route === '/vcards/purchases' && m === 'GET') return ok({ items: V.purchases(uid, { cardId: qs.get('card') }) }), true;
      if ((r = /^\/vcards\/auths\/([\w-]+)\/refund$/.exec(route)) && m === 'POST') { write(); return ok(V.simulateRefund(uid, r[1])), true; }
      if ((r = /^\/vcards\/([\w-]+)$/.exec(route)) && m === 'POST') { write(); const b = await body(req); gate(req, user, 'card_limits', { ...b, id: r[1] }); return ok(V.update(uid, r[1], b)), true; }
      if ((r = /^\/vcards\/([\w-]+)\/(freeze|unfreeze|close)$/.exec(route)) && m === 'POST') { write(); return ok(V.action(uid, r[1], r[2])), true; }
      if ((r = /^\/vcards\/([\w-]+)\/reveal$/.exec(route)) && m === 'POST') { write(); const b = await body(req); gate(req, user, 'card_reveal', { ...b, id: r[1] }); return ok(V.reveal(uid, r[1])), true; }
      if ((r = /^\/vcards\/([\w-]+)\/apple-wallet$/.exec(route)) && m === 'POST') { write(); const b = await body(req); gate(req, user, 'card_reveal', { ...b, id: r[1] }); return ok(V.appleWallet(uid, r[1], b)), true; }
      if ((r = /^\/vcards\/([\w-]+)\/simulate$/.exec(route)) && m === 'POST') { write(); return ok(V.simulate(uid, r[1], await body(req))), true; }
      if (route === '/merchants/blocked' && m === 'GET') return ok({ items: V.blocked(uid) }), true;
      if (route === '/merchants/block' && m === 'POST') { write(); const b = await body(req); return ok(V.block(uid, b.merchant, b.on !== false)), true; }
      if (route === '/subscriptions') { if (m === 'GET') return ok({ items: V.listSubs(uid) }), true; if (m === 'POST') { write(); return ok(V.addSub(uid, await body(req))), true; } }
      if ((r = /^\/subscriptions\/([\w-]+)\/(block|unblock|ignore|delete)$/.exec(route)) && m === 'POST') { write(); return ok(V.setSub(uid, r[1], r[2])), true; }

      /* ── budgets, saving rules, rewards ── */
      if (route === '/budgets') { if (m === 'GET') return ok(bank.planning.budgets(uid)), true; if (m === 'POST') { write(); return ok(bank.planning.setBudget(uid, await body(req))), true; } }
      if ((r = /^\/budgets\/([\w-]+)$/.exec(route)) && m === 'DELETE') { write(); return ok(bank.planning.deleteBudget(uid, r[1])), true; }
      if (route === '/rules') { if (m === 'GET') return ok({ items: bank.planning.listRules(uid) }), true; if (m === 'POST') { write(); return ok(bank.planning.createRule(uid, await body(req))), true; } }
      if ((r = /^\/rules\/([\w-]+)\/(pause|resume|delete)$/.exec(route)) && m === 'POST') { write(); return ok(bank.planning.setRule(uid, r[1], r[2])), true; }
      if (route === '/rewards' && m === 'GET') return ok(bank.rewards.summary(uid)), true;
      if (route === '/rewards/redeem' && m === 'POST') { write(); const b = await body(req); gate(req, user, 'redeem', b); return ok(bank.rewards.redeem(uid, b)), true; }

      /* ── money: rates, conversion, cross-border, open banking ── */
      if (route === '/fx/rates' && m === 'GET') return ok(await bank.fx.rates()), true;
      if (route === '/fx/calc' && m === 'GET') return ok(await bank.fx.calc({ from: qs.get('from'), to: qs.get('to'), amount: qs.get('amount') })), true;
      if (route === '/fx/convert' && m === 'POST') { write(); return ok(await bank.fx.convert(uid, await withIdem())), true; }
      if (route === '/intl/quote' && m === 'POST') { write(); return ok(await bank.fx.quoteIntl(uid, await body(req))), true; }
      if (route === '/intl/confirm' && m === 'POST') { write(); const b = await withIdem(); gate(req, user, 'intl_transfer', b); return ok(bank.fx.confirmIntl(uid, b)), true; }
      if (route === '/ob' && m === 'GET') return ok({ ...bank.ob.institutions(), links: bank.ob.links(uid) }), true;
      if (route === '/ob/link' && m === 'POST') { write(); const b = await body(req); gate(req, user, 'ob_link', b); return ok(bank.ob.link(uid, b)), true; }
      if ((r = /^\/ob\/([\w-]+)\/refresh$/.exec(route)) && m === 'POST') { write(); return ok(bank.ob.refresh(uid, r[1])), true; }
      if ((r = /^\/ob\/([\w-]+)$/.exec(route)) && m === 'DELETE') { write(); return ok(bank.ob.revoke(uid, r[1])), true; }
      if ((r = /^\/ob\/accounts\/([\w-]+)\/txns$/.exec(route)) && m === 'GET') return ok({ items: bank.ob.txns(uid, r[1]) }), true;

      /* ── insights, dashboard, tax ── */
      if (route === '/insights' && m === 'GET') return ok(bank.insights.insights(uid)), true;
      if (route === '/dashboard' && m === 'GET') return ok(await bank.insights.dashboard(uid)), true;
      if (route === '/tax' && m === 'GET') return ok(bank.insights.taxReport(uid, qs.get('year'))), true;
      if (route === '/tax.csv' && m === 'GET') {
        const csv = bank.insights.taxCsv(uid, qs.get('year'));
        res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="alphatrade-tax-${Number(qs.get('year'))}.csv"`, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
        res.end(`\ufeff${csv}`); return true;
      }

      /* ── support, notifications, push ── */
      if (route === '/tickets') { if (m === 'GET') return ok({ items: bank.support.list(uid) }), true; if (m === 'POST') { write(); return ok(bank.support.create(uid, await body(req))), true; } }
      if ((r = /^\/tickets\/([\w-]+)$/.exec(route)) && m === 'GET') return ok(bank.support.view(uid, r[1])), true;
      if ((r = /^\/tickets\/([\w-]+)\/(reply|close)$/.exec(route)) && m === 'POST') { write(); return ok(r[2] === 'reply' ? bank.support.reply(uid, r[1], await body(req)) : bank.support.close(uid, r[1])), true; }
      if (route === '/notifications' && m === 'GET') return ok(N.list(uid, { limit: Number(qs.get('limit')) || 50 })), true;
      if (route === '/notifications/read' && m === 'POST') { write(); return ok(N.markRead(uid)), true; }
      if (route === '/notifications/prefs') { if (m === 'GET') return ok(N.prefs(uid)), true; if (m === 'POST') { write(); return ok(N.setPrefs(uid, await body(req))), true; } }
      if (route === '/push/key' && m === 'GET') return ok({ publicKey: N.vapidPublicKey() }), true;
      if (route === '/push/subscribe' && m === 'POST') { write(); return ok(N.subscribe(uid, (await body(req)).subscription)), true; }
      if (route === '/push/unsubscribe' && m === 'POST') { write(); return ok(N.unsubscribe(uid, (await body(req)).endpoint)), true; }

      return send(res, 404, { error: 'not_found', code: 'not_found' }), true;
    } catch (e) {
      if (e instanceof BankError) return send(res, e.status, { error: e.code, code: e.code }), true;
      console.error('[bank] internal error:', e?.name, String(e?.message || '').slice(0, 120));   // never the request data: it can hold personal details
      return send(res, 500, { error: 'server_error', code: 'server_error' }), true;
    }
  };

  async function softUser(req) {
    if (!/^Bearer /.test(req.headers.authorization || '')) return null;
    const fake = { writeHead() {}, end() {}, headersSent: true };
    return requireUser(req, fake);
  }
  function openStream(req, res, uid, user) {
    const mine = streams.get(uid) || new Set();
    if (mine.size >= 3) return send(res, 429, { error: 'too_many_streams', code: 'too_many_streams' });
    streams.set(uid, mine); mine.add(res);
    res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Content-Type-Options': 'nosniff', 'X-Accel-Buffering': 'no' });
    const push = (ev) => res.write(`event: ${ev.type}\ndata: ${JSON.stringify({ at: ev.at })}\n\n`);
    const on = (ev) => push(ev); bank.events.on(`u:${uid}`, on); push({ type: 'balance', at: now() });
    const beat = setInterval(() => res.write(': ping\n\n'), 25_000);
    const ttl = setTimeout(() => res.end(), Math.max(60_000, (user.exp ? user.exp * 1000 - now() : 50 * 60_000)));   // tokens expire: the client reconnects with a fresh one
    const done = () => { clearInterval(beat); clearTimeout(ttl); bank.events.off(`u:${uid}`, on); mine.delete(res); };
    req.on('close', done); res.on('close', done);
  }
}
