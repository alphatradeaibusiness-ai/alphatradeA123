// v262 Telegram channel gate — only site members with an ACTIVE subscription may join or stay in the private channel.
//  • The bot (admin of the channel: "Invite users via link" + "Ban users") creates an invite link that needs approval
//    (creates_join_request). Every join request is checked against the site: the Telegram account must be linked to a site
//    account (/start link in "Notifications & connect") and that account must have an active subscription → approve;
//    otherwise → decline + a private message telling the person what to do (link the account / subscribe first).
//  • Anyone who still gets in another way (an old link, added by an admin) is checked on the chat_member update and removed
//    when not entitled.
//  • A periodic sweep removes members whose subscription ended (after an optional grace period), whose Telegram link was
//    removed, or whose site account was deleted. Removal = ban + immediate unban (they can come back after paying).
// Telegram's Bot API cannot list a channel's members: people who joined BEFORE the gate was switched on are only checked
// when they are seen (chat_member update) — revoke the old invite links so new joins go through approval.
import fs from 'node:fs';
import path from 'node:path';

const MSG = {
  link_first: ['🔒 قناة AlphaTrade AI للمشتركين بس.\n\nحسابك على تلغرام مش مربوط بحساب على الموقع. افتح الموقع ← «الإشعارات والربط» ← «اربط تليغرام»، وبعدين اطلب الانضمام مرة تانية:\n{url}/#/app/connect',
    '🔒 The AlphaTrade AI channel is for subscribers only.\n\nYour Telegram account is not linked to a site account. Open the site → “Notifications & connect” → “Link Telegram”, then request to join again:\n{url}/#/app/connect'],
  subscribe_first: ['🔒 قناة AlphaTrade AI للمشتركين بس.\n\nما عندك اشتراك فعّال على الموقع. اشترك أول، وبعدين اطلب الانضمام مرة تانية:\n{url}/#/app/pricing',
    '🔒 The AlphaTrade AI channel is for subscribers only.\n\nYou do not have an active subscription on the site. Subscribe first, then request to join again:\n{url}/#/app/pricing'],
  approved: ['✅ أهلاً فيك بقناة AlphaTrade AI! اشتراكك فعّال.', '✅ Welcome to the AlphaTrade AI channel! Your subscription is active.'],
  expired: ['⏳ انتهى اشتراكك على AlphaTrade AI، فانشالت عضويتك من القناة.\n\nجدّد اشتراكك وارجع اطلب الانضمام بأي وقت:\n{url}/#/app/pricing',
    '⏳ Your AlphaTrade AI subscription ended, so your channel membership was removed.\n\nRenew any time and request to join again:\n{url}/#/app/pricing'],
  unlinked: ['🔗 حساب التلغرام انفصل عن حسابك على الموقع، فانشالت عضويتك من القناة. اربطه من جديد واطلب الانضمام:\n{url}/#/app/connect',
    '🔗 Your Telegram account is no longer linked to a site account, so your membership was removed. Link it again and request to join:\n{url}/#/app/connect'],
};

export function createTgGate({ dir, now = Date.now, token = () => '', defaultChannel = () => '', ownerChannel = '', ownerInvite = '', entitlement = () => null, uidByTg = () => null, langOf = () => 'ar',
  publicUrl = () => '', tgBase = 'https://api.telegram.org', fetchFn = fetch, log = console } = {}) {
  const file = path.join(dir, 'tg-gate.json');
  let db = null;
  const load = () => { if (db) return db; db = { config: { enabled: false, channelId: '', inviteLink: '', kickOnExpiry: true, graceHours: 0, checkMinutes: 15, dm: true }, members: {}, events: [], lastSweep: 0 }; try { const j = JSON.parse(fs.readFileSync(file, 'utf8')); db = { ...db, ...j, config: { ...db.config, ...j.config } }; } catch { /* first start */ } return db; };
  const save = () => { fs.mkdirSync(dir, { recursive: true, mode: 0o700 }); const tmp = `${file}.${process.pid}.tmp`; fs.writeFileSync(tmp, JSON.stringify(db), { mode: 0o600 }); fs.renameSync(tmp, file); };
  const cfg = () => load().config;
  const channel = () => String(cfg().channelId || ownerChannel || defaultChannel() || '');
  const event = (type, data = {}) => { const d = load(); d.events.unshift({ at: now(), type, ...data }); if (d.events.length > 300) d.events.length = 300; };
  async function call(method, body) {
    const t = token(); if (!t) return { ok: false, error: 'no_token' };
    try {
      const r = await fetchFn(`${tgBase}/bot${t}/${method}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(12_000) });
      const j = await r.json().catch(() => ({})); return j.ok ? { ok: true, result: j.result } : { ok: false, error: String(j.description || r.status).split(t).join('***').slice(0, 160) };
    } catch (e) { return { ok: false, error: String(e?.message || e).split(t).join('***').slice(0, 120) }; }
  }
  const dm = (chatId, uidOrNull, key) => { if (!cfg().dm || !chatId) return Promise.resolve(); const ar = (uidOrNull ? langOf(uidOrNull) : 'ar') !== 'en'; return call('sendMessage', { chat_id: chatId, text: MSG[key][ar ? 0 : 1].replaceAll('{url}', publicUrl() || ''), disable_web_page_preview: true }); };
  /** Is this site account allowed in the channel right now? (active subscription, or inside the grace period) */
  function allowed(uid) {
    if (!uid) return { ok: false, why: 'link_first' };
    const e = entitlement(uid); if (e?.owner) return { ok: true };
    const until = e?.until || 0; const grace = (Number(cfg().graceHours) || 0) * 3_600_000;
    return until + grace > now() ? { ok: true, until } : { ok: false, why: 'subscribe_first' };
  }
  const sameChat = (id) => { const c = channel(); if (!c) return false; return String(id) === (c.startsWith('@') ? String(cfg().channelNumeric || '') : c); };

  async function onJoinRequest(rq) {
    const tgId = rq.from?.id; const uid = uidByTg(tgId); const a = allowed(uid);
    if (a.ok) {
      const r = await call('approveChatJoinRequest', { chat_id: rq.chat.id, user_id: tgId });
      if (r.ok) { load().members[tgId] = { uid, at: now(), via: 'request' }; event('approved', { tg: tgId, uid }); await dm(rq.user_chat_id || tgId, uid, 'approved'); }
      else event('approve_failed', { tg: tgId, error: r.error });
    } else {
      const r = await call('declineChatJoinRequest', { chat_id: rq.chat.id, user_id: tgId });
      event('declined', { tg: tgId, uid: uid || null, why: a.why, ok: r.ok }); await dm(rq.user_chat_id || tgId, uid, a.why);
    }
    save();
  }
  async function kick(tgId, uid, why) {
    const c = channel(); const b = await call('banChatMember', { chat_id: c, user_id: Number(tgId), until_date: Math.floor(now() / 1000) + 60 });
    if (b.ok) await call('unbanChatMember', { chat_id: c, user_id: Number(tgId), only_if_banned: true });
    delete load().members[tgId]; event(b.ok ? 'removed' : 'remove_failed', { tg: Number(tgId), uid: uid || null, why, error: b.ok ? undefined : b.error });
    if (b.ok) await dm(Number(tgId), uid, why === 'subscribe_first' ? 'expired' : why === 'unlinked' ? 'unlinked' : why);
    return b.ok;
  }
  async function onChatMember(cm) {
    const tgId = cm.new_chat_member?.user?.id; if (!tgId || cm.new_chat_member.user.is_bot) return;
    const st = cm.new_chat_member.status;
    if (['left', 'kicked'].includes(st)) { if (load().members[tgId]) { delete load().members[tgId]; event('left', { tg: tgId }); save(); } return; }
    if (!['member', 'restricted'].includes(st) || load().members[tgId]) return;
    const uid = uidByTg(tgId); const a = allowed(uid);
    if (a.ok) { load().members[tgId] = { uid, at: now(), via: 'joined' }; event('joined_ok', { tg: tgId, uid }); save(); }
    else await kick(tgId, uid, a.why);
    save();
  }
  /** Called by the bot's update loop (server/growth.js). Returns true when the update was handled here. */
  async function onUpdate(up) {
    if (!cfg().enabled || !token()) return false;
    try {
      if (up.chat_join_request && sameChat(up.chat_join_request.chat?.id)) { await onJoinRequest(up.chat_join_request); return true; }
      if (up.chat_member && sameChat(up.chat_member.chat?.id)) { await onChatMember(up.chat_member); return true; }
    } catch (e) { log.error?.('[tg-gate]', String(e?.message || e).slice(0, 80)); }
    return false;
  }
  /** Periodic check: remove members whose subscription ended, whose link was removed, or whose account is gone. */
  async function sweep({ force = false } = {}) {
    const c = cfg(); if (!c.enabled || !token() || !channel()) return { checked: 0, removed: 0 };
    if (!force && now() - load().lastSweep < Math.max(1, Number(c.checkMinutes) || 15) * 60_000) return { skipped: true };
    load().lastSweep = now(); let checked = 0, removed = 0;
    for (const [tgId, m] of Object.entries(load().members)) {
      checked++; const uid = uidByTg(Number(tgId));
      if (!uid || uid !== m.uid) { if (await kick(tgId, m.uid, 'unlinked')) removed++; continue; }
      if (!c.kickOnExpiry) continue;
      if (!allowed(uid).ok) { if (await kick(tgId, uid, 'subscribe_first')) removed++; }
    }
    event('sweep', { checked, removed }); save(); return { checked, removed };
  }
  async function createInvite() {
    const c = channel(); if (!c) return { error: 'no_channel' };
    const r = await call('createChatInviteLink', { chat_id: c, name: 'AlphaTrade AI — subscribers', creates_join_request: true });
    if (!r.ok) return { error: 'telegram', message: r.error };
    load().config.inviteLink = r.result.invite_link; event('invite_created', {}); save(); return { inviteLink: r.result.invite_link };
  }
  async function botRights() {
    const me = await call('getMe', {}); if (!me.ok) return { ok: false, error: me.error };
    const c = channel(); if (!c) return { ok: false, error: 'no_channel', bot: me.result.username };
    if (c.startsWith('@')) { const ch = await call('getChat', { chat_id: c }); if (ch.ok) { load().config.channelNumeric = String(ch.result.id); save(); } }
    const m = await call('getChatMember', { chat_id: c, user_id: me.result.id }); if (!m.ok) return { ok: false, error: m.error, bot: me.result.username };
    const r = m.result; return { ok: r.status === 'administrator' && r.can_invite_users !== false && r.can_restrict_members !== false, admin: r.status === 'administrator', canInvite: Boolean(r.can_invite_users), canRestrict: Boolean(r.can_restrict_members), bot: me.result.username };
  }
  function setConfig(p = {}) {
    const c = cfg();
    if ('enabled' in p) c.enabled = Boolean(p.enabled);
    if ('channelId' in p) { const v = String(p.channelId || '').trim(); if (v && !/^(-100\d{6,16}|@[A-Za-z0-9_]{5,32})$/.test(v)) return { error: 'bad_channel' }; c.channelId = v; }
    if ('kickOnExpiry' in p) c.kickOnExpiry = Boolean(p.kickOnExpiry);
    if ('dm' in p) c.dm = Boolean(p.dm);
    if ('graceHours' in p) c.graceHours = Math.max(0, Math.min(168, Math.round(Number(p.graceHours) || 0)));
    if ('checkMinutes' in p) c.checkMinutes = Math.max(5, Math.min(1440, Math.round(Number(p.checkMinutes) || 15)));
    event('config', {}); save(); return { ok: true };
  }
  const invite = () => cfg().inviteLink || ownerInvite || '';
  const status = () => ({ config: { ...cfg(), channelEffective: channel(), inviteEffective: invite() }, members: Object.keys(load().members).length, events: load().events.slice(0, 40), lastSweep: load().lastSweep, tokenSet: Boolean(token()) });
  function userView(uid, tgId) {
    const c = cfg(); const a = allowed(uid);
    return { enabled: c.enabled, linked: Boolean(tgId), active: a.ok, member: Boolean(tgId && load().members[tgId]?.uid === uid), inviteLink: c.enabled && a.ok && tgId ? invite() || null : null };
  }
  return { onUpdate, sweep, createInvite, botRights, setConfig, status, userView, allowed, _db: () => load() };
}
