// v275 — run the server as an unprivileged user even when the platform mounts the data disk as root.
// Render (and many hosts) mount persistent disks owned by root, so a Dockerfile `USER node` cannot write to them and the
// app fails at start. Instead the container starts as root, this module (imported FIRST) makes the data folders belong
// to RUN_AS_USER, then drops to that user for good — before any other module opens a file or a socket.
// Nothing happens unless the process is root AND RUN_AS_USER is set (the Dockerfiles set RUN_AS_USER=node).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function lookup(name) {
  for (const line of fs.readFileSync('/etc/passwd', 'utf8').split('\n')) {
    const f = line.split(':'); if (f[0] === name) return { uid: Number(f[2]), gid: Number(f[3]) };
  }
  return null;
}
function chownTree(dir, uid, gid) {
  let st; try { st = fs.lstatSync(dir); } catch { return; }
  if (st.isSymbolicLink()) return;                       // never follow links out of the data folders
  if (st.uid !== uid || st.gid !== gid) fs.chownSync(dir, uid, gid);
  if (st.isDirectory()) for (const e of fs.readdirSync(dir)) chownTree(path.join(dir, e), uid, gid);
}

export function dropPrivileges(env = process.env) {
  const user = env.RUN_AS_USER;
  if (!user || typeof process.getuid !== 'function' || process.getuid() !== 0) return { dropped: false };
  const id = lookup(user); if (!id) throw new Error(`RUN_AS_USER=${user} does not exist in this image`);
  const dataDir = path.resolve(env.SERVER_DATA_DIR || path.join(root, 'server-data'));
  const dirs = [dataDir, env.BACKUP_DIR, env.WORKER_DATA_DIR || (env.SERVER_DATA_DIR ? null : path.join(root, 'worker-data')), env.SERVER_NOTIFY_DIR]
    .filter(Boolean).map((d) => path.resolve(d));
  for (const d of new Set(dirs)) { fs.mkdirSync(d, { recursive: true, mode: 0o700 }); chownTree(d, id.uid, id.gid); }
  process.setgroups?.([]); process.setgid(id.gid); process.setuid(id.uid);
  if (process.getuid() !== id.uid || process.getgid() !== id.gid) throw new Error('could not drop root privileges');
  return { dropped: true, uid: id.uid, dirs: [...new Set(dirs)] };
}

const r = dropPrivileges();
if (r.dropped) console.log(`[security] running as uid ${r.uid}; data folders owned by it: ${r.dirs.join(', ')}`);
