// AlphaTrade AI — headless worker. Runs the SAME signals engine as the website (src/services/signals.js) on a server,
// so analysis, tracking and the phone notifications continue while no browser tab is open.
//
//   node server/worker.js
//
// Settings: export them from the site (Signals → Details & settings → "Export worker settings"), save as worker-config.json
// (or set WORKER_CONFIG to that JSON). Environment:
//   WORKER_DATA_DIR   where state.json lives (default ./worker-data — mount a persistent disk here)
//   WORKER_CONFIG_FILE / WORKER_CONFIG   exported settings (default ./worker-config.json)
//   ALERT_TOPIC       optional ntfy topic that receives a readable message for every new signal / target / stop (or set it on the website: AI key page)
//   TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID   optional: the same messages to Telegram (server/telegram.js; the token never leaves the server)
//   PORT              health endpoint (GET /health, GET /signals with WORKER_TOKEN if set)
//   TWELVEDATA_API_KEY        optional fallback for forex / metals / indices (Yahoo needs no key; crypto needs none)
import './dropPrivileges.js';   // v275: must stay the FIRST import
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DATA_DIR = path.resolve(process.env.WORKER_DATA_DIR || path.join(root, 'worker-data'));
const STATE_FILE = path.join(DATA_DIR, 'state.json');
const CONFIG_FILE = process.env.WORKER_CONFIG_FILE || path.join(root, 'worker-config.json');
// Keys that come from the exported site settings; everything else is runtime state kept in state.json.
export const CONFIG_KEYS = ['settings', 'risk', 'plan', 'chan-pref', 'lang'];

for (const f of ['.env', '.env.local']) {   // same .env loader as server/index.js
  const p = path.join(root, f);
  if (!fs.existsSync(p)) continue;
  for (const line of fs.readFileSync(p, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
}

/* ───────── browser shims ───────── */
const mem = new Map();
let dirty = false;
const mkStore = (persist) => ({
  getItem: (k) => (mem.has(k) ? mem.get(k) : null),
  setItem: (k, v) => { mem.set(k, String(v)); if (persist) dirty = true; },
  removeItem: (k) => { mem.delete(k); if (persist) dirty = true; },
});
globalThis.localStorage = mkStore(true);
globalThis.sessionStorage = { ...mkStore(false), getItem: () => null };
globalThis.window = new EventTarget();
globalThis.__CHANNEL_WORKER = true;
globalThis.document = { hidden: false, documentElement: { lang: 'ar', dir: 'rtl' }, addEventListener() {}, removeEventListener() {} };
globalThis.navigator ??= {};

function loadJson(file) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; } }
fs.mkdirSync(DATA_DIR, { recursive: true });
const state0 = loadJson(STATE_FILE) || {};
for (const [k, v] of Object.entries(state0)) mem.set(k, v);
let cfg = null;
try { cfg = process.env.WORKER_CONFIG ? JSON.parse(process.env.WORKER_CONFIG) : loadJson(CONFIG_FILE); } catch { cfg = null; }
if (!cfg) console.warn('[worker] no worker-config.json: running with default settings');
for (const k of CONFIG_KEYS) if (cfg && cfg[k] !== undefined) mem.set(`ata:${k}`, JSON.stringify(cfg[k]));

function persist() {
  if (!dirty) return;
  dirty = false;
  const out = {};
  for (const [k, v] of mem) if (!CONFIG_KEYS.some((c) => k === `ata:${c}`)) out[k] = v;
  const tmp = `${STATE_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(out)); fs.renameSync(tmp, STATE_FILE);
}
setInterval(persist, 5000);
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { persist(); process.exit(0); });

/* ───────── engine ───────── */
const { startSignals, signalState, notify: _n } = await import('../src/services/signals.js');
const { createNotifier } = await import('./notify.js');
const { createStore } = await import('./aiGateway.js');
void _n;
// Channels: what the owner saved on the website (encrypted file written by the web server, needs the same AI_KEY_SECRET),
// otherwise the TELEGRAM_* / ALERT_TOPIC environment values. Re-read every 10 s, so a change on the site needs no restart.
const NOTIFY_DIR = process.env.SERVER_NOTIFY_DIR || '/notify';
const notifier = createNotifier({ store: createStore({ dir: NOTIFY_DIR, secret: process.env.AI_KEY_SECRET || '', name: 'notify-config.json' }) });

// Readable phone message (Telegram and/or ntfy) for every alert the engine raises (new signal, targets, stop).
const seenAlerts = new Set();
window.addEventListener('alpha-signal', (e) => {
  const { title, body } = e.detail || {};
  console.log(`[alert] ${title} — ${body}`);
  const key = `${title}|${body}`;
  if (seenAlerts.has(key)) return;
  seenAlerts.add(key); if (seenAlerts.size > 500) seenAlerts.clear();
  notifier.send({ title, body }).then((r) => {
    if (r.telegram && !r.telegram.ok) console.warn('[worker] telegram:', r.telegram.status);
    if (r.ntfy && !r.ntfy.ok) console.warn('[worker] ntfy:', r.ntfy.status);
  });
});

startSignals();
// v247 Alpha Elite Signals: its own market scanner (indices, precious metals, commodities, Bitcoin) with the AI recommendation
// strategies, written to elite-signals.json for /api/elite/feed. ELITE_SCANNER=0 turns it off.
const ELITE_FILE = path.join(DATA_DIR, 'elite-signals.json');
if (process.env.ELITE_SCANNER !== '0') {
  const { createEliteScanner } = await import('../src/services/eliteScanner.js');
  const eliteScanner = createEliteScanner({
    store: { load: () => loadJson(ELITE_FILE), save: (st) => { const tmp = `${ELITE_FILE}.tmp`; fs.writeFileSync(tmp, JSON.stringify(st)); fs.renameSync(tmp, ELITE_FILE); } },
    onNew: (list) => console.log(`[elite] new: ${list.map((x) => `${x.symbol} ${x.tf} ${x.strategy} ${x.direction} ${x.entryType}`).join(' · ')}`),
    log: console,
  });
  eliteScanner.start();
  globalThis.__eliteScanner = eliteScanner;
}
{ const c = notifier.configured(); console.log(`[worker] started — data in ${DATA_DIR}; telegram: ${c.telegram ? 'on' : 'off'}; ntfy: ${c.ntfy ? 'on' : 'off'}`); }

/* ───────── health / read-only state ───────── */
const PORT = Number(process.env.PORT || process.env.WORKER_PORT || 0);
const TOKEN = process.env.WORKER_TOKEN || '';
if (PORT) {
  http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    const s = signalState();
    const send = (code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };
    if (url.pathname === '/health') { const e = globalThis.__eliteScanner?.state(); return send(200, { ok: true, scanning: s.scanning, lastScan: s.lastScan, lastTrack: s.lastTrack, live: s.live, active: s.signals.filter((x) => x.status === 'active').length, elite: e ? { lastScan: e.lastScan, signals: e.signals.length, errors: e.errors.length } : null }); }
    if (url.pathname === '/signals') {
      if (!TOKEN) { res.writeHead(503); res.end('Set WORKER_TOKEN for this private endpoint.'); return; }
      // Token in the "Authorization: Bearer …" header (preferred: not written to access logs) or ?token=… (kept for existing setups); constant-time compare.
      const given = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '') || url.searchParams.get('token') || '';
      const a = Buffer.from(given); const b = Buffer.from(TOKEN);
      if (TOKEN && !(a.length === b.length && crypto.timingSafeEqual(a, b))) return send(401, { error: 'token' });
      return send(200, { signals: s.signals });
    }
    send(404, { error: 'not found' });
  }).listen(PORT, () => console.log(`[worker] health on :${PORT}`));
}
