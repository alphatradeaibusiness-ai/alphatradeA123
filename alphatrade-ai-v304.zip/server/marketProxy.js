// A fixed-host proxy; the provider key never appears in browser requests.
const cache = new Map();
export const clearMarketCache = () => cache.clear();   // the cache is keyed by request, not by key: clear it whenever the key changes

/** Twelve Data error → one code the site can explain: invalid_key · rate_limit · no_permission · symbol_unavailable · unknown */
export function classifyMarket(status, body) {
  const code = Number(body?.code) || status; const msg = String(body?.message || '').toLowerCase();
  if (code === 401 || (/api ?key|apikey/.test(msg) && /incorrect|invalid|not specified|missing/.test(msg))) return 'invalid_key';
  if (code === 429 || /run out of api credits|rate limit/.test(msg)) return 'rate_limit';
  if (code === 403 || /available (starting )?with|upgrade|your plan|subscription/.test(msg)) return 'no_permission';
  if (code === 400 || code === 404 || /symbol/.test(msg)) return 'symbol_unavailable';
  return 'unknown';
}

const PROBES = [['forex', 'EUR/USD'], ['gold', 'XAU/USD'], ['indices', 'DJI']];
/**
 * Real check of a Twelve Data key: one tiny candle request per market class (forex, gold, indices), each straight to the
 * provider (never through the proxy cache). ok = at least one class answered with data; `markets` says which ones the plan unlocks.
 * Returns { ok, code, markets: { forex|gold|indices: { ok, code } } }.
 */
export async function testMarketKey(key, { fetcher = fetch, base = 'https://api.twelvedata.com' } = {}) {
  const markets = {};
  for (const [name, symbol] of PROBES) {
    try {
      const url = new URL(`${base.replace(/\/$/, '')}/time_series`);
      url.search = new URLSearchParams({ symbol, interval: '1h', outputsize: '1', apikey: key });
      const r = await fetcher(url, { signal: AbortSignal.timeout(10000) });
      const body = await r.json().catch(() => ({}));
      if (!r.ok || body.status === 'error') markets[name] = { ok: false, code: classifyMarket(r.status, body) };
      else markets[name] = Array.isArray(body.values) && body.values.length ? { ok: true, code: null } : { ok: false, code: 'unknown' };
    } catch { markets[name] = { ok: false, code: 'network' }; }
    if (markets[name].code === 'invalid_key') break;   // no point probing further with a rejected key
  }
  const good = Object.values(markets).some((m) => m.ok);
  const code = good ? null : Object.values(markets).map((m) => m.code).sort((a, b) => ['invalid_key', 'rate_limit', 'network', 'no_permission'].indexOf(a) - ['invalid_key', 'rate_limit', 'network', 'no_permission'].indexOf(b)).find(Boolean) || 'unknown';
  return { ok: good, code, markets };
}
export async function marketProxy(input, key, fetcher = fetch) {
  if (!key) return { code: 503, body: { status: 'error', message: 'Market data key is not configured' } };
  const { endpoint, symbol, interval = '1h', outputsize = 1000 } = input || {};
  if (!['time_series', 'quote'].includes(endpoint) || typeof symbol !== 'string' || !/^[A-Za-z0-9/_:. -]{1,60}$/.test(symbol)
      || !['1min','5min','15min','1h','4h','1day'].includes(interval)) return { code: 400, body: { status: 'error', message: 'Invalid market request' } };
  const n = Number(outputsize);
  if (!Number.isInteger(n) || n < 1 || n > 5000) return { code: 400, body: { status: 'error', message: 'Invalid history size' } };
  const id = JSON.stringify([endpoint,symbol,interval,n]);
  const hit = cache.get(id);
  if (hit && Date.now() - hit.at < (endpoint === 'quote' ? 15000 : 60000)) return hit.result;
  const url = new URL(`https://api.twelvedata.com/${endpoint}`);
  url.search = new URLSearchParams({symbol,apikey:key,...(endpoint === 'time_series' ? {interval,outputsize:String(n),order:'ASC',timezone:'UTC'} : {})});
  try {
    const r = await fetcher(url, { signal: AbortSignal.timeout(10000) });
    const body = await r.json();
    if (!r.ok || body.status === 'error') {
      const code = Number(body.code) || r.status;
      const plan = /available (starting )?with|upgrad|your plan/i.test(String(body.message || ''));   // the page hides symbols the plan does not include (see market/index.js)
      return { code: code === 429 ? 429 : 502, body: { status:'error', message: code === 429 ? 'Market data rate limit reached' : plan ? `Symbol not available on this plan: ${String(body.message).slice(0, 140)}` : 'Provider rejected the key, symbol or subscription access' } };
    }
    const result = {code:200,body};
    if(cache.size > 500) cache.clear();
    cache.set(id,{at:Date.now(),result});return result;
  } catch { return {code:502,body:{status:'error',message:'Market data provider unavailable'}}; }
}
