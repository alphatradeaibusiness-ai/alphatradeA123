import './dropPrivileges.js';   // v275: must stay the FIRST import (drops root before any file or socket is opened)
import { marketProxy, testMarketKey, clearMarketCache } from './marketProxy.js';
// AlphaTrade AI — small Node server (no dependencies).
//  • One AI gateway for every AI feature (server/aiGateway.js): the owner saves the provider + key once (encrypted on
//    this server, tied to the owner's verified account); every signed-in user's AI request goes through here.
//      GET    /api/ai/status          connection state (owner: + provider, model, last 4 characters, last error)
//      PUT    /api/ai/config          owner: save & activate — only after a REAL successful request
//      POST   /api/ai/config/test     owner: re-check the saved key
//      DELETE /api/ai/config          owner: delete the key (every AI feature stops)
//      POST   /api/ai/chat | support | explain | review | smc | images/describe | images/match   signed-in users
//  • Phone alerts (server/notify.js): GET /api/notify/status · PUT /api/notify/config (real test message first) ·
//    POST /api/notify/config/test · DELETE /api/notify/config[?channel=telegram|ntfy] — owner only, stored encrypted, never returned.
//  • Digital bank (server/bank/*): /api/bank/* — see docs/BANK.md. Disabled unless BANK_MASTER_KEY is set.
//  • Users are verified with Firebase ID tokens (Authorization: Bearer <token>); per-user and per-IP limits.
//  • --serve-dist → also serves the production build from ./dist
// The AI key never leaves this server and is never logged.
import http from 'node:http';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { chatSystem, supportSystem, explainSystem, smcSystem, reviewSystem, DESCRIBE_SYSTEM, describePrompt, MATCH_SYSTEM, matchPrompt } from '../src/services/ai/prompts.js';
import { createStore, callProvider, testConfig, createUserLimiter, cleanConfig, DEFAULT_MODELS } from './aiGateway.js';
import { verifyIdToken, googleCerts } from './firebaseVerify.js';
import { cleanNotify, effectiveNotify, parseStored, sendAll } from './notify.js';
import { createChannelAccess } from './channelAccess.js';
import { createUserTrades } from './userTrades.js';
import { createBackups } from './backup.js';
import { createTradeWatch } from './tradeWatch.js';
import { getInstrument } from '../src/config/instruments.js';
import { createEntitlements } from './entitlements.js';
import { createLedger } from './ledger.js';
import { createGrowth } from './growth.js';
import { createFaceLogin } from './faceLogin.js';
import { createMailer } from './mail.js';
import { createStripeBilling, createWebhook, deleteWebhook, KEY_RE, CATALOGUE } from './stripe.js';
import { createPartners } from './partners.js';
import { createTgGate } from './tgGate.js';
import { createCommunity } from './community.js';
import { createSecurityMonitor } from './securityMonitor.js';
import { createQuoteHub } from './quoteHub.js';
import { YAHOO_SYMBOLS } from '../src/services/market/yahoo.js';
import { createMt5Bridge, commandLines } from './mt5Bridge.js';
import { checkE164 } from '../src/services/phoneNumbers.js';
import { createProxyCache, marketTtl } from './proxyCache.js';
import { flushAllStores } from './writeBehind.js';
import { createPresence, dashboardSnapshot } from './adminDash.js';
import { eliteAlertBody, eliteTelegramText, ELITE_BRAND } from '../src/services/elite.js';
import { eliteSummary, LIVE_STATUSES as ELITE_LIVE } from '../src/services/eliteEngine.js';
import { ELITE_MARKETS, eliteAvailability } from '../src/config/eliteMarkets.js';
import { pairName } from '../src/services/tradeMessages.js';
import { writeBehind } from './writeBehind.js';
import { createRooms } from './rooms.js';
import { createChallenges, ACC_RE as CH_ACC_RE } from './challenges.js';
import { CONTRACTS as CH_CONTRACTS } from '../src/config/challenges.js';
import { createArena } from './arena.js';
import { MENTORS, mentorSystem } from '../src/config/mentors.js';
import { findInstrument } from '../src/config/instruments.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// Minimal .env loader (KEY=value lines). Real environment variables win.
for (const file of ['.env', '.env.local']) {
  const p = path.join(root, file);
  if (!fs.existsSync(p)) continue;
  for (const line of fs.readFileSync(p, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
}

const PORT = Number(process.env.SERVER_PORT || process.env.PORT || 8787);
const ENV_KEY = process.env.ANTHROPIC_API_KEY || '';   // optional fallback when the owner has not saved a key in the site
const MODEL = process.env.AI_MODEL || DEFAULT_MODELS.anthropic;
const MAX_TOKENS = Number(process.env.AI_MAX_TOKENS || 700);
const API_BASE = (process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com').replace(/\/$/, '');
const SERVE_DIST = process.argv.includes('--serve-dist');
const DIST = path.resolve(process.env.STATIC_DIR || path.join(root, 'dist'));

const hits = new Map(); // ip -> [timestamps]
const TRUST_PROXY = process.env.TRUST_PROXY === '1';   // behind Netlify/nginx/Cloudflare: read the real client IP
const ACCESS_TOKEN = process.env.AI_ACCESS_TOKEN || ''; // optional: require "Authorization: Bearer <token>"
const DAILY_TOTAL = Number(process.env.AI_DAILY_LIMIT || 500);    // all visitors together (protects your Anthropic bill)
const DAILY_PER_IP = Number(process.env.AI_DAILY_PER_IP || 100);
const IP_PER_MINUTE = Number(process.env.AI_IP_PER_MINUTE || 20);
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map((x) => x.trim()).filter(Boolean);
const daily = { day: '', total: 0, ip: new Map() };
// Market-data requests (candles for gold, indices, forex) have their own limit: they must not use up the AI budget above,
// and the chart legitimately asks for new data every few seconds.
const MARKET_PER_MINUTE = Number(process.env.MARKET_IP_PER_MINUTE || 240);
const marketHits = new Map();
function marketGate(req, res) {
  if (!originOk(req, res)) return false;
  const ip = clientIp(req); const now = Date.now();
  const arr = (marketHits.get(ip) || []).filter((x) => now - x < 60_000); arr.push(now); marketHits.set(ip, arr);
  if (marketHits.size > 5000) marketHits.clear();
  if (arr.length > MARKET_PER_MINUTE) { send(res, 429, { error: 'Too many market-data requests, slow down.' }); return false; }
  return true;
}

export function clientIp(req) {
  if (TRUST_PROXY) {
    // The RIGHT-most entry is the one our proxy added; the left-most is whatever the caller wrote, so it cannot be trusted for limits.
    const f = String(req.headers['x-forwarded-for'] || '').split(',').map((x) => x.trim()).filter(Boolean).pop() || '';
    if (f) return f;
  }
  return req.socket.remoteAddress || 'x';
}
function rateLimited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 60_000);
  arr.push(now);
  hits.set(ip, arr);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.some((x) => now - x < 60_000)) hits.delete(k); // do not let the table grow forever
  return arr.length > IP_PER_MINUTE;
}
/** Daily budget per IP and in total. Returns an error string, or '' when the call may go ahead. */
function overBudget(ip) {
  const day = new Date().toISOString().slice(0, 10);
  if (daily.day !== day) { daily.day = day; daily.total = 0; daily.ip.clear(); }
  const n = (daily.ip.get(ip) || 0) + 1;
  if (daily.total >= DAILY_TOTAL) return 'Daily AI limit reached, try again tomorrow.';
  if (n > DAILY_PER_IP) return 'Daily AI limit for your connection reached.';
  if (daily.ip.size > 20000) daily.ip.clear();
  daily.ip.set(ip, n); daily.total += 1;
  return '';
}
/** Constant-time string compare (token checks). */
function safeEqual(a, b) {
  const x = Buffer.from(String(a)); const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
/** Browser requests must come from this site (or ALLOWED_ORIGINS); a bearer token is required when AI_ACCESS_TOKEN is set. */
function originOk(req, res) {
  const origin = req.headers.origin;
  const tokenOk = Boolean(ACCESS_TOKEN) && safeEqual(req.headers.authorization || '', `Bearer ${ACCESS_TOKEN}`);
  if (ACCESS_TOKEN && !tokenOk) { send(res, 401, { error: 'Unauthorized' }); return false; }
  // Browsers always send Origin on these POSTs. A request without one is a script, not this site: only allowed with the access token.
  if (!origin && !tokenOk) { send(res, 403, { error: 'Origin not allowed' }); return false; }
  if (origin) {
    let host = '';
    try { host = new URL(origin).host; } catch { /* bad origin */ }
    if (host !== req.headers.host && !ALLOWED_ORIGINS.includes(origin)) { send(res, 403, { error: 'Origin not allowed' }); return false; }
  }
  return true;
}
function gate(req, res) {
  if (!originOk(req, res)) return false;
  const ip = clientIp(req);
  if (rateLimited(ip)) { send(res, 429, { error: 'Too many requests, slow down.' }); return false; }
  const over = overBudget(ip);
  if (over) { send(res, 429, { error: over }); return false; }
  return true;
}

function send(res, status, body, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(body));
}

function readBody(req, limit = 64 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    let over = false;
    req.on('data', (c) => {
      size += c.length;
      if (over) { if (size > limit * 4) req.destroy(); return; }   // v276: drain (not stored) so the 413 reply reaches the client…
      if (size > limit) { over = true; chunks.length = 0; const e = new Error('Request too large'); e.code = 'too_large'; reject(e); return; }
      chunks.push(c);                                               // …but never more than 4× the limit (then the socket is cut)
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

/* ───────── AI gateway ───────── */
const IS_TEST = process.env.NODE_ENV === 'test';
const store = createStore({ dir: path.resolve(process.env.SERVER_DATA_DIR || path.join(root, 'server-data')), secret: process.env.AI_KEY_SECRET || '' });
const DATA_DIR = path.resolve(process.env.SERVER_DATA_DIR || path.join(root, 'server-data'));
// Coalesced store writes (v229): changes inside this window are written to disk once (payments are always written at once).
const STORE_WRITE_DELAY_MS = Math.max(0, Math.min(2000, Number(process.env.STORE_WRITE_DELAY_MS ?? (IS_TEST ? 0 : 250)) || 0));
const channelAccess = createChannelAccess(DATA_DIR, { writeDelayMs: STORE_WRITE_DELAY_MS });
const userTrades = createUserTrades({ dir: DATA_DIR, secret: process.env.AI_KEY_SECRET || '' });
const ent = createEntitlements({ dir: DATA_DIR, access: channelAccess, env: process.env });   // ENFORCE_PLANS=1 → paid features checked here
const ledger = createLedger({ dir: DATA_DIR });
// Members features: sign-in alerts, message centre, trial, referrals, Telegram per user, e-mails, news alerts, TradingView, contest, sync.
let tgGate = null;   // v262: created right after growth (it needs growth's Telegram links)
const growth = createGrowth({ dir: DATA_DIR, secret: process.env.AI_KEY_SECRET || '', access: channelAccess, ent, ledger, userTrades, env: process.env, onTgUpdate: (up) => tgGate?.onUpdate(up),
  pushTo: (uid, msg) => bankRt?.bank?.notifications?.pushOnly?.(uid, msg) || 0,
  telegram: () => { try { return effectiveNotify(savedNotify()).telegramToken || ''; } catch { return ''; } },
  mailBase: IS_TEST && process.env.MAIL_TEST_BASE ? process.env.MAIL_TEST_BASE : 'https://api.resend.com',
  tgBase: IS_TEST && process.env.NOTIFY_TEST_TELEGRAM_BASE ? process.env.NOTIFY_TEST_TELEGRAM_BASE : 'https://api.telegram.org',
  calendarUrl: process.env.FF_CAL_URL || 'https://nfs.faireconomy.media/ff_calendar_thisweek.json', publicUrl: String(process.env.PUBLIC_URL || '').replace(/\/+$/, ''), writeDelayMs: STORE_WRITE_DELAY_MS });
// The owner's subscribers channel: t.me/boost?c=3991253906 → Bot API chat id -1003991253906 (TG_CHANNEL_ID overrides; the admin card too)
tgGate = createTgGate({ dir: DATA_DIR, ownerChannel: String(process.env.TG_CHANNEL_ID ?? (IS_TEST ? '' : '-1003991253906')), ownerInvite: String(process.env.TG_INVITE_URL ?? (IS_TEST ? '' : 'https://t.me/+UdQEPf4JY8RkNjlk')), token: () => { try { return effectiveNotify(savedNotify()).telegramToken || ''; } catch { return ''; } }, defaultChannel: () => { try { return effectiveNotify(savedNotify()).telegramChatId || ''; } catch { return ''; } },
  entitlement: (uid) => { if (ADMIN_EMAILS.includes(String(growth.emailOf(uid) || '').toLowerCase())) return { owner: true }; const a = channelAccess.account(uid); return a?.subscription ? { until: a.subscription.until } : null; },
  uidByTg: (id) => growth.uidByTg(id), langOf: (uid) => growth.langOf(uid), publicUrl: () => String(process.env.PUBLIC_URL || '').replace(/\/+$/, ''),
  tgBase: IS_TEST && process.env.NOTIFY_TEST_TELEGRAM_BASE ? process.env.NOTIFY_TEST_TELEGRAM_BASE : 'https://api.telegram.org' });
if (!IS_TEST || process.env.GROWTH_TEST === '1') setInterval(() => { tgGate.sweep().catch((e) => console.error('[tg-gate]', e?.message)); }, IS_TEST ? 500 : 60_000).unref();
// Feedback & reports, live support calls, live broadcasts, plans & coupons, business analytics + monthly reports (server/community.js).
const mt5 = createMt5Bridge({ dir: DATA_DIR, secret: process.env.AI_KEY_SECRET || '' });
const community = createCommunity({ dir: DATA_DIR, secret: process.env.AI_KEY_SECRET || '', growth, userTrades, env: process.env,
  isOwnerEmail: (e) => ADMIN_EMAILS.includes(String(e || '').toLowerCase()), pointSize: (sym) => getInstrument(sym)?.pointSize || 1 });

// v236 security monitoring (server/securityMonitor.js): log of refused tokens / owner probes / floods / owner changes + owner alerts.
const secMon = createSecurityMonitor({ dir: DATA_DIR, notify: (title, body) => { for (const m of growth.members?.() || []) if (ADMIN_EMAILS.includes(String(m.email || '').toLowerCase())) growth.deliver?.(m.uid, { kind: 'security', title, body, url: '/#/app/admin-dashboard', push: true, tg: true, email: null })?.catch?.(() => null); } });if (!IS_TEST) { setTimeout(() => community.runMonthly().catch(() => {}), 60_000).unref?.(); setInterval(() => community.runMonthly().catch(() => {}), 3600_000).unref?.(); }
const planItem = (id) => { const b = CATALOGUE[id]; if (!b) return null; const o = community.planOverrides()[id] || {}; return { ...b, cents: o.cents ?? b.cents, months: o.months ?? b.months, active: o.active !== false }; };
const mailer = createMailer({ dir: DATA_DIR, env: process.env });   // v295: welcome + sign-in e-mails (needs RESEND_API_KEY on the server)
const face = createFaceLogin({ dir: DATA_DIR, secret: process.env.AI_KEY_SECRET || '', env: process.env });   // face sign-in (passkeys)
if (!IS_TEST || process.env.GROWTH_TEST === '1') growth.start(IS_TEST ? { jobsMs: 300, pollMs: 300 } : undefined);
// Digital bank (wallet, deposits, withdrawals, KYC, card request, auto-invest). Off unless BANK_MASTER_KEY is set. See docs/BANK.md.
let bankRt = { enabled: false, handle: null, reason: 'no_master_key' };
try {
  const { createBankRuntime } = await import('./bank/runtime.js');
  bankRt = createBankRuntime({ env: process.env, isTest: IS_TEST, dataDir: DATA_DIR, deps: { requireUser: (...a) => requireUser(...a), isOwner: (u) => isOwnerEmail(u), originOk: (...a) => originOk(...a), send: (...a) => send(...a), readBody: (...a) => readBody(...a), clientIp: (...a) => clientIp(...a) } });
} catch (e) { console.error('[bank] disabled:', e?.code === 'ERR_UNKNOWN_BUILTIN_MODULE' ? 'needs Node 22.13+ (node:sqlite)' : String(e?.message || e).slice(0, 120)); }
// Daily rotating backups (bank snapshot + encrypted files). In tests only when BACKUP_TEST=1.
const backups = createBackups({ dataDir: DATA_DIR, snapshotBank: bankRt.snapshot || null, env: IS_TEST && process.env.BACKUP_TEST !== '1' ? { BACKUP_DISABLED: '1' } : process.env });
backups.start();
if (IS_TEST && process.env.BACKUP_TEST === '1') backups.run();
// Saved assistant trades are checked on the server too, so the push arrives with the browser closed (crypto pairs only).
const tradeWatch = createTradeWatch({ userTrades, allowed: (uid) => ent.canTradeAlerts(uid),
  // trade events: bank notification + push (when the bank runs), and the in-app message centre + the person's Telegram
  notify: (uid, kind, params) => {
    const N = bankRt.bank?.notifications;
    try { N?.notify(uid, kind, params); } catch { /* */ }
    const body = N?.text ? N.text('ar', kind, params, false) : `${params.symbol || ''} ${kind.replace('trade_', '')}${params.r != null ? ` (${params.r}R)` : ''}`;
    growth.deliver(uid, { kind, title: 'AlphaTrade AI · صفقاتي', body, url: '/#/app', push: !N, email: null }).catch(() => {});
  },
  // gold / forex / indices: candles from the site's Twelve Data key (when one is saved), every 10 minutes
  otherCandles: async (symbol, tf, fromSec) => {
    const key = activeMarketKey(); const inst = getInstrument(symbol);
    const TD = { '1m': '1min', '5m': '5min', '15m': '15min', '1h': '1h', '4h': '4h', '1D': '1day' }; const SEC = { '1m': 60, '5m': 300, '15m': 900, '1h': 3600, '4h': 14400, '1D': 86400 };
    if (!key || !inst?.providerSymbol || !TD[tf]) return null;
    const bars = Math.min(5000, Math.max(50, Math.ceil((Date.now() / 1000 - fromSec) / SEC[tf]) + 10));
    const r = await marketProxy({ endpoint: 'time_series', symbol: inst.providerSymbol, interval: TD[tf], outputsize: bars }, key);
    if (r.code !== 200 || !Array.isArray(r.body?.values)) return null;
    return r.body.values.map((v) => ({ time: Math.floor(Date.parse(/\d{2}:\d{2}/.test(v.datetime) ? `${v.datetime.replace(' ', 'T')}Z` : `${v.datetime}T00:00:00Z`) / 1000), open: +v.open, high: +v.high, low: +v.low, close: +v.close, volume: +(v.volume || 0) }))
      .filter((c) => Number.isFinite(c.time) && Number.isFinite(c.close)).sort((a, b) => a.time - b.time);
  },
  env: IS_TEST ? { TRADE_WATCH_DISABLED: process.env.TRADE_WATCH_TEST === '1' ? '0' : '1', TRADE_WATCH_MS: '400' } : process.env,
  base: IS_TEST && process.env.TRADE_WATCH_TEST_BASE ? process.env.TRADE_WATCH_TEST_BASE : 'https://api.binance.com' });
tradeWatch.start();
// Payments (Stripe Checkout + signed webhook). Off until STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET are set.
const STRIPE_API = IS_TEST && process.env.STRIPE_TEST_API ? process.env.STRIPE_TEST_API : 'https://api.stripe.com';
const billingStore = createStore({ dir: DATA_DIR, secret: process.env.AI_KEY_SECRET || '', name: 'billing-config.json' });   // owner's Stripe key + webhook secret, encrypted
const storedBilling = () => { const r = billingStore.load(); if (!r?.apiKey) return null; try { const j = JSON.parse(r.apiKey); return { key: j.key, whsec: j.whsec, webhookId: j.webhookId }; } catch { return null; } };
// v255 Alpha Partner Club (affiliate program) — commissions only from payments the signed Stripe webhook confirmed
const partners = createPartners({ dir: DATA_DIR, secret: process.env.AI_KEY_SECRET || '', deliver: (uid, n) => growth.deliver(uid, n), langOf: (uid) => growth.langOf?.(uid) || 'ar',
  hasPaid: (uid) => ledger.forUser(uid).some((r) => r.cents > 0), catalogue: CATALOGUE, env: process.env });
setInterval(() => { try { partners.tick(); } catch { /* next time */ } }, IS_TEST ? 1000 : 5 * 60_000).unref();
const billing = createStripeBilling({ env: process.env, access: channelAccess, keys: storedBilling, ledger, onPaid: (uid) => growth.onPaid(uid), onChallenge: (x) => challenges.purchase(x), onChallengeRefund: (pi) => challenges.onRefund(pi), partners, api: STRIPE_API,
  pricing: { item: planItem, quote: (code, ...a) => (partners.isCode(code) ? partners.quote(code, ...a) : community.quote(code, ...a)), redeem: (code, ...a) => (partners.isCode(code) ? null : community.redeem(code, ...a)), secret: process.env.AI_KEY_SECRET || '' } });
const billingView = () => { const m = billingStore.meta(); return { ...billing.status(), source: billing.source(), last4: billing.source() === 'site' ? m?.last4 || null : null, webhookUrl: m?.webhookUrl || null, savedAt: m?.updatedAt || null, envSet: Boolean(process.env.STRIPE_SECRET_KEY) }; };
const rawBody = (req, limit) => new Promise((resolve, reject) => { const c = []; let n = 0; req.on('data', (d) => { n += d.length; if (n > limit) { reject(new Error('too_large')); req.destroy(); } else c.push(d); }); req.on('end', () => resolve(Buffer.concat(c))); req.on('error', reject); });
/** Delete my account data on the server. Needs a fresh sign-in (10 min) and the word DELETE. Bank money must be withdrawn first;
 *  payment amounts stay in the accounts ledger without the person's id (bookkeeping duty). The sign-in account itself is deleted by the page. */
async function handleDeleteAccount(req, res) {
  if (!originOk(req, res)) return;
  if (rateLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' });
  const u = await requireUser(req, res); if (!u) return;
  let b; try { b = JSON.parse(await readBody(req, 1024)); } catch { return send(res, 400, { code: 'bad_request' }); }
  if (b.confirm !== 'DELETE') return send(res, 400, { code: 'confirm_required' });
  if (!u.authTime || Date.now() / 1000 - u.authTime > 600) return send(res, 401, { code: 'reauth_required' });
  if (isOwnerEmail(u)) return send(res, 409, { code: 'owner_account' });   // the site owner's account holds the keys
  if (bankRt.bank) {
    let w = []; try { w = bankRt.bank.wallet(u.uid); } catch { /* no bank account */ }
    if (w.some((x) => (x.available || 0) + (x.held || 0) + (x.pendingDeposits || 0) + (x.pockets || 0) + (x.vault || 0) > 0)) return send(res, 409, { code: 'bank_balance' });
  }
  userTrades.removeAll(u.uid); channelAccess.remove(u.uid); ent.forget(u.uid); growth.forget(u.uid); partners.forgetUser(u.uid); face.remove(u.uid); const anon = ledger.anonymise(u.uid);
  try { mt5.removeAll?.(u.uid); } catch { /* bridge off */ } try { community.forgetUser?.(u.uid); } catch { /* community off */ } try { rooms.forgetUser(u.uid); arena.forgetUser(u.uid); challenges.forgetUser(u.uid); } catch { /* v251 rooms off */ }   // v235: nothing of the account is left behind
  console.log('[account] deleted on request:', u.uid.slice(0, 6), 'payments kept anonymously:', anon);
  return send(res, 200, { ok: true, kept: { paymentsAnonymised: anon, bankRecords: Boolean(bankRt.bank) } });
}
/** Face sign-in (passkeys). The face is checked on the device; the server only checks signatures. */
const faceFails = new Map();
async function handleFace(req, res, pathname) {
  const m = req.method;
  if (m !== 'GET' && !originOk(req, res)) return;
  const origin = String(req.headers.origin || ''); let host = ''; try { host = new URL(origin).hostname; } catch { /* GET */ }
  const rp = { rpId: process.env.FACE_RP_ID || host || String(req.headers.host || '').split(':')[0], origins: origin ? [origin] : [] };
  const ip = clientIp(req);
  const err = (e) => send(res, e?.code === 'not_configured' ? 503 : 400, { code: e?.code || 'face_failed' });
  try {
    if (pathname === '/api/face/login/options' && m === 'POST') { if (rateLimited(ip)) return send(res, 429, { code: 'rate_limited' }); return send(res, 200, { ...face.loginOptions(rp), configured: face.configured() }); }
    if (pathname === '/api/face/login' && m === 'POST') {
      const t = Date.now(); const f = (faceFails.get(ip) || []).filter((x) => t - x < 600_000);
      if (f.length >= 10) return send(res, 429, { code: 'too_many_attempts' });
      let b; try { b = JSON.parse(await readBody(req, 16 * 1024)); } catch { return send(res, 400, { code: 'bad_request' }); }
      try { const out = face.login(b, rp); faceFails.delete(ip); console.log('[face] sign-in', out.uid.slice(0, 6)); return send(res, 200, { token: out.token }); }
      catch (e) { f.push(t); faceFails.set(ip, f); if (faceFails.size > 5000) faceFails.clear(); return err(e); }
    }
    const u = await requireUser(req, res); if (!u) return;
    if (pathname === '/api/face/status' && m === 'GET') return send(res, 200, face.status(u.uid));
    if (pathname === '/api/face/register/options' && m === 'POST') {
      if (!u.authTime || Date.now() / 1000 - u.authTime > 600) return send(res, 401, { code: 'reauth_required' });   // adding a face key needs a fresh sign-in
      return send(res, 200, face.registerOptions(u, rp));
    }
    if (pathname === '/api/face/register' && m === 'POST') {
      if (!u.authTime || Date.now() / 1000 - u.authTime > 900) return send(res, 401, { code: 'reauth_required' });
      let b; try { b = JSON.parse(await readBody(req, 16 * 1024)); } catch { return send(res, 400, { code: 'bad_request' }); }
      const out = face.register(u, b, rp);
      growth.deliverKey(u.uid, 'signin', 'face_t', 'face_b', { device: String(b.name || 'Device').slice(0, 40) }, { url: '/#/app/profile', email: true }).catch(() => {});
      return send(res, 200, out);
    }
    if (pathname === '/api/face' && m === 'DELETE') { let b = {}; try { b = JSON.parse(await readBody(req, 512) || '{}'); } catch { /* */ } return send(res, 200, face.remove(u.uid, b.id)); }
  } catch (e) { return err(e); }
  return send(res, 404, { error: 'Not found' });
}
/** Members routes. GETs need sign-in only (same-origin GETs have no Origin); writes also need our Origin. */
async function handleMembers(req, res, pathname) {
  const m = req.method;
  let r;
  if ((r = /^\/api\/tv\/([A-Za-z0-9_-]{20,40})$/.exec(pathname)) && m === 'POST') {   // TradingView → secret URL, no sign-in
    if (rateLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' });
    let raw; try { raw = await readBody(req, 2048); } catch { return send(res, 413, { code: 'too_large' }); }
    const out = await growth.tvHook(r[1], raw); return send(res, out.status, out.body);
  }
  if (m !== 'GET' && !originOk(req, res)) return;
  if (m !== 'GET' && rateLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' });
  const u = await requireUser(req, res); if (!u) return;
  if (!growth.canSave()) return send(res, 503, { code: 'no_secret' });
  const json = async (n = 8192) => { try { return JSON.parse(await readBody(req, n)); } catch { return null; } };
  const owner = Boolean(isOwnerEmail(u));
  if (pathname === '/api/me/signin' && m === 'POST') { const b = await json(1024) || {}; return send(res, 200, await growth.signIn(u, { device: b.device, lang: b.lang, owner }, clientIp(req))); }
  // phone number from the sign-up form / profile: re-validated here with the same rules (never trusted from the browser)
  if (pathname === '/api/me/phone' && m === 'GET') return send(res, 200, { phone: growth.getPhone(u.uid) });
  if (pathname === '/api/me/phone' && m === 'PUT') {
    const b = await json(512); if (!b || typeof b !== 'object') return send(res, 400, { code: 'bad_request' });
    const r = checkE164(b.phone, typeof b.country === 'string' ? b.country.slice(0, 2) : '');
    if (!r.ok) return send(res, 400, { code: `phone_${r.error}` });
    return send(res, 200, growth.setPhone(u.uid, { e164: r.e164, iso: r.iso }));
  }
  if (pathname === '/api/me/notices' && m === 'GET') return send(res, 200, growth.notices(u.uid));
  if (pathname === '/api/me/notices/read' && m === 'POST') { const b = await json(512) || {}; return send(res, 200, growth.markRead(u.uid, typeof b.id === 'string' ? b.id : null)); }
  if (pathname === '/api/me/broadcast/dismiss' && m === 'POST') { const b = await json(512) || {}; return send(res, 200, growth.dismissBroadcast(u.uid, b.id)); }
  if (pathname === '/api/me/connect' && m === 'GET') {
    const base = String(process.env.PUBLIC_URL || '').replace(/\/+$/, '');
    return send(res, 200, { ...growth.prefs(u.uid), tvPath: `/api/tv/${growth.tvToken(u.uid)}`, base, trial: growth.trialStatus(u.uid, u.email), referral: growth.referral(u.uid) });
  }
  if (pathname === '/api/me/prefs' && m === 'PUT') { const b = await json(2048); if (!b) return send(res, 400, { code: 'bad_request' }); return send(res, 200, growth.prefs(u.uid, b)); }
  if (pathname === '/api/me/telegram/link' && m === 'POST') { const out = await growth.tgLinkStart(u.uid); return send(res, out.error ? 409 : 200, out.error ? { code: out.error } : out); }
  if (pathname === '/api/me/telegram' && m === 'DELETE') return send(res, 200, growth.tgUnlink(u.uid));
  if (pathname === '/api/me/tv/regenerate' && m === 'POST') return send(res, 200, { tvPath: `/api/tv/${growth.tvToken(u.uid, true)}` });
  if (pathname === '/api/me/trial' && m === 'POST') { const out = await growth.startTrial(u); return send(res, out.error ? 409 : 200, out.error ? { code: out.error } : out); }
  if (pathname === '/api/me/referral' && m === 'POST') { const b = await json(512) || {}; const out = growth.claimReferral(u.uid, b.code); return send(res, out.error ? 409 : 200, out.error ? { code: out.error } : out); }
  if (pathname === '/api/me/sync' && m === 'GET') return send(res, 200, { sync: growth.getSync(u.uid) });
  if (pathname === '/api/me/sync' && m === 'PUT') { const b = await json(64 * 1024); if (!b) return send(res, 400, { code: 'bad_request' }); const out = growth.putSync(u.uid, b.data, b.ts); return send(res, out.error ? 400 : 200, out.error ? { code: out.error } : out); }
  if (pathname === '/api/contest' && m === 'GET') return send(res, 200, { ...growth.leaderboard(u.uid), owner });
  if (pathname === '/api/contest/join' && m === 'POST') { const b = await json(512) || {}; const out = growth.contestJoin(u.uid, b.nick); return send(res, out.error ? 409 : 200, out.error ? { code: out.error } : out); }
  if (pathname === '/api/contest/join' && m === 'DELETE') return send(res, 200, growth.contestLeave(u.uid));
  if (pathname === '/api/contest/award' && m === 'POST') { if (!owner) return send(res, 403, { code: 'not_owner' }); const b = await json(512) || {}; const out = await growth.contestAward(b.ref, Math.min(90, Math.max(1, Number(b.days) || 30))); return send(res, out.error ? 409 : 200, out.error ? { code: out.error } : out); }
  if (pathname === '/api/admin/broadcast' && m === 'POST') {
    if (!owner) return send(res, 403, { code: 'not_owner' });
    const b = await json(4096); if (!b || !String(b.title || '').trim() || !String(b.body || '').trim()) return send(res, 400, { code: 'bad_request' });
    return send(res, 200, await growth.broadcast({ title: b.title, body: b.body, push: b.push === true }));
  }
  return send(res, 404, { error: 'Not found' });
}
function revenueSummary(now) {
  const rows = ledger.all(); const accts = channelAccess.allAccounts();
  const d = new Date(now); const monthStart = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1);
  const sum = (list) => list.reduce((a, r) => a + (r.cents || 0), 0);
  const live = rows.filter((r) => r.live); const test = rows.filter((r) => !r.live);
  const active = {}; const expiring = [];
  for (const [uid, a] of Object.entries(accts)) {
    const s = a.subscription; if (!s || s.until <= now || s.startsAt > now) continue;
    active[s.product] = (active[s.product] || 0) + 1;
    if (s.until - now < 7 * 86_400_000) expiring.push({ ref: uid.slice(0, 6), product: s.product, until: s.until });
  }
  return { currency: 'usd', live: { month: sum(live.filter((r) => r.at >= monthStart)), total: sum(live), count: live.length },
    test: { month: sum(test.filter((r) => r.at >= monthStart)), total: sum(test), count: test.length },
    active, activeTotal: Object.values(active).reduce((a, b) => a + b, 0), expiring: expiring.sort((a, b) => a.until - b.until).slice(0, 20),
    recent: rows.slice(-10).reverse().map(({ uid: _u, ...r }) => r) };
}
async function handleBilling(req, res, pathname) {
  if (pathname === '/api/billing/webhook' && req.method === 'POST') {   // called by Stripe: no Origin, no sign-in — the signature is the check
    let raw; try { raw = await rawBody(req, 256 * 1024); } catch { return send(res, 413, { code: 'too_large' }); }
    const r = await billing.webhook(raw, req.headers['stripe-signature']);
    if (r.body?.result && r.body.result !== 'ignored') console.log('[billing] webhook:', r.body.result);
    return send(res, r.status, r.body);
  }
  if (pathname === '/api/billing/status' && req.method === 'GET') return send(res, 200, billing.status());
  if (pathname === '/api/billing/me' && req.method === 'GET') {
    const u = await requireUser(req, res); if (!u) return;
    const acc = channelAccess.account(u.uid);
    return send(res, 200, { owner: Boolean(isOwnerEmail(u)), enforce: ent.enforce, plan: ent.planOf(u.uid), subscription: acc?.subscription && acc.subscription.until > Date.now() ? acc.subscription : null,
      lastSubscription: acc?.subscription || null, addons: acc?.addons || [], ai: ent.aiAllowance(u.uid), payments: ledger.forUser(u.uid).slice(0, 50), billing: billing.status().configured,
      trial: growth.trialStatus(u.uid, u.email), referral: growth.referral(u.uid) });
  }
  if (pathname === '/api/billing/admin/summary' && req.method === 'GET') {
    const u = await requireUser(req, res); if (!u) return;
    if (!isOwnerEmail(u)) return send(res, 403, { code: 'not_owner' });
    return send(res, 200, revenueSummary(Date.now()));
  }
  if (pathname === '/api/billing/config') {
    if (req.method === 'GET') {   // same-origin GETs carry no Origin header: sign-in + owner check only
      const u = await requireUser(req, res); if (!u) return;
      if (!isOwnerEmail(u)) return send(res, 403, { code: 'not_owner' });
      return send(res, 200, billingView());
    }
    const user = await ownerOnly(req, res, billingStore); if (!user) return;
    if (req.method === 'DELETE') {
      const old = storedBilling(); if (old) await deleteWebhook({ key: old.key, id: old.webhookId, api: STRIPE_API });
      billingStore.remove(); console.log(`[billing] keys removed by ${user.email}`); return send(res, 200, billingView());
    }
    if (req.method === 'PUT') {
      if (!billingStore.canSave()) return send(res, 503, { code: 'no_secret' });
      let b; try { b = JSON.parse(await readBody(req, 2048)); } catch { return send(res, 400, { code: 'bad_request' }); }
      const key = typeof b.secretKey === 'string' ? b.secretKey.trim() : '';
      if (/^pk_/.test(key)) return send(res, 400, { code: 'publishable_key' });
      if (!KEY_RE.test(key)) return send(res, 400, { code: 'key_format' });
      const base = String(process.env.PUBLIC_URL || req.headers.origin || '').replace(/\/+$/, '');
      if (!/^https?:\/\/[^/]+$/.test(base)) return send(res, 400, { code: 'bad_origin' });
      const url = `${base}/api/billing/webhook`;
      const wh = await createWebhook({ key, url, api: STRIPE_API }).catch(() => ({ error: 'network' }));
      if (wh.error) { console.warn('[billing] key check failed:', wh.error); return send(res, 200, { ok: false, code: wh.error, message: wh.message || '', status: billingView() }); }
      const old = storedBilling(); if (old?.webhookId) await deleteWebhook({ key: old.key, id: old.webhookId, api: STRIPE_API });
      billingStore.save({ apiKey: JSON.stringify({ key, whsec: wh.secret, webhookId: wh.id }), last4: key.slice(-4), mode: key.includes('_live_') ? 'live' : 'test', webhookUrl: url, ownerUid: user.uid, ownerEmail: user.email, updatedAt: Date.now() });
      console.log(`[billing] Stripe ${key.includes('_live_') ? 'LIVE' : 'test'} key saved, webhook ${wh.id} created by ${user.email}`);
      return send(res, 200, { ok: true, status: billingView() });
    }
  }
  if (pathname === '/api/billing/checkout' && req.method === 'POST') {
    if (!originOk(req, res)) return;
    if (rateLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' });
    const user = await requireUser(req, res); if (!user) return;
    let b; try { b = JSON.parse(await readBody(req, 2048)); } catch { return send(res, 400, { code: 'bad_request' }); }
    const coupon = typeof b.coupon === 'string' ? b.coupon.slice(0, 24) : '';
    if (coupon && partners.isCode(coupon)) { const a = partners.attach(user, coupon, { ipHash: ipHashOf(req), via: 'coupon' }); if (a.error && a.error !== 'existing_customer' && a.error !== 'already_referred') return send(res, 409, { code: a.error }); }
    try { const r = await billing.checkout({ uid: user.uid, email: user.email, product: String(b.product || ''), origin: req.headers.origin, coupon, quantity: b.quantity }); return send(res, r.status, r.body); }
    catch { return send(res, 502, { code: 'stripe_error' }); }
  }
  return send(res, 404, { error: 'Not found' });
}
const COMMUNITY_RE = /^\/api\/(plans|coupon\/check|feedback(\/.*)?|support\/.+|live(\/.+)?|admin\/(plans|coupons|analytics|report|dashboard)|me\/reco)$/;
// MetaTrader 5 bridge (server/mt5Bridge.js). The EA endpoints authenticate with the pairing token (X-Bridge-Token header) and
// answer in a plain line format; the website endpoints need the signed-in customer, like everything else.
const eaHits = new Map();
function eaLimited(key) {
  const now = Date.now(); const arr = (eaHits.get(key) || []).filter((t) => now - t < 60_000); arr.push(now); eaHits.set(key, arr);
  if (eaHits.size > 5000) eaHits.clear();
  return arr.length > 120;
}
async function handleMt5(req, res, pathname) {
  const m = req.method; let mm;
  if ((mm = pathname.match(/^\/api\/mt5\/ea\/(hello|poll|ack)$/)) && m === 'POST') {
    const text = (code, body) => { res.writeHead(code, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(body); };
    const token = String(req.headers['x-bridge-token'] || '');
    if (eaLimited(`${clientIp(req)}|${token.slice(-8)}`)) return text(429, 'ERR|rate_limited');
    if (!mt5.canSave()) return text(503, 'ERR|no_secret');
    let b; try { b = JSON.parse(await readBody(req, 32 * 1024)); } catch { return text(400, 'ERR|bad_json'); }
    const r = mt5[mm[1]](token, b || {});
    if (r.error) return text(r.error === 'bad_token' ? 401 : 400, `ERR|${r.error}`);
    if (mm[1] === 'poll') return text(200, `OK|${Date.now()}|2000\n${commandLines(r.commands)}`);
    return text(200, `OK|${Date.now()}`);
  }
  if (m !== 'GET' && !originOk(req, res)) return;
  if (m !== 'GET' && rateLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' });
  const u = await requireUser(req, res); if (!u) return;
  if (!mt5.canSave()) return send(res, 503, { code: 'no_secret' });
  const out = (r) => send(res, r?.error ? (r.error === 'not_found' ? 404 : 400) : 200, r?.error ? { code: r.error } : r);
  const json = async () => { try { return JSON.parse(await readBody(req, 4096)); } catch { return null; } };
  if (pathname === '/api/mt5' && m === 'GET') return send(res, 200, mt5.list(u.uid));
  if (pathname === '/api/mt5/link' && m === 'POST') return out(mt5.createLink(u.uid, await json() || {}));
  if ((mm = pathname.match(/^\/api\/mt5\/link\/(m[0-9a-f]{12})$/)) && m === 'DELETE') return out(mt5.removeLink(u.uid, mm[1]));
  if ((mm = pathname.match(/^\/api\/mt5\/link\/(m[0-9a-f]{12})\/order$/)) && m === 'POST') return out(mt5.queueOrder(u.uid, mm[1], await json() || {}));
  return send(res, 404, { error: 'Not found' });
}
async function handleCommunity(req, res, pathname, searchParams) {
  const m = req.method;
  if (pathname === '/api/plans' && m === 'GET') {   // public: the prices and plans the owners set (no personal data)
    return send(res, 200, { items: Object.keys(CATALOGUE).map((id) => { const x = planItem(id); return { id, kind: x.kind, price: x.cents / 100, months: x.months, active: x.active }; }) });
  }
  if (m !== 'GET' && !originOk(req, res)) return;
  if (m !== 'GET' && rateLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' });
  const u = await requireUser(req, res); if (!u) return;
  if (!community.canSave()) return send(res, 503, { code: 'no_secret' });
  const owner = Boolean(isOwnerEmail(u));
  const json = async (n = 8192) => { try { return JSON.parse(await readBody(req, n)); } catch { return null; } };
  const out = (r, ok = 200) => send(res, r?.error ? (r.error === 'not_found' ? 404 : 400) : ok, r?.error ? { code: r.error } : r);
  const ownerOnlyHere = () => { if (!owner) { send(res, 403, { code: 'not_owner' }); return false; } return true; };
  let mm;
  if (pathname === '/api/coupon/check' && m === 'POST') { const b = await json(512) || {}; const x = planItem(String(b.product || '')); if (!x) return send(res, 400, { code: 'bad_product' }); if (partners.isCode(b.code)) return out(partners.quote(String(b.code).toUpperCase(), x.id, x.cents, u.uid)); return out(community.quote(b.code, x.id, x.cents, u.uid)); }
  if (pathname === '/api/me/reco' && m === 'POST') { const b = await json(512) || {}; return out(community.countReco(u.uid, { final: String(b.final || ''), strategy: /^[a-z_]{2,20}$/.test(b.strategy || '') ? b.strategy : null })); }
  // feedback & reports
  if (pathname === '/api/feedback' && m === 'GET') return send(res, 200, { ...community.listFeedback(u, owner), owner });
  if (pathname === '/api/feedback' && m === 'POST') { let b; try { b = JSON.parse(await readBody(req, 7 * 1024 * 1024)); } catch { return send(res, 413, { code: 'too_large' }); } return out(community.submitFeedback(u, b || {})); }
  if ((mm = pathname.match(/^\/api\/feedback\/img\/(i[0-9a-f]{12})$/)) && m === 'GET') {
    const img = community.feedbackImage(u, owner, mm[1]); if (!img) return send(res, 404, { code: 'not_found' });
    res.writeHead(200, { 'Content-Type': img.type, 'Cache-Control': 'private, max-age=600', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'" }); return res.end(img.data);
  }
  if ((mm = pathname.match(/^\/api\/feedback\/(f[0-9a-f]{12})$/)) && m === 'PATCH') { if (!ownerOnlyHere()) return; const b = await json(4096) || {}; return out(community.updateFeedback(mm[1], b)); }
  // live support calls (WebRTC signalling)
  if (pathname === '/api/support/ice' && m === 'GET') return send(res, 200, { iceServers: community.iceServers(), owner });
  if (pathname === '/api/support/call' && m === 'POST') { const b = await json(24 * 1024) || {}; return out(community.startCall(u, b)); }
  if (pathname === '/api/support/calls' && m === 'GET') { if (!ownerOnlyHere()) return; return send(res, 200, community.listCalls()); }
  if ((mm = pathname.match(/^\/api\/support\/call\/(c[0-9a-f]{12})(\/(answer|ice|end))?$/))) {
    const id = mm[1]; const act = mm[3] || '';
    if (!act && m === 'GET') { const st = community.callState(u, owner, id, { caller: searchParams.get('caller'), agent: searchParams.get('agent') }); return st ? send(res, 200, st) : send(res, 404, { code: 'not_found' }); }
    if (act === 'answer' && m === 'POST') { if (!ownerOnlyHere()) return; return out(community.answerCall(u, id, await json(24 * 1024) || {})); }
    if (act === 'ice' && m === 'POST') return out(community.addIce(u, owner, id, await json(2048) || {}));
    if (act === 'end' && m === 'POST') return out(community.endCall(u, owner, id));
  }
  // live broadcasts
  if (pathname === '/api/live' && m === 'GET') return send(res, 200, { ...community.liveState(), owner });
  if (pathname === '/api/live/start' && m === 'POST') { if (!ownerOnlyHere()) return; const host = (() => { try { return new URL(req.headers.origin || process.env.PUBLIC_URL || 'http://localhost').hostname; } catch { return 'localhost'; } })(); return out(await community.startLive(u, await json(2048) || {}, host)); }
  if (pathname === '/api/live/end' && m === 'POST') { if (!ownerOnlyHere()) return; return out(community.endLive()); }
  // in-site broadcast (WebRTC signalling)
  if (pathname === '/api/live/watch' && m === 'POST') return out(community.watchLive(u, await json(24 * 1024) || {}));
  if ((mm = pathname.match(/^\/api\/live\/watch\/(v[0-9a-f]{12})$/)) && m === 'GET') { const st = community.watchState(u, mm[1]); return st ? send(res, 200, st) : send(res, 404, { code: 'not_found' }); }
  if ((mm = pathname.match(/^\/api\/live\/watch\/(v[0-9a-f]{12})\/leave$/)) && m === 'POST') return out(community.leaveLive(u, owner, mm[1]));
  if (pathname === '/api/live/viewers' && m === 'GET') { if (!ownerOnlyHere()) return; return send(res, 200, community.liveViewers()); }
  if ((mm = pathname.match(/^\/api\/live\/viewer\/(v[0-9a-f]{12})\/answer$/)) && m === 'POST') { if (!ownerOnlyHere()) return; return out(community.answerViewer(mm[1], await json(24 * 1024) || {})); }
  // owners: plans, coupons, analytics, monthly reports
  if (pathname.startsWith('/api/admin/') && !ownerOnlyHere()) return;
  if (pathname === '/api/admin/plans' && m === 'GET') return send(res, 200, { items: Object.keys(CATALOGUE).map((id) => ({ ...planItem(id), base: CATALOGUE[id].cents })) });
  if (pathname === '/api/admin/plans' && m === 'PUT') { const b = await json(1024) || {}; return out(community.setPlan(String(b.id || ''), b, CATALOGUE)); }
  if (pathname === '/api/admin/coupons' && m === 'GET') return send(res, 200, community.listCoupons());
  if (pathname === '/api/admin/coupons' && m === 'PUT') return out(community.upsertCoupon(await json(2048) || {}));
  if (pathname === '/api/admin/coupons' && m === 'DELETE') return out(community.deleteCoupon(searchParams.get('code')));
  if (pathname === '/api/admin/dashboard' && m === 'GET') {   // v230 owner dashboard (owner checked above; aggregates only)
    if (rateLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' }, { 'Retry-After': '10' });
    return send(res, 200, dashboardSnapshot({ presence, activity: growth.activity(), accounts: channelAccess.allAccounts(), ledgerRows: ledger.all(),
      plans: Object.keys(CATALOGUE).map((id) => planItem(id)).filter(Boolean), sinceStart: PRESENCE_START, isMember: growth.isMember }));
  }
  if (pathname === '/api/admin/analytics' && m === 'GET') return send(res, 200, community.analytics());
  if (pathname === '/api/admin/report' && m === 'GET') { const r = community.report(String(searchParams.get('month') || '')); return r ? send(res, 200, r) : send(res, 400, { code: 'bad_month' }); }
  return send(res, 404, { error: 'Not found' });
}
const STARTED = Date.now();
// Browser error reports: a short message and code location only — no user data, rate-limited, never stored.
const errHits = new Map();
const scrub = (s, n) => String(s || '').replace(/[\w.+-]+@[\w-]+\.[\w.]+/g, '[email]').replace(/eyJ[\w-]{10,}\.[\w-]+\.[\w-]+/g, '[token]').replace(/\b(sk|pk|rk)[-_][\w-]{8,}/gi, '[key]').replace(/\b\d{12,19}\b/g, '[number]').replace(/[\u0000-\u001f]+/g, ' ').slice(0, n);
async function handleClientError(req, res) {
  if (req.headers.origin && !originOk(req, res)) return;
  const ip = clientIp(req); const t = Date.now();
  const arr = (errHits.get(ip) || []).filter((x) => t - x < 600_000); arr.push(t); errHits.set(ip, arr);
  if (errHits.size > 2000) errHits.clear();
  if (arr.length > 10) return send(res, 429, { code: 'rate_limited' });
  let b; try { b = JSON.parse(await readBody(req, 4096)); } catch { return send(res, 400, { code: 'bad_request' }); }
  const where = scrub(String(b.where || '').replace(/[?#].*$/, ''), 120);
  console.warn('[client-error]', JSON.stringify({ kind: scrub(b.kind, 20), msg: scrub(b.message, 300), at: scrub(b.at, 200), where, page: scrub(String(b.page || '').replace(/\?.*$/, ''), 60), v: scrub(b.v, 20) }));
  res.writeHead(204, { 'Cache-Control': 'no-store' }); return res.end();
}
const NOTIFY_DIR = path.resolve(process.env.SERVER_NOTIFY_DIR || DATA_DIR);   // may be a separate volume that the worker mounts read-only
const notifyStore = createStore({ dir: NOTIFY_DIR, secret: process.env.AI_KEY_SECRET || '', name: 'notify-config.json' });
const NOTIFY_TG_BASE = IS_TEST && process.env.NOTIFY_TEST_TELEGRAM_BASE ? process.env.NOTIFY_TEST_TELEGRAM_BASE : undefined;
const NOTIFY_NTFY_BASE = IS_TEST && process.env.NOTIFY_TEST_NTFY_BASE ? process.env.NOTIFY_TEST_NTFY_BASE : undefined;
const marketStore = createStore({ dir: DATA_DIR, secret: process.env.AI_KEY_SECRET || '', name: 'market-config.json' });   // same encryption, separate file
const ENV_MARKET_KEY = process.env.TWELVEDATA_API_KEY || '';
const MARKET_BASE = IS_TEST && process.env.TWELVEDATA_TEST_BASE ? process.env.TWELVEDATA_TEST_BASE : 'https://api.twelvedata.com';
const PROJECT_ID = process.env.FIREBASE_PROJECT_ID || process.env.VITE_FIREBASE_PROJECT_ID || '';
const ADMIN_EMAILS = String(process.env.ADMIN_EMAILS || process.env.VITE_ADMIN_EMAILS || 'shheahmad417@gmail.com').split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);
const userLimit = createUserLimiter({ perMinute: Number(process.env.AI_USER_PER_MINUTE || 10), perDay: Number(process.env.AI_USER_PER_DAY || 200) });
const providerOpts = { anthropicBase: API_BASE };

/** Current provider configuration WITH the key (server only), or null when AI is off. */
function activeConfig() {
  const c = store.load();
  if (c) return c;
  if (ENV_KEY) return { provider: 'anthropic', apiKey: ENV_KEY, model: MODEL, source: 'env' };
  return null;
}

let testCerts = { m: 0, c: null };
async function certs() {
  if (IS_TEST && process.env.AI_TEST_CERTS_FILE) { const st = fs.statSync(process.env.AI_TEST_CERTS_FILE); if (testCerts.m !== st.mtimeMs) testCerts = { m: st.mtimeMs, c: JSON.parse(fs.readFileSync(process.env.AI_TEST_CERTS_FILE, 'utf8')) }; return testCerts.c; }   // tests only (cached like Google's)
  return googleCerts();
}
/** The verified user, or null after sending 401 / 503. */
// v229: a verified ID token is remembered (by its SHA-256) until it expires, at most 5 minutes, so the RSA signature check does
// not run again on every poll. Same token → same checked result; a new / changed / expired token is always verified again.
const tokenCache = new Map();
// v230 owner dashboard: who is on line now (last signed-in request per account, memory only).
const presence = createPresence(); const PRESENCE_START = Date.now();
// v235 security: one signed-in account can make at most USER_PER_MINUTE API calls a minute (all tabs and devices together),
// so a stolen or scripted token cannot flood the server. Fixed one-minute windows, memory only, cheap per request.
const USER_PER_MINUTE = Math.max(60, Number(process.env.USER_PER_MINUTE) || 300);
const userHits = new Map();
function userLimited(uid) {
  const w = Math.floor(Date.now() / 60_000); const h = userHits.get(uid);
  if (!h || h.w !== w) { if (userHits.size > 50_000) userHits.clear(); userHits.set(uid, { w, n: 1 }); return false; }
  h.n += 1; return h.n > USER_PER_MINUTE;
}
async function requireUser(req, res) {
  const u = await requireUserInner(req, res); if (!u) return null;
  req._user = u;   // for the security monitor (who did an owner action)
  if (userLimited(u.uid)) { send(res, 429, { error: 'Too many requests, slow down.', code: 'rate_limited' }, { 'Retry-After': '30' }); return null; }
  return u;
}
async function requireUserInner(req, res) {
  if (!PROJECT_ID) { send(res, 503, { error: 'Server sign-in is not configured (FIREBASE_PROJECT_ID).', code: 'auth_not_configured' }); return null; }
  const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
  if (!m) { send(res, 401, { error: 'Sign in to use AI.', code: 'signin_required' }); return null; }
  const c = await certs();
  const k = crypto.createHash('sha256').update(m[1]).digest('base64');
  const hit = tokenCache.get(k);
  if (hit && hit.until > Date.now() && hit.certs === c) { presence.touch(hit.user.uid); return hit.user; }
  try {
    const user = verifyIdToken(m[1], { projectId: PROJECT_ID, certs: c });
    let exp = 0; try { exp = Number(JSON.parse(Buffer.from(m[1].split('.')[1], 'base64url').toString('utf8')).exp) * 1000; } catch { /* verified above */ }
    if (tokenCache.size >= 20000) tokenCache.clear();
    tokenCache.set(k, { user, certs: c, until: Math.min(exp || 0, Date.now() + 5 * 60_000) });
    presence.touch(user.uid);
    return user;
  } catch (e) { send(res, 401, { error: 'Your sign-in could not be verified. Sign in again.', code: 'signin_invalid' }); return null; }
}
// v235: ADMIN_REQUIRE_MFA=1 → owner powers only for a session signed in with a second factor (Firebase MFA). Off by default
// so an owner without MFA set up is never locked out; switch it on once MFA is enabled for the owner accounts.
const ADMIN_REQUIRE_MFA = process.env.ADMIN_REQUIRE_MFA === '1';
const isOwnerEmail = (u) => Boolean(u && u.emailVerified && ADMIN_EMAILS.includes(u.email) && (!ADMIN_REQUIRE_MFA || u.mfa));

/** Public state (no key, no provider details) + owner details when the caller is the owner. */
function statusFor(user) {
  const meta = store.meta();
  const env = !meta && ENV_KEY;
  const readable = meta ? Boolean(store.load()) : false;   // a key saved with another AI_KEY_SECRET cannot be decrypted → not usable
  const state = meta ? (meta.status === 'connected' && readable ? 'connected' : 'failed') : env ? 'unchecked' : 'none';
  const out = { state, vision: meta ? Boolean(meta.vision?.ok) : Boolean(env), signinConfigured: Boolean(PROJECT_ID) };
  if (isOwnerEmail(user)) {
    Object.assign(out, {
      owner: true, canSave: store.canSave(), source: meta ? 'site' : env ? 'env' : 'none',
      provider: meta?.provider || (env ? 'anthropic' : null), model: meta?.model || (env ? MODEL : null), visionModel: meta?.visionModel || '', baseUrl: meta?.baseUrl || '',
      last4: meta?.last4 || (env ? ENV_KEY.slice(-4) : null), checkedAt: meta?.checkedAt || null, error: meta && !readable ? 'cannot_decrypt' : meta?.error || null, visionError: meta?.vision?.ok ? null : meta?.vision?.code || null,
      boundTo: meta?.ownerEmail || null,
    });
  }
  return out;
}

async function handleStatus(req, res) {
  let user = null;
  if (PROJECT_ID && /^Bearer /.test(req.headers.authorization || '')) { try { user = verifyIdToken(req.headers.authorization.slice(7), { projectId: PROJECT_ID, certs: await certs() }); } catch { user = null; } }
  return send(res, 200, statusFor(user));
}

async function ownerOnly(req, res, st = store) {
  if (!gate(req, res)) return null;
  const user = await requireUser(req, res); if (!user) return null;
  if (!isOwnerEmail(user)) { send(res, 403, { error: 'Only the site owner can manage the AI key.', code: 'not_owner' }); return null; }
  const meta = st.meta();
  if (meta?.ownerUid && meta.ownerUid !== user.uid) { send(res, 403, { error: 'The key is bound to another owner account.', code: 'not_owner' }); return null; }
  return user;
}

async function handleConfigPut(req, res) {
  const user = await ownerOnly(req, res); if (!user) return;
  if (!store.canSave()) return send(res, 503, { error: 'Set AI_KEY_SECRET (32+ characters) on the server to store keys encrypted.', code: 'no_secret' });
  let input; try { input = JSON.parse(await readBody(req)); } catch { return send(res, 400, { error: 'Invalid JSON', code: 'bad_request' }); }
  const c = cleanConfig(input, { allowHttpLocal: IS_TEST });
  if (c.error) return send(res, 400, { error: 'Invalid settings', code: c.error });
  const prev = store.load();
  const cfg = { ...c.value, apiKey: c.value.apiKey || (prev && prev.provider === c.value.provider ? prev.apiKey : '') };
  if (!cfg.apiKey) return send(res, 400, { error: 'Enter the API key.', code: 'key_missing' });
  const t = await testConfig(cfg, providerOpts);
  if (!t.ok) {
    console.warn('[ai] key check failed:', t.code, t.status || '');
    return send(res, 200, { ok: false, code: t.code, status: statusFor(user) });   // nothing is saved; the previous key (if any) stays active
  }
  store.save({ ...cfg, last4: cfg.apiKey.slice(-4), ownerUid: user.uid, ownerEmail: user.email, status: 'connected', checkedAt: Date.now(), error: null, vision: t.vision, updatedAt: Date.now() });
  console.log(`[ai] key saved and verified (${cfg.provider}, ${cfg.model || 'default model'}) by ${user.email}`);
  return send(res, 200, { ok: true, status: statusFor(user) });
}

async function handleConfigTest(req, res) {
  const user = await ownerOnly(req, res); if (!user) return;
  const cfg = activeConfig();
  if (!cfg) return send(res, 200, { ok: false, code: 'not_configured', status: statusFor(user) });
  const t = await testConfig(cfg, providerOpts);
  if (cfg.source !== 'env') store.update({ status: t.ok ? 'connected' : 'failed', checkedAt: Date.now(), error: t.ok ? null : t.code, ...(t.ok ? { vision: t.vision } : {}) });
  return send(res, 200, { ok: t.ok, code: t.code || null, status: statusFor(user) });
}

async function handleConfigDelete(req, res) {
  const user = await ownerOnly(req, res); if (!user) return;
  store.remove();
  console.log(`[ai] key deleted by ${user.email}`);
  return send(res, 200, { ok: true, status: statusFor(user) });
}

/* ───────── Market-data key (Twelve Data: gold, indices, forex) ───────── */
const activeMarketKey = () => marketStore.load()?.apiKey || ENV_MARKET_KEY;
function marketStatusFor(user) {
  const meta = marketStore.meta();
  const readable = meta ? Boolean(marketStore.load()) : false;
  const state = meta ? (meta.status === 'connected' && readable ? 'connected' : 'failed') : ENV_MARKET_KEY ? 'unchecked' : 'none';
  const out = { configured: state !== 'none' && (meta ? readable : true), state, provider: 'Twelve Data', signinConfigured: Boolean(PROJECT_ID) };
  if (isOwnerEmail(user)) {
    Object.assign(out, { owner: true, canSave: marketStore.canSave(), source: meta ? 'site' : ENV_MARKET_KEY ? 'env' : 'none', last4: meta?.last4 || (ENV_MARKET_KEY ? ENV_MARKET_KEY.slice(-4) : null), checkedAt: meta?.checkedAt || null, markets: meta?.markets || null, error: meta && !readable ? 'cannot_decrypt' : meta?.error || null, boundTo: meta?.ownerEmail || null });
  }
  return out;
}
async function handleMarketStatus(req, res) {
  let user = null;
  if (PROJECT_ID && /^Bearer /.test(req.headers.authorization || '')) { try { user = verifyIdToken(req.headers.authorization.slice(7), { projectId: PROJECT_ID, certs: await certs() }); } catch { user = null; } }
  return send(res, 200, marketStatusFor(user));
}
async function handleMarketPut(req, res) {
  const user = await ownerOnly(req, res, marketStore); if (!user) return;
  if (!marketStore.canSave()) return send(res, 503, { error: 'Set AI_KEY_SECRET (32+ characters) on the server to store keys encrypted.', code: 'no_secret' });
  let input; try { input = JSON.parse(await readBody(req)); } catch { return send(res, 400, { error: 'Invalid JSON', code: 'bad_request' }); }
  const key = typeof input?.apiKey === 'string' ? input.apiKey.trim() : '';
  if (!key) return send(res, 400, { error: 'Enter the API key.', code: 'key_missing' });
  if (key.length < 8 || key.length > 200 || /[^\x21-\x7e]/.test(key)) return send(res, 400, { error: 'Invalid key format', code: 'key_format' });
  const t = await testMarketKey(key, { base: MARKET_BASE });
  if (!t.ok) { console.warn('[market] key check failed:', t.code); return send(res, 200, { ok: false, code: t.code, markets: t.markets, status: marketStatusFor(user) }); }   // nothing saved; the previous key stays
  marketStore.save({ apiKey: key, last4: key.slice(-4), ownerUid: user.uid, ownerEmail: user.email, status: 'connected', checkedAt: Date.now(), error: null, markets: t.markets, updatedAt: Date.now() });
  clearMarketCache();
  console.log(`[market] key saved and verified (Twelve Data) by ${user.email}`);
  return send(res, 200, { ok: true, markets: t.markets, status: marketStatusFor(user) });
}
async function handleMarketTest(req, res) {
  const user = await ownerOnly(req, res, marketStore); if (!user) return;
  const key = activeMarketKey();
  if (!key) return send(res, 200, { ok: false, code: 'not_configured', status: marketStatusFor(user) });
  const t = await testMarketKey(key, { base: MARKET_BASE });
  if (marketStore.meta()) marketStore.update({ status: t.ok ? 'connected' : 'failed', checkedAt: Date.now(), error: t.ok ? null : t.code, markets: t.markets });
  clearMarketCache();
  return send(res, 200, { ok: t.ok, code: t.code, markets: t.markets, status: marketStatusFor(user) });
}
async function handleMarketDelete(req, res) {
  const user = await ownerOnly(req, res, marketStore); if (!user) return;
  marketStore.remove(); clearMarketCache();
  console.log(`[market] key deleted by ${user.email}`);
  return send(res, 200, { ok: true, status: marketStatusFor(user) });
}

/* ───────── phone alerts: Telegram + ntfy (owner only, encrypted at rest, never sent back) ───────── */
const mask = (v, n = 4) => (v ? `…${String(v).slice(-n)}` : null);
const savedNotify = () => parseStored(notifyStore.load()) || {};
function notifyStatusFor(user) {
  const out = { signinConfigured: Boolean(PROJECT_ID), owner: false };
  if (!isOwnerEmail(user)) return out;
  const meta = notifyStore.meta(); const saved = savedNotify(); const eff = effectiveNotify(saved);
  const src = (siteVal, envVal) => (siteVal ? 'site' : envVal ? 'env' : 'none');
  return Object.assign(out, {
    owner: true, canSave: notifyStore.canSave(), error: meta && !notifyStore.load() ? 'cannot_decrypt' : null, boundTo: meta?.ownerEmail || null, checkedAt: meta?.checkedAt || null,
    telegram: { set: Boolean(eff.telegramToken && eff.telegramChatId), source: src(saved.telegramToken, process.env.TELEGRAM_BOT_TOKEN), tokenLast4: mask(eff.telegramToken), chat: mask(eff.telegramChatId, 3), ok: meta?.telegramOk ?? null, error: meta?.telegramError || null },
    ntfy: { set: Boolean(eff.ntfyTopic), source: src(saved.ntfyTopic, process.env.ALERT_TOPIC), topicLast3: mask(eff.ntfyTopic, 3), ok: meta?.ntfyOk ?? null, error: meta?.ntfyError || null },
  });
}
const tgCode = (r) => (r.ok ? null : r.status === 401 || r.status === 404 ? 'telegram_token_invalid' : r.status === 400 || r.status === 403 ? 'telegram_chat_invalid' : r.status === 'timeout' || typeof r.status === 'string' ? 'network' : 'telegram_failed');
const ntfyCode = (r) => (r.ok ? null : r.status === 'timeout' || typeof r.status === 'string' ? 'network' : 'ntfy_failed');
let lastNotifySend = 0;
const sendOpts = { ntfyBase: NOTIFY_NTFY_BASE, telegramBase: NOTIFY_TG_BASE };
async function handleNotifyStatus(req, res) {
  let user = null;
  if (PROJECT_ID && /^Bearer /.test(req.headers.authorization || '')) { try { user = verifyIdToken(req.headers.authorization.slice(7), { projectId: PROJECT_ID, certs: await certs() }); } catch { user = null; } }
  return send(res, 200, notifyStatusFor(user));
}
async function handleNotifyPut(req, res) {
  const user = await ownerOnly(req, res, notifyStore); if (!user) return;
  if (!notifyStore.canSave()) return send(res, 503, { error: 'Set AI_KEY_SECRET (32+ characters) on the server to store settings encrypted.', code: 'no_secret' });
  let input; try { input = JSON.parse(await readBody(req)); } catch { return send(res, 400, { error: 'Invalid JSON', code: 'bad_request' }); }
  const c = cleanNotify(input); if (c.error) return send(res, 400, { error: 'Invalid settings', code: c.error });
  const prev = savedNotify(); const merged = { ...prev, ...c.value };
  if (!Object.keys(c.value).length) return send(res, 400, { error: 'Nothing to save.', code: 'nothing' });
  if (Boolean(merged.telegramToken) !== Boolean(merged.telegramChatId)) return send(res, 400, { error: 'Telegram needs both the bot token and the chat id.', code: 'telegram_incomplete' });
  if (Date.now() - lastNotifySend < 3000) return send(res, 429, { error: 'Wait a few seconds.', code: 'rate_limited' });
  lastNotifySend = Date.now();
  // only the channels the owner just changed are tested — with a REAL message to the phone. A failing channel is not saved.
  const tgNew = c.value.telegramToken || c.value.telegramChatId; const ntNew = c.value.ntfyTopic;
  const msg = { title: 'Test', body: 'AlphaTrade AI: phone alerts are connected. ✔' };
  const results = {};
  if (tgNew) results.telegram = await sendAll({ telegramToken: merged.telegramToken, telegramChatId: merged.telegramChatId }, msg, sendOpts).then((r) => r.telegram);
  if (ntNew) results.ntfy = await sendAll({ ntfyTopic: merged.ntfyTopic }, msg, sendOpts).then((r) => r.ntfy);
  const codes = { telegram: results.telegram ? tgCode(results.telegram) : null, ntfy: results.ntfy ? ntfyCode(results.ntfy) : null };
  if (codes.telegram || codes.ntfy) { console.warn('[notify] check failed:', JSON.stringify(codes)); return send(res, 200, { ok: false, codes, status: notifyStatusFor(user) }); }
  const meta = notifyStore.meta() || {};
  notifyStore.save({ ...meta, apiKey: JSON.stringify(merged), ownerUid: user.uid, ownerEmail: user.email, checkedAt: Date.now(), telegramOk: merged.telegramToken ? true : null, telegramError: null, ntfyOk: merged.ntfyTopic ? true : null, ntfyError: null, updatedAt: Date.now() });
  console.log(`[notify] settings saved and verified by ${user.email} (telegram ${merged.telegramToken ? 'on' : 'off'}, ntfy ${merged.ntfyTopic ? 'on' : 'off'})`);
  return send(res, 200, { ok: true, codes, status: notifyStatusFor(user) });
}
async function handleNotifyTest(req, res) {
  const user = await ownerOnly(req, res, notifyStore); if (!user) return;
  const eff = effectiveNotify(savedNotify());
  if (!(eff.telegramToken && eff.telegramChatId) && !eff.ntfyTopic) return send(res, 200, { ok: false, codes: {}, code: 'not_configured', status: notifyStatusFor(user) });
  if (Date.now() - lastNotifySend < 3000) return send(res, 429, { error: 'Wait a few seconds.', code: 'rate_limited' });
  lastNotifySend = Date.now();
  const r = await sendAll(eff, { title: 'Test', body: 'AlphaTrade AI: phone alerts test message. ✔' }, sendOpts);
  const codes = { telegram: r.telegram ? tgCode(r.telegram) : null, ntfy: r.ntfy ? ntfyCode(r.ntfy) : null };
  if (notifyStore.meta()) notifyStore.update({ checkedAt: Date.now(), telegramOk: r.telegram ? r.telegram.ok : null, telegramError: codes.telegram, ntfyOk: r.ntfy ? r.ntfy.ok : null, ntfyError: codes.ntfy });
  return send(res, 200, { ok: !codes.telegram && !codes.ntfy, codes, status: notifyStatusFor(user) });
}
async function handleNotifyDelete(req, res, query) {
  const user = await ownerOnly(req, res, notifyStore); if (!user) return;
  const ch = query.get('channel'); const saved = savedNotify();
  if (ch === 'telegram') { delete saved.telegramToken; delete saved.telegramChatId; }
  else if (ch === 'ntfy') delete saved.ntfyTopic;
  else for (const k of Object.keys(saved)) delete saved[k];
  if (!Object.keys(saved).length) notifyStore.remove();
  else notifyStore.save({ ...(notifyStore.meta() || {}), apiKey: JSON.stringify(saved), telegramOk: saved.telegramToken ? true : null, ntfyOk: saved.ntfyTopic ? true : null, updatedAt: Date.now() });
  console.log(`[notify] ${ch || 'all'} deleted by ${user.email}`);
  return send(res, 200, { ok: true, status: notifyStatusFor(user) });
}

const clip = (s, n) => String(s ?? '').slice(0, n);
const parseJson = (t) => { const a = t.indexOf('{'); const b = t.lastIndexOf('}'); if (a < 0 || b <= a) return null; try { return JSON.parse(t.slice(a, b + 1)); } catch { return null; } };

/** Shared path for every AI feature: origin + IP limits, verified user, per-user limit, configured provider. */
async function aiCall(req, res, build, { bodyLimit = 64 * 1024, image = false } = {}) {
  if (!gate(req, res)) return;
  const user = await requireUser(req, res); if (!user) return;
  const owner = Boolean(isOwnerEmail(user)); const support = req.url.startsWith('/api/ai/support');
  if (!owner && channelAccess.channelOnly(user.uid) && !support) return send(res,403,{code:'platform_plan_required',error:'A channel-only subscription does not include platform AI tools.'});
  const denied = ent.checkAi(user, { owner, support });
  if (denied) return send(res, denied === 'ai_quota' ? 429 : 403, { code: denied, error: denied === 'ai_quota' ? 'This month\'s AI allowance is used up.' : 'This needs an active plan.' });
  const lim = userLimit(user.uid);
  if (lim) return send(res, 429, { error: 'Too many AI requests for your account, slow down.', code: lim });
  const cfg = activeConfig();
  if (!cfg) return send(res, 503, { error: 'AI is not connected. The site owner has to add the AI key.', code: 'not_configured' });
  if (image && cfg.source !== 'env' && store.meta()?.vision && !store.meta().vision.ok) return send(res, 400, { error: 'The connected model cannot read images.', code: 'vision_unsupported' });
  let payload; try { payload = JSON.parse(await readBody(req, bodyLimit)); } catch (e) { return send(res, 400, { error: e.message || 'Invalid JSON', code: 'bad_request' }); }
  const spec = build(payload);
  if (spec.error) return send(res, 400, { error: spec.error, code: 'bad_request' });
  const r = await callProvider(cfg, spec.request, providerOpts);
  if (!r.ok) {
    console.warn('[ai] provider error', r.code, r.status || '', r.diag || '');
    if (['invalid_key', 'no_credit'].includes(r.code) && cfg.source !== 'env') store.update({ status: 'failed', error: r.code, checkedAt: Date.now() });
    return send(res, r.code === 'rate_limit' ? 429 : 502, { error: 'AI provider error', code: r.code });
  }
  let out; try { out = spec.reply(r.text, r.model); } catch { return send(res, 502, { error: 'The AI reply could not be read.', code: 'bad_reply' }); }
  if (!owner && !support) ent.countAi(user.uid);   // count only answers that were delivered
  return send(res, 200, out);
}

const userMessages = (list) => {
  const m = (Array.isArray(list) ? list : []).filter((x) => (x.role === 'user' || x.role === 'assistant') && typeof x.content === 'string' && x.content.trim()).slice(-12).map((x) => ({ role: x.role, content: clip(x.content, 4000) }));
  while (m.length && m[0].role !== 'user') m.shift();
  return m;
};

const handleChat = (req, res) => aiCall(req, res, (p) => {
  const messages = userMessages(p.messages);
  if (!messages.length) return { error: 'No user message' };
  return { request: { system: chatSystem(p.context, p.lang), messages, maxTokens: MAX_TOKENS }, reply: (text, model) => ({ reply: text.trim(), model }) };
});
// v251: one-to-one chat with an AI mentor (the persona is chosen on the server from config/mentors.js)
const handleMentor = (req, res) => aiCall(req, res, (p) => {
  const messages = userMessages(p.messages); const system = mentorSystem(String(p.mentor || ''));
  if (!messages.length || !system) return { error: 'No mentor or message' };
  // v280 voice call with the mentor: the answer is read aloud, so it must be short, spoken and free of formatting.
  const voice = p.voice === true;
  const sys = voice ? `${system}\n\nThis is a LIVE VOICE CALL: your answer is read aloud by text-to-speech. Reply in 2–4 short spoken sentences in the user's language and dialect, no lists, no markdown, no symbols or emoji, no links. Ask at most one short follow-up question. Same rules as always: education only, no personal financial advice, no profit promises.` : system;
  return { request: { system: sys, messages, maxTokens: voice ? 350 : 900 }, reply: (text, model) => ({ reply: text.trim(), model }) };
});
const handleSupport = (req, res) => aiCall(req, res, (p) => {
  const messages = userMessages(p.messages);
  if (!messages.length) return { error: 'No user message' };
  return { request: { system: supportSystem({ page: clip(p.page, 80) }, p.lang), messages, maxTokens: 600 }, reply: (text, model) => ({ reply: text.trim(), model }) };
});
const handleExplain = (req, res) => aiCall(req, res, (p) => {
  if (!p.context || typeof p.context !== 'object') return { error: 'No analysis data' };
  return { request: { system: explainSystem(p.lang), messages: [{ role: 'user', content: `Analysis data (JSON):\n${JSON.stringify(p.context).slice(0, 7000)}` }], maxTokens: 600 }, reply: (text, model) => ({ reply: text.trim(), model }) };
});
const handleSmc = (req, res) => aiCall(req, res, (p) => {
  if (!p.context || typeof p.context !== 'object' || !['trade', 'wait', 'no_trade'].includes(p.context.verdict)) return { error: 'No assistant reading' };
  return { request: { system: smcSystem(p.lang), messages: [{ role: 'user', content: `Assistant reading (JSON):\n${JSON.stringify(p.context).slice(0, 7000)}` }], maxTokens: 650 }, reply: (text, model) => ({ reply: text.trim(), model }) };
});

/* ── the signed-in user's own SMC / ICT assistant trades (encrypted file per user) ── */
const tradeHits = new Map();
async function handleUserTrades(req, res, pathname) {
  // Same-origin browser GETs carry no Origin header; writes always do. Auth is the bearer token (no cookies → no CSRF).
  if ((req.method !== 'GET' || req.headers.origin) && !originOk(req, res)) return;
  const user = await requireUser(req, res); if (!user) return;
  if (!isOwnerEmail(user) && channelAccess.channelOnly(user.uid)) return send(res, 403, { code: 'platform_plan_required', error: 'A channel-only subscription does not include platform tools.' });
  const now = Date.now(); const arr = (tradeHits.get(user.uid) || []).filter((x) => now - x < 60_000); arr.push(now); tradeHits.set(user.uid, arr);
  if (tradeHits.size > 5000) tradeHits.clear();
  if (arr.length > 90) return send(res, 429, { code: 'rate_limited', error: 'Too many requests, slow down.' });
  if (!userTrades.canSave()) return send(res, 503, { code: 'no_secret', error: 'Set AI_KEY_SECRET (32+ characters) on the server to keep trade history encrypted.' });
  if (pathname === '/api/user/trades' && req.method === 'GET') return send(res, 200, { items: userTrades.list(user.uid), watch: { crypto: tradeWatch.status().enabled, other: tradeWatch.status().enabled && Boolean(activeMarketKey()) } });
  if (pathname === '/api/user/trades' && req.method === 'PUT') {
    let body; try { body = JSON.parse(await readBody(req, 8 * 1024)); } catch { return send(res, 400, { code: 'bad_request', error: 'Invalid JSON' }); }
    const r = userTrades.upsert(user.uid, body?.item);
    return r.error ? send(res, 400, { code: r.error, error: 'Invalid trade' }) : send(res, 200, r);
  }
  const m = /^\/api\/user\/trades\/([A-Za-z0-9_-]{6,40})$/.exec(pathname);
  if (m && req.method === 'DELETE') return userTrades.remove(user.uid, m[1]) ? send(res, 200, { ok: true }) : send(res, 404, { code: 'not_found', error: 'Not found' });
  return send(res, 405, { code: 'method_not_allowed', error: 'Method not allowed' });
}

const handleReview = (req, res) => aiCall(req, res, (p) => {
  if (!p.context || typeof p.context !== 'object' || !(Number(p.context.overall?.n) > 0)) return { error: 'No trade statistics' };
  return { request: { system: reviewSystem(p.lang), messages: [{ role: 'user', content: `Trade statistics (JSON):\n${JSON.stringify(p.context).slice(0, 7000)}` }], maxTokens: 700 }, reply: (text, model) => ({ reply: text.trim(), model }) };
});
const handleDescribe = (req, res) => aiCall(req, res, (p) => {
  if (!/^data:image\/(png|jpeg|webp|gif);base64,/.test(String(p.image || ''))) return { error: 'Send the image as a data URL' };
  return {
    request: { system: DESCRIBE_SYSTEM, messages: [{ role: 'user', content: describePrompt(p.lang) }], image: p.image, maxTokens: 400 },
    reply: (text) => {
      const j = parseJson(text); if (!j || !j.description) throw new Error('reply');
      return { description: clip(j.description, 300), alt: clip(j.alt, 125), keywords: (Array.isArray(j.keywords) ? j.keywords : []).map((x) => clip(x, 40)).slice(0, 16) };
    },
  };
}, { bodyLimit: 3 * 1024 * 1024, image: true });
const handleMatch = (req, res) => aiCall(req, res, (p) => {
  const items = (Array.isArray(p.items) ? p.items : []).slice(0, 20).map((x) => ({ title: clip(x.title, 200) }));
  const cands = (Array.isArray(p.candidates) ? p.candidates : []).slice(0, 40).map((x) => ({ id: clip(x.id, 40), text: clip(x.text, 240) }));
  if (!items.length || !cands.length) return { error: 'Nothing to match' };
  const ids = new Set(cands.map((c) => c.id));
  return {
    request: { system: MATCH_SYSTEM, messages: [{ role: 'user', content: matchPrompt(items, cands) }], maxTokens: 700 },
    reply: (text) => {
      const j = parseJson(text); const picks = [];
      for (const x of Array.isArray(j?.picks) ? j.picks : []) {
        const i = Number(x?.i);
        if (Number.isInteger(i) && i >= 0 && i < items.length) picks.push({ i, id: x.id != null && ids.has(String(x.id)) ? String(x.id) : null });   // only listed ids survive
      }
      return { picks };
    },
  };
});

// Same security headers as netlify.toml, so a self-hosted copy is protected the same way.
const STATIC_HEADERS = {
  'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
  'Permissions-Policy': 'camera=(self), microphone=(self), display-capture=(self), geolocation=(), payment=()',
  'Cross-Origin-Opener-Policy': 'same-origin-allow-popups',   // v235: other windows cannot script this one (sign-in popups still work)
  'Content-Security-Policy': "default-src 'self'; script-src 'self' https://www.gstatic.com https://apis.google.com https://platform.twitter.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob: https:; connect-src 'self' https: wss:; frame-src https:; worker-src 'self' blob:; form-action 'self'; frame-ancestors 'none'; base-uri 'self'; object-src 'none'",
};
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.woff2': 'font/woff2', '.webmanifest': 'application/manifest+json', '.webp': 'image/webp', '.txt': 'text/plain; charset=utf-8' };
// Compressible types are sent brotli/gzip-compressed (kept in memory per file version, bounded), every file has an ETag, and caching is
// explicit: the build's hashed files under /assets/ never change (cache a year), everything else is revalidated so a deploy shows at once.
const COMPRESSIBLE = new Set(['.html', '.js', '.css', '.svg', '.json', '.webmanifest', '.txt']);
const zcache = new Map(); let zbytes = 0; const ZMAX = 24 * 1024 * 1024;
function compressed(file, st, enc, read) {
  const key = `${file}|${st.mtimeMs}|${st.size}|${enc}`; const hit = zcache.get(key); if (hit) return hit;
  const raw = read();
  const out = enc === 'br' ? zlib.brotliCompressSync(raw, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 5, [zlib.constants.BROTLI_PARAM_SIZE_HINT]: raw.length } }) : zlib.gzipSync(raw, { level: 9 });
  if (zbytes + out.length > ZMAX) { zcache.clear(); zbytes = 0; }
  zcache.set(key, out); zbytes += out.length; return out;
}
function serveStatic(req, res) {
  let url;
  try { url = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch { return send(res, 400, { error: 'Bad request' }); }
  let file = path.join(DIST, url);
  // Must be inside DIST itself: a plain startsWith(DIST) would also accept a sibling folder such as "dist-old".
  if (file !== DIST && !file.startsWith(DIST + path.sep)) return send(res, 403, { error: 'Forbidden' });
  let st = fs.existsSync(file) ? fs.statSync(file) : null;
  if (!st || st.isDirectory()) {
    // A missing build file must be a real 404 (never index.html served as JavaScript and cached under a hashed name).
    if (url.startsWith('/assets/')) return send(res, 404, { error: 'Not found' });
    file = path.join(DIST, 'index.html'); st = fs.existsSync(file) ? fs.statSync(file) : null;
  }
  if (!st) return send(res, 404, { error: 'Run "npm run build" first' });
  const ext = path.extname(file);
  const immutable = file.startsWith(path.join(DIST, 'assets') + path.sep);
  const etag = `"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"`;
  const headers = {
    'Content-Type': MIME[ext] || 'application/octet-stream', ...STATIC_HEADERS, ETag: etag, Vary: 'Accept-Encoding',
    'Cache-Control': immutable ? 'public, max-age=31536000, immutable' : (['.png', '.svg', '.ico', '.woff2'].includes(ext) && !file.endsWith('index.html') ? 'public, max-age=86400' : 'no-cache'),
  };
  if (req.headers['if-none-match'] === etag || String(req.headers['if-none-match'] || '').split(',').some((x) => x.trim().replace(/^W\//, '') === etag)) { res.writeHead(304, headers); return res.end(); }
  const accept = String(req.headers['accept-encoding'] || '');
  const enc = COMPRESSIBLE.has(ext) && st.size > 1024 ? (/\bbr\b/.test(accept) ? 'br' : /\bgzip\b/.test(accept) ? 'gzip' : null) : null;
  if (enc) {
    const body = compressed(file, st, enc, () => fs.readFileSync(file));
    res.writeHead(200, { ...headers, 'Content-Encoding': enc, 'Content-Length': body.length });
    return req.method === 'HEAD' ? res.end() : res.end(body);
  }
  res.writeHead(200, { ...headers, 'Content-Length': st.size });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

// Forex Factory proxies, same paths as public/_redirects on Netlify (calendar feed + news page).
const FF_ROUTES = {
  '/ff/cal/thisweek': process.env.FF_CAL_URL || 'https://nfs.faireconomy.media/ff_calendar_thisweek.json',
  '/ff/news': process.env.FF_NEWS_URL || 'https://www.forexfactory.com/news',
};
// Market data proxies with the same paths as public/_redirects (Yahoo charts for gold / indices / forex, Binance public data).
// Only these read-only public endpoints are forwarded; the path is validated, so this is not an open proxy.
const PROXY_TEST_BASE = IS_TEST && process.env.MARKET_PROXY_TEST_BASE ? process.env.MARKET_PROXY_TEST_BASE : '';   // load tests only
// v243: one-second prices for gold / oil / indices / forex, shared by every visitor (server/quoteHub.js).
const quoteHub = createQuoteHub({ symbolMap: YAHOO_SYMBOLS, base: PROXY_TEST_BASE || 'https://query1.finance.yahoo.com' });

/* ───────── v251: market data for rooms (prediction prices) and the strategy arena (candles), fetched BY THE SERVER ───────── */
const BIN_BASE = PROXY_TEST_BASE || 'https://data-api.binance.vision'; const YH_BASE = PROXY_TEST_BASE || 'https://query1.finance.yahoo.com';
async function priceOf(symbol) {
  const inst = findInstrument(symbol); if (!inst) return null;
  try {
    if (inst.provider === 'binance') { const r = await fetch(`${BIN_BASE}/api/v3/ticker/price?symbol=${encodeURIComponent(symbol)}`, { signal: AbortSignal.timeout(5000) }); const j = await r.json(); const p = Number(j?.price); return p > 0 ? { price: p, at: Date.now(), source: 'Binance' } : null; }
    const q = (await quoteHub.get([symbol]))?.[symbol]; return q && q.price > 0 ? { price: q.price, at: q.at || Date.now(), source: 'Yahoo Finance' } : null;
  } catch { return null; }
}
const BIN_TF = { '15m': '15m', '1h': '1h', '4h': '4h', '1D': '1d' };
async function candlesOf(symbol, tf, limit = 1000) {
  const inst = findInstrument(symbol); if (!inst || !BIN_TF[tf]) return null;
  try {
    if (inst.provider === 'binance') {
      const r = await fetch(`${BIN_BASE}/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${BIN_TF[tf]}&limit=${Math.min(1000, limit)}`, { signal: AbortSignal.timeout(8000) }); const j = await r.json();
      const sec = { '15m': 900, '1h': 3600, '4h': 14400, '1D': 86400 }[tf];
      return Array.isArray(j) ? j.map((k) => ({ time: Math.floor(k[0] / 1000), open: +k[1], high: +k[2], low: +k[3], close: +k[4], volume: +k[5] })).filter((c) => (c.time + sec) * 1000 <= Date.now()) : null;
    }
    const y = YAHOO_SYMBOLS[symbol]; if (!y) return null;
    const iv = tf === '15m' ? '15m' : tf === '1D' ? '1d' : '60m'; const range = tf === '15m' ? '60d' : tf === '1D' ? '10y' : '730d';
    const r = await fetch(`${YH_BASE}/v8/finance/chart/${encodeURIComponent(y)}?interval=${iv}&range=${range}`, { headers: { 'user-agent': 'Mozilla/5.0 (compatible; AlphaTradeAI/1.0)' }, signal: AbortSignal.timeout(8000) }); const j = await r.json();
    const res = j?.chart?.result?.[0]; const ts = res?.timestamp || []; const q = res?.indicators?.quote?.[0] || {};
    let c = ts.map((t, i) => ({ time: t, open: q.open?.[i], high: q.high?.[i], low: q.low?.[i], close: q.close?.[i], volume: q.volume?.[i] || 0 })).filter((k) => [k.open, k.high, k.low, k.close].every(Number.isFinite));
    if (tf === '4h') { const m = new Map(); for (const k of c) { const b = Math.floor(k.time / 14400) * 14400; const x = m.get(b); if (!x) m.set(b, { ...k, time: b }); else { x.high = Math.max(x.high, k.high); x.low = Math.min(x.low, k.low); x.close = k.close; x.volume += k.volume; } } c = [...m.values()]; }
    return c.slice(-limit);
  } catch { return null; }
}
/** The site's AI for rooms / mentors — same checks as every AI feature (plan, monthly allowance, per-user limit, configured key). */
async function aiAsk(user, system, messages) {
  const owner = Boolean(isOwnerEmail(user));
  if (!owner && channelAccess.channelOnly(user.uid)) return { error: 'platform_plan_required' };
  const denied = ent.checkAi(user, { owner, support: false }); if (denied) return { error: denied };
  if (userLimit(user.uid)) return { error: 'slow_down' };
  const cfg = activeConfig(); if (!cfg) return { error: 'not_configured' };
  const r = await callProvider(cfg, { system, messages, maxTokens: 900 }, providerOpts);
  if (!r.ok) return { error: r.code === 'rate_limit' ? 'slow_down' : 'ai_error' };
  if (!owner) ent.countAi(user.uid);
  return { text: String(r.text || '').trim(), model: r.model };
}
const rooms = createRooms({ dir: DATA_DIR, secret: process.env.AI_KEY_SECRET || '', growth, env: process.env, priceOf, aiAsk, isOwnerEmail });
const arena = createArena({ dir: DATA_DIR, secret: process.env.AI_KEY_SECRET || '', candlesOf, env: process.env });
setInterval(() => { rooms.resolveDue().catch((e) => console.error('[rooms]', e?.message)); }, IS_TEST ? 1000 : 60_000).unref();
// v281 funded-trader challenges (server/challenges.js): demo accounts on server-fetched prices, rules checked every few seconds
// Prices for fills: crypto from Binance spot, forex / indices from Yahoo (freshness-checked), gold / silver / oil ONLY from Binance
// TradFi perpetuals (Yahoo's futures feed is delayed). Binance futures refuse some countries (e.g. US servers) → those markets show closed.
const FAPI_BASE = PROXY_TEST_BASE || 'https://fapi.binance.com';
async function chPriceOf(sym) {
  const c = CH_CONTRACTS[sym]; if (!c) return null;
  if (!c.fut) return priceOf(sym);
  try { const r = await fetch(`${FAPI_BASE}/fapi/v1/ticker/price?symbol=${c.fut}`, { signal: AbortSignal.timeout(5000) }); if (!r.ok) return null; const j = await r.json(); const p = Number(j?.price); return p > 0 ? { price: p, at: Number(j.time) || Date.now(), source: 'Binance Futures' } : null; } catch { return null; }
}
const challenges = createChallenges({ dir: DATA_DIR, secret: process.env.AI_KEY_SECRET || '', env: process.env, priceOf: chPriceOf, isOwnerEmail,
  notify: (uid, title, body, url) => growth.deliver?.(uid, { kind: 'challenge', title, body, url, push: true, tg: true, email: null })?.catch?.(() => null) });
setInterval(() => { challenges.tick(); }, IS_TEST ? 1000 : 5000).unref();
const CH_RE = /^\/api\/challenges(\/.*)?$/;
async function handleChallenges(req, res, pathname) {
  const m = req.method;
  if (m !== 'GET' && !originOk(req, res)) return;
  const u = await requireUser(req, res); if (!u) return;
  if (!challenges.canSave()) return send(res, 503, { code: 'no_secret' });
  const json = async (n = 4096) => { try { const v = JSON.parse(await readBody(req, n)); return v && typeof v === 'object' && !Array.isArray(v) ? v : null; } catch { return null; } };
  const out = (r) => send(res, r?.error ? (r.error === 'not_found' ? 404 : r.error === 'forbidden' ? 403 : r.error === 'rate_limited' ? 429 : r.error === 'market_closed' ? 409 : 400) : 200, r?.error ? { code: r.error } : r);
  const parts = pathname.split('/').slice(3);   // ['', 'AT-…', 'order'] etc.
  if (pathname === '/api/challenges' && m === 'GET') return out(challenges.list(u));
  if (pathname === '/api/challenges/payouts' && m === 'GET') return out(challenges.myPayouts(u));
  if (pathname === '/api/challenges/leaderboard' && m === 'GET') return out(challenges.leaderboard());
  if (pathname === '/api/challenges/admin' && m === 'GET') return out(challenges.admin(u));
  if (pathname === '/api/challenges/admin' && m === 'POST') {
    const b = await json(); if (!b) return send(res, 400, { code: 'bad_request' });
    const findUser = (email) => (email && /^[^\s@]+@[^\s@]+$/.test(email) ? (growth.members?.() || []).find((x) => String(x.email || '').toLowerCase() === email) || null : null);
    return out(challenges.adminAct(u, b, findUser));
  }
  const id = parts[0]; if (!CH_ACC_RE.test(String(id || ''))) return send(res, 404, { code: 'not_found' });
  if (parts.length === 1 && m === 'GET') return out(await challenges.view(u, id));
  if (parts[1] === 'order' && parts.length === 2 && m === 'POST') { const b = await json(); if (!b) return send(res, 400, { code: 'bad_request' }); return out(await challenges.order(u, id, b)); }
  if (parts[1] === 'close' && parts.length === 3 && m === 'POST') return out(await challenges.close(u, id, parts[2]));
  if (parts[1] === 'modify' && parts.length === 3 && m === 'POST') { const b = await json(); if (!b) return send(res, 400, { code: 'bad_request' }); return out(challenges.modify(u, id, parts[2], b)); }
  if (parts[1] === 'cancel' && parts.length === 3 && m === 'POST') return out(challenges.cancel(u, id, parts[2]));
  if (parts[1] === 'public' && parts.length === 2 && m === 'POST') { const b = await json(256); if (!b) return send(res, 400, { code: 'bad_request' }); return out(challenges.setPublic(u, id, b)); }
  if (parts[1] === 'retry' && parts.length === 2 && m === 'POST') {   // v285: discounted new challenge after a failed one
    if (rateLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' });
    const q = challenges.retryQuote(u, id); if (q.error) return out(q);
    try { const r = await billing.checkout({ uid: u.uid, email: u.email, product: q.product, origin: req.headers.origin, retry: { account: q.account, pct: q.pct } }); if (r.status !== 200) challenges.retryRelease(u, id); return send(res, r.status, r.body); }
    catch { challenges.retryRelease(u, id); return send(res, 502, { code: 'stripe_error' }); }
  }
  if (parts[1] === 'payout' && parts.length === 2 && m === 'POST') { const b = await json(); if (!b) return send(res, 400, { code: 'bad_request' }); return out(challenges.requestPayout(u, id, b)); }
  return send(res, 404, { code: 'not_found' });
}
if (!IS_TEST) setInterval(() => { arena.refresh().catch(() => {}); }, 10 * 60_000).unref();

/* ───────── v251 routes: /api/rooms/*, /api/experts, /api/arena/* ───────── */
const ipHashOf = (req) => crypto.createHash('sha256').update(`ip|${clientIp(req)}|${process.env.AI_KEY_SECRET || ''}`).digest('hex').slice(0, 20);
// v255 Alpha Partner Club. Every decision (attribution, commission, approval, payout) is made on the server; owners are checked
// with isOwnerEmail on the server for every /admin call.
// v262 Telegram channel gate (subscribers only): member view + owner controls
async function handleTgGate(req, res, pathname) {
  const m = req.method; if (m !== 'GET' && !originOk(req, res)) return;
  const u = await requireUser(req, res); if (!u) return;
  const json = async () => { try { return JSON.parse(await readBody(req, 4096)); } catch { return null; } };
  if (pathname === '/api/tg-gate/me' && m === 'GET') return send(res, 200, tgGate.userView(u.uid, growth.tgOf(u.uid)));
  if (!isOwnerEmail(u)) return send(res, 403, { code: 'forbidden' });
  if (pathname === '/api/tg-gate/admin' && m === 'GET') return send(res, 200, { ...tgGate.status(), bot: await tgGate.botRights() });
  if (pathname === '/api/tg-gate/admin' && m === 'PUT') { const r = tgGate.setConfig(await json() || {}); return send(res, r.error ? 400 : 200, r.error ? { code: r.error } : r); }
  if (pathname === '/api/tg-gate/admin/invite' && m === 'POST') { const r = await tgGate.createInvite(); return send(res, r.error ? 409 : 200, r.error ? { code: r.error, message: r.message } : r); }
  if (pathname === '/api/tg-gate/admin/sweep' && m === 'POST') return send(res, 200, await tgGate.sweep({ force: true }));
  return send(res, 404, { code: 'not_found' });
}
const PARTNERS_RE = /^\/api\/partners(\/.*)?$/;
// v261: ALPHA PARTNER CLUB is only for members of the site's Telegram channel. Membership is checked with the Bot API
// (getChatMember) for the Telegram account the user linked on the site (/start link) — never trusted from the page.
const gateCache = new Map();
async function partnerGate(u) {
  const g = partners.adminConfig().gate || {}; const tgs = tgGate.status().config; const inviteUrl = g.inviteUrl || tgs.inviteEffective || '';
  if (isOwnerEmail(u)) return { allowed: true, owner: true, inviteUrl };
  if (!g.telegram) return { allowed: true, inviteUrl };
  const eff = effectiveNotify(savedNotify()); if (!eff.telegramToken || !eff.telegramChatId) return { allowed: false, reason: 'telegram_not_configured', inviteUrl };
  const tgId = growth.tgOf?.(u.uid); if (!tgId) return { allowed: false, reason: 'tg_not_linked', inviteUrl };
  const k = `${u.uid}|${tgId}`; const c = gateCache.get(k); if (c && c.exp > Date.now()) return c.v;
  let v;
  try {
    const r = await fetch(`${NOTIFY_TG_BASE || 'https://api.telegram.org'}/bot${eff.telegramToken}/getChatMember`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: tgs.channelEffective || eff.telegramChatId, user_id: tgId }), signal: AbortSignal.timeout(8_000) });
    const j = await r.json().catch(() => ({})); const st = j?.result?.status;
    if (!j.ok) v = { allowed: false, reason: 'check_failed', inviteUrl, tgLinked: true };
    else v = ['creator', 'administrator', 'member'].includes(st) || (st === 'restricted' && j.result.is_member) ? { allowed: true, tgLinked: true, inviteUrl } : { allowed: false, reason: 'not_member', tgLinked: true, inviteUrl };
  } catch { v = { allowed: false, reason: 'check_failed', inviteUrl, tgLinked: true }; }
  if (gateCache.size > 20000) gateCache.clear(); gateCache.set(k, { v, exp: Date.now() + (v.allowed ? 10 * 60_000 : 45_000) });
  return v;
}
const partnerClicks = new Map();
async function handlePartners(req, res, pathname, searchParams) {
  const m = req.method; const sub = pathname.slice('/api/partners'.length) || '/';
  if (m !== 'GET' && !originOk(req, res)) return;
  if (!partners.canSave()) return send(res, 503, { code: 'no_secret' });
  const json = async (n = 64 * 1024) => { try { return JSON.parse(await readBody(req, n)); } catch { return null; } };
  const out = (r) => send(res, r?.error ? (r.error === 'forbidden' ? 403 : r.error === 'not_found' ? 404 : 409) : 200, r?.error ? { code: r.error, ...(r.details ? { details: r.details } : {}), ...(r.min != null ? { min: r.min } : {}) } : r);
  if (sub === '/click' && m === 'POST') {   // no sign-in needed (someone opened a partner link); one count per network per day
    const ip = clientIp(req); const w = Math.floor(Date.now() / 60_000); const h = partnerClicks.get(ip); if (h && h.w === w && h.n > 20) return send(res, 429, { code: 'rate_limited' });
    partnerClicks.set(ip, { w, n: h && h.w === w ? h.n + 1 : 1 }); if (partnerClicks.size > 20000) partnerClicks.clear();
    const b = await json(512) || {}; return send(res, 200, partners.click(String(b.code || '').slice(0, 30), ipHashOf(req)));
  }
  const u = await requireUser(req, res); if (!u) return;
  partners.seenIp(u.uid, ipHashOf(req));
  if (sub === '/access' && searchParams.get('fresh')) for (const k of gateCache.keys()) if (k.startsWith(`${u.uid}|`)) gateCache.delete(k);
  const gate = await partnerGate(u);
  if (sub === '/access' && m === 'GET') return send(res, 200, gate);
  if (!gate.allowed && (sub === '/me' && m === 'GET')) return send(res, 200, { gated: true, ...gate });
  if (!gate.allowed && (sub === '/join' || sub === '/payout')) return send(res, 403, { code: 'telegram_required', reason: gate.reason });
  if (sub === '/me' && m === 'GET') return send(res, 200, partners.me(u));
  if (sub === '/join' && m === 'POST') return out(partners.join(u, { ipHash: ipHashOf(req) }));
  if (sub === '/attach' && m === 'POST') { const b = await json(512) || {}; return out(partners.attach(u, String(b.code || '').slice(0, 30), { ipHash: ipHashOf(req), via: b.via === 'coupon' ? 'coupon' : 'link' })); }
  if (sub === '/payout' && m === 'POST') { const b = await json(2048) || {}; return out(partners.requestPayout(u, b)); }
  if (sub.startsWith('/admin')) {
    if (!isOwnerEmail(u)) return send(res, 403, { code: 'forbidden' });
    if (sub === '/admin' && m === 'GET') return send(res, 200, partners.adminView());
    if (sub === '/admin/config' && m === 'POST') { const b = await json(256 * 1024); if (!b) return send(res, 400, { code: 'bad_request' }); return out(partners.setConfig(b)); }
    if (sub === '/admin/act' && m === 'POST') { const b = await json(4096); if (!b) return send(res, 400, { code: 'bad_request' }); return out(partners.adminAct({ ...b, by: u.email })); }
    if (sub === '/admin/telegram' && m === 'POST') {   // v260: post + pin the club button in the Telegram channel, and the bot's menu button
      const b = await json(2048) || {}; const eff = effectiveNotify(savedNotify());
      if (!eff.telegramToken || !eff.telegramChatId) return send(res, 409, { code: 'telegram_not_configured' });
      const base = String(process.env.PUBLIC_URL || req.headers.origin || '').replace(/\/+$/, ''); if (!/^https?:\/\/[^/]+$/.test(base)) return send(res, 400, { code: 'bad_origin' });
      const url = `${base}/#/app/partners`; const tgBase = NOTIFY_TG_BASE || 'https://api.telegram.org';
      const call = async (method, body) => { try { const r = await fetch(`${tgBase}/bot${eff.telegramToken}/${method}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(12_000) }); const j = await r.json().catch(() => ({})); return { ok: Boolean(j.ok), result: j.result, error: j.ok ? null : String(j.description || r.status).split(eff.telegramToken).join('***').slice(0, 160) }; } catch (e) { return { ok: false, error: String(e?.message || e).split(eff.telegramToken).join('***').slice(0, 120) }; } };
      const ar = b.lang !== 'en';
      const text = ar
        ? '🏆 ALPHA PARTNER CLUB\n\nانضم لنادي ألفا للشركاء: شارك رابطك أو كوبونك، وخذ عمولة على كل اشتراك مدفوع عن طريقك وعمولة على تجديداته. 9 رتب و100 مستوى.\n\nالعمولة بس على مدفوعات حقيقية مؤكدة — ما في دخل مضمون.\n\n👇 اضغط الزر وادخل النادي'
        : '🏆 ALPHA PARTNER CLUB\n\nJoin the Alpha Partner Club: share your link or coupon and earn a commission on every paid subscription through you, and on its renewals. 9 ranks, 100 levels.\n\nCommissions only on real, confirmed payments — no guaranteed income.\n\n👇 Tap the button to open the club';
      const out = {};
      const post = await call('sendMessage', { chat_id: eff.telegramChatId, text, disable_web_page_preview: true, reply_markup: { inline_keyboard: [[{ text: '🏆 ALPHA PARTNER CLUB', url }]] } });
      out.post = post.ok ? { ok: true, messageId: post.result?.message_id } : { ok: false, error: post.error };
      if (post.ok && b.pin !== false) { const pin = await call('pinChatMessage', { chat_id: eff.telegramChatId, message_id: post.result?.message_id, disable_notification: true }); out.pin = pin.ok ? { ok: true } : { ok: false, error: pin.error }; }
      if (b.menu !== false) {
        if (!base.startsWith('https://')) out.menu = { ok: false, error: 'https_required' };
        else { const mb = await call('setChatMenuButton', { menu_button: { type: 'web_app', text: 'ALPHA PARTNER CLUB', web_app: { url } } }); out.menu = mb.ok ? { ok: true } : { ok: false, error: mb.error }; }
      }
      partners.noteTelegram({ at: Date.now(), messageId: out.post.messageId || null, pinned: Boolean(out.pin?.ok), menu: Boolean(out.menu?.ok), by: u.email });
      return send(res, out.post.ok ? 200 : 502, out);
    }
    if (sub === '/admin/export' && m === 'GET') { const t = String(searchParams.get('type') || 'commissions'); const csv = partners.exportCsv(t); res.writeHead(200, { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="partners-${t.replace(/\W/g, '')}.csv"`, 'cache-control': 'no-store' }); return res.end(csv); }
  }
  return send(res, 404, { code: 'not_found' });
}
const ROOMS_RE = /^\/api\/(rooms|arena|experts|mentors)(\/.*)?$/;
async function handleRooms(req, res, pathname, searchParams) {
  const m = req.method;
  if (m !== 'GET' && !originOk(req, res)) return;
  // no 20/min per-IP cap here (chat + meeting set-up need more): the per-account limit (USER_PER_MINUTE) and the rooms' own
  // anti-spam limits apply; AI calls keep their own limits
  const u = await requireUser(req, res); if (!u) return;
  if (!rooms.canSave()) return send(res, 503, { code: 'no_secret' });
  const json = async (n = 16 * 1024) => { try { return JSON.parse(await readBody(req, n)); } catch { return null; } };
  const out = (r, ok = 200) => send(res, r?.error ? (r.error === 'not_found' ? 404 : r.error === 'forbidden' || r.error === 'banned' ? 403 : 400) : ok, r?.error ? { code: r.error } : r);
  let mm; const ID = '([A-Z2-9]{6})';
  if (pathname === '/api/mentors' && m === 'GET') return send(res, 200, { items: MENTORS.map(({ prompt, ...x }) => x) });
  if (pathname === '/api/experts' && m === 'GET') return send(res, 200, rooms.experts());
  if (pathname === '/api/experts/apply' && m === 'POST') return out(rooms.applyExpert(u, await json(4096) || {}));
  if (pathname === '/api/arena' && m === 'GET') return send(res, 200, arena.list(u, { symbol: searchParams.get('symbol') || null, tf: searchParams.get('tf') || null }));
  if (pathname === '/api/arena' && m === 'POST') return out(await arena.submit(u, await json(8192) || {}));
  if ((mm = pathname.match(/^\/api\/arena\/(e[0-9a-f]{12})$/)) && m === 'POST') return out(arena.act(u, mm[1], await json(1024) || {}));
  if (pathname === '/api/rooms' && m === 'GET') return send(res, 200, rooms.dashboard(u));
  if (pathname === '/api/rooms' && m === 'POST') { const b = await json(3 * 1024 * 1024); if (!b) return send(res, 413, { code: 'too_large' }); return out(rooms.create(u, b)); }
  if (pathname === '/api/rooms/directory' && m === 'GET') return send(res, 200, rooms.directory(u, searchParams.get('q') || ''));
  if (pathname === '/api/rooms/leaderboard' && m === 'GET') return send(res, 200, rooms.leaderboard(searchParams.get('period') === 'month' ? 'month' : 'week'));
  if (pathname === '/api/rooms/preview' && m === 'POST') return out(rooms.preview(u, await json(1024) || {}));
  if (pathname === '/api/rooms/join' && m === 'POST') return out(rooms.join(u, await json(2048) || {}));
  if (pathname === '/api/rooms/admin' && m === 'GET') return out(rooms.admin(u));
  if (pathname === '/api/rooms/admin' && m === 'POST') return out(rooms.adminAct(u, await json(4096) || {}));
  if ((mm = pathname.match(new RegExp(`^/api/rooms/${ID}/file/(x[0-9a-f]{12})$`))) && m === 'GET') {
    const f = rooms.getFile(u, mm[1], mm[2]); if (!f) return send(res, 404, { code: 'not_found' });
    res.writeHead(200, { 'Content-Type': f.type, 'Cache-Control': 'private, max-age=3600', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'" }); return res.end(f.data);
  }
  if (!(mm = pathname.match(new RegExp(`^/api/rooms/${ID}(?:/([a-z]+))?(?:/([a-z][0-9a-f]{8,12}))?$`)))) return send(res, 404, { code: 'not_found' });
  const [, id, sub = '', sid = ''] = mm;
  if (!sub && m === 'GET') return out(rooms.poll(u, id, searchParams.get('since')));
  if (!sub && m === 'PATCH') { const b = await json(3 * 1024 * 1024); if (!b) return send(res, 413, { code: 'too_large' }); return out(rooms.updateSettings(u, id, b)); }
  if (sub === 'messages' && m === 'POST' && !sid) { const b = await json(2.2 * 1024 * 1024); if (!b) return send(res, 413, { code: 'too_large' }); return out(rooms.post(u, id, b)); }
  if (sub === 'messages' && m === 'POST' && sid) return out(rooms.editMsg(u, id, sid, await json(4096) || {}));
  if (sub === 'search' && m === 'GET') return out(rooms.search(u, id, searchParams.get('q') || ''));
  if (sub === 'report' && m === 'POST') return out(rooms.report(u, id, await json(2048) || {}));
  if (sub === 'invite' && m === 'POST') return out(rooms.invite(u, id, await json(1024) || {}));
  if (sub === 'decide' && m === 'POST') return out(rooms.decide(u, id, await json(1024) || {}));
  if (sub === 'leave' && m === 'POST') return out(rooms.leave(u, id));
  if (sub === 'manage' && m === 'POST') return out(rooms.manage(u, id, await json(1024) || {}));
  if (sub === 'fav' && m === 'POST') return out(rooms.fav(u, id, Boolean((await json(256) || {}).on)));
  if (sub === 'workspace' && m === 'POST') return out(rooms.workspace(u, id, await json(8192) || {}));
  if (sub === 'predict' && m === 'POST') return out(await rooms.predict(u, id, await json(8192) || {}));
  if (sub === 'vote' && m === 'POST' && sid) return out(rooms.vote(u, id, sid, await json(512) || {}));
  if (sub === 'meeting' && m === 'POST') return out(rooms.meeting(u, id, await json(80 * 1024) || {}));
  if (sub === 'ai' && m === 'POST') return out(await rooms.ai(u, id, await json(8192) || {}));
  if (sub === 'aiconfig' && m === 'POST') return out(rooms.setAi(u, id, await json(1024) || {}));
  return send(res, 404, { code: 'not_found' });
}
const quoteHits = new Map();
function quoteLimited(ip) {
  const w = Math.floor(Date.now() / 60_000); const h = quoteHits.get(ip);
  if (!h || h.w !== w) { if (quoteHits.size > 20000) quoteHits.clear(); quoteHits.set(ip, { w, n: 1 }); return false; }
  h.n += 1; return h.n > 300;   // 5 a second: one tab polls once a second
}
const MARKET_PROXY = [
  { re: /^\/yahoo(\/v8\/finance\/chart\/[A-Za-z0-9^=.\-%]{1,40})$/, base: PROXY_TEST_BASE || 'https://query1.finance.yahoo.com' },
  { re: /^\/binance(\/api\/v3\/(?:klines|ticker\/24hr|ticker\/price|depth|aggTrades|exchangeInfo))$/, base: PROXY_TEST_BASE || 'https://data-api.binance.vision' },
];
// Its own, higher per-IP budget: the channel scanner reads many markets per minute (the AI limit would block it).
const proxyHits = new Map();
function proxyLimited(ip) {
  const now = Date.now(); const arr = (proxyHits.get(ip) || []).filter((t) => now - t < 60_000); arr.push(now); proxyHits.set(ip, arr);
  if (proxyHits.size > 5000) for (const [k, v] of proxyHits) if (!v.some((x) => now - x < 60_000)) proxyHits.delete(k);
  return arr.length > 600;
}
// v229 (load test): one shared cache + request coalescing in front of the upstreams (server/proxyCache.js). Before, every
// visitor request went 1:1 to Binance / Yahoo from this server's single IP.
const proxyCache = createProxyCache({ maxUpstream: Number(process.env.PROXY_MAX_UPSTREAM || 48) });
async function proxyMarket(req, res, target) {
  try {
    const r = await proxyCache.get(target, { ttl: marketTtl(target), headers: { 'User-Agent': 'Mozilla/5.0 (AlphaTrade AI)', Accept: 'application/json' }, timeoutMs: 10000 });
    res.writeHead(r.status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Cache': r.cache, 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "sandbox; default-src 'none'" });
    res.end(r.body);
  } catch { send(res, 502, { error: 'Upstream unavailable' }, { 'Retry-After': '2' }); }
}
async function proxyFF(res, target) {
  try {
    // had no timeout before: a hanging upstream kept every caller's connection open
    const r = await proxyCache.get(target, { ttl: 60_000, headers: { 'User-Agent': 'Mozilla/5.0 (AlphaTrade AI)', Accept: '*/*' }, timeoutMs: 10000 });
    // Third-party content served from our own origin: forbid it from running scripts or being sniffed as something else.
    res.writeHead(r.status, { 'Content-Type': r.type || 'text/plain', 'Cache-Control': 'max-age=60', 'X-Cache': r.cache, 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "sandbox; default-src 'none'" });
    res.end(r.body);
  } catch (err) { console.warn('[ff] fetch failed:', err.message || err); send(res, 502, { error: 'Upstream unavailable' }, { 'Retry-After': '5' }); }
}

// v231 Alpha Elite Signals: picks are made on the server from the 24/7 worker's recommendations (same for every member),
// every 20 s even when nobody is watching, and kept in DATA_DIR/elite.json (public market data only — no personal data).
const ELITE_FILE = path.join(DATA_DIR, 'elite.json');
const elite = { state: (() => { try { const j = JSON.parse(fs.readFileSync(ELITE_FILE, 'utf8')); return Array.isArray(j?.picks) ? j : { picks: [] }; } catch { return { picks: [] }; } })() };
const eliteWriter = writeBehind(() => { try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(`${ELITE_FILE}.tmp`, JSON.stringify(elite.state)); fs.renameSync(`${ELITE_FILE}.tmp`, ELITE_FILE); } catch (e) { console.error('[elite] save failed:', e.message); } }, { delayMs: STORE_WRITE_DELAY_MS });
// v247: the signals come from the Elite market scanner (src/services/eliteScanner.js) that the 24/7 worker runs; it writes
// WORKER_DATA_DIR/elite-signals.json. This tick only reads it and announces each NEW signal once to every member.
let eliteFileCache = { key: '', data: null }; const ELITE_SINCE = Date.now() - 60_000;
function eliteFile() {
  const f = path.join(process.env.WORKER_DATA_DIR || path.join(root, 'worker-data'), 'elite-signals.json');
  const st = fs.statSync(f); const key = `${st.mtimeMs}|${st.size}`;
  if (eliteFileCache.key !== key) { const j = JSON.parse(fs.readFileSync(f, 'utf8')); eliteFileCache = { key, data: j && Array.isArray(j.signals) ? j : { signals: [] } }; }
  return eliteFileCache.data;
}
function eliteTick(now = Date.now()) {
  let data;
  try { data = eliteFile(); } catch { return false; }   // no Elite scanner on this host
  elite.state.announced ||= [];
  const seen = new Set(elite.state.announced);
  // only signals made while this server runs are announced (a restart never re-rings old ones), each one once
  const fresh = data.signals.filter((x) => x && typeof x.id === 'string' && !seen.has(x.id) && ELITE_LIVE.includes(x.status) && (x.createdAt || 0) >= ELITE_SINCE && now - (x.createdAt || 0) < 15 * 60_000);
  let grew = false; for (const x of data.signals) if (x?.id && !seen.has(x.id)) { seen.add(x.id); grew = true; }
  if (grew) { elite.state.announced = [...seen].slice(-2000); eliteWriter.schedule(); }
  if (fresh.length) { console.log(`[elite] ${fresh.map((p) => `${p.symbol} ${p.strategy} ${p.direction}`).join(' · ')}`); announceElite(fresh.slice(0, 6)); }
  return true;
}
function eliteFeed(now = Date.now()) {
  const data = eliteFile();
  const recent = data.signals.filter((x) => ELITE_LIVE.includes(x.status) || now - (x.closedAt || x.createdAt || 0) < 7 * 86_400_000).slice(0, 200);
  const markets = ELITE_MARKETS.map((m) => { const a = eliteAvailability(m); const ms = data.markets?.[m.id] || {}; return { id: m.id, cat: m.cat, region: m.region || null, symbol: m.symbol, state: a.ok ? (ms.state || 'pending') : 'unavailable', reason: a.ok ? (ms.reason || null) : a.reason, at: ms.at || null }; });
  return { configured: true, at: now, signals: recent, markets, summary: eliteSummary(recent), lastScan: data.lastScan || null, lastTrack: data.lastTrack || null };
}
// v237: every new Elite pick reaches every member automatically — phone push and Telegram (when linked), also with the site
// closed. One message per pick (tag = pick id: the open page's own alert replaces it silently instead of ringing twice).
// Sent in the background, a few at a time, so a big member list never slows the server.
let eliteQueue = Promise.resolve();
function announceElite(picks) {
  const list = growth.members?.() || []; if (!list.length) return;
  eliteQueue = eliteQueue.then(async () => {
    for (const p of picks) for (let i = 0; i < list.length; i += 20) {
      await Promise.all(list.slice(i, i + 20).map((m) => growth.deliver?.(m.uid, { kind: 'elite', tag: p.id, icon: '/elite/elite-icon-192.png', title: ELITE_BRAND, body: eliteAlertBody(p, m.lang, pairName), tgBody: eliteTelegramText(p, m.lang, pairName), url: '/#/app/elite', push: true, tg: true })?.catch?.(() => null)));
    }
  }).catch((e) => console.error('[elite] announce:', String(e?.message || e).slice(0, 80)));
}
if (!IS_TEST || process.env.ELITE_TEST === '1') setInterval(() => { try { eliteTick(); } catch (e) { console.error('[elite]', e.message); } }, IS_TEST ? 500 : 20_000).unref();

// v229: the worker's state file was read + parsed twice (outer JSON, then the signals JSON) on EVERY feed request.
const FEED_PER_MINUTE = Number(process.env.FEED_IP_PER_MINUTE || 120);
const feedHits = new Map();
function feedLimited(ip) {
  const now = Date.now(); const arr = (feedHits.get(ip) || []).filter((t) => now - t < 60_000); arr.push(now); feedHits.set(ip, arr);
  if (feedHits.size > 5000) for (const [k, v] of feedHits) if (!v.some((x) => now - x < 60_000)) feedHits.delete(k);
  return arr.length > FEED_PER_MINUTE;
}
let workerCache = { file: '', key: '', rows: null };
function workerSignals(file) {
  const st = fs.statSync(file); const key = `${st.mtimeMs}|${st.size}`;
  if (workerCache.file === file && workerCache.key === key) return workerCache.rows;
  const state = JSON.parse(fs.readFileSync(file, 'utf8'));
  const rows = JSON.parse(state['ata:signals'] || '[]');
  workerCache = { file, key, rows }; return rows;
}

// v229 load shedding: when the event loop is overloaded (median delay over the last second above SHED_LAG_MS), new API work is
// answered at once with 503 + Retry-After instead of queueing until everything times out. Never shed: health, static files,
// payments webhook, MT5 EA, owner AI config. The page already retries on its own (polls).
const SHED_LAG_MS = Number(process.env.SHED_LAG_MS || 500);
// Lag = how late a 50 ms timer fires. Overloaded when the median lag of the last second is above SHED_LAG_MS; it clears as soon
// as a second passes with the median back under it.
let overloaded = false; let shedCount = 0; let badSecs = 0; let lagWin = []; let lagMax = 0; let lagLast = 0;
{ let expect = performance.now() + 50;
  setInterval(() => { const now = performance.now(); lagWin.push(Math.max(0, now - expect)); expect = now + 50; }, 50).unref();
  setInterval(() => { const w = lagWin.sort((a, b) => a - b); lagWin = []; const med = w.length ? w[Math.floor(w.length / 2)] : 0;
    lagLast = w.length ? w[w.length - 1] : 0; lagMax = Math.max(lagMax * 0.9, lagLast);
    // v230: only a SUSTAINED overload sheds (3 seconds in a row). A single slow second (a CPU-limited container, a
    // backup, a garbage collection) must never refuse sign-ins or settings calls.
    const bad = med > SHED_LAG_MS || w.length < 3; badSecs = bad ? badSecs + 1 : 0;
    overloaded = SHED_LAG_MS > 0 && badSecs >= 3; }, 1000).unref(); }
const NEVER_SHED = /^\/api\/(health|billing\/|mt5\/|ai\/config|bank\/|me\/signin|me\/phone|admin\/)/;
const sheddable = (p) => p.startsWith('/api/') && !NEVER_SHED.test(p);

const server = http.createServer(async (req, res) => {
  if (req.url.startsWith('/api/')) res.on('finish', () => { try { secMon.observe(req, res, req.url.split('?')[0], clientIp(req)); } catch { /* never breaks a request */ } });
  try {
    await route(req, res);
  } catch (err) {
    if (!res.headersSent) send(res, 500, { error: 'Server error' }); else res.end();
  }
});

async function route(req, res) {
  const { pathname, searchParams } = new URL(req.url, 'http://x');
  if (overloaded && sheddable(pathname)) { shedCount++; return send(res, 503, { code: 'busy', error: 'Server busy, retrying shortly.' }, { 'Retry-After': '2' }); }
  if (FF_ROUTES[pathname] && req.method === 'GET') return proxyFF(res, FF_ROUTES[pathname]);
  if (pathname === '/api/market/quotes' && req.method === 'GET') {   // public market prices (no personal data), refreshed every second
    if (quoteLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' }, { 'Retry-After': '5' });
    const list = [...new Set(String(searchParams.get('s') || '').split(',').map((x) => x.trim().toUpperCase()).filter((x) => /^[A-Z0-9]{2,12}$/.test(x) && YAHOO_SYMBOLS[x]))].slice(0, 40);
    if (!list.length) return send(res, 400, { code: 'no_symbols' });
    const quotes = await quoteHub.get(list);
    return send(res, 200, { at: Date.now(), source: 'Yahoo Finance', quotes });
  }
  if (req.method === 'GET' && (pathname.startsWith('/yahoo/') || pathname.startsWith('/binance/'))) {
    for (const m of MARKET_PROXY) {
      const hit = pathname.match(m.re);
      if (!hit) continue;
      if (proxyLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' });
      const qs = new URL(req.url, 'http://x').search;
      return proxyMarket(req, res, `${m.base}${hit[1]}${qs.length <= 300 ? qs : ''}`);
    }
    return send(res, 404, { error: 'not found' });
  }
  if (pathname === '/api/health' && req.method === 'GET') {
    const bk = backups.status();
    return send(res, 200, { ok: true, uptimeS: Math.round((Date.now() - STARTED) / 1000), load: { overloaded, shed: shedCount, loopLagMs: +lagLast.toFixed(1), proxy: proxyCache.stats() }, bank: bankRt.enabled ? (bankRt.mode || 'on') : 'off', backups: { enabled: bk.enabled, count: bk.count, last: bk.last, stale: bk.stale }, tradeWatch: { enabled: tradeWatch.status().enabled, lastRun: tradeWatch.status().lastRun } });
  }
  if (pathname === '/api/client-error' && req.method === 'POST') return handleClientError(req, res);
  if (pathname === '/api/admin/security' && req.method === 'GET') {   // v236: the owners' security view (events, alerts)
    const u = await requireUser(req, res); if (!u) return;
    if (!isOwnerEmail(u)) return send(res, 403, { code: 'not_owner' });
    return send(res, 200, secMon.summary());
  }
  if (pathname === '/api/mail/signin' && req.method === 'POST') { if (!originOk(req, res)) return; const u = await requireUser(req, res); if (!u) return; const r = await mailer.onSignin(u); return send(res, 200, { ok: true, sent: r.sent }); }
  if (pathname.startsWith('/api/face/') || pathname === '/api/face') return handleFace(req, res, pathname);
  if (pathname === '/api/mt5' || pathname.startsWith('/api/mt5/')) return handleMt5(req, res, pathname);
  if (COMMUNITY_RE.test(pathname)) return handleCommunity(req, res, pathname, searchParams);
  if (pathname.startsWith('/api/tg-gate/')) return handleTgGate(req, res, pathname);
  if (PARTNERS_RE.test(pathname)) return handlePartners(req, res, pathname, searchParams);
  if (ROOMS_RE.test(pathname)) return handleRooms(req, res, pathname, searchParams);
  if (CH_RE.test(pathname)) return handleChallenges(req, res, pathname);
  if (pathname.startsWith('/api/me/') || pathname.startsWith('/api/contest') || pathname === '/api/admin/broadcast' || pathname.startsWith('/api/tv/')) return handleMembers(req, res, pathname);
  if (pathname.startsWith('/api/billing/')) return handleBilling(req, res, pathname);
  if (pathname === '/api/ai/health' && req.method === 'GET') { const st = statusFor(null); return send(res, 200, { ok: true, configured: st.state === 'connected' || st.state === 'unchecked', state: st.state, vision: st.vision }); }
  if (pathname === '/api/ai/status' && req.method === 'GET') return handleStatus(req, res);
  if (pathname === '/api/ai/config' && req.method === 'PUT') return handleConfigPut(req, res);
  if (pathname === '/api/ai/config' && req.method === 'DELETE') return handleConfigDelete(req, res);
  if (pathname === '/api/ai/config/test' && req.method === 'POST') return handleConfigTest(req, res);
  if (req.method === 'POST') {
    const h = { '/api/ai/mentor': handleMentor, '/api/ai/chat': handleChat, '/api/ai/support': handleSupport, '/api/ai/explain': handleExplain, '/api/ai/smc': handleSmc, '/api/ai/review': handleReview, '/api/ai/images/describe': handleDescribe, '/api/ai/images/match': handleMatch }[pathname];
    if (h) return h(req, res);
  }
  if (pathname === '/api/user/trades' || pathname.startsWith('/api/user/trades/')) return handleUserTrades(req, res, pathname);
  if (pathname === '/api/user/export' && req.method === 'GET') {
    const u = await requireUser(req, res); if (!u) return;
    if (rateLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' });
    const bankWallet = bankRt.bank ? (() => { try { return bankRt.bank.wallet(u.uid); } catch { return null; } })() : null;
    return send(res, 200, { exportedAt: new Date().toISOString(), account: { uid: u.uid, email: u.email, name: u.name || null },
      subscription: channelAccess.account(u.uid), payments: ledger.forUser(u.uid), members: growth.exportUser(u.uid), aiUsage: ent.aiAllowance(u.uid), trades: userTrades.canSave() ? userTrades.list(u.uid) : [],
      bank: bankWallet ? { wallet: bankWallet, note: 'Full bank statements: Bank → History (CSV), or ask support.' } : null }, { 'Content-Disposition': 'attachment; filename="alphatrade-my-data.json"' });
  }
  if (pathname === '/api/user/account' && req.method === 'DELETE') return handleDeleteAccount(req, res);
  if (pathname === '/api/channel/feed' && req.method === 'GET') {
    if (req.headers.origin && !originOk(req,res)) return;
    // v229: a read with its own per-IP budget (120/min). It shared the 20/min API budget, so visitors behind one shared
    // mobile-carrier / office IP were refused the channel after a few polls.
    if (feedLimited(clientIp(req))) return send(res,429,{code:'rate_limited'}, { 'Retry-After': '10' });
    const user = await requireUser(req, res); if (!user) return;
    let signals = [], configured = false;
    try {
      const rows = workerSignals(path.join(process.env.WORKER_DATA_DIR || path.join(root,'worker-data'),'state.json'));
      if (Array.isArray(rows)) { signals = rows; configured = true; }
    } catch { /* report worker unavailable separately from an empty channel */ }
    return send(res,200,channelAccess.feed(user.uid, signals, { owner: Boolean(isOwnerEmail(user)), configured }));
  }
  if (pathname === '/api/elite/feed' && req.method === 'GET') {   // v231 Alpha Elite Signals: one shared live feed
    if (req.headers.origin && !originOk(req, res)) return;
    if (feedLimited(clientIp(req))) return send(res, 429, { code: 'rate_limited' }, { 'Retry-After': '10' });
    const user = await requireUser(req, res); if (!user) return;
    if (!eliteTick()) return send(res, 200, { configured: false, at: Date.now(), signals: [], markets: [], summary: eliteSummary([]) });
    return send(res, 200, eliteFeed());
  }
  if (pathname === '/api/channel/grant' && req.method === 'POST') {
    const owner = await ownerOnly(req,res); if (!owner) return;
    let input; try { input=JSON.parse(await readBody(req,8192)); } catch { return send(res,400,{code:'bad_request'}); }
    try { return send(res,200,channelAccess.grant(input.uid,input)); }
    catch (e) { return send(res,400,{code:e.message}); }
  }
  if (pathname.startsWith('/api/bank/')) {
    if (!bankRt.handle) return send(res, 503, { error: 'bank_disabled', code: 'bank_disabled', reason: bankRt.reason || 'unavailable' });
    if (await bankRt.handle(req, res, pathname, searchParams)) return;
  }
  if (pathname === '/api/notify/status' && req.method === 'GET') return handleNotifyStatus(req, res);
  if (pathname === '/api/notify/config' && req.method === 'PUT') return handleNotifyPut(req, res);
  if (pathname === '/api/notify/config' && req.method === 'DELETE') return handleNotifyDelete(req, res, searchParams);
  if (pathname === '/api/notify/config/test' && req.method === 'POST') return handleNotifyTest(req, res);
  if (pathname === '/api/market/status' && req.method === 'GET') return handleMarketStatus(req, res);
  if (pathname === '/api/market/config' && req.method === 'PUT') return handleMarketPut(req, res);
  if (pathname === '/api/market/config' && req.method === 'DELETE') return handleMarketDelete(req, res);
  if (pathname === '/api/market/config/test' && req.method === 'POST') return handleMarketTest(req, res);
  if (pathname === '/api/market/twelve' && req.method === 'POST') {
    if (!marketGate(req, res)) return;
    let text = '';
    try {
      for await (const chunk of req) { text += chunk; if (text.length > 4096) return send(res,413,{error:'Request too large'}); }
      const result = await marketProxy(JSON.parse(text), activeMarketKey(), MARKET_BASE === 'https://api.twelvedata.com' ? fetch : (u, o) => fetch(String(u).replace('https://api.twelvedata.com', MARKET_BASE), o));
      return send(res,result.code,result.body);
    } catch { return send(res,400,{error:'Invalid request'}); }
  }
  if (pathname.startsWith('/api/')) return send(res, 404, { error: 'Not found' });
  if (SERVE_DIST) return serveStatic(req, res);
  return send(res, 404, { error: 'Frontend is served by Vite in development (npm run dev).' });
}

// v229 connection hygiene: slow / idle clients cannot hold sockets forever; keep-alive outlives typical proxy idle timeouts
// (avoids random 502s behind a load balancer); a hard cap on open sockets protects memory under a flood.
server.keepAliveTimeout = Number(process.env.KEEPALIVE_TIMEOUT_MS || 65_000);
server.headersTimeout = Number(process.env.HEADERS_TIMEOUT_MS || 20_000);
server.requestTimeout = Number(process.env.REQUEST_TIMEOUT_MS || 60_000);
server.maxConnections = Number(process.env.MAX_CONNECTIONS || 20_000);
// Graceful shutdown (deploys / restarts send SIGTERM): stop accepting, let running requests finish (≤ 10 s), write every
// pending store change, then exit. Before, pending work was simply cut off.
let stopping = false;
for (const sig of ['SIGTERM', 'SIGINT']) process.on(sig, () => {
  if (stopping) return; stopping = true;
  console.log(`[server] ${sig}: draining connections…`);
  const done = () => { flushAllStores(); process.exit(0); };
  server.close(done); server.closeIdleConnections?.();
  setTimeout(done, 10_000).unref();
});

server.listen(PORT, () => {
  console.log(`AlphaTrade AI server on http://localhost:${PORT}`);
  const st = statusFor(null);
  console.log(`AI gateway: ${st.state}${store.canSave() ? '' : ' — set AI_KEY_SECRET to let the owner save a key'}${PROJECT_ID ? '' : ' — set FIREBASE_PROJECT_ID to verify users'}`);
  if (SERVE_DIST) console.log(`Serving ./dist at http://localhost:${PORT}`);
  if (process.env.RUN_WORKER === '1' && !IS_TEST) startEmbeddedWorker();
});

// RUN_WORKER=1: run the 24/7 channel worker (server/worker.js) next to the web server in the SAME container, so a single
// hosting service (e.g. one Render web service) scans every market around the clock and /api/channel/feed can read its
// state. It is a separate process (a crash never takes the website down) and it is restarted with a back-off.
function startEmbeddedWorker() {
  import('node:child_process').then(({ fork }) => {
    const dir = process.env.WORKER_DATA_DIR || path.join(DATA_DIR, 'worker');
    process.env.WORKER_DATA_DIR = dir;   // the feed endpoint reads the same folder
    let delay = 5000;
    const run = () => {
      const child = fork(path.join(root, 'server', 'worker.js'), [], { env: { ...process.env, WORKER_DATA_DIR: dir, SERVER_NOTIFY_DIR: NOTIFY_DIR, PORT: '', WORKER_PORT: '' }, stdio: 'inherit' });
      const started = Date.now();
      child.on('exit', (code) => {
        if (Date.now() - started > 10 * 60_000) delay = 5000; else delay = Math.min(delay * 2, 5 * 60_000);
        console.warn(`[worker] exited (${code}); restarting in ${Math.round(delay / 1000)} s`);
        setTimeout(run, delay);
      });
    };
    run();
    console.log(`[worker] embedded 24/7 channel worker started — data in ${dir}`);
  }).catch((e) => console.warn('[worker] could not start:', e.message));
}
