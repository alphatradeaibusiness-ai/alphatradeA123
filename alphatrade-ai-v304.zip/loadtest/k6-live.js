// k6 load test for a DEPLOYED AlphaTrade AI (staging first; production only in a quiet window, with the team told).
//   k6 run -e BASE=https://staging.example.com -e PROFILE=load loadtest/k6-live.js
//   k6 run -e BASE=... -e PROFILE=stress -e TOKEN=<Firebase ID token of a TEST account> loadtest/k6-live.js
// PROFILE: smoke | load | stress | spike | soak.  TOKEN is optional (adds the signed-in polling calls).
// It sends only what a real visitor's browser sends. It never calls AI, payment, bank or owner endpoints, never writes
// anything except the visitor's own settings sync, and stops by itself when errors pass the abort thresholds.
// Note: from ONE machine every request has one IP, so the per-IP limits (429) will trigger — that is the protection working;
// spread the run over several load generators (k6 cloud / several machines) to measure capacity rather than the limiter.
import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Rate, Trend } from 'k6/metrics';

const BASE = (__ENV.BASE || '').replace(/\/$/, '');
if (!BASE) throw new Error('set -e BASE=https://your-staging-site');
const TOKEN = __ENV.TOKEN || '';
const errors = new Rate('app_errors');           // 5xx + network errors (429 is counted separately: it is the limiter)
const limited = new Rate('rate_limited');
const feedT = new Trend('feed_ms', true); const klinesT = new Trend('klines_ms', true);

const PROFILES = {
  smoke: { executor: 'constant-vus', vus: 5, duration: '1m' },
  load: { executor: 'ramping-vus', startVUs: 0, stages: [{ duration: '2m', target: 200 }, { duration: '5m', target: 500 }, { duration: '5m', target: 1000 }, { duration: '2m', target: 0 }] },
  stress: { executor: 'ramping-arrival-rate', startRate: 100, timeUnit: '1s', preAllocatedVUs: 500, maxVUs: 5000,
    stages: [{ duration: '2m', target: 500 }, { duration: '2m', target: 1000 }, { duration: '2m', target: 2000 }, { duration: '2m', target: 3000 }, { duration: '2m', target: 4000 }, { duration: '1m', target: 0 }] },
  spike: { executor: 'ramping-vus', startVUs: 50, stages: [{ duration: '1m', target: 50 }, { duration: '10s', target: 2000 }, { duration: '3m', target: 2000 }, { duration: '10s', target: 50 }, { duration: '2m', target: 50 }] },
  soak: { executor: 'constant-vus', vus: 400, duration: '2h' },
};
const P = __ENV.PROFILE || 'smoke';
export const options = {
  scenarios: { [P]: PROFILES[P] },
  thresholds: {
    app_errors: [{ threshold: 'rate<0.01', abortOnFail: true, delayAbortEval: '30s' }],   // stop if >1 % fail
    http_req_duration: ['p(95)<800', 'p(99)<2000'],
    feed_ms: ['p(95)<500'], klines_ms: ['p(95)<800'],
  },
  noConnectionReuse: false, userAgent: 'AlphaTrade-LoadTest/1.0 (k6)', discardResponseBodies: true,
};
const tally = (r) => { errors.add(r.status === 0 || r.status >= 500); limited.add(r.status === 429); return r; };
const hdr = TOKEN ? { Authorization: `Bearer ${TOKEN}` } : {};
const SYMS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT'];

export default function () {
  group('arrive', () => {
    const r = tally(http.get(`${BASE}/`, { tags: { name: 'page' } }));
    check(r, { 'page 200': (x) => x.status === 200 });
    tally(http.get(`${BASE}/api/ai/health`, { tags: { name: 'ai_health' } }));
  });
  for (let i = 0; i < 3; i++) {   // the app open for a while: prices, channel, notices
    const s = SYMS[Math.floor(Math.random() * SYMS.length)];
    const k = tally(http.get(`${BASE}/binance/api/v3/klines?symbol=${s}&interval=5m&limit=500`, { tags: { name: 'klines' } })); klinesT.add(k.timings.duration);
    if (TOKEN) {
      const f = tally(http.get(`${BASE}/api/channel/feed`, { headers: hdr, tags: { name: 'feed' } })); feedT.add(f.timings.duration);
      tally(http.get(`${BASE}/api/me/notices`, { headers: hdr, tags: { name: 'notices' } }));
    }
    sleep(1 + Math.random() * 2);
  }
}
