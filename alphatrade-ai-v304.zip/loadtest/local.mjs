// Local load-test harness: boots the real production server (node server/index.js --serve-dist) with test sign-in keys,
// seeded channel data and a mock market upstream (realistic 120 ms latency), then runs one scenario against it.
//   node loadtest/local.mjs <scenario> [--json out.json]        scenarios: see SCENARIOS below
// Simulated clients come from distinct IPs (X-Forwarded-For with TRUST_PROXY=1), like real visitors behind a proxy.
// Nothing here touches the live site. For the live/staging site use loadtest/k6-live.js (see loadtest/README.md).
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { run } from './engine.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const arg = (k, d) => { const i = process.argv.indexOf(k); return i > 0 ? process.argv[i + 1] : d; };
const SCEN = process.argv[2] || 'smoke';
const STATIC = arg('--static', process.env.STATIC_DIR || path.join(ROOT, 'dist'));
const PORT = 21000 + Math.floor(Math.random() * 9000); const UP = PORT + 1;
const BASE = `http://127.0.0.1:${PORT}`;

/* ── sign-in tokens (RS256, verified by the server exactly like Firebase ID tokens) ── */
const PROJECT = 'alphatrade-load'; const KID = 'k-load';
const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const b64u = (b) => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
const mkTok = (uid) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
  const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email: `${uid}@load.test`, email_verified: true, firebase: { sign_in_provider: 'password' } }));
  return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
const USERS = Number(arg('--users', 5000));
const tokens = Array.from({ length: USERS }, (_, i) => mkTok(`load${i}`));
// --rotate: every request from a new client IP (measures raw capacity instead of the per-IP limiter)
const ROTATE = process.argv.includes('--rotate');
const ip = (vu) => { const n = ROTATE ? Math.floor(Math.random() * 16_000_000) : vu; return `10.${(n >> 16) & 255}.${(n >> 8) & 255}.${n & 255}`; };

/* ── data + mock upstream ── */
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'atl-')); const wdir = path.join(dir, 'worker'); fs.mkdirSync(wdir);
fs.writeFileSync(path.join(dir, 'certs.json'), JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
const sig = (i) => ({ id: `s${i}`, symbol: ['BTCUSDT', 'ETHUSDT', 'XAUUSD', 'EURUSD', 'SOLUSDT'][i % 5], tf: '5m', direction: i % 2 ? 'long' : 'short', strategy: ['trend', 'smc', 'mean_reversion', 'edh'][i % 4],
  entry: 100 + i, stop: 98 + i, targets: [102 + i, 104 + i, 106 + i], confidence: 70, status: 'active', createdAt: Date.now() - i * 60_000, reasons: ['EMA 20/50 aligned', 'RSI 55', 'London session'], ctx: { session: 'london', adx: 24, rsi: 55 } });
fs.writeFileSync(path.join(wdir, 'state.json'), JSON.stringify({ 'ata:signals': JSON.stringify(Array.from({ length: 150 }, (_, i) => sig(i))) }));
// --subs N: N of the simulated users are paying channel subscribers, each with 20 granted recommendations (a grown site)
const SUBS = Number(arg('--subs', 0));
if (SUBS) {
  const db = {}; const now = Date.now();
  for (let u = 0; u < SUBS; u++) { const grants = {}; for (let i = 0; i < 20; i++) grants[`s${i}`] = { at: now - i * 60_000, refunded: false, snapshot: sig(i) };
    db[`load${u}`] = { subscription: { product: 'monthly', startsAt: now - 86_400_000, until: now + 20 * 86_400_000 }, grants, addons: [], purchases: [`pi_${u}`] }; }
  fs.writeFileSync(path.join(dir, 'channel-accounts.json'), JSON.stringify(db));
}
let upstreamHits = 0;
const klines = JSON.stringify(Array.from({ length: 500 }, (_, i) => [1_700_000_000_000 + i * 60_000, '100.1', '101.2', '99.8', '100.6', '12.5', 0, '0', 10, '1', '1', '0']));
const up = http.createServer((req, res) => { upstreamHits++; setTimeout(() => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(req.url.includes('ff_cal') ? '[]' : klines); }, 120); });
await new Promise((r) => up.listen(UP, '127.0.0.1', r));

/* ── the server under test ── */
const env = { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(PORT), STATIC_DIR: STATIC, SERVER_DATA_DIR: dir, WORKER_DATA_DIR: wdir, TRUST_PROXY: '1',
  AI_KEY_SECRET: crypto.randomBytes(24).toString('hex'), FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: path.join(dir, 'certs.json'), MARKET_PROXY_TEST_BASE: `http://127.0.0.1:${UP}`,
  FF_CAL_URL: `http://127.0.0.1:${UP}/ff_cal`, STORE_WRITE_DELAY_MS: process.env.STORE_WRITE_DELAY_MS || '250', BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', ADMIN_EMAILS: '' };
const child = spawn(process.execPath, ['--no-warnings', ...(process.env.SERVER_NODE_ARGS ? process.env.SERVER_NODE_ARGS.split(' ') : []), 'server/index.js', '--serve-dist'], { cwd: ROOT, env, stdio: ['ignore', 'ignore', 'pipe'] });
let stderr = ''; child.stderr.on('data', (d) => { stderr = (stderr + d).slice(-4000); });
for (let i = 0; i < 100; i++) { try { await fetch(`${BASE}/api/health`); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }

/* ── server resources (CPU %, RSS) + responsiveness probe (/api/health 5×/s from a separate connection) ── */
const TICK = os.constants?.signals ? 100 : 100; let lastCpu = null; const res = [];
const cpuRss = () => { try { const f = fs.readFileSync(`/proc/${child.pid}/stat`, 'utf8').split(') ')[1].split(' '); return { cpu: (+f[11] + +f[12]) / TICK, rss: +f[21] * 4096 / 1048576 }; } catch { return null; } };
const probe = []; let probeOn = true;
(async () => { while (probeOn) { const t = performance.now(); try { const r = await fetch(`${BASE}/api/health`, { signal: AbortSignal.timeout(10000) }); await r.arrayBuffer(); probe.push(performance.now() - t); } catch { probe.push(10000); } await new Promise((r) => setTimeout(r, 200)); } })();

/* ── first visit: assets from the built index.html ── */
const html = fs.existsSync(path.join(STATIC, 'index.html')) ? fs.readFileSync(path.join(STATIC, 'index.html'), 'utf8') : '';
const assets = [...html.matchAll(/(?:src|href)="(\/assets\/[^"]+\.(?:js|css))"/g)].map((m) => m[1]);
if (!assets.length) for (const f of fs.readdirSync(STATIC)) if (/\.(js|css)$/.test(f)) assets.push(`/${f}`);
const O = { origin: BASE };
const auth = (vu) => ({ authorization: `Bearer ${tokens[vu % USERS]}`, 'x-forwarded-for': ip(vu) });
const R = {
  page: { name: 'GET / (index.html)', build: (vu) => ({ path: '/', headers: { 'accept-encoding': 'br, gzip', 'x-forwarded-for': ip(vu) } }) },
  asset: { name: 'GET app bundle (br)', build: (vu) => ({ path: assets[vu % assets.length] || '/', headers: { 'accept-encoding': 'br, gzip', 'x-forwarded-for': ip(vu) } }) },
  asset304: { name: 'GET bundle revalidate (304)', build: (vu) => ({ path: '/', headers: { 'if-none-match': etag, 'x-forwarded-for': ip(vu) } }) },
  health: { name: 'GET /api/health', build: (vu) => ({ path: '/api/health', headers: { 'x-forwarded-for': ip(vu) } }) },
  aiHealth: { name: 'GET /api/ai/health', build: (vu) => ({ path: '/api/ai/health', headers: { 'x-forwarded-for': ip(vu) } }) },
  notices: { name: 'GET /api/me/notices', build: (vu) => ({ path: '/api/me/notices', headers: auth(vu) }) },
  feed: { name: 'GET /api/channel/feed', build: (vu) => ({ path: '/api/channel/feed', headers: auth(vu) }) },
  syncGet: { name: 'GET /api/me/sync', build: (vu) => ({ path: '/api/me/sync', headers: auth(vu) }) },
  syncPut: { name: 'PUT /api/me/sync', build: (vu) => ({ method: 'PUT', path: '/api/me/sync', headers: { ...auth(vu), ...O }, body: { data: { theme: 'dark', lang: 'ar', settings: { risk: 1, tf: '5m', markets: ['BTCUSDT', 'XAUUSD'] } }, ts: Date.now() } }) },
  signin: { name: 'POST /api/me/signin', build: (vu) => ({ method: 'POST', path: '/api/me/signin', headers: { ...auth(vu), ...O }, body: { device: 'iPhone · Safari', lang: 'ar' } }) },
  klines: { name: 'GET /binance klines (proxy)', build: (vu) => ({ path: `/binance/api/v3/klines?symbol=${['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT'][vu % 5]}&interval=${vu % 2 ? '1m' : '5m'}&limit=500`, headers: { 'x-forwarded-for': ip(vu) } }) },
  phone: { name: 'PUT /api/me/phone', build: (vu) => ({ method: 'PUT', path: '/api/me/phone', headers: { ...auth(vu), ...O }, body: { phone: `+96279${String(1000000 + (vu % 8999999)).slice(-7)}`, country: 'JO' } }) },
};
const etag = (await fetch(`${BASE}/`)).headers.get('etag') || '';
const W = (key, weight) => ({ ...R[key], weight });
// A real session: page + bundle on arrival, then the app polls the channel feed, notices, prices (proxy) and syncs settings.
const REALISTIC = [W('page', 4), W('asset', 4), W('asset304', 6), W('health', 1), W('aiHealth', 3), W('notices', 18), W('feed', 22), W('syncGet', 3), W('syncPut', 4), W('signin', 3), W('klines', 30), W('phone', 2)];
const one = (k) => [W(k, 1)];

const SCENARIOS = {
  smoke: { model: 'closed', mix: REALISTIC, stages: [{ seconds: 15, vus: 10 }], thinkMs: 200 },
  load: { model: 'closed', mix: REALISTIC, thinkMs: 1000, stages: [{ seconds: 20, vus: 200 }, { seconds: 30, vus: 500 }, { seconds: 30, vus: 1000 }, { seconds: 20, vus: 1000 }] },
  stress: { model: 'open', mix: REALISTIC, maxInflight: 3000, stages: [250, 500, 1000, 1500, 2000, 3000, 4000].map((rate) => ({ seconds: 15, rate })) },
  spike: { model: 'closed', mix: REALISTIC, thinkMs: 500, stages: [{ seconds: 15, vus: 50 }, { seconds: 1, vus: 2000 }, { seconds: 30, vus: 2000 }, { seconds: 1, vus: 50 }, { seconds: 20, vus: 50 }] },
  soak: { model: 'closed', mix: REALISTIC, thinkMs: 1000, stages: [{ seconds: 10, vus: 400 }, { seconds: Number(arg('--soak', 240)), vus: 400 }] },
  // v235: the user ladder asked for in the security brief (1 → 1000 concurrent users, each stage held 20 s), then a recovery stage.
  ladder: { model: 'closed', mix: REALISTIC, thinkMs: 1000, stages: [1, 10, 50, 100, 250, 500, 1000].map((vus) => ({ seconds: 20, vus })).concat([{ seconds: 20, vus: 10 }]) },
  writes: { model: 'closed', mix: [W('signin', 1), W('syncPut', 1), W('phone', 1)], stages: [{ seconds: 20, vus: 50 }, { seconds: 20, vus: 200 }] },
  ...Object.fromEntries(Object.keys(R).map((k) => [`only:${k}`, { model: 'closed', mix: one(k), stages: [{ seconds: 12, vus: Number(arg('--vus', 100)) }] }])),
};
const sc = SCENARIOS[SCEN]; if (!sc) { console.error('unknown scenario; one of:', Object.keys(SCENARIOS).join(', ')); process.exit(2); }

const t0 = Date.now(); lastCpu = cpuRss();
const cpuTimer = setInterval(() => { const c = cpuRss(); if (c && lastCpu) res.push({ cpu: +((c.cpu - lastCpu.cpu) * 100).toFixed(0), rss: +c.rss.toFixed(0) }); lastCpu = c; }, 1000);
const out = await run({ base: BASE, ...sc, onSecond: (r) => { if (!process.argv.includes('--quiet')) process.stdout.write(`\r t=${r.t}s rps=${r.rps} p95=${r.p95}ms err=${r.errors} inflight=${r.inflight}     `); } });
clearInterval(cpuTimer); probeOn = false;
const ps = [...probe].sort((a, b) => a - b);
const report = { scenario: SCEN, at: new Date().toISOString(), node: process.version, cpus: os.cpus().length, seconds: Math.round((Date.now() - t0) / 1000), users: USERS, upstreamHits,
  server: { alive: child.exitCode === null, cpuMaxPct: Math.max(0, ...res.map((r) => r.cpu)), cpuAvgPct: +(res.reduce((a, r) => a + r.cpu, 0) / (res.length || 1)).toFixed(0), rssStartMb: res[0]?.rss, rssEndMb: res[res.length - 1]?.rss, rssMaxMb: Math.max(0, ...res.map((r) => r.rss)) },
  probe: { n: ps.length, p50: +(ps[Math.floor(ps.length * 0.5)] || 0).toFixed(1), p99: +(ps[Math.floor(ps.length * 0.99)] || 0).toFixed(1), max: +(ps[ps.length - 1] || 0).toFixed(1) },
  stages: out.stages, timeline: out.timeline, resources: res };
process.stdout.write('\n');
for (const s of report.stages) console.log(`target ${String(s.target).padStart(5)}  rps ${String(s.rps).padStart(7)}  ok ${String(s.okRate).padStart(6)}%  p50 ${s.p50}  p95 ${s.p95}  p99 ${s.p99}  max ${s.max}  ${JSON.stringify(s.statuses)} ${JSON.stringify(s.errors)}`);
console.log('server', JSON.stringify(report.server), 'probe', JSON.stringify(report.probe), 'upstreamHits', upstreamHits);
if (process.argv.includes('--endpoints')) for (const [k, v] of Object.entries(report.stages.at(-1).byName)) console.log(`  ${k.padEnd(30)} rps ${String(v.rps).padStart(7)} p50 ${v.p50} p95 ${v.p95} p99 ${v.p99} ${JSON.stringify(v.statuses)} ${JSON.stringify(v.errors)}`);
const jf = arg('--json'); if (jf) { fs.mkdirSync(path.dirname(jf), { recursive: true }); fs.writeFileSync(jf, JSON.stringify(report, null, 1)); }
if (stderr.trim() && process.argv.includes('--stderr')) console.log('server stderr:', stderr.slice(-1500));
child.kill(); up.close(); fs.rmSync(dir, { recursive: true, force: true });
process.exit(0);
