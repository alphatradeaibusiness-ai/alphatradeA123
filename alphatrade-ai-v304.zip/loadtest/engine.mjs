// Zero-dependency HTTP load generator (Node 20+). Two models:
//   • closed  — N virtual users, each sends a request, waits for the answer, thinks, repeats (how real browsers behave)
//   • open    — a fixed arrival rate (requests/second) whatever the server does (how a traffic spike behaves; finds the breaking point)
// Stages ramp linearly between targets. Every request records latency, status and error; results come per stage and per second.
import http from 'node:http';
import https from 'node:https';

const pct = (sorted, p) => (sorted.length ? sorted[Math.min(sorted.length - 1, Math.floor((p / 100) * sorted.length))] : 0);
export function summarise(lat, statuses, errors, seconds) {
  const s = Float64Array.from(lat).sort();
  const n = s.length; const total = n + Object.values(errors).reduce((a, b) => a + b, 0);
  const ok = Object.entries(statuses).filter(([k]) => +k < 400).reduce((a, [, v]) => a + v, 0);
  return {
    requests: total, rps: +(total / seconds).toFixed(1), okRate: total ? +(ok / total * 100).toFixed(2) : 0,
    p50: +pct(s, 50).toFixed(1), p90: +pct(s, 90).toFixed(1), p95: +pct(s, 95).toFixed(1), p99: +pct(s, 99).toFixed(1), max: +(s[n - 1] || 0).toFixed(1),
    statuses, errors,
  };
}

/**
 * run({ base, mix, model, stages, timeoutMs, maxInflight, onSecond })
 *  mix: [{ name, weight, build(vu) → { method, path, headers?, body? } }]
 *  stages: closed → [{ seconds, vus }], open → [{ seconds, rate }] (each stage ramps from the previous target)
 */
export async function run({ base, mix, model = 'closed', stages, timeoutMs = 10_000, maxInflight = 4000, thinkMs = 0, onSecond }) {
  const u = new URL(base); const lib = u.protocol === 'https:' ? https : http;
  const agent = new lib.Agent({ keepAlive: true, maxSockets: Infinity, maxFreeSockets: 4096, keepAliveMsecs: 1000 });
  const totalW = mix.reduce((a, m) => a + m.weight, 0);
  const pick = () => { let r = Math.random() * totalW; for (const m of mix) { r -= m.weight; if (r <= 0) return m; } return mix[mix.length - 1]; };
  const per = new Map(mix.map((m) => [m.name, { lat: [], statuses: {}, errors: {} }]));
  const stageOut = []; const timeline = [];
  let inflight = 0; let sec = { n: 0, err: 0, lat: [] };

  const fire = (vu) => new Promise((resolve) => {
    const m = pick(); const r = m.build(vu); const rec = per.get(m.name);
    const body = r.body == null ? null : typeof r.body === 'string' ? r.body : JSON.stringify(r.body);
    const headers = { ...(r.headers || {}), ...(body ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(body) } : {}) };
    const t0 = performance.now(); inflight++;
    const done = (status, err) => {
      inflight--; const ms = performance.now() - t0;
      if (err) { rec.errors[err] = (rec.errors[err] || 0) + 1; sec.err++; } else { rec.lat.push(ms); rec.statuses[status] = (rec.statuses[status] || 0) + 1; sec.lat.push(ms); if (status >= 500) sec.err++; }
      sec.n++; resolve();
    };
    const q = lib.request({ host: u.hostname, port: u.port, path: r.path, method: r.method || 'GET', headers, agent, timeout: timeoutMs }, (res) => {
      res.on('data', () => {}); res.on('end', () => done(res.statusCode)); res.on('error', () => done(0, 'body_error'));
    });
    q.on('timeout', () => { q.destroy(new Error('timeout')); });
    q.on('error', (e) => done(0, e.message === 'timeout' ? 'timeout' : e.code || 'error'));
    if (body) q.write(body); q.end();
  });

  const tick = setInterval(() => {
    const s = Float64Array.from(sec.lat).sort();
    const row = { t: timeline.length + 1, rps: sec.n, errors: sec.err, p95: +pct(s, 95).toFixed(1), inflight };
    timeline.push(row); onSecond?.(row); sec = { n: 0, err: 0, lat: [] };
  }, 1000);

  let prev = 0;
  for (const st of stages) {
    const from = prev; const to = model === 'closed' ? st.vus : st.rate; prev = to;
    const snap = new Map([...per].map(([k, v]) => [k, { lat: v.lat.length, statuses: { ...v.statuses }, errors: { ...v.errors } }]));
    const t0 = Date.now(); const end = t0 + st.seconds * 1000;
    const target = () => from + (to - from) * Math.min(1, (Date.now() - t0) / (st.seconds * 1000));
    if (model === 'closed') {
      let active = 0; const loops = [];
      const startVu = (id) => { active++; loops.push((async () => {
        while (Date.now() < end && id < Math.round(target())) { await fire(id); if (thinkMs) await new Promise((r) => setTimeout(r, thinkMs * (0.5 + Math.random()))); }
        active--;
      })()); };
      while (Date.now() < end) {
        while (active < Math.round(target())) startVu(active);
        await new Promise((r) => setTimeout(r, 100));
      }
      await Promise.all(loops);
    } else {
      let carry = 0; let last = performance.now(); let dropped = 0;
      await new Promise((resolve) => {
        const iv = setInterval(() => {
          const now = performance.now(); carry += target() * (now - last) / 1000; last = now;
          while (carry >= 1) { carry--; if (inflight >= maxInflight) { dropped++; continue; } fire(Math.floor(Math.random() * 1e6)); }
          if (Date.now() >= end) { clearInterval(iv); resolve(); }
        }, 5);
      });
      if (dropped) { const r = per.get(mix[0].name); r.errors.client_backlog = (r.errors.client_backlog || 0) + dropped; }
      const deadline = Date.now() + timeoutMs; while (inflight > 0 && Date.now() < deadline) await new Promise((r) => setTimeout(r, 50));
    }
    // stage result = the difference from the snapshot
    const all = { lat: [], statuses: {}, errors: {} }; const byName = {};
    for (const [k, v] of per) {
      const s0 = snap.get(k); const lat = v.lat.slice(s0.lat);
      const statuses = Object.fromEntries(Object.entries(v.statuses).map(([c, n]) => [c, n - (s0.statuses[c] || 0)]).filter(([, n]) => n));
      const errors = Object.fromEntries(Object.entries(v.errors).map(([c, n]) => [c, n - (s0.errors[c] || 0)]).filter(([, n]) => n));
      byName[k] = summarise(lat, statuses, errors, st.seconds);
      for (const x of lat) all.lat.push(x); for (const [c, n] of Object.entries(statuses)) all.statuses[c] = (all.statuses[c] || 0) + n; for (const [c, n] of Object.entries(errors)) all.errors[c] = (all.errors[c] || 0) + n;
    }
    stageOut.push({ target: to, seconds: st.seconds, ...summarise(all.lat, all.statuses, all.errors, st.seconds), byName });
  }
  clearInterval(tick); agent.destroy();
  return { stages: stageOut, timeline };
}
