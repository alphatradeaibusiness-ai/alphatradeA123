# Backtest report — 2026-10-08
Engine: the app's own (services/backtest.js). Crypto fee 0.1% round trip; non-crypto cost proxy 0.03%; additional slippage 0.02% for all. GOLD_FUTURES is futures, not spot XAUUSD; NDX/SPX are indices, not broker CFDs. Points are the app's unit (1 point = pointSize: BTC $1, ETH $0.1, SOL $0.01). Monthly cap = 1000 points, enforced as "no new trade if this month's realised loss + the trade's full stop + fee could pass the cap". First 60% of each history = in-sample, last 40% = out-of-sample.

## Per asset (all timeframes, classic and SMC combined, cap ON)
| Asset | Trades | Win % | Net points | Avg R / trade | Worst month | Months over cap |
|---|---:|---:|---:|---:|---:|---:|
| BTCUSDT | 24 | 58.33 | 1,133 | 0.05 | -997 | 0 |
| ETHUSDT | 46 | 47.83 | -4,244 | -0.16 | -998 | 0 |
| EURUSD | 30 | 40.00 | -3,329 | -0.41 | -974 | 0 |
| GOLD_FUTURES | no data | | | | | |
| NDX | 9 | 22.22 | -1,919 | -0.57 | -975 | 0 |
| SPX500 | 15 | 46.67 | -381 | -0.28 | -432 | 0 |

## Detail (cap OFF → cap ON)
| Asset | TF | Strategy | Period | Trades (no cap → cap) | Win % (cap) | Net pts (no cap) | Net pts (cap) | Avg R | PF | Max DD | Worst month (no cap → cap) | Verdict |
|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|---|
| BTCUSDT | 1h | classic | 2026-01-31 → 2026-10-08 | 134 → 24 | 58.33 | -31,281 | 1,133 | 0.05 | 1.13 | 4,454 | -8,994 → -997 | too few trades |
| BTCUSDT | 1h | smc | 2026-01-31 → 2026-10-08 | 1 → 0 | – | 2,211 | – | – | – | – | 0 → – | too few trades |
| ETHUSDT | 1h | classic | 2026-01-31 → 2026-10-08 | 120 → 46 | 47.83 | -10,200 | -4,244 | -0.16 | 0.65 | 6,326 | -3,830 → -998 | negative |
| EURUSD | 1h | classic | 2026-04-08 → 2026-10-08 | 67 → 30 | 40.00 | -5,280 | -3,329 | -0.41 | 0.46 | 4,264 | -3,610 → -974 | negative |
| GOLD_FUTURES | 1h | classic | 2026-04-08 → 2026-10-08 | 60 → 0 | – | 5,428 | – | – | – | – | -13,804 → – | too few trades |
| NDX | 1h | classic | 2026-04-08 → 2026-10-07 | 17 → 9 | 22.22 | -1,648 | -1,919 | -0.57 | 0.33 | 2,353 | -1,315 → -975 | too few trades |
| SPX500 | 1h | classic | 2026-04-08 → 2026-10-07 | 15 → 15 | 46.67 | -381 | -381 | -0.28 | 0.50 | 516 | -432 → -432 | too few trades |

## Parameter grid — classic strategy, all assets and timeframes pooled (chronological split; exploratory comparison)
| Setting | In-sample trades | In-sample avg R | Out-of-sample trades | Out-of-sample avg R |
|---|---:|---:|---:|---:|
| default (ATR×3, targets 1/2/3.5R) | 249 | -0.20 | 159 | -0.10 |
| stop ATR×2 | 343 | -0.18 | 236 | -0.11 |
| targets 1.5/3/5R | 194 | -0.20 | 122 | -0.15 |
| min stop 10× fee | 201 | -0.17 | 119 | -0.11 |

No setting was positive in both halves with ≥100 out-of-sample trades: do not adopt any of them as an "optimised" setting.

## How to read this
- A monthly cap bounds the realised loss only if fills happen at the stop; gaps and slippage can exceed it.
- If "Trades" collapses when the cap is on, the cap is smaller than one normal stop on that asset/timeframe: raise the cap or use a smaller timeframe-stop, do not widen the cap silently.
- "negative" verdicts mean the strategy loses money net of fees on that data; the cap only limits how much.