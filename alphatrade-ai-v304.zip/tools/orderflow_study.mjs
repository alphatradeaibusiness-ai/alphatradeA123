#!/usr/bin/env node
// Order-flow study for AlphaRadar: does CVD / funding / open interest predict the next move on real data?
//
//   node tools/orderflow_study.mjs --selftest                        # checks the statistics on synthetic data (no network)
//   node tools/orderflow_study.mjs --symbol BTCUSDT --tf 1h --from 2020-01-01 --h 12 --fee 0.04
//   node tools/orderflow_study.mjs --symbol BTCUSDT --tf 1h --offline # reuse ./data/of_*.json
//   node tools/orderflow_study.mjs --file candles.json --proxy --tf 1h # any candles with volume; delta approximated from the candle (no network)
//
// Method (fixed BEFORE looking at results): 6 hypotheses with no fitted parameters, evaluated on non-overlapping signals
// (after a signal the next H candles are skipped, so no outcome is counted twice), chronological folds, Wilson 95% interval,
// Bonferroni correction for the 6 tests, and fees charged on every trade. A hypothesis only PASSES when the lower end of the
// interval is above 50% on the whole sample AND on the last 40%, the net mean return after fees is positive, and at least
// 3 of 4 folds are above 50%. Reaching "70%" would mean the lower end of the interval above 70%: the report prints that too.
// Data (public Binance endpoints; run it where the network is open):
//   spot klines (index 9 = taker buy base volume -> CVD, history since 2017), futures funding rate (since 2019),
//   futures open interest history (Binance keeps only the last ~30 days: for longer history use a vendor or run --collect-oi daily).
import fs from 'node:fs';
import path from 'node:path';

const arg = (k, d) => { const i = process.argv.indexOf(`--${k}`); return i > -1 ? (process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true) : d; };
const SYMBOL = String(arg('symbol', 'BTCUSDT')); const TF = String(arg('tf', '1h')); const H = Number(arg('h', 12));
const FEE = Number(arg('fee', 0.04)); const FROM = Date.parse(`${arg('from', '2020-01-01')}T00:00:00Z`);
const DATA = path.resolve(String(arg('data', './data'))); const OFFLINE = arg('offline', false) === true;
const TF_SEC = { '5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400 }[TF];
const SPOT = 'https://data-api.binance.vision'; const FUT = 'https://fapi.binance.com';

/* ───────── statistics ───────── */
export function wilson(k, n, z = 1.96) { if (!n) return [0, 1]; const p = k / n; const d = 1 + z * z / n; const c = p + z * z / (2 * n); const m = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)); return [(c - m) / d, (c + m) / d]; }
export function evaluate(signals, candles, h, feePct) { // signals: [{i, dir}] -> non-overlapping trades
  const out = []; let next = 0;
  for (const s of signals) {
    if (s.i < next || s.i + h >= candles.length) continue;
    const ret = (candles[s.i + h].close / candles[s.i].close - 1) * s.dir * 100 - feePct;
    out.push({ i: s.i, t: candles[s.i].time, win: ret + feePct > 0, ret });
    next = s.i + h + 1;
  }
  return out;
}
export function verdict(trades) {
  const n = trades.length; const k = trades.filter((x) => x.win).length;
  const cut = Math.floor(n * 0.6); const test = trades.slice(cut);
  const folds = [0, 1, 2, 3].map((f) => trades.slice(Math.floor(n * f / 4), Math.floor(n * (f + 1) / 4)));
  const foldOk = folds.filter((f) => f.length >= 5 && f.filter((x) => x.win).length / f.length > 0.5).length;
  const all = wilson(k, n); const te = wilson(test.filter((x) => x.win).length, test.length);
  const mean = trades.reduce((s, x) => s + x.ret, 0) / (n || 1);
  const pass = n >= 100 && all[0] > 0.5 && te[0] > 0.5 && mean > 0 && foldOk >= 3;
  return { n, hit: n ? k / n : 0, lo: all[0], hi: all[1], testN: test.length, testHit: test.length ? test.filter((x) => x.win).length / test.length : 0, testLo: te[0], meanNet: mean, foldOk, pass, reaches70: all[0] > 0.7 };
}

/* ───────── features and the 6 pre-registered hypotheses ───────── */
const sum = (a, f, i, n) => { let s = 0; for (let j = i - n + 1; j <= i; j++) s += f(a[j]); return s; };
export function hypotheses(c, ctx = {}) { // c: candles with volume, buyVolume (taker buy base); ctx.funding(time) -> rate or null; ctx.oi(time) -> OI or null
  const N = 24; const sigs = { H1_cvdTrend: [], H2_cvdDivergence: [], H3_fundingContrarian: [], H4_absorption: [], H5_oiPrice: [], H6_lastBarFlow: [] };
  const delta = c.map((x) => (Number.isFinite(x.buyVolume) ? 2 * x.buyVolume - x.volume : null));
  const d0 = delta.map((d) => d ?? 0);
  for (let i = 100; i < c.length - 1; i++) {
    if (delta[i] == null) continue;
    const vol = sum(c, (x) => x.volume, i, N) || 1; const cvd = sum(d0, (d) => d, i, N) / vol; // −1 … +1 share of net taker flow
    const chg = c[i].close / c[i - N].close - 1;
    const hi = Math.max(...c.slice(i - N, i + 1).map((x) => x.high)); const lo = Math.min(...c.slice(i - N, i + 1).map((x) => x.low));
    if (Math.abs(cvd) > 0.05) sigs.H1_cvdTrend.push({ i, dir: Math.sign(cvd) });
    if (c[i].close >= hi * 0.998 && cvd < -0.03) sigs.H2_cvdDivergence.push({ i, dir: -1 });
    if (c[i].close <= lo * 1.002 && cvd > 0.03) sigs.H2_cvdDivergence.push({ i, dir: 1 });
    const f = ctx.funding?.(c[i].time);
    if (f != null && f.z > 2) sigs.H3_fundingContrarian.push({ i, dir: -1 }); else if (f != null && f.z < -2) sigs.H3_fundingContrarian.push({ i, dir: 1 });
    const avgVol = sum(c, (x) => x.volume, i - 1, 20) / 20; const rng = (c[i].high - c[i].low) / c[i].close; const avgRng = sum(c, (x) => (x.high - x.low) / x.close, i - 1, 20) / 20;
    if (c[i].volume > 1.8 * avgVol && rng < 0.7 * avgRng && Math.abs(delta[i]) / (c[i].volume || 1) > 0.15) sigs.H4_absorption.push({ i, dir: -Math.sign(delta[i]) }); // heavy one-sided flow that cannot move price = absorbed
    const o1 = ctx.oi?.(c[i].time); const o0 = ctx.oi?.(c[i - N].time);
    if (o1 != null && o0 != null && o0 > 0) { const dOi = o1 / o0 - 1; if (dOi > 0.02 && Math.abs(chg) > 0.01) sigs.H5_oiPrice.push({ i, dir: Math.sign(chg) }); }
    if (Math.abs(delta[i]) / (c[i].volume || 1) > 0.25) sigs.H6_lastBarFlow.push({ i, dir: Math.sign(delta[i]) });
  }
  return sigs;
}
export function runAll(c, ctx, h, fee) { return Object.fromEntries(Object.entries(hypotheses(c, ctx)).map(([k, s]) => [k, verdict(evaluate(s, c, h, fee))])); }

/* ───────── data download ───────── */
async function jget(url) { for (let t = 0; t < 4; t++) { try { const r = await fetch(url); if (r.ok) return await r.json(); } catch { /* retry */ } await new Promise((r) => setTimeout(r, 800 * (t + 1))); } throw new Error(`failed: ${url}`); }
async function klines() {
  const file = path.join(DATA, `of_${SYMBOL}_${TF}.json`); fs.mkdirSync(DATA, { recursive: true });
  if (OFFLINE && fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  const out = []; let start = FROM;
  while (start < Date.now() - TF_SEC * 1000) {
    const rows = await jget(`${SPOT}/api/v3/klines?symbol=${SYMBOL}&interval=${TF}&startTime=${start}&limit=1000`);
    if (!rows.length) break;
    for (const k of rows) out.push({ time: k[0] / 1000, open: +k[1], high: +k[2], low: +k[3], close: +k[4], volume: +k[5], buyVolume: +k[9] });
    start = rows.at(-1)[0] + TF_SEC * 1000; process.stdout.write(`\rklines ${out.length}`);
  }
  fs.writeFileSync(file, JSON.stringify(out)); console.log(''); return out;
}
async function fundingSeries() {
  const out = []; let start = FROM;
  try { while (true) { const rows = await jget(`${FUT}/fapi/v1/fundingRate?symbol=${SYMBOL}&startTime=${start}&limit=1000`); if (!rows.length) break; out.push(...rows.map((r) => ({ t: r.fundingTime / 1000, r: +r.fundingRate }))); start = rows.at(-1).fundingTime + 1; if (rows.length < 1000) break; } } catch { return null; }
  const z = []; for (let i = 0; i < out.length; i++) { const w = out.slice(Math.max(0, i - 270), i + 1).map((x) => x.r); const m = w.reduce((s, x) => s + x, 0) / w.length; const sd = Math.sqrt(w.reduce((s, x) => s + (x - m) ** 2, 0) / w.length) || 1e-9; z.push({ t: out[i].t, z: (out[i].r - m) / sd }); }
  return (time) => { let lo = 0, hi = z.length - 1, a = -1; while (lo <= hi) { const mid = (lo + hi) >> 1; if (z[mid].t <= time) { a = mid; lo = mid + 1; } else hi = mid - 1; } return a < 0 ? null : z[a]; };
}
async function oiSeries() {
  try { const rows = await jget(`${FUT}/futures/data/openInterestHist?symbol=${SYMBOL}&period=1h&limit=500`); const s = rows.map((r) => ({ t: r.timestamp / 1000, v: +r.sumOpenInterest })); return (time) => { const x = s.filter((y) => y.t <= time).at(-1); return x && time - x.t < 7200 ? x.v : null; }; } catch { return null; }
}

/* ───────── self-test: planted effect must be found, pure noise must not ───────── */
function synthetic(plant, n = 30000, seed = 7) {
  let s = seed; const rnd = () => { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; };
  const c = []; let p = 100; let flow = 0;
  for (let i = 0; i < n; i++) {
    flow = 0.9 * flow + (rnd() - 0.5) * 0.4; // persistent net taker flow
    const drift = plant ? flow * 0.0012 : 0; const r = drift + (rnd() - 0.5) * 0.01; const o = p; p *= 1 + r;
    const vol = 100 + rnd() * 50; const buy = vol * Math.min(0.95, Math.max(0.05, 0.5 + flow * 0.6 + (rnd() - 0.5) * 0.1));
    c.push({ time: 1.6e9 + i * 3600, open: o, high: Math.max(o, p) * 1.001, low: Math.min(o, p) * 0.999, close: p, volume: vol, buyVolume: buy });
  }
  return c;
}
if (process.argv.includes('--selftest')) {
  const a = runAll(synthetic(true), {}, 6, 0.0); const b = runAll(synthetic(false), {}, 6, 0.0);
  console.log('planted effect  H1:', a.H1_cvdTrend.pass ? 'PASS (found)' : 'missed', `hit ${(a.H1_cvdTrend.hit * 100).toFixed(1)}% n=${a.H1_cvdTrend.n}`);
  console.log('pure noise      H1:', b.H1_cvdTrend.pass ? 'FALSE POSITIVE' : 'rejected', `hit ${(b.H1_cvdTrend.hit * 100).toFixed(1)}% n=${b.H1_cvdTrend.n}`);
  const fp = Object.values(b).filter((x) => x.pass).length; console.log('noise false positives over 6 tests:', fp);
  process.exit(a.H1_cvdTrend.pass && !b.H1_cvdTrend.pass && fp === 0 ? 0 : 1);
} else if (process.argv[1] && process.argv[1].endsWith('orderflow_study.mjs')) {
  const PROXY = process.argv.includes('--proxy'); // approximate delta from candles (volume x close location): works for every asset that has volume
  const FILE = arg('file', null);
  let c = FILE ? JSON.parse(fs.readFileSync(String(FILE), 'utf8')) : await klines();
  if (PROXY) c = c.map((x) => ({ ...x, buyVolume: x.high > x.low ? x.volume * (x.close - x.low) / (x.high - x.low) : x.volume / 2 }));
  const funding = FILE ? null : await fundingSeries(); const oi = FILE ? null : await oiSeries();
  const res = runAll(c, { funding, oi }, H, FEE);
  const lines = [`# Order-flow study — ${SYMBOL} ${TF}, horizon ${H} candles, fee ${FEE}% per trade, ${c.length} candles`, '', '| Hypothesis | n | hit % | 95% interval | last-40% hit % (low end) | net mean % | folds >50% | verdict |', '|---|---|---|---|---|---|---|---|'];
  for (const [k, v] of Object.entries(res)) lines.push(`| ${k} | ${v.n} | ${(v.hit * 100).toFixed(1)} | ${(v.lo * 100).toFixed(1)}–${(v.hi * 100).toFixed(1)} | ${(v.testHit * 100).toFixed(1)} (${(v.testLo * 100).toFixed(1)}) | ${v.meanNet.toFixed(3)} | ${v.foldOk}/4 | ${v.pass ? 'PASS' : 'no edge'}${v.reaches70 ? ' · reaches 70%' : ''} |`);
  if (!funding) lines.push('', 'Funding data unavailable (H3 empty).'); if (!oi) lines.push('Open-interest data unavailable (H5 empty).');
  fs.mkdirSync('results', { recursive: true }); fs.writeFileSync('results/orderflow.md', lines.join('\n')); console.log(lines.join('\n'));
}
