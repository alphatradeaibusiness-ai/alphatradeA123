#!/usr/bin/env bash
# v274 security scan: official release binaries from GitHub, each checked against the release's own checksum file before use.
#   gitleaks (secrets, MIT) · trivy (Dockerfile/config misconfigurations + secrets, Apache-2.0) · osv-scanner (known CVEs in package-lock, Apache-2.0)
# Usage: bash tools/security-scan.sh            (downloads into ~/.cache/alphatrade-sec, scans this project)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; BIN="${HOME}/.cache/alphatrade-sec"; mkdir -p "$BIN"; cd "$BIN"
GL=8.30.1; TV=0.76.2; OSV=2.7.1
fetch() { [ -f "$2" ] || curl -fsSL -o "$2" "$1"; }
verify() { local sum; sum=$(sha256sum "$1" | cut -d' ' -f1); grep -q "$sum" "$2" || { echo "checksum mismatch for $1"; exit 1; }; }
fetch "https://github.com/gitleaks/gitleaks/releases/download/v$GL/gitleaks_${GL}_linux_x64.tar.gz" gl.tgz
fetch "https://github.com/gitleaks/gitleaks/releases/download/v$GL/gitleaks_${GL}_checksums.txt" gl.sum
fetch "https://github.com/aquasecurity/trivy/releases/download/v$TV/trivy_${TV}_Linux-64bit.tar.gz" tv.tgz
fetch "https://github.com/aquasecurity/trivy/releases/download/v$TV/trivy_${TV}_checksums.txt" tv.sum
fetch "https://github.com/google/osv-scanner/releases/download/v$OSV/osv-scanner_linux_amd64" osv-scanner
fetch "https://github.com/google/osv-scanner/releases/download/v$OSV/osv-scanner_SHA256SUMS" osv.sum
verify gl.tgz gl.sum; verify tv.tgz tv.sum; verify osv-scanner osv.sum
tar -xzf gl.tgz gitleaks; tar -xzf tv.tgz trivy; chmod +x gitleaks trivy osv-scanner
cd "$ROOT"
echo "== gitleaks (fake keys inside tests are listed in .gitleaksignore)"; "$BIN/gitleaks" dir . --no-banner --redact
echo "== trivy (Dockerfiles, config, secrets)"; "$BIN/trivy" fs --scanners secret,misconfig --skip-dirs node_modules --exit-code 1 -q .
echo "== osv-scanner (needs api.osv.dev)"
# osv-scanner prints "0 known vulnerabilities" and exits 0 even when it could not reach the database, so check its log.
out=$("$BIN/osv-scanner" scan source -L package-lock.json 2>&1) || true; echo "$out" | tail -3
if echo "$out" | grep -qE "Error during extraction|request failed"; then echo "!! osv-scanner could not reach api.osv.dev — known vulnerabilities were NOT checked"; exit 2; fi
