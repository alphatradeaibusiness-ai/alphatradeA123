#!/usr/bin/env node
// SMC v2 research: how many trades each rule allows and how they hold up OUT OF SAMPLE.
//   node tools/smc_research.mjs --data ./data --symbol BTCUSDT --tfs 15m,5m --fee 0.1 --slip 0.02 --out ./results
// Needs <data>/<SYMBOL>_<tf>.json (candles {time,open,high,low,close,volume,buyVolume}); entry timeframes, plus 4h and 1h for the higher-timeframe context
// (the Daily bars are built from 1h candles). Nothing is downloaded here: use tools/research.mjs to fetch data first.
// Every variant is declared below BEFORE looking at results. Each timeframe is cut in time: the first 60% develops/chooses, the last 40% is never used to choose.
import fs from 'node:fs';
import path from 'node:path';
import { backtestSmc, rulesFrom } from '../src/services/backtest.js';
import { aggregate } from '../src/services/smc2.js';
import { getInstrument } from '../src/config/instruments.js';

const arg = (k, d) => { const i = process.argv.indexOf(`--${k}`); return i > -1 ? process.argv[i + 1] : d; };
const DATA = path.resolve(arg('data', './data'));
const SYMBOL = arg('symbol', 'BTCUSDT');
const TFS = arg('tfs', '15m,5m').split(',');
const FEE = Number(arg('fee', 0.1));      // round-trip fee, % of price
const SLIP = Number(arg('slip', 0.02));   // round-trip slippage allowance, % of price (no spread data exists for crypto candles)
const OUT = path.resolve(arg('out', './results'));
const SPLIT = 0.6;
const load = (tf) => JSON.parse(fs.readFileSync(path.join(DATA, `${SYMBOL}_${tf}.json`), 'utf8'));
const inst = getInstrument(SYMBOL);

// name, smcKillZone, smcHtf, smcMinScore, smcOpts
const VARIANTS = [
  ['A strict (current)', {}],
  ['B 4h bias only', { smcOpts: { htfMode: 'h4' } }],
  ['C no kill zone', { smcKillZone: false }],
  ['D 4h only + no kill zone', { smcKillZone: false, smcOpts: { htfMode: 'h4' } }],
  ['E D + score 70', { smcKillZone: false, smcMinScore: 70, smcOpts: { htfMode: 'h4' } }],
  ['F D + reversal rule', { smcKillZone: false, smcOpts: { htfMode: 'h4', reversal: true } }],
  ['G D + RSI gate', { smcKillZone: false, smcOpts: { htfMode: 'h4', rsiGate: true } }],
  ['H D + displacement ≥1.5', { smcKillZone: false, smcOpts: { htfMode: 'h4', minDisp: 1.5 } }],
  ['I D + FVG ≥0.3 ATR', { smcKillZone: false, smcOpts: { htfMode: 'h4', fvgMin: 0.3 } }],
  ['J D + CHoCH within 25', { smcKillZone: false, smcOpts: { htfMode: 'h4', maxAfterTap: 25 } }],
  ['K no HTF, kill zone on', { smcHtf: false }],
  ['L 4h only + kill zone', { smcOpts: { htfMode: 'h4' } }],
];

const h4 = load('4h');
const d1 = aggregate(load('1h'), 86400).filter((_, i, a) => i < a.length - 1);
const f1 = (x) => (Number.isFinite(x) ? x.toFixed(2) : '∞');
function figures(trades, months) {
  const n = trades.length;
  if (!n) return { n: 0, perMonth: 0 };
  const wins = trades.filter((t) => t.points > 0).length;
  const gw = trades.filter((t) => t.points > 0).reduce((a, t) => a + t.r, 0), gl = -trades.filter((t) => t.points <= 0).reduce((a, t) => a + t.r, 0);
  let eq = 0, pk = 0, dd = 0, streak = 0, worst = 0;
  for (const t of [...trades].sort((a, b) => a.closeTime - b.closeTime)) { eq += t.r; pk = Math.max(pk, eq); dd = Math.max(dd, pk - eq); if (t.points <= 0) { streak++; worst = Math.max(worst, streak); } else streak = 0; }
  const avgW = wins ? gw / wins : 0, avgL = n - wins ? gl / (n - wins) : 0;
  return { n, perMonth: n / months, win: (100 * wins) / n, tp1: (100 * trades.filter((t) => t.hits >= 1).length) / n, exp: trades.reduce((a, t) => a + t.r, 0) / n, pf: gl > 0 ? gw / gl : Infinity, netR: eq, ddR: dd, streak: worst, avgW, avgL };
}
const row = (name, a, b) => `| ${name} | ${a.n} (${f1(a.perMonth)}/mo) | ${a.n ? f1(a.win) + '%' : '—'} | ${a.n ? f1(a.pf) : '—'} | ${a.n ? f1(a.exp) : '—'} | ${a.n ? f1(a.ddR) : '—'} | ${a.n ? a.streak : '—'} | ${b.n} (${f1(b.perMonth)}/mo) | ${b.n ? f1(b.win) + '%' : '—'} | ${b.n ? f1(b.pf) : '—'} | ${b.n ? f1(b.exp) : '—'} | ${b.n ? f1(b.ddR) : '—'} |`;
const date = (t) => new Date(t * 1000).toISOString().slice(0, 10);

const lines = [`# SMC v2 research — ${SYMBOL}`, `Costs: fee ${FEE}% + slippage ${SLIP}% round trip (no spread data for crypto candles). Entry = market at the confirmation candle's close; stops/targets from the engine; a trade is "win" when net points > 0 after costs. R = result in units of the risk taken. Daily context built from 1h candles.`, ''];
for (const tf of TFS) {
  const c = load(tf);
  const cut = c[Math.floor(c.length * SPLIT)].time;
  const monthsDev = (cut - c[0].time) / 2_592_000, monthsOos = (c.at(-1).time - cut) / 2_592_000;
  lines.push(`## Entry timeframe ${tf}`, `Data ${date(c[0].time)} → ${date(c.at(-1).time)} (${c.length} candles). **Development** ${date(c[0].time)} → ${date(cut)} · **Out of sample** ${date(cut)} → ${date(c.at(-1).time)}.`, '',
    '| Variant | Dev trades | Dev win | Dev PF | Dev R/trade | Dev maxDD (R) | Dev loss streak | OOS trades | OOS win | OOS PF | OOS R/trade | OOS maxDD (R) |', '|---|---|---|---|---|---|---|---|---|---|---|---|');
  for (const [name, over] of VARIANTS) {
    const rules = { ...rulesFrom({ plan: { feePct: FEE }, smc2: {}, zone: {}, risk: {} }, inst), forced: null, maxPerDay: 0, openOnLast: false, pointSize: inst.pointSize, volumeKind: 'taker', htfCandles: { h4, d1 }, slipPct: SLIP, ...over };
    const trades = backtestSmc(c, rules).trades;
    lines.push(row(name, figures(trades.filter((t) => t.openTime < cut && t.closeTime < cut), monthsDev), figures(trades.filter((t) => t.openTime >= cut), monthsOos)));
    process.stderr.write(`${tf} ${name}: ${trades.length}\n`);
  }
  lines.push('');
}
fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'smc_research.md'), lines.join('\n'));
console.log(lines.join('\n'));
