// Cached reads of theme CSS variables and the page font (v230). getComputedStyle() on a page whose DOM was just rebuilt makes
// the browser recalculate every style on the spot; the charts did that on every build (after sign-in and on every language
// switch: up to ~180 ms on a phone). The values only change with the theme / palette (colours) or the language (font), so they
// are read once per change and kept.
const root = () => document.documentElement;
let colours = { key: '', cs: null, vals: new Map() };
let font = { key: '', value: '' };

/** Value of a CSS custom property on <html> (theme colours), or `fallback`. */
export function cssVar(name, fallback = '') {
  const d = root(); const key = `${d.dataset.theme}|${d.dataset.palette}`;
  if (colours.key !== key) colours = { key, cs: null, vals: new Map() };
  if (!colours.vals.has(name)) { colours.cs ||= getComputedStyle(d); colours.vals.set(name, colours.cs.getPropertyValue(name).trim()); }
  return colours.vals.get(name) || fallback;
}
// Same stacks as --font in styles/base.css (no style read needed at all).
const FONT = "'Inter', 'IBM Plex Sans Arabic', 'Segoe UI', system-ui, -apple-system, 'Noto Sans Arabic', 'DejaVu Sans', sans-serif";
const FONT_AR = "'IBM Plex Sans Arabic', 'Inter', 'Segoe UI', system-ui, 'Noto Sans Arabic', 'DejaVu Sans', sans-serif";
/** The page's font stack (follows the language). */
export function pageFont() {
  const key = root().lang || '';
  if (font.key !== key || !font.value) font = { key, value: key === 'ar' ? FONT_AR : FONT };
  return font.value;
}
