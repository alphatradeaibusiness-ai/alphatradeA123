// Namespaced, exception-safe localStorage wrapper (private mode can throw).
const PREFIX = 'ata:';

function safe(fn, fallback) {
  try { return fn(); } catch { return fallback; }
}

const setListeners = new Set();
export const storage = {
  get(key, fallback = null, area = 'local') {
    return safe(() => {
      const s = area === 'session' ? sessionStorage : localStorage;
      const raw = s.getItem(PREFIX + key);
      return raw === null ? fallback : JSON.parse(raw);
    }, fallback);
  },
  /** The stored JSON text itself (null when missing), for callers that cache the parsed value. */
  raw(key) {
    return safe(() => localStorage.getItem(PREFIX + key), null);
  },
  set(key, value, area = 'local') {
    safe(() => (area === 'session' ? sessionStorage : localStorage).setItem(PREFIX + key, JSON.stringify(value)));
    if (area === 'local') for (const fn of setListeners) { try { fn(key); } catch { /* a listener must not break saving */ } }
  },
  /** Called after every local save (used by the settings sync between devices). */
  onSet(fn) { setListeners.add(fn); return () => setListeners.delete(fn); },
  remove(key) {
    safe(() => { localStorage.removeItem(PREFIX + key); sessionStorage.removeItem(PREFIX + key); });
  },
};
