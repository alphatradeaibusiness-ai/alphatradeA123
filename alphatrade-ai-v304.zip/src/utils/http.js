// fetch() with a timeout and consistent, user-presentable errors.
export class RequestError extends Error {
  constructor(code, message, status) {
    super(message);
    this.code = code; // 'timeout' | 'http' | 'offline' | 'parse' | 'provider'
    this.status = status;
  }
}

export async function fetchJson(url, { timeoutMs = 9000, ...init } = {}) {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) throw new RequestError('offline', 'offline');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  let res;
  try {
    res = await fetch(url, { ...init, signal: ctrl.signal });
  } catch (e) {
    if (e.name === 'AbortError') throw new RequestError('timeout', 'timeout');
    // Online but the request failed: host unreachable, blocked, or refused by CORS.
    let host = '';
    try { host = new URL(url, location.href).host; } catch { /* ignore */ }
    throw new RequestError('network', host || e.message || 'network error');
  } finally {
    clearTimeout(timer);
  }
  let body;
  try {
    body = await res.json();
  } catch {
    if (!res.ok) throw new RequestError('http', `HTTP ${res.status}`, res.status);
    throw new RequestError('parse', 'invalid JSON');
  }
  if (!res.ok) throw new RequestError('http', body?.error || body?.msg || body?.message || `HTTP ${res.status}`, res.status);
  return body;
}

/** Turn an error into a translated, short message. */
export function describeError(err, t) {
  if (!err) return '';
  if (err.code === 'timeout') return t('errors.timeout');
  if (err.code === 'offline') return t('errors.offline');
  if (err.code === 'network') return t('errors.network', { host: err.message });
  if (err.code === 'parse') return t('errors.parse');
  const m = String(err.message || '');
  if (/available starting with|upgrad/i.test(m)) return t('errors.planRequired');
  if (/symbol.*(missing|invalid)|invalid.*symbol/i.test(m)) return t('errors.symbolInvalid');
  if (/api ?key/i.test(m)) return t('errors.badKey');
  if (/run out of api credits|limit/i.test(m)) return t('errors.rateLimit');
  if (err.code === 'http') return `${t('errors.http', { status: err.status })}${err.message && !/^HTTP/.test(err.message) ? ` — ${err.message}` : ''}`;
  return err.message || String(err);
}
