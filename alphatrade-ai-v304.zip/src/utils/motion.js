// Lightweight motion helpers. Everything here is skipped when the OS "reduce motion" setting is on.

export const reducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

const running = new WeakMap(); // element -> { raf, value }
const easeOut = (k) => 1 - (1 - k) ** 3;

/**
 * Count an element's number from its previous value to `to`.
 * The first call (no previous value) and reduced-motion users get the final value immediately.
 * @param {HTMLElement} el
 * @param {number} to
 * @param {(v:number)=>string} format
 * @param {number} [duration] ms
 */
export function tweenNumber(el, to, format, duration = 480) {
  if (!el) return;
  const state = running.get(el);
  if (state?.raf) cancelAnimationFrame(state.raf);
  const from = state ? state.value : Number(el.dataset.num);
  el.dataset.num = String(to);
  if (!Number.isFinite(to)) { el.textContent = format(to); running.delete(el); return; }
  if (!Number.isFinite(from) || from === to || duration <= 0 || reducedMotion() || document.hidden) {
    el.textContent = format(to);
    running.set(el, { raf: 0, value: to });
    return;
  }
  const t0 = performance.now();
  const s = { raf: 0, value: from };
  running.set(el, s);
  const step = (now) => {
    const k = Math.min(1, (now - t0) / duration);
    s.value = from + (to - from) * easeOut(k);
    el.textContent = format(k === 1 ? to : s.value);
    if (k < 1) s.raf = requestAnimationFrame(step);
    else { s.raf = 0; s.value = to; }
  };
  s.raf = requestAnimationFrame(step);
}

/** Flash an element green/red after a value moves up/down. */
export function flashDirection(el, up) {
  if (!el || reducedMotion()) return;
  restartClass(el, ['tick-up', 'tick-down'], up ? 'tick-up' : 'tick-down');
}

/** Restart a one-shot CSS animation class on an element. */
export function replayClass(el, cls) {
  if (!el || reducedMotion()) return;
  restartClass(el, [cls], cls);
}

/**
 * v230: restarts the animation on the next frames instead of with `void el.offsetWidth`. Reading offsetWidth forced the
 * browser to lay out the whole page synchronously — right after a re-render (≈240 ms on a phone after a language switch)
 * and on every price tick of every card. Two frames: the first paints without the class, the second adds it back.
 */
export function restartClass(el, remove, add) {
  if (!el) return;
  el.classList.remove(...remove);
  if (el._replayRaf) cancelAnimationFrame(el._replayRaf);
  el._replayRaf = requestAnimationFrame(() => { el._replayRaf = requestAnimationFrame(() => { el._replayRaf = 0; el.classList.add(add); }); });
}
