// v285 Challenge dashboard extras: price chart with the trader's own levels, trading statistics, pass certificate.
// The chart is for viewing only (the app's market feed); fills always use the price the server fetches. When the feed for an
// instrument is not real (demo mode), no chart is drawn — never generated candles next to real money rules.
import { esc } from '../utils/dom.js';
import { tx } from '../i18n/tx.js';
import { logoMark } from '../components/icons.js';
import { getHistory } from '../services/market/index.js';

const L = (ar, en) => tx({ ar, en });
const usd = (v, d = 2) => `${v < 0 ? '−' : ''}$${Math.abs(+v).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d })}`;

/** Real candles for a symbol, or { none: true } when the feed is not real / unreachable. */
export async function loadCandles(sym, tf) {
  try { const r = await getHistory(sym, tf, 120); if (r.mode === 'demo' || !r.candles?.length) return { none: true }; return { candles: r.candles.slice(-110), source: r.source || '' }; }
  catch { return { none: true }; }
}

/** Pure: price range that fits the candles and every level line, with a little air. */
export function chartRange(candles, levels = []) {
  let lo = Infinity, hi = -Infinity;
  for (const c of candles) { if (c.low < lo) lo = c.low; if (c.high > hi) hi = c.high; }
  const span = hi - lo || hi * 0.001 || 1;
  for (const l of levels) if (l.price > 0 && l.price > lo - span * 1.5 && l.price < hi + span * 1.5) { if (l.price < lo) lo = l.price; if (l.price > hi) hi = l.price; }   // far-away levels don't flatten the chart
  const pad = (hi - lo) * 0.06 || hi * 0.0005; return { lo: lo - pad, hi: hi + pad };
}

export function drawPriceChart(cv, candles, levels, fmt) {
  const dpr = Math.min(2, window.devicePixelRatio || 1); const W = cv.clientWidth, H = cv.clientHeight; if (!W || !H) return;
  cv.width = W * dpr; cv.height = H * dpr; const g = cv.getContext('2d'); g.scale(dpr, dpr); g.clearRect(0, 0, W, H);
  const css = getComputedStyle(cv); const up = css.getPropertyValue('--up').trim() || '#34d399', down = css.getPropertyValue('--down').trim() || '#f87171', txt = css.getPropertyValue('--text-3').trim() || '#7c8db3';
  const AX = 64, T = 8, B = 18; const { lo, hi } = chartRange(candles, levels); const y = (p) => T + (1 - (p - lo) / (hi - lo)) * (H - T - B);
  const n = candles.length; const cw = (W - AX) / n; const bw = Math.max(1, Math.min(9, cw * 0.62));
  g.font = '10.5px JetBrains Mono, monospace'; g.textBaseline = 'middle';
  for (let i = 0; i <= 4; i++) { const p = lo + ((hi - lo) * i) / 4; const yy = y(p); g.strokeStyle = 'rgba(255,255,255,.05)'; g.lineWidth = 1; g.beginPath(); g.moveTo(0, yy); g.lineTo(W - AX, yy); g.stroke(); g.fillStyle = txt; g.textAlign = 'left'; g.fillText(fmt(p), W - AX + 6, yy); }
  candles.forEach((c, i) => {
    const x = i * cw + cw / 2; const col = c.close >= c.open ? up : down; g.strokeStyle = col; g.fillStyle = col; g.lineWidth = 1;
    g.beginPath(); g.moveTo(x, y(c.high)); g.lineTo(x, y(c.low)); g.stroke();
    const a = y(Math.max(c.open, c.close)), b = y(Math.min(c.open, c.close)); g.fillRect(x - bw / 2, a, bw, Math.max(1, b - a));
  });
  const first = new Date(candles[0].time * 1000), last = new Date(candles[n - 1].time * 1000); const tf = (d) => d.toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  g.fillStyle = txt; g.textAlign = 'left'; g.fillText(tf(first), 2, H - 8); g.textAlign = 'right'; g.fillText(tf(last), W - AX - 2, H - 8);
  for (const l of levels) {
    if (!(l.price > lo && l.price < hi)) continue; const yy = y(l.price);
    g.strokeStyle = l.color; g.lineWidth = 1.2; g.setLineDash(l.dash ? [5, 4] : []); g.beginPath(); g.moveTo(0, yy); g.lineTo(W - AX, yy); g.stroke(); g.setLineDash([]);
    g.fillStyle = l.color; g.fillRect(W - AX, yy - 8, AX, 16); g.fillStyle = '#06101f'; g.textAlign = 'left'; g.fillText(fmt(l.price), W - AX + 6, yy);
    g.font = '600 10.5px Inter, sans-serif'; const tw = g.measureText(l.label).width + 10; g.fillStyle = l.color; g.fillRect(4, yy - 8, tw, 16); g.fillStyle = '#06101f'; g.fillText(l.label, 9, yy); g.font = '10.5px JetBrains Mono, monospace';
  }
}

/** Level lines of one symbol from the account view (positions + waiting orders). */
export function levelsOf(v, sym) {
  const out = [];
  for (const p of v.positions.filter((x) => x.sym === sym)) {
    out.push({ price: p.entry, color: '#60a5fa', label: `${p.side === 'buy' ? 'BUY' : 'SELL'} ${p.lots}` });
    if (p.sl) out.push({ price: p.sl, color: '#f87171', label: 'SL', dash: true }); if (p.tp) out.push({ price: p.tp, color: '#34d399', label: 'TP', dash: true });
  }
  for (const o of (v.pending || []).filter((x) => x.sym === sym)) out.push({ price: o.price, color: '#fbbf24', label: `${o.side === 'buy' ? 'BUY' : 'SELL'} ${o.type.toUpperCase()} ${o.lots}`, dash: true });
  return out;
}

export function statsHtml(st) {
  if (!st || !st.trades) return `<div class="card ch-stats"><h3>${L('إحصائياتك', 'Your statistics')}</h3><p class="muted">${L('بتبيّن بعد أول صفقة مسكّرة.', 'Shown after your first closed trade.')}</p></div>`;
  const cell = (a, b, cls = '') => `<div class="ch-stat ${cls}"><small>${esc(a)}</small><b>${b}</b></div>`;
  return `<div class="card ch-stats"><h3>${L('إحصائياتك', 'Your statistics')} <small class="muted">(${st.trades} ${L('صفقة مسكّرة', 'closed trades')})</small></h3>
    <div class="ch-statg">
      ${cell(L('نسبة الربح', 'Win rate'), `${st.winRate}%`, st.winRate >= 50 ? 'is-ok' : '')}
      ${cell(L('رابحة / خاسرة', 'Wins / losses'), `<span dir="ltr">${st.wins} / ${st.losses}</span>`)}
      ${cell(L('متوسط الربح', 'Avg win'), usd(st.avgWin), 'is-ok')}
      ${cell(L('متوسط الخسارة', 'Avg loss'), usd(-st.avgLoss), st.avgLoss ? 'is-bad' : '')}
      ${cell(L('معامل الربح', 'Profit factor'), st.profitFactor == null ? '—' : st.profitFactor.toFixed(2), st.profitFactor >= 1 ? 'is-ok' : st.profitFactor == null ? '' : 'is-bad')}
      ${cell(L('أحسن صفقة', 'Best trade'), usd(st.best), st.best > 0 ? 'is-ok' : '')}
      ${cell(L('أسوأ صفقة', 'Worst trade'), usd(st.worst), st.worst < 0 ? 'is-bad' : '')}
      ${cell(L('متوسط مدة الصفقة', 'Avg holding time'), st.avgHoldMin >= 120 ? `${(st.avgHoldMin / 60).toFixed(1)} ${L('س', 'h')}` : `${st.avgHoldMin} ${L('د', 'min')}`)}
    </div>
    <div class="ch-bysym">${st.bySymbol.map((s) => `<span class="ch-symchip ${s.pnl < 0 ? 'is-bad' : 'is-ok'}"><b>${esc(s.sym)}</b><i dir="ltr">${usd(s.pnl)}</i><small>${s.wins}/${s.trades}</small></span>`).join('')}</div></div>`;
}

/** Pass certificate as a PNG (drawn on the device from the account's real data). */
export async function downloadCertificate(v, holder) {
  const W = 1600, H = 1000; const cv = document.createElement('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d');
  const bg = g.createLinearGradient(0, 0, W, H); bg.addColorStop(0, '#0b1030'); bg.addColorStop(0.55, '#0a0d24'); bg.addColorStop(1, '#1a0f3a'); g.fillStyle = bg; g.fillRect(0, 0, W, H);
  const glow = g.createRadialGradient(W / 2, 250, 20, W / 2, 250, 620); glow.addColorStop(0, 'rgba(124,92,255,.35)'); glow.addColorStop(1, 'rgba(124,92,255,0)'); g.fillStyle = glow; g.fillRect(0, 0, W, H);
  g.strokeStyle = '#f5c84b'; g.lineWidth = 3; g.strokeRect(36, 36, W - 72, H - 72); g.strokeStyle = 'rgba(245,200,75,.35)'; g.lineWidth = 1; g.strokeRect(52, 52, W - 104, H - 104);
  try {
    const svg = logoMark(160).replace('<svg', '<svg xmlns="http://www.w3.org/2000/svg"'); const img = new Image();
    await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`; });
    g.drawImage(img, W / 2 - 70, 96, 140, 140);
  } catch { /* the certificate still works without the mark */ }
  const ar = document.documentElement.lang === 'ar' || document.documentElement.dir === 'rtl'; g.textAlign = 'center'; g.direction = ar ? 'rtl' : 'ltr';
  const F = (w, s) => `${w} ${s}px "IBM Plex Sans Arabic", "Space Grotesk", Inter, sans-serif`;
  g.fillStyle = '#e8ecff'; g.font = F(700, 34); g.fillText('AlphaTrade AI', W / 2, 290);
  g.fillStyle = '#f5c84b'; g.font = F(700, 64); g.fillText(v.phase === 'funded' ? L('شهادة متداول ممول', 'Funded Trader Certificate') : L('شهادة اجتياز', 'Certificate of Achievement'), W / 2, 390);
  g.fillStyle = '#9aa7cf'; g.font = F(500, 28); g.fillText(L('تُمنح هذه الشهادة إلى', 'This certificate is awarded to'), W / 2, 462);
  g.fillStyle = '#ffffff'; g.font = F(700, 72); g.fillText(String(holder || L('متداول', 'Trader')).slice(0, 40), W / 2, 560);
  const prog = tx(v.programName); const size = `$${v.size.toLocaleString('en-US')}`;
  g.fillStyle = '#c9d2f5'; g.font = F(500, 30);
  g.fillText(v.phase === 'funded' ? L(`لحصوله على حساب ممول ${size}, ${prog}`, `for earning a ${size} funded account, ${prog}`) : L(`لاجتيازه المرحلة ${v.phase} من ${prog}، حساب ${size}`, `for passing phase ${v.phase} of ${prog}, ${size} account`), W / 2, 630);
  g.direction = 'ltr';
  const cols = [[L('الربح', 'Profit'), `${v.profit >= 0 ? '+' : '−'}$${Math.abs(v.profit).toLocaleString('en-US', { maximumFractionDigits: 2 })}`], [L('أيام التداول', 'Trading days'), String(v.progress.days)], [L('التاريخ', 'Date'), new Date(v.endedAt || v.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })], [L('رقم الحساب', 'Account'), v.id]];
  cols.forEach(([a, b], i) => { const x = 260 + i * 360; g.fillStyle = '#7c8db3'; g.font = F(500, 22); g.fillText(a, x, 760); g.fillStyle = '#ffffff'; g.font = '700 32px "JetBrains Mono", monospace'; g.fillText(b, x, 804); });
  g.fillStyle = '#6b7a9c'; g.font = F(400, 20); g.direction = ar ? 'rtl' : 'ltr';
  g.fillText(L('حساب تجريبي (محاكاة) على أسعار سوق حقيقية، مش دليل على أرباح بفلوس حقيقية، والأداء السابق ما بيضمن نتائج.', 'Simulated (demo) account on real market prices, not evidence of real-money profit; past performance does not guarantee results.'), W / 2, 900);
  const a = document.createElement('a'); a.download = `AlphaTrade-certificate-${v.id}.png`; a.href = cv.toDataURL('image/png'); a.click();
}
