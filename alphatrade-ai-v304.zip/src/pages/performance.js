// Strategy performance page: backtest of the classic and SMC strategies on historical candles —
// winning trades, losing trades and net points per month, an equity curve and the latest trades.
import { h, esc, fmtNum } from '../utils/dom.js';
import { icons } from '../components/icons.js';
import { t, getLang } from '../i18n/index.js';
import { INSTRUMENTS, getInstrument, STOP_LOSS_POINTS, TARGET_POINTS } from '../config/instruments.js';
import { getHistory, isUnavailable } from '../services/market/index.js';
import { openBinanceStream } from '../services/market/binanceStream.js';
import { TIMEFRAMES } from '../config/market.js';
import { describeError } from '../utils/http.js';
import { backtestClassic, backtestSmc, backtestZone, backtestEdh, backtestLbr, summarize, rulesFrom } from '../services/backtest.js';
import { lbrHistory } from '../services/lbrData.js';
import { CHANNEL_STRATEGIES, RETIRED_STRATEGIES, setChannelPref } from '../services/channel.js';
import { stratName } from '../services/stratName.js';
import { regimeSeries, describe as describeRegime } from '../services/regime.js';
import { analyzeTrades } from '../services/lossAnalysis.js';
import { store } from '../state/store.js';
import { isReal, realOnlyCard } from '../components/realOnly.js';
import { tweenNumber } from '../utils/motion.js';
import { setStrategy } from '../services/strategy.js';
import { navigate } from '../router.js';

// History length per timeframe plus warm-up: 1m ≈ 7 days, 5m ≈ 1 month, 15m ≈ 1 month,
// 1h ≈ 3 months, 4h ≈ 6 months. "auto" tests 1m, 5m and 15m and picks the best.
const RANGES = { '1m': 1000, '5m': 1000, '15m': 1000, '1h': 1000, '4h': 1000 }; // last 1000 candles (one request)
const AUTO_TFS = ['1m', '5m', '15m'];
const TF_KEYS = ['auto', ...Object.keys(RANGES)];
const state = { symbol: null, tf: 'auto', strategy: 'edh' };

const signPts = (v) => `${v > 0 ? '+' : v < 0 ? '−' : ''}${fmtNum(Math.abs(v), 1)}`;
const dayName = (key) => new Date(`${key}T00:00:00Z`).toLocaleDateString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' });
const dateTime = (s) => new Date(s * 1000).toLocaleString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });

export function renderPerformance() {
  const list = INSTRUMENTS.filter((i) => !isUnavailable(i.symbol));
  if (!state.symbol || !list.some((i) => i.symbol === state.symbol)) state.symbol = store.get('symbol') && list.some((i) => i.symbol === store.get('symbol')) ? store.get('symbol') : list[0]?.symbol;

  const el = h(`<section class="subpage perf page-enter">
    <header class="subpage-head"><h1>${esc(t('perf.title'))}</h1><p class="muted">${esc(t('perf.sub'))}</p></header>
    <div class="card perf-controls fade-in">
      <label class="perf-field"><span>${esc(t('perf.symbol'))}</span>
        <select class="select" data-symbol>${list.map((i) => `<option value="${i.symbol}" ${i.symbol === state.symbol ? 'selected' : ''}>${i.symbol}</option>`).join('')}</select></label>
      <div class="perf-field"><span>${esc(t('perf.timeframe'))}</span>
        <div class="seg seg-wrap" data-tfs>${TF_KEYS.map((tf) => `<button type="button" data-tf="${tf}" class="${tf === state.tf ? 'is-on' : ''}">${esc(t(`perf.tf.${tf}`))}</button>`).join('')}</div></div>
      <div class="perf-field"><span>${esc(t('perf.strategy'))}</span>
        <div class="seg seg-wrap" data-strats>${['edh', 'lbr', 'classic', 'smc', 'zone'].map((k) => `<button type="button" data-strat="${k}" class="${state.strategy === k ? 'is-on' : ''}${RETIRED_STRATEGIES.includes(k) ? ' is-retired' : ''}"${RETIRED_STRATEGIES.includes(k) ? ` title="${esc(t('perf.retiredTip'))}"` : ''}>${esc(stratName(k))}${RETIRED_STRATEGIES.includes(k) ? ` <small>${esc(t('perf.retired'))}</small>` : ''}</button>`).join('')}</div></div>
    </div>
    <div class="perf-source muted" data-source></div>
    <div class="perf-body" data-body></div>
  </section>`);

  const body = el.querySelector('[data-body]');
  let results = null;
  let token = 0;

  let auto = null; // { byTf: {tf: results}, combos: [...], best }

  async function runFor(tf) {
    const ds = await getHistory(state.symbol, tf, RANGES[tf]);
    // LBR is defined on 5-minute candles and trades ~8 times a month: it is always tested on ~156 days of 5m candles (Binance only).
    const lbrDs = await lbrHistory(state.symbol);
    // Let the spinner paint before the computation.
    await new Promise((r) => setTimeout(r, 30));
    return compute(tf, ds, lbrDs);
  }

  function compute(tf, ds, lbrDs = null) {
    const inst = getInstrument(state.symbol);
    const pointSize = Number(store.get('settings').pointSizes?.[state.symbol]) > 0 ? Number(store.get('settings').pointSizes[state.symbol]) : inst.pointSize;
    // Same rules as the dashboard (Settings), all directions, fees included.
    const rules = { ...rulesFrom(store.get('settings'), inst), forced: null, pointSize, slPoints: STOP_LOSS_POINTS, tpPoints: TARGET_POINTS, volumeKind: ds.volumeKind };
    const classic = backtestClassic(ds.candles, rules);
    const smc = backtestSmc(ds.candles, rules);
    const zone = backtestZone(ds.candles, rules);
    const edh = backtestEdh(ds.candles, rules);
    const lbr = lbrDs ? backtestLbr(lbrDs.candles, { ...rules, volumeKind: lbrDs.volumeKind }) : { trades: [], open: null, pending: null, rejects: {} };
    // The old rule (fixed 30-point stop) for comparison, when the improved one is in use.
    const old = rules.stopMode === 'atr' ? backtestClassic(ds.candles, { ...rules, stopMode: 'points' }) : null;
    return { tf, ds, inst, pointSize, rules, old: old ? { ...old, sum: summarize(old.trades) } : null, classic: { ...classic, sum: summarize(classic.trades) }, smc: { ...smc, sum: summarize(smc.trades) }, zone: { ...zone, sum: summarize(zone.trades) }, edh: { ...edh, sum: summarize(edh.trades) }, lbr: { ...lbr, sum: summarize(lbr.trades) }, lbrDs };
  }

  /* ───────── Live: price every second, results recomputed when a candle closes ───────── */
  let stream = null;
  let liveTimer = null;
  let livePrice = null;
  let liveAt = null;
  let recomputing = false;
  let recomputeTimer = null;
  let liveGeneration = 0;
  function stopLive() { liveGeneration++; clearTimeout(recomputeTimer); recomputeTimer = null; recomputing = false; stream?.close(); stream = null; clearInterval(liveTimer); liveTimer = null; }
  function startLive() {
    stopLive();
    if (!results) return;
    const live = results.ds.mode === 'live' && results.inst.provider === 'binance';
    livePrice = results.ds.candles.at(-1)?.close ?? null;
    liveAt = null;
    if (live) {
      const sym = state.symbol;
      const interval = TIMEFRAMES.find((x) => x.id === results.tf)?.binance;
      stream = openBinanceStream({
        symbols: [sym], kline: { symbol: sym, interval },
        onTicker: (tk) => { if (tk.symbol === sym) { livePrice = tk.price; liveAt = Date.now(); } },
        onKline: (k) => onKline(k),
      });
    }
    liveTimer = setInterval(() => { if (!document.hidden && el.isConnected && !el.closest('[hidden]')) renderLive(); }, 1000);
    renderLive();
  }
  function onKline(k) {
    if (!results || !el.isConnected) return;
    const cs = results.ds.candles;
    const last = cs.at(-1);
    const bar = { time: k.time, open: k.open, high: k.high, low: k.low, close: k.close, volume: k.volume, buyVolume: k.buyVolume };
    if (last && k.time === last.time) Object.assign(last, bar);
    else if (!last || k.time > last.time) {
      cs.push(bar);
      // A candle just closed: replay the strategies so new trades and results appear.
      if (!recomputing) {
        recomputing = true;
        const generation = liveGeneration;
        const snapshot = results;
        recomputeTimer = setTimeout(() => {
          recomputeTimer = null;
          if (generation !== liveGeneration || results !== snapshot || !el.isConnected) { recomputing = false; return; }
          const fresh = compute(snapshot.tf, snapshot.ds, snapshot.lbrDs);
          if (auto) auto.byTf[results.tf] = fresh;
          results = fresh;
          recomputing = false;
          render();
          showSource();
        }, 50);
      }
    }
    livePrice = k.close;
    liveAt = Date.now();
  }
  function renderLive() {
    const box = body.querySelector('[data-live]');
    if (!el.isConnected) { stopLive(); return; }
    if (!box || !results) return;
    box.hidden = false;
    const r = results[state.strategy];
    const ps = results.pointSize;
    const prec = results.inst.precision;
    const price = livePrice ?? results.ds.candles.at(-1)?.close;
    const isLive = Boolean(stream);
    const today = Math.floor(Date.now() / 86400000);
    const todayN = r.trades.filter((x) => Math.floor(x.openTime / 86400) === today).length + (r.open && Math.floor(r.open.openTime / 86400) === today ? 1 : 0);
    let tradeHtml;
    if (r.open) {
      const o = r.open;
      const sign = o.direction === 'long' ? 1 : -1;
      let pts = 0;
      for (let k = 0; k < o.hits; k++) pts += ((o.targets[k] - o.entry) * sign) / ps / 3;
      pts += (((price - o.entry) * sign) / ps) * ((3 - o.hits) / 3);
      pts -= ((results.rules.feePct || 0) / 100) * o.entry / ps;
      tradeHtml = `<span class="badge ${o.direction === 'long' ? 'badge-live' : 'badge-error'}">${esc(t(o.direction === 'long' ? 'common.long' : 'common.short'))}</span>
        <span>${esc(t('perf.liveOpen', { entry: fmtNum(o.entry, prec), stop: fmtNum(o.stop, prec) }))}</span>
        <b class="mono ${pts >= 0 ? 'up' : 'down'}">${signPts(pts)}</b>`;
    } else if (r.pending) {
      tradeHtml = `<span>${esc(t('perf.livePending', { dir: t(r.pending.direction === 'long' ? 'common.long' : 'common.short'), entry: fmtNum(r.pending.entry, prec) }))}</span>`;
    } else tradeHtml = `<span class="muted">${esc(t('perf.liveNone'))}</span>`;
    box.innerHTML = `<div class="pl-row">
        <span class="pl-dot ${isLive ? 'on' : ''}"></span>
        <b class="mono pl-price">${fmtNum(price, prec)}</b>
        <span class="muted">${esc(isLive ? t('perf.liveOn', { time: new Date(liveAt || Date.now()).toLocaleTimeString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB') }) : t('perf.liveOff'))}</span>
        <span class="pl-today">${esc(t('perf.today', { n: todayN, max: results.rules.maxPerDay || '∞' }))}</span>
      </div>
      <div class="pl-trade">${tradeHtml}</div>`;
  }

  function showSource() {
    const ds = results.ds;
    const first = ds.candles[0]?.time;
    const last = ds.candles.at(-1)?.time;
    el.querySelector('[data-source]').innerHTML = `<span class="badge ${ds.mode === 'live' ? 'badge-live' : 'badge-demo'}">${esc(ds.mode === 'live' ? t('common.live') : t('common.demo'))}</span> ${esc(t(`perf.tf.${results.tf}`))} · ${esc(t('perf.range', { from: first ? dateTime(first) : '—', to: last ? dateTime(last) : '—', n: ds.candles.length, src: ds.source }))}`;
    if (ds.mode !== 'live') {
      const why = ds.notice?.error ? describeError(ds.notice.error, t) : ds.notice?.key ? t(ds.notice.key, { msg: '' }) : '';
      el.querySelector('[data-source]').insertAdjacentHTML('beforeend', `<div class="perf-demo-why">${icons.alert}<span>${esc(t('perf.demoWhy', { why }))}</span><button type="button" class="btn btn-sm" data-retry>${esc(t('common.retry'))}</button></div>`);
      el.querySelector('[data-retry]').addEventListener('click', () => load());
    }
  }

  async function load() {
    const my = ++token;
    stopLive();
    const loading = (txt) => { body.innerHTML = `<div class="card perf-loading"><span class="spinner"></span><span>${esc(txt)}</span></div>`; };
    loading(t('perf.loading'));
    el.querySelector('[data-source]').textContent = '';
    if (state.tf !== 'auto') {
      auto = null;
      const r = await runFor(state.tf);
      if (my !== token) return;
      if (!isReal(r.ds)) { results = null; body.innerHTML = realOnlyCard(r.ds); body.querySelector('[data-retry]')?.addEventListener('click', () => load()); return; }
      results = r;
      showSource();
      render();
      startLive();
      return;
    }
    // Auto: test 1m, 5m and 15m with both strategies, then pick the combination with the most net points.
    const byTf = {};
    for (let k = 0; k < AUTO_TFS.length; k++) {
      loading(t('perf.autoLoading', { n: k + 1, total: AUTO_TFS.length, tf: t(`perf.tf.${AUTO_TFS[k]}`) }));
      byTf[AUTO_TFS[k]] = await runFor(AUTO_TFS[k]);
      if (my !== token) return;
    }
    const fake = AUTO_TFS.find((tf) => !isReal(byTf[tf].ds));
    if (fake) { results = null; auto = null; body.innerHTML = realOnlyCard(byTf[fake].ds); body.querySelector('[data-retry]')?.addEventListener('click', () => load()); return; }
    const combos = [];
    // Only the active strategies are ranked (classic / SMC / Zones are retired); LBR exists on 5m only.
    for (const tf of AUTO_TFS) for (const st of CHANNEL_STRATEGIES) if (st !== 'lbr' || tf === '5m') combos.push({ tf, strategy: st, ...byTf[tf][st].sum.total });
    // Ranked by net R per trade (comparable across timeframes), not raw points (which grow with the stop size),
    // and only combinations with at least 10 trades: the best of nine tiny samples is mostly luck.
    const score = (c) => (c.trades >= 10 ? c.expectancy : -Infinity);
    const best = [...combos].sort((a, b) => score(b) - score(a))[0];
    auto = { byTf, combos, best };
    state.strategy = best.strategy;
    el.querySelectorAll('[data-strat]').forEach((x) => x.classList.toggle('is-on', x.dataset.strat === state.strategy));
    results = byTf[best.tf];
    showSource();
    render();
    startLive();
  }

  /** In auto mode: the best timeframe for the selected strategy. */
  function pickForStrategy() {
    if (!auto) return;
    const c = auto.combos.filter((x) => x.strategy === state.strategy).sort((a, b) => (b.trades >= 10 ? b.expectancy : -Infinity) - (a.trades >= 10 ? a.expectancy : -Infinity))[0];
    results = auto.byTf[c.tf];
    showSource();
    startLive();
  }

  function autoCard() {
    if (!auto) return '';
    const b = auto.best;
    const stName = stratName;
    const allLose = auto.combos.every((c) => c.expectancy <= 0 || c.trades < 10);
    return `<article class="card perf-auto fade-in">
      <div class="pa-head"><span class="pa-crown">${icons.trophy}</span><div><span class="muted">${esc(t('perf.autoBest'))}</span>
        <h2>${esc(t(`perf.tf.${b.tf}`))} · ${esc(stName(b.strategy))}</h2></div>
        <button type="button" class="btn btn-sm btn-primary" data-apply>${esc(t('perf.apply'))}</button></div>
      ${allLose ? `<p class="pa-warn">${icons.alert}<span>${esc(t('perf.allLose'))}</span></p>` : ''}
      <div class="table-scroll"><table class="kv-table wide-table perf-table pa-table">
        <thead><tr><th>${esc(t('perf.option'))}</th><th class="col-opt">${esc(t('perf.trades'))}</th><th>${esc(t('perf.winRate'))}</th><th>${esc(t('perf.pointsShort'))}</th><th class="col-opt">PF</th></tr></thead>
        <tbody>${auto.combos.map((c) => `<tr class="${c === b ? 'is-best' : ''}">
          <td><b>${esc(t(`perf.tfShort.${c.tf}`))}</b> · ${esc(stName(c.strategy))}</td><td class="mono col-opt">${c.trades}</td>
          <td class="mono">${fmtNum(c.winRate, 0)}%</td><td class="mono ${c.points >= 0 ? 'up' : 'down'}"><b>${signPts(c.points)}</b></td>
          <td class="mono col-opt">${Number.isFinite(c.profitFactor) ? fmtNum(c.profitFactor, 2) : '∞'}</td></tr>`).join('')}</tbody></table></div>
      <p class="muted pa-note">${esc(t('perf.autoNote', { fee: results.rules.feePct }))}</p>
    </article>`;
  }

  /** Market conditions, why trades lost, drawdown, and what blocking bad conditions would have done. */
  function lossCard(r) {
    const cs = r === results.lbr && results.lbrDs ? results.lbrDs.candles : results.ds.candles;   // LBR trades come from its own 5m candles
    if (!r._an) { const R = regimeSeries(cs); r._an = { R, a: analyzeTrades(r.trades, cs, R) }; }
    const { R, a } = r._an;
    const now = describeRegime(R, cs.length - 1);
    const chip = (k, v, cls = '') => `<span class="rg-chip ${cls}"><small>${esc(t(`rg.${k}`))}</small><b>${esc(v == null ? '—' : t(`rg.v.${v}`))}</b></span>`;
    const n = a.tagged.length;
    const pct = (x) => (a.causes.losers ? `${fmtNum((x / a.causes.losers) * 100, 0)}%` : '—');
    const wf = a.wf;
    const flags = a.flags.filter((f) => f.n > 0);
    const verdict = n < 60 ? t('rg.wfFew', { n })
      : wf.improved ? t('rg.wfYes', { flags: wf.blocked.map((f) => t(`rg.flag.${f}`)).join('، '), w0: fmtNum(wf.before.win, 0), w1: fmtNum(wf.after.win, 0), n0: wf.before.n, n1: wf.after.n })
      : wf.blocked.length ? t('rg.wfNo', { flags: wf.blocked.map((f) => t(`rg.flag.${f}`)).join('، ') }) : t('rg.wfNone');
    return `<article class="card perf-regime fade-in">
      <h2 class="card-title">${icons.info}<span>${esc(t('rg.title'))}</span></h2>
      <div class="rg-now"><span class="muted">${esc(t('rg.now'))}</span>${chip('vol', now.vol, now.vol === 'high' ? 'warn' : '')}${chip('liq', now.liq, now.liq === 'thin' ? 'warn' : '')}${chip('trend', now.trend)}${chip('htf', now.htf === 1 ? 'up' : now.htf === -1 ? 'down' : null)}</div>
      ${n ? `<div class="rg-dd"><div><small>${esc(t('rg.maxDd'))}</small><b class="mono down">${fmtNum(a.dd.maxDrawdownR, 1)}R</b></div><div><small>${esc(t('rg.streak'))}</small><b class="mono">${a.dd.longestLosingStreak}</b></div><div><small>${esc(t('rg.worstDay'))}</small><b class="mono down">${fmtNum(a.dd.worstDayR, 1)}R</b></div><div><small>${esc(t('rg.netR'))}</small><b class="mono ${a.dd.netR >= 0 ? 'up' : 'down'}">${a.dd.netR >= 0 ? '+' : ''}${fmtNum(a.dd.netR, 1)}R</b></div></div>
      ${a.causes.losers ? `      <h3 class="rg-h">${esc(t('rg.causesTitle', { n: a.causes.losers }))}</h3>
      <ul class="rg-causes"><li><b>${pct(a.causes.quick)}</b> ${esc(t('rg.c.quick'))}</li><li><b>${pct(a.causes.wick)}</b> ${esc(t('rg.c.wick'))}</li><li><b>${pct(a.causes.feesOnly)}</b> ${esc(t('rg.c.fees'))}</li><li><b>${pct(a.causes.afterTp1)}</b> ${esc(t('rg.c.afterTp1'))}</li><li><b>${pct(a.causes.flagged)}</b> ${esc(t('rg.c.flagged'))}</li></ul>` : ''}
      <div class="table-scroll"><table class="kv-table perf-table"><thead><tr><th>${esc(t('rg.cond'))}</th><th>${esc(t('perf.trades'))}</th><th>${esc(t('perf.winRate'))}</th><th>${esc(t('rg.avgR'))}</th><th>${esc(t('rg.without'))}</th></tr></thead>
        <tbody>${flags.map((f) => `<tr class="${f.n >= 20 && f.avgR <= -0.1 && f.z <= -2.5 ? 'is-bad' : ''}"><td>${esc(t(`rg.flag.${f.flag}`))}</td><td class="mono">${f.n}</td><td class="mono">${fmtNum(f.win, 0)}%</td><td class="mono ${f.avgR >= 0 ? 'up' : 'down'}">${fmtNum(f.avgR, 2)}</td><td class="mono muted">${fmtNum(f.restAvgR, 2)}</td></tr>`).join('')}</tbody></table></div>
      <p class="rg-verdict ${wf.improved ? 'is-yes' : ''}">${esc(verdict)}</p>` : `<p class="muted">${esc(t('perf.noTrades'))}</p>`}
      <p class="disclaimer">${esc(t('rg.note'))}</p>
    </article>`;
  }

  function render() {
    if (!results) return;
    const r = results[state.strategy];
    const s = r.sum.total;
    const pfTxt = Number.isFinite(s.profitFactor) ? fmtNum(s.profitFactor, 2) : '∞';
    body.innerHTML = `${autoCard()}<article class="card perf-live fade-in" data-live hidden></article>
      <div class="perf-kpis">
        <article class="card kpi kpi-win fade-in" style="animation-delay:0ms"><span class="kpi-label">${esc(t('perf.wins'))}</span><b class="kpi-val" data-n="${s.wins}">0</b><span class="kpi-sub up">${esc(t('perf.winsSub', { pts: signPts(s.grossWin) }))}</span></article>
        <article class="card kpi kpi-loss fade-in" style="animation-delay:70ms"><span class="kpi-label">${esc(t('perf.losses'))}</span><b class="kpi-val" data-n="${s.losses}">0</b><span class="kpi-sub down">${esc(t('perf.lossesSub', { pts: signPts(-s.grossLoss) }))}</span></article>
        <article class="card kpi kpi-rate fade-in" style="animation-delay:140ms"><span class="kpi-label">${esc(t('perf.winRate'))}</span><b class="kpi-val" data-n="${s.winRate}" data-dp="1" data-suffix="%">0</b>
          <span class="kpi-ring"><i style="--p:${s.winRate.toFixed(1)}"></i></span><span class="kpi-sub">${esc(t('perf.tradesN', { n: s.trades }))}</span></article>
        <article class="card kpi kpi-pts ${s.points >= 0 ? 'up' : 'down'} fade-in" style="animation-delay:210ms"><span class="kpi-label">${esc(t('perf.points'))}</span><b class="kpi-val" data-n="${s.points}" data-dp="1" data-signed>0</b><span class="kpi-sub">${esc(t('perf.pf', { pf: pfTxt }))}</span></article>
      </div>

      <article class="card perf-audit fade-in">
        <div><small>${esc(t('au.exp'))}</small><b class="mono ${s.expectancy > 0 ? 'up' : 'down'}">${s.expectancy >= 0 ? '+' : '−'}${fmtNum(Math.abs(s.expectancy), 2)}R</b></div>
        <div><small>${esc(t('au.gross'))}</small><b class="mono ${s.points + s.fees >= 0 ? 'up' : 'down'}">${signPts(s.points + s.fees)}</b></div>
        <div><small>${esc(t('au.fees'))}</small><b class="mono down">−${fmtNum(s.fees, 1)}</b></div>
        <div><small>${esc(t('au.net'))}</small><b class="mono ${s.points >= 0 ? 'up' : 'down'}">${signPts(s.points)}</b></div>
        <p class="muted">${esc(s.trades < 30 ? t('au.few', { n: s.trades }) : s.expectancy > 0 ? t('au.pos') : t('au.neg'))}</p>
        ${s.trades && s.feeR > 0.25 ? `<p class="pa-warn">${icons.alert}<span>${esc(t('au.feeHeavy', { f: fmtNum(s.feeR, 2) }))}</span></p>` : ''}
      </article>

      <div class="perf-grid">
        <article class="card perf-months fade-in">
          <h2 class="card-title">${esc(t('perf.daily'))}</h2>
          ${r.sum.days.length ? `<div class="table-scroll"><table class="kv-table wide-table perf-table">
            <thead><tr><th>${esc(t('perf.day'))}</th><th>${esc(t('perf.trades'))}</th><th>${esc(t('perf.winsShort'))}</th><th>${esc(t('perf.lossesShort'))}</th><th>${esc(t('perf.winRate'))}</th><th>${esc(t('perf.pointsShort'))}</th></tr></thead>
            <tbody>${r.sum.days.slice(0, 14).map((m) => `<tr>
              <td><b>${esc(dayName(m.day))}</b></td>
              <td class="mono">${m.trades}</td>
              <td class="mono up">${m.wins}</td>
              <td class="mono down">${m.losses}</td>
              <td><div class="wl-bar" title="${m.wins} / ${m.losses}"><i style="width:${m.winRate.toFixed(1)}%"></i></div><span class="mono wl-pct">${fmtNum(m.winRate, 0)}%</span></td>
              <td class="mono ${m.points >= 0 ? 'up' : 'down'}"><b>${signPts(m.points)}</b></td></tr>`).join('')}</tbody></table></div>` : `<p class="muted">${esc(t('perf.noTrades'))}</p>`}
        </article>

        <article class="card perf-equity fade-in">
          <h2 class="card-title">${esc(t('perf.equity'))}</h2>
          ${equitySvg(r.sum.equity)}
          <div class="perf-compare">
            <div class="${state.strategy === 'classic' ? 'is-on' : ''}"><span>${esc(t('perf.classic'))}</span><b class="mono ${results.classic.sum.total.points >= 0 ? 'up' : 'down'}">${signPts(results.classic.sum.total.points)}</b><small>${esc(t('perf.cmp', { w: results.classic.sum.total.wins, l: results.classic.sum.total.losses, r: fmtNum(results.classic.sum.total.winRate, 0) }))}</small></div>
            <div class="${state.strategy === 'smc' ? 'is-on' : ''}"><span>SMC</span><b class="mono ${results.smc.sum.total.points >= 0 ? 'up' : 'down'}">${signPts(results.smc.sum.total.points)}</b><small>${esc(t('perf.cmp', { w: results.smc.sum.total.wins, l: results.smc.sum.total.losses, r: fmtNum(results.smc.sum.total.winRate, 0) }))}</small></div>
            <div class="${state.strategy === 'zone' ? 'is-on' : ''}"><span>${esc(t('zs.name'))}</span><b class="mono ${results.zone.sum.total.points >= 0 ? 'up' : 'down'}">${signPts(results.zone.sum.total.points)}</b><small>${esc(t('perf.cmp', { w: results.zone.sum.total.wins, l: results.zone.sum.total.losses, r: fmtNum(results.zone.sum.total.winRate, 0) }))}</small></div>
            <div class="${state.strategy === 'edh' ? 'is-on' : ''}"><span>EDH</span><b class="mono ${results.edh.sum.total.points >= 0 ? 'up' : 'down'}">${signPts(results.edh.sum.total.points)}</b><small>${esc(t('perf.cmp', { w: results.edh.sum.total.wins, l: results.edh.sum.total.losses, r: fmtNum(results.edh.sum.total.winRate, 0) }))}</small></div>
            <div class="${state.strategy === 'lbr' ? 'is-on' : ''}"><span>${esc(t('lbr.name'))} <small class="muted">${esc(results.lbrDs ? t('perf.lbrSpan', { d: Math.round((results.lbrDs.candles.at(-1).time - results.lbrDs.candles[0].time) / 86400) }) : t('perf.lbrNone'))}</small></span><b class="mono ${results.lbr.sum.total.points >= 0 ? 'up' : 'down'}">${signPts(results.lbr.sum.total.points)}</b><small>${esc(t('perf.cmp', { w: results.lbr.sum.total.wins, l: results.lbr.sum.total.losses, r: fmtNum(results.lbr.sum.total.winRate, 0) }))}</small></div>
            ${results.old ? `<div class="perf-old"><span>${esc(t('perf.oldRule'))}</span><b class="mono ${results.old.sum.total.points >= 0 ? 'up' : 'down'}">${signPts(results.old.sum.total.points)}</b><small>${esc(t('perf.cmp', { w: results.old.sum.total.wins, l: results.old.sum.total.losses, r: fmtNum(results.old.sum.total.winRate, 0) }))}</small></div>` : ''}
          </div>
        </article>
      </div>

      ${lossCard(r)}

      <article class="card perf-trades fade-in">
        <h2 class="card-title">${esc(t('perf.latest'))}</h2>
        ${r.trades.length ? `<div class="table-scroll"><table class="kv-table wide-table perf-table">
          <thead><tr><th>${esc(t('perf.closed'))}</th><th>${esc(t('perf.dir'))}</th><th>${esc(t('plan.entry'))}</th><th>${esc(t('perf.result'))}</th><th>${esc(t('perf.pointsShort'))}</th></tr></thead>
          <tbody>${[...r.trades].reverse().slice(0, 12).map((tr) => `<tr>
            <td class="mono">${esc(dateTime(tr.closeTime))}</td>
            <td><span class="badge ${tr.direction === 'long' ? 'badge-live' : 'badge-error'}">${esc(t(tr.direction === 'long' ? 'common.long' : 'common.short'))}</span></td>
            <td class="mono">${fmtNum(tr.entry, results.inst.precision)}</td>
            <td><span class="res res-${tr.outcome}">${esc(t(`perf.out.${tr.outcome}`, { n: tr.hits }))}</span></td>
            <td class="mono ${tr.points >= 0 ? 'up' : 'down'}">${signPts(tr.points)}</td></tr>`).join('')}</tbody></table></div>` : `<p class="muted">${esc(t('perf.noTrades'))}</p>`}
        ${r.open ? `<p class="muted perf-open">${esc(t('perf.openNow', { dir: t(r.open.direction === 'long' ? 'common.long' : 'common.short'), entry: fmtNum(r.open.entry, results.inst.precision) }))}</p>` : ''}
      </article>

      <article class="card perf-rules fade-in">
        <h2 class="card-title">${icons.info}<span>${esc(t('perf.rulesTitle'))}</span></h2>
        <ul>${t('perf.rules').map((x) => { const v = { ps: results.pointSize, sl: STOP_LOSS_POINTS, tp: TARGET_POINTS.join(' / '), k: results.rules.atrMult, r: results.rules.tpR.join(' / '), fee: results.rules.feePct, max: results.rules.maxPerDay || '∞', min: fmtNum(results.rules.minRiskPct, 2), mode: results.rules.stopMode === 'atr' ? t('perf.modeAtr', { k: results.rules.atrMult, r: (results.rules.firstTargetR > 0 ? [results.rules.firstTargetR, ...results.rules.tpR.slice(1)] : results.rules.tpR).join(' / ') }) : t('perf.modePts', { sl: STOP_LOSS_POINTS, tp: TARGET_POINTS.join(' / ') }) }; return `<li>${esc(x.replace(/\{(\w+)\}/g, (m, k) => (k in v ? v[k] : m)))}</li>`; }).join('')}</ul>
        <p class="disclaimer">${esc(t('perf.disclaimer'))}</p>
      </article>`;
    // Count the KPI numbers up.
    body.querySelectorAll('.kpi-val').forEach((n) => {
      const v = Number(n.dataset.n);
      const dp = Number(n.dataset.dp || 0);
      const fmt = (x) => (n.dataset.signed !== undefined ? signPts(x) : fmtNum(x, dp)) + (n.dataset.suffix || '');
      n.textContent = fmt(0);
      tweenNumber(n, v, fmt, 900);
    });
    renderLive();
  }

  body.addEventListener('click', (e) => {
    if (!e.target.closest('[data-apply]') || !auto) return;
    store.set('symbol', state.symbol);
    // LBR is not a chart mode: it lives in the recommendations channel.
    if (auto.best.strategy === 'lbr') { setChannelPref('lbr'); navigate('#/app/signals'); return; }
    store.set('timeframe', auto.best.tf);
    setStrategy(auto.best.strategy);
    navigate('#/app');
  });
  el.querySelector('[data-symbol]').addEventListener('change', (e) => { state.symbol = e.target.value; load(); });
  el.querySelector('[data-tfs]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tf]'); if (!b || b.dataset.tf === state.tf) return;
    state.tf = b.dataset.tf; el.querySelectorAll('[data-tf]').forEach((x) => x.classList.toggle('is-on', x === b)); load();
  });
  el.querySelector('[data-strats]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-strat]'); if (!b || b.dataset.strat === state.strategy) return;
    state.strategy = b.dataset.strat; el.querySelectorAll('[data-strat]').forEach((x) => x.classList.toggle('is-on', x === b)); pickForStrategy(); render();
  });
  load();
  return el;
}

/** Cumulative points over time as a small SVG line (green above zero, red below). */
function equitySvg(eq) {
  if (eq.length < 2) return `<p class="muted">${esc(t('perf.noTrades'))}</p>`;
  const W = 600;
  const H = 180;
  const vals = [0, ...eq.map((p) => p.value)];
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const span = max - min || 1;
  const x = (i) => (i / (vals.length - 1)) * W;
  const y = (v) => H - 8 - ((v - min) / span) * (H - 16);
  const pts = vals.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  const zero = y(0);
  const last = vals.at(-1);
  const col = last >= 0 ? '#22c55e' : '#f0444f';
  return `<svg class="equity" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="${esc(t('perf.equity'))}">
    <defs><linearGradient id="eqFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".35"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs>
    <line x1="0" x2="${W}" y1="${zero}" y2="${zero}" class="eq-zero"/>
    <polygon points="0,${zero} ${pts} ${W},${zero}" fill="url(#eqFill)" class="eq-area"/>
    <polyline points="${pts}" fill="none" stroke="${col}" stroke-width="2.2" vector-effect="non-scaling-stroke" class="eq-line" pathLength="1"/>
  </svg>`;
}
