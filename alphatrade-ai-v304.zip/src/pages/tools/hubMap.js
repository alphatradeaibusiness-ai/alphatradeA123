// Which route belongs to which hub. Kept apart from hub.js (which pulls in every tool page) so the app shell can highlight the
// right menu entry without loading them; tests/hubMap.test.js checks it against HUBS so the two cannot drift.
export const HUB_TABS = {
  radar: ['radar', 'radar-smf', 'radar-tracker', 'radar-replay', 'radar-corr', 'radar-multi', 'radar-levels'],
  lab: ['lab', 'walkforward'],
  journal: ['journal', 'smartlog'],
  alerts: ['alerts', 'radar-rules'],
  news: ['news', 'calendar'],
};
// Old addresses that now live inside a hub tab.
// Removed pages (v159) open their nearest remaining page instead of a blank one.
export const ALIASES = { performance: 'lab', correlation: 'radar-corr', 'radar-market': 'radar', 'radar-vol': 'radar', 'radar-heat': 'radar', 'radar-liq': 'radar', 'radar-tf': 'lab', 'radar-perf': 'lab', 'radar-risk': 'risk', autotest: 'lab', versions: 'lab' };
const HUB_OF = {};
for (const [hub, tabs] of Object.entries(HUB_TABS)) for (const id of tabs) HUB_OF[id] = hub;
/** { hub, id } for a route that lives inside a hub, or null. */
export function hubOf(sub) {
  const id = ALIASES[sub] || sub;
  return HUB_OF[id] ? { hub: HUB_OF[id], id } : null;
}
