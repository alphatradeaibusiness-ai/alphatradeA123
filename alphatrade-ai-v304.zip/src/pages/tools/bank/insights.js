// Insights tab: rule-based insights (each one says why), the personal dashboard (net worth, 6-month cash flow, spending by
// category) and Open Banking (linked accounts at other banks, read-only; demo data in sandbox, labelled so).
import { icons } from '../../../components/icons.js';
import { bankApi } from '../../../services/bank/api.js';
import { dateStr } from '../common.js';
import { T, esc, fmtMinor, catName, opts, field, badge, fd, amt, card, empty } from './ui.js';

const usd = (v) => (v == null ? '—' : `$${Number(v).toLocaleString('en-US', { maximumFractionDigits: 2, minimumFractionDigits: 2 })}`);
const SEV = { warn: icons.alert, good: icons.check, info: icons.info };

/** Grouped bars (money in / money out per month). Two series → legend + per-bar hover title; values in the table below. */
function flowChart(rows) {
  const W = 640; const H = 200; const pad = 28; const max = Math.max(1, ...rows.flatMap((r) => [r.inUsd, r.outUsd]));
  const gw = (W - pad * 2) / rows.length; const bw = Math.min(26, gw / 3);
  const y = (v) => H - 24 - ((H - 44) * v) / max;
  return `<figure class="bank-chart"><div class="bank-legend"><span><i class="is-in"></i>${esc(T('ds.in'))}</span><span><i class="is-out"></i>${esc(T('ds.out'))}</span></div>
    <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(T('ds.flow'))}" dir="ltr"><line x1="${pad}" x2="${W - pad}" y1="${H - 24}" y2="${H - 24}" class="bank-axis"/>
    ${rows.map((r, i) => { const x = pad + i * gw + gw / 2; return `<g><rect class="bank-bar is-in" x="${x - bw - 1}" y="${y(r.inUsd)}" width="${bw}" height="${Math.max(0, H - 24 - y(r.inUsd))}" rx="3"><title>${esc(r.month)} · ${esc(T('ds.in'))}: ${usd(r.inUsd)}</title></rect>
      <rect class="bank-bar is-out" x="${x + 1}" y="${y(r.outUsd)}" width="${bw}" height="${Math.max(0, H - 24 - y(r.outUsd))}" rx="3"><title>${esc(r.month)} · ${esc(T('ds.out'))}: ${usd(r.outUsd)}</title></rect>
      <text x="${x}" y="${H - 8}" text-anchor="middle" class="bank-tick">${esc(r.month.slice(5))}/${esc(r.month.slice(2, 4))}</text></g>`; }).join('')}</svg></figure>`;
}
function catBars(rows) {
  if (!rows.length) return empty(T('ds.noSpend'));
  const max = Math.max(...rows.map((r) => r.amount));
  return `<ul class="bank-hbars">${rows.map((r) => `<li><span>${esc(catName(r.category))}</span><span class="bank-hbar"><i style="width:${Math.max(2, (r.amount / max) * 100)}%"></i></span><b class="mono">${fmtMinor(r.amount, 'USD')}</b></li>`).join('')}</ul>`;
}

export async function insightsTab(p, B) {
  p.innerHTML = '<div class="perf-loading"><span class="spinner"></span></div>';
  const [ins, dash, ob] = await Promise.all([bankApi.insights().catch(() => ({ items: [] })), bankApi.dashboard().catch(() => null), bankApi.ob().catch(() => ({ links: [], institutions: [] }))]);
  if (!B.alive() || B.st.tab !== 'insights') return;
  const it = (x) => {
    const pr = x.params || {};
    const text = T(`in.${x.kind}`, { category: catName(pr.category || ''), pct: pr.pct, merchant: pr.merchant || '', name: pr.name || '', pts: pr.pts,
      amount: pr.amount != null && pr.currency ? `${fmtMinor(pr.amount, pr.currency)} ${pr.currency}` : '', avg: pr.avg != null ? `${fmtMinor(pr.avg, 'USD')} USD` : '', before: pr.before != null ? `${fmtMinor(pr.before, pr.currency || 'USD')}` : '', at: pr.at ? dateStr(pr.at, { month: 'short', day: 'numeric' }) : '' });
    return `<li class="bank-insight is-${esc(x.severity)}">${SEV[x.severity] || icons.info}<span>${esc(text)}</span></li>`;
  };
  p.innerHTML = `${card(T('in.title'), icons.bulb, ins.items.length ? `<ul class="bank-insights">${ins.items.map(it).join('')}</ul><p class="muted tool-note">${esc(T('in.note'))}</p>` : empty(T('in.none')))}
    ${dash ? card(T('ds.title'), icons.lineChart, `<div class="bank-networth"><span class="muted">${esc(T('ds.netWorth'))}</span><b class="mono bank-amt">${usd(dash.netWorthUsd)}</b>${dash.complete ? '' : `<small class="muted">${esc(T('ds.partial'))}</small>`}</div>
        <div class="table-scroll"><table class="kv-table"><thead><tr><th>${esc(T('currency'))}</th><th>${esc(T('ds.wallet'))}</th><th>${esc(T('w.inPockets'))}</th><th>${esc(T('w.inVault'))}</th><th>${esc(T('held'))}</th></tr></thead><tbody>
        ${dash.parts.filter((x) => x.wallet || x.pockets || x.vault || x.held).map((x) => `<tr><td>${esc(x.currency)}</td><td class="mono">${fmtMinor(x.wallet, x.currency)}</td><td class="mono">${fmtMinor(x.pockets, x.currency)}</td><td class="mono">${fmtMinor(x.vault, x.currency)}</td><td class="mono">${fmtMinor(x.held, x.currency)}</td></tr>`).join('') || `<tr><td colspan="5" class="muted">—</td></tr>`}
        ${dash.invest.map((x) => `<tr><td>${esc(x.asset)}</td><td class="mono" colspan="4">${(x.qty / 1e8).toFixed(8)} · ${x.valueUsdt != null ? `${fmtMinor(x.valueUsdt, 'USDT')} USDT` : '—'}</td></tr>`).join('')}
        ${dash.external.map((x) => `<tr><td>${esc(x.currency)} ${x.demo ? `<span class="badge badge-demo">${esc(T('ob.demo'))}</span>` : ''}</td><td class="mono" colspan="4">${esc(T('ob.external'))}: ${fmtMinor(x.balance, x.currency)}</td></tr>`).join('')}</tbody></table></div>
        <h3 class="bank-h">${esc(T('ds.flow'))}</h3>${flowChart(dash.cashflow)}
        <div class="table-scroll"><table class="kv-table bank-small"><thead><tr><th>${esc(T('ds.month'))}</th><th>${esc(T('ds.in'))}</th><th>${esc(T('ds.out'))}</th></tr></thead><tbody>${dash.cashflow.map((r) => `<tr><td class="mono">${esc(r.month)}</td><td class="mono">${usd(r.inUsd)}</td><td class="mono">${usd(r.outUsd)}</td></tr>`).join('')}</tbody></table></div>
        <h3 class="bank-h">${esc(T('ds.byCat'))}</h3>${catBars(dash.spendByCategory)}
        <p class="muted tool-note">${esc(T('ds.note'))}</p>`) : ''}
    ${card(T('ob.title'), icons.globe2, `${!ob.provider ? `<p class="muted">${esc(T('ob.none'))}</p>` : `
      ${ob.links.map((l) => `<div class="bank-oblink"><div class="tool-head"><b>${esc(l.institution)}</b>${badge(l.status === 'active' ? 'active' : l.status)}
          <span class="bank-row-actions"><button class="btn btn-sm" data-obr="${esc(l.id)}">${icons.refresh}<span>${esc(T('ob.refresh'))}</span></button><button class="btn btn-sm btn-ghost" data-obx="${esc(l.id)}">${esc(T('ob.unlink'))}</button></span></div>
        <small class="muted">${esc(T('ob.consent', { t: dateStr(l.consentExpires, { year: 'numeric', month: 'short', day: 'numeric' }) }))}</small>
        <ul class="bank-list">${l.accounts.map((a) => `<li><b>${esc(a.name)}</b> <span class="mono">•••• ${esc(a.last4)}</span> ${amt(a.balance, a.currency)} ${a.demo ? `<span class="badge badge-demo">${esc(T('ob.demo'))}</span>` : ''} <button class="btn btn-sm btn-ghost" data-obt="${esc(a.id)}">${esc(T('ob.txns'))}</button></li>`).join('')}</ul><div data-obout></div></div>`).join('')}
      <form class="bank-form" data-oblink>${field(T('ob.bank'), `<select class="select" name="institution">${opts(ob.institutions)}</select>`)}<button class="btn btn-sm btn-primary" type="submit">${icons.plus}<span>${esc(T('ob.link'))}</span></button></form>
      <p class="muted tool-note">${esc(T(ob.demo ? 'ob.demoNote' : 'ob.note'))}</p>`}`)}`;
  const reload = () => insightsTab(p, B);
  p.querySelector('[data-oblink]')?.addEventListener('submit', async (e) => { e.preventDefault(); const v = fd(e.target); if (await B.act(e.target.querySelector('button'), () => B.secure('ob_link', v, (passkey) => bankApi.obLink({ ...v, passkey })), T('ob.linked'))) reload(); });
  p.querySelectorAll('[data-obr]').forEach((b) => b.addEventListener('click', async () => { if (await B.act(b, () => bankApi.obRefresh(b.dataset.obr))) reload(); }));
  p.querySelectorAll('[data-obx]').forEach((b) => b.addEventListener('click', async () => { if (!window.confirm(T('ob.confirmUnlink'))) return; if (await B.act(b, () => bankApi.obRevoke(b.dataset.obx), T('ob.unlinked'))) reload(); }));
  p.querySelectorAll('[data-obt]').forEach((b) => b.addEventListener('click', async () => {
    const r = await bankApi.obTxns(b.dataset.obt).catch(() => ({ items: [] }));
    b.closest('.bank-oblink').querySelector('[data-obout]').innerHTML = `<div class="table-scroll"><table class="kv-table bank-small"><tbody>${r.items.map((x) => `<tr><td class="mono">${esc(dateStr(x.at, { month: 'short', day: 'numeric' }))}</td><td>${esc(x.description)} <small class="muted">${esc(catName(x.category))}</small></td><td class="mono ${x.amount > 0 ? 'up' : 'down'}">${fmtMinor(x.amount, x.currency)} ${esc(x.currency)}</td></tr>`).join('')}</tbody></table></div>`;
  }));
}
