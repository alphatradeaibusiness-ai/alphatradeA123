// Security tab: passkeys (fingerprint / face), freeze everything, co-signers (M of N), notification settings and Web Push.
import { icons } from '../../../components/icons.js';
import { bankApi } from '../../../services/bank/api.js';
import { passkeysSupported, createPasskey } from '../../../services/bank/passkey.js';
import { pushSupported, enablePush, disablePush, currentSubscription } from '../../../services/bank/push.js';
import { getLang } from '../../../i18n/index.js';
import { dateStr } from '../common.js';
import { T, esc, CURS, field, input, badge, fd, amt, card, empty } from './ui.js';

const GROUPS = ['money', 'cards', 'planning', 'rewards', 'support', 'kyc', 'trading'];
const DEC = { USD: 2, EUR: 2, USDT: 6, BTC: 8 };

export async function securityTab(p, B) {
  const [tp, pk, ap, prefs, sub] = await Promise.all([bankApi.totp().catch(() => null), bankApi.passkeys().catch(() => ({ items: [] })), bankApi.approvals().catch(() => null), bankApi.prefs().catch(() => null), currentSubscription().catch(() => null)]);
  if (!B.alive() || B.st.tab !== 'security') return;
  const frozen = B.st.info.frozen;
  const totpCard = tp ? card(T('totp.title'), icons.lock, `<p class="muted tool-note">${esc(T('totp.note'))}</p>
      <p>${tp.enabled ? `<span class="badge badge-live">${esc(T('totp.on'))}</span> <small class="muted">${esc(T('totp.backupLeft', { n: tp.backupLeft }))}</small>` : `<span class="badge badge-demo">${esc(T('totp.off'))}</span>`}</p>
      <div data-totp-area>${tp.enabled
        ? `<form class="bank-form" data-totp-off>${field(T('totp.code'), input('code', { max: 12, mono: true }))}<button class="btn btn-sm btn-danger" type="submit">${esc(T('totp.disable'))}</button> <button class="btn btn-sm" type="button" data-totp-newcodes>${esc(T('totp.newCodes'))}</button></form>`
        : `<button class="btn btn-sm btn-primary" data-totp-start>${esc(T('totp.start'))}</button>`}</div>`) : '';
  p.innerHTML = `${totpCard}${card(T('sec.passkeys'), icons.fingerprint, `<p class="muted tool-note">${esc(T('sec.passkeyNote'))}</p>
      ${pk.items.length ? `<ul class="bank-list">${pk.items.map((x) => `<li>${icons.fingerprint}<b>${esc(x.name)}</b> <small class="muted">${esc(T('sec.added', { t: dateStr(x.createdAt) }))}${x.lastUsed ? ` · ${esc(T('sec.used', { t: dateStr(x.lastUsed) }))}` : ''}</small> <button class="btn btn-sm btn-ghost" data-pkdel="${esc(x.id)}">${icons.trash}</button></li>`).join('')}</ul>` : empty(T('sec.noPasskey'))}
      ${passkeysSupported() ? `<form class="bank-form" data-pkadd>${field(T('sec.deviceName'), input('name', { max: 40, value: /iPhone|iPad/.test(navigator.userAgent) ? 'iPhone' : /Android/.test(navigator.userAgent) ? 'Android' : /Mac/.test(navigator.userAgent) ? 'Mac' : 'Windows' }))}
        <button class="btn btn-sm btn-primary" type="submit">${icons.plus}<span>${esc(T('sec.addPasskey'))}</span></button></form>` : `<p class="muted">${esc(T('sec.noWebauthn'))}</p>`}`)}
    ${card(T('sec.freeze'), icons.lock, `<p>${frozen ? `<span class="badge badge-error">${esc(T('sec.frozenNow'))}</span>` : `<span class="badge badge-live">${esc(T('sec.activeNow'))}</span>`}</p>
      <p class="muted tool-note">${esc(T('sec.freezeNote'))}</p><button class="btn btn-sm ${frozen ? 'btn-primary' : 'btn-danger'}" data-freeze>${esc(T(frozen ? 'sec.unfreeze' : 'sec.freezeBtn'))}</button>`)}
    ${ap ? card(T('co.title'), icons.user, `<p class="muted tool-note">${esc(T('co.note'))}</p>
      ${ap.pending.length ? `<h3 class="bank-h">${esc(T('co.toApprove'))}</h3><ul class="bank-list">${ap.pending.map((a) => `<li><b>${esc(a.from)}</b> · ${esc(T(`co.kind.${a.kind}`))} ${amt(a.amount, a.currency)} <small class="muted">${a.approvals}/${a.needed} · ${esc(T('co.until', { t: dateStr(a.expiresAt) }))}</small>
        <button class="btn btn-sm btn-primary" data-vote="approve" data-id="${esc(a.id)}">${esc(T('adm.approve'))}</button><button class="btn btn-sm btn-ghost" data-vote="reject" data-id="${esc(a.id)}">${esc(T('adm.reject'))}</button></li>`).join('')}</ul>` : ''}
      ${ap.requests.length ? `<h3 class="bank-h">${esc(T('co.mine'))}</h3><ul class="bank-list">${ap.requests.slice(0, 5).map((a) => `<li>${esc(T(`co.kind.${a.kind}`))} ${amt(a.amount, a.currency)} ${badge(a.status)} <small class="muted">${a.approvals}/${a.needed}</small></li>`).join('')}</ul>` : ''}
      <h3 class="bank-h">${esc(T('co.signers'))} (${ap.signers.length})</h3>
      ${ap.signers.length ? `<ul class="bank-list">${ap.signers.map((x) => `<li>${icons.user}<b>${esc(x.label)}</b> <small class="muted">${esc(T('sec.added', { t: dateStr(x.since) }))}</small> <button class="btn btn-sm btn-ghost" data-aprdel="${esc(x.ref)}">${icons.trash}</button></li>`).join('')}</ul>` : empty(T('co.noSigners'))}
      <form class="bank-form" data-policy><label class="bank-check"><input type="checkbox" name="enabled" ${ap.policy.enabled ? 'checked' : ''} ${ap.signers.length ? '' : 'disabled'}/> ${esc(T('co.enable'))}</label>
        ${field(T('co.needed'), input('needed', { mono: true, mode: 'numeric', value: String(ap.policy.needed || 1) }))}
        ${CURS.map((c) => field(`${T('co.threshold')} ${c}`, input(`th_${c}`, { mono: true, mode: 'decimal', value: ap.policy.threshold[c] != null ? String(ap.policy.threshold[c] / 10 ** DEC[c]) : '' }))).join('')}
        <button class="btn btn-sm btn-primary" type="submit" ${ap.signers.length ? '' : 'disabled'}>${icons.check}<span>${esc(T('save'))}</span></button></form>
      <div class="bank-grid2"><form class="bank-form" data-invite>${field(T('co.inviteLabel'), input('label', { max: 30, req: true, ph: T('co.invitePh') }))}<button class="btn btn-sm" type="submit">${icons.plus}<span>${esc(T('co.invite'))}</span></button><p data-code class="mono bank-code" aria-live="polite"></p></form>
        <form class="bank-form" data-accept>${field(T('co.code'), input('code', { max: 20, req: true, mono: true }))}<button class="btn btn-sm" type="submit">${icons.check}<span>${esc(T('co.accept'))}</span></button></form></div>
      ${ap.iApproveFor.length ? `<p class="muted">${esc(T('co.iApprove'))}: ${ap.iApproveFor.map((x) => esc(x.label)).join(', ')}</p>` : ''}`) : ''}
    ${prefs ? card(T('nt.title'), icons.bell, `<form class="bank-form" data-prefs>${GROUPS.map((g) => `<label class="bank-check"><input type="checkbox" name="g_${g}" ${prefs.groups[g] ? 'checked' : ''}/> ${esc(T(`nt.g.${g}`))}</label>`).join('')}
        <label class="bank-check"><input type="checkbox" checked disabled/> ${esc(T('nt.g.security'))}</label>
        <label class="bank-check"><input type="checkbox" name="hideAmounts" ${prefs.hideAmounts ? 'checked' : ''}/> ${esc(T('nt.hide'))}</label>
        <button class="btn btn-sm btn-primary" type="submit">${icons.check}<span>${esc(T('save'))}</span></button></form>
      <div class="tool-actions">${pushSupported() ? (sub ? `<span class="badge badge-live">${esc(T('nt.pushOn'))}</span><button class="btn btn-sm" data-push="off">${esc(T('nt.pushOff'))}</button>` : `<button class="btn btn-sm btn-primary" data-push="on">${icons.bell}<span>${esc(T('nt.pushEnable'))}</span></button>`) : `<span class="muted">${esc(T('nt.pushUnsupported'))}</span>`}</div>
      <p class="muted tool-note">${esc(T('nt.note'))}</p>`) : ''}`;
  const reload = async () => { await B.refreshStatus(); securityTab(p, B); };
  p.querySelector('[data-pkadd]')?.addEventListener('submit', async (e) => {
    e.preventDefault(); const v = fd(e.target);
    if (await B.act(e.target.querySelector('button'), async () => {
      const made = await createPasskey();
      return B.secure('passkey_add', {}, (passkey) => bankApi.passkeyRegister({ ...made, name: v.name || 'Passkey', passkey }));
    }, T('sec.passkeyAdded'))) reload();
  });
  p.querySelectorAll('[data-pkdel]').forEach((b) => b.addEventListener('click', async () => { if (!window.confirm(T('sec.confirmRemove'))) return; const id = b.dataset.pkdel; if (await B.act(b, () => B.secure('passkey_remove', { id }, (passkey) => bankApi.passkeyRemove(id, { passkey })), T('sec.passkeyRemoved'))) reload(); }));
  const area = p.querySelector('[data-totp-area]');
  const showCodes = (codes) => {
    area.innerHTML = `<p class="muted tool-note">${esc(T('totp.saveCodes'))}</p><pre class="mono totp-codes">${codes.map(esc).join('\n')}</pre><button class="btn btn-sm btn-primary" data-totp-done>${esc(T('totp.done'))}</button>`;
    area.querySelector('[data-totp-done]').addEventListener('click', reload);
  };
  p.querySelector('[data-totp-start]')?.addEventListener('click', async (e) => {
    const r = await B.act(e.currentTarget, () => bankApi.totpEnroll()); if (!r?.secret) return;
    const pretty = r.secret.replace(/(.{4})/g, '$1 ').trim();
    area.innerHTML = `<p class="muted tool-note">${esc(T('totp.scan'))}</p><p class="mono totp-secret" dir="ltr">${esc(pretty)}</p>
      <p><a class="btn btn-sm" data-totp-link rel="noopener">${esc(T('totp.openApp'))}</a></p>
      <form class="bank-form" data-totp-confirm>${field(T('totp.code'), input('code', { max: 6, mono: true }))}<button class="btn btn-sm btn-primary" type="submit">${esc(T('totp.confirm'))}</button></form>`;
    if (/^otpauth:\/\/totp\//.test(r.uri)) area.querySelector('[data-totp-link]').href = r.uri;
    area.querySelector('[data-totp-confirm]').addEventListener('submit', async (ev) => {
      ev.preventDefault(); const v = fd(ev.target);
      const out = await B.act(ev.target.querySelector('button'), () => bankApi.totpConfirm(String(v.code || '').replace(/\s/g, '')), T('totp.enabled'));
      if (out?.backupCodes) showCodes(out.backupCodes);
    });
  });
  p.querySelector('[data-totp-off]')?.addEventListener('submit', async (e) => {
    e.preventDefault(); const v = fd(e.target);
    if (!window.confirm(T('totp.confirmOff'))) return;
    if (await B.act(e.target.querySelector('button'), () => bankApi.totpDisable(String(v.code || '').replace(/\s/g, '')), T('totp.disabled'))) reload();
  });
  p.querySelector('[data-totp-newcodes]')?.addEventListener('click', async (e) => {
    const v = fd(p.querySelector('[data-totp-off]'));
    const out = await B.act(e.currentTarget, () => bankApi.totpBackup(String(v.code || '').replace(/\s/g, '')));
    if (out?.backupCodes) showCodes(out.backupCodes);
  });
  p.querySelector('[data-freeze]').addEventListener('click', async (e) => {
    if (!frozen) { if (!window.confirm(T('sec.confirmFreeze'))) return; if (await B.act(e.currentTarget, () => bankApi.freeze({ on: true }), T('sec.frozen'))) reload(); return; }
    if (await B.act(e.currentTarget, () => B.secure('unfreeze', {}, (passkey) => bankApi.freeze({ on: false, passkey })), T('sec.unfrozen'))) reload();
  });
  p.querySelectorAll('[data-vote]').forEach((b) => b.addEventListener('click', async () => { const id = b.dataset.id; const decision = b.dataset.vote; if (await B.act(b, () => B.secure('approval_vote', { id, decision }, (passkey) => bankApi.vote(id, { decision, passkey })), T('adm.done'))) reload(); }));
  p.querySelectorAll('[data-aprdel]').forEach((b) => b.addEventListener('click', async () => { const ref = b.dataset.aprdel; if (!window.confirm(T('confirmDel'))) return; if (await B.act(b, () => B.secure('approver_remove', { ref }, (passkey) => bankApi.removeApprover(ref, { passkey })))) reload(); }));
  p.querySelector('[data-policy]')?.addEventListener('submit', async (e) => {
    e.preventDefault(); const v = fd(e.target);
    const threshold = {}; for (const c of CURS) if (v[`th_${c}`]) threshold[c] = v[`th_${c}`];
    const body = { enabled: Boolean(v.enabled), needed: Number(v.needed || 1), threshold };
    if (await B.act(e.target.querySelector('button'), () => B.secure('policy_set', body, (passkey) => bankApi.setPolicy({ ...body, passkey })), T('co.saved'))) reload();
  });
  p.querySelector('[data-invite]')?.addEventListener('submit', async (e) => { e.preventDefault(); const v = fd(e.target); const r = await B.act(e.target.querySelector('button'), () => bankApi.invite(v.label)); if (r?.code) e.target.querySelector('[data-code]').textContent = `${T('co.codeIs')}: ${r.code}`; });
  p.querySelector('[data-accept]')?.addEventListener('submit', async (e) => { e.preventDefault(); const v = fd(e.target); if (await B.act(e.target.querySelector('button'), () => bankApi.acceptInvite(v.code), T('co.accepted'))) reload(); });
  p.querySelector('[data-prefs]')?.addEventListener('submit', async (e) => {
    e.preventDefault(); const v = fd(e.target); const groups = {}; for (const g of GROUPS) groups[g] = Boolean(v[`g_${g}`]);
    await B.act(e.target.querySelector('button'), () => bankApi.setPrefs({ groups, hideAmounts: Boolean(v.hideAmounts), lang: getLang() }), T('nt.saved'));
  });
  p.querySelector('[data-push]')?.addEventListener('click', async (e) => {
    const on = e.currentTarget.dataset.push === 'on';
    if (await B.act(e.currentTarget, async () => { if (on) { await bankApi.setPrefs({ lang: getLang() }); return enablePush(); } return disablePush(); }, T(on ? 'nt.pushEnabled' : 'nt.pushDisabled'))) securityTab(p, B);
  });
}
