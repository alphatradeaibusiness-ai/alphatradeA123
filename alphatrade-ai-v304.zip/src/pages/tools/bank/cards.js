// Cards tab: virtual Visa cards (issued instantly by the connected issuer; in sandbox by the built-in test issuer that has no
// real card numbers), their controls and purchases, the purchase simulator (sandbox), blocked merchants, and the physical card request.
import { icons } from '../../../components/icons.js';
import { bankApi } from '../../../services/bank/api.js';
import { dateStr } from '../common.js';
import { T, Tx, esc, fmtMinor, CATEGORIES, catName, opts, field, input, badge, fd, amt, card, empty } from './ui.js';

const COLORS = ['alpha', 'graphite', 'sand', 'sage', 'slate', 'plum', 'dusk']; const PATTERNS = ['tree', 'lines', 'dots', 'waves', 'grid', 'plain'];
const artParts = (a) => { const [c, p] = String(a || '').split(':'); return [COLORS.includes(c) ? c : 'alpha', PATTERNS.includes(p) ? p : 'tree']; };
const spaced = (pan) => String(pan).replace(/(\d{4})(?=\d)/g, '$1 ');
/** The card picture. Colour and pattern are fixed classes (no user CSS); the number stays masked until details are revealed. */
function face(c, shown = null) {
  const [col, pat] = artParts(c.art);
  return `<div class="bank-vcard-face art-${col} pat-${pat}"><span class="bvc-brand">AlphaTrade <b>AI</b></span>
    <span class="bvc-mid"><i class="bvc-chip"></i><svg class="bvc-nfc" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 7c2.5 3 2.5 7 0 10M11 5c3.6 4.2 3.6 9.8 0 14M15 3c4.7 5.4 4.7 12.6 0 18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></span>
    <span class="mono bank-vcard-num" data-num>${shown ? esc(spaced(shown.pan)) : `•••• •••• •••• ${esc(c.last4)}`}</span>
    <span class="bvc-bottom"><span class="bvc-lbl">VALID THRU ${esc(c.exp)}${shown ? ` · CVV ${esc(shown.cvv)}` : ''}</span><span class="bvc-name">${esc((c.holder || c.label || '').toUpperCase())}</span></span>
    <span class="bank-vcard-brand">VISA</span>${c.issuer === 'sandbox' ? `<span class="bank-vcard-test">${esc(T('vc.testCard'))}</span>` : ''}</div>`;
}
function artPicker(cur) {
  const [col, pat] = artParts(cur);
  return `<fieldset class="bank-art"><legend>${esc(T('vc.art'))}</legend><div class="bank-swatches">${COLORS.map((x) => `<label class="bank-swatch art-${x}" title="${esc(Tx(`vc.color.${x}`, x))}"><input type="radio" name="artColor" value="${x}" ${x === col ? 'checked' : ''}/><span class="sr-only">${esc(Tx(`vc.color.${x}`, x))}</span></label>`).join('')}</div>
    <select class="select" name="artPattern" aria-label="${esc(T('vc.pattern'))}">${opts(PATTERNS, pat, (x) => Tx(`vc.pat.${x}`, x))}</select></fieldset>`;
}
function bindArt(form, base, target, replaceFace = false) {
  const draw = () => { const v = fd(form); const c = { ...base(), art: `${v.artColor || 'graphite'}:${v.artPattern || 'lines'}` };
    if (replaceFace) { target.className = `bank-vcard-face art-${artParts(c.art)[0]} pat-${artParts(c.art)[1]}`; } else target.innerHTML = face(c); };
  form.addEventListener('input', draw); form.addEventListener('change', draw); draw();
}
/** Shows number + CVV for 30 s on the card itself, then wipes them from the page. */
function showDetails(el, out, c, r) {
  const faceEl = el.querySelector('.bank-vcard-face');
  if (!r.pan) { out.innerHTML = `<p class="bank-reveal">${r.sandbox ? esc(T('vc.revealSandbox')) : esc(T('vc.revealIssuer'))} · <span class="mono">•••• ${esc(r.last4)} · ${esc(r.exp)}</span></p>`; return; }
  const secs = Math.min(60, Number(r.showSeconds) || 30); let left = secs;
  faceEl.outerHTML = face({ ...c, holder: r.holder || c.holder }, r);
  out.innerHTML = `<div class="bank-reveal" role="status"><span data-left></span> <button class="btn btn-sm" data-copy="pan">${esc(T('vc.copyNumber'))}</button> <button class="btn btn-sm" data-copy="cvv">${esc(T('vc.copyCvv'))}</button> <button class="btn btn-sm btn-ghost" data-hide>${esc(T('vc.hide'))}</button></div>`;
  const end = () => { clearInterval(timer); const f = el.querySelector('.bank-vcard-face'); if (f) f.outerHTML = face(c); out.innerHTML = ''; r = null; };
  const tick = () => { out.querySelector('[data-left]').textContent = T('vc.hidesIn').replace('{s}', String(left)); if (left-- <= 0) end(); };
  const timer = setInterval(tick, 1000); tick();
  out.querySelector('[data-hide]').addEventListener('click', end);
  out.querySelectorAll('[data-copy]').forEach((b) => b.addEventListener('click', async () => { try { await navigator.clipboard.writeText(r?.[b.dataset.copy] || ''); b.textContent = T('vc.copied'); } catch { /* clipboard blocked */ } }));
  document.addEventListener('visibilitychange', () => { if (document.hidden) end(); }, { once: true });
}

export async function cardsTab(p, B) {
  const { st } = B;
  if (st.wallet.kyc.tier < 2) { p.innerHTML = `<div class="card sig-empty">${icons.shield}<span>${esc(T('needKyc2'))}</span></div>`; return; }
  const [vc, pockets, purchases, blocked] = await Promise.all([bankApi.vcards().catch((e) => ({ items: [], error: e })), bankApi.pockets().catch(() => ({ items: [] })),
    bankApi.purchases().catch(() => ({ items: [] })), bankApi.blocked().catch(() => ({ items: [] }))]);
  if (!B.alive() || st.tab !== 'cards') return;
  const sandbox = st.info.mode === 'sandbox'; const issuer = vc.issuer;
  const usdPockets = pockets.items.filter((x) => x.currency === 'USD');
  p.innerHTML = `${!issuer ? `<div class="alert alert-info">${icons.info}<div>${esc(T('vc.noIssuer'))}</div></div>` : ''}
    <div class="bank-vcards">${vc.items.map((c) => `<article class="card bank-vcard is-${esc(c.status)}" data-card="${esc(c.id)}">
      ${face(c)}
      <div class="bank-vcard-body"><div>${badge(c.status)} <small class="muted">${esc(Tx(`vc.kind.${c.kind}`, c.kind))}${c.merchantLock ? ` · ${esc(c.merchantLock)}` : ''}</small></div>
        <small class="muted">${esc(T('vc.spentDay'))}: ${amt(c.spent.day, 'USD')} / ${amt(c.limits.day, 'USD')} · ${esc(T('vc.spentMonth'))}: ${amt(c.spent.month, 'USD')} / ${amt(c.limits.month, 'USD')} · ${esc(T('vc.perTx'))}: ${amt(c.limits.tx, 'USD')}</small>
        <div class="tool-actions">${c.status === 'active' ? `<button class="btn btn-sm" data-va="freeze">${esc(T('freeze'))}</button>` : ''}${c.status === 'frozen' ? `<button class="btn btn-sm" data-va="unfreeze">${esc(T('unfreeze'))}</button>` : ''}
          <button class="btn btn-sm" data-reveal>${icons.eye}<span>${esc(T('vc.reveal'))}</span></button><button class="btn btn-sm" data-limits>${icons.settings}<span>${esc(T('vc.limits'))}</span></button>
          <button class="btn btn-sm" data-design>${icons.sparkle}<span>${esc(T('vc.design'))}</span></button>${c.status === 'active' ? `<button class="btn btn-sm" data-apple>${icons.phone ? icons.phone : icons.card}<span>${esc(T('vc.apple'))}</span></button>` : ''}
          <button class="btn btn-sm btn-ghost" data-va="close">${esc(T('vc.close'))}</button></div><div data-cardout></div></div></article>`).join('') || ''}</div>
    ${issuer ? card(T('vc.new'), icons.card, `<form class="bank-form" data-vnew><div class="bank-vnew-preview" data-preview></div>
        ${field(T('vc.holder'), input('holder', { max: 26, req: true, ph: 'ADA LOVELACE', dir: 'ltr' }))}${field(T('vc.dob'), `<input class="input mono" type="date" name="dob" required autocomplete="off"/>`)}
        <p class="muted tool-note bank-sub">${esc(T('vc.verifyNote'))}</p>
        ${field(T('vc.label'), input('label', { max: 30, req: true, ph: T('vc.labelPh') }))}${artPicker('alpha:tree')}
        ${field(T('vc.kindL'), `<select class="select" name="kind">${opts(['standard', 'single_use', 'merchant_locked'], 'standard', (k) => T(`vc.kind.${k}`))}</select>`)}
        <span data-merch hidden class="bank-sub">${field(T('vc.merchant'), input('merchant', { max: 40, ph: 'Netflix' }))}</span>
        ${field(`${T('vc.perTx')} (USD)`, input('limitTx', { mono: true, ph: '1000', mode: 'decimal' }))}${field(`${T('vc.perDay')} (USD)`, input('limitDay', { mono: true, ph: '2000', mode: 'decimal' }))}${field(`${T('vc.perMonth')} (USD)`, input('limitMonth', { mono: true, ph: '5000', mode: 'decimal' }))}
        ${field(T('vc.funding'), `<select class="select" name="pocketId"><option value="">${esc(T('vc.fromWallet'))}</option>${usdPockets.map((x) => `<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('')}</select>`)}
        <button class="btn btn-sm btn-primary" type="submit">${icons.plus}<span>${esc(T('vc.create'))}</span></button></form><p class="muted tool-note">${esc(T('vc.note'))}</p>`) : ''}
    ${sandbox && vc.items.some((c) => c.status === 'active') ? card(T('vc.sim'), icons.bolt, `<form class="bank-form" data-sim>${field(T('vc.card'), `<select class="select" name="card">${vc.items.filter((c) => c.status === 'active').map((c) => `<option value="${esc(c.id)}">${esc(c.label)} •••• ${esc(c.last4)}</option>`).join('')}</select>`)}
        ${field(T('vc.merchant'), input('merchant', { max: 40, req: true, ph: 'Coffee Corner' }))}${field(T('lb.category'), `<select class="select" name="category">${opts(CATEGORIES, 'dining', catName)}</select>`)}
        ${field(`${T('amount')} (USD)`, input('amount', { mono: true, req: true, mode: 'decimal', ph: '4.20' }))}${field(T('vc.daysAgo'), input('daysAgo', { mono: true, ph: '0', mode: 'numeric' }))}
        <button class="btn btn-sm btn-primary" type="submit">${icons.send}<span>${esc(T('vc.pay'))}</span></button></form><p class="muted tool-note">${esc(T('vc.simNote'))}</p><p data-simout aria-live="polite"></p>`) : ''}
    ${card(T('vc.purchases'), icons.journal, purchases.items.length ? `<div class="table-scroll"><table class="kv-table"><thead><tr><th>${esc(T('when'))}</th><th>${esc(T('vc.merchant'))}</th><th>${esc(T('amount'))}</th><th>${esc(T('status'))}</th><th></th></tr></thead><tbody>${purchases.items.map((x) => `<tr><td class="mono">${esc(dateStr(x.createdAt))}</td><td>${esc(x.merchant)} <small class="muted">${esc(catName(x.category))}</small></td><td class="mono">${amt(x.amount, x.currency)}</td><td>${badge(x.status)}${x.reason ? ` <small class="muted">${esc(Tx(`decl.${x.reason}`, x.reason))}</small>` : ''}</td><td>${sandbox && ['approved', 'settled'].includes(x.status) ? `<button class="btn btn-sm btn-ghost" data-refund="${esc(x.id)}">${esc(T('vc.refund'))}</button>` : ''}</td></tr>`).join('')}</tbody></table></div>` : empty(T('vc.noPurchases')))}
    ${card(T('vc.blocked'), icons.lock, `${blocked.items.length ? `<ul class="bank-list">${blocked.items.map((b) => `<li><span class="mono">${esc(b.merchant_key)}</span> <button class="btn btn-sm btn-ghost" data-unblock="${esc(b.merchant_key)}">${esc(T('vc.unblock'))}</button></li>`).join('')}</ul>` : empty(T('vc.noBlocked'))}
      <form class="bank-form" data-block>${field(T('vc.merchant'), input('merchant', { max: 40, req: true }))}<button class="btn btn-sm" type="submit">${icons.lock}<span>${esc(T('vc.block'))}</span></button></form>`)}
    <div data-physical></div>`;

  const vnew = p.querySelector('[data-vnew]');
  if (vnew) {
    const sync = () => { p.querySelector('[data-merch]').hidden = vnew.kind.value !== 'merchant_locked'; }; vnew.kind.addEventListener('change', sync); sync();
    bindArt(vnew, () => ({ label: vnew.label.value || T('vc.labelPh'), holder: vnew.holder.value, exp: '••/••', last4: '0000', status: 'active', issuer: 'preview' }), p.querySelector('[data-preview]'));
    vnew.addEventListener('submit', async (e) => {
      e.preventDefault(); const v = fd(vnew); const body = Object.fromEntries(Object.entries(v).filter(([, x]) => x !== '')); body.art = `${body.artColor || 'graphite'}:${body.artPattern || 'lines'}`; delete body.artColor; delete body.artPattern;
      if (await B.act(vnew.querySelector('button'), () => B.secure('vcard_create', { kind: body.kind || 'standard', merchant: body.merchant, pocketId: body.pocketId }, (passkey) => bankApi.createVcard({ ...body, passkey })), T('vc.created'))) cardsTab(p, B);
    });
  }
  p.querySelectorAll('[data-card]').forEach((el) => {
    const id = el.dataset.card; const c = vc.items.find((x) => x.id === id); const out = el.querySelector('[data-cardout]');
    el.querySelectorAll('[data-va]').forEach((b) => b.addEventListener('click', async () => {
      if (b.dataset.va === 'close' && !window.confirm(T('vc.confirmClose'))) return;
      if (await B.act(b, () => bankApi.vcardAction(id, b.dataset.va))) cardsTab(p, B);
    }));
    el.querySelector('[data-reveal]').addEventListener('click', async (e) => {
      const r = await B.act(e.currentTarget, () => B.secure('card_reveal', { id }, (passkey) => bankApi.revealVcard(id, { passkey })));
      if (r) showDetails(el, out, c, r);
    });
    el.querySelector('[data-design]').addEventListener('click', () => {
      out.innerHTML = `<form class="bank-form" data-art>${artPicker(c.art)}<button class="btn btn-sm btn-primary" type="submit">${icons.check}<span>${esc(T('vc.saveDesign'))}</span></button></form>`;
      const f = out.querySelector('[data-art]'); bindArt(f, () => c, el.querySelector('.bank-vcard-face'), true);
      f.addEventListener('submit', async (ev) => { ev.preventDefault(); const v = fd(f);
        if (await B.act(f.querySelector('button'), () => B.secure('card_limits', { id, art: `${v.artColor}:${v.artPattern}` }, (passkey) => bankApi.updateVcard(id, { art: `${v.artColor}:${v.artPattern}`, passkey })), T('vc.saved'))) cardsTab(p, B); });
    });
    el.querySelector('[data-apple]')?.addEventListener('click', async (e) => {
      if (!vc.applePay) { out.innerHTML = `<p class="alert alert-info">${icons.info}<span>${esc(T('vc.appleOff'))}</span></p>`; return; }
      out.innerHTML = `<p class="alert alert-info">${icons.info}<span>${esc(T('vc.appleNeedsApp'))}</span></p>`;
    });
    el.querySelector('[data-limits]').addEventListener('click', () => {
      out.innerHTML = `<form class="bank-form" data-lim>${field(`${T('vc.perTx')} (USD)`, input('limitTx', { mono: true, value: fmtMinor(c.limits.tx, 'USD').replace(/,/g, '') }))}${field(`${T('vc.perDay')} (USD)`, input('limitDay', { mono: true, value: fmtMinor(c.limits.day, 'USD').replace(/,/g, '') }))}${field(`${T('vc.perMonth')} (USD)`, input('limitMonth', { mono: true, value: fmtMinor(c.limits.month, 'USD').replace(/,/g, '') }))}<button class="btn btn-sm btn-primary" type="submit">${icons.check}<span>${esc(T('save'))}</span></button></form>`;
      const f = out.querySelector('[data-lim]');
      f.addEventListener('submit', async (ev) => { ev.preventDefault(); const v = fd(f); if (await B.act(f.querySelector('button'), () => B.secure('card_limits', { id, ...v }, (passkey) => bankApi.updateVcard(id, { ...v, passkey })), T('vc.saved'))) cardsTab(p, B); });
    });
  });
  const sim = p.querySelector('[data-sim]');
  sim?.addEventListener('submit', async (e) => {
    e.preventDefault(); const v = fd(sim);
    const r = await B.act(sim.querySelector('button'), () => bankApi.simulate(v.card, { merchant: v.merchant, category: v.category, amount: v.amount, daysAgo: Number(v.daysAgo || 0) }));
    if (r) { p.querySelector('[data-simout]').innerHTML = r.approved ? `<span class="badge badge-live">${esc(T('vc.approved'))}</span>` : `<span class="badge badge-error">${esc(T('vc.declined'))}</span> ${esc(Tx(`decl.${r.reason}`, r.reason))}`; setTimeout(() => B.alive() && st.tab === 'cards' && cardsTab(p, B), 900); }
  });
  p.querySelectorAll('[data-refund]').forEach((b) => b.addEventListener('click', async () => { if (await B.act(b, () => bankApi.simulateRefund(b.dataset.refund), T('vc.refunded'))) cardsTab(p, B); }));
  p.querySelectorAll('[data-unblock]').forEach((b) => b.addEventListener('click', async () => { if (await B.act(b, () => bankApi.block(b.dataset.unblock, false))) cardsTab(p, B); }));
  p.querySelector('[data-block]').addEventListener('submit', async (e) => { e.preventDefault(); const v = fd(e.target); if (await B.act(e.target.querySelector('button'), () => bankApi.block(v.merchant, true), T('vc.blockedOk'))) cardsTab(p, B); });
  physical(p.querySelector('[data-physical]'), B);
}

/** The physical Visa card request (v149 flow: owner reviews, issuer produces, courier delivers). */
async function physical(el, B) {
  const cards = await bankApi.cards().catch(() => ({ items: [] })); if (!B.alive()) return;
  const addr = ['country', 'region', 'city', 'postal', 'line1', 'line2'].map((k) => field(T(k), input(`ad_${k}`, { max: k === 'country' ? 2 : 80, req: !['line2', 'region'].includes(k) }), k.startsWith('line'))).join('');
  const steps = ['requested', 'review', 'sent_to_issuer', 'produced', 'shipped', 'delivered', 'active'];
  const phys = cards.items.filter((c) => c.product === 'physical');
  el.innerHTML = `<article class="card tool-card"><h2 class="card-title">${icons.wallet}<span>${esc(T('cardTitle'))}</span></h2>
    <form class="bank-form" data-card-req><input type="hidden" name="product" value="physical"/>
      ${field(T('nameOnCard'), input('nameOnCard', { max: 26, req: true, ph: 'ADA LOVELACE' }))}${field(T('phone'), input('phone', { max: 20, req: true, ph: '+49 30 1234567', dir: 'ltr' }))}${field(T('vc.dob'), `<input class="input mono" type="date" name="dob" required autocomplete="off"/>`)}
      <span class="bank-sub">${field(T('shipping'), `<select class="select" name="shipping"><option value="standard">${esc(T('standard'))} ($15)</option><option value="express">${esc(T('express'))} ($35)</option></select>`)}
      <h3 class="bank-h">${esc(T('deliveryAddress'))}</h3>${addr}</span>
      <label class="bank-check"><input type="checkbox" name="terms"/> ${esc(T('consentTerms'))}</label><label class="bank-check"><input type="checkbox" name="fees"/> ${esc(T('consentFees'))}</label><label class="bank-check"><input type="checkbox" name="dataSharing"/> ${esc(T('consentData'))}</label>
      <button class="btn btn-sm btn-primary" type="submit">${icons.send}<span>${esc(T('requestCard'))}</span></button></form>
    <p class="muted tool-note">${esc(T('cardNote'))}</p></article>
    ${phys.map((c) => `<article class="card tool-card"><div class="tool-head"><h2 class="card-title">${icons.wallet}<span>${esc(T('physical'))} · ${esc(c.city || '')} ${esc(c.country || '')}</span></h2>${badge(c.status)}</div>
      <ol class="bank-steps">${steps.map((s) => `<li class="${steps.indexOf(s) <= steps.indexOf(c.status) ? 'is-done' : ''}">${esc(Tx(`st.${s}`, s))}</li>`).join('')}</ol>
      ${c.tracking ? `<p class="mono">${esc(T('tracking'))}: ${esc(c.tracking)}</p>` : ''}
      <div class="tool-actions">${c.status === 'requested' ? `<button class="btn btn-sm" data-ca="cancel" data-id="${esc(c.id)}">${esc(T('cancel'))}</button>` : ''}${c.status === 'delivered' ? `<button class="btn btn-sm btn-primary" data-ca="activate" data-id="${esc(c.id)}">${esc(T('activate'))}</button>` : ''}${c.status === 'active' ? `<button class="btn btn-sm" data-ca="freeze" data-id="${esc(c.id)}">${esc(T('freeze'))}</button>` : ''}${c.status === 'frozen' ? `<button class="btn btn-sm" data-ca="unfreeze" data-id="${esc(c.id)}">${esc(T('unfreeze'))}</button>` : ''}</div></article>`).join('')}`;
  const f = el.querySelector('[data-card-req]');
  f.addEventListener('submit', async (e) => {
    e.preventDefault(); const v = fd(f);
    const payload = { product: 'physical', dob: v.dob, nameOnCard: v.nameOnCard, phone: v.phone, shipping: v.shipping, consents: { terms: Boolean(v.terms), fees: Boolean(v.fees), dataSharing: Boolean(v.dataSharing) },
      address: { country: v.ad_country, region: v.ad_region || '-', city: v.ad_city, postal: v.ad_postal, line1: v.ad_line1, line2: v.ad_line2 } };
    if (await B.act(f.querySelector('button'), () => bankApi.requestCard(payload), T('cardRequested'))) physical(el, B);
  });
  el.querySelectorAll('[data-ca]').forEach((b) => b.addEventListener('click', async () => { if (await B.act(b, () => bankApi.cardAction(b.dataset.id, b.dataset.ca))) physical(el, B); }));
}
