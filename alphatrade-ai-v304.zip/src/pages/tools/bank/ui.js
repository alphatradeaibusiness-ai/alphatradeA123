// Shared helpers for the bank page sections (rendering only — every rule lives on the server).
import { esc } from '../../../utils/dom.js';
import { t } from '../../../i18n/index.js';
import { CURRENCIES, fmtMinor } from '../../../services/bank/money.js';

export { esc, fmtMinor, CURRENCIES };
export const T = (k, p) => t(`tools.bank.${k}`, p);
/** Translation with a fallback to the raw value when a key is missing (e.g. a new server code). */
export const Tx = (k, fallback) => { const v = T(k); return v.startsWith('tools.bank.') ? fallback : v; };
export const errText = (e) => { const c = e?.code || 'unknown'; const m = t(`tools.bank.err.${c}`); return m && !m.startsWith('tools.bank.err.') ? m : T('err.unknown'); };
export const CURS = Object.keys(CURRENCIES);
export const CATEGORIES = ['groceries', 'dining', 'transport', 'shopping', 'bills', 'subscriptions', 'entertainment', 'travel', 'health', 'education', 'transfers', 'savings', 'investing', 'fees', 'income', 'other'];
export const catName = (c) => Tx(`cat.${c}`, c);
export const opts = (list, sel, label = (x) => x) => list.map((x) => `<option value="${esc(x)}" ${x === sel ? 'selected' : ''}>${esc(label(x))}</option>`).join('');
export const field = (label, inner, wide = false) => `<label class="tf-field ${wide ? 'tf-wide' : ''}"><span>${esc(label)}</span>${inner}</label>`;
export const input = (name, o = {}) => `<input class="input ${o.mono ? 'mono' : ''}" name="${name}" ${o.type ? `type="${o.type}"` : ''} ${o.ph ? `placeholder="${esc(o.ph)}"` : ''} ${o.max ? `maxlength="${o.max}"` : ''} ${o.dir ? `dir="${o.dir}"` : ''} ${o.req ? 'required' : ''} ${o.value != null ? `value="${esc(o.value)}"` : ''} ${o.mode ? `inputmode="${o.mode}"` : ''} autocomplete="off" spellcheck="false"/>`;
const GOOD = ['completed', 'confirmed', 'active', 'approved', 'filled', 'delivered', 'settled', 'released', 'answered', 'linked'];
const BAD = ['rejected', 'failed', 'cancelled', 'expired', 'declined', 'blocked', 'closed', 'refunded', 'reversed'];
export const badge = (st) => `<span class="badge ${GOOD.includes(st) ? 'badge-live' : BAD.includes(st) ? 'badge-error' : 'badge-demo'}">${esc(Tx(`st.${st}`, st))}</span>`;
export const fd = (form) => Object.fromEntries(new FormData(form).entries());
export const amt = (n, cur) => `<bdi class="mono">${fmtMinor(n, cur)} ${esc(cur)}</bdi>`;
export const card = (title, icon, body, extra = '') => `<article class="card tool-card ${extra}"><h2 class="card-title">${icon}<span>${esc(title)}</span></h2>${body}</article>`;
/** "12.5" → minor units for display-side checks only (the server re-validates). */
export const empty = (msg) => `<p class="muted">${esc(msg)}</p>`;
