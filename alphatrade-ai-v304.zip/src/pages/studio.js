// v251 Strategy Studio — build a rule-based strategy without code, back-test it on real closed candles (in-sample 70 % /
// out-of-sample 30 %, costs included, a candle touching stop and target counts as the stop), get its Strategy DNA
// (a deterministic fingerprint + a 10-axis profile), compare it with your other strategies and the Arena, and submit it to
// the Anonymous Strategy Arena (the SERVER re-tests it on its own data and keeps forward-testing it — results from a page
// are never trusted). Nothing here touches the EDH strategy or the signal engines.
import { h, esc, fmtNum } from '../utils/dom.js';
import { icons } from '../components/icons.js';
import { getLang } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { apiRequest } from '../services/ai/gateway.js';
import { toast } from '../components/ui.js';
import { getHistory } from '../services/market/index.js';
import { TIMEFRAMES } from '../config/market.js';
import { LAB_SYMBOLS, LAB_TFS, RULES, cleanSpec, backtest, splitTest, strategyDna, dnaSimilarity, DNA_AXES } from '../services/strategyLab.js';
import { lineSvg, dateStr } from './tools/common.js';
import { pageHead } from './community.js';
import { roomErr } from './rooms.js';
import '../styles/rooms.css';

const L = (ar, en) => tx({ ar, en });
const ruleName = (t) => (getLang() === 'ar' ? RULES[t].ar : RULES[t].en);
const OPT = { up: ['صعود', 'up'], down: ['هبوط', 'down'], above: ['فوق', 'above'], below: ['تحت', 'below'], lt: ['أقل من', '<'], gt: ['أكبر من', '>'], lower: ['السفلي', 'lower'], upper: ['العلوي', 'upper'], asia: ['آسيا', 'Asia'], london: ['لندن', 'London'], newyork: ['نيويورك', 'New York'] };
const PN = { fast: ['سريع', 'fast'], slow: ['بطيء', 'slow'], len: ['الطول', 'length'], dir: ['الاتجاه', 'direction'], op: ['الشرط', 'condition'], level: ['المستوى', 'level'], mult: ['المضاعف', 'mult'], band: ['الحد', 'band'], name: ['الجلسة', 'session'] };
const SAVE_KEY = 'ata:studio:v1';
const loadSaved = () => { try { return JSON.parse(localStorage.getItem(SAVE_KEY) || '[]'); } catch { return []; } };
const storeSaved = (l) => { try { localStorage.setItem(SAVE_KEY, JSON.stringify(l.slice(0, 30))); } catch { /* */ } };
const PRESETS = [
  { name: 'Trend pullback', symbol: 'BTCUSDT', tf: '1h', side: 'both', entry: [{ type: 'price_ema', len: 200, dir: 'above' }, { type: 'rsi', len: 14, op: 'lt', level: 40 }, { type: 'adx', len: 14, op: 'gt', level: 20 }], exit: { stopAtr: 1.5, rr: 2, maxBars: 48 } },
  { name: 'Donchian breakout', symbol: 'XAUUSD', tf: '4h', side: 'both', entry: [{ type: 'breakout', len: 20, dir: 'up' }, { type: 'adx', len: 14, op: 'gt', level: 22 }], exit: { stopAtr: 2, rr: 2.5, maxBars: 40, trail: true } },
  { name: 'Bollinger mean reversion', symbol: 'EURUSD', tf: '1h', side: 'both', entry: [{ type: 'bb_touch', len: 20, mult: 2, band: 'lower' }, { type: 'adx', len: 14, op: 'lt', level: 20 }], exit: { stopAtr: 1.2, rr: 1.5, maxBars: 24 } },
];

/** SVG radar of a DNA vector (0..1 per axis); `other` is drawn as a dashed overlay. */
export function dnaRadar(v, other = null, size = 260) {
  const n = DNA_AXES.length; const c = size / 2; const R = c - 34;
  const pt = (i, r) => { const a = (Math.PI * 2 * i) / n - Math.PI / 2; return [c + Math.cos(a) * R * r, c + Math.sin(a) * R * r]; };
  const poly = (vec) => vec.map((x, i) => pt(i, Math.max(0.03, x)).map((q) => q.toFixed(1)).join(',')).join(' ');
  const rings = [0.25, 0.5, 0.75, 1].map((r) => `<polygon points="${DNA_AXES.map((_, i) => pt(i, r).join(',')).join(' ')}" class="dna-ring"/>`).join('');
  const labels = DNA_AXES.map((a, i) => { const [x, y] = pt(i, 1.17); return `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" text-anchor="middle" dominant-baseline="middle">${esc(getLang() === 'ar' ? a[1] : a[2])}</text>`; }).join('');
  return `<svg class="dna-radar" viewBox="0 0 ${size} ${size}" role="img" aria-label="DNA">${rings}${DNA_AXES.map((_, i) => `<line x1="${c}" y1="${c}" x2="${pt(i, 1)[0]}" y2="${pt(i, 1)[1]}" class="dna-axis"/>`).join('')}
    ${other ? `<polygon points="${poly(other)}" class="dna-other"/>` : ''}<polygon points="${poly(v)}" class="dna-me"/>${labels}</svg>`;
}
const mBox = (title, m) => `<div class="card st-m"><h4>${esc(title)}</h4>${m && m.n ? `<dl>
  <dt>${L('صفقات', 'Trades')}</dt><dd>${m.n}</dd><dt>${L('نسبة الربح', 'Win rate')}</dt><dd>${m.winRate}%</dd><dt>${L('التوقع (R)', 'Expectancy (R)')}</dt><dd class="${m.expR > 0 ? 'up' : 'down'}">${m.expR}</dd>
  <dt>${L('معامل الربح', 'Profit factor')}</dt><dd>${m.pf === 99 ? '∞' : m.pf}</dd><dt>${L('المجموع (R)', 'Total (R)')}</dt><dd class="${m.totalR > 0 ? 'up' : 'down'}">${m.totalR}</dd><dt>${L('أقصى سحب (R)', 'Max DD (R)')}</dt><dd>${m.maxDdR}</dd>
  <dt>Sharpe*</dt><dd>${m.sharpe}</dd><dt>${L('متوسط المدة (شموع)', 'Avg bars')}</dt><dd>${m.avgBars}</dd></dl>` : `<p class="muted">${L('ولا صفقة.', 'No trades.')}</p>`}</div>`;

export function renderStudio() {
  const root = h(`<section class="subpage tool cm rm st page-enter">${pageHead('fingerprint', L('استوديو الاستراتيجيات و DNA', 'Strategy studio & DNA'), L('ابني استراتيجيتك بدون كود، اختبرها على شموع حقيقية مسكّرة (داخل/خارج العينة)، شوف بصمتها DNA، وقارنها، وابعتها للساحة المجهولة.', 'Build without code, back-test on real closed candles (in/out of sample), see its DNA fingerprint, compare it, and enter the anonymous Arena.'))}
    <nav class="rm-tabs"><button type="button" class="rm-tab is-on" data-tab="build">${icons.flask}<span>${L('البناء والاختبار', 'Build & test')}</span></button><button type="button" class="rm-tab" data-tab="arena">${icons.trophy}<span>${L('الساحة المجهولة', 'Anonymous arena')}</span></button><button type="button" class="rm-tab" data-tab="saved">${icons.journal}<span>${L('استراتيجياتي', 'My strategies')}</span></button></nav>
    <div class="tool-body" data-body></div></section>`);
  const body = root.querySelector('[data-body]');
  let spec = structuredClone(PRESETS[0]); let last = null;

  function ruleRow(r, i) {
    const def = RULES[r.type];
    return `<div class="st-rule" data-i="${i}"><b>${esc(ruleName(r.type))}</b>${Object.entries(def.p).map(([k, d]) => typeof d[0] === 'string'
      ? `<label>${esc(L(...(PN[k] || [k, k])))}<select class="input input-sm" data-k="${k}">${d.map((o) => `<option value="${o}"${r[k] === o ? ' selected' : ''}>${esc(L(...(OPT[o] || [o, o])))}</option>`).join('')}</select></label>`
      : `<label>${esc(L(...(PN[k] || [k, k])))}<input class="input input-sm mono" type="number" step="any" min="${d[0]}" max="${d[1]}" data-k="${k}" value="${r[k] ?? d[2]}"></label>`).join('')}
      <button type="button" class="btn btn-sm btn-ghost" data-del="${i}">${icons.trash}</button></div>`;
  }
  function build() {
    body.innerHTML = `<div class="st-wrap">
      <form class="card rm-sec st-form" data-f>
        <div class="st-presets">${PRESETS.map((p, i) => `<button type="button" class="btn btn-sm btn-ghost" data-pre="${i}">${esc(p.name)}</button>`).join('')}</div>
        <div class="rm-form-g">
          <label>${L('الاسم', 'Name')}<input class="input" name="name" maxlength="60" value="${esc(spec.name)}"></label>
          <label>${L('الرمز', 'Symbol')}<select class="input" name="symbol">${LAB_SYMBOLS.map((s) => `<option${s === spec.symbol ? ' selected' : ''}>${s}</option>`).join('')}</select></label>
          <label>${L('الفريم', 'Timeframe')}<select class="input" name="tf">${LAB_TFS.map((s) => `<option${s === spec.tf ? ' selected' : ''}>${s}</option>`).join('')}</select></label>
          <label>${L('الاتجاه', 'Side')}<select class="input" name="side">${[['both', 'الاتنين', 'Both'], ['long', 'شراء بس', 'Long only'], ['short', 'بيع بس', 'Short only']].map(([v, a, b]) => `<option value="${v}"${spec.side === v ? ' selected' : ''}>${esc(L(a, b))}</option>`).join('')}</select></label>
        </div>
        <h3>${L('شروط الدخول (كلها لازم تتحقق)', 'Entry rules (all must be true)')}</h3>
        <p class="muted">${L('للاتجاه "الاتنين": الشروط بتنعكس تلقائيًا للبيع.', 'With "Both", rules mirror automatically for shorts.')}</p>
        <div data-rules>${spec.entry.map(ruleRow).join('')}</div>
        <div class="st-add"><select class="input input-sm" data-addsel>${Object.keys(RULES).map((k) => `<option value="${k}">${esc(ruleName(k))}</option>`).join('')}</select><button type="button" class="btn btn-sm" data-add>${icons.plus}<span>${L('ضيف شرط', 'Add rule')}</span></button></div>
        <h3>${L('الخروج', 'Exit')}</h3>
        <div class="rm-form-g">
          <label>${L('الوقف (× ATR)', 'Stop (× ATR)')}<input class="input mono" type="number" step="0.1" min="0.3" max="6" name="stopAtr" value="${spec.exit.stopAtr}"></label>
          <label>${L('الهدف (R)', 'Target (R)')}<input class="input mono" type="number" step="0.1" min="0.5" max="8" name="rr" value="${spec.exit.rr}"></label>
          <label>${L('أقصى مدة (شموع)', 'Max bars')}<input class="input mono" type="number" min="3" max="500" name="maxBars" value="${spec.exit.maxBars}"></label>
          <label class="rm-checks"><input type="checkbox" name="trail"${spec.exit.trail ? ' checked' : ''}> ${L('وقف متحرك', 'Trailing stop')}</label>
        </div>
        <div class="rm-form-a"><button class="btn btn-primary">${icons.flask}<span>${L('اختبر على بيانات حقيقية', 'Back-test on real data')}</span></button><button type="button" class="btn" data-save>${L('احفظ', 'Save')}</button></div>
      </form>
      <div data-out></div></div>`;
    const f = body.querySelector('[data-f]');
    const read = () => {
      const rules = [...f.querySelectorAll('.st-rule')].map((row, i) => { const r = { type: spec.entry[i].type }; row.querySelectorAll('[data-k]').forEach((el) => { r[el.dataset.k] = el.tagName === 'SELECT' ? el.value : Number(el.value); }); return r; });
      spec = { name: f.name.value, symbol: f.symbol.value, tf: f.tf.value, side: f.side.value, entry: rules, exit: { stopAtr: Number(f.stopAtr.value), rr: Number(f.rr.value), maxBars: Number(f.maxBars.value), trail: f.trail.checked } };
      return spec;
    };
    f.addEventListener('click', (e) => {
      const p = e.target.closest('[data-pre]'); const d = e.target.closest('[data-del]');
      if (p) { spec = structuredClone(PRESETS[+p.dataset.pre]); build(); }
      if (d) { read(); spec.entry.splice(+d.dataset.del, 1); build(); }
      if (e.target.closest('[data-add]')) { read(); if (spec.entry.length >= 6) return toast(L('أقصى شي 6 شروط.', 'Up to 6 rules.'), 'error'); const t = f.querySelector('[data-addsel]').value; const r = { type: t }; for (const [k, dd] of Object.entries(RULES[t].p)) r[k] = typeof dd[0] === 'string' ? dd[0] : dd[2]; spec.entry.push(r); build(); }
      if (e.target.closest('[data-save]')) { const s = cleanSpec(read()); if (s.error) return toast(L(`الإعداد مش صحيح (${s.error})`, `Invalid setup (${s.error})`), 'error'); const l = loadSaved().filter((x) => x.name !== s.name); l.unshift({ ...s, savedAt: Date.now(), dna: strategyDna(s, last?.oos || null) }); storeSaved(l); toast(L('انحفظت على هالجهاز.', 'Saved on this device.'), 'success'); }
    });
    f.addEventListener('submit', (e) => { e.preventDefault(); run(read()); });
    if (last) showResult(last);
  }
  async function run(s0) {
    const s = cleanSpec(s0); const out = body.querySelector('[data-out]');
    if (s.error) { toast(L(`الإعداد مش صحيح (${s.error})`, `Invalid setup (${s.error})`), 'error'); return; }
    out.innerHTML = '<div class="perf-loading"><span class="spinner"></span></div>';
    try {
      const r = await getHistory(s.symbol, s.tf, 1000); const sec = TIMEFRAMES.find((x) => x.id === s.tf)?.seconds || 3600;
      const c = r.candles.filter((k) => (k.time + sec) * 1000 <= Date.now());   // closed candles only
      if (c.length < 200) { out.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${L('بيانات قليلة لاختبار جدّي (أقل من 200 شمعة).', 'Too few candles for a serious test (under 200).')}</div></div>`; return; }
      const st = splitTest(s, c); const full = backtest(s, c); const cut = Math.floor(c.length * 0.7);
      last = { spec: s, mode: r.mode, source: r.source, c, ...st, full, cut, dna: strategyDna(s, st.oos) };
      showResult(last);
    } catch (x) { out.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(roomErr(x))}</div></div>`; }
  }
  async function showResult(R) {
    const out = body.querySelector('[data-out]'); if (!out) return;
    const overfit = R.is.n >= 10 && R.oos.n >= 5 && R.is.expR > 0 && R.oos.expR < R.is.expR * 0.4;
    const others = loadSaved().filter((x) => x.dna && x.dna.id !== R.dna.id).map((x) => ({ name: x.name, sim: dnaSimilarity(R.dna.vector, x.dna.vector), vec: x.dna.vector }));
    let arena = []; try { arena = (await apiRequest('GET', '/api/arena', undefined, 15000)).items.filter((x) => !x.mine).map((x) => ({ name: x.alias, sim: dnaSimilarity(R.dna.vector, x.vector), vec: x.vector, score: x.score?.score })); } catch { /* arena offline */ }
    const sims = [...others, ...arena].sort((a, b) => b.sim - a.sim).slice(0, 5);
    out.innerHTML = `
      ${R.mode === 'demo' ? `<div class="alert alert-error">${icons.alert}<div>${L('البيانات تجريبية (مزوّد البيانات مش متاح)، النتايج مش حقيقية وما بتنبعت للساحة.', 'Demo data (provider unavailable), results are not real and cannot be sent to the Arena.')}</div></div>` : ''}
      <div class="card rm-sec"><h2>${icons.flask} ${L('النتائج', 'Results')} <small class="muted">${R.c.length} ${L('شمعة مسكّرة', 'closed candles')} · ${dateStr(R.c[0].time * 1000)} → ${dateStr(R.c.at(-1).time * 1000)} · ${esc(R.source?.name || R.source || '')}</small></h2>
        <div class="st-ms">${mBox(L('داخل العينة (70% الأولى)', 'In-sample (first 70%)'), R.is)}${mBox(L('خارج العينة (30% الأخيرة)', 'Out-of-sample (last 30%)'), R.oos)}${mBox(L('كل الفترة', 'Whole period'), R.full.metrics)}</div>
        ${overfit ? `<p class="alert alert-error">${icons.alert} ${L('تحذير: الأداء خارج العينة أضعف بكتير من داخلها، غالبًا الاستراتيجية مفصّلة على الماضي (overfitting).', 'Warning: out-of-sample is much weaker than in-sample, likely over-fitted.')}</p>` : ''}
        ${R.full.equity.length ? `<div class="st-eq">${lineSvg(R.full.equity, { height: 160 })}<small class="muted">${L('منحنى الرصيد بالـ R (كل الفترة)', 'Equity curve in R (whole period)')}</small></div>` : ''}
        <p class="muted rm-note">${L('الدخول على افتتاح الشمعة اللي بعد الإشارة، التكاليف محسوبة، والشمعة اللي بتلمس الوقف والهدف بتنحسب وقف. *Sharpe على مستوى الصفقة. الماضي مش ضمان للمستقبل.', 'Entry at the next candle’s open, costs included; a candle touching stop and target counts as the stop. *Per-trade Sharpe. Past results do not guarantee the future.')}</p>
        <details><summary>${L('آخر 20 صفقة', 'Last 20 trades')}</summary><div class="rm-table-wrap"><table class="rm-table"><thead><tr><th>${L('الوقت', 'Time')}</th><th>${L('الاتجاه', 'Side')}</th><th>${L('دخول', 'Entry')}</th><th>${L('خروج', 'Exit')}</th><th>R</th><th>${L('السبب', 'Why')}</th></tr></thead><tbody>
          ${R.full.trades.slice(-20).reverse().map((t) => `<tr><td>${dateStr(t.t * 1000)}</td><td>${t.dir === 'long' || t.dir > 0 ? '⬆' : '⬇'}</td><td class="mono">${fmtNum(t.entry, 4)}</td><td class="mono">${fmtNum(t.exit, 4)}</td><td class="${t.r > 0 ? 'up' : 'down'}">${t.r}</td><td>${esc(t.why || '')}</td></tr>`).join('')}</tbody></table></div></details>
      </div>
      <div class="card rm-sec st-dna"><h2>${icons.fingerprint} Strategy DNA</h2>
        <div class="st-dna-g"><div>${dnaRadar(R.dna.vector, sims[0]?.vec || null)}</div>
        <div><p class="st-dna-id mono">${esc(R.dna.id)}</p><p><b>${L('العائلة', 'Family')}:</b> ${esc(tx(R.dna.familyName))} · ${esc(R.dna.symbol)} · ${esc(R.dna.tf)}</p>
          <p><b>${L('الجينات', 'Genes')}:</b> ${R.dna.genes.map((g) => `<code>${esc(g)}</code>`).join(' ')}</p>
          <p class="muted">${L('البصمة ثابتة: نفس القواعد = نفس الـID. المحاور من القواعد ومن سلوك الاختبار خارج العينة.', 'Deterministic: same rules = same ID. Axes come from the rules and the out-of-sample behaviour.')}</p>
          <h4>${L('أقرب استراتيجيات (تشابه البصمة)', 'Most similar (DNA similarity)')}</h4>${sims.length ? `<ul class="st-sims">${sims.map((x, i) => `<li><b>${esc(x.name)}</b> <span class="mono">${Math.round(x.sim * 100)}%</span>${x.score != null ? ` <small class="muted">score ${x.score}</small>` : ''}${i === 0 ? ` <small class="muted">(${L('مرسومة متقطّع', 'dashed on chart')})</small>` : ''}</li>`).join('')}</ul>` : `<p class="muted">${L('احفظ استراتيجيات تانية أو شوف الساحة للمقارنة.', 'Save more strategies or check the Arena to compare.')}</p>`}
          ${sims[0]?.sim > 0.97 ? `<p class="alert alert-error">${L('شبه نسخة من استراتيجية موجودة.', 'Almost a copy of an existing strategy.')}</p>` : ''}
          <div class="rm-form-a"><button type="button" class="btn btn-primary" data-submit${R.mode === 'demo' ? ' disabled' : ''}>${icons.trophy}<span>${L('ابعتها للساحة المجهولة', 'Submit to the Arena')}</span></button></div>
        </div></div></div>`;
    out.querySelector('[data-submit]')?.addEventListener('click', async (e) => {
      e.currentTarget.disabled = true;
      try { const r = await apiRequest('POST', '/api/arena', { spec: R.spec }, 90000); toast(L(`انضافت للساحة باسم ${r.entry.alias}، السيرفر اختبرها على بياناته.`, `Entered as ${r.entry.alias}, re-tested by the server on its own data.`), 'success'); }
      catch (x) { toast(x.code === 'no_data' ? L('السيرفر ما قدر يجيب بيانات لهالرمز هلّق.', 'The server could not get data for this symbol now.') : x.code === 'entry_limit' ? L('أقصى شي 5 استراتيجيات بالساحة.', 'Up to 5 entries.') : roomErr(x), 'error'); e.currentTarget.disabled = false; }
    });
  }
  async function arena() {
    body.innerHTML = '<div class="perf-loading"><span class="spinner"></span></div>';
    try {
      const d = await apiRequest('GET', '/api/arena');
      body.innerHTML = `<div class="card rm-sec"><h2>${icons.trophy} ${L('الساحة المجهولة', 'Anonymous strategy arena')}</h2>
        <p class="muted">${L('ما بيبين مين صاحب الاستراتيجية ولا قواعدها، بس الاسم المستعار، العائلة والأرقام. السيرفر بيعيد الاختبار وبيكمّل يتابع الأداء بعد الإرسال (forward).', 'No owner and no rules are shown, only an alias, the family and the numbers. The server re-tests and keeps following results after submission (forward).')}</p>
        <div class="rm-table-wrap"><table class="rm-table"><thead><tr><th>#</th><th>${L('الاسم', 'Alias')}</th><th>${L('العائلة', 'Family')}</th><th>${L('السوق', 'Market')}</th><th>OOS n / R / PF</th><th>Forward n / R</th><th>${L('التقييم', 'Score')}</th><th></th></tr></thead><tbody>
        ${d.items.map((x, i) => `<tr class="${x.mine ? 'is-mine' : ''}"><td>${x.score?.ranked ? i + 1 : '—'}</td><td><b class="mono">${esc(x.alias)}</b>${x.owner ? ` <small>(${esc(x.owner)})</small>` : ''}${x.mine ? ` <span class="rm-badge is-role">${L('إلك', 'yours')}</span>` : ''}</td><td>${esc(tx(x.familyName))}</td><td>${esc(x.symbol)} ${esc(x.tf)}</td>
          <td class="mono">${x.oos?.n ?? 0} / ${x.oos?.expR ?? 0} / ${x.oos?.pf === 99 ? '∞' : x.oos?.pf ?? 0}</td><td class="mono">${x.fwd?.n ?? 0} / ${x.fwd?.expR ?? 0}</td><td><b>${x.score?.ranked ? x.score.score : `<small class="muted">${L('أقل من 10 صفقات', '< 10 trades')}</small>`}</b></td>
          <td>${x.mine ? `<button type="button" class="btn btn-sm btn-ghost" data-rev="${x.id}" data-on="${x.owner ? 0 : 1}">${x.owner ? L('خفي اسمي', 'Hide my name') : L('اكشف اسمي', 'Reveal my name')}</button><button type="button" class="btn btn-sm btn-ghost" data-wd="${x.id}">${L('اسحب', 'Withdraw')}</button>` : ''}</td></tr>`).join('') || `<tr><td colspan="8" class="muted">${L('لسا ما في استراتيجيات بالساحة.', 'No strategies in the arena yet.')}</td></tr>`}</tbody></table></div>
        <p class="rm-rules muted">${icons.info} <span class="mono" dir="ltr">${esc(d.rules)}</span></p></div>`;
    } catch (x) { body.innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(roomErr(x))}</div></div>`; }
  }
  body.addEventListener('click', async (e) => {
    const r = e.target.closest('[data-rev]'); const w = e.target.closest('[data-wd]'); const ld = e.target.closest('[data-load]'); const dl = e.target.closest('[data-drop]');
    try {
      if (r) { await apiRequest('POST', `/api/arena/${r.dataset.rev}`, { action: 'reveal', on: r.dataset.on === '1' }); arena(); }
      if (w && window.confirm(L('تسحب الاستراتيجية من الساحة؟', 'Withdraw from the arena?'))) { await apiRequest('POST', `/api/arena/${w.dataset.wd}`, { action: 'withdraw' }); arena(); }
      if (ld) { const s = loadSaved()[+ld.dataset.load]; spec = { name: s.name, symbol: s.symbol, tf: s.tf, side: s.side, entry: s.entry, exit: s.exit }; last = null; tab('build'); }
      if (dl) { const l = loadSaved(); l.splice(+dl.dataset.drop, 1); storeSaved(l); saved(); }
    } catch (x) { toast(roomErr(x), 'error'); }
  });
  function saved() {
    const l = loadSaved();
    body.innerHTML = `<div class="card rm-sec"><h2>${icons.journal} ${L('استراتيجياتي (على هالجهاز)', 'My strategies (this device)')}</h2>${l.length ? `<div class="rm-grid">${l.map((s, i) => `<article class="card rm-card"><div class="st-mini">${dnaRadar(s.dna?.vector || [], null, 150)}</div><h3>${esc(s.name)}</h3><p class="muted mono">${esc(s.dna?.id || '')}</p><p class="muted">${esc(s.symbol)} · ${esc(s.tf)} · ${esc(tx(s.dna?.familyName) || '')}</p>
      <div class="rm-card-a"><button type="button" class="btn btn-sm btn-primary" data-load="${i}">${L('افتح', 'Open')}</button><button type="button" class="btn btn-sm btn-ghost" data-drop="${i}">${icons.trash}</button></div></article>`).join('')}</div>` : `<p class="muted">${L('لسا ما حفظت استراتيجيات.', 'No saved strategies yet.')}</p>`}</div>`;
  }
  const tab = (id) => { root.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('is-on', b.dataset.tab === id)); ({ build, arena, saved })[id](); };
  root.querySelector('.rm-tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) tab(b.dataset.tab); });
  build();
  return root;
}
