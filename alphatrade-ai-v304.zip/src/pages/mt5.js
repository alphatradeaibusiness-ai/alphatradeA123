// MetaTrader 5 bridge page (v216): pair an MT5 terminal running the AlphaTradeBridge Expert Advisor, watch its connection,
// balance and open positions, send documented orders, and read the log of every command and result.
// The broker password is never asked for: the EA runs inside the logged-in terminal, so a one-time pairing token + the account
// number + the server name are enough (server/mt5Bridge.js).
import { h, esc, fmtNum } from '../utils/dom.js';
import { getLocale } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { apiRequest } from '../services/ai/gateway.js';
import { toast } from '../components/ui.js';
import { whileMounted } from './tools/common.js';
import { pageHead, errText } from './community.js';
import { oneClickLot, setOneClickLot } from '../services/mt5Apply.js';
import '../styles/community.css';
import '../styles/mt5.css';

const T = (ar, en) => tx({ ar, en });
const when = (ms) => (ms ? new Date(ms).toLocaleString(getLocale(), { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—');
const ERR = {
  bad_account: T('رقم الحساب لازم يكون أرقام بس (3–15 رقم).', 'The account number must be digits only (3–15).'),
  bad_server: T('اكتب اسم الخادم متل ما بيبيّن بـ MT5، مثلًا MetaQuotes-Demo.', 'Enter the server name as shown in MT5, e.g. MetaQuotes-Demo.'),
  too_many_links: T('الحد 3 حسابات مربوطة. احذف واحد أول.', 'Up to 3 linked accounts. Remove one first.'),
  terminal_offline: T('المنصة مش متصلة هلّق. تأكد إنه MT5 مفتوح والـ EA شغّال.', 'The terminal is offline. Make sure MT5 is open and the EA is running.'),
  trading_disabled: T('التداول من الموقع مطفي بإعدادات الـ EA (Allow trading) أو Algo Trading مطفي بالمنصة.', 'Trading from the site is off in the EA inputs (Allow trading) or Algo Trading is off in the terminal.'),
  queue_full: T('في أوامر كتير بالانتظار.', 'Too many orders waiting.'),
  bad_side: T('اختار شراء أو بيع.', 'Choose buy or sell.'),
  bad_symbol: T('رمز السوق غير صالح.', 'Invalid symbol.'),
  bad_volume: T('الحجم لازم يكون أكبر من صفر.', 'Volume must be above zero.'),
  bad_levels: T('الوقف والهدف لازم يكونوا أرقام موجبة أو فاضيين.', 'Stop and target must be positive numbers or empty.'),
  bad_ticket: T('رقم التذكرة غير صالح.', 'Invalid ticket.'),
};
const err = (e) => ERR[e?.code] || (e?.status === 404 || e?.code === 'server_missing' ? T('خدمة الربط بتحتاج سيرفر الموقع (Render أو سيرفر خاص). على Netlify لحاله ما بتشتغل، شوف DEPLOY_WORKER_AR.md.', 'The bridge needs the site server (Render or your own). Netlify alone cannot run it, see DEPLOY_WORKER_AR.md.') : errText(e?.code || 'server_unreachable'));
const STATUS = { queued: T('بالانتظار', 'Queued'), sent: T('انبعت للمنصة', 'Sent to terminal'), done: T('تنفّذ', 'Executed'), failed: T('فشل', 'Failed'), expired: T('انتهت صلاحيته', 'Expired'), refused: T('مرفوض', 'Refused'), created: T('انعمل', 'Created'), connected: T('اتصل', 'Connected') };

export function renderMt5() {
  const el = h(`<section class="subpage tool cm mt5 page-enter">
    ${pageHead('swap', T('ربط MetaTrader 5', 'MetaTrader 5 bridge'), T('اربط منصة MT5 بالموقع عن طريق Expert Advisor: حالة الاتصال، الرصيد والصفقات المفتوحة، وإرسال أوامر موثّقة.', 'Link your MT5 terminal to the site with an Expert Advisor: connection status, balance and open positions, and documented orders.'))}
    <div class="card mt5-steps">
      <h3>${T('خطوات الربط', 'How to link')}</h3>
      <ol>
        <li>${T('اكتب رقم حساب MT5 واسم الخادم تحت، واكبس «إنشاء رمز ربط»، وانسخ الرمز.', 'Enter your MT5 account number and server below, press “Create pairing token” and copy it.')}</li>
        <li><a class="btn btn-sm" href="/mt5/AlphaTradeBridge.mq5" download>${T('تنزيل الـ Expert Advisor (.mq5)', 'Download the Expert Advisor (.mq5)')}</a> ${T('وحطّه بمجلد MQL5\\Experts واعمله Compile بـ MetaEditor (F7).', 'and put it in MQL5\\Experts, then compile it in MetaEditor (F7).')}</li>
        <li>${T('بـ MT5: Tools ← Options ← Expert Advisors ← علّم «Allow WebRequest for listed URL» وضيف رابط الموقع:', 'In MT5: Tools → Options → Expert Advisors → tick “Allow WebRequest for listed URL” and add the site URL:')} <code dir="ltr" data-origin></code></li>
        <li>${T('حط الـ EA على أي شارت، وعبّي: رابط الموقع، رقم الحساب، اسم الخادم، ورمز الربط. لتنفيذ الأوامر فعّل «Allow trading» و Algo Trading.', 'Attach the EA to any chart and fill in: site URL, account number, server name and pairing token. To execute orders, enable “Allow trading” and Algo Trading.')}</li>
      </ol>
      <p class="mt5-note">${T('ليش ما في كلمة سر؟ الـ EA بيشتغل جوّا منصتك وهي أصلًا مسجّلة دخول عند الوسيط، فكلمة السر مش لازمة أبدًا. وإرسالها لأي موقع بيعرّض حسابك للخطر. بدالها بنستعمل رمز ربط بينعرض مرة وحدة، ومربوط برقم حسابك واسم الخادم.', 'Why no password? The EA runs inside your terminal, which is already logged in to your broker, so the password is never needed, and sending it to any website would put your account at risk. A one-time pairing token bound to your account number and server is used instead.')}</p>
    </div>
    <form class="card mt5-link" data-link>
      <h3>${T('حساب جديد', 'New account')}</h3>
      <div class="mt5-grid">
        <label>${T('رقم حساب MT5', 'MT5 account number')}<input class="input" name="account" inputmode="numeric" autocomplete="off" required maxlength="15" dir="ltr" placeholder="5012345"/></label>
        <label>${T('اسم الخادم', 'Server name')}<input class="input" name="server" autocomplete="off" required maxlength="64" dir="ltr" placeholder="MetaQuotes-Demo"/></label>
      </div>
      <button class="btn" type="submit">${T('إنشاء رمز ربط', 'Create pairing token')}</button>
      <div class="mt5-token" data-token hidden></div>
    </form>
    <div class="card mt5-oneclick"><h3>${T('زر «تطبيق على MT5» بالتوصيات', '“Apply on MT5” button on recommendations')}</h3>
      <p class="muted">${T('كبسة وحدة على التوصية النشطة بقناة التوصيات بتبعتها للمنصة: دخول ماركت مع وقف وأهداف التوصية. من 0.03 لوت وطالع بتنقسم 3 أوامر، ثلث لكل هدف.', 'One click on an active recommendation in the channel sends it to MT5: market entry with the recommendation’s stop and targets. From 0.03 lots it is split into 3 orders, a third per target.')}</p>
      <label class="mt5-lot">${T('الحجم لكل توصية (لوت)', 'Volume per recommendation (lots)')}<input class="input" type="number" min="0.01" max="100" step="0.01" dir="ltr" data-lot/></label></div>
    <div data-links class="mt5-links"></div>
  </section>`);
  const $ = (s) => el.querySelector(s);
  $('[data-origin]').textContent = location.origin;
  const lotIn = $('[data-lot]'); lotIn.value = oneClickLot();
  lotIn.addEventListener('change', () => { lotIn.value = setOneClickLot(lotIn.value); toast(T('انحفظ الحجم', 'Volume saved'), 'success', 1500); });
  let data = { links: [] }; let errShown = '';

  const posRows = (t) => (t?.positions?.length ? `<table class="kv-table mt5-pos"><thead><tr><th>${T('تذكرة', 'Ticket')}</th><th>${T('السوق', 'Symbol')}</th><th>${T('النوع', 'Type')}</th><th>${T('الحجم', 'Volume')}</th><th>${T('الربح', 'Profit')}</th></tr></thead><tbody>${t.positions.map((p) => `<tr><td class="mono">${esc(p.ticket)}</td><td class="mono">${esc(p.symbol)}</td><td class="${p.type === 'sell' ? 'down' : 'up'}">${p.type === 'sell' ? T('بيع', 'Sell') : T('شراء', 'Buy')}</td><td class="mono">${fmtNum(p.volume, 2)}</td><td class="mono ${p.profit < 0 ? 'down' : 'up'}">${fmtNum(p.profit, 2)}</td></tr>`).join('')}</tbody></table>` : `<p class="muted">${T('ما في صفقات مفتوحة.', 'No open positions.')}</p>`);
  const logRows = (L) => (L.log.length ? `<table class="kv-table mt5-log"><thead><tr><th>${T('الوقت', 'Time')}</th><th>${T('الأمر', 'Command')}</th><th>${T('الحالة', 'Status')}</th><th>${T('تفاصيل', 'Details')}</th></tr></thead><tbody>${L.log.slice(0, 20).map((x) => `<tr><td class="mono">${esc(when(x.at))}</td><td class="mono">${esc([x.action, x.symbol, x.volume ? fmtNum(x.volume, 2) : ''].filter(Boolean).join(' '))}</td><td><span class="mt5-st is-${esc(x.status)}">${esc(STATUS[x.status] || x.status)}</span></td><td class="mono mt5-msg">${esc([x.ticket ? '#' + x.ticket : '', x.price ? '@' + x.price : '', x.message || ''].filter(Boolean).join(' · '))}</td></tr>`).join('')}</tbody></table>` : `<p class="muted">${T('لسا ما في أحداث.', 'No events yet.')}</p>`);

  const card = (L) => {
    const t = L.terminal; const on = L.connected;
    return `<article class="card mt5-acc" data-id="${esc(L.id)}">
      <header><span class="mt5-dot ${on ? 'is-on' : ''}" aria-hidden="true"></span><b dir="ltr">${esc(L.account)} @ ${esc(L.server)}</b>
        <span class="mt5-state">${on ? T('متصل', 'Connected') : L.lastSeen ? T('غير متصل', 'Offline') : T('بانتظار أول اتصال من الـ EA', 'Waiting for the EA')}</span>
        <button type="button" class="btn btn-sm btn-ghost" data-del>${T('حذف', 'Remove')}</button></header>
      <dl class="mt5-kv"><div><dt>${T('آخر اتصال', 'Last contact')}</dt><dd>${esc(when(L.lastSeen))}</dd></div>
        <div><dt>${T('الوسيط', 'Broker')}</dt><dd>${esc(t?.company || '—')}</dd></div>
        <div><dt>${T('الرصيد', 'Balance')}</dt><dd class="mono">${t ? `${fmtNum(t.balance, 2)} ${esc(t.currency)}` : '—'}</dd></div>
        <div><dt>${T('حقوق الملكية', 'Equity')}</dt><dd class="mono">${t ? `${fmtNum(t.equity, 2)} ${esc(t.currency)}` : '—'}</dd></div>
        <div><dt>${T('التداول من الموقع', 'Trading from site')}</dt><dd>${t?.allowTrading ? `<b class="up">${T('مفعّل', 'On')}</b> · ${T('أقصى حجم', 'max')} ${fmtNum(t.maxLot, 2)}` : `<b class="down">${T('مطفي', 'Off')}</b>`}</dd></div></dl>
      <details class="mt5-sec" open><summary>${T('الصفقات المفتوحة', 'Open positions')} (${t?.positions?.length || 0})</summary>${posRows(t)}</details>
      <details class="mt5-sec"><summary>${T('إرسال أمر', 'Send an order')}</summary>
        <form class="mt5-order" data-order>
          <div class="mt5-grid">
            <label>${T('السوق', 'Symbol')}<input class="input" name="symbol" required maxlength="24" dir="ltr" placeholder="EURUSD"/></label>
            <label>${T('الاتجاه', 'Side')}<select class="input" name="side"><option value="buy">${T('شراء', 'Buy')}</option><option value="sell">${T('بيع', 'Sell')}</option></select></label>
            <label>${T('الحجم (لوت)', 'Volume (lots)')}<input class="input" name="volume" type="number" step="0.01" min="0.01" required dir="ltr" value="0.01"/></label>
            <label>${T('وقف الخسارة (سعر)', 'Stop loss (price)')}<input class="input" name="sl" type="number" step="any" min="0" dir="ltr"/></label>
            <label>${T('الهدف (سعر)', 'Take profit (price)')}<input class="input" name="tp" type="number" step="any" min="0" dir="ltr"/></label>
          </div>
          <label class="mt5-confirm"><input type="checkbox" name="confirm" required/> ${T('بأكّد إنه هاد أمر حقيقي رح يتنفّذ على حسابي.', 'I confirm this is a real order that will be executed on my account.')}</label>
          <button class="btn" type="submit" ${on && t?.allowTrading ? '' : 'disabled'}>${T('إرسال للمنصة', 'Send to terminal')}</button>
          ${on && t?.allowTrading ? '' : `<p class="muted">${on ? ERR.trading_disabled : ERR.terminal_offline}</p>`}
        </form></details>
      <details class="mt5-sec"><summary>${T('سجل الأوامر والنتائج', 'Command & result log')}</summary>${logRows(L)}</details>
    </article>`;
  };
  const paint = () => {
    const open = new Set([...el.querySelectorAll('.mt5-acc details[open]')].map((d) => `${d.closest('[data-id]').dataset.id}|${[...d.parentNode.children].indexOf(d)}`));
    const typing = el.querySelector('.mt5-order :focus');
    if (typing) return;   // never rebuild while the customer is filling an order
    $('[data-links]').innerHTML = data.links.length ? data.links.map(card).join('') : `<p class="muted mt5-empty">${T('ما في حسابات مربوطة لسا.', 'No linked accounts yet.')}</p>`;
    el.querySelectorAll('.mt5-acc details').forEach((d) => { const k = `${d.closest('[data-id]').dataset.id}|${[...d.parentNode.children].indexOf(d)}`; if (open.size) d.open = open.has(k); });
  };
  const load = async () => {
    try { data = await apiRequest('GET', '/api/mt5', undefined, 8000); errShown = ''; paint(); }
    catch (e) { const m = err(e); if (m !== errShown) { errShown = m; $('[data-links]').innerHTML = `<p class="card mt5-err">${esc(m)}</p>`; } }
  };

  $('[data-link]').addEventListener('submit', async (ev) => {
    ev.preventDefault(); const f = new FormData(ev.currentTarget); const btn = ev.currentTarget.querySelector('button');
    btn.disabled = true;
    try {
      const r = await apiRequest('POST', '/api/mt5/link', { account: String(f.get('account')).trim(), server: String(f.get('server')).trim() }, 8000);
      const box = $('[data-token]'); box.hidden = false;
      box.innerHTML = `<p><b>${T('رمز الربط (بينعرض مرة وحدة بس):', 'Pairing token (shown only once):')}</b></p><code dir="ltr" class="mt5-code">${esc(r.token)}</code>
        <button type="button" class="btn btn-sm" data-copy>${T('نسخ', 'Copy')}</button><p class="muted">${T('حطه بخانة InpToken بالـ EA. لا تشاركه مع حدا.', 'Paste it in the EA’s InpToken input. Never share it.')}</p>`;
      box.querySelector('[data-copy]').addEventListener('click', () => navigator.clipboard?.writeText(r.token).then(() => toast(T('انتسخ', 'Copied'), 'success', 2000)).catch(() => {}));
      ev.currentTarget?.reset?.(); await load();
    } catch (e) { toast(err(e), 'error', 5000); }
    finally { btn.disabled = false; }
  });
  $('[data-links]').addEventListener('click', async (ev) => {
    const del = ev.target.closest('[data-del]'); if (!del) return;
    const id = del.closest('[data-id]').dataset.id;
    if (del.dataset.armed !== '1') { del.dataset.armed = '1'; del.textContent = T('متأكد؟ اكبس مرة تانية', 'Sure? Click again'); setTimeout(() => { if (del.isConnected) { del.dataset.armed = ''; del.textContent = T('حذف', 'Remove'); } }, 4000); return; }
    try { await apiRequest('DELETE', `/api/mt5/link/${id}`, undefined, 8000); await load(); } catch (e) { toast(err(e), 'error', 5000); }
  });
  $('[data-links]').addEventListener('submit', async (ev) => {
    const form = ev.target.closest('[data-order]'); if (!form) return;
    ev.preventDefault(); const id = form.closest('[data-id]').dataset.id; const f = new FormData(form); const btn = form.querySelector('button');
    btn.disabled = true;
    try {
      await apiRequest('POST', `/api/mt5/link/${id}/order`, { side: f.get('side'), symbol: String(f.get('symbol')).trim().toUpperCase(), volume: Number(f.get('volume')), sl: f.get('sl') ? Number(f.get('sl')) : 0, tp: f.get('tp') ? Number(f.get('tp')) : 0 }, 8000);
      toast(T('انبعت الأمر. النتيجة بتظهر بالسجل خلال ثواني.', 'Order sent. The result appears in the log within seconds.'), 'success', 4000);
      form.reset(); document.activeElement?.blur?.(); await load();
    } catch (e) { toast(err(e), 'error', 6000); }
    finally { btn.disabled = false; }
  });
  load();
  whileMounted(el, load, 5000);
  return el;
}
