// Smart Money Concepts (SMC) — pure calculations on OHLC candles.
//
//  • Swings: fractal pivots (a high/low that is the extreme of `len` bars on each side).
//  • Structure: a close beyond the last swing high/low. In the trend's direction it is a
//    BOS (break of structure); against the trend it is a CHoCH (change of character).
//  • Order block (OB): the last opposite-colour candle before the impulse that broke structure.
//  • Fair value gap (FVG): a three-candle imbalance (candle 1 and candle 3 do not overlap).
//  • Liquidity: unbroken swing highs (buy-side, BSL) above price and swing lows (sell-side, SSL) below.
//  • Setup: trade in the direction of the last break, entering at the OB's near edge,
//    stop beyond the OB, targets at the next liquidity pools (R-multiples when none exist).

/** Fractal swing points. Returns [{ type:'high'|'low', index, time, price }] in time order. */
export function findSwings(candles, len = 3) {
  const out = [];
  for (let i = len; i < candles.length - len; i++) {
    let isHigh = true;
    let isLow = true;
    for (let k = 1; k <= len; k++) {
      if (!(candles[i].high > candles[i - k].high && candles[i].high >= candles[i + k].high)) isHigh = false;
      if (!(candles[i].low < candles[i - k].low && candles[i].low <= candles[i + k].low)) isLow = false;
      if (!isHigh && !isLow) break;
    }
    if (isHigh) out.push({ type: 'high', index: i, time: candles[i].time, price: candles[i].high });
    if (isLow) out.push({ type: 'low', index: i, time: candles[i].time, price: candles[i].low });
  }
  return out;
}

/**
 * Walk the candles and record structure breaks.
 * A swing only counts once it is confirmed (`len` bars after it), as a live trader would see it.
 */
export function findStructure(candles, swings, len = 3) {
  const events = [];
  let trend = null;
  let lastHigh = null;
  let lastLow = null;
  let si = 0;
  for (let j = 0; j < candles.length; j++) {
    while (si < swings.length && swings[si].index + len <= j) {
      const s = swings[si++];
      if (s.type === 'high') lastHigh = { ...s, broken: false };
      else lastLow = { ...s, broken: false };
    }
    const c = candles[j];
    if (lastHigh && !lastHigh.broken && c.close > lastHigh.price) {
      lastHigh.broken = true;
      events.push({ kind: trend === 'bear' ? 'CHoCH' : 'BOS', dir: 'bull', level: lastHigh.price, swingIndex: lastHigh.index, swingTime: lastHigh.time, index: j, time: c.time });
      trend = 'bull';
    }
    if (lastLow && !lastLow.broken && c.close < lastLow.price) {
      lastLow.broken = true;
      events.push({ kind: trend === 'bull' ? 'CHoCH' : 'BOS', dir: 'bear', level: lastLow.price, swingIndex: lastLow.index, swingTime: lastLow.time, index: j, time: c.time });
      trend = 'bear';
    }
  }
  return { events, trend };
}

/** Order block that caused a structure break. */
export function orderBlockFor(candles, ev) {
  const from = ev.swingIndex;
  const to = ev.index;
  if (to - from < 1) return null;
  // Extreme of the move that produced the break.
  let k = from;
  for (let i = from; i <= to; i++) {
    if (ev.dir === 'bull' ? candles[i].low < candles[k].low : candles[i].high > candles[k].high) k = i;
  }
  // Last opposite-colour candle at or before that extreme (within 10 bars).
  let ob = null;
  for (let i = k; i >= Math.max(0, k - 10); i--) {
    const c = candles[i];
    if (ev.dir === 'bull' ? c.close < c.open : c.close > c.open) { ob = i; break; }
  }
  if (ob == null) ob = k;
  const c = candles[ob];
  return { dir: ev.dir, index: ob, time: c.time, top: c.high, bottom: c.low, breakIndex: ev.index, breakTime: ev.time };
}

/** An OB is invalid once a candle closes through its far edge after the break. */
export function obInvalidated(candles, ob) {
  for (let i = ob.breakIndex + 1; i < candles.length; i++) {
    if (ob.dir === 'bull' ? candles[i].close < ob.bottom : candles[i].close > ob.top) return true;
  }
  return false;
}

/** Fair value gaps not yet filled by later price. Newest last. */
export function findFVGs(candles, maxAge = 150) {
  const out = [];
  const start = Math.max(2, candles.length - maxAge);
  for (let i = start; i < candles.length; i++) {
    const a = candles[i - 2];
    const c = candles[i];
    let gap = null;
    if (c.low > a.high) gap = { dir: 'bull', top: c.low, bottom: a.high };
    else if (c.high < a.low) gap = { dir: 'bear', top: a.low, bottom: c.high };
    if (!gap) continue;
    let filled = false;
    for (let j = i + 1; j < candles.length; j++) {
      if (gap.dir === 'bull' ? candles[j].low <= gap.bottom : candles[j].high >= gap.top) { filled = true; break; }
    }
    if (!filled) out.push({ ...gap, index: i - 1, time: candles[i - 1].time });
  }
  return out;
}

/** Unbroken swing levels: highs above / lows below the current close. */
export function findLiquidity(candles, swings) {
  const last = candles[candles.length - 1];
  const bsl = [];
  const ssl = [];
  for (const s of swings) {
    let taken = false;
    for (let j = s.index + 1; j < candles.length; j++) {
      if (s.type === 'high' ? candles[j].high > s.price : candles[j].low < s.price) { taken = true; break; }
    }
    if (taken) continue;
    if (s.type === 'high' && s.price > last.close) bsl.push(s);
    if (s.type === 'low' && s.price < last.close) ssl.push(s);
  }
  bsl.sort((x, y) => x.price - y.price);
  ssl.sort((x, y) => y.price - x.price);
  return { bsl, ssl };
}

/** Entry / stop / targets from an order block and the liquidity around it. */
export function buildSetup(ob, liquidity, swings) {
  const long = ob.dir === 'bull';
  const h = ob.top - ob.bottom;
  const buffer = Math.max(h * 0.1, Math.abs(ob.top) * 0.0002);
  const entry = long ? ob.top : ob.bottom;
  const stop = long ? ob.bottom - buffer : ob.top + buffer;
  const risk = Math.abs(entry - stop);
  if (!(risk > 0)) return null;
  const sign = long ? 1 : -1;
  // Liquidity pools beyond the entry in the trade direction, at least 1R away; nearest first.
  const pools = (long ? [...liquidity.bsl, ...swings.filter((s) => s.type === 'high')] : [...liquidity.ssl, ...swings.filter((s) => s.type === 'low')])
    .map((s) => s.price)
    // Pools too far away (over 5R) are not realistic targets for one trade and would squash the chart.
    .filter((p) => (p - entry) * sign >= risk && (p - entry) * sign <= risk * 5)
    .sort((a, b) => (a - b) * sign);
  const uniq = [];
  for (const p of pools) if (!uniq.length || Math.abs(p - uniq[uniq.length - 1]) > risk * 0.25) uniq.push(p);
  const targets = [];
  const fallbacks = [2, 3, 4.5]; // R-multiples when there is no liquidity pool to aim for
  for (let k = 0; k < 3; k++) {
    const prev = k ? targets[k - 1] : entry;
    const pool = uniq.find((p) => (p - prev) * sign > risk * 0.25);
    const fb = long ? Math.max(entry + fallbacks[k] * risk, prev + risk) : Math.min(entry - fallbacks[k] * risk, prev - risk);
    targets.push(pool ?? fb);
  }
  return {
    strategy: 'smc', direction: long ? 'long' : 'short', entry, stop, targets, distance: risk,
    rr: targets.map((tp) => Math.abs(tp - entry) / risk), ob, createdTime: ob.breakTime,
  };
}

/**
 * Status of a setup given the candles after it formed.
 * pending → (price trades into the entry) → active → stopped | tp3; or invalid if
 * price closes through the OB before the entry is filled.
 */
export function evaluateSetup(setup, candles) {
  const long = setup.direction === 'long';
  let triggered = false;
  let fav = setup.entry;
  let status = 'pending';
  let triggeredTime = null;
  for (const c of candles) {
    if (c.time <= setup.createdTime) continue;
    if (!triggered) {
      if (long ? c.low <= setup.entry : c.high >= setup.entry) { triggered = true; triggeredTime = c.time; status = 'active'; }
      else continue;
    }
    if (long ? c.low <= setup.stop : c.high >= setup.stop) { status = 'stopped'; break; }
    fav = long ? Math.max(fav, c.high) : Math.min(fav, c.low);
    const hits = setup.targets.filter((tp) => (long ? fav >= tp : fav <= tp)).length;
    if (hits >= 3) { status = 'tp3'; break; }
  }
  const hits = triggered ? setup.targets.filter((tp) => (long ? fav >= tp : fav <= tp)).length : 0;
  return { status, hits: status === 'tp3' ? 3 : hits, triggeredTime };
}

/** Full SMC read of the chart. */
export function smcAnalysis(candles, { len = 3 } = {}) {
  if (!candles || candles.length < len * 4 + 10) return null;
  const swings = findSwings(candles, len);
  const { events, trend } = findStructure(candles, swings, len);
  const liquidity = findLiquidity(candles, swings);
  const fvgs = findFVGs(candles);
  // Latest valid order block in the direction of the last break.
  let setup = null;
  let ob = null;
  for (let i = events.length - 1; i >= Math.max(0, events.length - 6); i--) {
    if (events[i].dir !== trend) continue;
    const cand = orderBlockFor(candles, events[i]);
    if (cand && !obInvalidated(candles, cand)) { ob = cand; break; }
  }
  if (ob) setup = buildSetup(ob, liquidity, swings);
  const fvg = [...fvgs].reverse().find((g) => g.dir === trend) || null;
  return { trend, swings, events: events.slice(-2), liquidity, fvg, ob, setup };
}

/**
 * Full SMC read of the whole loaded history (e.g. 500 candles), shown on the chart whether or
 * not there is a trade:
 *  • swings labelled HH / HL / LH / LL (market structure);
 *  • the last structure breaks (BOS / CHoCH);
 *  • order blocks still valid (not closed through), newest first, with "mitigated" when price
 *    has already traded back into them;
 *  • fair value gaps still open;
 *  • liquidity pools above (BSL) and below (SSL) price;
 *  • the current dealing range with its equilibrium (50%), premium and discount halves.
 */
export function smcFull(candles, { len = 3, maxEvents = 6, maxObs = 4, maxFvgs = 4 } = {}) {
  const base = smcAnalysis(candles, { len });
  if (!base) return null;
  const { swings } = base;
  // HH / HL / LH / LL labels
  let lastH = null;
  let lastL = null;
  const labelled = swings.map((s) => {
    let label;
    if (s.type === 'high') { label = lastH == null ? 'H' : s.price > lastH ? 'HH' : 'LH'; lastH = s.price; }
    else { label = lastL == null ? 'L' : s.price > lastL ? 'HL' : 'LL'; lastL = s.price; }
    return { ...s, label };
  });
  const { events } = findStructure(candles, swings, len);
  const recentEvents = events.slice(-maxEvents);
  // Valid order blocks from recent breaks (both directions), newest first.
  const obs = [];
  for (let i = events.length - 1; i >= 0 && obs.length < maxObs; i--) {
    const ob = orderBlockFor(candles, events[i]);
    if (!ob || obInvalidated(candles, ob)) continue;
    if (obs.some((o) => o.index === ob.index)) continue;
    let mitigated = false;
    for (let j = ob.breakIndex + 1; j < candles.length; j++) {
      if (ob.dir === 'bull' ? candles[j].low <= ob.top : candles[j].high >= ob.bottom) { mitigated = true; break; }
    }
    obs.push({ ...ob, kind: events[i].kind, mitigated, age: candles.length - 1 - ob.index });
  }
  const fvgs = findFVGs(candles, Math.min(candles.length, 300)).slice(-maxFvgs);
  // Dealing range: the latest confirmed swing high and swing low.
  const hi = [...swings].reverse().find((s) => s.type === 'high');
  const lo = [...swings].reverse().find((s) => s.type === 'low');
  const range = hi && lo && hi.price > lo.price ? {
    high: hi.price, low: lo.price, eq: (hi.price + lo.price) / 2, fromTime: Math.min(hi.time, lo.time),
    zone: candles.at(-1).close > (hi.price + lo.price) / 2 ? 'premium' : 'discount',
  } : null;
  const last = recentEvents.at(-1) || null;
  return {
    ...base, labelled, recentEvents, obs, fvgs, range, lastBreak: last,
    bsl: base.liquidity.bsl.slice(0, 2), ssl: base.liquidity.ssl.slice(0, 2), bars: candles.length,
  };
}

/** Trading sessions in UTC hours (approximate, no daylight-saving shift): [name, startHour, endHour]. */
export const SESSIONS = [['ASIA', 0, 8], ['LONDON', 7, 16], ['NY', 13, 22]];

/**
 * Session liquidity: high and low of the most recent COMPLETED Asia / London / New York session in `candles`
 * (intraday timeframes only, `tfSec` ≤ 1 hour). Returns [{ name, high, highTime, low, lowTime, start, end }].
 * Each level is a real candle extreme with its own time, so it stays anchored on zoom / pan.
 */
export function sessionLevels(candles, tfSec) {
  if (!candles?.length || !(tfSec > 0) || tfSec > 3600) return [];
  const lastT = candles.at(-1).time;
  const out = [];
  for (const [name, h0, h1] of SESSIONS) {
    // walk back day by day to the latest window that ended before the last candle
    const day0 = Math.floor(lastT / 86400) * 86400;
    for (let d = 0; d < 4; d++) {
      const start = day0 - d * 86400 + h0 * 3600, end = day0 - d * 86400 + h1 * 3600;
      if (end > lastT) continue;
      let hi = null, lo = null;
      for (const c of candles) {
        if (c.time < start || c.time >= end) continue;
        if (!hi || c.high > hi.high) hi = c;
        if (!lo || c.low < lo.low) lo = c;
      }
      if (hi && lo) out.push({ name, high: hi.high, highTime: hi.time, low: lo.low, lowTime: lo.time, start, end });
      break;
    }
  }
  return out;
}
