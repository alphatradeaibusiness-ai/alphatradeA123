// Global UI helpers: toasts and modal dialogs.
import { h, esc } from '../utils/dom.js';
import { icons } from './icons.js';
import { t } from '../i18n/index.js';

let toastHost;
export function toast(message, type = 'info', ms = 4200) {
  if (!toastHost) { toastHost = h('<div class="toasts" role="status" aria-live="polite"></div>'); document.body.append(toastHost); }
  const icon = type === 'error' ? icons.alert : type === 'success' ? icons.check : icons.info;
  const el = h(`<div class="alert alert-${type} toast">${icon}<div>${esc(message)}</div></div>`);
  toastHost.append(el);
  setTimeout(() => el.remove(), ms);
}

/** Open a modal. `render(body, close)` fills the body. Returns close(). */
export function openModal(title, render, { wide = false } = {}) {
  const prev = document.activeElement;
  const back = h(`<div class="modal-backdrop"><div class="modal card${wide ? ' modal-wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
    <div class="modal-head"><h2 class="card-title">${esc(title)}</h2><button class="btn btn-icon btn-ghost" data-close aria-label="${esc(t('common.close'))}">${icons.close}</button></div>
    <div class="modal-body"></div></div></div>`);
  const close = () => { back.remove(); document.removeEventListener('keydown', onKey); prev?.focus?.(); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  back.addEventListener('mousedown', (e) => { if (e.target === back) close(); });
  back.querySelector('[data-close]').addEventListener('click', close);
  document.addEventListener('keydown', onKey);
  document.body.append(back);
  render(back.querySelector('.modal-body'), close);
  back.querySelector('.modal button, .modal input, .modal select')?.focus();
  return close;
}
