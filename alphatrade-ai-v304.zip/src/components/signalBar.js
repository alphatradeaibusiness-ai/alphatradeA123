// Thin bar under the header: live progress of the signals channel (updated every 3 s).
import { h, esc, fmtNum } from '../utils/dom.js';
import { t } from '../i18n/index.js';
import { onSignals, signalState, MIN_ACCURACY } from '../services/signals.js';
import { toast } from './ui.js';
import { showSignalCard } from './signalCard.js';

export function createSignalBar() {
  const el = h(`<a class="signal-bar" href="#/app/signals" aria-live="polite">
    <span class="sb-live"><i></i>${esc(t('sig.bar'))}</span>
    <span class="sb-track"><span class="sb-run" data-run></span></span>
  </a>`);
  const run = el.querySelector('[data-run]');
  let lastHtml = ''; let lastW = 0;

  const ptsOf = (s) => (s.price != null ? (s.price - s.entry) * (s.direction === 'long' ? 1 : -1) : 0);
  const ptsText = (s) => { const v = ptsOf(s); return `${v >= 0 ? '+' : '−'}${fmtNum(Math.abs(v), s.precision)}`; };
  // The live distance is patched in place every second (see render): rebuilding the strip for it made the scrolling text jump.
  const item = (s) => {
    const p = (v) => fmtNum(v, s.precision);
    const long = s.direction === 'long';
    const dots = [0, 1, 2].map((k) => `<i class="${s.hits > k ? 'hit' : ''}">TP${k + 1}</i>`).join('');
    const st = s.status === 'active' ? '' : `<b class="sb-st sb-${s.status}">${esc(t(`sig.status.${s.status}`))}</b>`;
    return `<span class="sb-item ${s.status}"><b class="${long ? 'up' : 'down'}">${esc(t(long ? 'common.long' : 'common.short'))}</b>
      <b class="mono">${esc(s.symbol)}</b><span class="muted">${esc(t(`perf.tfShort.${s.tf}`))}</span>
      <span class="mono">${esc(t('plan.entry'))} ${p(s.entry)}</span><span class="sb-dots">${dots}</span>${st}
      ${s.status === 'active' ? `<span class="mono sb-pts" data-pts="${esc(String(s.id))}"></span>` : ''}
      ${s.accuracy>0?`<span class="sb-acc">${fmtNum(s.accuracy, 0)}%</span>`:''}</span>`;
  };

  const render = (st) => {
    const recent = st.signals.filter((s) => ['active','pending'].includes(s.status) || Date.now() - (s.closedAt || s.createdAt) < 24 * 3600e3).slice(0, 8);
    let html;
    if (recent.length) {
      const one = recent.map(item).join('<span class="sb-sep">•</span>');
      html = `<span class="sb-seq">${one}<span class="sb-sep">•</span></span><span class="sb-seq" aria-hidden="true">${one}<span class="sb-sep">•</span></span>`;
      el.classList.add('has-signals');
    } else {
      html = `<span class="sb-idle">${esc(st.live === false ? t('sig.needLive') : st.scanning ? t('sig.scanning') : t('sig.none', { min: MIN_ACCURACY }))}</span>`;
      el.classList.remove('has-signals');
    }
    if (html !== lastHtml) {
      run.innerHTML = html;
      lastHtml = html;
      // Speed: ~60 px per second whatever the length. Changing the duration restarts the animation, so only when the width really changed.
      const w = run.firstElementChild?.scrollWidth || 0;
      if (!lastW || Math.abs(w - lastW) / lastW > 0.1) { lastW = w; run.style.setProperty('--sb-dur', `${Math.max(12, w / 60)}s`); }
    }
    for (const s of recent) {
      if (s.status !== 'active') continue;
      const txt = ptsText(s); const up = ptsOf(s) >= 0;
      run.querySelectorAll(`[data-pts="${CSS.escape(String(s.id))}"]`).forEach((n) => {
        if (n.textContent !== txt) n.textContent = txt;
        n.classList.toggle('up', up); n.classList.toggle('down', !up);
      });
    }
  };
  render(signalState());
  const off = onSignals(render);
  const onToast = (e) => { if (el.isConnected && !e.detail.cardShown) toast(`${e.detail.title}, ${e.detail.body.split('\n')[0]}`, 'info', 5000); };
  const onCard = (e) => { if (el.isConnected) showSignalCard(e.detail.signal); };
  window.addEventListener('alpha-signal', onToast);
  window.addEventListener('alpha-signal-card', onCard);
  return { el, destroy() { off(); window.removeEventListener('alpha-signal', onToast); window.removeEventListener('alpha-signal-card', onCard); } };
}
