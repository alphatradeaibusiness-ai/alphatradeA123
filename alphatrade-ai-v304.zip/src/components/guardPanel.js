// Risk guard status (today's result in R, open signals, losing streak, signals held back) — one renderer for the
// signals channel and the Risk Control Center, so both always show the same thing.
import { esc, fmtNum } from '../utils/dom.js';
import { t } from '../i18n/index.js';
import { icons } from './icons.js';
import { store } from '../state/store.js';
import { guardSummary } from '../services/signals.js';

export function guardPanelHtml(st, { settingsLink = false } = {}) {
  const cfg = store.get('settings').risk || {};
  const gs = guardSummary();
  const blocked = cfg.enabled !== false && ((cfg.dailyLossR > 0 && gs.dailyR <= -cfg.dailyLossR) || (cfg.streakPause > 0 && gs.streak >= cfg.streakPause));
  const why = (x) => t(`guard.blocked.${x.key}`, x.params || {});
  return `<h2 class="card-title">${icons.shield}<span>${esc(t('guard.title'))}</span><span class="badge ${blocked ? 'badge-error' : cfg.enabled === false ? 'badge-muted' : 'badge-live'}">${esc(blocked ? t('guard.blocked.short') : cfg.enabled === false ? '—' : t('guard.ok'))}</span></h2>
    <div class="sig-track-row"><div><b class="mono ${gs.dailyR >= 0 ? 'up' : 'down'}">${gs.dailyR >= 0 ? '+' : '−'}${fmtNum(Math.abs(gs.dailyR), 1)}R</b><span>${esc(t('guard.today'))}</span></div><div><b class="mono">${gs.active}${cfg.maxActive > 0 ? `/${cfg.maxActive}` : ''}</b><span>${esc(t('guard.maxActive'))}</span></div><div><b class="mono">${gs.streak}</b><span>${esc(t('guard.streakShort'))}</span></div></div>
    ${st?.skipped?.length ? `<ul class="sig-skipped">${st.skipped.slice(0, 4).map((x) => `<li><b class="mono">${esc(x.symbol)}</b> ${esc(why(x))}</li>`).join('')}</ul>` : ''}
    ${settingsLink ? `<p class="muted tool-note">${esc(t('rc.limits', { d: cfg.dailyLossR || '—', a: cfg.maxActive || '∞', s: cfg.streakPause || '—', n: cfg.newsMinutes || '—', c: cfg.maxCorrelated || '—' }))}</p>` : ''}`;
}
