// The small animated recommendation card: logo, "AlphaTrading", pair, entry, stop and three targets.
// Appears as a pop-up when a new signal of the client's strategy arrives, and can be placed anywhere (signals page).
import { esc, fmtNum } from '../utils/dom.js';
import { t, getLang } from '../i18n/index.js';
import { logoMark, assetIcon } from './icons.js';
import { stratName } from '../services/stratName.js';
import { CHANNEL_STRATEGIES } from '../services/channel.js';
import { getInstrument } from '../config/instruments.js';
import { pipPoints } from '../services/pips.js';
import { onSignals, signalState } from '../services/signals.js';
import { tweenNumber, restartClass } from '../utils/motion.js';
import { pairName } from '../services/tradeMessages.js';

export const strategyLabel = (k) => (k === 'zone' ? t('ch.combo') : stratName(k));

export function signalCardHtml(s, { animated = true, brand = null } = {}) {
  const p = (v) => fmtNum(v, s.precision);
  const long = s.direction === 'long';
  const sign = long ? 1 : -1;
  // One horizontal ladder, always left = stop, right = TP3 (a profitable move always runs to the right, in every language).
  const span = (s.targets[2] - s.stop) * sign || 1;
  const at = (v) => Math.max(0, Math.min(100, (((v - s.stop) * sign) / span) * 100));
  const en=getLang() !== 'ar';
  const marks = [['sl', en?'Stop loss':'وقف الخسارة', s.stop, null], ['en', t('plan.entry'), s.entry, null], ['tp0', en?'Target 1':'الهدف ١', s.targets[0], 0], ['tp1', en?'Target 2':'الهدف ٢', s.targets[1], 1], ['tp2', en?'Target 3':'الهدف ٣', s.targets[2], 2]];
  return `<article class="sigcard ${long ? 'is-long' : 'is-short'} ${animated ? 'is-anim' : ''}${brand === 'elite' ? ' is-elite' : ''}" role="group" aria-label="${esc(t('ch.cardLabel'))}">
    <i class="sigcard-sweep" aria-hidden="true"></i>
    <header class="sigcard-head">
      <span class="sigcard-logo">${brand === 'elite' ? '<img src="/elite/elite-icon.svg" width="26" height="26" alt="" decoding="async"/>' : logoMark(26)}</span>
      <span class="sigcard-brand"><b>${brand === 'elite' ? 'Alpha Elite Signals' : 'AlphaTrade AI'}</b><small>${esc(strategyLabel(s.strategy))} · ${esc(t(`perf.tfShort.${s.tf}`))}</small></span>
      <span class="sigcard-sym" dir="ltr">${esc(pairName(s.symbol))}</span>
      <span class="sigcard-asset">${assetIcon(getInstrument(s.symbol).icon, 28)}</span>
      <span class="sigcard-dir">${esc(t(long ? 'common.long' : 'common.short'))}</span>
    </header>
    <div class="rc-meta">${s.tier==='watch'?`<span class="rc-tier">${en?'Under watch':'تحت المراقبة'}</span>`:s.tier==='engine'?`<span class="rc-tier is-engine">${en?'AI engine · conditions met':'محرك AI · شروط محققة'}</span>`:''}<b>${s.order==='limit'?(en?'Limit · pending price':'ليمِت · سعر محدد'):(en?'Market · confirmed entry':'ماركت · دخول مؤكد')}</b><time>${esc(new Date(s.createdAt).toLocaleString(en?'en-GB':'ar-EG-u-nu-latn'))}</time></div>
    <div class="sigcard-ladder" dir="ltr" data-live="${esc(String(s.id))}">
      <div class="lad-track">
        <i class="lad-seg lad-risk" style="left:0;width:${at(s.entry).toFixed(2)}%"></i>
        <i class="lad-seg lad-reward" style="left:${at(s.entry).toFixed(2)}%;width:${(100 - at(s.entry)).toFixed(2)}%"></i>
        <i class="lad-fill" data-l-fill></i>
        ${marks.map(([k, , v]) => `<i class="lad-tick lad-${k.startsWith('tp') ? 'tp' : k}" data-tick="${k}" style="--i:${marks.findIndex((m) => m[0] === k)};left:${at(v).toFixed(2)}%"></i>`).join('')}
        <span class="lad-now" data-l-now style="left:${at(s.entry).toFixed(2)}%"><em class="mono" data-l-price>—</em></span>
      </div>
      <div class="lad-labels">
        ${marks.map(([k, name, v, i]) => `<div class="lad-lab lad-${k.startsWith('tp') ? 'tp' : k}" ${i != null ? `data-tp="${i}"` : ''}><span>${esc(name)}</span><b class="mono">${p(v)}</b></div>`).join('')}
      </div>
    </div>
    <div class="sigcard-foot"><b class="mono sl-pips" data-l-pips>—</b><span class="sl-next" data-l-next></span><span class="sl-state" data-l-state></span><span class="sl-note">${esc(t('ch.cardNote'))}</span></div><p class="rc-quote muted" data-quote-time></p>
  </article>`;
}

/** Refreshes the live strip of every card on screen (price, pips, progress, targets hit, status). Called every second with the tracked signals. */
export function paintLive(root, signals) {
  for (const box of root.querySelectorAll('[data-live]')) {
    const s = signals.find((x) => String(x.id) === box.dataset.live);
    if (!s) continue;
    const card = box.closest('.sigcard');
    const sign = s.direction === 'long' ? 1 : -1;
    const inst = getInstrument(s.symbol);
    const pip = (inst ? pipPoints(inst) : 10) * (s.pointSize || 1);
    const span = (s.targets[2] - s.stop) * sign || 1;
    const at = (v) => Math.max(0, Math.min(100, (((v - s.stop) * sign) / span) * 100));
    const priceEl = box.querySelector('[data-l-price]');
    const now = box.querySelector('[data-l-now]');
    const fill = box.querySelector('[data-l-fill]');
    const pe = card.querySelector('[data-l-pips]');
    if (Number.isFinite(s.price)) {
      const prev = Number(priceEl.dataset.num);
      if (prev !== s.price) {
        tweenNumber(priceEl, s.price, (v) => fmtNum(v, s.precision), 500);   // the digits roll to the new price
        if (Number.isFinite(prev)) restartClass(pe, ['tick-up', 'tick-down'], s.price > prev ? 'tick-up' : 'tick-down');
      }
      const x = at(s.price), e = at(s.entry);
      now.style.left = `${x}%`;
      now.classList.toggle('is-edge-l', x < 14); now.classList.toggle('is-edge-r', x > 86);
      fill.style.left = `${Math.min(x, e)}%`; fill.style.width = `${Math.abs(x - e)}%`;
      const pips = ((s.price - s.entry) * sign) / pip;
      fill.classList.toggle('is-loss', pips < 0);
      pe.textContent = `${pips >= 0 ? '+' : '−'}${fmtNum(Math.abs(pips), 1)} ${t('ch.pips')}`;
      pe.classList.toggle('up', pips >= 0); pe.classList.toggle('down', pips < 0);
    }
    const st = card.querySelector('[data-l-state]'); if (st) st.textContent = t(`sig.status.${s.status}`);
    card.classList.toggle('is-closed', !['active','pending'].includes(s.status));
    const en=getLang() !== 'ar', quote=card.querySelector('[data-quote-time]');
    if(quote){ const at=s.priceAt, stale=!at || Date.now()-at>30000;
      quote.textContent=(stale?(en?'Price stale / feed unavailable':'السعر متأخر / الاتصال غير متاح'):(en?'Last received price':'آخر سعر مستلم'))+(at?' · '+new Date(at).toLocaleTimeString(en?'en-GB':'ar-EG-u-nu-latn'):'');
      quote.classList.toggle('down',stale);now.classList.toggle('is-stale',stale);
    }
    if(s.status==='pending') { pe.textContent=en?'Waiting for entry':'بانتظار الدخول'; pe.classList.remove('up','down'); }
    // a target that was just reached bursts once (ring + glow), then stays lit
    const burst = (el, hit) => { const was = el.classList.contains('hit'); el.classList.toggle('hit', hit); if (hit && !was && el.dataset.seen) restartClass(el, ['burst'], 'burst'); el.dataset.seen = '1'; };
    card.querySelectorAll('[data-tp]').forEach((row) => burst(row, (s.hits || 0) > Number(row.dataset.tp)));
    box.querySelectorAll('[data-tick^=tp]').forEach((tk, i) => burst(tk, (s.hits || 0) > i));
    // next target and how far it is
    const nx = card.querySelector('[data-l-next]');
    if (nx) {
      const k = Math.min(2, s.hits || 0);
      nx.textContent = s.status === 'active' && s.price != null && (s.hits || 0) < 3 ? `TP${k + 1} · ${fmtNum(Math.max(0, ((s.targets[k] - s.price) * sign) / pip), 1)} ${t('ch.pips')}` : '';
    }
  }
}

let host = null;
const HOLD_MS = 14000;
/** Shows the card as a pop-up in the corner; it stays 14 s (hover keeps it) and can be closed. */
export function showSignalCard(s) {
  if (typeof document === 'undefined' || !CHANNEL_STRATEGIES.includes(s.strategy)) return;
  if (!host || !host.isConnected) { host = document.createElement('div'); host.className = 'sigpop-host'; host.setAttribute('aria-live', 'polite'); document.body.appendChild(host); }
  const wrap = document.createElement('div');
  wrap.className = 'sigpop';
  wrap.innerHTML = `${signalCardHtml(s)}<button type="button" class="sigpop-x" aria-label="${esc(t('common.close') || 'close')}">×</button>`;
  host.prepend(wrap);
  paintLive(wrap, signalState().signals);
  const off = onSignals((st) => { if (!wrap.isConnected) { off(); return; } paintLive(wrap, st.signals); });
  while (host.children.length > 3) host.lastElementChild.remove();
  let timer = 0;
  const close = () => { clearTimeout(timer); off(); wrap.classList.add('is-out'); setTimeout(() => wrap.remove(), 320); };
  const arm = () => { clearTimeout(timer); timer = setTimeout(close, HOLD_MS); };
  wrap.addEventListener('mouseenter', () => clearTimeout(timer));
  wrap.addEventListener('mouseleave', arm);
  wrap.querySelector('.sigpop-x').addEventListener('click', close);
  arm();
}
