// Phone number field (v228): a searchable country picker (flag + name + dialling code) and the number input.
// Accessible combobox: the picker is a button (aria-haspopup="listbox") that opens a search box and a listbox; arrows / Home /
// End / Enter / Escape work, type-ahead filters by name, ISO code or "+code". Everything is rendered with esc() / textContent.
// Validation: services/phoneNumbers.js (the server re-checks the same rules).
import { esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { COUNTRIES, countryByIso, countryName, validatePhone, guessCountry } from '../services/phoneNumbers.js';

// Shown first (most of our members); everything else follows alphabetically by localised name.
const TOP = ['PS', 'JO', 'IL', 'SA', 'AE', 'EG', 'KW', 'QA', 'BH', 'OM', 'IQ', 'LB', 'SY', 'MA', 'DZ', 'TN', 'TR', 'US', 'GB', 'DE', 'FR'];

export const PHONE_ERRORS = {
  required: { ar: 'اكتب رقم الهاتف.', en: 'Enter your phone number.', he: 'הזן מספר טלפון.', es: 'Introduce tu teléfono.', zh: '请输入手机号码。' },
  country: { ar: 'اختار الدولة.', en: 'Choose your country.', he: 'בחר מדינה.', es: 'Elige tu país.', zh: '请选择国家。' },
  chars: { ar: 'الرقم لازم يكون أرقام بس (مسموح مسافات وشرطات).', en: 'Use digits only (spaces and dashes are fine).', he: 'ספרות בלבד.', es: 'Solo dígitos (se permiten espacios y guiones).', zh: '只能输入数字（可含空格和横线）。' },
  prefix: { ar: 'مفتاح الدولة بالرقم مش نفس الدولة المختارة.', en: 'The country code in the number does not match the selected country.', he: 'קידומת המדינה אינה תואמת.', es: 'El prefijo no coincide con el país elegido.', zh: '号码中的国家代码与所选国家不符。' },
  short: { ar: 'الرقم قصير لهالدولة.', en: 'The number is too short for this country.', he: 'המספר קצר מדי.', es: 'El número es demasiado corto.', zh: '号码太短。' },
  long: { ar: 'الرقم طويل لهالدولة.', en: 'The number is too long for this country.', he: 'המספר ארוך מדי.', es: 'El número es demasiado largo.', zh: '号码太长。' },
  format: { ar: 'الرقم مش بصيغة صحيحة لهالدولة.', en: 'This is not a valid number format for this country.', he: 'פורמט לא תקין.', es: 'Formato no válido para este país.', zh: '该国家的号码格式无效。' },
};
export const phoneErrorText = (code) => tx(PHONE_ERRORS[code] || PHONE_ERRORS.format);

/** HTML for the field (name="phone" + a hidden name="country"). */
export function phoneFieldHtml({ id = 'phone', required = true } = {}) {
  const lbl = tx({ ar: 'رقم الهاتف', en: 'Phone number', he: 'מספר טלפון', es: 'Teléfono', zh: '手机号码' });
  return `<div class="field-wrap phone-wrap">
    <div class="field phone-field" data-field="phone">
      <span class="visually-hidden" id="${id}-lbl">${esc(lbl)}</span>
      <button type="button" class="phone-cc" data-cc aria-haspopup="listbox" aria-expanded="false" aria-controls="${id}-list" aria-label="${esc(tx({ ar: 'الدولة', en: 'Country', he: 'מדינה', es: 'País', zh: '国家' }))}"><span class="phone-flag" data-flag>🌐</span><span class="phone-dial mono" data-dial>+—</span><span class="phone-caret" aria-hidden="true">▾</span></button>
      <input type="hidden" name="country" value=""/>
      <input name="phone" type="tel" inputmode="tel" autocomplete="tel-national" maxlength="24" dir="ltr" placeholder="${esc(lbl)}" aria-labelledby="${id}-lbl" ${required ? 'aria-required="true"' : ''} spellcheck="false"/>
    </div>
    <div class="phone-pop" data-pop hidden>
      <input class="phone-search" type="search" data-search autocomplete="off" spellcheck="false" placeholder="${esc(tx({ ar: 'ابحث عن دولة أو مفتاح…', en: 'Search a country or code…', he: 'חפש מדינה או קידומת…', es: 'Busca un país o prefijo…', zh: '搜索国家或区号…' }))}" aria-label="${esc(tx({ ar: 'بحث', en: 'Search', he: 'חיפוש', es: 'Buscar', zh: '搜索' }))}" aria-controls="${id}-list"/>
      <ul class="phone-list" id="${id}-list" role="listbox" tabindex="-1" data-list></ul>
    </div>
    <p class="field-error" data-error-for="phone" role="alert"></p>
  </div>`;
}

/** Wires the field inside `root`. Returns { value(): { country, phone }, validate(): result, setError(code), focus() }. */
export function bindPhoneField(root, { initial = null } = {}) {
  const lang = getLang();
  const q = (s) => root.querySelector(s);
  const btn = q('[data-cc]'), pop = q('[data-pop]'), list = q('[data-list]'), search = q('[data-search]');
  const hidden = q('input[name=country]'), input = q('input[name=phone]'), err = q('[data-error-for=phone]'), wrap = q('.phone-field');
  const coll = (() => { try { return new Intl.Collator(lang); } catch { return null; } })();
  const named = COUNTRIES.map((c) => ({ ...c, name: countryName(c.iso, lang), nameEn: countryName(c.iso, 'en') }));
  const ordered = [...TOP.map((i) => named.find((c) => c.iso === i)).filter(Boolean), ...named.filter((c) => !TOP.includes(c.iso)).sort((a, b) => (coll ? coll.compare(a.name, b.name) : a.name.localeCompare(b.name)))];
  let shown = ordered; let active = 0;

  const choose = (iso, { focusInput = true } = {}) => {
    const c = countryByIso(iso); if (!c) return;
    hidden.value = c.iso; q('[data-flag]').textContent = c.flag; q('[data-dial]').textContent = `+${c.dial}`;
    btn.setAttribute('aria-label', `${countryName(c.iso, lang)} +${c.dial}`);
    close(); if (focusInput) input.focus();
    if (input.value) check(false);
  };
  const paint = () => {
    list.innerHTML = shown.map((c, i) => `<li role="option" id="${list.id}-${c.iso}" data-iso="${c.iso}" aria-selected="${c.iso === hidden.value}" class="${i === active ? 'is-active' : ''}${i === TOP.length - 1 && shown === ordered ? ' is-sep' : ''}"><span class="phone-flag">${c.flag}</span><span class="phone-name">${esc(c.name)}</span><span class="phone-code mono">+${esc(c.dial)}</span></li>`).join('')
      || `<li class="phone-none" aria-disabled="true">${esc(tx({ ar: 'ما في نتائج', en: 'No results', he: 'אין תוצאות', es: 'Sin resultados', zh: '无结果' }))}</li>`;
    const a = list.children[active]; if (a?.dataset.iso) { search.setAttribute('aria-activedescendant', a.id); a.scrollIntoView({ block: 'nearest' }); }
  };
  const filter = () => {
    const v = search.value.trim().toLowerCase().replace(/^\+/, '');
    shown = !v ? ordered : ordered.filter((c) => c.name.toLowerCase().includes(v) || c.nameEn.toLowerCase().includes(v) || c.iso.toLowerCase() === v || c.dial.startsWith(v));
    active = 0; paint();
  };
  const open = () => { pop.hidden = false; btn.setAttribute('aria-expanded', 'true'); search.value = ''; shown = ordered; active = Math.max(0, shown.findIndex((c) => c.iso === hidden.value)); paint(); search.focus(); };
  function close() { pop.hidden = true; btn.setAttribute('aria-expanded', 'false'); }

  btn.addEventListener('click', () => (pop.hidden ? open() : close()));
  search.addEventListener('input', filter);
  search.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); active = Math.min(shown.length - 1, active + 1); paint(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); active = Math.max(0, active - 1); paint(); }
    else if (e.key === 'Home') { e.preventDefault(); active = 0; paint(); }
    else if (e.key === 'End') { e.preventDefault(); active = shown.length - 1; paint(); }
    else if (e.key === 'Enter') { e.preventDefault(); if (shown[active]) choose(shown[active].iso); }
    else if (e.key === 'Escape') { e.preventDefault(); close(); btn.focus(); }
    else if (e.key === 'Tab') close();
  });
  list.addEventListener('mousedown', (e) => e.preventDefault());   // keep focus in the search box
  list.addEventListener('click', (e) => { const li = e.target.closest('[data-iso]'); if (li) choose(li.dataset.iso); });
  const outside = (e) => { if (!pop.hidden && !root.contains(e.target)) close(); };
  document.addEventListener('pointerdown', outside);
  const off = () => document.removeEventListener('pointerdown', outside);
  new MutationObserver((_, obs) => { if (!root.isConnected) { off(); obs.disconnect(); } }).observe(document.body, { childList: true, subtree: true });

  // typing: keep only characters a phone number can have (paste included); a typed "+code" selects that country
  input.addEventListener('input', () => {
    const clean = input.value.replace(/[^\d\s().+\-]/g, '').slice(0, 24);
    if (clean !== input.value) input.value = clean;
    const m = /^\s*(?:\+|00)(\d{1,4})/.exec(clean);
    if (m && !hidden.value) { for (let n = Math.min(4, m[1].length); n >= 1; n--) { const hit = TOP.map(countryByIso).concat(COUNTRIES).find((c) => c && c.dial === m[1].slice(0, n)); if (hit) { choose(hit.iso, { focusInput: false }); break; } } }
    if (err.textContent) setError(null);
  });
  input.addEventListener('blur', () => { if (input.value.trim()) check(false); });

  function setError(code) { err.textContent = code ? phoneErrorText(code) : ''; wrap.classList.toggle('has-error', Boolean(code)); input.setAttribute('aria-invalid', String(Boolean(code))); }
  function check(showRequired = true) {
    if (!hidden.value) { const r = { ok: false, error: 'country' }; setError(input.value.trim() || showRequired ? r.error : null); return r; }
    const r = validatePhone(input.value, hidden.value);
    if (!r.ok && (r.error !== 'required' || showRequired)) setError(r.error); else if (r.ok) { setError(null); input.value = formatNational(r); }
    return r;
  }
  const formatNational = (r) => r.national.replace(/(\d{2,3})(?=(\d{3,4})+$)/g, '$1 ').trim();

  const start = initial?.iso || guessCountry();
  if (start) choose(start, { focusInput: false });
  if (initial?.e164 && initial.iso) { const c = countryByIso(initial.iso); if (c) input.value = initial.e164.slice(c.dial.length + 1); }
  return { validate: () => check(true), setError, value: () => ({ country: hidden.value, phone: input.value }), focus: () => input.focus() };
}
