// Phone alerts (owner only): Telegram bot + ntfy topic, set on the site instead of in .env.
// "Saved" appears only after the server sent a REAL test message to that channel; a failing channel is not saved.
import { esc } from '../utils/dom.js';
import { t } from '../i18n/index.js';
import { icons } from './icons.js';
import { toast } from './ui.js';
import { statePill } from './aiKeyCard.js';
import { notifyStatus, saveNotify, testNotify, deleteNotify, onNotify, lastNotify } from '../services/notifyApi.js';
import { auth } from '../services/auth/index.js';

const errText = (code) => t(`ntf.err.${code}`) || t('aiErr.unknown');

export function notifyCardHtml() {
  return `<article class="card tool-card fade-in ai-key-card" data-nf-panel>
    <div class="tool-head"><h2 class="card-title">${icons.alarm || icons.lock}<span>${esc(t('ntf.title'))}</span></h2><span data-nf-pill>${statePill('checking')}</span></div>
    <div data-nf-body><p class="muted">${esc(t('aiKey.loading'))}</p></div>
  </article>`;
}

export function bindNotifyCard(root) {
  const panel = root.querySelector('[data-nf-panel]');
  const $ = (s) => panel.querySelector(s);
  let busy = false; let note = null;
  const pill = (st) => (st.state === 'no_server' ? 'no_server' : st.telegram?.set || st.ntfy?.set ? ((st.telegram?.set && st.telegram.ok === false) || (st.ntfy?.set && st.ntfy.ok === false) ? 'failed' : 'connected') : 'none');
  const src = (c) => (c.source === 'env' ? t('ntf.fromEnv') : '');

  const form = (st) => `
    <div class="ntf-ch"><h3>${esc(t('ntf.tg'))} <span class="muted">${st.telegram.set ? esc(`${t('ntf.set')} ${st.telegram.tokenLast4 || ''} · ${st.telegram.chat || ''} ${src(st.telegram)}`) : esc(t('ntf.notSet'))}</span></h3>
      <div class="tf-grid">
        <label class="tf-field tf-wide"><span>${esc(t('ntf.token'))}</span><input class="input mono" type="password" data-nf-token dir="ltr" autocomplete="new-password" spellcheck="false" placeholder="${esc(st.telegram.set ? t('ntf.keep') : '123456789:AAH…')}"/></label>
        <label class="tf-field"><span>${esc(t('ntf.chat'))}</span><input class="input mono" data-nf-chat dir="ltr" spellcheck="false" placeholder="${esc(st.telegram.set ? t('ntf.keep') : '123456789 / -100…')}"/></label>
      </div>
      <div class="tool-actions"><button type="button" class="btn btn-sm btn-primary" data-nf-save-tg>${icons.check}<span>${esc(t('ntf.saveTg'))}</span></button>
        <button type="button" class="btn btn-sm btn-ghost" data-nf-del-tg ${st.telegram.source === 'site' ? '' : 'hidden'}>${icons.trash}<span>${esc(t('aiKey.delete'))}</span></button></div>
      <p class="muted tool-note">${esc(t('ntf.tgHow'))}</p></div>
    <div class="ntf-ch"><h3>${esc(t('ntf.ntfy'))} <span class="muted">${st.ntfy.set ? esc(`${t('ntf.set')} ${st.ntfy.topicLast3 || ''} ${src(st.ntfy)}`) : esc(t('ntf.notSet'))}</span></h3>
      <label class="tf-field tf-wide"><span>${esc(t('ntf.topic'))}</span><input class="input mono" type="password" data-nf-topic dir="ltr" autocomplete="new-password" spellcheck="false" placeholder="${esc(st.ntfy.set ? t('ntf.keep') : 'my-secret-topic-8chars+')}"/></label>
      <div class="tool-actions"><button type="button" class="btn btn-sm btn-primary" data-nf-save-nt>${icons.check}<span>${esc(t('ntf.saveNt'))}</span></button>
        <button type="button" class="btn btn-sm btn-ghost" data-nf-del-nt ${st.ntfy.source === 'site' ? '' : 'hidden'}>${icons.trash}<span>${esc(t('aiKey.delete'))}</span></button></div>
      <p class="muted tool-note">${esc(t('ntf.ntHow'))}</p></div>
    <div class="tool-actions"><button type="button" class="btn btn-sm" data-nf-test ${st.telegram.set || st.ntfy.set ? '' : 'disabled'}>${icons.refresh}<span>${esc(t('ntf.test'))}</span></button></div>
    ${st.error ? `<p class="ai-k-err down">${esc(errText(st.error))}</p>` : ''}
    <p class="ai-k-note ${note ? note.kind : ''}" aria-live="polite">${note ? esc(note.text) : ''}</p>
    ${st.canSave === false ? `<p class="ai-k-err down">${esc(t('aiErr.no_secret'))}</p>` : ''}
    <p class="muted tool-note">${esc(t('ntf.secureNote'))}</p>`;

  const notOwner = (st) => (st.state === 'no_server' ? `<p class="ai-k-err down">${esc(t('aiKey.line.noServer'))}</p>`
    : st.signinConfigured === false ? `<p class="ai-k-err down">${esc(t('aiKey.line.noSignin'))}</p>`
      : auth.current()?.provider === 'local' ? `<p class="muted">${esc(t('aiKey.line.localAccount'))}</p>`
        : `<p class="muted">${esc(t('ntf.ownerOnly'))}</p>`);

  const verdict = (r, okText) => {
    if (r.ok) return { kind: 'up', text: okText };
    const why = Object.values(r.codes || {}).filter(Boolean).map(errText).join(' · ') || errText(r.code || 'unknown');
    return { kind: 'down', text: t('aiKey.notSaved', { why }) };
  };

  function render(st, checking = false) {
    $('[data-nf-pill]').innerHTML = statePill(checking ? 'checking' : st.owner ? pill(st) : (st.state || 'none'));
    $('[data-nf-body]').innerHTML = st.owner ? form(st) : notOwner(st);
    if (!st.owner) return;
    if (busy) panel.querySelectorAll('button').forEach((b) => { b.disabled = true; });
    $('[data-nf-save-tg]').addEventListener('click', () => {
      const cfg = { telegramToken: $('[data-nf-token]').value.trim(), telegramChatId: $('[data-nf-chat]').value.trim() };   // read BEFORE run() re-renders
      run(async () => (cfg.telegramToken || cfg.telegramChatId ? verdict(await saveNotify(cfg), t('ntf.savedTg')) : { kind: 'down', text: errText('nothing') }));
    });
    $('[data-nf-save-nt]').addEventListener('click', () => {
      const cfg = { ntfyTopic: $('[data-nf-topic]').value.trim() };
      run(async () => (cfg.ntfyTopic ? verdict(await saveNotify(cfg), t('ntf.savedNt')) : { kind: 'down', text: errText('nothing') }));
    });
    $('[data-nf-test]').addEventListener('click', () => run(async () => verdict(await testNotify(), t('ntf.testOk'))));
    for (const [sel, ch] of [['[data-nf-del-tg]', 'telegram'], ['[data-nf-del-nt]', 'ntfy']]) {
      $(sel).addEventListener('click', () => { if (!window.confirm(t('ntf.deleteAsk'))) return; run(async () => { await deleteNotify(ch); return { kind: 'muted', text: t('ntf.deleted') }; }); });
    }
  }

  async function run(fn) {
    if (busy) return; busy = true; note = null;
    const st0 = lastNotify() || {};
    render(st0, true);
    try { note = await fn(); } catch (e) { note = { kind: 'down', text: errText(e?.code || 'unknown') }; }
    finally { busy = false; render(lastNotify() || st0); if (note?.kind === 'up') toast(note.text, 'success'); }
  }
  const off = onNotify((st) => { if (!busy && panel.isConnected) render(st); else if (!panel.isConnected) off(); });
  notifyStatus();
}
