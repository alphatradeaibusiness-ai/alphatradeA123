// v281 Payment-method badges shown before checkout (plans and challenges). Which methods actually appear at checkout depends
// on the buyer's country and what the site owner switched on in Stripe.
import { esc } from '../utils/dom.js';
import { tx } from '../i18n/tx.js';
import { PAY_METHODS } from '../config/challenges.js';
import '../styles/challenges.css';
const PAY_LABEL = { visa: 'VISA', mastercard: 'Mastercard', applepay: 'Apple Pay', googlepay: 'Google Pay', paypal: 'PayPal', crypto: 'USDT · Crypto' };
export const payMethodsHtml = () => `<div class="ch-paym" aria-label="${esc(tx({ ar: 'طرق الدفع', en: 'Payment methods' }))}">${PAY_METHODS.map((m) => `<span class="ch-pm is-${m}">${PAY_LABEL[m]}</span>`).join('')}</div>`;
