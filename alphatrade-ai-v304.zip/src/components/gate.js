// Plan gates: a feature either runs, or the person sees which plan unlocks it (see config/entitlements.js).
import { t } from '../i18n/index.js';
import { toast } from './ui.js';
import { icons } from './icons.js';
import { esc } from '../utils/dom.js';
import { can, planFor, limit, lockPlan } from '../config/entitlements.js';
import { alertState } from '../services/alerts.js';

const planName = (feature) => t(`pricing.plans.${planFor(feature)}`);

/** true when the feature is included; otherwise a toast names the plan that unlocks it. */
export function gate(feature) {
  if (can(feature)) return true;
  toast(t('ent.locked', { plan: planName(feature) }), 'info', 5200);
  return false;
}

/** true while the plan still has room for another alert or rule. */
export function alertSlotOk() {
  const lim = limit('alerts');
  if (!(lim > 0)) return true;
  const st = alertState();
  const n = (st.alerts?.length || 0) + (st.rules?.length || 0);
  if (n < lim) return true;
  toast(t('ent.alertsFull', { n: lim }), 'info', 5200);
  return false;
}

/** A card shown in place of a locked tool. */
export function lockedCard(feature) {
  return `<article class="card ent-locked fade-in">
    <span class="ent-lock">${icons.lock}</span>
    <h2 class="card-title">${esc(t('ent.lockedTitle'))}</h2>
    <p class="muted">${esc(t('ent.locked', { plan: planName(feature) }))}</p>
    <a class="btn btn-primary" href="#/app/pricing">${esc(t('ent.seePlans'))}</a>
  </article>`;
}

/** v276: a whole side-menu page that the person's plan does not include. */
export function lockedPage(navId) {
  const el = document.createElement('section'); el.className = 'page ent-page-locked';
  el.innerHTML = `<article class="card ent-locked fade-in">
    <span class="ent-lock">${icons.lock}</span>
    <h2 class="card-title">${esc(t('ent.lockedTitle'))}</h2>
    <p class="muted">${esc(t('ent.locked', { plan: t(`pricing.plans.${lockPlan(navId)}`) }))}</p>
    <a class="btn btn-primary" href="#/app/pricing">${esc(t('ent.seePlans'))}</a>
  </article>`;
  return el;
}
