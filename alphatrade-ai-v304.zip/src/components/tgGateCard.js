// v262 Owner card: Telegram channel only for active subscribers (join requests checked against the site, removal on expiry).
import { esc } from '../utils/dom.js';
import { tx } from '../i18n/tx.js';
import { getLocale } from '../i18n/index.js';
import { icons } from './icons.js';
import { toast } from './ui.js';
import { apiRequest } from '../services/ai/gateway.js';

const L = (ar, en) => tx({ ar, en });
const EV = { approved: ['قُبل', 'approved'], declined: ['انرفض', 'declined'], removed: ['انشال', 'removed'], remove_failed: ['ما قدر يشيل', 'removal failed'], joined_ok: ['دخل (مسموح)', 'joined (allowed)'], left: ['طلع', 'left'], sweep: ['فحص دوري', 'periodic check'], invite_created: ['رابط جديد', 'new link'], config: ['⚙ إعدادات', '⚙ settings'], approve_failed: ['القبول فشل', 'approve failed'] };
const WHY = { subscribe_first: ['بدون اشتراك فعّال', 'no active subscription'], link_first: ['تلغرام مش مربوط', 'Telegram not linked'], unlinked: ['انفصل الربط', 'link removed'] };

export const tgGateCardHtml = () => `<article class="card tool-card fade-in ai-key-card" data-tgg><div class="tool-head"><h2 class="card-title">${icons.send || icons.lock}<span>${esc(L('قناة تلغرام للمشتركين بس', 'Telegram channel, subscribers only'))}</span></h2></div><div data-tgg-body><p class="muted">…</p></div></article>`;

export function bindTgGateCard(root) {
  const box = root.querySelector('[data-tgg-body]'); if (!box) return;
  async function load() {
    let s; try { s = await apiRequest('GET', '/api/tg-gate/admin', undefined, 25000); } catch (e) { box.innerHTML = `<p class="muted">${esc(e.code === 'forbidden' ? L('للمالكين بس.', 'Owners only.') : L('السيرفر مش متاح.', 'Server not available.'))}</p>`; return; }
    const c = s.config; const b = s.bot || {};
    const right = (ok, a, e) => `<li class="${ok ? 'up' : 'down'}">${ok ? '✔' : '✕'} ${esc(L(a, e))}</li>`;
    box.innerHTML = `
      <p class="tool-note">${esc(L('ما حدا بيدخل القناة أو بيضل فيها إلا إذا عنده حساب بالموقع واشتراك فعّال. البوت بيفحص كل طلب انضمام، وبيشيل اللي خلص اشتراكهم تلقائيًا.', 'Nobody joins or stays in the channel without a site account and an active subscription. The bot checks every join request and removes members whose plan ended.'))}</p>
      ${!s.tokenSet ? `<p class="muted">${esc(L('اضبط بوت تلغرام ورقم القناة بالبطاقة اللي فوق أول.', 'Set the Telegram bot and channel in the card above first.'))}</p>` : ''}
      <ul class="tool-list">${right(b.admin, 'البوت أدمن بالقناة', 'Bot is a channel admin')}${right(b.canInvite, 'صلاحية «دعوة مستخدمين» (لقبول الطلبات)', '“Invite users” right (to approve requests)')}${right(b.canRestrict, 'صلاحية «حظر مستخدمين» (للإزالة)', '“Ban users” right (to remove)')}${b.bot ? `<li class="muted">@${esc(b.bot)}</li>` : ''}${b.error ? `<li class="down">${esc(b.error)}</li>` : ''}</ul>
      <div class="tf-grid">
        <label class="tf-field"><span>${esc(L('رقم القناة', 'Channel id'))}</span><input class="input mono" dir="ltr" data-g="channelId" placeholder="${esc(c.channelEffective || '-100…')}" value="${esc(c.channelId || '')}"></label>
        <label class="tf-field"><span>${esc(L('مهلة بعد انتهاء الاشتراك (ساعات)', 'Grace after expiry (hours)'))}</span><input class="input" type="number" min="0" max="168" data-g="graceHours" value="${c.graceHours}"></label>
        <label class="tf-field"><span>${esc(L('الفحص الدوري كل (دقيقة)', 'Periodic check every (minutes)'))}</span><input class="input" type="number" min="5" max="1440" data-g="checkMinutes" value="${c.checkMinutes}"></label>
      </div>
      <div class="tool-actions">${[['enabled', 'شغّل البوابة', 'Gate on'], ['kickOnExpiry', 'شيل اللي خلص اشتراكهم', 'Remove expired members'], ['dm', 'ابعت رسالة توجيه بالخاص', 'Send a guiding private message']].map(([k, a, e]) => `<label class="pc-switch"><input type="checkbox" data-gc="${k}" ${c[k] ? 'checked' : ''}> ${esc(L(a, e))}</label>`).join('')}</div>
      <div class="tool-actions"><button type="button" class="btn btn-sm btn-primary" data-g-save>${icons.check}<span>${esc(L('احفظ', 'Save'))}</span></button>
        <button type="button" class="btn btn-sm" data-g-invite>${icons.external} <span>${esc(L('أنشئ رابط دعوة بالموافقة', 'Create approval invite link'))}</span></button>
        <button type="button" class="btn btn-sm btn-ghost" data-g-sweep>${icons.refresh} <span>${esc(L('افحص الأعضاء هلّق', 'Check members now'))}</span></button></div>
      ${c.inviteEffective ? `<p class="tool-note">${esc(L('رابط الدعوة (بيوصل للمشتركين بصفحة «الإشعارات والربط»)', 'Invite link (shown to subscribers in “Notifications & connect”)'))}: <code dir="ltr">${esc(c.inviteEffective)}</code>${c.inviteLink ? '' : `<br><small>${esc(L('هاد رابطك. خلّيه بتلغرام «يحتاج موافقة الأدمن» (Request admin approval) ليمرّ كل دخول على البوت، أو اكبس «أنشئ رابط دعوة بالموافقة».', 'This is your link. In Telegram set it to “Request admin approval” so every join goes through the bot, or press “Create approval invite link”.'))}</small>`}</p>` : ''}
      <p class="muted tool-note">${esc(L(`أعضاء متتبَّعين: ${s.members} · آخر فحص: ${s.lastSweep ? new Date(s.lastSweep).toLocaleString(getLocale()) : '—'}`, `Tracked members: ${s.members} · last check: ${s.lastSweep ? new Date(s.lastSweep).toLocaleString(getLocale()) : '—'}`))}</p>
      <p class="muted tool-note">⚠ ${esc(L('مهم: خلّي القناة خاصة، وألغِ روابط الدعوة القديمة من تلغرام. تلغرام ما بيسمح للبوت يجيب قائمة الأعضاء القدام، فاللي دخلوا قبل البوابة بينفحصوا بس لما يبيّنوا. كل الدخول الجديد لازم يكون من رابط الموافقة.', 'Important: keep the channel private and revoke old invite links in Telegram. Telegram does not let bots list existing members, so people who joined before the gate are only checked when seen. All new joins must use the approval link.'))}</p>
      ${s.events.length ? `<details><summary>${esc(L('آخر الأحداث', 'Recent events'))}</summary><ul class="tool-list">${s.events.slice(0, 25).map((e) => `<li><small>${esc(new Date(e.at).toLocaleString(getLocale()))}</small> ${esc(L(...(EV[e.type] || [e.type, e.type])))}${e.tg ? ` <code>${e.tg}</code>` : ''}${e.why ? ` · ${esc(L(...(WHY[e.why] || [e.why, e.why])))}` : ''}${e.type === 'sweep' ? ` · ${e.checked}/${e.removed}` : ''}${e.error ? ` · ${esc(e.error)}` : ''}</li>`).join('')}</ul></details>` : ''}`;
  }
  box.addEventListener('click', async (e) => {
    try {
      if (e.target.closest('[data-g-save]')) { const b = {}; box.querySelectorAll('[data-g]').forEach((i) => { b[i.dataset.g] = i.dataset.g === 'channelId' ? i.value.trim() : Number(i.value); }); box.querySelectorAll('[data-gc]').forEach((i) => { b[i.dataset.gc] = i.checked; }); await apiRequest('PUT', '/api/tg-gate/admin', b); toast(L('انحفظ ✔', 'Saved ✔'), 'success'); load(); }
      if (e.target.closest('[data-g-invite]')) { const r = await apiRequest('POST', '/api/tg-gate/admin/invite', {}); toast(L('انعمل رابط دعوة بالموافقة ✔', 'Approval invite link created ✔'), 'success'); navigator.clipboard?.writeText(r.inviteLink).catch(() => {}); load(); }
      if (e.target.closest('[data-g-sweep]')) { const r = await apiRequest('POST', '/api/tg-gate/admin/sweep', {}, 60000); toast(L(`انفحص ${r.checked || 0} · انشال ${r.removed || 0}`, `Checked ${r.checked || 0} · removed ${r.removed || 0}`), 'success'); load(); }
    } catch (x) { toast(x.code === 'bad_channel' ? L('رقم القناة لازم يبلّش بـ -100 أو @', 'Channel id must start with -100 or @') : x.code === 'telegram' || x.code === 'no_channel' ? L('تلغرام رفض، تأكد إن البوت أدمن بصلاحية دعوة.', 'Telegram refused, make sure the bot is an admin with the invite right.') : L('ما زبط.', 'Failed.'), 'error'); }
  });
  load();
}
