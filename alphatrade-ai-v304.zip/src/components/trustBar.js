// The "secure connection" chip in the header: it only shows when the page is really served over HTTPS.
import { getLang } from '../i18n/index.js';
import { icons } from './icons.js';

const L = (ar, en) => (getLang() !== 'ar' ? en : ar);
export const secureConnection = () => typeof window !== 'undefined' && window.isSecureContext === true && (location.protocol === 'https:' || ['localhost', '127.0.0.1'].includes(location.hostname));

/** Header chip; empty when the page is not on a secure connection. */
export function secureChipHtml() {
  if (!secureConnection()) return '';
  return `<span class="sec-chip" title="${L('الاتصال مشفّر (HTTPS) ومفاتيحك محفوظة مشفّرة على السيرفر', 'The connection is encrypted (HTTPS) and your keys are stored encrypted on the server')}">${icons.lock}<span>${L('اتصال آمن', 'Secure')}</span></span>`;
}
