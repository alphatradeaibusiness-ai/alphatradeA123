// Lower-left card: buyer / seller pressure histogram (delta per candle) with percentage badges.
import { createChart, HistogramSeries } from 'lightweight-charts';
import { pageFont } from '../utils/cssVars.js';
import { h, esc, fmtCompact } from '../utils/dom.js';
import { icons } from './icons.js';
import { t } from '../i18n/index.js';
import { store } from '../state/store.js';

// The chart area is LTR; isolate the translated label so Arabic text and numbers do not reorder.
const deltaLabel = (d) => `<bdi>${esc(t('pressure.delta'))}</bdi>: <b class="${d.delta >= 0 ? 'up' : 'down'}">${d.delta >= 0 ? '+' : ''}${fmtCompact(d.delta)}</b>`;

export function createPressureCard() {
  const el = h(`<section class="card pressure-card fade-in" style="animation-delay:400ms">
    <div class="pc-head">
      <h3 class="card-title">${esc(t('pressure.title'))}</h3>
      <div class="pc-badges">
        <span class="pc-badge buy"><b class="mono" data-pc-buy>—</b><span>${esc(t('pressure.buyers'))}</span></span>
        <span class="pc-badge sell"><b class="mono" data-pc-sell>—</b><span>${esc(t('pressure.sellers'))}</span></span>
      </div>
    </div>
    <div class="pc-chart" dir="ltr"><div class="pc-host"></div><div class="pc-label mono" data-pc-label></div></div>
    <p class="pc-note" data-pc-note></p>
    <div class="pc-empty alert alert-info" data-pc-empty hidden>${icons.info}<div>${esc(t('pressure.noVolume'))}</div></div>
  </section>`);
  const host = el.querySelector('.pc-host');
  const dark = () => document.documentElement.dataset.theme !== 'light';
  const chart = createChart(host, {
    autoSize: true,
    layout: { background: { type: 'solid', color: 'transparent' }, textColor: dark() ? '#9b98b5' : '#5b5775', fontSize: 11, attributionLogo: false, fontFamily: pageFont() },
    grid: { vertLines: { visible: false }, horzLines: { color: 'rgba(148,130,255,.06)' } },
    rightPriceScale: { borderVisible: false, scaleMargins: { top: 0.12, bottom: 0.08 } },
    timeScale: { borderVisible: false, timeVisible: true },
    crosshair: { horzLine: { visible: false, labelVisible: false }, vertLine: { color: 'rgba(167,139,250,.4)', labelBackgroundColor: '#5b21b6' } },
    // Horizontal drag pans; vertical touch drags scroll the page instead of being captured.
    handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
    handleScale: true,
    localization: { locale: 'en-US' },
  });
  const series = chart.addSeries(HistogramSeries, { priceFormat: { type: 'volume' }, priceLineVisible: false, lastValueVisible: false, base: 0 });
  let data = [];

  chart.subscribeCrosshairMove((p) => {
    const lab = el.querySelector('[data-pc-label]');
    const d = p.time !== undefined ? data.find((x) => x.time === p.time) : data.at(-1);
    if (!d) { lab.textContent = ''; return; }
    lab.innerHTML = `${deltaLabel(d)} <span class="muted">· B ${fmtCompact(d.buy)} / S ${fmtCompact(d.sell)}</span>`;
  });

  return {
    el,
    /** Mirror the main chart's visible range so both histograms line up in time. */
    syncWith(mainChart) {
      mainChart.timeScale().subscribeVisibleLogicalRangeChange((r) => { if (r && data.length) chart.timeScale().setVisibleLogicalRange(r); });
    },
    update(an, mainRange) {
      const s = store.get('settings');
      const off = !s.pressure.enabled;
      el.classList.toggle('is-off', off);
      const empty = el.querySelector('[data-pc-empty]');
      if (!an || !an.pressure || off) {
        empty.querySelector('div').textContent = off ? `${t('ind.pressure')}: ${t('common.off')}` : t('pressure.noVolume');
        empty.hidden = false;
        el.querySelector('.pc-chart').hidden = true;
        el.querySelector('[data-pc-buy]').textContent = '—';
        el.querySelector('[data-pc-sell]').textContent = '—';
        el.querySelector('[data-pc-note]').textContent = '';
        data = [];
        return;
      }
      empty.hidden = true;
      el.querySelector('.pc-chart').hidden = false;
      data = an.pressure;
      series.setData(data.map((d) => ({ time: d.time, value: d.delta, color: d.delta >= 0 ? 'rgba(34,197,94,.85)' : 'rgba(240,68,79,.85)' })));
      if (mainRange) chart.timeScale().setVisibleLogicalRange(mainRange);
      const tot = an.pressureTotals;
      el.querySelector('[data-pc-buy]').textContent = tot ? `${Math.round(tot.buyPct)}%` : '—';
      el.querySelector('[data-pc-sell]').textContent = tot ? `${Math.round(tot.sellPct)}%` : '—';
      const basis = an.volumeKind === 'taker' ? t('ind.volTaker') : an.volumeKind === 'synthetic' ? t('ind.volDemo') : t('ind.volEstimated');
      el.querySelector('[data-pc-note]').textContent = `${t('ind.pressureWindow')}: ${s.pressure.window} · ${basis}`;
      const last = data.at(-1);
      el.querySelector('[data-pc-label]').innerHTML = last ? deltaLabel(last) : '';
    },
    refreshTheme() { chart.applyOptions({ layout: { textColor: dark() ? '#9b98b5' : '#5b5775' } }); },
    destroy() { chart.remove(); },
  };
}
