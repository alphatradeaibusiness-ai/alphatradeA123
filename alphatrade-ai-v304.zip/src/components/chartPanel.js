// Main chart card: symbol / timeframe / indicator controls, drawing toolbar, legend and status.
import { h, esc, fmtNum, fmtCompact, fmtTime } from '../utils/dom.js';
import { pageFont } from '../utils/cssVars.js';
import { gate } from './gate.js';
import { icons } from './icons.js';
import { TradingChart } from './chart/TradingChart.js';
import { INSTRUMENTS, getInstrument } from '../config/instruments.js';
import { TIMEFRAMES } from '../config/market.js';
import { store } from '../state/store.js';
import { aviewOn } from '../services/aview.js';
import { t, getLang, getDir } from '../i18n/index.js';
import { replayClass } from '../utils/motion.js';
import { setStrategy } from '../services/strategy.js';
import { toast } from './ui.js';

const TOOLS = [
  { id: 'cursor', icon: 'crosshair' },
  { id: 'trend', icon: 'trend' },
  { id: 'hline', icon: 'hline' },
  { id: 'fib', icon: 'fib' },
  { id: 'frvp', icon: 'frvp' },
  { id: 'measure', icon: 'ruler' },
  { id: 'text', icon: 'text' },
  { sep: true },
  { id: 'zoomIn', icon: 'zoomIn', action: true, key: 'chart.zoomIn' },
  { id: 'zoomOut', icon: 'zoomOut', action: true, key: 'chart.zoomOut' },
  { id: 'reset', icon: 'reset', action: true, key: 'chart.resetView' },
  { id: 'clear', icon: 'trash', action: true, key: 'chart.tools.clear' },
];

// Drawings survive re-renders (e.g. language switch), keyed by symbol.
const drawingsBySymbol = new Map();

export function createChartPanel({ onOpenIndicators, onOpenSettings, onFibPicked, onFrvpPicked }) {
  const el = h(`<section class="card chart-card fade-in" style="animation-delay:180ms" aria-label="Chart">
    <div class="chart-top">
      <div class="sym-picker">
        <button class="sym-btn" data-sym-btn aria-haspopup="listbox">${icons.search}<span class="mono" data-sym></span></button>
        <div class="sym-menu card" role="listbox" hidden>
          ${INSTRUMENTS.map((i) => `<button role="option" data-pick="${i.symbol}" class="mono">${i.symbol}</button>`).join('')}
        </div>
      </div>
      <div class="tf-group" role="group" aria-label="Timeframe">
        ${TIMEFRAMES.map((tf) => `<button class="tf-btn" data-tf="${tf.id}" title="${esc(t(`chart.tfLong.${tf.id}`))}">${esc(t(`chart.tf.${tf.id}`))}</button>`).join('')}
      </div>
      <span class="ct-sep"></span>
      <button class="ct-btn tools-toggle" data-tools-toggle aria-pressed="false" title="${esc(t('chart.toolsToggle'))}" aria-label="${esc(t('chart.toolsToggle'))}">${icons.trend}</button>
      <button class="ct-btn" data-chart-type title="${esc(t('settings.chartType'))}"></button>
      <button class="ct-btn ct-text" data-indicators>${icons.indicators}<span>${esc(t('chart.indicators'))}</span></button>
      <button class="ct-btn ct-smc" data-smc aria-pressed="false" title="Smart Money Concepts">${esc(t('smc.toggle'))}</button>
      <button class="ct-btn ct-smc ct-edh" data-edh aria-pressed="false" title="${esc(t('ed.tip'))}">EDH</button>
      <button class="ct-btn ct-smc ct-zone" data-zone aria-pressed="false" title="${esc(t('zs.tip'))}">${esc(t('zs.toggle'))}</button>
      <button class="ct-btn ct-smc ct-liq" data-liq aria-pressed="false" title="${esc(t('liq.tip'))}">${esc(t('liq.toggle'))}</button>
      <button class="ct-btn ct-smc ct-clean" data-clean aria-pressed="false" title="${esc(t('chart.cleanTip'))}">${esc(t('chart.clean'))}</button>
      <button class="ct-btn ct-ai" data-ai aria-pressed="false" title="${esc(t('aie.tip'))}">${icons.brain}<span>${esc(t('aie.toggle'))}</span></button>
      <button class="ct-btn" data-reset title="${esc(t('chart.resetView'))}" aria-label="${esc(t('chart.resetView'))}">${icons.reset}</button>
      <span class="ct-spacer"></span>
      <span class="ct-status" data-status></span>
      <button class="ct-btn" data-settings title="${esc(t('chart.settings'))}" aria-label="${esc(t('chart.settings'))}">${icons.settings}</button>
      <button class="ct-btn" data-shot title="${esc(t('chart.screenshot'))}" aria-label="${esc(t('chart.screenshot'))}">${icons.camera}</button>
    </div>
    <div class="chart-body">
      <div class="chart-tools" role="toolbar" aria-label="Drawing tools">
        ${TOOLS.map((tl) => (tl.sep ? '<span class="tool-sep"></span>' : `<button class="tool-btn${tl.id === 'cursor' ? ' is-active' : ''}" data-tool="${tl.id}" ${tl.action ? 'data-action' : ''} title="${esc(t(tl.key || `chart.tools.${tl.id}`))}" aria-label="${esc(t(tl.key || `chart.tools.${tl.id}`))}">${icons[tl.icon]}</button>`)).join('')}
      </div>
      <div class="chart-stage" dir="ltr">
        <div class="chart-host"></div>
        <div class="legend">
          <div class="lg-1"><span class="lg-sym" data-lg-title></span><span class="dot" data-lg-dot></span><span data-lg-mode></span></div>
          <div class="lg-2 mono" data-lg-ohlc></div>
        </div>
        <div class="pane-label" data-vol-label hidden></div>
        <div class="pane-label" data-rsi-label hidden></div>
        <button type="button" class="ai-chip" data-ai-chip hidden></button>
        <div class="cd-badge" data-cd hidden><span class="cd-ico" aria-hidden="true"></span><b class="mono" data-cd-text></b></div>
        <div class="chart-hint" data-hint hidden></div>
        <div class="chart-notice" data-notice hidden></div>
        <div class="chart-loading" data-loading hidden><span class="spinner"></span><span data-loading-text></span></div>
        <div class="chart-error" data-error hidden><div class="alert alert-error">${icons.alert}<div data-error-text></div></div><button class="btn btn-sm" data-retry>${esc(t('common.retry'))}</button></div>
      </div>
    </div>
  </section>`);


  const host = el.querySelector('.chart-host');
  const $ = (s) => el.querySelector(s);
  let dataset = null;
  let analysis = null;
  let onRetry = null;
  let lastBarIdx = -1;

  const symbolDrawings = () => {
    const s = store.get('symbol');
    if (!drawingsBySymbol.has(s)) drawingsBySymbol.set(s, []);
    return drawingsBySymbol.get(s);
  };

  const chart = new TradingChart(host, {
    onCrosshair: (bar, idx) => renderLegend(bar, idx),
    onRangeChange: () => { positionPaneLabels(); syncZoomButtons(); },
    onToolDone: () => setToolUi('cursor'),
    onPick: (tool, pts) => {
      const [a, b] = pts;
      if (tool === 'trend' || tool === 'measure') {
        const list = symbolDrawings().filter((d) => tool !== 'measure' || d.type !== 'measure');
        list.push({ type: tool, a, b });
        drawingsBySymbol.set(store.get('symbol'), list);
      } else if (tool === 'hline') symbolDrawings().push({ type: 'hline', a });
      else if (tool === 'text') {
        // Inline note editor (browser prompt() is blocked in embedded/sandboxed views).
        const stage = el.querySelector('.chart-stage');
        const rect = stage.getBoundingClientRect();
        const x = chart.chart.timeScale().logicalToCoordinate(a.logical) ?? 40;
        const y = chart.candleSeries.priceToCoordinate(a.price) ?? 40;
        const box = document.createElement('input');
        box.className = 'note-input';
        box.placeholder = t('chart.textPrompt');
        box.maxLength = 80;
        box.dir = 'auto';
        box.style.left = `${Math.min(Math.max(4, x), rect.width - 190)}px`;
        box.style.top = `${Math.max(4, y - 16)}px`;
        stage.append(box);
        box.focus();
        let done = false;
        const commit = (save) => {
          if (done) return;
          done = true;
          const text = box.value.trim();
          box.remove();
          if (save && text) { symbolDrawings().push({ type: 'text', a, text }); chart.setDrawings(symbolDrawings()); }
        };
        box.addEventListener('keydown', (e) => { if (e.key === 'Enter') commit(true); if (e.key === 'Escape') commit(false); });
        box.addEventListener('blur', () => commit(true));
      } else if (tool === 'fib') {
        const hi = a.price >= b.price ? a : b;
        const lo = hi === a ? b : a;
        onFibPicked?.({ high: hi.price, highTime: hi.time, low: lo.price, lowTime: lo.time });
      } else if (tool === 'frvp') onFrvpPicked?.({ from: Math.min(a.time, b.time), to: Math.max(a.time, b.time) });
      chart.setDrawings(symbolDrawings());
    },
  });

  function syncZoomButtons() {
    for (const [id, dir] of [['zoomIn', 'in'], ['zoomOut', 'out']]) {
      const b = el.querySelector(`[data-tool="${id}"]`);
      const can = chart.canZoom(dir);
      b.classList.toggle('is-limit', !can);
      b.setAttribute('aria-disabled', String(!can));
    }
  }

  function setToolUi(tool) {
    el.querySelectorAll('.tool-btn:not([data-action])').forEach((b) => b.classList.toggle('is-active', b.dataset.tool === tool));
    const hint = $('[data-hint]');
    hint.hidden = tool === 'cursor';
    if (tool !== 'cursor') hint.textContent = t(`chart.pickHint.${tool}`);
  }

  // Toolbar
  el.querySelector('.chart-tools').addEventListener('click', (e) => {
    const b = e.target.closest('.tool-btn');
    if (b && window.matchMedia('(max-width: 640px)').matches) { el.querySelector('.chart-body').classList.remove('tools-open'); $('[data-tools-toggle]').classList.remove('is-on'); }
    if (!b) return;
    const id = b.dataset.tool;
    if (id === 'zoomIn') chart.zoom(0.6);
    else if (id === 'zoomOut') chart.zoom(1 / 0.6);
    else if (id === 'reset') chart.resetView();
    else if (id === 'clear') { drawingsBySymbol.set(store.get('symbol'), []); chart.setDrawings([]); }
    else {
      const next = chart.tool === id ? 'cursor' : id;
      chart.setTool(next);
      setToolUi(next);
    }
  });


  const globalAbort = new AbortController();   // window / document listeners of this panel, removed in destroy()
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && chart.tool !== 'cursor') { chart.setTool('cursor'); setToolUi('cursor'); }
  }, { signal: globalAbort.signal });

  // Top controls
  const symMenu = $('.sym-menu');
  $('[data-sym-btn]').addEventListener('click', (e) => {
    e.stopPropagation();
    // The top bar scrolls horizontally on small screens, so the menu is fixed-positioned.
    const r = e.currentTarget.getBoundingClientRect();
    symMenu.style.top = `${r.bottom}px`;
    symMenu.style.left = `${Math.min(r.left, window.innerWidth - 180)}px`;
    symMenu.hidden = !symMenu.hidden;
  });
  window.addEventListener('scroll', () => { symMenu.hidden = true; }, { passive: true, signal: globalAbort.signal });
  symMenu.addEventListener('click', (e) => { const b = e.target.closest('[data-pick]'); if (b) { store.set('symbol', b.dataset.pick); symMenu.hidden = true; } });
  document.addEventListener('click', () => { symMenu.hidden = true; }, { signal: globalAbort.signal });
  el.querySelectorAll('[data-tf]').forEach((b) => b.addEventListener('click', () => store.set('timeframe', b.dataset.tf)));
  $('[data-chart-type]').addEventListener('click', () => store.updateSettings('chartType', store.get('settings').chartType === 'line' ? 'candles' : 'line'));
  $('[data-tools-toggle]').addEventListener('click', () => { const open = el.querySelector('.chart-body').classList.toggle('tools-open'); $('[data-tools-toggle]').classList.toggle('is-on', open); $('[data-tools-toggle]').setAttribute('aria-pressed', String(open)); });
  $('[data-clean]').addEventListener('click', () => store.updateSettings('chartClean', store.get('settings').chartClean === false));
  $('[data-liq]').addEventListener('click', () => store.updateSettings('liqMap', !store.get('settings').liqMap));
  $('[data-indicators]').addEventListener('click', () => onOpenIndicators?.());
  $('[data-smc]').addEventListener('click', () => {
    const on = store.get('settings').strategy !== 'smc';
    if (on && !gate('strategies')) return;
    setStrategy(on ? 'smc' : 'classic');
    setTimeout(() => (on ? chart.focusSmc() : chart.resetView()), 60);
    toast(t(on ? 'smc.on' : 'smc.off'), 'info', 3500);
  });
  $('[data-zone]').addEventListener('click', () => {
    const on = store.get('settings').strategy !== 'zone';
    if (on && !gate('strategies')) return;
    setStrategy(on ? 'zone' : 'classic');
    setTimeout(() => chart.resetView(), 60);
    toast(t(on ? 'zs.on' : 'zs.off'), 'info', 4500);
  });
  $('[data-edh]').addEventListener('click', () => {
    const on = store.get('settings').strategy !== 'edh';
    if (on && !gate('strategies')) return;
    setStrategy(on ? 'edh' : 'classic');
    setTimeout(() => chart.resetView(), 60);
    toast(t(on ? 'ed.on' : 'ed.off'), 'info', 4500);
  });
  $('[data-ai]').addEventListener('click', () => {
    const on = store.get('settings').ai?.enabled === false;
    store.updateSettings('ai', { enabled: on });
    toast(t(on ? 'aie.on' : 'aie.off'), 'info', 3500);
  });
  $('[data-ai-chip]').addEventListener('click', () => document.querySelector('.ai-card')?.scrollIntoView({ behavior: 'smooth', block: 'center' }));
  $('[data-settings]').addEventListener('click', () => onOpenSettings?.());
  $('[data-reset]').addEventListener('click', () => chart.resetView());
  $('[data-shot]').addEventListener('click', () => chart.screenshot(`${store.get('symbol')}-${store.get('timeframe')}.png`));
  $('[data-retry]').addEventListener('click', () => onRetry?.());

  /** Hide symbols the data provider does not serve for this key. */
  function setUnavailable(symbols) {
    symMenu.querySelectorAll('[data-pick]').forEach((b) => { b.hidden = symbols.includes(b.dataset.pick); });
  }

  function syncControls() {
    $('[data-sym]').textContent = store.get('symbol');
    el.querySelectorAll('[data-tf]').forEach((b) => b.classList.toggle('is-active', b.dataset.tf === store.get('timeframe')));
    const type = store.get('settings').chartType;
    const smcOn = store.get('settings').strategy === 'smc';
    $('[data-smc]').classList.toggle('is-on', smcOn);
    $('[data-smc]').setAttribute('aria-pressed', String(smcOn));
    const zoneOn = store.get('settings').strategy === 'zone';
    $('[data-zone]').classList.toggle('is-on', zoneOn);
    $('[data-zone]').setAttribute('aria-pressed', String(zoneOn));
    const edhOn = store.get('settings').strategy === 'edh';
    $('[data-edh]').classList.toggle('is-on', edhOn);
    $('[data-edh]').setAttribute('aria-pressed', String(edhOn));
    const cleanOn = store.get('settings').chartClean !== false;
    $('[data-clean]').classList.toggle('is-on', cleanOn);
    { const liqOn = Boolean(store.get('settings').liqMap); $('[data-liq]').classList.toggle('is-on', liqOn); $('[data-liq]').setAttribute('aria-pressed', String(liqOn)); }
    $('[data-clean]').setAttribute('aria-pressed', String(cleanOn));
    const aiOn = store.get('settings').ai?.enabled !== false;
    $('[data-ai]').classList.toggle('is-on', aiOn);
    $('[data-ai]').setAttribute('aria-pressed', String(aiOn));
    $('[data-chart-type]').innerHTML = type === 'line' ? icons.lineChart : icons.candles;
  }
  syncControls();

  function renderLegend(bar, idx) {
    if (!dataset) return;
    const inst = getInstrument(dataset.symbol);
    const b = bar || dataset.candles.at(-1);
    const i = bar ? idx : dataset.candles.length - 1;
    if (!b) return;
    if (i === lastBarIdx && bar) return;
    lastBarIdx = bar ? i : -1;
    const prev = dataset.candles[i - 1];
    const ch = prev ? b.close - prev.close : 0;
    const pct = prev ? (ch / prev.close) * 100 : 0;
    const cls = ch >= 0 ? 'up' : 'down';
    const p = (v) => fmtNum(v, inst.precision);
    $('[data-lg-ohlc]').innerHTML = `<span class="ohl">O<span class="${cls}">${p(b.open)}</span> H<span class="${cls}">${p(b.high)}</span> L<span class="${cls}">${p(b.low)}</span></span> C<span class="${cls}">${p(b.close)}</span> <span class="${cls}">${ch >= 0 ? '+' : ''}${p(ch)} (${ch >= 0 ? '+' : ''}${pct.toFixed(2)}%)</span>`;
    const volLabel = $('[data-vol-label]');
    if (!volLabel.hidden) volLabel.innerHTML = `<span dir="${getDir()}">${esc(t('chart.volume'))}</span> <b class="${cls}">${fmtCompact(b.volume)}</b>`;
    const rsiLabel = $('[data-rsi-label]');
    if (!rsiLabel.hidden && analysis) {
      const v = analysis.rsi[i];
      rsiLabel.innerHTML = `RSI ${store.get('settings').rsi.period} <b style="color:var(--purple-3)">${Number.isFinite(v) ? v.toFixed(1) : '—'}</b>`;
    }
  }

  function positionPaneLabels() {
    const tops = chart.paneTops();
    const vl = $('[data-vol-label]');
    const rl = $('[data-rsi-label]');
    vl.hidden = tops.volume == null;
    rl.hidden = tops.rsi == null;
    if (tops.volume != null) vl.style.top = `${tops.volume + 4}px`;
    if (tops.rsi != null) rl.style.top = `${tops.rsi + 4}px`;
  }

  /** Small on-chart badge: success chance of the current/best setup (and whether the model has proven skill). */
  function renderAiChip(an, s) {
    const chip = $('[data-ai-chip]');
    const on = s.ai?.enabled !== false;
    const ai = an?.ai;
    if (!on || !ai?.ready || !ai.m) { chip.hidden = true; return; }
    const m = ai.m;
    const pct = Math.round(m.p * 100);
    const long = ai.side === 'long';
    chip.hidden = false;
    chip.className = `ai-chip ${long ? 'is-long' : 'is-short'}${m.edge ? '' : ' is-base'}`;
    chip.style.setProperty('--p', pct);
    chip.innerHTML = `<span class="ai-ring"><i>${long ? '▲' : '▼'}</i></span><span class="ai-txt"><b class="mono">${pct}<small>%</small></b><em>${esc(t(long ? 'aie.buyWord' : 'aie.sellWord'))}</em></span><span class="ai-sub">${esc(m.edge ? `${t('aie.quality')} ${m.grade}` : t('aie.baseTag'))}</span>`;
    chip.title = `${t('aie.title')}, ${t(long ? 'common.long' : 'common.short')}`;
  }

  function renderStatus() {
    if (!dataset) return;
    const live = dataset.mode === 'live';
    $('[data-lg-title]').textContent = `${dataset.symbol} · ${dataset.tf} · ${dataset.source.toUpperCase()}`;
    $('[data-lg-dot]').className = `dot ${live ? 'ok' : 'warn'}`;
    $('[data-lg-mode]').innerHTML = live ? `<span class="badge badge-live">${esc(t('common.live'))}</span>` : `<span class="badge badge-demo">${esc(t('common.demo'))}</span>`;
    $('[data-status]').innerHTML = `<span class="muted">${esc(t('common.lastUpdate'))}:</span> <span class="mono">${fmtTime(dataset.fetchedAt, getLang())}</span>`;
  }

  return {
    el,
    chart,
    syncControls,
    setUnavailable,
    showLoading(symbol) {
      $('[data-loading]').hidden = false;
      $('[data-loading-text]').textContent = t('chart.loadingData', { symbol });
      $('[data-error]').hidden = true;
      el.querySelector('.chart-stage').classList.add('is-busy');
    },
    showError(message, retry) {
      $('[data-loading]').hidden = true;
      $('[data-error]').hidden = false;
      $('[data-error-text]').textContent = message;
      onRetry = retry;
      el.querySelector('.chart-stage').classList.remove('is-busy');
    },
    setData(ds, an, { keepRange = false } = {}) {
      const changed = !dataset || dataset.symbol !== ds.symbol || dataset.tf !== ds.tf;
      dataset = ds;
      analysis = an;
      $('[data-loading]').hidden = true;
      $('[data-error]').hidden = true;
      const stage = el.querySelector('.chart-stage');
      stage.classList.remove('is-busy');
      if (changed) replayClass(stage, 'swap'); // short fade/rise of the chart on symbol or timeframe change
      const inst = getInstrument(ds.symbol);
      chart.setData(ds, { keepRange: keepRange && !changed, precision: inst.precision, chartType: store.get('settings').chartType });
      this.setAnalysis(an);
      chart.setDrawings(symbolDrawings());
      renderStatus();
      syncControls();
    },
    /** Real-time tick: refresh analysis overlays and the status line (the candle itself is painted by paintBar). */
    liveUpdate(ds, an) {
      if (!dataset || ds !== dataset) return;
      this.setAnalysis(an);
      renderStatus();
    },
    /** An already-closed candle got its final values: redraw the series without touching the view. */
    refreshBars(ds) {
      if (!dataset || ds !== dataset) return;
      chart.redrawCandles();
    },
    /** Draws the forming candle right now (called once per animation frame while the price moves). */
    paintBar(ds, bar) {
      if (!dataset || ds !== dataset) return;
      chart.updateLast(bar);
      if (globalThis.__PAINT_PROBE) globalThis.__paints = (globalThis.__paints || 0) + 1;
    },
    /** Countdown to the candle close: text, urgency (0 calm · 1 under 30 s · 2 under 10 s) and the price it sits under. */
    setCountdown(text, level = 0, price = null) {
      const cdH = (this._cdH ||= { t: 0, v: 0 });
      const cd = $('[data-cd]');
      if (text == null) { cd.hidden = true; return; }
      cd.hidden = false;
      const tx = $('[data-cd-text]');
      if (tx.textContent !== text) tx.textContent = text;
      if (cd.dataset.level !== String(level)) cd.dataset.level = String(level);
      if (price != null) {
        const y = chart.candleSeries.priceToCoordinate(price);
        // clientHeight forces a layout every frame; the height barely changes, so read it twice a second.
        const now = performance.now();
        if (!cdH.t || now - cdH.t > 500) { cdH.v = host.clientHeight; cdH.t = now; }
        if (y != null && Number.isFinite(y)) {
          const tr = `translateY(${Math.round(Math.min(Math.max(y + 13, 4), Math.max(40, cdH.v * 0.72)))}px)`;
          if (cd.style.transform !== tr) cd.style.transform = tr;
        }
      }
    },
    setAnalysis(an) {
      analysis = an;
      const s = store.get('settings');
      renderAiChip(an, s);
      chart.setRsi(an?.rsi, s.rsi);
      chart.setEma(an?.ema20, an?.ema50, s.ema.enabled);
      chart.setBb(an?.bb, Boolean(s.bb?.enabled || aviewOn(s)));
      chart.setChartType(s.chartType);
      chart.setOverlays({
        analysis: an,
        settings: s,
        rtl: getDir() === 'rtl',
        font: pageFont(),
        labels: {
          sell: t('chart.sellZone'), buy: t('chart.buyZone'), entry: t('chart.entry'), be: t('chart.beShort'), proposal: t('aie.proposalShort'), stop: t('chart.stopLoss'), stopShort: t('chart.stopShort'),
          fibSell: t('fs.sell'), fibBuy: t('fs.buy'), fibLive: t('fs.live'), fibStrong: t('fs.strong'),
          fibKind: (k) => t(`fs.kind.${k}`), fibSide: (s) => t(`fs.${s}`),
          tp: (n) => t('chart.tp', { n }), measure: (diff, pct, bars) => t('chart.measureResult', { diff, pct, bars }),
        },
      });
      const notice = $('[data-notice]');
      notice.hidden = Boolean(an?.hasVolume);
      notice.textContent = an?.hasVolume ? '' : t('chart.noVolume');
      requestAnimationFrame(() => {
        positionPaneLabels();
        lastBarIdx = -2;
        renderLegend(null);
        const lg = el.querySelector('.legend');
        const chip = $('[data-ai-chip]');
        chart.overlay.set({ avoid: { w: lg.offsetLeft + lg.offsetWidth, h: lg.offsetTop + lg.offsetHeight }, avoidR: chip && !chip.hidden ? { h: chip.offsetTop + chip.offsetHeight } : null });
      });
      syncControls();
    },
    refreshTheme() { chart.applyTheme(); },
    destroy() { globalAbort.abort(); chart.destroy(); },
  };
}
