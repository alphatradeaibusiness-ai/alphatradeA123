import { cssVar, pageFont } from '../../utils/cssVars.js';
// Wrapper around TradingView Lightweight Charts (https://github.com/tradingview/lightweight-charts, Apache-2.0).
// Panes: 0 = price (+ overlay primitive), 1 = volume (when the source has volume), 2 = RSI (when enabled).
import { createChart, CandlestickSeries, LineSeries, HistogramSeries, CrosshairMode, LineStyle } from 'lightweight-charts';
import { ChartOverlay, syncAccent } from './overlay.js';
import { volumeProfile } from '../../indicators/index.js';
import { aviewOn } from '../../services/aview.js';
import { debounce, fmtNum } from '../../utils/dom.js';

export class TradingChart {
  /**
   * @param {HTMLElement} el
   * @param {{ onPick?:(tool, points)=>void, onCrosshair?:(bar, idx)=>void, onToolDone?:()=>void, onRangeChange?:()=>void }} hooks
   */
  constructor(el, hooks = {}) {
    this.el = el;
    // v230: the chart's width comes from a ResizeObserver. Reading el.clientWidth while the page was being built forced the
    // browser to lay out the whole app on the spot (≈430 ms on a phone after a language switch or sign-in).
    this._w = 0;
    if (typeof ResizeObserver !== 'undefined') {
      this._ro = new ResizeObserver((entries) => {
        const w = Math.round(entries[entries.length - 1].contentRect.width); if (!w) return;
        const was = this._w ? this._w < 520 : null; this._w = w;
        if (was !== null && was !== (w < 520) && this.chart) this._layoutPanes();
      });
      this._ro.observe(el);
    }
    this.hooks = hooks;
    this.candles = [];
    this.tool = 'cursor';
    this.pending = [];
    this.settings = null;
    this.precision = 2;
    this.chart = createChart(el, this._options());
    this.candleSeries = this.chart.addSeries(CandlestickSeries, {
      upColor: '#22c55e', downColor: '#f0444f', borderVisible: false, wickUpColor: '#22c55e', wickDownColor: '#f0444f',
      priceLineColor: '#22c55e', priceLineStyle: LineStyle.Dotted,
    });
    this.lineSeries = null;
    this.volumeSeries = null;
    this.rsiSeries = null;
    this.overlay = new ChartOverlay();
    el.__tradingChart = this; // handle for automated UI tests
    this.candleSeries.attachPrimitive(this.overlay);

    // Tool clicks are read from pointer events directly: the library swallows a second click
    // made within 500 ms (double-click detection), which breaks quick two-point picking.
    this._down = null;
    this._onDown = (e) => { this._down = { x: e.clientX, y: e.clientY }; };
    this._onUp = (e) => this._handlePointerUp(e);
    el.addEventListener('pointerdown', this._onDown, true);
    el.addEventListener('pointerup', this._onUp, true);
    this._onMove = (p) => this._handleMove(p);
    this.chart.subscribeCrosshairMove(this._onMove);
    this._onRange = debounce(() => { this._updateVisibleVP(); this.hooks.onRangeChange?.(); }, 120);
    this.chart.timeScale().subscribeVisibleLogicalRangeChange(this._onRange);
  }

  _accent() {
    const g = (n, d) => cssVar(n, d);   // cached per theme (v230): no style recalc on every chart build
    return { rgb0: g('--a0-rgb', '124, 58, 237'), rgb1: g('--a1-rgb', '139, 92, 246'), rgb3: g('--a3-rgb', '192, 132, 252'), a0: g('--a0', '#7c3aed'), light: g('--purple-3', '#a78bfa') };
  }

  _options() {
    const dark = document.documentElement.dataset.theme !== 'light';
    const ac = this._accent();
    syncAccent();
    const grid = dark ? `rgba(${ac.rgb3}, 0.06)` : `rgba(${ac.rgb0}, 0.07)`;
    return {
      autoSize: true,
      layout: {
        background: { type: 'solid', color: 'transparent' },
        textColor: dark ? '#9b98b5' : '#5b5775',
        fontFamily: pageFont(),
        fontSize: this._width() < 520 ? 10 : 11,
        attributionLogo: true,
        panes: { separatorColor: dark ? `rgba(${ac.rgb3},.14)` : `rgba(${ac.rgb0},.14)`, separatorHoverColor: `rgba(${ac.rgb1},.25)`, enableResize: true },
      },
      grid: { vertLines: { color: grid }, horzLines: { color: grid } },
      crosshair: { mode: CrosshairMode.Normal, vertLine: { color: `rgba(${ac.rgb3},.5)`, labelBackgroundColor: ac.a0 }, horzLine: { color: `rgba(${ac.rgb3},.5)`, labelBackgroundColor: ac.a0 } },
      rightPriceScale: { borderColor: dark ? 'rgba(148,130,255,.14)' : 'rgba(91,33,182,.14)', scaleMargins: { top: 0.13, bottom: 0.06 } },
      timeScale: { borderColor: dark ? 'rgba(148,130,255,.14)' : 'rgba(91,33,182,.14)', timeVisible: true, secondsVisible: false, rightOffset: 10, barSpacing: 7, minBarSpacing: 1.2 },
      localization: { locale: 'en-US', priceFormatter: (p) => this.fmt(p) },
      handleScale: { axisPressedMouseMove: true, mouseWheel: true, pinch: true },
      // Horizontal drag pans the chart (mouse and touch); vertical touch drags scroll the page.
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
      kineticScroll: { touch: true, mouse: true },
    };
  }

  fmt(v) {
    if (!Number.isFinite(v)) return '';
    return fmtNum(v, this.precision);   // cached Intl formatter: the price axis calls this hundreds of times per frame
  }

  applyTheme() { this.chart.applyOptions(this._options()); }

  /** Replace data. keepRange keeps the user's zoom/pan (used for periodic refreshes). */
  setData(dataset, { keepRange = false, precision = 2, chartType = 'candles' } = {}) {
    const range = keepRange ? this.chart.timeScale().getVisibleLogicalRange() : null;
    this.precision = precision;
    this.dataset = dataset;
    this.candles = dataset.candles;
    this.candleSeries.applyOptions({ priceFormat: { type: 'price', precision, minMove: 1 / 10 ** precision } });
    this.candleSeries.setData(this.candles.map(({ time, open, high, low, close }) => ({ time, open, high, low, close })));
    this.setChartType(chartType);
    this._syncVolume();
    this.overlay.set({ candles: this.candles, fmt: (v) => this.fmt(v) });
    if (range) this.chart.timeScale().setVisibleLogicalRange(range);
    else this.resetView();
  }

  /** Redraw all candles from this.candles (a closed candle changed) keeping the zoom/pan. */
  redrawCandles() {
    const range = this.chart.timeScale().getVisibleLogicalRange();
    this.candleSeries.setData(this.candles.map(({ time, open, high, low, close }) => ({ time, open, high, low, close })));
    this.lineSeries?.setData(this.candles.map((c) => ({ time: c.time, value: c.close })));
    if (range) this.chart.timeScale().setVisibleLogicalRange(range);
    this.overlay.set({ candles: this.candles });
  }

  /** Live update of the forming (or a new) last candle without resetting the view. */
  updateLast(bar) {
    this.candleSeries.update({ time: bar.time, open: bar.open, high: bar.high, low: bar.low, close: bar.close });
    this.lineSeries?.update({ time: bar.time, value: bar.close });
    if (this.volumeSeries && Number.isFinite(bar.volume)) {
      this.volumeSeries.update({ time: bar.time, value: bar.volume, color: bar.close >= bar.open ? 'rgba(34,197,94,.55)' : 'rgba(240,68,79,.55)' });
    }
    this.overlay.set({ candles: this.candles });
  }

  setChartType(type) {
    if (type === 'line') {
      if (!this.lineSeries) this.lineSeries = this.chart.addSeries(LineSeries, { color: this._accent().light, lineWidth: 2, priceLineVisible: false, lastValueVisible: true }, 0);
      this.lineSeries.setData(this.candles.map((c) => ({ time: c.time, value: c.close })));
      this.candleSeries.applyOptions({ visible: false });
    } else {
      if (this.lineSeries) { this.chart.removeSeries(this.lineSeries); this.lineSeries = null; }
      this.candleSeries.applyOptions({ visible: true });
    }
  }

  _syncVolume() {
    const hasVol = this.dataset && this.dataset.volumeKind !== 'none' && this.candles.some((c) => Number.isFinite(c.volume));
    if (hasVol) {
      if (!this.volumeSeries) {
        // Keep pane order price → volume → RSI: drop RSI; the caller re-adds it via setRsi().
        if (this.rsiSeries) { this.chart.removeSeries(this.rsiSeries); this.rsiSeries = null; this.rsiLines = null; }
        this.volumeSeries = this.chart.addSeries(HistogramSeries, { priceFormat: { type: 'volume' }, priceLineVisible: false, lastValueVisible: false }, 1);
      }
      this.volumeSeries.setData(this.candles.map((c) => ({ time: c.time, value: c.volume ?? 0, color: c.close >= c.open ? 'rgba(34,197,94,.55)' : 'rgba(240,68,79,.55)' })));
    } else if (this.volumeSeries) {
      this.chart.removeSeries(this.volumeSeries);
      this.volumeSeries = null;
    }
    this._layoutPanes();
  }

  /** EMA 20 / 50 overlays on the price pane. */
  setEma(e20, e50, enabled) {
    if (!enabled || !e20) {
      (this.emaSeries || []).forEach((x) => this.chart.removeSeries(x));
      this.emaSeries = null;
      return;
    }
    if (!this.emaSeries) {
      const opts = (color) => ({ color, lineWidth: 1.4, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false });
      this.emaSeries = [this.chart.addSeries(LineSeries, opts('#f59e0b'), 0), this.chart.addSeries(LineSeries, opts('#38bdf8'), 0)];
    }
    [e20, e50].forEach((vals, k) => this.emaSeries[k].setData(this.candles.map((c, i) => (vals[i] == null ? { time: c.time } : { time: c.time, value: vals[i] }))));
  }

  /** Bollinger Bands (upper / middle / lower) on the price pane. */
  setBb(bb, enabled) {
    if (!enabled || !bb) {
      (this.bbSeries || []).forEach((x) => this.chart.removeSeries(x));
      this.bbSeries = null;
      return;
    }
    if (!this.bbSeries) {
      const opts = (color, style) => ({ color, lineWidth: 1, lineStyle: style, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false });
      this.bbSeries = [this.chart.addSeries(LineSeries, opts('rgba(167,139,250,.85)', LineStyle.Solid), 0), this.chart.addSeries(LineSeries, opts('rgba(167,139,250,.5)', LineStyle.Dotted), 0), this.chart.addSeries(LineSeries, opts('rgba(167,139,250,.85)', LineStyle.Solid), 0)];
    }
    [bb.upper, bb.mid, bb.lower].forEach((vals, k) => this.bbSeries[k].setData(this.candles.map((c, i) => (vals[i] == null ? { time: c.time } : { time: c.time, value: vals[i] }))));
  }

  /** RSI pane on/off + data. */
  setRsi(values, cfg) {
    if (!cfg?.enabled || !values) {
      if (this.rsiSeries) { this.chart.removeSeries(this.rsiSeries); this.rsiSeries = null; this.rsiLines = null; }
      this._layoutPanes();
      return;
    }
    const paneIndex = this.volumeSeries ? 2 : 1;
    if (!this.rsiSeries) {
      this.rsiSeries = this.chart.addSeries(LineSeries, { color: this._accent().light, lineWidth: 1.6, priceLineVisible: false, lastValueVisible: true, priceFormat: { type: 'price', precision: 1, minMove: 0.1 }, autoscaleInfoProvider: () => ({ priceRange: { minValue: 0, maxValue: 100 } }) }, paneIndex);
    }
    if (this.rsiLines) this.rsiLines.forEach((l) => this.rsiSeries.removePriceLine(l));
    this.rsiLines = [
      this.rsiSeries.createPriceLine({ price: cfg.overbought, color: 'rgba(240,68,79,.7)', lineStyle: LineStyle.Dashed, lineWidth: 1, axisLabelVisible: true, title: '' }),
      this.rsiSeries.createPriceLine({ price: 50, color: 'rgba(148,163,184,.35)', lineStyle: LineStyle.Dotted, lineWidth: 1, axisLabelVisible: false, title: '' }),
      this.rsiSeries.createPriceLine({ price: cfg.oversold, color: 'rgba(34,197,94,.7)', lineStyle: LineStyle.Dashed, lineWidth: 1, axisLabelVisible: true, title: '' }),
    ];
    this.rsiSeries.setData(this.candles.map((c, i) => (values[i] == null ? { time: c.time } : { time: c.time, value: values[i] })));
    this._layoutPanes();
  }

  /** Width of the chart without forcing a layout: last ResizeObserver size, else the window width (same on a phone). */
  _width() { return this._w || (typeof window !== 'undefined' ? window.innerWidth : 999); }

  _layoutPanes() {
    const panes = this.chart.panes();
    if (!panes.length) return;
    panes[0].setStretchFactor(1);
    let i = 1;
    const phone = this._width() < 520;
    if (this.volumeSeries && panes[i]) { panes[i].setStretchFactor(phone ? 0.14 : 0.2); i++; }
    if (this.rsiSeries && panes[i]) panes[i].setStretchFactor(phone ? 0.2 : 0.26);
  }

  /** Pixel offsets of the volume / RSI panes (for HTML labels). */
  paneTops() {
    const panes = this.chart.panes();
    const tops = [];
    let y = 0;
    for (const p of panes) { tops.push(y); y += p.getHeight() + 1; }
    return { volume: this.volumeSeries ? tops[1] : null, rsi: this.rsiSeries ? tops[this.volumeSeries ? 2 : 1] : null };
  }

  /** Push analysis overlays (zones, fib, plan, VP, FRVP) to the primitive. */
  setOverlays({ analysis, settings, labels, rtl, font }) {
    this.settings = settings;
    this.analysis = analysis;
    const a = analysis || {};
    const lastTime = this.candles.at(-1)?.time;
    const fromIdx = Math.max(0, this.candles.length - 60);
    let frvp = null;
    if (settings.frvp.enabled && settings.frvp.from && settings.frvp.to && a.hasVolume && (!settings.frvp.symbol || settings.frvp.symbol === this.dataset?.symbol)) {
      const i0 = this._indexOf(Math.min(settings.frvp.from, settings.frvp.to));
      const i1 = this._indexOf(Math.max(settings.frvp.from, settings.frvp.to));
      const profile = volumeProfile(this.candles, { rows: settings.frvp.rows, from: i0, to: i1 });
      frvp = profile ? { profile } : null;
    }
    this.frvpProfile = frvp?.profile || null;
    this.overlay.set({
      rtl, labels, font,
      clean: settings.chartClean !== false,
      showZones: settings.zones.enabled, showFib: settings.fib.enabled, showPlan: settings.planLines.enabled, showPoc: settings.vp.showPoc,
      // Narrow screens: keep the profile slim so candles keep most of the width.
      vpWidthPct: this._width() < 520 ? Math.min(settings.vp.widthPct, 11) : (settings.chartClean !== false ? Math.min(settings.vp.widthPct, 13) : settings.vp.widthPct),
      zones: a.zones && a.fib ? (() => {
        // Zones start at the earlier swing point so both stay visible even when one anchor is the latest bar.
        const from = Math.min(a.fib.highTime ?? lastTime, a.fib.lowTime ?? lastTime);
        return { sell: { ...a.zones.sell, fromTime: from }, buy: { ...a.zones.buy, fromTime: from } };
      })() : null,
      fib: a.fib ? { levels: a.fib.levels.filter((l) => settings.fib.levels?.includes(l.ratio) ?? true), fromTime: Math.min(a.fib.highTime ?? Infinity, a.fib.lowTime ?? Infinity) } : null,
      fibSig: settings.fib.enabled && a.fibSig ? {
        breaks: settings.fib.signals !== false ? a.fibSig.breaks.filter((b) => settings.fib.levels?.includes(b.ratio) ?? true) : [],
        strong: settings.fib.strong !== false ? a.fibSig.strong.filter((z) => settings.fib.levels?.includes(z.ratio) ?? true).slice(0, 2) : [],
      } : null,
      plan: (a.plan || a.proposal) ? { ...(a.plan || a.proposal), fromTime: this.candles[fromIdx]?.time } : null,
      frvp,
      edh: settings.strategy === 'edh' && a.edh ? a.edh : null,
      // SMC drawings only while the SMC strategy is on: the active OB, one FVG, the last breaks, the nearest liquidity.
      // also when the Liquidity map toggle is on (any strategy)
      smc: (settings.strategy === 'smc' && a.smc) || ((settings.liqMap || aviewOn(settings)) && a.liq) ? ((S) => ({
        obs: (S.obs || (S.ob ? [S.ob] : [])).slice(0, this._width() < 480 ? 2 : 4),
        fvgs: (S.fvgs || (S.fvg ? [S.fvg] : [])).slice(this._width() < 480 ? -2 : -4),
        events: S.recentEvents || S.events, swings: S.labelled || [], range: S.range || null,
        bsl: S.bsl || (S.liquidity?.bsl || []).slice(0, 1), ssl: S.ssl || (S.liquidity?.ssl || []).slice(0, 1),
      }))(settings.strategy === 'smc' && a.smc ? a.smc : a.liq) : null,
      sessions: settings.liqMap || aviewOn(settings) ? a.sessions || [] : [],
    });
    this._updateVisibleVP();
  }

  _indexOf(time) {
    const cs = this.candles;
    let lo = 0;
    let hi = cs.length - 1;
    while (lo < hi) { const m = (lo + hi) >> 1; if (cs[m].time < time) lo = m + 1; else hi = m; }
    return lo;
  }

  _updateVisibleVP() {
    const s = this.settings;
    if (!s || !s.vp.enabled || !this.analysis?.hasVolume || !this.candles.length) { this.vpProfile = null; this.overlay.set({ vp: null }); return; }
    let from = 0;
    let to = this.candles.length - 1;
    if (s.vp.range === 'visible') {
      const r = this.chart.timeScale().getVisibleLogicalRange();
      if (r) { from = Math.max(0, Math.floor(r.from)); to = Math.min(this.candles.length - 1, Math.ceil(r.to)); }
    }
    this.vpProfile = volumeProfile(this.candles, { rows: s.vp.rows, from, to, valueAreaPct: s.vp.valueAreaPct });
    this.overlay.set({ vp: this.vpProfile });
  }

  setDrawings(drawings) { this.overlay.set({ drawings }); }
  /** SMC / ICT assistant drawing (zones, liquidity, plan) — independent of the strategy overlays. null clears it. */
  setAssist(assist) { this.overlay.set({ assist }); }

  /* ───────── view controls ───────── */
  /** Default framing: recent candles at ~8 px each (≈40 bars on a phone, ≈120 on a desktop). */
  defaultRange() {
    const n = this.candles.length;
    const plot = Math.max(120, this._width() - (this.chart.priceScale('right').width() || 60));
    const bars = Math.round(Math.min(150, Math.max(36, plot / 8)));
    const pad = Math.max(4, Math.round(bars * 0.08));
    return { from: Math.max(0, n - bars), to: n - 1 + pad };
  }

  resetView() {
    const n = this.candles.length;
    this._cancelZoomAnim();
    this.chart.panes().forEach((_, i) => this.chart.priceScale('right', i).applyOptions({ autoScale: true }));
    if (!n) return;
    const apply = () => this.chart.timeScale().setVisibleLogicalRange(this.defaultRange());
    apply();
    // Re-apply after layout: a chart created off-screen has no width on the first frame.
    requestAnimationFrame(apply);
  }

  /** Frame the SMC structure (latest breaks, order block, FVG) so its prices fill the chart height. */
  focusSmc() {
    const m = this.analysis?.smc;
    const n = this.candles.length;
    if (!m || !n) return;
    // Frame the recent structure (last breaks and newest order blocks), but show at least the default view.
    const idx = [...(m.obs || []).slice(0, 2).map((o) => o.index), ...(m.recentEvents || m.events || []).slice(-3).map((e) => e.swingIndex)].filter((i) => Number.isFinite(i));
    if (!idx.length) return;
    const def = this.defaultRange();
    const minBars = Math.min(def.to - def.from, Math.max(30, Math.round((def.to - def.from) * 0.5)));
    let from = Math.max(0, Math.min(...idx) - 4);
    if (n - from < minBars) from = Math.max(0, n - minBars);
    const to = n - 1 + Math.max(4, Math.round((n - from) * 0.12));
    this.chart.panes().forEach((_, i) => this.chart.priceScale('right', i).applyOptions({ autoScale: true }));
    this._animateRange({ from, to });
  }

  /** Visible bar-count limits for zooming. */
  zoomLimits() {
    const n = Math.max(1, this.candles.length);
    return { min: 12, max: Math.max(24, n + 20) };
  }

  /**
   * Button zoom. factor < 1 zooms in (fewer, wider candles), > 1 zooms out.
   * Keeps the centre of the current view fixed and animates briefly.
   */
  zoom(factor) {
    const ts = this.chart.timeScale();
    const r = this._zoomTarget || ts.getVisibleLogicalRange();
    if (!r) return false;
    const { min, max } = this.zoomLimits();
    const width = r.to - r.from;
    const next = Math.min(max, Math.max(min, width * factor));
    if (Math.abs(next - width) < 0.5) return false; // already at a limit
    const center = (r.from + r.to) / 2;
    const target = { from: center - next / 2, to: center + next / 2 };
    this._animateRange(target);
    return true;
  }

  canZoom(direction) {
    const r = this._zoomTarget || this.chart.timeScale().getVisibleLogicalRange();
    if (!r) return true;
    const { min, max } = this.zoomLimits();
    const w = r.to - r.from;
    return direction === 'in' ? w > min + 0.5 : w < max - 0.5;
  }

  _animateRange(target) {
    const ts = this.chart.timeScale();
    const start = ts.getVisibleLogicalRange();
    this._cancelZoomAnim();
    this._zoomTarget = target;
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reduce || !start) { ts.setVisibleLogicalRange(target); this._zoomTarget = null; return; }
    const t0 = performance.now();
    const dur = 180;
    const step = (now) => {
      const k = Math.min(1, (now - t0) / dur);
      const e = 1 - (1 - k) ** 3;
      ts.setVisibleLogicalRange({ from: start.from + (target.from - start.from) * e, to: start.to + (target.to - start.to) * e });
      if (k < 1) this._zoomRaf = requestAnimationFrame(step);
      else { this._zoomRaf = null; this._zoomTarget = null; }
    };
    this._zoomRaf = requestAnimationFrame(step);
  }

  _cancelZoomAnim() {
    if (this._zoomRaf) cancelAnimationFrame(this._zoomRaf);
    if (this._zoomTarget) this.chart.timeScale().setVisibleLogicalRange(this._zoomTarget);
    this._zoomRaf = null;
    this._zoomTarget = null;
  }

  screenshot(filename) {
    const canvas = this.chart.takeScreenshot(true);
    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = filename;
    a.click();
  }

  /* ───────── tools ───────── */
  setTool(tool) {
    this.tool = tool;
    this.pending = [];
    this.overlay.set({ preview: null });
    this.el.classList.toggle('is-picking', tool !== 'cursor');
  }

  _pointFromParam(p) {
    if (!p.point || p.logical === undefined || (p.paneIndex ?? 0) !== 0) return null;
    const price = this.candleSeries.coordinateToPrice(p.point.y);
    if (price == null) return null;
    const n = this.candles.length;
    if (!n) return null;
    const step = n > 1 ? this.candles[1].time - this.candles[0].time : 60;
    const l = Math.round(p.logical);
    const time = l < 0 ? this.candles[0].time + l * step : l >= n ? this.candles[n - 1].time + (l - n + 1) * step : this.candles[l].time;
    return { time, price, logical: l };
  }

  _handlePointerUp(e) {
    if (this.tool === 'cursor' || !this._down) return;
    if (Math.abs(e.clientX - this._down.x) + Math.abs(e.clientY - this._down.y) > 6) return; // a drag, not a click
    const rect = this.el.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const plotWidth = rect.width - this.chart.priceScale('right').width();
    const pane0 = this.chart.panes()[0]?.getHeight() ?? rect.height;
    if (x < 0 || x > plotWidth || y < 0 || y > pane0) return;
    const logical = this.chart.timeScale().coordinateToLogical(x);
    if (logical == null) return;
    this._handleClick({ point: { x, y }, logical, paneIndex: 0 });
  }

  _handleClick(p) {
    if (this.tool === 'cursor') return;
    const pt = this._pointFromParam(p);
    if (!pt) return;
    const needs = { trend: 2, measure: 2, fib: 2, frvp: 2, hline: 1, text: 1 }[this.tool] || 1;
    this.pending.push(pt);
    if (this.pending.length < needs) {
      this.overlay.set({ preview: { type: 'point', a: pt } });
      return;
    }
    const points = this.pending;
    const tool = this.tool;
    this.setTool('cursor');
    this.hooks.onPick?.(tool, points);
    this.hooks.onToolDone?.();
  }

  _handleMove(p) {
    if (p.time !== undefined && p.logical !== undefined) {
      const idx = Math.max(0, Math.min(this.candles.length - 1, Math.round(p.logical)));
      this.hooks.onCrosshair?.(this.candles[idx], idx);
    } else this.hooks.onCrosshair?.(null);
    if (this.tool === 'cursor' || this.pending.length !== 1) return;
    const pt = this._pointFromParam(p);
    if (!pt) return;
    const type = { trend: 'trend', measure: 'measure', fib: 'fibpick', frvp: 'frvppick' }[this.tool];
    if (type) this.overlay.set({ preview: { type, a: this.pending[0], b: pt } });
  }

  destroy() {
    this._ro?.disconnect();
    this.el.removeEventListener('pointerdown', this._onDown, true);
    this.el.removeEventListener('pointerup', this._onUp, true);
    this.chart.unsubscribeCrosshairMove(this._onMove);
    this.chart.timeScale().unsubscribeVisibleLogicalRangeChange(this._onRange);
    if (this._zoomRaf) cancelAnimationFrame(this._zoomRaf);
    this.chart.remove();
  }
}
