// Public business details shown on the legal pages (these are meant to be public; never put secrets in VITE_ vars).
import { readEnv } from './env.js';
export const BUSINESS = {
  name: readEnv('VITE_BUSINESS_NAME', ''),
  email: readEnv('VITE_CONTACT_EMAIL', 'alphatradeaisupport@gmail.com'),   // technical support (public)
  address: readEnv('VITE_BUSINESS_ADDRESS', ''),
  country: readEnv('VITE_BUSINESS_COUNTRY', ''),
  refundDays: readEnv('VITE_REFUND_DAYS', ''),
};
/** Fill the [placeholders] of the legal drafts with what the owner set; anything not set stays visible in [brackets]. */
export function fillBusiness(text) {
  const b = BUSINESS;
  return String(text)
    .replace(/\[(company \/ owner name|اسم الشركة \/ المالك|owner|المالك)\]/g, (m) => b.name || m)
    .replace(/\[(email|الإيميل)\]/g, (m) => b.email || m)
    .replace(/\[(address|العنوان)\]/g, (m) => b.address || m)
    .replace(/\[(Country \/ courts to be specified\.|البلد \/ المحاكم لازم تتحدد\.)\]/g, (m) => (b.country ? `${b.country}.` : m))
    .replace(/\[(X days|عدد الأيام)\]/g, (m) => (b.refundDays ? (/[a-z]/i.test(m) ? `${b.refundDays} days` : `${b.refundDays} يوم`) : m));
}
