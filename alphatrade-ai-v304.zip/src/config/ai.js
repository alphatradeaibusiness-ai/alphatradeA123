import { readEnv } from './env.js';

export const aiConfig = {
  // Endpoint that accepts POST { messages, context } and returns { reply }.
  apiUrl: readEnv('VITE_AI_API_URL', '/api/ai/chat'),
  // Health endpoint used for the connection badge. Derived from apiUrl by default.
  healthUrl: readEnv('VITE_AI_HEALTH_URL', readEnv('VITE_AI_API_URL', '/api/ai/chat').replace(/\/chat$/, '/health')),
  timeoutMs: 45000,
  maxHistory: 12,
};
