// v281 Funded-trader challenges (prop firm style): programs, account sizes, prices, rules and the contract table used to turn
// price moves into dollars. Shared by the server (which enforces everything) and the page (which only shows it).
// Challenge and funded accounts are SIMULATED (demo) accounts on real market prices; rewards are paid by the site owner from
// the company's own funds under the published terms. Prices and rules can be changed here (and prices by the owner on the
// site, like every plan).

export const SIZES = [5000, 10000, 25000, 50000, 100000, 200000];

/**
 * Programs. Percentages are of the starting balance.
 *  phases[i]: { target } profit target to pass that phase
 *  daily: max loss in one day (from the higher of balance / equity at the start of the day, 00:00 UTC) — null = no daily limit
 *  maxLoss: max total loss (static, from the starting balance)
 *  minDays: minimum trading days per phase (Instant: trading days before the first payout) · split: trader's share of funded profits · payoutDays: days between payouts
 */
export const PROGRAMS = [
  { id: 'step1', name: { ar: 'Step 1 — مرحلة وحدة', en: 'Step 1 — one phase' }, short: 'Step 1',
    desc: { ar: 'مرحلة وحدة وبتصير ممول. هدف أعلى بس أسرع طريق.', en: 'One phase to funded. Higher target, fastest route.' },
    phases: [{ target: 10 }], daily: 4, maxLoss: 6, minDays: 3, split: 80, payoutDays: 14, leverage: { fx: 100, metal: 100, index: 20, energy: 20, crypto: 2 },
    prices: { 5000: 39, 10000: 69, 25000: 149, 50000: 259, 100000: 469, 200000: 899 } },
  { id: 'step2', name: { ar: 'Step 2 — مرحلتين', en: 'Step 2 — two phases' }, short: 'Step 2', popular: true,
    desc: { ar: 'مرحلتين بأهداف أسهل وحدود خسارة أوسع. الأنسب لأغلب المتداولين.', en: 'Two phases, easier targets and wider loss limits. Best for most traders.' },
    phases: [{ target: 8 }, { target: 5 }], daily: 5, maxLoss: 10, minDays: 3, split: 80, payoutDays: 14, leverage: { fx: 100, metal: 100, index: 20, energy: 20, crypto: 2 },
    prices: { 5000: 29, 10000: 49, 25000: 119, 50000: 209, 100000: 379, 200000: 749 } },
  { id: 'flex', name: { ar: 'Flex — مرن', en: 'Flex — flexible' }, short: 'Flex',
    desc: { ar: 'بدون حد خسارة يومي، مرحلة وحدة، أرخص سعر. حصة أرباح أقل.', en: 'No daily loss limit, one phase, lowest price. Lower profit share.' },
    phases: [{ target: 8 }], daily: null, maxLoss: 8, minDays: 5, split: 70, payoutDays: 14, leverage: { fx: 50, metal: 50, index: 10, energy: 10, crypto: 2 },
    prices: { 5000: 25, 10000: 42, 25000: 95, 50000: 169, 100000: 319, 200000: 619 } },
  // v283 Instant: no challenge and no profit target — a funded account from day one with only a loss limit.
  { id: 'instant', name: { ar: 'Instant — تمويل فوري', en: 'Instant — funded now' }, short: 'Instant', noTarget: true,
    desc: { ar: 'بدون تحدي وبدون هدف ربح: حساب ممول من أول يوم، والقاعدة الوحيدة حد الخسارة.', en: 'No challenge and no profit target: funded from day one; the only rule is the loss limit.' },
    phases: [], daily: null, maxLoss: 6, minDays: 5, split: 70, payoutDays: 14, leverage: { fx: 30, metal: 30, index: 10, energy: 10, crypto: 2 },
    prices: { 5000: 59, 10000: 99, 25000: 219, 50000: 399, 100000: 749, 200000: 1399 } },
];
export const programById = (id) => PROGRAMS.find((p) => p.id === id) || null;
export const productId = (program, size) => `ch-${program}-${size / 1000}k`;
export function parseProduct(id) {
  const m = /^ch-(step1|step2|flex|instant)-(\d{1,3})k$/.exec(String(id || '')); if (!m) return null;
  const size = Number(m[2]) * 1000; const p = programById(m[1]);
  return p && SIZES.includes(size) ? { program: p, size } : null;
}
/** Every challenge as a checkout product (Stripe catalogue). */
export const CHALLENGE_PRODUCTS = PROGRAMS.flatMap((p) => SIZES.map((size) => ({ id: productId(p.id, size), program: p.id, size, price: p.prices[size] })));

/**
 * Contracts: what 1.00 lot is, and how a price move becomes US dollars.
 *  unit: units per lot · usd: 'direct' (quote currency is USD) | 'inverse' (USD is the base: P&L / price) · cls: leverage class
 *  fut: real-time price from Binance USDⓈ-M TradFi perpetuals (the free Yahoo feed for gold / silver / oil futures is delayed
 *       ~10 minutes, which would let anyone trade on a known future price — so those are never filled from Yahoo)
 */
export const CONTRACTS = {
  BTCUSDT: { unit: 1, usd: 'direct', cls: 'crypto', min: 0.01 }, ETHUSDT: { unit: 1, usd: 'direct', cls: 'crypto', min: 0.01 }, SOLUSDT: { unit: 1, usd: 'direct', cls: 'crypto', min: 0.01 },
  BNBUSDT: { unit: 1, usd: 'direct', cls: 'crypto', min: 0.01 }, XRPUSDT: { unit: 100, usd: 'direct', cls: 'crypto', min: 0.01 },
  XAUUSD: { unit: 100, usd: 'direct', cls: 'metal', min: 0.01, fut: 'XAUUSDT' }, XAGUSD: { unit: 5000, usd: 'direct', cls: 'metal', min: 0.01, fut: 'XAGUSDT' },
  EURUSD: { unit: 100000, usd: 'direct', cls: 'fx', min: 0.01 }, GBPUSD: { unit: 100000, usd: 'direct', cls: 'fx', min: 0.01 }, AUDUSD: { unit: 100000, usd: 'direct', cls: 'fx', min: 0.01 },
  NZDUSD: { unit: 100000, usd: 'direct', cls: 'fx', min: 0.01 }, USDJPY: { unit: 100000, usd: 'inverse', cls: 'fx', min: 0.01 }, USDCHF: { unit: 100000, usd: 'inverse', cls: 'fx', min: 0.01 },
  USDCAD: { unit: 100000, usd: 'inverse', cls: 'fx', min: 0.01 },
  US30: { unit: 1, usd: 'direct', cls: 'index', min: 0.1 }, US100: { unit: 1, usd: 'direct', cls: 'index', min: 0.1 }, SPX500: { unit: 1, usd: 'direct', cls: 'index', min: 0.1 },
  USOIL: { unit: 1000, usd: 'direct', cls: 'energy', min: 0.01, fut: 'CLUSDT' },
};
export const CH_SYMBOLS = Object.keys(CONTRACTS);
export const MAX_LOTS = 50;

/** Profit / loss in USD of `lots` from `entry` to `price` (side 'buy' | 'sell'). */
export function pnlUsd(sym, side, lots, entry, price) {
  const c = CONTRACTS[sym]; if (!c || !(price > 0) || !(entry > 0)) return 0;
  const diff = (side === 'buy' ? price - entry : entry - price) * c.unit * lots;
  return c.usd === 'inverse' ? diff / price : diff;
}
/** Margin needed in USD for a position (notional / leverage). */
export function marginUsd(sym, lots, price, program) {
  const c = CONTRACTS[sym]; if (!c || !(price > 0)) return Infinity;
  const notional = c.usd === 'inverse' ? c.unit * lots : c.unit * lots * price;
  return notional / ((program?.leverage || {})[c.cls] || 1);
}

/** Starting balance → the account's limits in USD. */
export function limitsOf(program, size, phaseIdx) {
  const ph = program.phases[phaseIdx] || null;
  return { target: ph ? size * (ph.target / 100) : null, daily: program.daily == null ? null : size * (program.daily / 100), maxLoss: size * (program.maxLoss / 100), floor: size * (1 - program.maxLoss / 100) };
}

/** Payout methods (for rewards) — the actual transfer is made by the owner through the provider; no card numbers are collected. */
export const PAYOUT_METHODS = [
  { id: 'paypal', name: { ar: 'PayPal', en: 'PayPal' } },
  { id: 'card', name: { ar: 'فيزا / ماستركارد (عبر المزوّد)', en: 'Visa / Mastercard (via the provider)' } },
  { id: 'bank', name: { ar: 'تحويل بنكي (IBAN)', en: 'Bank transfer (IBAN)' } },
  { id: 'usdt', name: { ar: 'USDT (كريبتو)', en: 'USDT (crypto)' } },
];
/** Checkout methods shown to the buyer — what actually appears depends on what the owner switched on in Stripe. */
export const PAY_METHODS = ['visa', 'mastercard', 'applepay', 'googlepay', 'paypal', 'crypto'];
