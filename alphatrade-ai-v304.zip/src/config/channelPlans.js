// Shared public catalogue. Payment confirmation and usage live on the server.
export const CHANNEL_PLANS = Object.freeze({
  monthly: { quota: 30, view: 'essential' },
  quarterly: { quota: 50, view: 'research' },
  semiannual: { quota: 90, view: 'advanced' },
  annual: { quota: 120, view: 'complete' },
  prime: { quota: 150, view: 'complete' },
  apex: { quota: 200, view: 'complete' },
  max: { quota: 300, view: 'complete' },
  channel: { quota: 30, view: 'research' },
});
export const CHANNEL_PRODUCTS = [
  { id: 'channel', count: 30, price: 25, kind: 'subscription', env: 'VITE_PAY_LINK_CHANNEL' },
  { id: 'signals25', count: 25, price: 10, kind: 'addon', env: 'VITE_PAY_LINK_SIGNALS_25' },
  { id: 'signals50', count: 50, price: 18, kind: 'addon', env: 'VITE_PAY_LINK_SIGNALS_50' },
  { id: 'signals100', count: 100, price: 30, kind: 'addon', env: 'VITE_PAY_LINK_SIGNALS_100' },
];
// Billing-month boundaries retain the original UTC anchor (including Jan 31 -> Feb 28 -> Mar 31).
export function channelPeriod(startedAt, now = Date.now()) {
  const start = new Date(startedAt), current = new Date(now);
  if (!Number.isFinite(+start) || +start > now) return null;
  const boundary = n => {
    const year = start.getUTCFullYear(), month = start.getUTCMonth() + n;
    const days = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
    return Date.UTC(year, month, Math.min(start.getUTCDate(), days), start.getUTCHours(), start.getUTCMinutes(), start.getUTCSeconds(), start.getUTCMilliseconds());
  };
  let n = (current.getUTCFullYear() - start.getUTCFullYear()) * 12 + current.getUTCMonth() - start.getUTCMonth();
  if (boundary(n) > now) n--;
  return { start: boundary(n), end: boundary(n + 1) };
}
