import { readEnv } from './env.js';

// Instrument definitions.
//
// "Point" — the stop-loss rule is "30 points from entry". A point is NOT a
// universal unit, so every instrument declares what one point is in price terms.
// Users can override these in Settings (stored per browser).
//
//   Crypto (USDT pairs): there is no industry-wide "point". Defaults below use a
//     practical unit per coin (BTC $1, ETH $0.10, SOL/BNB $0.01 / $0.10).
//   XAUUSD (gold, quoted to 2 decimals): in MetaTrader 1 point = 0.01 USD.
//     Many gold traders instead call 0.10 a "pip". Default here: 0.01 (MT point).
//   US indices (US30, US100, SPX500): 1 point = 1.0 index point, as index traders count it.
//     (Some CFD platforms quote these with 1–2 decimals; change the point size if yours differs.)
//   Forex example (not listed): EURUSD 5-digit quote → 1 point = 0.00001.


export const INSTRUMENTS = [
  {
    symbol: 'BTCUSDT', base: 'BTC', quote: 'USDT', icon: 'btc', type: 'crypto',
    provider: 'binance', precision: 2, pointSize: 1, demoSeed: 81498,
    pointNote: { en: '1 point = 1 USDT', ar: 'النقطة = 1 USDT' },
  },
  {
    symbol: 'ETHUSDT', base: 'ETH', quote: 'USDT', icon: 'eth', type: 'crypto',
    provider: 'binance', precision: 2, pointSize: 0.1, demoSeed: 2404,
    pointNote: { en: '1 point = 0.10 USDT', ar: 'النقطة = 0.10 USDT' },
  },
  {
    symbol: 'SOLUSDT', base: 'SOL', quote: 'USDT', icon: 'sol', type: 'crypto',
    provider: 'binance', precision: 2, pointSize: 0.01, demoSeed: 104,
    pointNote: { en: '1 point = 0.01 USDT', ar: 'النقطة = 0.01 USDT' },
  },
  {
    symbol: 'BNBUSDT', base: 'BNB', quote: 'USDT', icon: 'bnb', type: 'crypto',
    provider: 'binance', precision: 2, pointSize: 0.1, demoSeed: 745,
    pointNote: { en: '1 point = 0.10 USDT', ar: 'النقطة = 0.10 USDT' },
  },
  {
    symbol: 'XAUUSD', base: 'XAU', quote: 'USD', icon: 'xau', type: 'metal',
    provider: 'twelvedata', providerSymbol: 'XAU/USD', precision: 2, pointSize: 0.01, demoSeed: 4010,
    pointNote: { en: '1 point = 0.01 USD (MetaTrader convention)', ar: 'النقطة = 0.01 دولار (اصطلاح ميتاتريدر)' },
  },
  // US indices via Twelve Data. Provider symbols can be overridden in .env if your plan
  // uses different tickers (e.g. VITE_TD_SYMBOL_US30=DJI).
  {
    symbol: 'US30', base: 'Dow Jones 30', quote: 'USD', icon: 'us30', type: 'index',
    provider: 'twelvedata', providerSymbol: readEnv('VITE_TD_SYMBOL_US30', 'DJI'), precision: 2, pointSize: 1, demoSeed: 52293,
    pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' },
  },
  {
    symbol: 'US100', base: 'Nasdaq 100', quote: 'USD', icon: 'us100', type: 'index',
    provider: 'twelvedata', providerSymbol: readEnv('VITE_TD_SYMBOL_US100', 'NDX'), precision: 2, pointSize: 1, demoSeed: 29001,
    pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' },
  },
  {
    symbol: 'SPX500', base: 'S&P 500', quote: 'USD', icon: 'spx500', type: 'index',
    provider: 'twelvedata', providerSymbol: readEnv('VITE_TD_SYMBOL_SPX500', 'SPX'), precision: 2, pointSize: 1, demoSeed: 7632,
    pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' },
  },
  // ── World indices (Yahoo Finance, real prices, no key needed) ──
  { symbol: 'UK100', base: 'FTSE 100', quote: 'GBP', icon: 'uk100', type: 'index', provider: 'twelvedata', providerSymbol: '^FTSE', precision: 2, pointSize: 1, demoSeed: 10150, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  { symbol: 'GER40', base: 'DAX 40', quote: 'EUR', icon: 'ger40', type: 'index', provider: 'twelvedata', providerSymbol: '^GDAXI', precision: 2, pointSize: 1, demoSeed: 24650, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  { symbol: 'FRA40', base: 'CAC 40', quote: 'EUR', icon: 'fra40', type: 'index', provider: 'twelvedata', providerSymbol: '^FCHI', precision: 2, pointSize: 1, demoSeed: 8120, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  { symbol: 'EU50', base: 'Euro Stoxx 50', quote: 'EUR', icon: 'eu50', type: 'index', provider: 'twelvedata', providerSymbol: '^STOXX50E', precision: 2, pointSize: 1, demoSeed: 5230, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  { symbol: 'JP225', base: 'Nikkei 225', quote: 'JPY', icon: 'jp225', type: 'index', provider: 'twelvedata', providerSymbol: '^N225', precision: 2, pointSize: 1, demoSeed: 52300, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  { symbol: 'HK50', base: 'Hang Seng', quote: 'HKD', icon: 'hk50', type: 'index', provider: 'twelvedata', providerSymbol: '^HSI', precision: 2, pointSize: 1, demoSeed: 26200, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  { symbol: 'AUS200', base: 'ASX 200', quote: 'AUD', icon: 'aus200', type: 'index', provider: 'twelvedata', providerSymbol: '^AXJO', precision: 2, pointSize: 1, demoSeed: 9120, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  { symbol: 'SPAIN35', base: 'IBEX 35', quote: 'EUR', icon: 'spain35', type: 'index', provider: 'twelvedata', providerSymbol: '^IBEX', precision: 2, pointSize: 1, demoSeed: 12460, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  { symbol: 'SWISS20', base: 'SMI 20', quote: 'CHF', icon: 'swiss20', type: 'index', provider: 'twelvedata', providerSymbol: '^SSMI', precision: 2, pointSize: 1, demoSeed: 12410, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  { symbol: 'NED25', base: 'AEX 25', quote: 'EUR', icon: 'ned25', type: 'index', provider: 'twelvedata', providerSymbol: '^AEX', precision: 2, pointSize: 1, demoSeed: 960, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  { symbol: 'KOSPI', base: 'KOSPI', quote: 'KRW', icon: 'kospi', type: 'index', provider: 'twelvedata', providerSymbol: '^KS11', precision: 2, pointSize: 1, demoSeed: 4160, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  { symbol: 'INDIA50', base: 'Nifty 50', quote: 'INR', icon: 'india50', type: 'index', provider: 'twelvedata', providerSymbol: '^NSEI', precision: 2, pointSize: 1, demoSeed: 26250, pointNote: { en: '1 point = 1 index point', ar: 'النقطة = نقطة مؤشر واحدة' } },
  // ── Metals & energy (Yahoo Finance futures) ──
  { symbol: 'XAGUSD', base: 'XAG', quote: 'USD', icon: 'xag', type: 'metal', provider: 'twelvedata', providerSymbol: 'SI=F', precision: 3, pointSize: 0.001, demoSeed: 47.5, pointNote: { en: '1 point = 0.001 USD', ar: 'النقطة = 0.001 دولار' } },
  { symbol: 'XPTUSD', base: 'XPT', quote: 'USD', icon: 'xpt', type: 'metal', provider: 'twelvedata', providerSymbol: 'PL=F', precision: 2, pointSize: 0.1, demoSeed: 985, pointNote: { en: '1 point = 0.10 USD', ar: 'النقطة = 0.10 دولار' } },
  { symbol: 'USOIL', base: 'WTI Crude', quote: 'USD', icon: 'uso', type: 'energy', provider: 'twelvedata', providerSymbol: 'CL=F', precision: 2, pointSize: 0.01, demoSeed: 58.4, pointNote: { en: '1 point = 0.01 USD', ar: 'النقطة = 0.01 دولار' } },
  { symbol: 'UKOIL', base: 'Brent Crude', quote: 'USD', icon: 'uko', type: 'energy', provider: 'twelvedata', providerSymbol: 'BZ=F', precision: 2, pointSize: 0.01, demoSeed: 62.1, pointNote: { en: '1 point = 0.01 USD', ar: 'النقطة = 0.01 دولار' } },
  { symbol: 'NATGAS', base: 'Natural Gas', quote: 'USD', icon: 'ng', type: 'energy', provider: 'twelvedata', providerSymbol: 'NG=F', precision: 3, pointSize: 0.001, demoSeed: 3.05, pointNote: { en: '1 point = 0.001 USD', ar: 'النقطة = 0.001 دولار' } },
  { symbol: 'COPPER', base: 'Copper', quote: 'USD', icon: 'copper', type: 'metal', provider: 'twelvedata', providerSymbol: 'HG=F', precision: 3, pointSize: 0.001, demoSeed: 4.85, pointNote: { en: '1 point = 0.001 USD', ar: 'النقطة = 0.001 دولار' } },
  // ── More crypto (Binance, real-time WebSocket) ──
  { symbol: 'XRPUSDT', base: 'XRP', quote: 'USDT', icon: 'xrp', type: 'crypto', provider: 'binance', precision: 4, pointSize: 0.001, demoSeed: 2.35, pointNote: { en: '1 point = 0.001 USDT', ar: 'النقطة = 0.001 USDT' } },
  { symbol: 'DOGEUSDT', base: 'DOGE', quote: 'USDT', icon: 'doge', type: 'crypto', provider: 'binance', precision: 5, pointSize: 0.0001, demoSeed: 0.115, pointNote: { en: '1 point = 0.0001 USDT', ar: 'النقطة = 0.0001 USDT' } },
  { symbol: 'ADAUSDT', base: 'ADA', quote: 'USDT', icon: 'ada', type: 'crypto', provider: 'binance', precision: 4, pointSize: 0.001, demoSeed: 0.62, pointNote: { en: '1 point = 0.001 USDT', ar: 'النقطة = 0.001 USDT' } },
  { symbol: 'AVAXUSDT', base: 'AVAX', quote: 'USDT', icon: 'avax', type: 'crypto', provider: 'binance', precision: 3, pointSize: 0.01, demoSeed: 26.4, pointNote: { en: '1 point = 0.01 USDT', ar: 'النقطة = 0.01 USDT' } },
  { symbol: 'LINKUSDT', base: 'LINK', quote: 'USDT', icon: 'link', type: 'crypto', provider: 'binance', precision: 3, pointSize: 0.01, demoSeed: 14.8, pointNote: { en: '1 point = 0.01 USDT', ar: 'النقطة = 0.01 USDT' } },
  { symbol: 'LTCUSDT', base: 'LTC', quote: 'USDT', icon: 'ltc', type: 'crypto', provider: 'binance', precision: 2, pointSize: 0.1, demoSeed: 108.5, pointNote: { en: '1 point = 0.1 USDT', ar: 'النقطة = 0.1 USDT' } },
  { symbol: 'TRXUSDT', base: 'TRX', quote: 'USDT', icon: 'trx', type: 'crypto', provider: 'binance', precision: 5, pointSize: 0.0001, demoSeed: 0.29, pointNote: { en: '1 point = 0.0001 USDT', ar: 'النقطة = 0.0001 USDT' } },
  { symbol: 'DOTUSDT', base: 'DOT', quote: 'USDT', icon: 'dot', type: 'crypto', provider: 'binance', precision: 3, pointSize: 0.01, demoSeed: 4.95, pointNote: { en: '1 point = 0.01 USDT', ar: 'النقطة = 0.01 USDT' } },
  { symbol: 'ATOMUSDT', base: 'ATOM', quote: 'USDT', icon: 'atom', type: 'crypto', provider: 'binance', precision: 3, pointSize: 0.01, demoSeed: 4.75, pointNote: { en: '1 point = 0.01 USDT', ar: 'النقطة = 0.01 USDT' } },
  { symbol: 'NEARUSDT', base: 'NEAR', quote: 'USDT', icon: 'near', type: 'crypto', provider: 'binance', precision: 3, pointSize: 0.01, demoSeed: 2.55, pointNote: { en: '1 point = 0.01 USDT', ar: 'النقطة = 0.01 USDT' } },
  { symbol: 'SUIUSDT', base: 'SUI', quote: 'USDT', icon: 'sui', type: 'crypto', provider: 'binance', precision: 4, pointSize: 0.001, demoSeed: 1.85, pointNote: { en: '1 point = 0.001 USDT', ar: 'النقطة = 0.001 USDT' } },
  { symbol: 'PEPEUSDT', base: 'PEPE', quote: 'USDT', icon: 'pepe', type: 'crypto', provider: 'binance', precision: 8, pointSize: 0.00000001, demoSeed: 0.0000085, pointNote: { en: '1 point = 0.00000001 USDT', ar: 'النقطة = 0.00000001 USDT' } },
];

// Additional provider-backed markets. Availability is checked by the data provider.
for (const pair of ['EURUSD','GBPUSD','USDJPY','USDCHF','AUDUSD','NZDUSD','USDCAD','EURGBP','EURJPY','GBPJPY']) {
  const jpy = pair.endsWith('JPY');
  INSTRUMENTS.push({symbol:pair,base:pair.slice(0,3),quote:pair.slice(3),icon:'forex',type:'forex',provider:'twelvedata',providerSymbol:`${pair.slice(0,3)}/${pair.slice(3)}`,precision:jpy?3:5,pointSize:jpy?.001:.00001,demoSeed:jpy?156.8:1.12});
}

export const STOP_LOSS_POINTS = 30;

// Targets, in points from the entry, in the trade's direction:
// TP1 = 50, TP2 = TP1 + 30 = 80, TP3 = TP2 + 50 = 130.
export const TARGET_POINTS = [50, 80, 130];

// v247: markets used by Alpha Elite Signals only (never scanned by the channel / EDH, never listed with the other markets).
// Real Yahoo Finance tickers: ^RUT (Russell 2000) and PA=F (palladium futures).
export const EXTRA_INSTRUMENTS = [
  { symbol: 'US2000', base: 'Russell 2000', quote: 'USD', icon: 'us100', type: 'index', provider: 'twelvedata', providerSymbol: '^RUT', precision: 2, pointSize: 0.1, demoSeed: 2450, pointNote: { en: '1 point = 0.1 index point', ar: 'النقطة = 0.1 نقطة مؤشر' } },
  { symbol: 'XPDUSD', base: 'XPD', quote: 'USD', icon: 'xpt', type: 'metal', provider: 'twelvedata', providerSymbol: 'PA=F', precision: 2, pointSize: 0.1, demoSeed: 1020, pointNote: { en: '1 point = 0.10 USD', ar: 'النقطة = 0.10 دولار' } },
  // v248: more liquid forex crosses for «توصية AI» (on-demand analysis only; not scanned by the channel / EDH)
  ...['EURCHF', 'AUDJPY', 'CADJPY'].map((pair) => { const jpy = pair.endsWith('JPY'); return { symbol: pair, base: pair.slice(0, 3), quote: pair.slice(3), icon: 'forex', type: 'forex', provider: 'twelvedata', providerSymbol: `${pair.slice(0, 3)}/${pair.slice(3)}`, precision: jpy ? 3 : 5, pointSize: jpy ? 0.001 : 0.00001, demoSeed: jpy ? 100 : 0.94 }; }),
];
/** Strict lookup: the instrument or null (never a substitute). */
export const findInstrument = (symbol) => INSTRUMENTS.find((i) => i.symbol === symbol) || EXTRA_INSTRUMENTS.find((i) => i.symbol === symbol) || null;

export function getInstrument(symbol) {
  return INSTRUMENTS.find((i) => i.symbol === symbol) || EXTRA_INSTRUMENTS.find((i) => i.symbol === symbol) || INSTRUMENTS[0];
}
