// v285 translation batch 2 (challenges menu entry, markets page, signals channel, real-data notices). Merged over the language file.
export default {
 "nav": {
  "challenges": "Desafíos de fondeo"
 },
 "navShort": {
  "challenges": "Desafíos de fondeo"
 },
 "pages": {
  "guideTitle": "Guía de uso",
  "strategiesTitle": "Estrategias",
  "strategiesNote": "Son ideas educativas, no asesoramiento de inversión.",
  "marketsTitle": "Mercados",
  "marketsSub": "Pulsa un símbolo para abrirlo en el panel de análisis.",
  "colSymbol": "Símbolo",
  "colPrice": "Precio",
  "colChange": "Cambio 24 h",
  "colHigh": "Máximo",
  "colLow": "Mínimo",
  "colVolume": "Volumen",
  "colSource": "Fuente",
  "open": "Abrir",
  "indicatorsTitle": "Indicadores"
 },
 "sig": {
  "title": "Canal de señales",
  "bar": "Señales",
  "pts": "pts",
  "acc": "Precisión",
  "now": "Ahora",
  "atEntry": "en la entrada",
  "scanning": "Probando las estrategias con precios en vivo…",
  "watching": "En vivo · se actualiza cada segundo",
  "none": "Ahora no hay señal de una estrategia con {min}% o más de precisión; el canal sigue comprobando y enviará una en cuanto aparezca.",
  "needLive": "El canal necesita precios en vivo: no se envían señales con datos de demostración.",
  "status": {
   "pending": "Esperando entrada",
   "expired": "Caducada",
   "cancelled": "Cancelada antes de entrar",
   "active": "Activa",
   "tp3": "Los 3 objetivos ✓",
   "sl": "Cerrada por stop",
   "be": "Salida en la entrada"
  },
  "chartNew": "Nueva operación en el gráfico",
  "chartPending": "Operación pendiente en el gráfico (esperando entrada)",
  "newTitle": "Nueva señal",
  "tpTitle": "Objetivo {n} alcanzado ✅",
  "slTitle": "Señal cerrada por stop",
  "beTitle": "Señal cerrada en la entrada",
  "enable": "Activar notificaciones en este dispositivo",
  "notifAsk": "Activa las notificaciones para recibir cada señal y objetivo en tu teléfono, con el nombre y el logo del sitio.",
  "notifFailed": "El navegador no mostró la notificación. En iPhone: añade el sitio a la pantalla de inicio, ábrelo desde ahí y comprueba que las notificaciones están permitidas en Ajustes.",
  "notifDenied": "Las notificaciones están bloqueadas para este sitio: permítelas en los ajustes del navegador.",
  "notifOn": "Notificaciones activadas",
  "notifOnHelp": "Las notificaciones llegan mientras el sitio está abierto (también en segundo plano).",
  "notifNo": "Este navegador no admite notificaciones",
  "iosHelp": "En iPhone: abre el sitio en Safari → Compartir → \"Añadir a pantalla de inicio\", luego abre la app desde la pantalla de inicio y activa las notificaciones.",
  "enabledBody": "Las notificaciones del canal de señales están activadas ✅",
  "test": "Notificación de prueba",
  "testTitle": "Notificación de prueba",
  "qualsTitle": "Estrategias probadas (aptas ≥ {min}%)",
  "qualified": "Apta",
  "oos": "Fuera de muestra",
  "trackTitle": "Resultados reales de las señales publicadas",
  "trackRate": "alcanzaron el objetivo 1 o más",
  "trackClosed": "señales cerradas",
  "trackTp2": "alcanzaron el objetivo 2",
  "trackTp3": "alcanzaron el objetivo 3",
  "trackSmall": "Muestra pequeña (solo {n} señales): no te fíes de la tasa hasta que se hayan cerrado al menos 20 señales.",
  "trackNone": "Aún no se ha cerrado ninguna señal. El resultado real aparecerá aquí cuando terminen las señales publicadas.",
  "clear": "Borrar señales terminadas"
 },
 "intro": {
  "welcome": "Bienvenido, {name}",
  "skip": "Omitir",
  "granted": "Sesión iniciada correctamente"
 },
 "real": {
  "title": "Ahora no hay datos reales del mercado",
  "body": "No se muestran resultados porque los precios no vienen del mercado en vivo (datos de demostración generados). Cualquier prueba con ellos daría cifras inventadas. Inténtalo de nuevo cuando vuelva la conexión.",
  "retry": "Reintentar"
 }
};
