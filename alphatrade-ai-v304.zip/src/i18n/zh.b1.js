// v276 translation batch 1 (menus, sign-in, account, plans, errors). Merged over the language file.
export default {
 "auth": {
  "providerMissing": "{provider} 登录尚未配置。请添加 Firebase 设置并启用该登录方式（见 .env.example）。",
  "demoAuthNote": "演示账户：仅保存在此浏览器中，不会发送邮件。添加 Firebase 设置即可启用真实认证。",
  "firebaseNote": "由 Firebase 提供身份验证",
  "resetDemo": "演示模式：无法发送邮件。你可以直接为这个本地账户设置新密码。",
  "err": {
   "providerDisabled": "该登录方式未在 Firebase 中启用。",
   "wrongPassword": "当前密码不正确。",
   "samePassword": "新密码与当前密码相同。",
   "unauthorizedDomain": "此域名未在 Firebase 中授权（Authentication → Settings → Authorized domains）。",
   "differentCredential": "此邮箱已使用其他登录方式，请用该方式登录。"
  }
 },
 "navShort": {
  "noticeSettings": "提醒与链接设置 →",
  "paper": "模拟交易"
 },
 "nav": {
  "smart-images": "智能图片",
  "paper": "模拟交易",
  "confluence": "共振实验室",
  "radar-tf": "最佳周期（1–15 分钟）",
  "radar-vol": "波动监测",
  "radar-liq": "流动性探测",
  "radar-risk": "自动风险",
  "radar-corr": "多周期相关性",
  "radar-perf": "绩效面板",
  "radar-heat": "市场热度扫描",
  "portfolio": "投资组合",
  "autotest": "自动回测",
  "correlation": "相关性矩阵",
  "learn": "策略详解",
  "more": "更多",
  "snapshot": "AI 市场分析",
  "performance": "策略结果",
  "palette": "网站配色",
  "pal_violet": "紫色",
  "pal_ocean": "海洋",
  "pal_teal": "青绿",
  "pal_gold": "金色",
  "pal_aurora": "极光（紫 + 青）",
  "pal_sunset": "日落（粉 + 橙）",
  "pal_royal": "皇家（靛蓝 + 金）",
  "pal_orchid": "兰花（粉 + 紫）",
  "pal_graphite": "石墨"
 },
 "status": {
  "demoPartial": "{symbols} 为演示模式——生成的测试数据，不是真实价格。其他品种为实时数据。",
  "whyDemo": "原因",
  "fallback": "无法连接数据源（{msg}），已切换到演示模式。",
  "providerDemo": "该品种没有 API 密钥——演示模式。"
 },
 "profile": {
  "photoHint": "JPG 或 PNG，最大 8 MB。照片保存在此设备上。",
  "photoSaved": "照片已更新。",
  "photoRemoved": "照片已删除。",
  "photoType": "请选择图片文件（JPG 或 PNG）。",
  "photoSize": "图片超过 8 MB。",
  "photoRead": "无法读取图片。",
  "providers": {
   "password": "邮箱和密码",
   "local": "本地账户（此浏览器）"
  },
  "noPassword": "你是通过 {provider} 登录的，这里没有可修改的密码。请在你的 {provider} 账户中管理。"
 },
 "ent": {
  "locked": "{plan} 套餐起包含。",
  "lockedTitle": "升级即可解锁",
  "seePlans": "查看套餐",
  "alertsFull": "你的套餐最多 {n} 条提醒和规则。请删除一条或升级。",
  "aiOut": "本月的深度 AI 分析已用完。升级可获得更多额度——内置分析引擎始终不限次数。",
  "moreSignals": "本月额度已用完。可加购推荐或升级套餐。",
  "tier": {
   "free": "无套餐",
   "trader": "交易者",
   "pro": "专业版",
   "elite": "精英版",
   "institutional": "机构版"
  },
  "aiLine": "每月 {n} 次深度 AI 分析",
  "carry": "未用额度可结转 {m} 个月",
  "noCarry": "不可结转",
  "localLine": "内置分析引擎：不限次数",
  "yourPlan": "你的套餐",
  "usage": "本月深度 AI 分析：{used} / {total}",
  "compare": "套餐对比",
  "row": "功能",
  "unlimited": "不限",
  "rows": {
   "core": "专业图表、指标、经典计划、交易日志",
   "frvp": "固定区间成交量分布",
   "strategies": "SMC v2 + Zone 策略",
   "radarFull": "全部 Alpha Radar 工具",
   "autotest": "优化与回测实验室",
   "quant": "量化层与亏损分析",
   "multiScreen": "多屏分析",
   "earlyAccess": "抢先体验",
   "signals": "每月推荐数",
   "alerts": "提醒与规则",
   "ai": "每月深度 AI 分析"
  },
  "feat": {
   "monthly": [
    "实时价格、专业图表和画线工具",
    "RSI、斐波那契突破与强势区域、成交量分布",
    "经典交易计划：入场、止损、3 个目标",
    "信号频道：每月 30 条推荐"
   ],
   "quarterly": [
    "包含交易者版全部内容，另加：",
    "固定区间成交量分布、POC 与价值区",
    "SMC v2 与 Zone 策略（0–100 评分）",
    "全部 Alpha Radar 工具",
    "自动优化与回测"
   ],
   "semiannual": [
    "包含专业版全部内容，另加：",
    "实时多屏分析",
    "亏损分析、市场状态学习与量化层",
    "优先支持 · 100 条提醒"
   ],
   "annual": [
    "包含精英版全部内容，另加：",
    "抢先体验新功能",
    "最大 AI 额度，可结转 2 个月",
    "不限提醒 · 最快支持"
   ],
   "prime": [
    "包含年付全部内容，另加：",
    "形态工作室"
   ],
   "apex": [
    "包含 Prime 全部内容，另加：",
    "AI 委员会：多个模型共同审核同一笔交易"
   ],
   "max": [
    "包含 Apex 全部内容，另加：",
    "实时流动性地图（订单簿热力图）"
   ]
  }
 },
 "pricing": {
  "perMonth": "≈ 每月 ${v}",
  "save": "节省 {pct}%（${v}）",
  "notConfigured": "该套餐的支付尚未设置。请在 .env 中添加支付链接后重新部署。",
  "redirect": "安全支付页面将在新标签页中打开。",
  "paidOk": "已收到付款，谢谢。Stripe 确认后一分钟内开通套餐，如未生效请刷新。",
  "signIn": "请先登录，以便付款关联到你的账户。",
  "payFail": "无法打开安全支付页面，请稍后重试。",
  "needSub": "加购信号前需要先有有效的套餐或频道订阅。",
  "note": "付款在支付服务商的安全页面完成，确认付款后即开通订阅。"
 },
 "errors": {
  "http": "服务器错误（{status}）",
  "network": "无法连接 {host}（网络、拦截或浏览器策略）",
  "planRequired": "不在你的数据服务商套餐范围内",
  "symbolInvalid": "数据服务商无法识别该品种",
  "badKey": "API 密钥无效",
  "rateLimit": "已达到服务商请求上限，稍后重试"
 }
};
