// v285 translation batch 2 (challenges menu entry, markets page, signals channel, real-data notices). Merged over the language file.
export default {
 "nav": {
  "challenges": "资金挑战赛"
 },
 "navShort": {
  "challenges": "资金挑战"
 },
 "pages": {
  "guideTitle": "使用指南",
  "strategiesTitle": "策略",
  "strategiesNote": "这些是教学思路，不构成投资建议。",
  "marketsTitle": "市场",
  "marketsSub": "点击品种即可在分析面板中打开。",
  "colSymbol": "品种",
  "colPrice": "价格",
  "colChange": "24小时涨跌",
  "colHigh": "最高",
  "colLow": "最低",
  "colVolume": "成交量",
  "colSource": "来源",
  "open": "打开",
  "indicatorsTitle": "指标"
 },
 "sig": {
  "title": "信号频道",
  "bar": "信号",
  "pts": "点",
  "acc": "准确率",
  "now": "现在",
  "atEntry": "入场时",
  "scanning": "正在用实时价格检验策略…",
  "watching": "实时 · 每秒更新",
  "none": "目前没有准确率达到 {min}% 以上的策略信号——频道会持续检查，一出现就发送。",
  "needLive": "频道需要实时价格——不会根据演示数据发送信号。",
  "status": {
   "pending": "等待入场",
   "expired": "已过期",
   "cancelled": "入场前已取消",
   "active": "进行中",
   "tp3": "3 个目标全部达成 ✓",
   "sl": "已止损",
   "be": "保本出场"
  },
  "chartNew": "图表上的新交易",
  "chartPending": "图表上的挂单交易（等待入场）",
  "newTitle": "新信号",
  "tpTitle": "目标 {n} 已达成 ✅",
  "slTitle": "信号已止损",
  "beTitle": "信号保本出场",
  "enable": "在此设备上开启通知",
  "notifAsk": "开启通知，即可在手机上收到每个信号和目标，并带有网站名称和标志。",
  "notifFailed": "浏览器没有显示通知。iPhone 上：把网站添加到主屏幕并从那里打开，并在设置中确认已允许通知。",
  "notifDenied": "此网站的通知已被阻止——请在浏览器设置中允许。",
  "notifOn": "通知已开启",
  "notifOnHelp": "网站打开期间（包括在后台）都会收到通知。",
  "notifNo": "此浏览器不支持通知",
  "iosHelp": "iPhone 上：用 Safari 打开网站 → 分享 →“添加到主屏幕”，然后从主屏幕打开应用并开启通知。",
  "enabledBody": "信号频道通知已开启 ✅",
  "test": "测试通知",
  "testTitle": "测试通知",
  "qualsTitle": "已检验的策略（达标 ≥ {min}%）",
  "qualified": "达标",
  "oos": "样本外",
  "trackTitle": "已发布信号的真实结果",
  "trackRate": "达到目标 1 或以上",
  "trackClosed": "已结束的信号",
  "trackTp2": "达到目标 2",
  "trackTp3": "达到目标 3",
  "trackSmall": "样本很小（仅 {n} 个信号）：至少有 20 个信号结束前，请不要依赖该比率。",
  "trackNone": "还没有信号结束。已发布的信号结束后，真实结果会显示在这里。",
  "clear": "清除已结束的信号"
 },
 "intro": {
  "welcome": "欢迎，{name}",
  "skip": "跳过",
  "granted": "登录成功"
 },
 "real": {
  "title": "目前没有真实市场数据",
  "body": "未显示结果，因为价格并非来自实时市场（生成的演示数据）。用它们做任何测试都只会得到虚构的数字。连接恢复后请重试。",
  "retry": "重试"
 }
};
