// Strategy versioning: every change to the settings that drive trading (strategy, its rules, the plan, risk, filters)
// is saved as a numbered version, so a result can be tied to the exact settings that produced it and any version
// can be restored. Chart-only display options (clean view, liquidity map, chart type…) do not create versions.
import { storage } from '../utils/storage.js';

const KEY = 'strategy-versions';
const MAX = 40;
/** Display-only settings: changing them never changes a trade, so they are left out of versions. */
export const VISUAL = ['chartType', 'chartClean', 'liqMap', 'vp', 'frvp', 'planLines', 'zones', 'preSmc'];

const relevant = (settings) => Object.fromEntries(Object.entries(settings || {}).filter(([k]) => !VISUAL.includes(k)));
const sig = (o) => JSON.stringify(Object.fromEntries(Object.keys(o).sort().map((k) => [k, o[k]])));   // top-level order independent

export const versions = () => storage.get(KEY, []);

/** Top-level sections that differ between two settings objects (display-only ones excluded). */
export function diffSections(a, b) {
  const A = relevant(a); const B = relevant(b);
  return [...new Set([...Object.keys(A), ...Object.keys(B)])].filter((k) => JSON.stringify(A[k]) !== JSON.stringify(B[k])).sort();
}

/** Saves a new version when the trading-relevant settings changed. Returns the (new or current) version. */
export function recordVersion(settings, { now = Date.now(), note = '' } = {}) {
  const list = versions();
  const rel = relevant(settings);
  const s = sig(rel);
  if (list[0] && list[0].sig === s) return list[0];
  const prev = list[0];
  const v = { n: (prev?.n || 0) + 1, at: now, strategy: settings?.strategy || 'classic', sig: s, settings: structuredClone(rel), changed: prev ? diffSections(prev.settings, rel) : [], note };
  storage.set(KEY, [v, ...list].slice(0, MAX));
  return v;
}

/** Settings to apply for a restore: the saved trading settings on top of the current display options. */
export function restoreSettings(n, current) {
  const v = versions().find((x) => x.n === n);
  if (!v) return null;
  const visual = Object.fromEntries(Object.entries(current || {}).filter(([k]) => VISUAL.includes(k)));
  return { ...structuredClone(v.settings), ...visual };
}
