// «توصية AI» (v234) — back-test of each strategy on its own, on real history, with the honest parts that matter:
//  • no look-ahead: the signal at bar i sees bars ≤ i only; the order fills on the NEXT bar's open; pivots only once confirmed;
//  • costs: spread + commission + slippage (config/aiSignalRules.js costModel) are paid on every filled trade, in R;
//  • management as the page shows it: a third closed at each target, stop to entry after TP1, a bar touching both the stop and
//    a target counts as the stop, a time exit after `maxBars`;
//  • a time split train 60 % / validation 20 % / test 20 % and a 4-window walk-forward. NOTHING is tuned on any of them:
//    every strategy runs on its fixed defaults, so the split measures stability instead of selecting the best fit;
//  • a naive baseline (EMA 200 direction, ATR stop, same management) and buy & hold for comparison;
//  • a Wilson 95 % interval on the win rate and a clear "small sample" flag.
// Results describe the past on the candles that were loaded; they are not a forecast.
import { snapshot, trendStrategy, meanReversionStrategy, presetCfg, DEFAULTS } from './multiStrategy.js';
import { paperSeries, PAPER, unavailableReason } from './aiPaperStrategies.js';
import { backtestSmcIct } from './smcBacktest.js';
import { cleanInputs } from './smcAssist.js';
import { PROMOTION } from '../config/aiSignalRules.js';
import { atr, ema } from '../indicators/index.js';

const r3 = (v) => (Number.isFinite(v) ? Math.round(v * 1000) / 1000 : null);

/**
 * Simulates one strategy. signalAt(i) → { direction, stop, targets } | null, computed from bars ≤ i.
 * → [{ i, exitI, direction, entry, r, bars, hour }]
 */
export function simulate(cs, signalAt, { costPct = 0, maxBars = 60, warmup = 210, beAfterTp1 = true } = {}) {
  const out = []; const n = cs.length;
  for (let i = warmup; i < n - 1; i++) {
    const s = signalAt(i); if (!s) continue;
    const long = s.direction === 'long'; const sg = long ? 1 : -1;
    const e = cs[i + 1].open; let stop = s.stop; const tg = s.targets;
    if ((e - stop) * sg <= 0 || (tg[0] - e) * sg <= 0) continue;       // gapped through the stop or TP1: no trade
    const risk = (e - stop) * sg; const costR = (e * costPct) / 100 / risk;
    let hits = 0, banked = 0, exitI = null, r = null;
    for (let j = i + 1; j < n && j <= i + maxBars; j++) {
      const c = cs[j];
      if (long ? c.low <= stop : c.high >= stop) { r = banked + ((3 - hits) / 3) * (((stop - e) * sg) / risk); exitI = j; break; }
      while (hits < 3 && (long ? c.high >= tg[hits] : c.low <= tg[hits])) { banked += (((tg[hits] - e) * sg) / risk) / 3; hits++; }
      if (hits >= 1 && beAfterTp1) stop = e;
      if (hits >= 3) { r = banked; exitI = j; break; }
    }
    if (r == null) {
      if (i + maxBars > n - 1) break;                       // still open when the data ends: not counted (no invented exit)
      const j = i + maxBars; r = banked + ((3 - hits) / 3) * (((cs[j].close - e) * sg) / risk); exitI = j;   // time exit
    }
    out.push({ i, exitI, direction: s.direction, entry: e, r: r3(r - costR), bars: exitI - i, hour: new Date(cs[i].time * 1000).getUTCHours() });
    i = exitI;   // one position at a time per strategy
  }
  return out;
}

/** Wilson score interval (95 %) for a win rate. */
export function wilson(wins, n, z = 1.96) {
  if (!n) return [null, null];
  const p = wins / n; const d = 1 + (z * z) / n; const c = p + (z * z) / (2 * n); const m = z * Math.sqrt((p * (1 - p)) / n + (z * z) / (4 * n * n));
  return [r3((c - m) / d), r3((c + m) / d)];
}

/** Statistics of a list of trades (R after costs). */
export function tradeStats(list) {
  const rs = list.map((x) => x.r); const n = rs.length;
  if (!n) return { n: 0, wins: 0, losses: 0, be: 0, winRate: null, ci: [null, null], avgR: null, expectancy: null, profitFactor: null, maxDD: 0, sharpe: null, sortino: null, avgBars: null, maxLossStreak: 0, small: true };
  let eq = 0, peak = 0, dd = 0, streak = 0, worst = 0;
  for (const r of rs) { eq += r; peak = Math.max(peak, eq); dd = Math.max(dd, peak - eq); streak = r < 0 ? streak + 1 : 0; worst = Math.max(worst, streak); }
  const wins = rs.filter((r) => r > 0.02).length, losses = rs.filter((r) => r < -0.02).length;
  const mean = eq / n; const sd = Math.sqrt(rs.reduce((s, r) => s + (r - mean) ** 2, 0) / Math.max(1, n - 1));
  const down = Math.sqrt(rs.reduce((s, r) => s + Math.min(0, r) ** 2, 0) / n);
  const gain = rs.filter((r) => r > 0).reduce((s, r) => s + r, 0), loss = -rs.filter((r) => r < 0).reduce((s, r) => s + r, 0);
  return { n, wins, losses, be: n - wins - losses, winRate: r3(wins / n), ci: wilson(wins, n), avgR: r3(mean), expectancy: r3(mean), totalR: r3(eq), profitFactor: loss > 0 ? r3(gain / loss) : null,
    maxDD: r3(dd), sharpe: sd > 0 ? r3(mean / sd) : null, sortino: down > 0 ? r3(mean / down) : null, avgBars: r3(list.reduce((s, x) => s + x.bars, 0) / n), maxLossStreak: worst, small: n < PROMOTION.minTestTrades };
}
const SESSION = (h) => (h < 7 ? 'asia' : h < 12 ? 'london' : h < 16 ? 'london_ny' : h < 21 ? 'new_york' : 'late');

/** Splits, walk-forward, sessions and the promotion verdict for one strategy's trades over `n` bars. */
export function evaluate(trades, n, warmup = 210) {
  const span = n - warmup; const at = (f) => warmup + Math.floor(span * f);
  const part = (a, b) => tradeStats(trades.filter((t) => t.i >= a && t.i < b));
  const train = part(warmup, at(0.6)), validation = part(at(0.6), at(0.8)), test = part(at(0.8), n);
  const windows = [0, 1, 2, 3].map((k) => part(at(k / 4), k === 3 ? n : at((k + 1) / 4)));
  const withTrades = windows.filter((w) => w.n);
  const positiveShare = withTrades.length ? withTrades.filter((w) => w.expectancy > 0).length / withTrades.length : 0;
  const bySession = {}; for (const t of trades) (bySession[SESSION(t.hour)] ||= []).push(t);
  const all = tradeStats(trades);
  const P = PROMOTION; const fails = [];
  if (test.n < P.minTestTrades) fails.push('test_sample');
  if (!(test.expectancy > P.minExpectancyR)) fails.push('test_expectancy');
  if (!(test.profitFactor >= P.minProfitFactor)) fails.push('test_pf');
  if (train.n && test.n && Math.abs(train.expectancy - test.expectancy) > P.maxTrainTestGapR) fails.push('unstable');
  if (positiveShare < P.minPositiveWindows) fails.push('walk_forward');
  return { all, train, validation, test, windows: windows.map((w) => ({ n: w.n, expectancy: w.expectancy })), positiveShare: r3(positiveShare),
    bySession: Object.fromEntries(Object.entries(bySession).map(([k, v]) => [k, tradeStats(v)])), meetsLive: fails.length === 0, fails };
}

/** Naive baseline: every 20 bars, trade the EMA 200 side with a 1.5 ATR stop and the same 1/2/3 R management. */
export function baselineSignals(cs) {
  const c = cs.map((x) => x.close); const e = ema(c, 200); const a = atr(cs, 14);
  return (i) => {
    if (i % 20 || e[i] == null || !a[i]) return null; const long = c[i] > e[i]; const sg = long ? 1 : -1; const stop = c[i] - sg * 1.5 * a[i]; const risk = 1.5 * a[i];
    return { direction: long ? 'long' : 'short', stop, targets: [1, 2, 3].map((k) => c[i] + sg * k * risk) };
  };
}

const LIVE_WINDOW = 400;   // the live strategies re-read a window like the page (closed candles only)
/** Signal function of a live strategy, on the same snapshot rules as the page (minus the live quote checks). */
function liveSignals(id, cs, { htf = null, tfSec, cfg, costPct }) {
  return (i) => {
    const w = cs.slice(Math.max(0, i - LIVE_WINDOW + 1), i + 1); if (w.length < 210) return null;
    const S = snapshot(w, { htf: null, tfSec });
    const st = id === 'trend' ? trendStrategy(S, { minRR: cfg.minRR, costPct, adxTrend: cfg.adxTrend, ai: true }) : meanReversionStrategy(S, { minRR: cfg.minRR, costPct, rsiLo: cfg.rsiLo, rsiHi: cfg.rsiHi, adxRange: cfg.adxRange, ai: true });
    return st.status === 'qualified' && st.plan ? { direction: st.direction, stop: st.plan.stop, targets: st.plan.targets } : null;
  };
}

/**
 * The whole suite on one market / timeframe. ctx: { symbol, tf, tfSec, assetClass, volumeKind, costPct, style, source }
 * → { at, symbol, tf, bars, from, to, costPct, source, strategies: { id: evaluate(...) | { unavailable } }, baseline, buyHold, notes }
 */
export async function runSuite(cs, ctx, { onProgress = null, isCancelled = null, ids = null } = {}) {
  const n = cs.length; const tfSec = ctx.tfSec || 900; const costPct = ctx.costPct ?? 0; const cfg = { ...DEFAULTS, ...presetCfg('balanced') };
  const res = { at: Date.now(), symbol: ctx.symbol, tf: ctx.tf, style: ctx.style, bars: n, from: cs[0]?.time, to: cs.at(-1)?.time, costPct, source: ctx.source || null, strategies: {}, notes: [] };
  if (n < 400) { res.error = 'not_enough_history'; return res; }
  const tick = async (k, total) => { onProgress?.(k / total); await new Promise((r) => setTimeout(r, 0)); if (isCancelled?.()) throw new Error('cancelled'); };
  const T = paperSeries(cs, { volumeKind: ctx.volumeKind });
  const list = ids || ['trend', 'mean_reversion', 'smc', ...Object.keys(PAPER)];
  let k = 0;
  for (const id of list) {
    await tick(k++, list.length + 1);
    if (id === 'smc') {
      const smc = await backtestSmcIct(cs, { ...cleanInputs({ style: ctx.style, execution: 'market', asset: ctx.assetClass, costPct }), symbol: ctx.symbol, tf: ctx.tf, tfSec }, { window: 300, horizon: 200, isCancelled });
      if (smc.error) { res.strategies.smc = { unavailable: smc.error }; continue; }
      const idx = new Map(cs.map((c, i) => [c.time, i]));
      const trades = smc.trades.map((t) => { const i = idx.get(t.time) ?? 0; const e = idx.get(t.closedAt) ?? i; return { i, exitI: e, direction: t.direction, entry: t.entry, r: r3(t.resultR), bars: e - i, hour: new Date(t.time * 1000).getUTCHours() }; });
      res.strategies.smc = { ...evaluate(trades, n, 300), engine: 'smcBacktest (site engine rules, market entries, chart-only higher frames)' };
      continue;
    }
    if (id === 'trend' || id === 'mean_reversion') { res.strategies[id] = evaluate(simulate(cs, liveSignals(id, cs, { tfSec, cfg, costPct }), { costPct }), n); continue; }
    const why = unavailableReason(id, { volumeKind: ctx.volumeKind, assetClass: ctx.assetClass, tf: ctx.tf });
    if (why) { res.strategies[id] = { unavailable: why }; continue; }
    const c2 = { assetClass: ctx.assetClass, tf: ctx.tf, tfSec };
    res.strategies[id] = evaluate(simulate(cs, (i) => { try { return PAPER[id](T, i, c2); } catch { return null; } }, { costPct }), n);
  }
  await tick(list.length, list.length + 1);
  res.baseline = evaluate(simulate(cs, baselineSignals(cs), { costPct }), n);
  res.buyHoldPct = r3(((cs.at(-1).close - cs[210].close) / cs[210].close) * 100);
  res.notes = ['no_tuning', 'next_open_fill', 'costs_included', 'stop_first', 'htf_chart_only'];
  onProgress?.(1);
  return res;
}
