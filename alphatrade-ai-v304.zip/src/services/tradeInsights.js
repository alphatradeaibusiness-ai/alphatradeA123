// Smart trade log: analyses a list of closed trades and finds where a strategy makes or loses
// money — by strategy, asset, timeframe, direction, trading session, weekday, hour, volatility,
// trend alignment, result type and the trade after a loss. Pure functions (no DOM), unit-tested.
//
// Trade shape (normalised): { symbol, tf, strategy, direction, openTime (ms), closeTime (ms),
//   r (result in R), hits (0–3 or null), atrPct (volatility at entry, optional),
//   withTrend (true/false/null), source }

export const MIN_SEG = 5; // smallest group size worth judging

const mean = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0);
const sd = (a) => { if (a.length < 2) return 0; const m = mean(a); return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1)); };

/** Win / loss statistics in R. */
export function statsR(trades) {
  const rs = trades.map((t) => t.r);
  const wins = rs.filter((r) => r > 0);
  const losses = rs.filter((r) => r < 0);
  const gw = wins.reduce((s, r) => s + r, 0);
  const gl = -losses.reduce((s, r) => s + r, 0);
  // Max drawdown of the cumulative R curve (in time order).
  let cum = 0; let peak = 0; let dd = 0; let streak = 0; let worst = 0; let wstreak = 0; let best = 0;
  for (const t of [...trades].sort((a, b) => a.closeTime - b.closeTime)) {
    cum += t.r; peak = Math.max(peak, cum); dd = Math.max(dd, peak - cum);
    streak = t.r < 0 ? streak + 1 : 0; worst = Math.max(worst, streak);
    wstreak = t.r > 0 ? wstreak + 1 : 0; best = Math.max(best, wstreak);
  }
  return {
    n: trades.length, wins: wins.length, losses: losses.length, winRate: trades.length ? (wins.length / trades.length) * 100 : 0,
    avgR: mean(rs), sdR: sd(rs), netR: rs.reduce((s, r) => s + r, 0), pf: gl > 0 ? gw / gl : gw > 0 ? Infinity : 0,
    avgWin: wins.length ? gw / wins.length : 0, avgLoss: losses.length ? gl / losses.length : 0, maxDD: dd, lossStreak: worst, winStreak: best,
  };
}

/** Trading session from the UTC hour of entry. */
export function sessionOf(ms) {
  const h = new Date(ms).getUTCHours();
  if (h >= 13 && h < 17) return 'overlap'; // London + New York
  if (h >= 7 && h < 13) return 'london';
  if (h >= 17 && h < 21) return 'newyork';
  return 'asia';
}
export const volBucket = (p) => (p == null ? null : p < 0.35 ? 'low' : p < 0.9 ? 'mid' : 'high');
export const outcomeOf = (t) => (t.hits == null ? (t.r < 0 ? 'loss' : t.r < 0.5 ? 'small' : 'win') : t.hits === 0 ? 'sl' : t.hits >= 3 ? 'tp3' : `tp${t.hits}be`);

export const DIMENSIONS = {
  strategy: (t) => t.strategy || null,
  symbol: (t) => t.symbol || null,
  tf: (t) => t.tf || null,
  direction: (t) => t.direction || null,
  session: (t) => (t.openTime ? sessionOf(t.openTime) : null),
  weekday: (t) => (t.openTime ? String(new Date(t.openTime).getUTCDay()) : null),
  volatility: (t) => volBucket(t.atrPct),
  trend: (t) => (t.withTrend == null ? null : t.withTrend ? 'with' : 'against'),
  afterLoss: (t) => t.afterLoss ?? null,
};

/** Mark each trade with whether the previous trade (same strategy & symbol) lost. */
function markAfterLoss(trades) {
  const last = new Map();
  for (const t of [...trades].sort((a, b) => a.openTime - b.openTime || a.closeTime - b.closeTime)) {
    const k = `${t.strategy}|${t.symbol}|${t.tf}`;
    if (last.has(k)) t.afterLoss = last.get(k) < 0 ? 'afterLoss' : 'afterWin';
    last.set(k, t.r);
  }
}

/** Groups for one dimension, with how each differs from the overall average. */
export function breakdown(trades, dim, overall) {
  const key = DIMENSIONS[dim];
  const groups = new Map();
  for (const t of trades) {
    const k = key(t);
    if (k == null) continue;
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(t);
  }
  return [...groups.entries()].map(([k, list]) => {
    const s = statsR(list);
    // How sure we are that this group really differs from the rest (rough t-score).
    const z = s.n >= 2 && overall.sdR > 0 ? ((s.avgR - overall.avgR) * Math.sqrt(s.n)) / overall.sdR : 0;
    return { dim, key: k, ...s, z, share: s.n / trades.length };
  }).sort((a, b) => b.avgR - a.avgR);
}

/** Average R per UTC hour of entry (24 cells). */
export function byHour(trades) {
  const cells = Array.from({ length: 24 }, (_, h) => ({ h, list: [] }));
  for (const t of trades) if (t.openTime) cells[new Date(t.openTime).getUTCHours()].list.push(t.r);
  return cells.map((c) => ({ h: c.h, n: c.list.length, avgR: mean(c.list) }));
}

/**
 * Full analysis: overall stats, breakdowns, strengths, weaknesses, rule-of-thumb diagnostics,
 * and a "what if" that removes the weak groups.
 */
export function analyzeTrades(input, { minSeg = MIN_SEG } = {}) {
  const trades = input.filter((t) => Number.isFinite(t.r)).map((t) => ({ ...t }));
  markAfterLoss(trades);
  const overall = statsR(trades);
  const dims = {};
  for (const d of Object.keys(DIMENSIONS)) dims[d] = breakdown(trades, d, overall);
  const outcomes = {};
  for (const t of trades) { const o = outcomeOf(t); outcomes[o] = (outcomes[o] || 0) + 1; }

  const all = Object.values(dims).flat().filter((g) => g.n >= minSeg && g.share < 0.97); // a group that is everything says nothing
  const strengths = all.filter((g) => g.avgR > 0 && g.avgR > overall.avgR && g.z >= 0.8).sort((a, b) => b.z - a.z).slice(0, 5);
  const weaknesses = all.filter((g) => g.avgR < 0 && g.avgR < overall.avgR && g.z <= -0.8).sort((a, b) => a.z - b.z).slice(0, 5);

  // What if the clearly losing groups were skipped (one per dimension, worst first)?
  const skip = [];
  const usedDims = new Set();
  for (const w of weaknesses) { if (usedDims.has(w.dim)) continue; usedDims.add(w.dim); skip.push(w); if (skip.length === 2) break; }
  const kept = trades.filter((t) => !skip.some((w) => DIMENSIONS[w.dim](t) === w.key));
  const whatIf = skip.length ? { skip, before: overall, after: statsR(kept) } : null;

  // Diagnostics on how trades end.
  const diag = [];
  const n = trades.length;
  if (n >= minSeg * 2) {
    const slRate = (outcomes.sl || 0) / n;
    const tp1be = ((outcomes.tp1be || 0) + (outcomes.tp2be || 0)) / n;
    const tp3 = (outcomes.tp3 || 0) / n;
    if (slRate > 0.6) diag.push({ key: 'stopTight', v: slRate * 100 });
    if (tp1be > 0.35) diag.push({ key: 'beOften', v: tp1be * 100 });
    if (trades.some((t) => t.hits != null) && tp3 < 0.05) diag.push({ key: 'tp3Rare', v: tp3 * 100 });
    if (overall.winRate >= 55 && overall.avgR < 0) diag.push({ key: 'smallWins', v: overall.winRate });
    if (overall.winRate < 40 && overall.avgR > 0) diag.push({ key: 'lowWinPositive', v: overall.winRate });
    if (overall.lossStreak >= 6) diag.push({ key: 'longStreak', v: overall.lossStreak });
    const al = dims.afterLoss.find((g) => g.key === 'afterLoss'); const aw = dims.afterLoss.find((g) => g.key === 'afterWin');
    if (al && aw && al.n >= minSeg && al.avgR < aw.avgR - 0.25) diag.push({ key: 'tilt', v: al.avgR });
    if (overall.avgLoss > 1.15) diag.push({ key: 'bigLosses', v: overall.avgLoss });
  }

  // Grade from expectancy and profit factor.
  const score = Math.max(0, Math.min(100, 50 + overall.avgR * 120 + (Math.min(overall.pf, 3) - 1) * 15 - Math.min(20, overall.maxDD * 1.5)));
  const grade = n < minSeg ? null : score >= 80 ? 'A' : score >= 65 ? 'B' : score >= 50 ? 'C' : score >= 35 ? 'D' : 'F';
  return { trades, overall, dims, hours: byHour(trades), outcomes, strengths, weaknesses, whatIf, diag, score, grade };
}
