// One clear reading of the open chart, built only from data the platform already has:
// chart trend (EMA 20/50), higher-timeframe trend (real 4h / daily candles), momentum, RSI extremes,
// volatility regime (ATR now vs its own recent history), SMC structure (last BOS/CHoCH, premium/discount)
// and news risk (the economic calendar). It is an explanation, not a trade signal: when the parts
// disagree, a high-impact release is close, or data is missing, the answer is "wait" and says why.
import { ema, atr } from '../indicators/index.js';
import { smcFull } from '../indicators/smc.js';
import { CCY_IMPACT } from './news.js';

/**
 * The calendar's risk for one symbol around `now`: a high-impact release that moves this symbol
 * within the next `aheadMin` minutes or released in the last `afterMin` minutes.
 * Returns { level: 'high' | 'soon' | 'none', event?, minutes? } (minutes > 0 = still to come).
 */
export function newsRisk(symbol, events, now = Date.now(), { aheadMin = 60, soonMin = 240, afterMin = 30 } = {}) {
  if (!Array.isArray(events) || !events.length) return { level: 'none', known: Array.isArray(events) };
  const moves = (e) => (CCY_IMPACT[e.country] || CCY_IMPACT.ALL || []).includes(symbol);
  const high = events.filter((e) => String(e.impact).toLowerCase() === 'high' && moves(e));
  const near = high.find((e) => e.time - now <= aheadMin * 60_000 && now - e.time <= afterMin * 60_000);
  if (near) return { level: 'high', event: near, minutes: Math.round((near.time - now) / 60_000), known: true };
  const soon = high.find((e) => e.time > now && e.time - now <= soonMin * 60_000);
  if (soon) return { level: 'soon', event: soon, minutes: Math.round((soon.time - now) / 60_000), known: true };
  return { level: 'none', known: true };
}

const sideOf = (v, up, down) => (v >= up ? 'bull' : v <= down ? 'bear' : 'neutral');

function htfSide(candles, period) {
  if (!candles || candles.length < period + 5) return null;
  const closes = candles.map((c) => c.close);
  const e = ema(closes, period);
  const last = closes.length - 1;
  const slope = e[last] - e[Math.max(0, last - 5)];
  if (closes[last] > e[last] && slope > 0) return 'bull';
  if (closes[last] < e[last] && slope < 0) return 'bear';
  return 'neutral';
}

let smcMemo = { key: '', value: null };

/**
 * @param an       computeAnalysis() result (ema20, ema50, rsi, momentum, plan, mode…)
 * @param candles  the chart candles (the forming one last)
 * @param htf      { h4, d1 } real higher-timeframe candles, or null
 * @param news     newsRisk() result, or null when the calendar could not be loaded
 * @returns { stance: 'long'|'short'|'wait', confidence: 'low'|'medium'|'high', factors: [{ key, side, params }], reasons: [key], score }
 */
export function synthesize(an, candles, htf, news) {
  if (!an || !candles || candles.length < 60) return { stance: 'wait', confidence: 'low', factors: [], reasons: ['short'], score: 0 };
  const closed = candles.slice(0, -1);
  const last = closed.length - 1;
  const px = closed[last].close;
  const factors = [];
  const add = (key, side, params = {}, weight = 1) => factors.push({ key, side, params, weight });

  // 1. Chart trend: EMA 20 against EMA 50 and price against both.
  const e20 = an.ema20?.[last]; const e50 = an.ema50?.[last];
  if (Number.isFinite(e20) && Number.isFinite(e50)) {
    const side = px > e20 && e20 > e50 ? 'bull' : px < e20 && e20 < e50 ? 'bear' : 'neutral';
    add('trend', side, {}, 1);
  }
  // 2. Higher timeframes (real candles only).
  const h4 = htfSide(htf?.h4, 50); const d1 = htfSide(htf?.d1, 20);
  if (h4 || d1) {
    const side = h4 && d1 ? (h4 === d1 ? h4 : 'neutral') : (h4 || d1);
    add('htf', side, { h4: h4 || '-', d1: d1 || '-' }, 1.5);
  } else add('htfMissing', 'neutral', {}, 0);
  // 3. Momentum score (0–100).
  const m = an.momentum?.score;
  if (Number.isFinite(m)) add('momentum', sideOf(m, 58, 42), { v: Math.round(m) }, 1);
  // 4. RSI extremes are a caution, not a direction.
  const r = an.rsi?.[last];
  if (Number.isFinite(r) && (r >= 72 || r <= 28)) add(r >= 72 ? 'rsiHigh' : 'rsiLow', 'risk', { v: Math.round(r) }, 0);
  // 5. Volatility regime: ATR% now against the median of the last 100 candles.
  const a = atr(closed, 14);
  const pct = a.slice(-100).map((v, i, arr) => v / closed[closed.length - arr.length + i].close * 100).filter(Number.isFinite);
  const now = pct.at(-1);
  if (Number.isFinite(now) && pct.length >= 30) {
    const med = [...pct].sort((x, y) => x - y)[Math.floor(pct.length / 2)];
    const ratio = med > 0 ? now / med : 1;
    add('vol', ratio >= 1.6 ? 'risk' : 'neutral', { ratio: Math.round(ratio * 100) / 100, state: ratio >= 1.6 ? 'high' : ratio <= 0.6 ? 'low' : 'normal' }, 0);
  }
  // 6. Smart-money structure: last break and where price sits in the dealing range.
  const key = `${closed.length}|${closed[last].time}|${closed[last].close}`;
  if (smcMemo.key !== key) smcMemo = { key, value: smcFull(closed) };
  const smc = smcMemo.value;
  if (smc?.lastBreak) {
    const ev = smc.lastBreak;
    add('smc', ev.dir === 'bull' ? 'bull' : 'bear', { kind: ev.kind, ago: last - ev.index }, last - ev.index <= 30 ? 1 : 0.5);
  }
  if (smc?.range) {
    const zone = px > smc.range.eq ? 'premium' : 'discount';
    add('pd', 'neutral', { zone }, 0);
  }
  // 7. News risk.
  if (news && news.level !== 'none') add(news.level === 'high' ? 'newsHigh' : 'newsSoon', 'risk', { title: news.event?.title || '', m: news.minutes }, 0);
  else if (!news || news.known === false) add('newsUnknown', 'neutral', {}, 0);

  // Weighted vote of the directional parts.
  const score = factors.reduce((s, f) => s + (f.side === 'bull' ? f.weight : f.side === 'bear' ? -f.weight : 0), 0);
  const directional = factors.filter((f) => f.weight > 0);
  const agree = directional.filter((f) => f.side === (score > 0 ? 'bull' : 'bear')).length;
  const reasons = [];
  let stance = Math.abs(score) >= 2 ? (score > 0 ? 'long' : 'short') : 'wait';
  if (stance === 'wait') reasons.push('mixed');
  if (news?.level === 'high') { stance = 'wait'; reasons.push('news'); }
  if (an.mode !== 'live') { stance = 'wait'; reasons.push('demo'); }
  // Buying at the top of the range or selling at the bottom is a caution.
  const pd = factors.find((f) => f.key === 'pd')?.params.zone;
  if ((stance === 'long' && pd === 'premium') || (stance === 'short' && pd === 'discount')) reasons.push('pdAgainst');
  const highVol = factors.some((f) => f.key === 'vol' && f.side === 'risk');
  if (highVol) reasons.push('highVol');
  let confidence = 'low';
  if (stance !== 'wait') confidence = agree >= 4 && !highVol && !reasons.includes('pdAgainst') ? 'high' : agree >= 3 ? 'medium' : 'low';
  return { stance, confidence, factors, reasons, score: Math.round(score * 10) / 10 };
}

/**
 * Why a radar result exists, in plain parts (no blind buy / sell): what agrees, what argues against, and the state.
 * `r` is a radarScore() result. Returns { state: 'setup' | 'watch' | 'avoid', pros: [{key, params}], cons: [{key, params}] }.
 */
export function explainRadar(r, news = null) {
  const pros = []; const cons = [];
  const long = r.direction === 'long';
  const want = long ? 1 : -1;
  if (Number.isFinite(r.trend)) (Math.sign(r.trend) === want ? pros : cons).push({ key: 'trend', params: { strong: Math.abs(r.trend) >= 1 } });
  if (Number.isFinite(r.momentum)) {
    if ((long && r.momentum >= 55) || (!long && r.momentum <= 45)) pros.push({ key: 'momentum', params: { v: Math.round(r.momentum) } });
    else if ((long && r.momentum <= 45) || (!long && r.momentum >= 55)) cons.push({ key: 'momentumAgainst', params: { v: Math.round(r.momentum) } });
  }
  if (r.event) (((r.event.dir === 'bull') === long) ? pros : cons).push({ key: 'smc', params: { kind: r.event.kind, ago: r.event.ago } });
  if (Number.isFinite(r.rsi) && ((long && r.rsi > 72) || (!long && r.rsi < 28)) && !(r.filters?.unstable || []).concat(r.filters?.weak || []).includes('rsiStretched')) cons.push({ key: 'stretched', params: { v: Math.round(r.rsi) } });
  if (r.trades >= 5) (r.winRate >= 55 ? pros : r.winRate < 45 ? cons : pros).push({ key: r.winRate >= 45 ? 'history' : 'historyWeak', params: { rate: Math.round(r.winRate), n: r.trades } });
  else cons.push({ key: 'fewTrades', params: { n: r.trades || 0 } });
  if (r.setup) (r.aligned ? pros : cons).push({ key: r.aligned ? 'setup' : 'setupOpposite', params: { status: r.setup.status } });
  for (const k of r.filters?.unstable || []) cons.push({ key: `rf.${k}`, params: {} });
  for (const k of r.filters?.weak || []) cons.push({ key: `rf.${k}`, params: {} });
  if (news?.level === 'high') cons.push({ key: 'news', params: { title: news.event?.title || '', m: news.minutes } });
  const state = r.verdict === 'unstable' || news?.level === 'high' ? 'avoid' : r.setup && r.aligned && r.verdict === 'strong' ? 'setup' : 'watch';
  return { state, pros, cons };
}
