// The market-data key (Twelve Data: gold, indices, forex). Lives only on the server, encrypted; the browser sends it once
// when the owner saves it and afterwards only ever sees its last 4 characters.
import { apiRequest } from '../ai/gateway.js';
import { resetMarketAvailability } from './index.js';

let last = null; const listeners = new Set();
export const onMarketKey = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
export const lastMarketKey = () => last;
function publish(st) { last = { ...st, at: Date.now() }; listeners.forEach((fn) => { try { fn(last); } catch { /* one view must not break the others */ } }); return last; }

export async function marketKeyStatus() {
  try { return publish(await apiRequest('GET', '/api/market/status', undefined, 10000)); }
  catch (e) { return publish({ state: e.code === 'server_missing' || e.code === 'server_unreachable' ? 'no_server' : 'unknown', error: e.code }); }
}
async function owner(method, path, body, ms) {
  const r = await apiRequest(method, path, body, ms);
  publish(r.status);
  resetMarketAvailability();   // every symbol is asked again with the new key (or with none)
  return r;
}
export const saveMarketKey = (apiKey) => owner('PUT', '/api/market/config', { apiKey }, 60000);
export const testMarketKey = () => owner('POST', '/api/market/config/test', {}, 60000);
export const deleteMarketKey = () => owner('DELETE', '/api/market/config', undefined, 20000);
