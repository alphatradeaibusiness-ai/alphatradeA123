// Yahoo Finance public chart API (no API key needed) — real prices for gold,
// indices and forex. Used as a free live provider so the app never has to fall
// back to generated demo data for these instruments.
import { fetchJson } from '../../utils/http.js';

export const YAHOO_SOURCE = 'Yahoo Finance';

// The browser cannot call query1.finance.yahoo.com directly (CORS). The site proxies
// it through /yahoo/* (see _redirects), so requests stay on the site's own origin.
// Direct hosts are kept as fallbacks for non-Netlify deployments.
const YAHOO_BASES = ['/yahoo', 'https://query1.finance.yahoo.com', 'https://query2.finance.yahoo.com'];
let goodBase = null;
function yahooBases() {
  return goodBase ? [goodBase, ...YAHOO_BASES.filter((b) => b !== goodBase)] : YAHOO_BASES;
}

// Map our symbols to Yahoo chart tickers.
export const YAHOO_SYMBOLS = {
  XAUUSD: 'GC=F',      // gold futures (USD/oz)
  US30: '^DJI',        // Dow Jones Industrial Average
  US100: '^NDX',       // NASDAQ-100
  SPX500: '^GSPC',     // S&P 500
  EURUSD: 'EURUSD=X',
  GBPUSD: 'GBPUSD=X',
  USDJPY: 'USDJPY=X',
  USDCHF: 'USDCHF=X',
  AUDUSD: 'AUDUSD=X',
  NZDUSD: 'NZDUSD=X',
  USDCAD: 'USDCAD=X',
  EURGBP: 'EURGBP=X',
  EURJPY: 'EURJPY=X',
  GBPJPY: 'GBPJPY=X',
  // World indices
  UK100: '^FTSE',
  GER40: '^GDAXI',
  FRA40: '^FCHI',
  EU50: '^STOXX50E',
  JP225: '^N225',
  HK50: '^HSI',
  AUS200: '^AXJO',
  SPAIN35: '^IBEX',
  SWISS20: '^SSMI',
  NED25: '^AEX',
  KOSPI: '^KS11',
  INDIA50: '^NSEI',
  // Metals & energy
  XAGUSD: 'SI=F',
  XPTUSD: 'PL=F',
  USOIL: 'CL=F',
  UKOIL: 'BZ=F',
  NATGAS: 'NG=F',
  COPPER: 'HG=F',
  // v247: Alpha Elite Signals only
  US2000: '^RUT',
  XPDUSD: 'PA=F',
  // v248: «توصية AI» only
  EURCHF: 'EURCHF=X',
  AUDJPY: 'AUDJPY=X',
  CADJPY: 'CADJPY=X',
};

// Yahoo interval names per our timeframe ids.
const INTERVALS = { '1m': '1m', '5m': '5m', '15m': '15m', '1h': '1h', '4h': '1h', '1D': '1d' };

function check(body) {
  const err = body?.chart?.error;
  if (err) throw new Error(err.description || 'Yahoo Finance error');
  const result = body?.chart?.result?.[0];
  if (!result) throw new Error('Yahoo Finance: empty response');
  return result;
}

async function yahooChart(symbol, interval, range) {
  const path = `/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${interval}&range=${range}`;
  let lastErr;
  for (const base of yahooBases()) {
    try {
      const r = check(await fetchJson(`${base}${path}`, { timeoutMs: 9000 }));
      goodBase = base;
      return r;
    } catch (e) {
      lastErr = e;
      // A real 4xx answer (bad symbol) — do not retry elsewhere.
      if (e.code === 'http' && e.status && e.status < 500 && ![403, 404, 418, 429, 451].includes(e.status)) throw e;
    }
  }
  throw lastErr;
}

/** Real candles for a symbol/timeframe (newest last). */
export async function fetchYahooCandles(yahooSymbol, tf, limit = 500) {
  const interval = INTERVALS[tf] || '1h';
  // Yahoo caps intraday history; request enough range for the limit.
  // Yahoo's limits: 1m → 7 days, other intraday → 60 days; ask for more only when the caller needs a deep history.
  const range = tf === '1D' ? '2y' : tf === '4h' ? '3mo' : tf === '1h' ? (limit > 700 ? '6mo' : '1mo') : tf === '1m' ? (limit > 1500 ? '7d' : '5d') : (limit > 1200 ? '60d' : '5d');
  const r = await yahooChart(yahooSymbol, interval, range);
  const ts = r.timestamp || [];
  const q = r.indicators?.quote?.[0] || {};
  const closes = q.close || [], opens = q.open || [], highs = q.high || [], lows = q.low || [], vols = q.volume || [];
  const candles = [];
  for (let i = 0; i < ts.length; i++) {
    const c = closes[i];
    if (!Number.isFinite(c)) continue; // skip gaps
    candles.push({
      time: ts[i],
      open: Number.isFinite(opens[i]) ? opens[i] : c,
      high: Number.isFinite(highs[i]) ? highs[i] : c,
      low: Number.isFinite(lows[i]) ? lows[i] : c,
      close: c,
      volume: Number.isFinite(vols[i]) && vols[i] > 0 ? vols[i] : null,
      buyVolume: null,
    });
  }
  // 4h aggregation from 1h candles.
  if (tf === '4h') return aggregate4h(candles);
  return candles.slice(-limit);
}

function aggregate4h(hourly) {
  const out = [];
  for (const c of hourly) {
    const bucket = Math.floor(c.time / 14400) * 14400;
    const last = out[out.length - 1];
    if (last && last.time === bucket) {
      last.high = Math.max(last.high, c.high);
      last.low = Math.min(last.low, c.low);
      last.close = c.close;
      if (c.volume != null) last.volume = (last.volume || 0) + c.volume;
    } else {
      out.push({ time: bucket, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume, buyVolume: null });
    }
  }
  return out;
}

/** Latest quote for a symbol. */
export async function fetchYahooQuote(yahooSymbol) {
  const r = await yahooChart(yahooSymbol, '1m', '1d');
  const meta = r.meta || {};
  const ts = r.timestamp || [];
  const closes = r.indicators?.quote?.[0]?.close || [];
  let price = Number(meta.regularMarketPrice);
  for (let i = closes.length - 1; i >= 0; i--) {
    if (Number.isFinite(closes[i])) { price = closes[i]; break; }
  }
  if (!Number.isFinite(price)) throw new Error('Yahoo Finance: no price');
  return {
    at: (meta.regularMarketTime || Math.floor(Date.now() / 1000)) * 1000,
    price,
    changePct: Number(meta.regularMarketChangePercent) || 0,
    high: Number(meta.regularMarketDayHigh) || price,
    low: Number(meta.regularMarketDayLow) || price,
    volume: Number(meta.regularMarketVolume) || null,
  };
}

export const yahooSymbolFor = (ourSymbol) => YAHOO_SYMBOLS[ourSymbol] || null;
