// Demo-mode data generator. Produces deterministic, realistic-looking candles so the
// interface can be tested without network access. These are NOT market prices and the
// UI labels them as Demo Mode everywhere they appear.
import { getInstrument } from '../../config/instruments.js';
import { TIMEFRAMES } from '../../config/market.js';

function hashString(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

function mulberry32(seed) {
  let a = seed;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function gaussian(rand) {
  const u = Math.max(rand(), 1e-12);
  const v = rand();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

const BASE_VOLUME = { BTCUSDT: 900, ETHUSDT: 9000, SOLUSDT: 60000, BNBUSDT: 15000, XAUUSD: 4000, US30: 3000, US100: 3000, SPX500: 3000 };

/**
 * @param {string} symbol
 * @param {string} tf timeframe id
 * @param {number} count number of candles
 * @param {number} [now] epoch ms (defaults to Date.now())
 */
export function generateDemoCandles(symbol, tf, count = 500, now = Date.now()) {
  const inst = getInstrument(symbol);
  const tfDef = TIMEFRAMES.find((x) => x.id === tf) || TIMEFRAMES[4];
  const sec = tfDef.seconds;
  const rand = mulberry32(hashString(`${symbol}|${tf}`));
  const vol = 0.0042 * Math.sqrt(sec / 3600) * (inst.type === 'metal' || inst.type === 'index' ? 0.35 : symbol === 'BTCUSDT' ? 1 : 1.25);
  const endTime = Math.floor(now / 1000 / sec) * sec;
  const startTime = endTime - (count - 1) * sec;
  const baseVol = (BASE_VOLUME[symbol] || 1000) * (sec / 3600);

  // Walk backwards from the seed so the latest prices stay near the instrument's demo seed.
  const rets = [];
  let regime = 0;
  for (let i = 0; i < count; i++) {
    if (rand() < 0.03) regime = (rand() - 0.5) * vol * 0.5;
    rets.push(regime + gaussian(rand) * vol);
  }
  const closes = new Array(count);
  closes[count - 1] = inst.demoSeed * (1 + (rand() - 0.5) * 0.02);
  for (let i = count - 1; i > 0; i--) closes[i - 1] = closes[i] / Math.exp(rets[i]);

  const candles = [];
  for (let i = 0; i < count; i++) {
    const c = closes[i];
    const o = i === 0 ? c / Math.exp(rets[0]) : closes[i - 1];
    const wick = Math.abs(gaussian(rand)) * vol * 0.6;
    const high = Math.max(o, c) * (1 + wick * rand());
    const low = Math.min(o, c) * (1 - wick * rand());
    const move = Math.abs(rets[i]) / vol;
    const volume = baseVol * (0.45 + rand() * 0.6 + move * 0.55);
    const bias = Math.max(-0.35, Math.min(0.35, (rets[i] / vol) * 0.12 + (rand() - 0.5) * 0.18));
    const round = (v) => Math.round(v * 10 ** inst.precision) / 10 ** inst.precision;
    candles.push({
      time: startTime + i * sec,
      open: round(o), high: round(high), low: round(low), close: round(c),
      volume: Math.round(volume * 1000) / 1000,
      buyVolume: Math.round(volume * (0.5 + bias) * 1000) / 1000,
    });
  }
  return candles;
}

export function demoTicker(symbol, now = Date.now()) {
  const c = generateDemoCandles(symbol, '1h', 25, now);
  const last = c[c.length - 1].close;
  const first = c[0].open;
  return {
    symbol,
    price: last,
    changePct: ((last - first) / first) * 100,
    high: Math.max(...c.map((x) => x.high)),
    low: Math.min(...c.map((x) => x.low)),
    volume: c.reduce((a, x) => a + x.volume, 0),
  };
}
