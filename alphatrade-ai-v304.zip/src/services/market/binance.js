// Binance public market data (no API key). Docs: https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints
import { marketConfig } from '../../config/market.js';
import { fetchJson } from '../../utils/http.js';

export const BINANCE_SOURCE = 'Binance';

// Some networks / countries block data-api.binance.vision. The request then falls back, in order, to this site's own proxy
// (/binance/* → Netlify redirect, so the browser only talks to this site), then to Binance's other public hosts.
// The host that last worked is tried first next time.
const FALLBACKS = ['/binance', 'https://api.binance.com', 'https://api1.binance.com', 'https://api-gcp.binance.com'];
let goodBase = null;
export function binanceBases() {
  const all = [marketConfig.binanceBaseUrl, ...FALLBACKS];
  return goodBase ? [goodBase, ...all.filter((b) => b !== goodBase)] : all;
}
/** GET a Binance REST path (e.g. '/api/v3/klines?...'), trying each host until one answers with JSON. */
export async function binanceGet(path, opts = {}) {
  let lastErr;
  for (const base of binanceBases()) {
    try {
      const data = await fetchJson(`${base}${path}`, opts);
      goodBase = base;
      return data;
    } catch (e) {
      lastErr = e;
      if (e.code === 'http' && e.status && ![403, 404, 418, 429, 451].includes(e.status) && e.status < 500) throw e;   // a real answer (e.g. bad symbol): do not retry elsewhere
    }
  }
  throw lastErr;
}

export async function fetchBinanceCandles(symbol, interval, limit = marketConfig.candleLimit, endTime = null) {
  const url = `/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${interval}&limit=${limit}${endTime ? `&endTime=${endTime}` : ''}`;
  const rows = await binanceGet(url, { timeoutMs: marketConfig.requestTimeoutMs });
  if (!Array.isArray(rows)) throw new Error('Unexpected Binance response');
  return rows.map((r) => ({
    time: Math.floor(r[0] / 1000),
    open: +r[1], high: +r[2], low: +r[3], close: +r[4],
    volume: +r[5],
    // Taker buy base-asset volume: volume from aggressive buyers.
    buyVolume: +r[9],
  }));
}

export async function fetchBinanceTickers(symbols) {
  if (!symbols.length) return {};
  const url = `/api/v3/ticker/24hr?symbols=${encodeURIComponent(JSON.stringify(symbols))}`;
  const rows = await binanceGet(url, { timeoutMs: marketConfig.requestTimeoutMs });
  const out = {};
  for (const r of rows) {
    out[r.symbol] = {
      symbol: r.symbol, price: +r.lastPrice, at: +r.closeTime, changePct: +r.priceChangePercent,
      high: +r.highPrice, low: +r.lowPrice, volume: +r.volume,
    };
  }
  return out;
}

/** v266: every live Binance Spot pair quoted in USDT, most traded first (for the liquidity map's coin picker).
 *  One light request (type=MINI), cached 10 min. Leveraged tokens and pairs with no trade in the last 2 days are dropped. */
let pairsCache = null;
export async function fetchBinanceUsdtPairs() {
  if (pairsCache && Date.now() - pairsCache.at < 600_000) return pairsCache.list;
  const rows = await binanceGet('/api/v3/ticker/24hr?type=MINI', { timeoutMs: Math.max(marketConfig.requestTimeoutMs, 15000) });
  if (!Array.isArray(rows)) throw new Error('Unexpected ticker response');
  const fresh = Date.now() - 2 * 86400_000;
  const list = rows
    .filter((r) => /^[A-Z0-9]{2,20}USDT$/.test(r.symbol) && !/(UP|DOWN|BULL|BEAR)USDT$/.test(r.symbol) && +r.quoteVolume > 0 && +r.closeTime > fresh)
    .map((r) => ({ symbol: r.symbol, base: r.symbol.slice(0, -4), qv: +r.quoteVolume, price: +r.lastPrice }))
    .sort((a, b) => b.qv - a.qv);
  pairsCache = { at: Date.now(), list };
  return list;
}

/** v253: order-book snapshot with its update id (for a local book kept in sync by the diff stream). */
export async function fetchBinanceBook(symbol, limit = 1000) {
  const d = await binanceGet(`/api/v3/depth?symbol=${encodeURIComponent(symbol)}&limit=${limit}`, { timeoutMs: marketConfig.requestTimeoutMs });
  if (!Array.isArray(d?.bids) || !Array.isArray(d?.asks)) throw new Error('Unexpected depth response');
  return d;
}
/** v253: recent real trades (aggregated by Binance): [{ price, qty, time, buy }]. */
export async function fetchBinanceTrades(symbol, limit = 500) {
  const rows = await binanceGet(`/api/v3/aggTrades?symbol=${encodeURIComponent(symbol)}&limit=${limit}`, { timeoutMs: marketConfig.requestTimeoutMs });
  if (!Array.isArray(rows)) throw new Error('Unexpected trades response');
  return rows.map((r) => ({ id: r.a, price: +r.p, qty: +r.q, time: +r.T, buy: !r.m }));
}

/** Order-book snapshot (top 100 levels per side) for the live DOM wall filter. */
export async function fetchBinanceDepth(symbol, limit = 100) {
  const d = await binanceGet(`/api/v3/depth?symbol=${encodeURIComponent(symbol)}&limit=${limit}`, { timeoutMs: marketConfig.requestTimeoutMs });
  if (!Array.isArray(d?.bids) || !Array.isArray(d?.asks)) throw new Error('Unexpected depth response');
  return { bids: d.bids, asks: d.asks };
}
