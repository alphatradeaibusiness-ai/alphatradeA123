// v279 Real public order books for metals, energy, indices and stocks on the liquidity map.
// - Binance USDⓈ-M Futures "TradFi perpetuals" (contractType TRADIFI_PERPETUAL: gold XAU, silver XAG, platinum, palladium,
//   copper, oil, gas, stocks, ETFs). Full diff-depth order book + aggTrades, same as crypto.
//   Docs: https://developers.binance.com/docs/derivatives/usds-margined-futures/market-data/rest-api/Exchange-Information
// - Hyperliquid HIP-3 markets by trade.xyz (S&P 500, Nasdaq-100 style index perps, commodities): public l2Book (top 20 levels
//   per side) + trades over WebSocket. Docs: https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api
// These are perpetual contracts that track the asset, not the spot/cash market itself — the page says so.
import { fetchJson } from '../../utils/http.js';

/* ── ids used by the picker: 'BTCUSDT' (Binance spot) · 'F:XAUUSDT' (Binance futures) · 'H:xyz:SP500' (Hyperliquid) ── */
export const venueOf = (id) => (String(id).startsWith('F:') ? 'fut' : String(id).startsWith('H:') ? 'hl' : 'spot');
export const rawOf = (id) => String(id).replace(/^[FH]:/, '');
export const VALID_ID = /^(?:[A-Z0-9]{2,20}USDT|F:[A-Z0-9]{2,20}USDT|H:[a-z0-9]{1,12}:[A-Za-z0-9._-]{1,24})$/;

const METALS = new Set(['XAU', 'XAG', 'XPT', 'XPD', 'COPPER', 'GOLD', 'SILVER', 'PLATINUM', 'PALLADIUM', 'ALUMINIUM', 'ALUMINUM']);
const ENERGY = new Set(['CL', 'BZ', 'NATGAS', 'WTI', 'BRENT', 'OIL', 'USOIL', 'UKOIL', 'GAS']);
const INDEX_RE = /^(SP500|SPX|SPY|XYZ100|NDX|NAS100|US100|QQQ|US30|DJI|DIA|US2000|RUT|IWM|SMALL2000|DAX|GER40|DE40|NIKKEI|JP225|N225|FTSE|UK100|HSI|HK50|KOSPI|KR200|EWJ|EWY|EWZ|EWZS|EU50|STOXX50|CAC40|FR40|MAG7|VIX)$/;
const NAMES = {
  XAU: ['ذهب', 'Gold'], GOLD: ['ذهب', 'Gold'], XAG: ['فضة', 'Silver'], SILVER: ['فضة', 'Silver'], XPT: ['بلاتين', 'Platinum'], PLATINUM: ['بلاتين', 'Platinum'],
  XPD: ['بلاديوم', 'Palladium'], PALLADIUM: ['بلاديوم', 'Palladium'], COPPER: ['نحاس', 'Copper'], CL: ['نفط WTI', 'WTI crude'], WTI: ['نفط WTI', 'WTI crude'], BZ: ['نفط برنت', 'Brent crude'],
  BRENT: ['نفط برنت', 'Brent crude'], NATGAS: ['غاز طبيعي', 'Natural gas'], SP500: ['S&P 500', 'S&P 500'], XYZ100: ['ناسداك 100 (XYZ100)', 'Nasdaq-100 (XYZ100)'],
  EWJ: ['اليابان (EWJ)', 'Japan (EWJ)'], EWY: ['كوريا (EWY)', 'Korea (EWY)'], EWZ: ['البرازيل (EWZ)', 'Brazil (EWZ)'], EWZS: ['البرازيل صغيرة (EWZS)', 'Brazil small-cap (EWZS)'],
};
/** 'metal' | 'energy' | 'index' | 'stock' for a TradFi base (e.g. 'XAU', 'SP500', 'TSLA'). */
export function classify(base) {
  const b = String(base).toUpperCase();
  if (METALS.has(b)) return 'metal';
  if (ENERGY.has(b)) return 'energy';
  if (INDEX_RE.test(b)) return 'index';
  return 'stock';
}
/** Display name pair [ar, en] or null. */
export const tradfiName = (base) => NAMES[String(base).toUpperCase()] || null;

/* ───────────── Binance USDⓈ-M futures ───────────── */
const FUT_BASES = ['https://fapi.binance.com', 'https://fapi1.binance.com', 'https://fapi2.binance.com'];
let goodFut = null;
export async function futGet(path, opts = {}) {
  const order = goodFut ? [goodFut, ...FUT_BASES.filter((b) => b !== goodFut)] : FUT_BASES; let last;
  for (const base of order) {
    try { const d = await fetchJson(`${base}${path}`, { timeoutMs: 12000, ...opts }); goodFut = base; return d; }
    catch (e) { last = e; if (e.code === 'http' && e.status && ![403, 404, 418, 429, 451].includes(e.status) && e.status < 500) throw e; }
  }
  throw last;
}
/** Pure: pick the TradFi perpetuals out of an exchangeInfo + 24h tickers. */
export function pickTradfi(info, tickers = []) {
  const vol = new Map((Array.isArray(tickers) ? tickers : []).map((t) => [t.symbol, +t.quoteVolume || 0]));
  return (info?.symbols || [])
    .filter((s) => s.status === 'TRADING' && s.quoteAsset === 'USDT' && (s.contractType === 'TRADIFI_PERPETUAL' || /TRADFI|TRADIFI/i.test(String(s.underlyingType || ''))))
    .map((s) => { const base = s.baseAsset || s.symbol.replace(/USDT$/, ''); return { id: `F:${s.symbol}`, symbol: s.symbol, base, cls: classify(base), venue: 'fut', qv: vol.get(s.symbol) || 0 }; })
    .sort((a, b) => b.qv - a.qv);
}
let futCache = null;
export async function fetchTradfiFutures() {
  if (futCache && Date.now() - futCache.at < 600_000) return futCache.list;
  const [info, tick] = await Promise.all([futGet('/fapi/v1/exchangeInfo'), futGet('/fapi/v1/ticker/24hr').catch(() => [])]);
  const list = pickTradfi(info, tick); futCache = { at: Date.now(), list }; return list;
}
export async function fetchFutBook(symbol, limit = 1000) {
  const d = await futGet(`/fapi/v1/depth?symbol=${encodeURIComponent(symbol)}&limit=${limit}`);
  if (!Array.isArray(d?.bids) || !Array.isArray(d?.asks)) throw new Error('Unexpected depth response');
  return d;
}
export async function fetchFutTrades(symbol, limit = 500) {
  const rows = await futGet(`/fapi/v1/aggTrades?symbol=${encodeURIComponent(symbol)}&limit=${limit}`);
  if (!Array.isArray(rows)) throw new Error('Unexpected trades response');
  return rows.map((r) => ({ id: r.a, price: +r.p, qty: +r.q, time: +r.T, buy: !r.m }));
}
export const FUT_WS = 'wss://fstream.binance.com';

/* ───────────── Hyperliquid (trade.xyz HIP-3) ───────────── */
export const HL_API = 'https://api.hyperliquid.xyz/info';
export const HL_WS = 'wss://api.hyperliquid.xyz/ws';
const hlPost = (body) => fetchJson(HL_API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), timeoutMs: 12000 });
/** Pure: indices + commodities out of a metaAndAssetCtxs answer for one HIP-3 dex. */
export function pickHl(resp, dex = 'xyz') {
  const [meta, ctxs] = Array.isArray(resp) ? resp : [resp, []];
  return (meta?.universe || []).map((u, i) => {
    if (!u?.name || u.isDelisted) return null;
    const name = String(u.name); const base = name.includes(':') ? name.split(':')[1] : name; const cls = classify(base);
    if (cls === 'stock') return null;   // stocks come from Binance; keep the Hyperliquid list to indices and commodities
    return { id: `H:${name.includes(':') ? name : `${dex}:${name}`}`, symbol: name.includes(':') ? name : `${dex}:${name}`, base, cls, venue: 'hl', qv: +(ctxs?.[i]?.dayNtlVlm) || 0 };
  }).filter(Boolean).sort((a, b) => b.qv - a.qv);
}
let hlCache = null;
export async function fetchHlMarkets(dex = 'xyz') {
  if (hlCache && Date.now() - hlCache.at < 600_000) return hlCache.list;
  const list = pickHl(await hlPost({ type: 'metaAndAssetCtxs', dex }), dex); hlCache = { at: Date.now(), list }; return list;
}
/** Pure: Hyperliquid l2Book `{ time, levels:[[{px,sz,n}],[…]] }` → `{ lastUpdateId, bids, asks }`. */
export function hlToSnap(d) {
  const [b = [], a = []] = d?.levels || [];
  return { lastUpdateId: +d?.time || Date.now(), bids: b.map((l) => [+l.px, +l.sz]), asks: a.map((l) => [+l.px, +l.sz]) };
}
export async function fetchHlBook(coin) { return hlToSnap(await hlPost({ type: 'l2Book', coin })); }
/** Pure: Hyperliquid trade → `{ id, price, qty, time, buy }` (side 'B' = the aggressor bought). */
export const hlTrade = (t) => ({ id: +t.tid || 0, price: +t.px, qty: +t.sz, time: +t.time, buy: t.side === 'B' });
