// Back-test of the SMC / ICT assistant: the SAME rules (smcAssist.js) run candle by candle over real history.
// No look-ahead: at candle i the analysis sees only candles ≤ i (a window like the chart's), higher-frame candles that
// existed at that time and lower-frame candles inside closed chart candles. Outcomes use only the candles after i.
//
// Two samples come out of one pass:
//   • trades      — what the assistant would really have done: only "trade" verdicts, one position at a time.
//   • candidates  — every distinct plan it drew (also the ones a required check refused), each judged on its own.
//                   Splitting them by each condition shows which conditions actually changed the result.
// Then a walk-forward check: the first 70 % of the period vs the last 30 % (the newest prices were never used to choose
// anything, so a result that only holds in the first part is not an edge).
import { analyzeSmcIct, trackTrade, STYLES } from './smcAssist.js';

const CLOSED = ['done', 'stopped', 'breakeven'];
export const CONDITIONS = ['bias', 'structure', 'sweep', 'mss', 'pd', 'ote', 'killzone', 'rr', 'risk', 'ltf'];
export const MIN_TRADES = 30;

const upTo = (bars, t) => {   // bars with time ≤ t (binary search, bars sorted by time)
  if (!bars?.length) return bars;
  let lo = 0; let hi = bars.length - 1; let k = -1;
  while (lo <= hi) { const m = (lo + hi) >> 1; if (bars[m].time <= t) { k = m; lo = m + 1; } else hi = m - 1; }
  return bars.slice(0, k + 1);
};
const tradeOf = (r) => ({
  direction: r.plan.direction, execution: r.plan.execution, entry: r.plan.entry, stop: r.plan.stop, targets: r.plan.targets, rr: r.plan.rr,
  createdAt: r.plan.createdAt, validUntil: r.plan.execution === 'market' ? null : r.plan.validUntil, costR: r.plan.costR,
});
const r2 = (v) => (Number.isFinite(v) ? Math.round(v * 100) / 100 : null);

/** Statistics of a list of closed results ({ resultR, time }). */
export function stats(list) {
  const rs = list.map((x) => x.resultR);
  const n = rs.length;
  if (!n) return { n: 0, wins: 0, winRate: null, avgR: null, totalR: 0, profitFactor: null, maxDD: 0, maxLossStreak: 0, equity: [] };
  let eq = 0; let peak = 0; let dd = 0; let streak = 0; let worst = 0; const equity = [];
  for (const r of rs) { eq += r; equity.push(r2(eq)); peak = Math.max(peak, eq); dd = Math.max(dd, peak - eq); streak = r < 0 ? streak + 1 : 0; worst = Math.max(worst, streak); }
  const wins = rs.filter((r) => r > 0).length;
  const gain = rs.filter((r) => r > 0).reduce((s, r) => s + r, 0); const loss = -rs.filter((r) => r < 0).reduce((s, r) => s + r, 0);
  return { n, wins, winRate: wins / n, avgR: r2(eq / n), totalR: r2(eq), profitFactor: loss > 0 ? r2(gain / loss) : null, maxDD: r2(dd), maxLossStreak: worst, equity };
}

/** Verdict on the numbers — deliberately strict. */
export function judge(all, oos) {
  if (all.n < MIN_TRADES) return 'too_few';
  if (!(all.avgR > 0)) return 'negative';
  if (oos.n < 10 || !(oos.avgR > 0)) return 'not_stable';
  return 'positive';
}

/**
 * @param candles  history, oldest first (≥ window + 50)
 * @param input    the panel's inputs (style, execution, account, asset, costPct, …)
 * @param opts     { window, htf: {h4,d1}, ltf, horizon, onProgress(fraction), isCancelled() }
 */
export async function backtestSmcIct(candles, input, { window = 500, htf = null, ltf = null, horizon = 400, onProgress = null, isCancelled = null } = {}) {
  const n = candles.length;
  if (n < window + 50) return { error: 'not_enough_history', bars: n };
  const tfSec = input.tfSec || candles[1].time - candles[0].time;
  const indexOf = new Map(candles.map((c, i) => [c.time, i]));
  const trades = []; const unfilled = { expired: 0, missed: 0 }; let open = 0;
  const candidates = []; const seen = new Set(); const unfilledSeen = new Set();
  let busyUntil = -1;
  for (let i = window - 1; i < n - 1; i++) {
    if (isCancelled?.()) return { error: 'cancelled' };
    if ((i - window) % 150 === 0) { onProgress?.((i - window + 1) / (n - window)); await new Promise((r) => setTimeout(r, 0)); }
    const last = candles[i];
    const r = analyzeSmcIct(candles.slice(i - window + 1, i + 1), {
      ...input, tfSec, news: null, todayLossPct: 0,
      htf: htf ? { h4: upTo(htf.h4, last.time), d1: upTo(htf.d1, last.time) } : null, ltf,
    });
    if (!r.plan) continue;
    const future = candles.slice(i + 1, i + 1 + horizon);
    // Every distinct plan (same direction + same zone counts once), judged on its own.
    const key = `${r.plan.direction}|${r.plan.poi.kind}|${r.plan.poi.time}`;
    if (!seen.has(key)) {
      seen.add(key);
      const out = trackTrade(tradeOf(r), future);
      if (CLOSED.includes(out.status)) candidates.push({ time: last.time, verdict: r.verdict, resultR: out.resultR, checks: Object.fromEntries(r.checks.map((c) => [c.id, c.ok])) });
    }
    // What the assistant would really have done.
    if (i > busyUntil && r.verdict === 'trade') {
      const out = trackTrade(tradeOf(r), future);
      const endIdx = out.closedAt != null ? indexOf.get(out.closedAt) ?? n : n;
      busyUntil = endIdx;
      if (CLOSED.includes(out.status)) trades.push({ time: last.time, closedAt: out.closedAt, direction: r.plan.direction, entry: r.plan.entry, stop: r.plan.stop, targets: r.plan.targets, status: out.status, hits: out.hits, resultR: out.resultR, execution: r.plan.execution });
      else if (out.status === 'expired' || out.status === 'missed') { if (!unfilledSeen.has(key)) { unfilledSeen.add(key); unfilled[out.status]++; } }
      else open++;
    }
  }
  onProgress?.(1);
  const from = candles[window - 1].time; const to = candles.at(-1).time;
  const cut = from + (to - from) * 0.7;
  const all = stats(trades); const inS = stats(trades.filter((t) => t.time < cut)); const oos = stats(trades.filter((t) => t.time >= cut));
  const conditions = CONDITIONS.map((id) => {
    const has = candidates.filter((c) => id in c.checks);
    if (!has.length) return null;
    const yes = stats(has.filter((c) => c.checks[id])); const no = stats(has.filter((c) => !c.checks[id]));
    return { id, with: { n: yes.n, winRate: yes.winRate, avgR: yes.avgR }, without: { n: no.n, winRate: no.winRate, avgR: no.avgR },
      diff: yes.n >= 10 && no.n >= 10 ? r2(yes.avgR - no.avgR) : null };
  }).filter(Boolean);
  return {
    symbol: input.symbol, tf: input.tf, style: input.style, execution: input.execution, costPct: input.costPct, bars: n - window + 1, from, to, cut,
    all, inSample: inS, outOfSample: oos, verdict: judge(all, oos), unfilled, open, trades,
    candidates: { n: candidates.length, strict: stats(candidates.filter((c) => c.verdict === 'trade')), any: stats(candidates) },
    conditions, minTrades: MIN_TRADES, monteCarlo: monteCarlo(trades.map((x) => x.resultR), { riskPct: Number(input.riskPct) || 1 }), risk: riskAdvice(trades.map((x) => x.resultR), { maxDDPct: Number(input.maxDDPct) || 10 }), minRR: STYLES[input.style]?.minRR,
  };
}

/* ───────── Monte Carlo: how bad could the same trades have been in another order? ───────── */
function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const pctl = (arr, p) => { const s = [...arr].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };
/**
 * Re-orders the back-test's results many times (seeded, so repeatable) and measures the drawdown each order would have
 * caused, in R and in % of the account at the chosen risk per trade (compounded). Same trades, same average — only luck
 * of the order changes. Answers: "what drawdown should I be ready for?".
 */
export function monteCarlo(results, { runs = 2000, riskPct = 1, seed = 7 } = {}) {
  const rs = results.filter(Number.isFinite);
  if (rs.length < 10) return null;
  const rand = rng(seed); const ddR = []; const ddPct = []; const finals = [];
  for (let k = 0; k < runs; k++) {
    const a = [...rs];
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    let eq = 0; let peak = 0; let dd = 0; let acct = 1; let top = 1; let ddp = 0;
    for (const r of a) { eq += r; peak = Math.max(peak, eq); dd = Math.max(dd, peak - eq); acct *= 1 + (r * riskPct) / 100; top = Math.max(top, acct); ddp = Math.max(ddp, 1 - acct / top); }
    ddR.push(dd); ddPct.push(ddp * 100); finals.push(eq);
  }
  return {
    runs, trades: rs.length, riskPct,
    ddR: { p50: r2(pctl(ddR, 0.5)), p95: r2(pctl(ddR, 0.95)) }, ddPct: { p50: r2(pctl(ddPct, 0.5)), p95: r2(pctl(ddPct, 0.95)) },
    probDD20: r2(ddPct.filter((x) => x >= 20).length / runs), finalR: r2(finals[0]),
  };
}

/* ───────── compare a few settings on the same data (newest 30 % decides) ───────── */
/**
 * Runs the back-test for each order type (and with / without a required sweep) on the SAME candles. Ranked by the newest
 * 30 % only (needs ≥ 10 trades there): picking the best of several is itself a kind of fitting, so the ranking uses the
 * part of the data the comparison is least likely to have been lucky on — and still says so.
 */
export async function compareSettings(candles, base, { htf = null, ltf = null, onProgress = null, isCancelled = null } = {}) {
  const execs = ['limit', 'market', ...(ltf ? ['confirm'] : [])];
  const reqs = [base.require || [], [...new Set([...(base.require || []), 'sweep'])]].filter((v, i, a) => i === 0 || v.length !== a[0].length);
  const combos = execs.flatMap((execution) => reqs.map((require) => ({ execution, require })));
  const rows = [];
  for (let k = 0; k < combos.length; k++) {
    if (isCancelled?.()) return { error: 'cancelled' };
    const c = combos[k];
    const res = await backtestSmcIct(candles, { ...base, ...c }, { htf, ltf: c.execution === 'confirm' ? ltf : null, isCancelled, onProgress: (f) => onProgress?.((k + f) / combos.length) });
    if (res.error) return res;
    rows.push({ ...c, verdict: res.verdict, all: { n: res.all.n, avgR: res.all.avgR, winRate: res.all.winRate }, oos: { n: res.outOfSample.n, avgR: res.outOfSample.avgR } });
  }
  rows.sort((a, b) => (b.oos.n >= 10) - (a.oos.n >= 10) || (b.oos.avgR ?? -99) - (a.oos.avgR ?? -99));
  return { rows };
}

/* ───────── how much to risk per trade ───────── */
/**
 * Two honest answers from the back-test's results:
 *   • the largest risk % per trade whose 1-in-20 Monte Carlo drawdown stays within the drawdown the user accepts;
 *   • the Kelly fraction (W − (1−W)/payoff), shown halved and capped at 2 % — full Kelly is far too aggressive for an
 *     estimate from a few dozen trades. No edge (Kelly ≤ 0) → 0: the numbers say not to trade these settings.
 */
export function riskAdvice(results, { maxDDPct = 10 } = {}) {
  const rs = results.filter(Number.isFinite);
  if (rs.length < 20) return null;
  const wins = rs.filter((r) => r > 0); const losses = rs.filter((r) => r < 0);
  const W = wins.length / rs.length;
  const payoff = losses.length ? (wins.reduce((s, r) => s + r, 0) / Math.max(1, wins.length)) / (-losses.reduce((s, r) => s + r, 0) / losses.length) : null;
  const kelly = payoff ? W - (1 - W) / payoff : null;
  let lo = 0.05; let hi = 5; let best = 0;
  for (let k = 0; k < 18; k++) {
    const mid = (lo + hi) / 2; const mc = monteCarlo(rs, { riskPct: mid, runs: 800 });
    if (mc && mc.ddPct.p95 <= maxDDPct) { best = mid; lo = mid; } else hi = mid;
  }
  return { maxDDPct, riskForDD: Math.floor(best * 100) / 100, kelly: kelly == null ? null : r2(kelly * 100), halfKelly: kelly == null || kelly <= 0 ? 0 : r2(Math.min(2, (kelly * 100) / 2)), trades: rs.length };
}

/** Recent vs earlier results: the last `n` closed trades against everything before them. */
export function drift(results, n = 20) {
  const rs = results.filter(Number.isFinite);
  if (rs.length < n * 2) return null;
  const recent = stats(rs.slice(-n).map((r) => ({ resultR: r }))); const before = stats(rs.slice(0, -n).map((r) => ({ resultR: r })));
  return { n, recent: { avgR: recent.avgR, winRate: recent.winRate }, before: { avgR: before.avgR, winRate: before.winRate, n: before.n }, worse: recent.avgR < before.avgR - 0.5 || (before.avgR > 0 && recent.avgR <= 0) };
}

/** Same settings on several markets: does the result hold beyond one chart? */
export function robustness(rows) {
  const tested = rows.filter((x) => x.n >= 10);
  const positive = tested.filter((x) => x.avgR > 0).length;
  return { markets: rows.length, tested: tested.length, positive, robust: tested.length >= 3 && positive / tested.length >= 0.6 };
}
