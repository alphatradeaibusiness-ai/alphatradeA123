// Strict confirmation engine: a BUY / SELL is shown (chart, AI proposal, signals channel, chart alerts) only when
// several INDEPENDENT families of evidence point the same way, nothing important points the other way, the market is
// not sideways / news-driven / demo, and the entry, stop and targets themselves make sense. Otherwise: NO TRADE, with reasons.
//
// It only reads closed candles (no look-ahead) and the platform's own indicators. It never produces a win-rate or an
// accuracy figure: the output is evidence, not a promise.
import { ema, rsi, atr, volumeProfile, momentumScore } from '../indicators/index.js';
import { smcFull } from '../indicators/smc.js';

/** Weights: structure, higher timeframe, liquidity and confluence zones count most (as asked); single indicators count little. */
export const WEIGHTS = { structure: 3, htf: 3, liquidity: 2, zone: 2, trend: 1, momentum: 1, edh: 1, rsi: 0.5 };
/** Acceptance rules. */
export const RULES = {
  minScore: 7,            // weighted evidence FOR the direction (out of 13.5)
  minGroups: 4,           // independent families agreeing
  maxAgainst: 1,          // weighted evidence AGAINST tolerated (a single minor disagreement at most)
  needCore: true,         // structure or higher timeframe must be among the agreeing families
  minRR: 1,               // the LAST target at least as far as the stop (reward ≥ risk); the first target may be a partial take-profit but must clear the fees
  stopAtr: [0.3, 4],      // stop distance in ATRs
  maxEntryAtr: 1,         // entry at most 1 ATR away from the last close
  sidewaysEr: 0.18,       // efficiency ratio (30 bars) below this = sideways / noise
  spikeAtr: 2.5,          // ATR above 2.5× its median = disorderly market
};

const sideTo = (dirSign, s) => (s === 0 ? 'neutral' : s === dirSign ? 'for' : 'against');

function emaSide(candles, period) {
  if (!candles || candles.length < period + 6) return 0;
  const c = candles.map((x) => x.close); const e = ema(c, period); const n = c.length - 1;
  const slope = e[n] - e[n - 5];
  return c[n] > e[n] && slope > 0 ? 1 : c[n] < e[n] && slope < 0 ? -1 : 0;
}

function efficiency(candles, n = 30) {
  if (candles.length <= n) return null;
  let path = 0;
  for (let i = candles.length - n; i < candles.length; i++) path += Math.abs(candles[i].close - candles[i - 1].close);
  return path > 0 ? Math.abs(candles.at(-1).close - candles[candles.length - 1 - n].close) / path : 0;
}

/**
 * @param p.candles    CLOSED candles up to the decision bar (the forming candle excluded)
 * @param p.direction  'long' | 'short'
 * @param p.entry, p.stop, p.targets   the levels that would be shown
 * @param p.htf        { h4, d1 } real higher-timeframe candles (closed), or null
 * @param p.news       newsRisk() result or null
 * @param p.mode       'live' | 'demo'
 * @param p.feePct     round-trip fee in % of price (for the reward / risk check)
 * @param p.rules      override RULES (tests / research)
 * @returns { verdict: 'trade' | 'no-trade', score, against, agree, groups: [{key, side, weight, params}], blockers: [key], levels: { ok, issues: [key], rr } }
 */
export function confirmTrade(p) {
  const R = { ...RULES, ...(p.rules || {}) };
  const c = p.candles || [];
  const blockers = [];
  const groups = [];
  const out = (extra = {}) => ({ verdict: 'no-trade', score: 0, against: 0, agree: 0, groups, blockers, levels: { ok: false, issues: [] }, ...extra });
  if (c.length < 120) { blockers.push('data'); return out(); }
  if (p.mode && p.mode !== 'live') blockers.push('demo');
  const long = p.direction === 'long'; const d = long ? 1 : -1;
  const last = c.at(-1); const px = last.close;
  const A = atr(c, 14); const a = A.at(-1);
  const add = (key, s, params = {}) => groups.push({ key, side: s, weight: WEIGHTS[key], params });

  // ── Market condition filters ──
  const er = efficiency(c, 30);
  if (er != null && er < R.sidewaysEr) blockers.push('sideways');
  const recent = A.slice(-100).filter(Number.isFinite).sort((x, y) => x - y);
  const med = recent[Math.floor(recent.length / 2)];
  if (med > 0 && a > R.spikeAtr * med) blockers.push('spike');
  if (p.news?.level === 'high') blockers.push('news');

  // 1. Market structure (last BOS / CHoCH and the swing trend).
  const smc = smcFull(c);
  if (smc) {
    const br = smc.lastBreak; const brS = br ? (br.dir === 'bull' ? 1 : -1) : 0;
    const trS = smc.trend === 'bull' ? 1 : smc.trend === 'bear' ? -1 : 0;
    const s = brS && trS && brS !== trS ? brS : brS || trS;   // the latest break leads; a fresh CHoCH beats the older trend
    add('structure', sideTo(d, s), { kind: br?.kind || '-', ago: br ? c.length - 1 - br.index : null });
  }
  // 2. Higher timeframes (4h EMA50, daily EMA20), real candles only.
  const h4 = emaSide(p.htf?.h4, 50); const d1 = emaSide(p.htf?.d1, 20);
  if (p.htf?.h4 || p.htf?.d1) {
    const s = h4 && d1 ? (h4 === d1 ? h4 : 0) : h4 || d1;
    const opp = h4 === -d || d1 === -d;
    add('htf', opp ? 'against' : sideTo(d, s), { h4, d1 });
  }
  // 3. Liquidity: a recent sweep of the opposite side (stops taken, price back inside) or price in the discount / premium half.
  if (smc) {
    const swings = smc.swings || [];
    let swept = false;
    for (let i = c.length - 15; i < c.length; i++) {
      if (i < 1) continue;
      const lvl = swings.filter((s) => s.index < i - 1 && s.type === (long ? 'low' : 'high')).at(-1);
      if (!lvl) continue;
      if (long ? c[i].low < lvl.price && c[i].close > lvl.price : c[i].high > lvl.price && c[i].close < lvl.price) { swept = true; break; }
    }
    const zone = smc.range ? (px > smc.range.eq ? 'premium' : 'discount') : null;
    const good = long ? zone === 'discount' : zone === 'premium';
    const bad = long ? zone === 'premium' : zone === 'discount';
    add('liquidity', swept || good ? 'for' : bad ? 'against' : 'neutral', { swept, zone: zone || '-' });
  }
  // 4. Confluence zone at the entry: Fibonacci 50–78.6% pocket of the last swing leg, an order block of the same side,
  //    or the volume-profile value-area edge / POC (Fixed Range over the last 120 bars).
  {
    const kinds = [];
    const sw = smc?.swings || [];
    const hi = [...sw].reverse().find((s) => s.type === 'high'); const lo = [...sw].reverse().find((s) => s.type === 'low');
    if (hi && lo && hi.price > lo.price) {
      const leg = hi.price - lo.price;
      const r = long ? (hi.price - p.entry) / leg : (p.entry - lo.price) / leg;   // retracement of the leg in the trade's favour
      if (r >= 0.5 && r <= 0.786) kinds.push('fib');
    }
    const ob = (smc?.obs || []).find((o) => o.dir === (long ? 'bull' : 'bear') && !o.mitigated && p.entry >= o.bottom - 0.25 * a && p.entry <= o.top + 0.25 * a);
    if (ob) kinds.push('ob');
    const vp = c.some((x) => x.volume > 0) ? volumeProfile(c, { from: c.length - 120, rows: 30 }) : null;
    if (vp) {
      const edge = long ? vp.val : vp.vah;
      if (Math.abs(p.entry - edge) <= 0.5 * a || Math.abs(p.entry - vp.poc) <= 0.35 * a) kinds.push('vp');
    }
    add('zone', kinds.length ? 'for' : 'neutral', { kinds: kinds.join('+') || '-' });
  }
  // 5. Trend: EMA 20 / 50 / 200 stacked in the trade's direction.
  {
    const cl = c.map((x) => x.close); const n = cl.length - 1;
    const e20 = ema(cl, 20)[n], e50 = ema(cl, 50)[n], e200 = ema(cl, 200)[n];
    const s = px > e20 && e20 > e50 && (!Number.isFinite(e200) || px > e200) ? 1 : px < e20 && e20 < e50 && (!Number.isFinite(e200) || px < e200) ? -1 : 0;
    add('trend', sideTo(d, s));
  }
  // 6. Momentum score.
  const rv = rsi(c.map((x) => x.close), 14);
  const mom = momentumScore({ candles: c, rsiValues: rv, pressure: null })?.score;
  if (Number.isFinite(mom)) add('momentum', sideTo(d, mom >= 55 ? 1 : mom <= 45 ? -1 : 0), { v: Math.round(mom) });
  // 7. EDH: where price closed against yesterday's high / low.
  if (p.htf?.d1?.length >= 2) {
    const y = p.htf.d1.at(-1);
    add('edh', sideTo(d, px > y.high ? 1 : px < y.low ? -1 : 0), { yh: y.high, yl: y.low });
  }
  // 8. RSI: room to run (not stretched) supports; stretched in the trade's direction argues against.
  const r = rv.at(-1);
  if (Number.isFinite(r)) add('rsi', long ? (r > 75 ? 'against' : r >= 40 && r <= 68 ? 'for' : 'neutral') : (r < 25 ? 'against' : r <= 60 && r >= 32 ? 'for' : 'neutral'), { v: Math.round(r) });

  // ── Conflicts: structure or higher timeframe against the trade is a hard stop ──
  if (groups.some((g) => (g.key === 'structure' || g.key === 'htf') && g.side === 'against')) blockers.push('conflictCore');

  // ── Levels ──
  const issues = [];
  let rr1 = null;
  const tg = (p.targets || []).filter(Number.isFinite);
  const risk = Math.abs(p.entry - p.stop);
  if (!(Number.isFinite(p.entry) && Number.isFinite(p.stop)) || !tg.length) issues.push('missing');
  else {
    if (long ? p.stop >= p.entry : p.stop <= p.entry) issues.push('stopSide');
    if (tg.some((x) => (long ? x <= p.entry : x >= p.entry))) issues.push('targetSide');
    if (tg.some((x, i) => i && (long ? x < tg[i - 1] : x > tg[i - 1]))) issues.push('targetOrder');
    if (a > 0 && (risk < R.stopAtr[0] * a || risk > R.stopAtr[1] * a)) issues.push('stopSize');
    if (a > 0 && Math.abs(p.entry - px) > R.maxEntryAtr * a) issues.push('entryFar');
    const fee = ((p.feePct || 0) / 100) * p.entry;
    rr1 = risk > 0 ? Math.abs(tg.at(-1) - p.entry) / risk : 0;
    if (rr1 < R.minRR - 1e-9) issues.push('rr');
    if (Math.abs(tg[0] - p.entry) <= fee) issues.push('tp1Fee');   // the first target would not even pay the fees
  }
  const levels = { ok: !issues.length, issues, rr: rr1 == null ? null : Math.round(rr1 * 100) / 100 };
  if (!levels.ok) blockers.push('levels');

  const score = groups.filter((g) => g.side === 'for').reduce((s, g) => s + g.weight, 0);
  const against = groups.filter((g) => g.side === 'against').reduce((s, g) => s + g.weight, 0);
  const agree = groups.filter((g) => g.side === 'for').length;
  const core = groups.some((g) => (g.key === 'structure' || g.key === 'htf') && g.side === 'for');
  if (score < R.minScore) blockers.push('weak');
  if (agree < R.minGroups) blockers.push('fewGroups');
  if (against > R.maxAgainst) blockers.push('conflict');
  if (R.needCore && !core) blockers.push('noCore');
  const verdict = blockers.length ? 'no-trade' : 'trade';
  return { verdict, score, against, agree, groups, blockers: [...new Set(blockers)], levels };
}
