// Alpha Opportunity Tracker (v233). Every opportunity Alpha Radar shows is recorded with its plan, then followed on REAL
// candles until it ends. Detection is never a success: only prices that actually traded move the status.
//
// Status flow:  detected → waiting (limit entry) → triggered → tp1 → tp2 → tp3
//                                  ↘ cancelled (stop traded before the entry)      ↘ sl (stop traded)
//                                  ↘ expired (entry not reached in time)            ↘ expired (open too long: closed at the last price)
// A bar that touches both the stop and a target is counted as the STOP (conservative; the order inside a bar is unknown).
// Result in R, managed like the channel: a third at each target, the stop moves to the entry after TP1.
// Pure part (makeOpp / stepOpp / trackerStats) + a small loop with alerts (startRadarTracker).
import { storage } from '../utils/storage.js';
import { getCandles } from './market/index.js';
import { getInstrument } from '../config/instruments.js';
import { notify } from './signals.js';
import { TF_SEC, validateCandles, cleanCandles, smartMoneyFlow } from './radarPro.js';

export const STATUSES = ['detected', 'waiting', 'triggered', 'tp1', 'tp2', 'tp3', 'sl', 'cancelled', 'expired'];
export const WAIT_BARS = 12;      // a limit entry has 12 candles to be reached
export const OPEN_BARS = 60;      // a triggered trade is closed at the market after 60 candles
const KEY = 'radar-tracker-v1';
const PREF_KEY = 'radar-alert-prefs-v1';
const SEEN_KEY = 'radar-alert-seen-v1';
export const ALERT_TYPES = ['strong', 'near', 'entry', 'tp', 'sl', 'expired', 'sweep'];
const r3 = (v) => Math.round(v * 1000) / 1000;

/* ───────── pure ───────── */
/** A record from a radar reading `r` (+ its quality `q`). Returns null when the plan is not valid at the current price. */
export function makeOpp(r, q, now = Date.now()) {
  const long = r.direction === 'long'; const sgn = long ? 1 : -1; const price = r.price;
  let entry, stop, targets, order, plan;
  if (r.setup && r.setup.direction === r.direction && r.setup.targets?.length >= 3) {
    order = r.setup.status === 'active' ? 'market' : 'limit'; plan = r.strategy;
    entry = order === 'market' ? price : r.setup.entry; stop = r.setup.stop; targets = r.setup.targets.slice(0, 3);
  } else {
    // no strategy setup: an ATR plan (stop 1.5 × ATR, targets 1 / 2 / 3 R), labelled as such
    const a = (r.atrPct / 100) * price; if (!(a > 0)) return null;
    order = 'market'; plan = 'atr'; entry = price; stop = price - sgn * 1.5 * a; targets = [1, 2, 3].map((k) => price + sgn * 1.5 * a * k);
  }
  const risk = (entry - stop) * sgn;
  if (!(risk > 0) || targets.some((t) => (t - entry) * sgn <= 0)) return null;          // stop or targets on the wrong side
  if (order === 'market' && (price - targets[0]) * sgn >= 0) return null;               // TP1 already passed: too late
  return {
    id: `${r.symbol}|${r.tf}|${r.direction}|${Math.round(now / 60000)}`, symbol: r.symbol, tf: r.tf, direction: r.direction, precision: r.precision,
    detectedAt: now, detectedPrice: price, entry, stop, targets, order, plan, score: q?.score ?? Math.round(r.score), grade: q?.grade ?? null,
    why: (q?.parts || []).filter((p) => p.pts >= p.max * 0.6).map((p) => p.key).slice(0, 4),
    status: order === 'market' ? 'triggered' : 'waiting', closed: false, hits: 0, triggeredAt: order === 'market' ? now : null,
    closedAt: null, exit: null, r: null, lastPrice: price, lastBar: Math.floor(now / 1000), source: 'live',
  };
}

/** Advances one opportunity on candles (sorted). Pure: returns { opp, events: [type] }. */
export function stepOpp(o0, candles, now = Date.now()) {
  if (o0.closed) return { opp: o0, events: [] };
  const o = { ...o0, targets: o0.targets.slice() }; const events = [];
  const sec = TF_SEC[o.tf] || 300; const sgn = o.direction === 'long' ? 1 : -1;
  const risk = (o.entry - o.stop) * sgn;
  const R = (exit) => { const tR = o.targets.map((t) => ((t - o.entry) * sgn) / risk); const banked = tR.slice(0, o.hits).reduce((s, x) => s + x / 3, 0); return r3(banked + ((3 - o.hits) / 3) * (((exit - o.entry) * sgn) / risk)); };
  const close = (status, exit, at) => { o.status = status; o.closed = true; o.exit = exit; o.closedAt = at; o.r = status === 'cancelled' || (status === 'expired' && !o.triggeredAt) ? 0 : R(exit); events.push(status === 'sl' ? 'sl' : status === 'expired' ? 'expired' : status === 'tp3' ? 'tp' : status); };
  const bars = candles.filter((c) => c.time >= o.lastBar);   // the newest processed bar is checked again (it may still be forming)
  for (const c of bars) {
    const at = c.time * 1000;
    if (o.status === 'waiting') {
      const stopFirst = sgn > 0 ? c.low <= o.stop : c.high >= o.stop;
      const touch = sgn > 0 ? c.low <= o.entry : c.high >= o.entry;
      if (touch && !stopFirst) { o.status = 'triggered'; o.triggeredAt = at; events.push('entry'); }
      else if (stopFirst) { close('cancelled', null, at); break; }
      else if ((c.time - Math.floor(o.detectedAt / 1000)) / sec >= WAIT_BARS) { close('expired', null, at); break; }
      else continue;
    }
    // triggered (or a target already hit)
    const stopNow = o.hits >= 1 ? o.entry : o.stop;   // after TP1 the stop sits at the entry
    const hitStop = sgn > 0 ? c.low <= stopNow : c.high >= stopNow;
    if (hitStop) { close(o.hits >= 1 ? `tp${o.hits}` : 'sl', stopNow, at); if (o.hits >= 1) events[events.length - 1] = 'stopAtEntry'; break; }
    while (o.hits < 3 && (sgn > 0 ? c.high >= o.targets[o.hits] : c.low <= o.targets[o.hits])) { o.hits++; o.status = `tp${o.hits}`; if (o.hits < 3) events.push('tp'); }
    if (o.hits === 3) { close('tp3', o.targets[2], at); break; }
    if (o.triggeredAt && (c.time * 1000 - o.triggeredAt) / 1000 / sec >= OPEN_BARS) { close('expired', c.close, at); break; }
  }
  const lastC = candles.at(-1);
  if (lastC) { o.lastPrice = lastC.close; if (!o.closed) o.lastBar = lastC.time; }
  return { opp: o, events };
}

/** Live-signal results only (never mixed with back-tests, paper or real trades). */
export function trackerStats(opps) {
  const done = opps.filter((o) => o.closed && o.r != null && o.status !== 'cancelled' && !(o.status === 'expired' && !o.triggeredAt));
  const wins = done.filter((o) => o.r > 0), losses = done.filter((o) => o.r < 0);
  const gross = wins.reduce((s, o) => s + o.r, 0), lossSum = -losses.reduce((s, o) => s + o.r, 0);
  let eq = 0, peak = 0, dd = 0;
  for (const o of [...done].sort((a, b) => a.closedAt - b.closedAt)) { eq += o.r; peak = Math.max(peak, eq); dd = Math.max(dd, peak - eq); }
  const group = (k) => { const m = {}; for (const o of done) { const g = (m[o[k]] ||= { n: 0, wins: 0, r: 0 }); g.n++; if (o.r > 0) g.wins++; g.r = r3(g.r + o.r); } return Object.entries(m).map(([key, v]) => ({ key, ...v, winRate: Math.round((v.wins / v.n) * 100) })).sort((a, b) => b.n - a.n); };
  return {
    total: opps.length, open: opps.filter((o) => !o.closed).length, completed: done.length, wins: wins.length, losses: losses.length,
    cancelled: opps.filter((o) => o.status === 'cancelled' || (o.status === 'expired' && !o.triggeredAt)).length,
    winRate: done.length ? Math.round((wins.length / done.length) * 100) : null,
    avgR: done.length ? r3(done.reduce((s, o) => s + o.r, 0) / done.length) : null,
    profitFactor: lossSum > 0 ? r3(gross / lossSum) : gross > 0 ? Infinity : null,
    maxDrawdownR: r3(dd), byMarket: group('symbol'), byTf: group('tf'), byStrategy: group('plan'),
  };
}

/* ───────── storage, alerts, loop ───────── */
const listeners = new Set();
export const onTracker = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
export const trackerList = () => { const v = storage.get(KEY, null); return Array.isArray(v) ? v : []; };
const save = (list) => { storage.set(KEY, list.slice(0, 300)); listeners.forEach((fn) => { try { fn(); } catch { /* */ } }); };
export const alertPrefs = () => ({ strong: true, near: true, entry: true, tp: true, sl: true, expired: true, sweep: true, ...(storage.get(PREF_KEY, {}) || {}) });
export const setAlertPref = (k, v) => { if (ALERT_TYPES.includes(k)) storage.set(PREF_KEY, { ...alertPrefs(), [k]: Boolean(v) }); };
export const clearTracker = () => save([]);

function alertOnce(type, key, title, body) {
  if (!alertPrefs()[type === 'stopAtEntry' ? 'sl' : type]) return;
  const seen = new Set(storage.get(SEEN_KEY, []) || []); const k = `${type}|${key}`;
  if (seen.has(k)) return;                                   // never the same alert twice
  storage.set(SEEN_KEY, [k, ...seen].slice(0, 600));
  notify(title, body, `radar-${k}`);
}
const L = (ar, en) => (typeof document !== 'undefined' && document.documentElement.lang === 'ar' ? ar : en);
const dirTxt = (o) => (o.direction === 'long' ? L('شراء', 'Buy') : L('بيع', 'Sell'));
const EV_TXT = { entry: () => L('تفعّل الدخول', 'Entry triggered'), tp: (o) => L(`وصل الهدف ${o.hits}`, `Target ${o.hits} hit`), sl: () => L('ضرب وقف الخسارة', 'Stop loss hit'),
  stopAtEntry: (o) => L(`رجع للدخول بعد الهدف ${o.hits}`, `Back to entry after TP${o.hits}`), expired: () => L('انتهت صلاحية الفرصة', 'Opportunity expired'), cancelled: () => L('انلغت قبل الدخول', 'Cancelled before entry') };

/** Called by the radar scan with its shown readings (+ quality). Records new ones; one open record per market/frame/direction. */
export function recordOpportunities(items, now = Date.now()) {
  const list = trackerList(); let added = 0;
  for (const { r, q } of items) {
    if (!r || r.mode !== 'live') continue;
    if (list.some((o) => !o.closed && o.symbol === r.symbol && o.tf === r.tf && o.direction === r.direction)) continue;
    const recent = list.find((o) => o.symbol === r.symbol && o.tf === r.tf && o.closed && now - o.closedAt < (TF_SEC[r.tf] || 300) * 3000);
    if (recent) continue;
    const o = makeOpp(r, q, now); if (!o) continue;
    list.unshift(o); added++;
    if (o.score >= 80) alertOnce('strong', o.id, `Alpha Radar · ${o.symbol}`, `${dirTxt(o)} · ${o.tf} · ${L('درجة', 'score')} ${o.score} — ${L('فرصة قوية', 'strong setup')}`);
  }
  if (added) save(list);
  return added;
}

let busy = false;
/** Follows every open record on real candles (closed + forming bar). Alerts once per event. */
export async function trackTick(now = Date.now()) {
  if (busy) return; busy = true;
  try {
    const list = trackerList(); const open = list.filter((o) => !o.closed); if (!open.length) return;
    const groups = new Map(); for (const o of open) { const k = `${o.symbol}|${o.tf}`; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(o); }
    let changed = false;
    for (const [k, items] of [...groups].slice(0, 10)) {
      const [symbol, tf] = k.split('|');
      let ds; try { ds = await getCandles(symbol, tf); } catch { continue; }
      if (!ds || ds.mode !== 'live') continue;                                  // never followed on demo data
      const candles = cleanCandles(ds.candles);
      const q = validateCandles(candles, tf, { crypto: getInstrument(symbol)?.provider === 'binance', now });
      if (!q.ok || q.state === 'stale') continue;                              // a stale feed does not move a status
      for (const o of items) {
        const { opp, events } = stepOpp(o, candles, now);
        const i = list.findIndex((x) => x.id === o.id); if (i >= 0) { list[i] = opp; changed = true; }
        for (const ev of events) alertOnce(ev === 'tp' ? 'tp' : ev === 'cancelled' ? 'expired' : ev, `${opp.id}|${ev}|${opp.hits}`, `Alpha Radar · ${opp.symbol}`, `${dirTxt(opp)} · ${opp.tf} — ${(EV_TXT[ev] || (() => ev))(opp)}${opp.r != null ? ` (${opp.r > 0 ? '+' : ''}${opp.r}R)` : ''}`);
        if (opp.status === 'waiting') {
          const dist = Math.abs(opp.lastPrice - opp.entry); const risk = Math.abs(opp.entry - opp.stop);
          if (risk > 0 && dist <= risk * 0.25) alertOnce('near', opp.id, `Alpha Radar · ${opp.symbol}`, `${dirTxt(opp)} · ${opp.tf} — ${L('السعر قرّب من منطقة الدخول', 'price is near the entry zone')}`);
        }
      }
      // a liquidity sweep on the newest closed candle of a market being followed
      const smf = smartMoneyFlow(candles.slice(0, -1));
      const sw = smf?.sweeps?.find((s) => s.ago === 0);
      if (sw) alertOnce('sweep', `${k}|${candles.at(-2)?.time}`, `Alpha Radar · ${symbol}`, `${tf} — ${sw.side === 'buy' ? L('سحب سيولة فوق القمم (BSL)', 'buy-side liquidity swept') : L('سحب سيولة تحت القيعان (SSL)', 'sell-side liquidity swept')}`);
    }
    if (changed) save(list);
  } finally { busy = false; }
}
let timer = 0;
export function startRadarTracker() { if (timer) return; trackTick(); timer = setInterval(() => { if (!document.hidden) trackTick(); }, 60_000); }
