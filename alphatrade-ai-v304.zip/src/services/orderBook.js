// v253 Live order-book engine (pure, testable): a Binance-style local order book (REST snapshot + diff updates with
// sequence checks), price bucketing for the heatmap, and a wall tracker that follows large resting orders over time
// (refills, absorption by real trades, pulled vs broken). Everything here comes from REAL exchange data; nothing is
// estimated. Hidden/iceberg size is NOT visible in an order book — only "refills" (size coming back after being traded)
// are reported, and they are labelled as such.

export class LocalBook {
  constructor() { this.bids = new Map(); this.asks = new Map(); this.lastId = 0; this.ready = false; this.buffer = []; }
  /** Load a REST snapshot `{ lastUpdateId, bids:[[p,q]], asks:[[p,q]] }`, then replay buffered diffs. Returns false on a gap. */
  snapshot(s) {
    this.bids.clear(); this.asks.clear();
    for (const [p, q] of s.bids) if (+q > 0) this.bids.set(+p, +q);
    for (const [p, q] of s.asks) if (+q > 0) this.asks.set(+p, +q);
    this.lastId = Number(s.lastUpdateId) || 0; this.ready = true; this.chained = false;
    const buf = this.buffer; this.buffer = [];
    for (const e of buf) if (this.apply(e) === false) return false;
    return true;
  }
  /** Apply one diff event `{ U, u, b:[[p,q]], a:[[p,q]] }`. Returns false when a sequence gap means a resync is needed. */
  apply(e) {
    if (!this.ready) { this.buffer.push(e); if (this.buffer.length > 2000) this.buffer.shift(); return true; }
    if (e.pu != null) {                                                    // v279 futures stream: chained by pu (previous u)
      if (e.u < this.lastId) return true;                                  // older than the snapshot
      if (this.chained ? e.pu !== this.lastId : e.U > this.lastId) { this.ready = false; this.chained = false; return false; }
      this.chained = true;
    } else {
      if (e.u <= this.lastId) return true;                                 // older than the snapshot
      if (e.U > this.lastId + 1) { this.ready = false; return false; }     // gap
    }
    for (const [p, q] of e.b) { if (+q > 0) this.bids.set(+p, +q); else this.bids.delete(+p); }
    for (const [p, q] of e.a) { if (+q > 0) this.asks.set(+p, +q); else this.asks.delete(+p); }
    this.lastId = e.u; return true;
  }
  /** Replace the whole book from a plain REST snapshot (polling fallback). */
  replace(s) { this.buffer = []; this.ready = false; return this.snapshot(s); }
  best() { let bb = -Infinity, ba = Infinity; for (const p of this.bids.keys()) if (p > bb) bb = p; for (const p of this.asks.keys()) if (p < ba) ba = p; return { bid: Number.isFinite(bb) ? bb : null, ask: Number.isFinite(ba) ? ba : null }; }
  sorted(n = 20) {
    const b = [...this.bids.entries()].sort((x, y) => y[0] - x[0]).slice(0, n);
    const a = [...this.asks.entries()].sort((x, y) => x[0] - y[0]).slice(0, n);
    return { bids: b, asks: a };
  }
}

/** A "nice" bucket size near `mid × bps / 10000` (1, 2, 2.5, 5 × 10^k). */
export function niceStep(mid, bps = 2) {
  const raw = Math.max(1e-8, (mid * bps) / 10000); const k = 10 ** Math.floor(Math.log10(raw)); const m = raw / k;
  return +((m < 1.5 ? 1 : m < 2.25 ? 2 : m < 3.5 ? 2.5 : m < 7.5 ? 5 : 10) * k).toPrecision(6);
}
const keyOf = (p, step) => Math.round(Math.floor(p / step + 1e-9) * step * 1e8) / 1e8;

/** Bucket the book into price bins within ±rangePct of mid → { step, lo, bins: Map(binPrice → {bid, ask}) }. */
export function bucket(book, mid, step, rangePct = 2) {
  const lo = mid * (1 - rangePct / 100), hi = mid * (1 + rangePct / 100); const bins = new Map();
  const add = (p, q, side) => { if (p < lo || p > hi) return; const k = keyOf(p, step); const b = bins.get(k) || { bid: 0, ask: 0 }; b[side] += q; bins.set(k, b); };
  for (const [p, q] of book.bids) add(p, q, 'bid');
  for (const [p, q] of book.asks) add(p, q, 'ask');
  return { step, lo, hi, bins };
}

/** Bid/ask notional within ±pct of mid and the imbalance (−1 … +1, positive = more resting bids). */
export function imbalance(book, mid, pct = 1) {
  let b = 0, a = 0; const lo = mid * (1 - pct / 100), hi = mid * (1 + pct / 100);
  for (const [p, q] of book.bids) if (p >= lo) b += p * q;
  for (const [p, q] of book.asks) if (p <= hi) a += p * q;
  return { bid: b, ask: a, imb: b + a ? (b - a) / (b + a) : 0 };
}

const median = (arr) => { if (!arr.length) return 0; const s = [...arr].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };

/**
 * Wall tracker. Call `update(bucketed, mid, now)` once per heatmap column and `trade(t)` for every real trade.
 * A wall = a bin whose resting size is ≥ `mult` × the median non-empty bin size within ±1 % (and above `minNotional`).
 * Status: active → broken (price traded through it) | pulled (it vanished while price was away) | filled (it vanished
 * while price was at it — traded away). `refills` counts times the size came back by ≥ 30 % after dropping ≥ 30 %.
 */
export class WallTracker {
  constructor({ mult = 4, minNotional = 0 } = {}) { this.mult = mult; this.minNotional = minNotional; this.walls = new Map(); this.done = []; this.stats = { held: 0, broken: 0, pulled: 0, filled: 0 }; this.absorbed = { buy: 0, sell: 0 }; this.step = 0; }
  update({ bins, step }, mid, now) {
    this.step = step; const near = []; for (const [p, v] of bins) if (Math.abs(p - mid) / mid <= 0.01) { if (v.bid) near.push(v.bid); if (v.ask) near.push(v.ask); }
    const med = median(near); const thr = med * this.mult;
    const seen = new Set();
    for (const [p, v] of bins) for (const side of ['bid', 'ask']) {
      const q = v[side]; if (!q || q < thr || p * q < this.minNotional) continue;
      if ((side === 'bid' && p > mid) || (side === 'ask' && p < mid)) continue;
      const id = `${side}:${p}`; seen.add(id); let w = this.walls.get(id);
      if (!w) { w = { id, side, price: p, step, first: now, last: now, size: q, max: q, min: q, refills: 0, dipped: false, absorbed: 0, touches: 0, status: 'active' }; this.walls.set(id, w); }
      else {
        if (q < w.size * 0.7) w.dipped = true;
        if (w.dipped && q >= w.size * 1.3) { w.refills++; w.dipped = false; }
        w.size = q; w.max = Math.max(w.max, q); w.min = Math.min(w.min, q); w.last = now;
      }
    }
    for (const [id, w] of this.walls) {
      if (seen.has(id)) continue;
      const through = w.side === 'bid' ? mid < w.price : mid > w.price + w.step;
      const at = Math.abs(mid - (w.price + w.step / 2)) <= w.step * 1.5;
      if (now - w.last < 2500 && !through) continue;                  // tolerate one missed column
      w.status = through ? 'broken' : at || w.absorbed > 0 ? 'filled' : 'pulled'; w.end = now;
      this.stats[w.status]++; if (now - w.first > 60_000 && w.status === 'pulled') { /* a long-lived wall that was pulled is still counted as pulled */ }
      this.done.unshift(w); this.walls.delete(id);
    }
    if (this.done.length > 200) this.done.length = 200;
  }
  /** A real trade `{ price, qty, buy }` (buy = aggressor bought / lifted the ask). */
  trade(t) {
    for (const w of this.walls.values()) {
      if (t.price >= w.price && t.price < w.price + w.step + 1e-12) {
        if ((w.side === 'ask' && t.buy) || (w.side === 'bid' && !t.buy)) { w.absorbed += t.qty; w.touches++; this.absorbed[t.buy ? 'buy' : 'sell'] += t.qty; }
      }
    }
  }
  /** Walls that lived ≥ 30 s and were touched but are still there count as "held" when read. */
  list() {
    const act = [...this.walls.values()].sort((a, b) => b.size * b.price - a.size * a.price);
    const held = act.filter((w) => w.touches > 0 && w.last - w.first >= 30_000).length;
    return { active: act, done: this.done, stats: { ...this.stats, held } };
  }
}

/** Liquidity strength 0–100 from the imbalance and the depth near price relative to its own session average. */
export function liquidityStrength(depthNow, depthAvg) {
  if (!depthAvg) return null;
  return Math.max(0, Math.min(100, Math.round(50 * (depthNow / depthAvg))));
}

/** v253 anomaly radar: the last closed candle vs the previous 50 on the same market (z-scores; volume when the feed has it). */
const stats = (a) => { const m = a.reduce((x, y) => x + y, 0) / (a.length || 1); const sd = Math.sqrt(a.reduce((x, y) => x + (y - m) ** 2, 0) / (a.length || 1)); return { m, sd }; };
export function anomalyOf(c) {
  if (!c || c.length < 60) return null;
  const k = c.at(-1), prev = c.slice(-51, -1); const rng = prev.map((x) => x.high - x.low); const rets = prev.map((x, i) => (i ? Math.abs(Math.log(x.close / prev[i - 1].close)) : 0)).slice(1);
  const R = stats(rng), Q = stats(rets); const r = k.high - k.low; const ret = Math.abs(Math.log(k.close / c.at(-2).close));
  const rangeZ = R.sd ? (r - R.m) / R.sd : 0; const retZ = Q.sd ? (ret - Q.m) / Q.sd : 0;
  const vols = prev.map((x) => x.volume || 0); const V = stats(vols); const volZ = V.m > 0 && V.sd ? ((k.volume || 0) - V.m) / V.sd : null;
  const gap = R.m ? Math.abs(k.open - c.at(-2).close) / R.m : 0;
  const last5 = c.slice(-6).map((x, i, a) => (i ? Math.log(x.close / a[i - 1].close) : 0)).slice(1); const accel = Q.m ? Math.abs(last5.reduce((x, y) => x + y, 0)) / (Q.m * 5) : 0;
  const parts = [['range', Math.max(0, rangeZ)], ['move', Math.max(0, retZ)], ['volume', Math.max(0, volZ ?? 0)], ['gap', gap * 2], ['accel', Math.max(0, accel - 1)]];
  const score = Math.min(100, Math.round(Math.max(...parts.map((p) => p[1])) * 22 + parts.reduce((x, p) => x + p[1], 0) * 4));
  return { rangeZ: +rangeZ.toFixed(2), retZ: +retZ.toFixed(2), volZ: volZ == null ? null : +volZ.toFixed(2), gap: +gap.toFixed(2), accel: +accel.toFixed(2), score, top: parts.sort((a, b) => b[1] - a[1])[0][0], time: k.time, close: k.close };
}

/**
 * v254 Order-flow read — a transparent, rule-based checklist built ONLY from the live book, real trades and the wall
 * tracker. It never says "buy now"; it says whether the conditions an order-flow trader looks for are present, where the
 * idea would be wrong (stop beyond the wall) and where the next real obstacle is (target before the opposite wall).
 *   state: 'buy_setup' | 'sell_setup' | 'wait' | 'no_trade' | 'collecting'
 * Conditions (long; short is the mirror):
 *   1 support   — an active bid wall ≤ 0.35 % under price, alive ≥ 30 s (not a flashing order)
 *   2 defended  — sellers hit it (absorbed > 0) or it refilled, and it is still there
 *   3 aggression— buyers lead: CVD over the last 30 s is rising
 *   4 balance   — resting bids ≥ asks within ±0.5 % (imbalance ≥ −0.05)
 *   5 room      — reward to the next ask wall (or open space) ≥ 1.5 × risk to below the wall
 *   6 no recent break — no bid wall broke in the last 60 s
 * Blockers (→ no_trade): feed not live, fewer than 45 s collected, spread ≥ 3 × its session median.
 */
export function orderFlowRead({ mid, step, walls, cols, im, spread, spreadMed, live = true, now = Date.now() }) {
  if (!mid || !step || !cols || cols.length < 45) return { state: 'collecting', need: Math.max(0, 45 - (cols?.length || 0)) };
  const blockers = [];
  if (!live) blockers.push({ ar: 'البيانات مش مباشرة هلّق', en: 'Data is not live right now' });
  if (spreadMed > 0 && spread >= spreadMed * 3) blockers.push({ ar: 'السبريد واسع كتير هلّق', en: 'Spread is unusually wide' });
  const recent = cols.slice(-30); const cvdSlope = recent.length > 1 ? recent.at(-1).cvd - recent[0].cvd : 0;
  const vol30 = recent.reduce((s, c) => s + c.buy + c.sell, 0);
  const side = (dir) => {
    const mine = dir > 0 ? 'bid' : 'ask'; const opp = dir > 0 ? 'ask' : 'bid';
    const sup = walls.active.filter((w) => w.side === mine && (dir > 0 ? w.price <= mid : w.price >= mid) && Math.abs(mid - w.price) / mid <= 0.0035 && now - w.first >= 30_000)
      .sort((a, b) => Math.abs(mid - a.price) - Math.abs(mid - b.price))[0] || null;
    const obst = walls.active.filter((w) => w.side === opp && (dir > 0 ? w.price > mid : w.price < mid)).sort((a, b) => Math.abs(mid - a.price) - Math.abs(mid - b.price))[0] || null;
    const brokeRecently = walls.done.some((w) => w.side === mine && w.status === 'broken' && now - (w.end || 0) < 60_000);
    let stop = null, target = null, rr = null;
    if (sup) {
      stop = dir > 0 ? sup.price - step * 2 : sup.price + step * 3;
      const risk = Math.abs(mid - stop);
      target = obst ? (dir > 0 ? obst.price - step : obst.price + step * 2) : mid + dir * risk * 2;
      rr = risk > 0 ? Math.abs(target - mid) / risk : null;
    }
    const checks = [
      { id: 'support', ok: Boolean(sup), ar: dir > 0 ? 'في جدار شراء ثابت (≥30ث) قريب تحت السعر' : 'في جدار بيع ثابت (≥30ث) قريب فوق السعر', en: dir > 0 ? 'A stable bid wall (≥30 s) close below price' : 'A stable ask wall (≥30 s) close above price' },
      { id: 'defended', ok: Boolean(sup && (sup.absorbed > 0 || sup.refills > 0)), ar: dir > 0 ? 'البائعين ضربوا فيه وصمد (امتصاص أو إعادة تعبئة)' : 'المشترين ضربوا فيه وصمد (امتصاص أو إعادة تعبئة)', en: dir > 0 ? 'Sellers hit it and it held (absorption or refill)' : 'Buyers hit it and it held (absorption or refill)' },
      { id: 'aggression', ok: vol30 > 0 && dir * cvdSlope > 0, ar: dir > 0 ? 'المشترين هجوميين بآخر 30 ثانية (CVD طالع)' : 'البائعين هجوميين بآخر 30 ثانية (CVD نازل)', en: dir > 0 ? 'Buyers aggressive over the last 30 s (CVD rising)' : 'Sellers aggressive over the last 30 s (CVD falling)' },
      { id: 'balance', ok: dir * (im?.imb ?? 0) >= -0.05, ar: dir > 0 ? 'أوامر الشراء بالدفتر مش أضعف من البيع (±0.5%)' : 'أوامر البيع بالدفتر مش أضعف من الشراء (±0.5%)', en: dir > 0 ? 'Resting bids not weaker than asks (±0.5 %)' : 'Resting asks not weaker than bids (±0.5 %)' },
      { id: 'room', ok: rr != null && rr >= 1.5, ar: `في مساحة للهدف قبل الجدار المعاكس (عائد/مخاطرة ≥ 1.5${rr != null ? `، هلّق ${rr.toFixed(2)}` : ''})`, en: `Room before the opposite wall (R:R ≥ 1.5${rr != null ? `, now ${rr.toFixed(2)}` : ''})` },
      { id: 'nobreak', ok: !brokeRecently, ar: dir > 0 ? 'ما انكسر جدار شراء بآخر دقيقة' : 'ما انكسر جدار بيع بآخر دقيقة', en: dir > 0 ? 'No bid wall broke in the last minute' : 'No ask wall broke in the last minute' },
    ];
    const n = checks.filter((c) => c.ok).length; const core = ['support', 'defended', 'aggression', 'room'].every((id) => checks.find((c) => c.id === id).ok);
    return { dir, checks, n, core, wall: sup, obstacle: obst, stop, target, rr, entry: sup ? [Math.min(mid, sup.price + step * (dir > 0 ? 3 : -2)), Math.max(mid, sup.price + step * (dir > 0 ? 3 : -2))] : null };
  };
  const long = side(1), short = side(-1);
  let state = 'no_trade', best = long.n >= short.n ? long : short;
  if (blockers.length) state = 'no_trade';
  else if (long.core && long.n >= 5 && !(short.core && short.n >= 5)) { state = 'buy_setup'; best = long; }
  else if (short.core && short.n >= 5 && !(long.core && long.n >= 5)) { state = 'sell_setup'; best = short; }
  else if (Math.max(long.n, short.n) >= 4) state = 'wait';
  return { state, long, short, best, blockers, cvdSlope, at: now };
}

/** Follows flagged setups on live prices: first touch of target or stop decides (stop wins a tie). */
export class SetupTracker {
  constructor() { this.items = []; }
  add(read, mid, now) {
    const b = read.best; if (!b?.stop || !b?.target) return null;
    const open = this.items.find((x) => !x.result && x.dir === b.dir); if (open) return null;     // one open idea per side
    const it = { id: `${now}`, dir: b.dir, at: now, entry: mid, stop: b.stop, target: b.target, rr: b.rr, result: null };
    this.items.unshift(it); if (this.items.length > 50) this.items.length = 50; return it;
  }
  price(lo, hi, now, maxAgeMs = 30 * 60_000) {
    for (const it of this.items) {
      if (it.result) continue;
      const hitStop = it.dir > 0 ? lo <= it.stop : hi >= it.stop; const hitT = it.dir > 0 ? hi >= it.target : lo <= it.target;
      if (hitStop) it.result = { kind: 'stop', at: now }; else if (hitT) it.result = { kind: 'target', at: now }; else if (now - it.at > maxAgeMs) it.result = { kind: 'expired', at: now };
    }
  }
  stats() { const done = this.items.filter((x) => x.result && x.result.kind !== 'expired'); const w = done.filter((x) => x.result.kind === 'target').length; return { total: this.items.length, closed: done.length, wins: w, losses: done.length - w, open: this.items.filter((x) => !x.result).length }; }
}
