// Pure strategy evidence, using closed provider candles only. No model-generated prices.
const finite = Number.isFinite;
export function closedBars(bars, seconds, now = Date.now()) {
  return (bars || []).filter(b => [b.time,b.open,b.high,b.low,b.close].every(finite) && b.high >= Math.max(b.open,b.close) && b.low <= Math.min(b.open,b.close) && (b.time + seconds) * 1000 <= now).sort((a,b)=>a.time-b.time);
}
export function validPlan(p) {
  if (!p || !['long','short'].includes(p.direction) || ![p.entry,p.stop,...(p.targets || [])].every(v=>finite(v)&&v>0) || p.targets?.length !== 3) return false;
  const s = p.direction === 'long' ? 1 : -1;
  return (p.entry-p.stop)*s > 0 && p.targets.every((v,i)=>(v-(i?p.targets[i-1]:p.entry))*s > 0);
}
export function analyzeEvidence({ candles, higher, daily, seconds, strategy='smc', order='market', price, now=Date.now(), point=0.01 }) {
  const bars = closedBars(candles,seconds,now), ht=closedBars(higher,14400,now), days=closedBars(daily,86400,now);
  const checks=[], zones=[];
  const add=(key,pass)=>checks.push({key,pass:Boolean(pass)});
  const result={checks,zones,plan:null, strategy,order,asOf:bars.at(-1)?.time,probability:null};
  add('data',bars.length>=30 && (strategy==='edh'||ht.length>=12) && finite(price) && price>0);
  if (!checks[0].pass) return result;
  const last=bars.at(-1), prior=bars.slice(-21,-1);
  const hi=Math.max(...prior.map(b=>b.high)),lo=Math.min(...prior.map(b=>b.low));
  let direction=null, entry,stop;
  if(strategy==='edh') {
    add('fiveMinute',seconds===300); add('previousDay',days.length>0);
    if(days.length){const d=days.at(-1); zones.push({label:'PDH',low:d.high,high:d.high},{label:'PDL',low:d.low,high:d.low});
      if(last.close>d.high && bars.at(-2).close<=d.high) direction='long';
      if(last.close<d.low && bars.at(-2).close>=d.low) direction='short';
      add('closeBreak',!!direction);
      entry=order==='market'?price:direction==='long'?d.high:d.low;
      stop=direction==='long'?Math.min(last.low,d.high)-point*2:Math.max(last.high,d.low)+point*2;
    }
  } else {
    // Sweep must precede a close through the intervening swing and a displacement candle.
    const bias=ht.at(-1).close>ht.slice(-12).reduce((n,b)=>n+b.close,0)/12?'long':'short';
    direction=bias;
    let sweep=-1;
    for(let i=bars.length-9;i<bars.length-1;i++){
      const prev=bars.slice(Math.max(0,i-12),i), b=bars[i];
      const level=bias==='long'?Math.min(...prev.map(x=>x.low)):Math.max(...prev.map(x=>x.high));
      if(bias==='long'?b.low<level && b.close>level:b.high>level && b.close<level) sweep=i;
    }
    add('bias4h',true);add('sweep',sweep>=0);
    const swing=sweep>=0?bars.slice(sweep,-1):prior;
    add('mss',bias==='long'?last.close>Math.max(...swing.map(b=>b.high)):last.close<Math.min(...swing.map(b=>b.low)));
    const average=prior.reduce((n,b)=>n+b.high-b.low,0)/prior.length;
    add('displacement',Math.abs(last.close-last.open)>=average*.7 && (bias==='long'?last.close>last.open:last.close<last.open));
    let ob=null,fvg=null;
    for(let i=Math.max(2,sweep);i<bars.length;i++){
      const a=bars[i-2],c=bars[i];
      if(bias==='long'?c.low>a.high:c.high<a.low) {
        const z={label:'FVG',low:bias==='long'?a.high:c.high,high:bias==='long'?c.low:a.low,time:c.time};
        const unfilled=bars.slice(i+1).every(b=>bias==='long'?b.low>z.low:b.high<z.high);
        if(unfilled)fvg=z;
      }
    }
    if(sweep>=0)for(let i=sweep;i<bars.length-1;i++){
      const b=bars[i]; if(bias==='long'?b.close<b.open:b.close>b.open)ob={label:'OB',low:b.low,high:b.high,time:b.time};
    }
    if(ob && bars.filter(b=>b.time>ob.time).some(b=>bias==='long'?b.close<ob.low:b.close>ob.high))ob=null;
    if(ob)zones.push(ob);if(fvg)zones.push(fvg);
    // A gap born on the confirmation bar has not yet been retraced.
    const zone=order==='market'?(fvg?.time<last.time?fvg:ob):(fvg||ob);
    add('pdArray',!!zone);
    // Market: confirmation candle touched the array; limit: only pending retracement.
    add('retrace',order==='limit'||!!zone && last.low<=zone.high && last.high>=zone.low);
    entry=order==='market'?price:zone?(zone.low+zone.high)/2:NaN;
    stop=bias==='long'?Math.min(...bars.slice(sweep>=0?sweep:-10).map(b=>b.low))-point*2:Math.max(...bars.slice(sweep>=0?sweep:-10).map(b=>b.high))+point*2;
    zones.push({label:'Liquidity',low:bias==='long'?lo:hi,high:bias==='long'?lo:hi});
  }
  const s=direction==='long'?1:-1;
  add('entrySide',!!direction && (order==='limit'?(price-entry)*s>0:Math.abs(price-last.close)<=Math.max(last.high-last.low,point*10)));
  const risk=(entry-stop)*s;
  const plan={direction,entry,stop,targets:[1,1.45,2.5].map(r=>entry+s*risk*r),order};
  add('levels',validPlan(plan));
  result.direction=direction;
  if(checks.every(c=>c.pass))result.plan=plan;
  return result;
}

// Tracking observes quotes after analysis, never claims broker execution or historical touches.
export function advanceTracker(state,plan,price,time=Date.now()) {
  if(!validPlan(plan)||!finite(price)||price<=0||['stop','complete','expired'].includes(state.status)||time<=state.at)return state;
  const s=plan.direction==='long'?1:-1;
  let status=state.status;
  if(status==='pending' && (price-plan.entry)*s<=0)status='active';
  let hits=[...(state.hits||[])];
  if(status==='active'){
    if((price-plan.stop)*s<=0)status='stop';
    else {hits=plan.targets.map((p,i)=>hits[i]||(price-p)*s>=0);if(hits.every(Boolean))status='complete';}
  }
  return {...state,status,hits,price,at:time};
}
