// Dynamic position sizing: the amount risked per trade is a fixed share of the account, and it shrinks
// when the market is unusually volatile (never grows above the chosen share). The size is the number of
// units (coins / ounces / index units) whose loss at the stop equals the risked amount. It does not know
// contract sizes, margin or leverage of a specific broker — convert the units to lots there.
export function positionSize({ account, riskPct, entry, stop, volRank = null, volScale = true }) {
  const dist = Math.abs(entry - stop);
  if (!(account > 0) || !(riskPct > 0) || !(dist > 0) || !(entry > 0)) return null;
  const scale = volScale && volRank != null ? (volRank >= 0.9 ? 0.5 : volRank >= 0.75 ? 0.7 : 1) : 1;
  const pct = riskPct * scale;
  const riskAmount = (account * pct) / 100;
  const units = riskAmount / dist;
  return { units, riskAmount, notional: units * entry, pct, scale };
}
