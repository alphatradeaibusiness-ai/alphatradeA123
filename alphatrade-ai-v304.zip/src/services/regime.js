// Market-condition reading: volatility, liquidity (volume), trend strength, higher-timeframe trend and
// session, per candle, from PAST candles only (trailing windows — no look-ahead). Used to
//   • tag every trade with the conditions it was opened in (so losing trades can be explained), and
//   • block entries in conditions that were proven bad on earlier data (see lossAnalysis.js).
// Pure functions.
import { atr } from '../indicators/index.js';
import { killZone } from './smc2.js';
import { htfTrendSeries } from './zoneStrategy.js';

const WIN = 500;       // trailing candles used for percentile ranks
const MIN_HIST = 100;  // ranks need at least this many past values
const ER_LEN = 30;     // candles for the efficiency ratio

/** Every flag a trade can carry at entry, with a short meaning (texts live in i18n `regime.flag.*`). */
export const FLAGS = ['highVol', 'lowVol', 'thinLiq', 'range', 'againstHtf', 'offSession', 'weakVolume'];

/** Share of the previous `WIN` values that are below `values[i]` (null while there is too little history). */
function trailingRank(values, i) {
  const from = Math.max(0, i - WIN);
  if (i - from < MIN_HIST || values[i] == null) return null;
  let below = 0; let n = 0;
  for (let k = from; k < i; k++) { if (values[k] == null) continue; n++; if (values[k] < values[i]) below++; }
  return n >= MIN_HIST ? below / n : null;
}

export function regimeSeries(candles) {
  const n = candles.length;
  const tfSec = n > 1 ? candles[1].time - candles[0].time : 60;
  const a = atr(candles, 14);
  const atrPct = a.map((v, i) => (v == null ? null : v / candles[i].close));
  const hasVol = candles.some((c) => c.volume > 0);
  const vsum = new Array(n + 1).fill(0);
  for (let i = 0; i < n; i++) vsum[i + 1] = vsum[i] + (candles[i].volume || 0);
  const avg20 = candles.map((_, i) => (i >= 20 ? (vsum[i + 1] - vsum[i - 19]) / 20 : null));
  const dsum = new Array(n).fill(0);
  for (let i = 1; i < n; i++) dsum[i] = dsum[i - 1] + Math.abs(candles[i].close - candles[i - 1].close);
  const volRank = new Array(n).fill(null);
  const liqRank = new Array(n).fill(null);
  const er = new Array(n).fill(null);
  for (let i = 0; i < n; i++) {
    volRank[i] = trailingRank(atrPct, i);
    if (hasVol) liqRank[i] = trailingRank(avg20, i);
    if (i >= ER_LEN) { const path = dsum[i] - dsum[i - ER_LEN]; er[i] = path > 0 ? Math.abs(candles[i].close - candles[i - ER_LEN].close) / path : 0; }
  }
  return { n, tfSec, hasVol, volRank, liqRank, er, avg20, htf: htfTrendSeries(candles, tfSec), candles };
}

/** Flags that apply to a trade opened at the close of candle `i` in `direction` ('long' | 'short'). */
export function flagsAt(R, i, direction) {
  const out = [];
  const v = R.volRank[i];
  if (v != null) { if (v >= 0.75) out.push('highVol'); else if (v <= 0.25) out.push('lowVol'); }
  const l = R.liqRank[i];
  if (l != null && l <= 0.25) out.push('thinLiq');
  if (R.er[i] != null && R.er[i] < 0.25) out.push('range');
  const h = R.htf[i];
  if (h && h !== (direction === 'long' ? 1 : -1)) out.push('againstHtf');
  if (R.tfSec < 14400 && !killZone(R.candles[i].time)) out.push('offSession');
  if (R.hasVol && R.avg20[i] > 0 && R.candles[i].volume < 0.8 * R.avg20[i]) out.push('weakVolume');
  return out;
}

/** One-word reading of the market for display: volatility · liquidity · trend. */
export function describe(R, i) {
  const v = R.volRank[i]; const l = R.liqRank[i]; const e = R.er[i];
  return {
    vol: v == null ? null : v >= 0.75 ? 'high' : v <= 0.25 ? 'low' : 'normal',
    liq: l == null ? null : l <= 0.25 ? 'thin' : l >= 0.75 ? 'deep' : 'normal',
    trend: e == null ? null : e >= 0.25 ? 'trending' : 'range',
    htf: R.htf[i] || null,
  };
}

/** True when an entry at candle `i` carries any of the blocked flags. */
export function isBlocked(R, blocked, i, direction) {
  if (!blocked || !blocked.length) return false;
  const f = flagsAt(R, i, direction);
  return f.some((x) => blocked.includes(x));
}
