// Walk-forward stability report. The strategy runs ONCE over the whole loaded history with fixed rules (the user's current
// settings, fees included — nothing is tuned), and the trades are then split by time into sequential folds. A strategy that
// only works in one stretch of history, or whose average trade is not clearly above zero, is reported as such.
// It describes the past on the loaded candles. It is not a prediction and not a win-rate promise.
import { runStrategy, WARMUP } from './backtest.js';

export const FOLDS = 5;
export const MIN_TRADES_TOTAL = 30;   // below this the sample says too little to judge
export const MIN_TRADES_FOLD = 3;

const mean = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);
export function foldStats(trades) {
  const r = trades.map((t) => (Number.isFinite(t.r) ? t.r : 0));
  const wins = trades.filter((t) => t.points > 0).length;
  const gw = r.filter((v) => v > 0).reduce((a, b) => a + b, 0); const gl = -r.filter((v) => v < 0).reduce((a, b) => a + b, 0);
  return { n: trades.length, winRate: trades.length ? (wins / trades.length) * 100 : 0, netR: r.reduce((a, b) => a + b, 0), avgR: mean(r), pf: gl > 0 ? gw / gl : gw > 0 ? Infinity : 0 };
}

/** t-statistic of the average trade (R) against zero: how many standard errors above/below zero it is. */
export function tStat(rs) {
  const n = rs.length; if (n < 2) return 0;
  const m = mean(rs); const v = rs.reduce((a, x) => a + (x - m) ** 2, 0) / (n - 1);
  return v > 0 ? m / Math.sqrt(v / n) : 0;
}

/**
 * Verdict from the fold results (rules, in this order):
 *   insufficient  fewer than MIN_TRADES_TOTAL trades
 *   negative      average trade ≤ 0 after fees
 *   stable        average trade > 0, t ≥ 2, at least 70% of the folds that have trades are positive, and the most recent half is not negative
 *   inconsistent  anything else (positive on average but not clearly above zero, or only in some stretches)
 * Even "stable" is a statement about the past on these candles.
 */
export function verdictOf({ total, folds, tail, t }) {
  if (total.n < MIN_TRADES_TOTAL) return 'insufficient';
  if (total.avgR <= 0) return 'negative';
  const used = folds.filter((f) => f.n >= MIN_TRADES_FOLD);
  const pos = used.filter((f) => f.netR > 0).length;
  if (t >= 2 && used.length >= 3 && pos / used.length >= 0.7 && tail.netR >= 0) return 'stable';
  return 'inconsistent';
}

/** @param candles ascending candles  @param strategy 'classic'|'smc'|'zone'  @param rules same object the results page builds */
export function walkForward(candles, strategy, rules, { folds = FOLDS } = {}) {
  if (!candles?.length || candles.length < WARMUP + 50) return null;
  const run = runStrategy(strategy, candles, rules);
  const trades = (run.trades || []).filter((x) => Number.isFinite(x.openTime)).sort((a, b) => a.openTime - b.openTime);
  const t0 = candles[WARMUP].time; const t1 = candles[candles.length - 1].time;
  const span = (t1 - t0) / folds;
  const parts = Array.from({ length: folds }, (_, k) => trades.filter((x) => x.openTime >= t0 + k * span && (k === folds - 1 ? x.openTime <= t1 : x.openTime < t0 + (k + 1) * span)));
  const foldRows = parts.map((p, k) => ({ k, from: Math.round(t0 + k * span), to: Math.round(t0 + (k + 1) * span), ...foldStats(p) }));
  const total = foldStats(trades);
  const tail = foldStats(parts.slice(Math.ceil(folds / 2)).flat());   // the most recent half of the history
  const t = tStat(trades.map((x) => (Number.isFinite(x.r) ? x.r : 0)));
  const verdict = verdictOf({ total, folds: foldRows, tail, t });
  return { folds: foldRows, total, tail, t, verdict, positiveFolds: foldRows.filter((f) => f.n >= MIN_TRADES_FOLD && f.netR > 0).length, usedFolds: foldRows.filter((f) => f.n >= MIN_TRADES_FOLD).length };
}
