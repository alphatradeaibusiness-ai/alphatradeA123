// Assistant + technical support, through the site's AI gateway (services/ai/gateway.js).
import { aiConfig } from '../../config/ai.js';
import { ENFORCE, aiRemaining, consumeAi } from '../../config/entitlements.js';
import { t } from '../../i18n/index.js';
import { aiStatus, aiPost } from './gateway.js';

/** { connected, state, vision } — connected only after the server reported a verified key. */
export async function checkAiHealth() {
  const st = await aiStatus();
  return { connected: st.state === 'connected' || st.state === 'unchecked', state: st.state, vision: Boolean(st.vision), error: st.error };
}

const clean = (messages) => messages.slice(-aiConfig.maxHistory).map(({ role, content }) => ({ role, content }));

export async function sendAiMessage(messages, context, lang) {
  if (ENFORCE && aiRemaining() <= 0) throw new Error(t('ent.aiOut'));
  const res = await aiPost('/chat', { messages: clean(messages), context, lang });
  if (!res || typeof res.reply !== 'string' || !res.reply.trim()) throw new Error('Empty reply from AI service');
  consumeAi();
  return res.reply;
}

/** Smart technical support: how to use the site (no market data, no trading advice). */
export async function sendSupportMessage(messages, page, lang) {
  const res = await aiPost('/support', { messages: clean(messages), page, lang });
  if (!res || typeof res.reply !== 'string' || !res.reply.trim()) throw new Error('Empty reply from AI service');
  return res.reply;
}

/** AI review of the user's own trades, from statistics the site computed (never from raw guesses). */
export async function reviewTrades(context, lang) {
  if (ENFORCE && aiRemaining() <= 0) throw new Error(t('ent.aiOut'));
  const res = await aiPost('/review', { context, lang });
  consumeAi();
  return res.reply;
}

/** AI explanation of the chart analysis + strategy results, from the real numbers on screen. */
export async function explainAnalysis(context, lang) {
  if (ENFORCE && aiRemaining() <= 0) throw new Error(t('ent.aiOut'));
  const res = await aiPost('/explain', { context, lang });
  consumeAi();
  return res.reply;
}

/** AI explanation of the SMC / ICT assistant's reading (the numbers come from the site; the AI only explains them). */
export async function explainSmc(context, lang) {
  if (ENFORCE && aiRemaining() <= 0) throw new Error(t('ent.aiOut'));
  const res = await aiPost('/smc', { context, lang });
  consumeAi();
  return res.reply;
}
