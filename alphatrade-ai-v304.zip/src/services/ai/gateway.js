// The ONLY way the browser reaches AI: the site's own server (/api/ai/*), which holds the owner's key (encrypted)
// and checks the signed-in user. The browser never sees, stores or sends an AI key.
import { aiConfig } from '../../config/ai.js';
import { auth } from '../auth/index.js';

export const AI_BASE = aiConfig.apiUrl.replace(/\/chat$/, '');

export class AiError extends Error {
  constructor(code, status = 0) { super(code); this.code = code; this.status = status; }
}

let last = null; const listeners = new Set();
export const onAiStatus = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
export const lastAiStatus = () => last;
function publish(st) { last = { ...st, at: Date.now() }; listeners.forEach((fn) => { try { fn(last); } catch { /* a view error must not break the others */ } }); return last; }

async function headers(json = true) {
  const h = json ? { 'Content-Type': 'application/json' } : {};
  const tok = await auth.idToken().catch(() => null);
  if (tok) h.Authorization = `Bearer ${tok}`;
  return h;
}

async function request(method, path, body, timeoutMs = 60000) { return apiRequest(method, `${AI_BASE}${path}`, body, timeoutMs); }

/** Same call for any of the site's own server routes (used by the market-data key too). Adds the sign-in token. */
export async function apiRequest(method, url, body, timeoutMs = 60000) {
  const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  let r;
  try {
    r = await fetch(url, { method, headers: await headers(body !== undefined), body: body === undefined ? undefined : JSON.stringify(body), signal: ctrl.signal, credentials: 'same-origin' });
  } catch (e) {
    throw new AiError(e?.name === 'AbortError' ? 'timeout' : 'server_unreachable');
  } finally { clearTimeout(timer); }
  const ct = r.headers.get('content-type') || '';
  if (ct.includes('text/html')) throw new AiError('server_missing', r.status);   // static host (e.g. Netlify) answered with the page, not the API
  const j = await r.json().catch(() => null);
  if (!j) throw new AiError(r.status === 404 ? 'server_missing' : 'bad_reply', r.status);   // a static host without the Node server answers 404 / HTML
  if (!r.ok) throw new AiError(j.code || (r.status === 401 ? 'signin_required' : 'unknown'), r.status);
  return j;
}

/** A signed-in GET that returns a blob URL (images the server only shows to their owner, e.g. feedback attachments). */
export async function apiBlobUrl(url) {
  const r = await fetch(url, { headers: await headers(false), credentials: 'same-origin' });
  if (!r.ok) throw new AiError(r.status === 404 ? 'not_found' : 'unknown', r.status);
  return URL.createObjectURL(await r.blob());
}

/** Connection state for everyone; owner details when the signed-in user is the owner. */
export async function aiStatus() {
  try { return publish(await request('GET', '/status', undefined, 10000)); }
  catch (e) { return publish({ state: e.code === 'server_missing' || e.code === 'server_unreachable' || e.code === 'bad_reply' ? 'no_server' : 'unknown', error: e.code }); }
}

/** A feature request (chat, support, explain, vision, images/describe, images/match). */
export async function aiPost(path, body, { timeoutMs = 70000 } = {}) {
  try { return await request('POST', path, body, timeoutMs); }
  catch (e) {
    if (['not_configured', 'invalid_key', 'no_credit', 'vision_unsupported'].includes(e.code)) aiStatus();   // the owner changed something: refresh every view
    throw e;
  }
}

/* Owner actions. Each returns { ok, code, status } and publishes the new status to every view. */
export async function saveAiConfig(cfg) { const r = await request('PUT', '/config', cfg, 90000); publish(r.status); return r; }
export async function testAiConfig() { const r = await request('POST', '/config/test', {}, 90000); publish(r.status); return r; }
export async function deleteAiConfig() { const r = await request('DELETE', '/config', undefined, 20000); publish(r.status); return r; }
