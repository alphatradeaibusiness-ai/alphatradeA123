// What the AI gets for "review my trades": only statistics the site computed from the user's trades (services/tradeInsights.js).
// No raw notes, no account data. Group names are the raw dimension/value so the AI cannot be fed invented labels.
const g = (x) => ({ dim: x.dim, key: x.key, n: x.n, winRate: round(x.winRate, 0), avgR: round(x.avgR, 2), netR: round(x.netR, 1) });
const round = (v, d) => (Number.isFinite(v) ? Number(v.toFixed(d)) : null);

export function reviewContext(res, { source = 'journal', strategy = 'all' } = {}) {
  if (!res?.overall || !(res.overall.n > 0)) return null;
  const o = res.overall;
  return {
    source, strategy, grade: res.grade || null,
    overall: { n: o.n, winRate: round(o.winRate, 1), avgR: round(o.avgR, 2), netR: round(o.netR, 1), profitFactor: Number.isFinite(o.pf) ? round(o.pf, 2) : null, avgWinR: round(o.avgWin, 2), avgLossR: round(o.avgLoss, 2), maxDrawdownR: round(o.maxDD, 1), longestLossStreak: o.lossStreak },
    strengths: (res.strengths || []).slice(0, 4).map(g),
    weaknesses: (res.weaknesses || []).slice(0, 4).map(g),
    diagnostics: (res.diag || []).map((d) => ({ key: d.key, value: round(d.v, 2) })),
    outcomes: res.outcomes || {},
    whatIfSkipping: res.whatIf ? { groups: res.whatIf.skip.map((s) => ({ dim: s.dim, key: s.key })), netRBefore: round(res.whatIf.before.netR, 1), netRAfter: round(res.whatIf.after.netR, 1), tradesAfter: res.whatIf.after.n, note: 'in-sample what-if, not a prediction' } : null,
    note: 'statistics of past trades computed by the site; small samples are unreliable',
  };
}
