// Signals channel. Runs in the background while the app is open:
//  • every minute it tests both strategies on the last 1000 REAL candles for every symbol and
//    timeframe (15m, 1h, 4h). A combination qualifies only if its real accuracy (trades that made
//    money after fees) is ≥ 62% over at least 20 trades with a positive net result AND it also holds on
//    its newest 40% of trades (≥ 60%, at least 8 trades) that were not used to choose it;
//  • when a qualifying combination opens a NEW trade (on a closed candle), a signal is published;
//  • every 3 seconds live prices are checked and each signal's progress (TP1 → TP2 → TP3, or stop)
//    is updated; new signals and hits trigger a phone/desktop notification with the logo.
// Demo data never produces signals.
import { INSTRUMENTS, STOP_LOSS_POINTS, TARGET_POINTS } from '../config/instruments.js';
import { getHistory, getTickers, isUnavailable } from './market/index.js';
import { runStrategy, rulesFrom, LBR_DEFAULTS } from './backtest.js';
import { lbrHistory } from './lbrData.js';
import { stratName } from './stratName.js';
import { gateFor } from './adaptive.js';
import { store } from '../state/store.js';
import { storage } from '../utils/storage.js';
import { t, getLang } from '../i18n/index.js';
import { tradeAlert, pairName } from './tradeMessages.js';
import { fmtNum } from '../utils/dom.js';
import { gateTrade, confirmCfg } from './gate.js';
import { logSignal, logSignals, channelCheck, channelWants } from './channel.js';
import { dailyPipsOf, pipPoints } from './pips.js';
import { guardCheck, guardState } from './riskGuard.js';
import { domWall } from './execFilters.js';
import { fetchBinanceDepth } from './market/binance.js';
import { getCalendar, CCY_IMPACT } from './news.js';
import { newsRisk } from './synthesis.js';
import { prefetchHtf, htfCandles } from './htfData.js';
import { getDerivs, readDerivs, derivCheck } from './derivatives.js';
import { returnCorrelation, correlatedExposure } from './quant.js';
import { apiRequest } from './ai/gateway.js';
import { auth } from './auth/index.js';
import { analyzeEvidence, closedBars } from './marketAnalysis.js';
import { pendingTransition } from './recommendationLifecycle.js';
import { presetCfg } from './multiStrategy.js';
import { scanJob } from './scanAsync.js';
import { learnFrom, learnCheck } from './learning.js';
import { engineMode } from './engineMode.js';

// The channel page now runs the full scanner locally in the browser (real prices from
// Binance/Yahoo). No server worker needed — recommendations appear automatically.
const REMOTE_CHANNEL = false;

// The publishing bar and its evaluation live in a pure module (also used by the scan Web Worker).
export { MIN_ACCURACY, MIN_TRADES, MIN_OOS_TRADES, MIN_OOS_ACC, WATCH_ACCURACY, WATCH_TRADES, evaluateCombo } from './comboEval.js';
import { MIN_ACCURACY, evaluateCombo } from './comboEval.js';
// Entry frames: every market is analysed continuously and entries are taken on 1-minute or 5-minute closes.
// Each frame keeps its own deep proof (1m every 5 min, 5m every 15 min) and a light live check for a fresh setup.
const TFS = ['1m', '5m'];
// Strategies tested on the 15m / 1h / 4h scan. Classic, SMC and Zones were retired in v173 (services/channel.js); LBR runs on 5m (lbrScan).
const SCAN_STRATEGIES = ['edh'];
const TF_SEC = { '1m': 60, '5m': 300, '15m': 900, '1h': 3600, '4h': 14400 };
const PROOF_BARS = { '1m': { binance: 15000, other: 5000 }, '5m': { binance: 12000, other: 5000 } };   // ~10 and ~41 days on Binance
// Smooth load: a deep proof is the heavy part (thousands of candles), so each frame re-tests at a pace that matches how fast its
// result can change, and only a couple of deep tests run per pass (markets take turns), with a breather after each.
const PROOF_EVERY_MS = { '1m': 5 * 60_000, '5m': 15 * 60_000 };
const MAX_PROOFS_PER_PASS = 2;
let proofsThisPass = 0;
const LIVE_BARS = { '1m': 3000, '5m': 1000 };   // 50 h / 83 h: always covers the previous day the strategy needs
const TRACK_MS = 1000;   // prices of open signals (and their cards) refresh every second
const SCAN_MS = 60_000;
// Continuous scanner: after each pass it re-scans after this delay when the tab is visible.
// One second keeps new setups flowing in near-real-time.
const SCAN_AGAIN_MS = 1000;   // re-scan every second
const KEY = 'signals';
// Each recommendation stays in the channel for 2 hours from when it was sent, whatever its status, then it is removed
// automatically (an open one is closed as "expired" at that point and recorded in the channel history first).
export const SIGNAL_LIFETIME_MS = 2 * 3600_000;

const state = {
  signals: REMOTE_CHANNEL ? [] : storage.get(KEY, []).filter((x) => x?.status !== 'sl'),   // stop-loss hits are never kept across reloads  // private feed never persists across browser accounts
  combos: {},                     // `${sym}|${tf}|${strategy}` → { winRate, trades, points, qualified, at }
  scanning: false, lastScan: null, lastTrack: null, live: null,
  skipped: [],                    // signals the risk guard held back (newest first, kept in memory)
  allowance: null, feedConfigured: null, feedError: null,
};
const listeners = new Set();
let trackTimer = null;
let scanTimer = null;
let started = false;
let feedTimer = null;
let authOff = null;

// Hybrid channel: the browser keeps scanning on its own, AND when the 24/7 server worker is deployed (server/worker.js →
// /api/channel/feed) the signals it found while this page was closed are merged in (same ids, so nothing is duplicated).
// On a static host without the API (e.g. Netlify only) the request simply fails and nothing changes.
let serverBusy = false, serverOff = 0;
const SERVER_PULL_MS = 30_000;
async function pullServerSignals() {
  if (REMOTE_CHANNEL || serverBusy || globalThis.__CHANNEL_WORKER || !auth.current() || Date.now() < serverOff) return;
  serverBusy = true;
  try {
    const data = await apiRequest('GET', '/api/channel/feed', undefined, 8000);
    if (!data?.configured || !Array.isArray(data.signals)) { serverOff = Date.now() + 10 * 60_000; return; }
    state.server = { at: Date.now(), n: data.signals.length };
    if (data.allowance && typeof data.allowance === 'object') { state.serverAllowance = data.allowance; state.allowance = localAllowance(); emit(); }
    const have = new Map(state.signals.map((x) => [x.id, x]));
    let changed = false;
    for (const x of data.signals) {
      if (!x?.id || !Number.isFinite(x.entry) || x.targets?.length !== 3 || Date.now() - (x.createdAt || 0) >= SIGNAL_LIFETIME_MS) continue;
      const mine = have.get(x.id);
      if (!mine) {
        state.signals.unshift({ ...x, via: 'server' }); changed = true;
        // only a recommendation that is still open and recent is announced (no flood of old ones after a long absence)
        if (['active', 'pending'].includes(x.status) && Date.now() - (x.createdAt || 0) < 15 * 60_000) { notify(`${t('sig.newTitle')} · ${pairName(x.symbol)}`, describe(x, true), x.id, true); window.dispatchEvent(new CustomEvent('alpha-signal-card', { detail: { signal: x } })); }
      } else if (mine.via === 'server' && (x.status !== mine.status || x.hits !== mine.hits)) { Object.assign(mine, x); changed = true; if (!['active', 'pending'].includes(mine.status)) learnFrom(mine); }
    }
    if (changed) { state.signals.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)); save(); emit(); }
  } catch { serverOff = Date.now() + 10 * 60_000; }   // no API on this host (or signed out): try again later, quietly
  finally { serverBusy = false; }
}

export const onSignals = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
export const signalState = () => state;
const emit = () => listeners.forEach((fn) => { try { fn(state); } catch (e) { console.error(e); } });
// Saved on this device: open recommendations and finished ones — except a stop-loss hit, which is shown under "Closed"
// until it leaves the channel and is never kept in storage (its result is still recorded in the channel history / learning).
const save = () => { if(!REMOTE_CHANNEL) storage.set(KEY, state.signals.filter(s => ['active','pending'].includes(s.status)).concat(state.signals.filter(s => !['active','pending','sl'].includes(s.status)).slice(0, 200))); };

export function startSignals() {
  if (started) return;
  started = true;
  if (!REMOTE_CHANNEL && !state.allowance) { state.allowance = localAllowance(); emit(); }   // v230: the card shows at once, not after the first scan
  // Local scanner: runs the full strategy engine on real prices in the browser.
  // Self-scheduling loop: next pass 1 s after the previous one finished (visible tab).
  // In a hidden tab the browser throttles timers, so scanning simply slows down — it never stacks.
  const loop = () => { scanTimer = setTimeout(async () => { await scan(); loop(); }, document.hidden ? SCAN_MS : SCAN_AGAIN_MS); };
  scan().then(loop);
  trackTimer = setInterval(track, TRACK_MS);
  track();
  feedTimer = setInterval(pullServerSignals, SERVER_PULL_MS); setTimeout(pullServerSignals, 4000);
}
export function stopSignals() { clearInterval(feedTimer); clearTimeout(scanTimer); clearInterval(trackTimer); authOff?.(); authOff=null; started = false; }

// Local channel: no server needed. The allowance is computed locally so the
// channel page shows recommendations immediately for any signed-in user.
// v230: no invented numbers. The local channel has no monthly cap (mode 'open'); the person's REAL subscription (plan,
// renewal) comes from the server's feed answer when the server is reachable. Before, every user saw a fake
// "active subscription · 0 / 999" (createdAt is a number, so the month filter never matched either).
function localAllowance() {
  const sub = state.serverAllowance;
  return { mode: 'open', active: true, view: 'complete', owner: Boolean(sub?.owner),
    plan: sub?.active && !sub.owner ? sub.plan || null : null, subscribed: Boolean(sub?.active && !sub.owner && sub.plan), renewsAt: sub?.active ? sub.renewsAt || null : null, channelOnly: Boolean(sub?.channelOnly) };
}

const pause = (ms) => new Promise((r) => setTimeout(r, ms));

async function scan() {
  if (state.scanning) return;   // keeps scanning in a background tab too (browsers slow the timer down, but it does not stop)
  state.scanning = true;
  emit();
  let anyLive = false;
  let anyData = false;
  proofsThisPass = 0;
  try {
    const settings = store.get('settings');
    for (const inst of INSTRUMENTS) {
      if (isUnavailable(inst.symbol)) continue;
      await lbrScan(inst, settings).catch(() => {});
      for (const tf of TFS) {
        const r = await entryScan(inst, settings, tf).catch(() => null);
        if (r) { anyData = true; if (r.live) anyLive = true; }
        await pause(15); // keep the page responsive between tests
      }
    }
  } finally {
    if (anyData) state.live = anyLive || Object.values(state.combos).length > 0;
    state.scanning = false;
    state.lastScan = Date.now();
    state.allowance = localAllowance();
    state.feedConfigured = true;
    state.feedError = null;
    emit();
  }
}

// One market × one entry frame (1m / 5m). Proof: 1m every 5 min / 5m every 15 min (staggered), on deep history of that frame (EDH rules unchanged, only the frame it is
// tested on). Live: once per candle, on the recent closes; a setup opened on one of the last 2 closed candles is published when
// the proof is "qualified" or "watch" (tier recorded on the signal).
const proofAt = {}, liveAt = {};
async function entryScan(inst, settings, tf) {
  const strategy = SCAN_STRATEGIES[0], key = `${inst.symbol}|${tf}|${strategy}`, sec = TF_SEC[tf];
  const pointSize = Number(settings.pointSizes?.[inst.symbol]) > 0 ? Number(settings.pointSizes[inst.symbol]) : inst.pointSize;
  const rulesFor = (ds) => ({ ...rulesFrom(settings, inst), forced: null, maxPerDay: 0, pointSize, slPoints: STOP_LOSS_POINTS, tpPoints: TARGET_POINTS, volumeKind: ds.volumeKind, openOnLast: false, htfCandles: htfCandles(inst.symbol) });
  const run = (ds) => {
    const rules = rulesFor(ds);
    let r = runStrategy(strategy, ds.candles, rules);
    if (settings.regime?.enabled) { const g = gateFor(strategy, ds.candles, rules, `${inst.symbol}|${tf}`); if (g.blocked.length) r = runStrategy(strategy, ds.candles, { ...rules, regimeBlock: g.blocked, regimeR: g.R }); }
    return r;
  };
  let touched = null;
  if (Date.now() - (proofAt[key] || 0) >= PROOF_EVERY_MS[tf] && proofsThisPass < MAX_PROOFS_PER_PASS) {
    proofAt[key] = Date.now(); proofsThisPass++;
    const n = PROOF_BARS[tf][inst.provider === 'binance' ? 'binance' : 'other'];
    let deep = null;
    try { deep = await getHistory(inst.symbol, tf, n); } catch { /* retried next hour */ }
    if (deep) touched = { live: deep.mode === 'live' };
    if (deep?.mode === 'live' && deep.candles?.length >= 1500) {
      try { await prefetchHtf(inst.symbol, sec); } catch { /* the filter then uses what the candles hold */ }
      // the deep back-test runs in the scan Web Worker (the regime gate needs the main thread, so it stays here when enabled)
      const ev = settings.regime?.enabled ? evaluateCombo(run(deep).trades) : await scanJob('proof', { strategy, candles: deep.candles, rules: rulesFor(deep) });
      const dp = dailyPipsOf(ev.all.points, pipPoints(inst), deep.candles.at(-1).time - deep.candles[0].time);
      state.combos[key] = { symbol: inst.symbol, tf, strategy, winRate: ev.all.winRate, trades: ev.all.trades, points: ev.all.points, oosRate: ev.oos.winRate, oosTrades: ev.oos.trades, qualified: ev.qualified, watch: ev.watch, accuracy: ev.accuracy, dailyPips: dp.dailyPips, windowDays: dp.windowDays, at: Date.now() };
      emit();
      await pause(60);   // let the page paint before the next heavy test
    }
  }
  const proof = state.combos[key];
  const edhOn = Boolean(proof && (proof.qualified || proof.watch));
  if (Date.now() - (liveAt[key] || 0) < Math.max(20_000, sec * 500)) return touched;   // twice per candle at most
  liveAt[key] = Date.now();
  let ds;
  try { ds = await getHistory(inst.symbol, tf, edhOn ? LIVE_BARS[tf] : ENGINE_BARS); } catch { return touched; }
  if (ds.mode !== 'live' || !ds.candles?.length) return { live: false };
  const age = Date.now() / 1000 - ds.candles.at(-1).time;
  if (age < 0 || age > sec * 2 + 120) return { live: false };   // stale history, future timestamps or a closed market
  try { await prefetchHtf(inst.symbol, sec); } catch { /* see above */ }
  await engineScan(inst, settings, tf, ds).catch(() => {});   // the AI page's strategies (trend / mean reversion / SMC), every market
  if (!edhOn) return { live: true };
  const r = settings.regime?.enabled ? run(ds) : await scanJob('live', { strategy, candles: ds.candles, rules: rulesFor(ds) });
  const freshN = Number(globalThis.__SIG_FRESH) || 2; // test hook
  const fresh = r.open && r.open.openTime >= ds.candles[Math.max(0, ds.candles.length - 1 - freshN)].time;
  if (!fresh) return { live: true };
  const tier = proof.qualified ? 'qualified' : 'watch';
  let candidate = r.open, stats = { winRate: proof.accuracy, trades: proof.trades, tier };
  if (settings.channelOrder === 'limit') {
    const a = analyzeEvidence({ candles: ds.candles, higher: htfCandles(inst.symbol)?.h4 || [], daily: htfCandles(inst.symbol)?.d1 || [], seconds: sec, strategy, order: 'limit', price: ds.candles.at(-1).close, point: pointSize });
    if (!a.plan) return { live: true };
    candidate = { ...a.plan, openTime: a.asOf, status: 'pending', initialStop: a.plan.stop };
    stats = { winRate: 0, trades: 0, tier };   // market replay statistics do not validate different limit-entry rules
  }
  const g = await guardFor(inst.symbol, candidate.direction, Math.abs(candidate.entry - candidate.stop) / pointSize);
  if (await confirmBlock(inst.symbol, tf, strategy, ds, candidate, settings)) return { live: true };
  if (g.ok && settings.exec?.dom && inst.type === 'crypto' && await domBlocked(inst.symbol, candidate)) { proof.domBlocked = Date.now(); return { live: true }; }
  if (g.ok && !(await channelBlock(inst.symbol, strategy, tf))) await publishLive({ inst, tf, strategy, trade: candidate, stats, price: ds.candles.at(-1).close, dataset: ds });
  return { live: true };
}

// The same multi-strategy engine as the AI signal page (services/multiStrategy.js) on every market's 1m / 5m closes: every
// strategy that meets ALL of its own mandatory conditions (and every global safety filter) gets its own recommendation.
// These have no back-tested win rate, so they are published with tier 'engine' (labelled "conditions met · no proven rate").
// One open recommendation per market × strategy at a time; the last 600 closed candles keep it light.
const ENGINE_BARS = 600;
const ENGINE_IDS = ['trend', 'mean_reversion', 'smc'];
async function engineScan(inst, settings, tf, ds) {
  const sec = TF_SEC[tf], nowS = Date.now() / 1000;
  const closed = ds.candles.filter((c) => c.time + sec <= nowS + 1).slice(-ENGINE_BARS);
  if (closed.length < 210) return;
  const htf = htfCandles(inst.symbol);
  let cal = null;
  try { const c = await getCalendar(); if (Array.isArray(c?.events)) cal = { events: c.events, at: c.at ?? Date.now(), stale: Boolean(c.stale) }; } catch { /* the news filter then reports it */ }
  const news = cal ? newsRisk(inst.symbol, cal.events, Date.now()) : null;
  const pointSize = Number(settings.pointSizes?.[inst.symbol]) > 0 ? Number(settings.pointSizes[inst.symbol]) : inst.pointSize;
  const isOpen = (id) => state.signals.some((s) => s.symbol === inst.symbol && s.strategy === id && ['active', 'pending'].includes(s.status));
  // Each strategy is independent: its trade is published the moment ALL of its own conditions pass (onTrade fires before the
  // next strategy is even evaluated); an open recommendation from one strategy never blocks another.
  const sends = [];
  const onTrade = (x) => {
    if (!ENGINE_IDS.includes(x.id) || isOpen(x.id)) return;
    const pl = x.plan;
    // what the engine learned from its own past mistakes (services/learning.js): a losing context or a raised R:R bar
    const lc = learnCheck(x.id, { ...(x.ctx || {}), direction: x.direction, symbol: inst.symbol }, pl.rrMain, minRR);
    if (!lc.ok) { state.skipped.unshift({ symbol: inst.symbol, direction: x.direction, key: 'learned', params: { why: lc.why === 'rr' ? `R:R ${lc.rr} < ${lc.need}` : `${x.id} · ${lc.feature}` }, at: Date.now() }); state.skipped = state.skipped.slice(0, 8); return; }
    const trade = { direction: x.direction, entry: pl.entry, stop: pl.stop, initialStop: pl.stop, targets: pl.targets.slice(0, 3), openTime: closed.at(-1).time, order: 'market', ctx: x.ctx || null };
    if (trade.targets.length < 3 || !trade.targets.every(Number.isFinite)) return;
    sends.push((async () => {
      const g = await guardFor(inst.symbol, trade.direction, Math.abs(trade.entry - trade.stop) / pointSize, { independent: true });
      if (!g.ok || isOpen(x.id) || await channelBlock(inst.symbol, x.id, tf)) return;
      await publishLive({ inst, tf, strategy: x.id, trade, stats: { winRate: 0, trades: 0, tier: 'engine' }, price: ds.candles.at(-1).close, dataset: ds }, { reprice: true });
    })().catch(() => {}));
  };
  const openByStrategy = Object.fromEntries(ENGINE_IDS.map((id) => [id, isOpen(id) ? 1 : 0]));
  // Every strategy (and the SMC reading) is evaluated in the scan Web Worker; each qualified one comes back as its own trade.
  const instPlain = { symbol: inst.symbol, type: inst.type, provider: inst.provider, precision: inst.precision, pointSize: inst.pointSize };
  const res = await scanJob('engine', {
    input: { symbol: inst.symbol, inst: instPlain, tf, tfSec: sec, candles: closed, mode: ds.mode, htf, calendar: cal, peer: null, nowMs: Date.now(), account: { openByStrategy } },
    smc: { asset: inst.type === 'crypto' ? 'crypto' : (inst.type || 'crypto'), news }, cfg: presetCfg(engineMode()),
  });
  const minRR = res.minRR || 0;
  for (const x of res.emitted || []) onTrade(x);
  await Promise.all(sends);
}

// LBR (London breakout, entered on the retest) runs on 5-minute candles and only on the symbols it was researched on (LBR_DEFAULTS.symbols).
// Proof: hourly, on ~156 days of 5-minute candles, with its own 65% bar (overall AND on the newest 40% of trades). Only when that proof
// holds, a light check every minute looks for today's setup: the limit order at the broken edge (pending) or its fill (active).
const lbrLiveAt = {};
async function lbrScan(inst, settings) {
  const L = { ...LBR_DEFAULTS, ...(settings.lbr || {}) };
  if (!Array.isArray(L.symbols) || !L.symbols.includes(inst.symbol)) return;
  const key = `${inst.symbol}|5m|lbr`;
  const pointSize = Number(settings.pointSizes?.[inst.symbol]) > 0 ? Number(settings.pointSizes[inst.symbol]) : inst.pointSize;
  const rulesFor = (ds) => ({ ...rulesFrom(settings, inst), forced: null, maxPerDay: 0, pointSize, slPoints: STOP_LOSS_POINTS, tpPoints: TARGET_POINTS, volumeKind: ds.volumeKind, openOnLast: false });
  const prev = state.combos[key];
  if (!prev || Date.now() - prev.at >= 3600_000) {
    const deep = await lbrHistory(inst.symbol);
    if (deep) {
      const run = runStrategy('lbr', deep.candles, rulesFor(deep));
      const ev = evaluateCombo(run.trades, Math.max(MIN_ACCURACY, Number(L.minAccuracy) || 65));
      const dp = dailyPipsOf(ev.all.points, pipPoints(inst), deep.candles.at(-1).time - deep.candles[0].time);
      state.combos[key] = { symbol: inst.symbol, tf: '5m', strategy: 'lbr', winRate: ev.all.winRate, trades: ev.all.trades, points: ev.all.points, oosRate: ev.oos.winRate, oosTrades: ev.oos.trades, qualified: ev.qualified, accuracy: ev.accuracy, dailyPips: dp.dailyPips, windowDays: dp.windowDays, at: Date.now() };
      emit();
    }
  }
  const proof = state.combos[key];
  if (!proof?.qualified || Date.now() - (lbrLiveAt[inst.symbol] || 0) < 60_000) return;
  lbrLiveAt[inst.symbol] = Date.now();
  let ds;
  try { ds = await getHistory(inst.symbol, '5m', 3600); } catch { return; }   // 300 hours: enough for the 1-hour EMA200 trend
  if (ds.mode !== 'live' || !(ds.candles?.length > 3000)) return;
  const age = Date.now() / 1000 - ds.candles.at(-1).time;
  if (age < 0 || age > 300 * 2 + 120) return;
  const run = runStrategy('lbr', ds.candles, rulesFor(ds));
  const since = ds.candles[Math.max(0, ds.candles.length - 1 - (Number(globalThis.__SIG_FRESH) || 2))].time;
  let cand = null;
  if (run.open && run.open.openTime >= since) cand = { ...run.open, order: 'limit' };
  else if (run.pending && run.pending.createdTime >= since) cand = { ...run.pending, status: 'pending', order: 'limit' };
  if (!cand) return;
  cand.openTime = cand.breakTime ?? cand.createdTime;   // one id per day's setup: the fill never re-publishes the pending order
  const g = await guardFor(inst.symbol, cand.direction, Math.abs(cand.entry - cand.stop) / pointSize);
  if (!g.ok || await confirmBlock(inst.symbol, '5m', 'lbr', ds, cand, settings) || await channelBlock(inst.symbol, 'lbr', '5m')) return;
  await publishLive({ inst, tf: '5m', strategy: 'lbr', trade: cand, stats: { winRate: proof.accuracy, trades: proof.trades }, price: ds.candles.at(-1).close, dataset: ds });
}

// Test hook (only when a test sets __SIG_FRESH before load).
if (globalThis.__SIG_FRESH) globalThis.__sigPublish = (...a) => publish(...a);


/** Open-signal cap (6 per strategy at a time) and the mistake review; remembers why a signal was held back. */
async function channelBlock(symbol, strategy, tf) {
  const c = channelCheck(strategy, symbol, tf);
  if (c.ok) return false;
  state.skipped.unshift({ symbol, direction: '', key: c.key, params: c.params, at: Date.now() }); state.skipped = state.skipped.slice(0, 8); emit();
  return true;
}

/** Strict confirmation engine: true = held back (the reasons are remembered next to the other held-back signals). */
async function confirmBlock(symbol, tf, strategy, ds, trade, settings) {
  const cfg = confirmCfg(settings);
  if (!cfg.enabled) return false;
  let news = null;
  try { news = newsRisk(symbol, (await getCalendar()).events); } catch { /* no calendar → no news blocker */ }
  const r = gateTrade({ symbol, tf, mode: ds.mode, candles: ds.candles, trade, strategy, news, feePct: Number(settings.plan?.feePct) || 0, cfg });
  let key = null; let params = {};
  if (!r || r.verdict !== 'trade') { key = 'confirm'; params = { why: (r?.blockers || ['data']).map((b) => t(`cnf.b.${b}`)).join(' · ') }; }
  else if (cfg.maxActive > 0 && state.signals.filter((s) => s.status === 'active').length >= cfg.maxActive) { key = 'confirmCap'; params = { n: cfg.maxActive }; }
  if (!key) { trade.confirm = { score: r.score, agree: r.agree, rr: r.levels.rr }; return false; }
  state.skipped.unshift({ symbol, direction: trade.direction, key, params, at: Date.now() }); state.skipped = state.skipped.slice(0, 8); emit();
  return true;
}

/** Runs the risk guard for a candidate signal; remembers why it was held back. */
export async function guardFor(symbol, direction, riskPts = 0, { independent = false } = {}) {
  // independent: the AI engine's strategies are judged each on its own — open recommendations from OTHER strategies or markets
  // (active cap, correlated-crypto cap, dynamic correlation) do not hold it back; the account-level safety limits still apply.
  const base = store.get('settings').risk;
  const cfg = independent ? { ...base, maxActive: 0, maxCorrelated: 0, corrDynamic: false } : base;
  let events = [];
  if (cfg?.newsMinutes > 0) { try { events = (await getCalendar()).events; } catch { /* no calendar → no news filter */ } }
  let deriv = null;
  if (cfg?.derivFilter !== false) { try { deriv = derivCheck(readDerivs(await getDerivs(symbol)), direction); } catch { /* no futures data → no filter */ } }
  let corr = null;
  if (cfg?.corrDynamic !== false) { try { corr = await corrExposure(symbol, direction, Number(cfg?.corrLimit) || 0.75); } catch { /* no data → static filter only */ } }
  const g = guardCheck({ signals: state.signals, candidate: { symbol, direction, riskPts }, cfg, events, impact: CCY_IMPACT, deriv, corr });
  if (!g.ok) { state.skipped.unshift({ symbol, direction, key: g.key, params: g.key === 'deriv' ? { why: t(`dv.why.${g.params.why}`), f: g.params.f } : g.params, at: Date.now() }); state.skipped = state.skipped.slice(0, 8); emit(); }
  return g;
}
// Rolling correlation of hourly returns between two symbols (cached 15 minutes)
const corrCache = new Map();
async function pairCorr(a, b) {
  const key = [a, b].sort().join('|');
  const hit = corrCache.get(key);
  if (hit && Date.now() - hit.at < 15 * 60_000) return hit.r;
  const [da, db] = await Promise.all([getHistory(a, '1h', 160), getHistory(b, '1h', 160)]);
  const r = da.mode === 'live' && db.mode === 'live' ? returnCorrelation(da.candles, db.candles, 100) : null;
  corrCache.set(key, { at: Date.now(), r });
  return r;
}
async function corrExposure(symbol, direction, limit) {
  const others = [...new Set(state.signals.filter((s) => s.status === 'active' && s.symbol !== symbol).map((s) => s.symbol))];
  if (!others.length) return null;
  const rs = {};
  for (const o of others) rs[o] = await pairCorr(symbol, o);
  return correlatedExposure({ symbol, direction }, state.signals.filter((s) => s.status === 'active'), (a, b) => rs[a === symbol ? b : a] ?? null, limit);
}
/** Live DOM filter: a big resistance (buy) / support (sell) wall within 1R in the way, seen in two snapshots 2s apart (a pulled order = spoof). Fails open. */
async function domBlocked(symbol, trade) {
  try {
    const risk = Math.abs(trade.entry - trade.stop);
    const a = domWall(await fetchBinanceDepth(symbol), trade.direction, trade.entry, risk);
    if (!a) return false;
    await pause(2000);
    const b = domWall(await fetchBinanceDepth(symbol), trade.direction, trade.entry, risk);
    return !!(b && Math.abs(b.price - a.price) / a.price < 0.0005);
  } catch { return false; }
}
export const guardSummary = () => guardState(state.signals, store.get('settings').risk);

// Every recommendation must be real at the moment it is sent: a market entry is checked against the LIVE price (fresh quote,
// < 30 s). The AI engine's trades enter at that live price; any setup whose price already ran past the first target or beyond
// the stop (or whose reward-to-risk at the live price dropped below 1) is not sent. Limit / pending orders keep their price.
export function liveEntry(trade, price, { reprice = false } = {}) {
  if (!Number.isFinite(price) || price <= 0) return null;
  if (trade.status === 'pending' || trade.order === 'limit') return trade;
  const long = trade.direction === 'long', sg = long ? 1 : -1;
  const stop = trade.initialStop ?? trade.stop, tp1 = trade.targets[0], tp2 = trade.targets[1] ?? tp1;
  if ((price - stop) * sg <= 0 || (tp1 - price) * sg <= 0) return null;   // already beyond the stop, or already at/after target 1
  const entry = reprice ? price : trade.entry;
  if (reprice && (tp2 - entry) * sg / ((entry - stop) * sg) < 1) return null;      // most of the move already happened
  return { ...trade, entry };
}
async function publishLive(args, opts) {
  let tk = null;
  try { tk = (await getTickers([args.inst.symbol]))?.[args.inst.symbol]; } catch { /* no quote → not sent */ }
  const fresh = tk && tk.mode === 'live' && Number.isFinite(tk.price) && (!Number.isFinite(tk.at) || Date.now() - tk.at < 30_000);
  if (!fresh) return false;
  const trade = liveEntry(args.trade, tk.price, opts);
  if (!trade) { state.skipped.unshift({ symbol: args.inst.symbol, direction: args.trade.direction, key: 'stale', params: {}, at: Date.now() }); state.skipped = state.skipped.slice(0, 8); return false; }
  publish({ ...args, trade, price: tk.price });
  return true;
}

function publish({ inst, tf, strategy, trade, stats, price, dataset }) {
  const id = `${inst.symbol}|${tf}|${strategy}|${trade.openTime}`;
  if (state.signals.some((s) => s.id === id)) return;
  const sig = {
    id, symbol: inst.symbol, tf, strategy, direction: trade.direction, precision: inst.precision,
    pointSize: Number(store.get('settings').pointSizes?.[inst.symbol]) > 0 ? Number(store.get('settings').pointSizes[inst.symbol]) : (inst.pointSize || 1),
    entry: trade.entry, stop: trade.initialStop ?? trade.stop, targets: trade.targets.slice(), hits: 0, status: 'active',
    trailDist: (Number(store.get('settings').plan?.trailAtr) > 0 && trade.atrE > 0) ? Number(store.get('settings').plan.trailAtr) * trade.atrE : 0,
    ctx: trade.ctx || null, accuracy: stats.winRate, trades: stats.trades, tier: ['watch', 'engine'].includes(stats.tier) ? stats.tier : 'qualified', score: trade.score ?? null, confirm: trade.confirm || null, createdAt: Date.now(), openTime: trade.openTime, price, closedAt: null,
    order: trade.order === 'limit' ? 'limit' : 'market', activatedAt: trade.status === 'pending' ? null : Date.now(), priceAt: Date.now(),
    expiresAt: trade.status === 'pending' ? (Number(trade.expiresTime) > 0 ? trade.expiresTime * 1000 : Date.now()+(TF_SEC[tf] || 300)*2000) : null,
    evidence: dataset ? { source: dataset.source || 'Market provider', bars: closedBars(dataset.candles,TF_SEC[tf] || 300).slice(-65), zones: ['smc','edh'].includes(strategy) ? analyzeEvidence({ candles:dataset.candles,higher:htfCandles(inst.symbol)?.h4 || [],daily:htfCandles(inst.symbol)?.d1 || [],seconds:TF_SEC[tf] || 300,strategy,price,point:inst.pointSize }).zones : [] } : null,
  };
  if (trade.status === 'pending') sig.status='pending';
  state.signals.unshift(sig);
  save();
  logSignal(sig);
  const wanted = channelWants(sig.symbol, strategy);
  if (wanted) {   // the client hears about (and sees the card of) the chosen strategy only (automatic mode: the symbol's pick this month)
    notify(`${t('sig.newTitle')} · ${pairName(sig.symbol)}`, describe(sig, true), id, true);
    window.dispatchEvent(new CustomEvent('alpha-signal-card', { detail: { signal: sig } }));
  }
  emit();
}

let trackBusy=false;
async function track() { if(trackBusy)return;trackBusy=true;try{await trackOnce();}finally{trackBusy=false;} }
function pruneOld(now = Date.now()) {
  const cut = now - SIGNAL_LIFETIME_MS;
  const old = state.signals.filter((x) => (x.createdAt || 0) < cut);
  if (!old.length) return false;
  const closing = old.filter((x) => ['active', 'pending'].includes(x.status));
  for (const x of closing) { x.status = 'expired'; x.closedAt = now; learnFrom(x, now); }
  if (closing.length && !REMOTE_CHANNEL) logSignals(closing);
  state.signals = state.signals.filter((x) => (x.createdAt || 0) >= cut);
  save(); emit();
  return true;
}
async function trackOnce() {
  pruneOld();
  if(!REMOTE_CHANNEL){
    const expired=[];
    for(const s of state.signals){if(s.status==='pending'){const next=pendingTransition(s,null);if(next.status!==s.status){Object.assign(s,next);expired.push(s);}}}
    if(expired.length){save();logSignals(expired);emit();}
  }
  if (document.hidden && !state.signals.some((s) => ['active','pending'].includes(s.status))) return;
  const active = state.signals.filter((s) => ['active','pending'].includes(s.status));
  if (!active.length) { state.lastTrack = Date.now(); emit(); return; }
  let tickers;
  try { tickers = await getTickers([...new Set(active.map((s) => s.symbol))]); } catch { return; }
  let changed = false, quotesChanged=false;
  for (const s of active) {
    const tk = tickers[s.symbol];
    if (!tk || tk.mode !== 'live' || !Number.isFinite(tk.price) || !Number.isFinite(tk.at) || Date.now()-tk.at>30000 || tk.at>Date.now()+5000 || tk.at <= (s.priceAt || 0)) continue;
    if(!REMOTE_CHANNEL && s.status==='pending') {
      const previous=s.status,next=pendingTransition(s,tk);Object.assign(s,next);
      if(s.status!==previous){changed=true;if(s.status==='active')notify(t('sig.status.active'),describe(s),s.id);}
      if(s.status!=='active'){quotesChanged=true;continue;}
    }
    s.price = tk.price; s.priceAt = tk.at;quotesChanged=true;
    if (REMOTE_CHANNEL) continue; // only the worker decides fills/targets/results
    const long = s.direction === 'long';
    let stopNow = s.hits >= 1 || s.beMoved ? s.entry : s.stop; // breakeven after TP1 (or earlier, see Settings)
    // ATR trailing stop (Settings → Plan): follows the best price seen once the trade is protected
    if (s.trailDist > 0 && (s.hits >= 1 || s.beMoved)) {
      s.ext = long ? Math.max(s.ext ?? s.entry, tk.price) : Math.min(s.ext ?? s.entry, tk.price);
      const trail = long ? s.ext - s.trailDist : s.ext + s.trailDist;
      if (long ? trail > stopNow : trail < stopNow) stopNow = trail;
    }
    if (long ? tk.price <= stopNow : tk.price >= stopNow) {
      s.status = s.hits || s.beMoved ? 'be' : 'sl';
      s.closedAt = Date.now();
      const kind = s.status === 'be' && (long ? stopNow > s.entry : stopNow < s.entry) ? 'trail' : s.status;   // trailing stop closed it beyond the entry
      const m = tradeAlert(kind, { ...alertData(s), price: stopNow, stop: stopNow }, getLang());
      notify(m?.title || t(s.hits || s.beMoved ? 'sig.beTitle' : 'sig.slTitle'), m ? alertBody(s, m) : describe(s), s.id);
      learnFrom(s);
      changed = true;
      continue;
    }
    while (s.hits < 3 && (long ? tk.price >= s.targets[s.hits] : tk.price <= s.targets[s.hits])) {
      s.hits++;
      changed = true;
      const last = s.hits >= Math.min(3, s.targets.length);
      const m = tradeAlert(last ? 'final' : 'tp', { ...alertData(s), price: s.targets[s.hits - 1] }, getLang());
      notify(m?.title || t('sig.tpTitle', { n: s.hits }), m ? alertBody(s, m) : describe(s), s.id);
    }
    if (s.hits === 3) { s.status = 'tp3'; s.closedAt = Date.now(); }
    if (['sl', 'be', 'tp3'].includes(s.status)) learnFrom(s);   // the engine learns from every closed result
    const beR = Number(store.get('settings').plan?.beAtR) || 0;
    const risk0 = Math.abs(s.entry - s.stop);
    if (s.status === 'active' && beR > 0 && !s.beMoved && s.hits === 0 && risk0 > 0 && (long ? tk.price >= s.entry + beR * risk0 : tk.price <= s.entry - beR * risk0)) {
      s.beMoved = true; changed = true;
      notify(t('dv.beTitle'), describe(s), s.id);
    }
  }
  state.lastTrack = Date.now();
  if (changed || quotesChanged) save();
  if (changed) logSignals(active);
  emit();
}

// Data for the short phone alert (tradeMessages.js), plus a second line with the timeframe and strategy.
function alertData(s) { return { symbol: s.symbol, direction: s.direction, n: s.hits, entry: s.entry, stop: s.stop, precision: s.precision }; }
function alertBody(s, m) { return `${m.body}\n${t(`perf.tfShort.${s.tf}`)} · ${stratName(s.strategy)}`; }

export function describe(s, full = false) {
  const p = (v) => fmtNum(v, s.precision);
  const dir = t(s.direction === 'long' ? 'common.long' : 'common.short');
  const head = `${dir} ${pairName(s.symbol)} · ${t(`perf.tfShort.${s.tf}`)} · ${stratName(s.strategy)}${s.accuracy ? ` · ${t('sig.acc')} ${fmtNum(s.accuracy, 0)}%` : ''}${s.score != null ? ` · ${t('smcv2.scoreTag', { n: Math.round(s.score) })}` : ''}`;
  // Each value follows its own (Arabic) label so the line reads correctly right-to-left on phones.
  const ps = s.pointSize || 1;
  const pts = (x) => Math.round(Math.abs(x - s.entry) / ps).toLocaleString('en-US');
  const iso = (txt) => `\u2066${txt}\u2069`; // keeps "+594" in order inside right-to-left text
  const tps = s.targets.map((x, k) => `${t('sig.tpN', { n: k + 1 })}: ${p(x)} (${iso(`+${pts(x)}`)})${s.hits > k ? ' ✅' : ''}`).join(' · ');
  const lv = `${t('plan.entry')}: ${p(s.entry)} · ${t('plan.stop')}: ${p(s.stop)} (${iso(`−${pts(s.stop)}`)})\n${tps}`;
  return full ? `${head}\n${lv}` : `${dir} ${pairName(s.symbol)} · ${lv}`;
}

/* ───────── Notifications ───────── */
export const notifySupported = () => typeof window !== 'undefined' && 'Notification' in window;
export const notifyPermission = () => (notifySupported() ? Notification.permission : 'unsupported');
export async function enableNotifications() {
  if (!notifySupported()) return 'unsupported';
  let r;
  try { r = await Notification.requestPermission(); } catch { return 'error'; }   // some browsers throw outside a user gesture / in private mode
  if (r === 'granted') notify('AlphaTrade AI', t('sig.enabledBody'), 'welcome');
  return r;
}
/**
 * In-app toast always; a system notification when allowed. Resolves to what happened:
 * 'shown' | 'blocked' (no permission / not supported) | 'failed' (the browser refused to show it).
 */
export async function notify(title, body, tag, cardShown = false) {
  window.dispatchEvent(new CustomEvent('alpha-signal', { detail: { title, body, cardShown } }));
  if (!notifySupported() || Notification.permission !== 'granted') return 'blocked';
  const opts = { body, icon: '/icon-192.png', badge: '/icon-192.png', tag: `${tag}-${title}`, renotify: true, vibrate: [120, 60, 120], lang: document.documentElement.lang, dir: document.documentElement.dir };
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    if (reg) { await reg.showNotification(`AlphaTrade AI · ${title}`, opts); return 'shown'; }
  } catch { /* fall back below */ }
  try { new Notification(`AlphaTrade AI · ${title}`, opts); return 'shown'; } catch { return 'failed'; }   // e.g. iOS without "Add to Home Screen"
}

