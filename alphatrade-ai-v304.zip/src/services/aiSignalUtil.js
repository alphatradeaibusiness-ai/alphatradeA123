// Pure helpers for the "AI signal" page (pages/aiSignal.js): the user's clock, the status of a saved signal and
// where the live price sits between the stop and the last target. No DOM, so they are tested in node.

// v234: the page (and what the AI is told) uses the time zone of the user's device, not a fixed UTC+03:00.
// Times are stored in UTC (seconds) and only formatted for display.
export function userTz() { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; } }
/** "UTC+02:00" for a zone at `at` (ms); daylight saving is taken into account. */
export function tzOffset(tz = userTz(), at = Date.now()) {
  try {
    const part = new Intl.DateTimeFormat('en-US', { timeZone: tz, timeZoneName: 'longOffset' }).formatToParts(new Date(at)).find((x) => x.type === 'timeZoneName')?.value || 'GMT';
    const m = /GMT([+-]\d{2}):?(\d{2})?/.exec(part);
    return m ? `UTC${m[1]}:${m[2] || '00'}` : 'UTC+00:00';
  } catch { return 'UTC+00:00'; }
}
export const tzLabel = (tz = userTz(), at = Date.now()) => `${tzOffset(tz, at)} (${tz})`;
// kept for older imports: the label of the device zone when the module loaded
export const TZ = userTz();
export const TZ_LABEL = tzLabel(TZ);

/** "31 Oct, 09:15" in the user's zone (Latin digits in Arabic too). `tz` can be given explicitly (tests, the AI brief). */
export function fmtTz(sec, lang = 'ar', tz = userTz()) {
  if (!Number.isFinite(sec)) return '';
  try {
    return new Date(sec * 1000).toLocaleString(({ ar: 'ar-EG-u-nu-latn', he: 'he-IL', es: 'es-ES', zh: 'zh-CN' })[lang] || 'en-GB', { timeZone: tz, month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false });
  } catch { return new Date(sec * 1000).toISOString().slice(5, 16).replace('T', ' '); }
}

/** Status pill of a saved signal: { cls, ar, en }. */
export function signalStatus(x) {
  const s = x?.status; const n = Number(x?.hits) || 0;
  if (s === 'pending') return { cls: 'is-pending', ar: 'معلّقة', en: 'PENDING' };
  if (s === 'active') return n ? { cls: 'is-hit', ar: `TP${n} تحقق`, en: `TP${n} HIT` } : { cls: 'is-active', ar: 'نشطة', en: 'ACTIVE' };
  if (s === 'done') return { cls: 'is-hit', ar: 'الهدف تحقق', en: 'TARGET HIT' };
  if (s === 'stopped') return { cls: 'is-sl', ar: 'ضرب الوقف', en: 'SL HIT' };
  if (s === 'breakeven') return { cls: 'is-be', ar: 'على الدخول', en: 'BREAKEVEN' };
  if (s === 'expired') return { cls: 'is-off', ar: 'انتهت', en: 'EXPIRED' };
  if (s === 'missed') return { cls: 'is-off', ar: 'فاتت', en: 'MISSED' };
  return { cls: 'is-off', ar: 'ملغاة', en: 'CANCELLED' };
}

/**
 * Position of `price` on the track from the stop (0) to the last target (1), clamped; null without a price.
 * Also returns where the entry sits, so the card can mark it.
 */
export function trackPos({ direction, entry, stop, targets }, price) {
  const end = Array.isArray(targets) && targets.length ? targets[targets.length - 1] : null;
  if (!Number.isFinite(stop) || !Number.isFinite(end) || end === stop) return null;
  const at = (v) => Math.min(1, Math.max(0, (v - stop) / (end - stop)));   // works for buys and sells (sign cancels)
  return { price: Number.isFinite(price) ? at(price) : null, entry: Number.isFinite(entry) ? at(entry) : null, long: direction !== 'short' };
}

/** Saved signals for the hub: open ones first (newest first), then the latest closed, at most `max`. */
export function hubItems(items, max = 6) {
  const live = (items || []).filter((x) => x && x.mode === 'live');
  const open = live.filter((x) => ['pending', 'active'].includes(x.status)).sort((a, b) => b.savedAt - a.savedAt);
  const closed = live.filter((x) => !['pending', 'active'].includes(x.status)).sort((a, b) => b.savedAt - a.savedAt);
  return { list: [...open, ...closed].slice(0, max), open: open.length };
}

// A market order fills at the price on the screen: the plan's entry is moved to the live price (allowed slippage
// MARKET_TOL_PTS points), and risk, R:R and costs are recomputed from it. If the live price has already passed the stop or
// TP1, or the R:R left is below the style's minimum, there is no market entry.
export const MARKET_TOL_PTS = 5;
/**
 * plan: the engine's plan ({ direction, entry, stop, targets, sources, ... }); live: the live price.
 * → { ok: true, plan, movedPts } | { ok: false, reason: 'past_stop' | 'past_tp1' | 'rr_low' | 'no_price', movedPts }
 */
export function anchorMarket(plan, live, { pointSize = 1, minRR = 0, costPct = 0 } = {}) {
  if (!plan || !Number.isFinite(live) || live <= 0) return { ok: false, reason: 'no_price', movedPts: null };
  const long = plan.direction !== 'short'; const sign = long ? 1 : -1;
  const movedPts = Math.round((Math.abs(live - plan.entry) / (pointSize > 0 ? pointSize : 1)) * 10) / 10;
  if ((live - plan.stop) * sign <= 0) return { ok: false, reason: 'past_stop', movedPts };
  if ((plan.targets[0] - live) * sign <= 0) return { ok: false, reason: 'past_tp1', movedPts };
  const r2 = (v) => Math.round(v * 100) / 100;
  const risk = Math.abs(live - plan.stop);
  const rr = plan.targets.map((t) => r2(Math.abs(t - live) / risk));
  const costR = Math.round(((live * costPct) / 100 / risk) * 1000) / 1000;
  const rrNet = rr.map((v) => r2(v - costR));
  const liqIdx = (plan.sources || []).map((s, k) => (/R$/.test(String(s)) ? -1 : k)).filter((k) => k >= 0).at(-1);
  const rrMain = rrNet[liqIdx ?? Math.min(1, rr.length - 1)];
  if (!(rrMain >= minRR)) return { ok: false, reason: 'rr_low', movedPts };
  return { ok: true, movedPts, plan: { ...plan, entry: live, risk, rr, rrNet, rrMain, costR, marketFill: { price: live, tolPts: MARKET_TOL_PTS } } };
}


/** v302: what the AI reads of the chart itself: the last closed candles and three basic indicators, rounded the way the chart shows them. */
export function chartBrief(candles, n = 40) {
  const cs = (candles || []).filter((c) => Number.isFinite(c?.close));
  if (cs.length < 20) return null;
  const closes = cs.map((c) => c.close);
  const ema = (len) => { const k = 2 / (len + 1); let e = closes[0]; for (let i = 1; i < closes.length; i++) e = closes[i] * k + e * (1 - k); return e; };
  let g = 0, l = 0; for (let i = closes.length - 14; i < closes.length; i++) { const d = closes[i] - closes[i - 1]; if (d >= 0) g += d; else l -= d; }
  const rsi = l === 0 ? 100 : 100 - 100 / (1 + g / l);
  const last = cs.slice(-n); const dec = Math.max(0, 5 - String(Math.floor(Math.abs(closes.at(-1)))).length);
  const r = (v) => +v.toFixed(dec);
  const hi = Math.max(...last.map((c) => c.high)), lo = Math.min(...last.map((c) => c.low));
  return { bars: last.length, candlesOHLC: last.map((c) => [r(c.open), r(c.high), r(c.low), r(c.close)]), rangeHigh: r(hi), rangeLow: r(lo),
    ema20: r(ema(20)), ema50: closes.length >= 50 ? r(ema(50)) : null, rsi14: Math.round(rsi * 10) / 10, lastClose: r(closes.at(-1)) };
}
