// v247 Alpha Elite Signals — the signal engine of the section. Pure functions (no DOM, no network): every number comes from
// the candles and the live quote passed in, so every rule is tested in node.
//
// It runs the SAME strategy engines as «توصية AI» (services/multiStrategy.js: trend following, mean reversion, SMC / ICT with
// the tiered SMC reading of services/smcAssist.js) and the SAME execution layer (services/aiSignalEngine.js: market vs
// limit, no chase, costs, expiry). Nothing is re-implemented or simplified here.
//
// Independence: runAllStrategies evaluates every strategy on its own; each one that meets ALL of its own conditions (and the
// shared safety filters: live data, fresh candle, market open, volatility, spread, news, candle integrity) becomes its own
// signal — no vote, no consensus, no SMC confirmation of another strategy. Two strategies in opposite directions on the same
// market are both kept and flagged as a conflict.
//
// PAPER strategies (aiPaperStrategies.js) are NOT used: they did not pass the promotion rules (config/aiSignalRules.js) and
// are research only — publishing them would be publishing unvalidated signals.
import { runAllStrategies, presetCfg } from './multiStrategy.js';
import { analyzeSmcIct, cleanInputs, STYLES } from './smcAssist.js';
import { executionPlan, extraGlobals, prepare } from './aiSignalEngine.js';
import { EXEC, STRATEGIES, costModel, distanceOf } from '../config/aiSignalRules.js';
import { validateCandles } from './radarPro.js';
import { newsRisk } from './synthesis.js';
import { assetOf } from '../config/eliteMarkets.js';

export const ELITE_ENGINE_VERSION = 'elite-2.0 (v247)';
export const ELITE_STRATEGIES = STRATEGIES.filter((s) => s.status === 'live').map((s) => s.id);   // smc · trend · mean_reversion
export const ELITE_TFS = ['15m', '1h', '4h'];
export const STYLE_OF = { '1m': 'scalp', '5m': 'scalp', '15m': 'scalp', '1h': 'swing', '4h': 'swing', '1D': 'swing' };
export const TF_SEC = { '1m': 60, '5m': 300, '15m': 900, '1h': 3600, '4h': 14400, '1D': 86400 };
export const LIVE_STATUSES = ['active', 'entry_hit', 'tp1', 'tp2'];
export const FINAL_STATUSES = ['tp3', 'sl', 'expired', 'cancelled'];
export const STATUSES = [...LIVE_STATUSES, ...FINAL_STATUSES];

// Practical entries: a pending (limit) entry further than this from the live price is not published. Per market category and
// trading style, in ATR of the signal's timeframe AND in % of price (both must hold), scaled per strategy (a trend pullback to
// EMA 20 must be closer than an SMC zone or a Bollinger band). Much tighter than the AI page's own ceiling (EXEC.limitMax*),
// so a swing signal never waits days for a far-away level.
export const ELITE_ENTRY = {
  limit: {
    index: { scalp: { atr: 0.8, pct: 0.3 }, swing: { atr: 1.2, pct: 0.8 } },
    metal: { scalp: { atr: 0.8, pct: 0.35 }, swing: { atr: 1.2, pct: 1 } },
    commodity: { scalp: { atr: 0.8, pct: 0.6 }, swing: { atr: 1.2, pct: 1.5 } },
    bitcoin: { scalp: { atr: 0.8, pct: 0.8 }, swing: { atr: 1.2, pct: 2 } },
  },
  strategyFactor: { smc: 1, trend: 0.75, mean_reversion: 1 },
  maxPendingHours: { scalp: 4, swing: 24 },   // an unfilled limit expires after this (or earlier: the AI page's own expiry)
  maxHoldHours: { scalp: 24, swing: 120 },    // an entered trade with no stop / TP3 after this is closed as expired
};

const r8 = (v) => (Number.isFinite(v) ? Math.round(v * 1e8) / 1e8 : v);
const roundTo = (v, prec) => (Number.isFinite(v) ? Number(v.toFixed(Math.min(8, Math.max(0, prec ?? 2)))) : v);
const stratDef = (id) => STRATEGIES.find((s) => s.id === id) || null;

/** Distance limit of a limit entry for this market / style / strategy → { atr, pct }. */
export function limitCap(cat, style, strategy) {
  const c = ELITE_ENTRY.limit[cat]?.[style] || ELITE_ENTRY.limit.index[style] || ELITE_ENTRY.limit.index.scalp;
  const f = ELITE_ENTRY.strategyFactor[strategy] ?? 1;
  return { atr: Math.round(c.atr * f * 100) / 100, pct: Math.round(c.pct * f * 1000) / 1000 };
}

/** Is a pending entry practical? → { ok, reason, dist, cap } (never moves the level). */
export function practicalLimit({ entry, price, atr, cat, style, strategy, pointSize = 0 }) {
  const dist = distanceOf(entry, price, atr, pointSize); const cap = limitCap(cat, style, strategy);
  if (dist.atr != null && dist.atr > cap.atr) return { ok: false, reason: 'too_far_atr', dist, cap };
  if (dist.pct != null && dist.pct > cap.pct) return { ok: false, reason: 'too_far_pct', dist, cap };
  return { ok: true, reason: null, dist, cap };
}

/** Every level of a signal is usable: finite, stop on the losing side, three targets in order on the winning side. */
export function levelsValid({ direction, entry, stop, targets }) {
  if (![entry, stop].every(Number.isFinite) || !Array.isArray(targets) || targets.length !== 3 || !targets.every(Number.isFinite)) return false;
  const sg = direction === 'long' ? 1 : direction === 'short' ? -1 : 0; if (!sg) return false;
  if ((entry - stop) * sg <= 0) return false;
  let prev = entry; for (const t of targets) { if ((t - prev) * sg <= 0) return false; prev = t; }
  return true;
}

export const setupKey = (s) => `${s.symbol}|${s.strategy}|${s.direction}`;
/** Same market, strategy and direction still live, or the same setup (entry within 0.25 ATR) seen in the last day → duplicate. */
export function isEliteDuplicate(signals, cand, atr, nowMs = Date.now()) {
  const tol = Number.isFinite(atr) && atr > 0 ? 0.25 * atr : Math.abs(cand.entry) * 0.0005;
  return (signals || []).some((x) => x && setupKey(x) === setupKey(cand) && (LIVE_STATUSES.includes(x.status) || (nowMs - (x.createdAt || 0) < 86_400_000 && Math.abs(x.entry - cand.entry) <= tol)));
}

/** The strategy's own conditions that passed, as reasons (bilingual). */
function reasonsOf(st) {
  return (st?.checks || []).filter((c) => c.status === 'pass').map((c) => ({ ar: c.label?.ar || c.id, en: c.label?.en || c.id, value: c.value || '' }));
}
function explanationOf({ strategy, tf, entryType, dist, nChecks }) {
  const d = stratDef(strategy); const name = d ? d.name : { ar: strategy, en: strategy };
  const how = entryType === 'market'
    ? { ar: 'الدخول على السعر الحالي لأنه شروط الاستراتيجية متحققة هلق.', en: 'Entry at the current price because the strategy\'s conditions are met now.' }
    : { ar: `الدخول بأمر معلّق عند مستوى الاستراتيجية (${dist?.atr ?? '—'} ATR عن السعر).`, en: `Entry with a pending order at the strategy's own level (${dist?.atr ?? '—'} ATR from price).` };
  return { ar: `${name.ar} على فريم ${tf}: تحققت كل شروطها (${nChecks}). ${how.ar} ${d?.logic?.[0] || ''}`.trim(), en: `${name.en} on ${tf}: all of its conditions are met (${nChecks}). ${how.en} ${d?.logic?.[1] || ''}`.trim() };
}

/**
 * One market × one timeframe.
 * in: { market (eliteMarkets entry), inst, tf, ds ({ mode, candles, source }), htf ({ h4, d1 } | null), calendar ({ events, at, stale } | null),
 *       quote ({ price, bid?, ask?, at } | null), nowMs, signals (existing Elite signals, for duplicates / conflicts), cfg (engine preset) }
 * → { state: 'ok'|'no_trade'|'unavailable'|'stale'|'closed'|'insufficient', reason, barTime, signals: [new], rejected: [{ strategy, reason }] }
 */
export function evaluateMarket({ market, inst, tf, ds, htf = null, calendar = null, quote = null, nowMs = Date.now(), signals = [], cfg = presetCfg('balanced'), run = runAllStrategies }) {
  const out = (state, reason, extra = {}) => ({ state, reason, barTime: null, signals: [], rejected: [], ...extra });
  if (!market || !inst) return out('unavailable', 'no_instrument');
  if (!ELITE_TFS.includes(tf) && !TF_SEC[tf]) return out('unavailable', 'timeframe');
  if (!ds || ds.mode !== 'live' || !Array.isArray(ds.candles)) return out('unavailable', ds?.mode === 'demo' ? 'demo_data' : 'no_data');
  const tfSec = TF_SEC[tf]; const style = STYLE_OF[tf] || 'swing'; const asset = assetOf(inst); const crypto = asset === 'crypto';
  const nowS = nowMs / 1000;
  const closed = ds.candles.filter((c) => c.time + tfSec <= nowS + 1);
  if (closed.length < 210) return out('insufficient', 'few_candles');
  const v = validateCandles(closed, tf, { crypto, now: nowMs });
  // the newest CLOSED candle may be up to one candle old by construction; anything older is a delayed or closed market
  const lastClose = closed.at(-1).time + tfSec; const ageSec = nowS - lastClose;
  if (v.state === 'bad') return out('unavailable', 'bad_data');
  if (ageSec > Math.max(2 * tfSec, 20 * 60) + 120) return out(v.state === 'closed' ? 'closed' : 'stale', v.state === 'closed' ? 'market_closed' : 'stale_data');
  const barTime = closed.at(-1).time;
  const quoteOk = quote && Number.isFinite(quote.price) && quote.price > 0 && (!Number.isFinite(quote.at) || nowMs - quote.at <= EXEC.quoteMaxAgeMs);
  const spreadPct = quoteOk && Number.isFinite(quote.bid) && Number.isFinite(quote.ask) && quote.ask >= quote.bid && quote.bid > 0 ? ((quote.ask - quote.bid) / ((quote.ask + quote.bid) / 2)) * 100 : null;
  const cost = costModel(asset, spreadPct);
  const news = calendar?.events ? newsRisk(inst.symbol, calendar.events, nowMs) : null;
  const reading = () => { try { return analyzeSmcIct(closed, { ...cleanInputs({ style, asset, execution: 'market', costPct: cost.totalPct }), symbol: inst.symbol, tfSec, htf, news, htfMode: 'tiered', poiMaxAtr: EXEC.limitMaxAtr[style] }); } catch { return null; } };
  let smcReading = null; const lazyReading = () => (smcReading ||= reading());
  const openBy = {}; for (const s of signals) if (s.symbol === inst.symbol && LIVE_STATUSES.includes(s.status)) openBy[s.strategy] = (openBy[s.strategy] || 0) + 1;
  const extra = extraGlobals({ validation: { ...v, n: closed.length }, open: [], riskPct: 0, asset });
  const multi = run({
    symbol: inst.symbol, inst, tf, tfSec, candles: closed, mode: 'live', htf, reading: lazyReading, calendar, peer: null, nowMs,
    spread: spreadPct != null ? { bidAskPct: spreadPct } : null, account: { openByStrategy: openBy },
  }, { ...cfg, ai: true, costPct: cost.totalPct, chaseMaxAtr: EXEC.chaseMaxAtr[style], extraGlobals: extra });
  const rejected = [];
  for (const st of multi.strategies || []) if (ELITE_STRATEGIES.includes(st.id) && st.status !== 'qualified') rejected.push({ strategy: st.id, reason: st.status || 'conditions' });
  if (!multi.trades?.length) {
    const g = (multi.globals || []).filter((x) => x.status !== 'pass').map((x) => x.id);
    return { ...out('no_trade', multi.reason || 'no_strategy'), barTime, rejected, globalsFailed: g };
  }
  const prep = prepare(closed, { htf, tfSec, asset, spreadPct });
  const atr = prep.S?.a?.[prep.S.i];
  const last = closed.at(-1);
  const made = [];
  for (const x of multi.trades) {
    if (!ELITE_STRATEGIES.includes(x.id)) continue;
    const isSmc = x.id === 'smc';
    const sr = isSmc ? lazyReading() : null;
    const base = isSmc ? { ...x.plan, sources: sr?.plan?.sources } : x.plan;
    const ex = executionPlan({ id: x.id, plan: base, engineExec: isSmc ? sr?.plan?.execution : null, want: 'market', style, asset, tf, tfSec, S: prep.S, atr, price: last.close,
      live: quoteOk ? quote : null, minRR: isSmc ? (STYLES[style]?.minRR ?? 0) : (multi.minRR || 0), costPct: cost.totalPct, createdAt: last.time, session24: crypto, nowMs });
    if (!ex.ok) { rejected.push({ strategy: x.id, reason: ex.reason || ex.state }); continue; }
    const pl = ex.plan; const entryType = pl.execution === 'limit' ? 'limit' : 'market';
    let dist = ex.exec?.dist || null;
    if (entryType === 'limit') {
      const pc = practicalLimit({ entry: pl.entry, price: quoteOk ? quote.price : last.close, atr, cat: market.cat, style, strategy: x.id, pointSize: inst.pointSize });
      if (!pc.ok) { rejected.push({ strategy: x.id, reason: pc.reason, dist: pc.dist, cap: pc.cap }); continue; }
      dist = pc.dist;
    }
    const prec = inst.precision ?? 2;
    const sig = {
      symbol: inst.symbol, market: market.id, category: market.cat, region: market.region || null, tf, style, strategy: x.id, direction: pl.direction,
      entryType, entry: roundTo(pl.entry, prec), stop: roundTo(pl.stop, prec), targets: pl.targets.slice(0, 3).map((t) => roundTo(t, prec)),
      rr: pl.rr, rrNet: pl.rrNet, rrMain: pl.rrMain, costR: pl.costR, precision: prec, pointSize: inst.pointSize,
    };
    if (!levelsValid(sig)) { rejected.push({ strategy: x.id, reason: 'levels' }); continue; }
    if (isEliteDuplicate([...signals, ...made], sig, atr, nowMs)) { rejected.push({ strategy: x.id, reason: 'duplicate' }); continue; }
    const createdAt = nowMs;
    const pendingCap = createdAt + ELITE_ENTRY.maxPendingHours[style] * 3600_000;
    const expiresAt = entryType === 'limit' ? Math.min(pendingCap, Number.isFinite(pl.validUntil) ? pl.validUntil * 1000 : pendingCap) : createdAt + ELITE_ENTRY.maxHoldHours[style] * 3600_000;
    const st = multi.strategies.find((s) => s.id === x.id);
    const reasons = reasonsOf(st);
    made.push({
      id: `elite|${inst.symbol}|${tf}|${x.id}|${barTime}`, ...sig, initialStop: sig.stop,
      status: entryType === 'market' ? 'entry_hit' : 'active', hits: 0, createdAt, barTime, expiresAt, filledAt: entryType === 'market' ? createdAt : null, closedAt: null,
      price: quoteOk ? quote.price : last.close, priceAt: quoteOk ? (quote.at || nowMs) : null, source: ds.source || null,
      reasons, explanation: explanationOf({ strategy: x.id, tf, entryType, dist, nChecks: reasons.length }), dist,
      quality: x.plan.quality ?? null, conflict: false, engine: ELITE_ENGINE_VERSION,
    });
  }
  markConflicts([...signals, ...made]);
  return { state: made.length ? 'ok' : 'no_trade', reason: made.length ? null : 'execution', barTime, signals: made, rejected };
}

/** Live signals of one market pointing in opposite directions are both kept and flagged (mutates `conflict`). */
export function markConflicts(signals) {
  const live = (signals || []).filter((s) => LIVE_STATUSES.includes(s.status));
  for (const s of live) s.conflict = live.some((o) => o !== s && o.symbol === s.symbol && o.direction !== s.direction);
  for (const s of signals || []) if (!LIVE_STATUSES.includes(s.status) && s.conflict == null) s.conflict = false;
  return signals;
}

/**
 * Follows one signal on candles that closed AFTER `s.checkedTo` (ms; default its creation) — 1-minute candles normally.
 * Conservative when a candle touches both a stop and a target: the stop counts first. After TP1 the stop moves to the entry
 * (the platform's existing management: a third at each target, stop to entry after TP1).
 * Returns the same object, updated: status, hits, stop, filledAt, closedAt, closeReason, price, checkedTo.
 */
export function trackSignal(s, candles, { nowMs = Date.now(), barSec = 60, price = null, priceAt = null } = {}) {
  if (!s || FINAL_STATUSES.includes(s.status)) return s;
  const sg = s.direction === 'long' ? 1 : -1;
  const from = Number.isFinite(s.checkedTo) ? s.checkedTo : s.createdAt;
  const close = (status, at, why) => { s.status = status; s.closedAt = at; s.closeReason = why; };
  for (const c of (candles || []).filter((k) => Number.isFinite(k.time) && k.time * 1000 >= from - barSec * 1000 && k.time * 1000 + barSec * 1000 <= nowMs + 1000)) {
    const at = (c.time + barSec) * 1000; if (at <= from) continue;
    const hi = c.high, lo = c.low; const touch = (lvl) => (sg > 0 ? hi >= lvl : lo <= lvl); const back = (lvl) => (sg > 0 ? lo <= lvl : hi >= lvl);
    if (s.status === 'active') {   // pending limit, not filled yet
      if (s.expiresAt && at > s.expiresAt) { close('expired', s.expiresAt, 'not_filled'); break; }
      if (back(s.entry)) {
        s.status = 'entry_hit'; s.filledAt = at; s.expiresAt = s.filledAt + ELITE_ENTRY.maxHoldHours[s.style || 'swing'] * 3600_000;
        if (back(s.stop)) { close('sl', at, 'stop'); break; }   // filled and stopped in the same candle: counted as a loss
        continue;
      }
      if (touch(s.targets[0])) { close('cancelled', at, 'tp1_before_entry'); break; }   // the move left without the entry
      if (back(s.stop)) { close('cancelled', at, 'invalidated'); break; }
      continue;
    }
    // entered: stop first (conservative), then the next targets in order
    if (back(s.stop)) { close('sl', at, s.hits > 0 ? 'stop_at_entry' : 'stop'); break; }
    while (s.hits < 3 && touch(s.targets[s.hits])) {
      s.hits += 1; s.status = `tp${s.hits}`;
      if (s.hits === 1) s.stop = s.entry;   // stop to entry after TP1
    }
    if (s.hits >= 3) { s.closedAt = at; s.closeReason = 'tp3'; break; }
    if (s.expiresAt && at > s.expiresAt) { close('expired', s.expiresAt, 'max_hold'); break; }
  }
  if (!FINAL_STATUSES.includes(s.status) && s.expiresAt && nowMs > s.expiresAt + barSec * 1000 * 2) close('expired', s.expiresAt, s.status === 'active' ? 'not_filled' : 'max_hold');
  const lastC = (candles || []).at(-1);
  s.checkedTo = Math.max(from, Math.min(nowMs, lastC ? (lastC.time + barSec) * 1000 : from));
  if (Number.isFinite(price)) { s.price = price; s.priceAt = priceAt || nowMs; } else if (lastC && Number.isFinite(lastC.close)) { s.price = lastC.close; s.priceAt = (lastC.time + barSec) * 1000; }
  return s;
}

/** Counts for the header (no win-rate claim beyond what happened: share of closed signals that reached TP1). */
export function eliteSummary(signals) {
  const all = signals || []; const closed = all.filter((s) => FINAL_STATUSES.includes(s.status));
  const entered = closed.filter((s) => Number.isFinite(s.filledAt));
  const reached = entered.filter((s) => (s.hits || 0) > 0).length;
  return { total: all.length, open: all.filter((s) => LIVE_STATUSES.includes(s.status)).length, closed: closed.length, entered: entered.length, tp1Rate: entered.length ? Math.round((reached / entered.length) * 100) : null,
    byStrategy: Object.fromEntries(ELITE_STRATEGIES.map((id) => [id, all.filter((s) => s.strategy === id).length])) };
}

/** The card component's status words (sig.status.*) for an Elite status. */
export const cardStatus = (st) => ({ active: 'pending', entry_hit: 'active', tp1: 'active', tp2: 'active', tp3: 'tp3', sl: 'sl', expired: 'expired', cancelled: 'cancelled' })[st] || st;
export { r8 };
