// Institutional-style helpers used by the zone strategy and the risk layer. Pure functions, no look-ahead:
// every value at index i uses candles <= i only.
//
//  • Order flow: per-candle delta and Cumulative Volume Delta (CVD) from the exchange's taker-buy volume
//    (`buyVolume`; Binance klines carry it — other feeds do not, then everything here reports "n/a").
//  • Z-score of price against its 50-candle mean (statistical over-extension for reversal entries).
//  • Market regime: trending / ranging / spike, with score-weight multipliers per regime.
//  • ATR trailing stop and rolling return correlation.

/* ───────── Order flow ───────── */
/** Aggressive-buy minus aggressive-sell volume of one candle (null when the feed has no taker split). */
export function candleDelta(c) {
  if (!Number.isFinite(c.buyVolume) || !(c.volume > 0)) return null;
  return 2 * c.buyVolume - c.volume;
}

export function hasFlow(candles) {
  let n = 0;
  for (let i = Math.max(0, candles.length - 50); i < candles.length; i++) if (candleDelta(candles[i]) != null) n++;
  return n >= 20;
}

/** Cumulative delta series (a candle without a split adds 0). */
export function cvdSeries(candles) {
  const out = new Array(candles.length);
  let acc = 0;
  for (let i = 0; i < candles.length; i++) { acc += candleDelta(candles[i]) ?? 0; out[i] = acc; }
  return out;
}

/**
 * Reads the order flow on candle `i` for a trade in direction `dir`:
 *  - absorption: the other side sold (bought) aggressively but price closed on the right side of the candle;
 *  - cvdDiv: price printed a new 12-candle extreme while CVD did not (hidden accumulation / distribution);
 *  - imbalance: one candle with |delta| >= 45% of its volume in our direction (stacked = 2 of the last 3).
 * Returns { ok, points (0..15), kinds[] } or { ok:false } when the feed has no taker split.
 */
export function flowRead(candles, cvd, i, dir) {
  const k = candles[i];
  const d = candleDelta(k);
  if (d == null || i < 15) return { ok: false, points: 0, kinds: [] };
  const long = dir === 'long';
  const range = k.high - k.low;
  const ratio = d / k.volume; // -1..+1
  const kinds = [];
  // absorption: against-side delta, yet the close sits in the favourable half of the range
  const closePos = range > 0 ? (k.close - k.low) / range : 0.5;
  if (long ? ratio <= -0.2 && closePos >= 0.55 : ratio >= 0.2 && closePos <= 0.45) kinds.push('absorb');
  // CVD divergence against the last 12 candles
  let lo = Infinity; let hi = -Infinity; let cLo = Infinity; let cHi = -Infinity;
  for (let j = i - 12; j < i; j++) { lo = Math.min(lo, candles[j].low); hi = Math.max(hi, candles[j].high); cLo = Math.min(cLo, cvd[j]); cHi = Math.max(cHi, cvd[j]); }
  if (long ? k.low <= lo && cvd[i] > cLo : k.high >= hi && cvd[i] < cHi) kinds.push('cvdDiv');
  // imbalance in our direction
  const dirRatio = long ? ratio : -ratio;
  let stacked = 0;
  for (let j = i - 2; j <= i; j++) {
    const dj = candleDelta(candles[j]);
    if (dj != null && (long ? dj : -dj) / candles[j].volume >= 0.3) stacked++;
  }
  if (dirRatio >= 0.45) kinds.push('imbalance');
  if (stacked >= 2) kinds.push('stacked');
  const points = (kinds.includes('absorb') || kinds.includes('cvdDiv') ? 8 : 0)
    + (kinds.includes('stacked') ? 7 : kinds.includes('imbalance') ? 4 : 0);
  return { ok: true, points: Math.min(15, points), kinds, ratio };
}

/* ───────── Z-score ───────── */
/** Z-score of each close against its trailing `n`-candle mean / standard deviation (null while warming up). */
export function zScoreSeries(closes, n = 50) {
  const out = new Array(closes.length).fill(null);
  let s = 0; let s2 = 0;
  for (let i = 0; i < closes.length; i++) {
    s += closes[i]; s2 += closes[i] * closes[i];
    if (i >= n) { s -= closes[i - n]; s2 -= closes[i - n] * closes[i - n]; }
    if (i >= n - 1) {
      const m = s / n; const v = Math.max(0, s2 / n - m * m); const sd = Math.sqrt(v);
      out[i] = sd > 0 ? (closes[i] - m) / sd : 0;
    }
  }
  return out;
}

/** Points (0..10) for a reversal: the more stretched against our direction, the better. */
export function zPoints(z, dir) {
  if (z == null) return 0;
  const s = dir === 'long' ? -z : z; // positive = stretched against the trade (so we fade it)
  return s >= 2 ? 10 : s >= 1.5 ? 8 : s >= 1 ? 6 : s >= 0.5 ? 3 : 0;
}

/* ───────── Regime ───────── */
/** Kaufman efficiency ratio over `n` candles: 1 = straight line, 0 = pure noise. */
export function efficiency(closes, i, n = 20) {
  if (i < n) return null;
  let path = 0;
  for (let j = i - n + 1; j <= i; j++) path += Math.abs(closes[j] - closes[j - 1]);
  return path > 0 ? Math.abs(closes[i] - closes[i - n]) / path : 0;
}

/**
 * 'spike' (ATR in its top 10% of the last 200 candles, or the candle is >= 3x ATR),
 * 'trend' (efficiency >= 0.35), 'range' (efficiency <= 0.2), otherwise 'mixed'.
 */
export function classifyRegime(candles, atrArr, closes, i) {
  const a = atrArr[i];
  if (!(a > 0) || i < 60) return 'mixed';
  const k = candles[i];
  let below = 0; let n = 0;
  for (let j = Math.max(14, i - 200); j <= i; j++) { if (atrArr[j] > 0) { n++; if (atrArr[j] < a) below++; } }
  if ((k.high - k.low) >= 3 * a || (n >= 50 && below / n >= 0.9)) return 'spike';
  const er = efficiency(closes, i, 20);
  if (er == null) return 'mixed';
  return er >= 0.35 ? 'trend' : er <= 0.2 ? 'range' : 'mixed';
}

/**
 * Score-weight multipliers per regime. In a trend the order flow and the zone matter more and
 * mean-reversion (z-score) counts less; in a range the profile and z-score matter more; in a spike
 * everything is dampened and the caller raises the minimum score.
 */
export const REGIME_MULT = {
  trend: { zone: 1, vp: 1, fib: 1, rsi: 1, flow: 1.4, stat: 0.5 },
  range: { zone: 1.1, vp: 1.2, fib: 1, rsi: 1, flow: 1, stat: 1.5 },
  spike: { zone: 1, vp: 1, fib: 1, rsi: 1, flow: 1, stat: 0.5 },
  mixed: { zone: 1, vp: 1, fib: 1, rsi: 1, flow: 1, stat: 1 },
};
export const SPIKE_EXTRA_SCORE = 5;

/* ───────── ATR trailing stop ───────── */
/**
 * After target 1 (or an early breakeven) the stop follows the best price by `o.trailAtr` x ATR (never backwards).
 * Call once per candle after the hit / breakeven handling. Returns true when the same candle also reached the
 * new stop (the order inside a candle is unknown, so we assume the worst).
 */
export function trailUpdate(t, c, o) {
  if (!(o.trailAtr > 0)) return false;
  if (!(t.hits >= 1 || t.beMoved)) return false;
  const a = t.atrE > 0 ? t.atrE : t.risk / 1.5;
  const d = o.trailAtr * a;
  const long = t.direction === 'long';
  t.ext = long ? Math.max(t.ext ?? t.entry, c.high) : Math.min(t.ext ?? t.entry, c.low);
  const cand = long ? t.ext - d : t.ext + d;
  if (long ? cand > t.stop : cand < t.stop) {
    // never closer than the entry once we are in profit territory
    t.stop = cand; t.trailed = true;
    if (long ? c.low <= t.stop : c.high >= t.stop) return true;
  }
  return false;
}

/* ───────── Correlation ───────── */
/** Pearson correlation of the last `n` simple returns of two close series aligned by time (null if too short). */
export function returnCorrelation(a, b, n = 100) {
  const mapB = new Map(b.map((x) => [x.time, x.close]));
  const pa = []; const pb = [];
  for (const x of a) { const y = mapB.get(x.time); if (y != null) { pa.push(x.close); pb.push(y); } }
  const m = Math.min(pa.length, pb.length);
  if (m < 30) return null;
  const ra = []; const rb = [];
  for (let i = Math.max(1, m - n); i < m; i++) { ra.push(pa[i] / pa[i - 1] - 1); rb.push(pb[i] / pb[i - 1] - 1); }
  const mean = (x) => x.reduce((s, v) => s + v, 0) / x.length;
  const ma = mean(ra); const mb = mean(rb);
  let num = 0; let da = 0; let db = 0;
  for (let i = 0; i < ra.length; i++) { num += (ra[i] - ma) * (rb[i] - mb); da += (ra[i] - ma) ** 2; db += (rb[i] - mb) ** 2; }
  return da > 0 && db > 0 ? num / Math.sqrt(da * db) : null;
}

/**
 * Would `candidate` multiply exposure? Same direction with correlation >= limit, or the opposite direction with
 * correlation <= -limit, against any active signal on another symbol.
 */
export function correlatedExposure(candidate, active, corrOf, limit = 0.75) {
  for (const s of active) {
    if (s.symbol === candidate.symbol) continue;
    const r = corrOf(candidate.symbol, s.symbol);
    if (r == null) continue;
    const same = s.direction === candidate.direction;
    if ((same && r >= limit) || (!same && r <= -limit)) return { symbol: s.symbol, r };
  }
  return null;
}
