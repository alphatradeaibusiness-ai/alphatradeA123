// International phone numbers (v228): the country list (ISO code, dialling code, national number length) and a strict
// validator that returns the number in E.164 form (+9627XXXXXXXX). Pure: no DOM, no network — the sign-up form and the
// server (PUT /api/me/phone) use the same code, so the server never trusts the browser's check.
//
// Rules applied to every number:
//   • only digits after removing spaces, dashes, dots, brackets and a leading "+" / "00" international prefix;
//   • if the number itself starts with an international prefix it must match the chosen country's code;
//   • the national trunk "0" is removed where the country uses one (07 9123 4567 → 7 9123 4567);
//   • the national length must fit the country's range, and the whole number at most 15 digits (ITU-T E.164);
//   • stricter patterns for the countries where the format is unambiguous (North America, Israel, Palestine, Jordan, Saudi
//     Arabia, UAE, Egypt, UK, Germany, France, Turkey, India, …) and no number made of one repeated digit.
// Lengths are the national significant number (without trunk prefix) as published in the ITU-T E.164 national plans.

// ISO|dial|min|max  (one per country/territory; shared codes such as +1 and +7 repeat)
const RAW = `AF|93|9|9 AL|355|8|9 DZ|213|8|9 AS|1684|7|7 AD|376|6|9 AO|244|9|9 AI|1264|7|7 AG|1268|7|7 AR|54|10|11 AM|374|8|8
AW|297|7|7 AU|61|9|9 AT|43|4|13 AZ|994|9|9 BS|1242|7|7 BH|973|8|8 BD|880|10|10 BB|1246|7|7 BY|375|9|10 BE|32|8|9
BZ|501|7|7 BJ|229|8|10 BM|1441|7|7 BT|975|7|8 BO|591|8|8 BA|387|8|9 BW|267|7|8 BR|55|10|11 VG|1284|7|7 BN|673|7|7
BG|359|7|9 BF|226|8|8 BI|257|8|8 KH|855|8|9 CM|237|9|9 CA|1|10|10 CV|238|7|7 KY|1345|7|7 CF|236|8|8 TD|235|8|8
CL|56|9|9 CN|86|11|11 CO|57|10|10 KM|269|7|7 CG|242|9|9 CD|243|9|9 CK|682|5|5 CR|506|8|8 CI|225|10|10 HR|385|8|9
CU|53|8|8 CW|599|7|8 CY|357|8|8 CZ|420|9|9 DK|45|8|8 DJ|253|8|8 DM|1767|7|7 DO|1809|7|7 EC|593|8|9 EG|20|9|10
SV|503|8|8 GQ|240|9|9 ER|291|7|7 EE|372|7|8 SZ|268|8|8 ET|251|9|9 FK|500|5|5 FO|298|6|6 FJ|679|7|7 FI|358|6|11
FR|33|9|9 GF|594|9|9 PF|689|8|8 GA|241|7|8 GM|220|7|7 GE|995|9|9 DE|49|6|11 GH|233|9|9 GI|350|8|8 GR|30|10|10
GL|299|6|6 GD|1473|7|7 GP|590|9|9 GU|1671|7|7 GT|502|8|8 GG|44|10|10 GN|224|9|9 GW|245|9|9 GY|592|7|7 HT|509|8|8
HN|504|8|8 HK|852|8|8 HU|36|8|9 IS|354|7|9 IN|91|10|10 ID|62|9|12 IR|98|10|10 IQ|964|10|10 IE|353|7|9 IM|44|10|10
IL|972|8|9 IT|39|6|11 JM|1876|7|7 JP|81|9|10 JE|44|10|10 JO|962|8|9 KZ|7|10|10 KE|254|9|9 KI|686|5|8 XK|383|8|8
KW|965|8|8 KG|996|9|9 LA|856|8|10 LV|371|8|8 LB|961|7|8 LS|266|8|8 LR|231|7|9 LY|218|9|9 LI|423|7|9 LT|370|8|8
LU|352|4|11 MO|853|8|8 MG|261|9|9 MW|265|7|9 MY|60|9|10 MV|960|7|7 ML|223|8|8 MT|356|8|8 MH|692|7|7 MQ|596|9|9
MR|222|8|8 MU|230|7|8 YT|262|9|9 MX|52|10|10 FM|691|7|7 MD|373|8|8 MC|377|8|9 MN|976|8|8 ME|382|8|8 MS|1664|7|7
MA|212|9|9 MZ|258|8|9 MM|95|7|10 NA|264|8|9 NR|674|7|7 NP|977|8|10 NL|31|9|9 NC|687|6|6 NZ|64|8|10 NI|505|8|8
NE|227|8|8 NG|234|8|10 MK|389|8|8 MP|1670|7|7 NO|47|8|8 OM|968|8|8 PK|92|10|10 PW|680|7|7 PS|970|9|9 PA|507|7|8
PG|675|7|8 PY|595|9|9 PE|51|8|9 PH|63|8|10 PL|48|9|9 PT|351|9|9 PR|1787|7|7 QA|974|8|8 RE|262|9|9 RO|40|9|9
RU|7|10|10 RW|250|9|9 KN|1869|7|7 LC|1758|7|7 PM|508|6|6 VC|1784|7|7 WS|685|5|7 SM|378|6|10 ST|239|7|7 SA|966|9|9
SN|221|9|9 RS|381|8|9 SC|248|7|7 SL|232|8|8 SG|65|8|8 SX|1721|7|7 SK|421|9|9 SI|386|8|8 SB|677|5|7 SO|252|7|9
ZA|27|9|9 KR|82|8|10 SS|211|9|9 ES|34|9|9 LK|94|9|9 SD|249|9|9 SR|597|6|7 SE|46|7|10 CH|41|9|9 SY|963|9|9
TW|886|8|9 TJ|992|9|9 TZ|255|9|9 TH|66|8|9 TL|670|7|8 TG|228|8|8 TO|676|5|7 TT|1868|7|7 TN|216|8|8 TR|90|10|10
TM|993|8|8 TC|1649|7|7 TV|688|5|6 UG|256|9|9 UA|380|9|9 AE|971|8|9 GB|44|10|10 US|1|10|10 UY|598|8|8 UZ|998|9|9
VU|678|5|7 VA|39|6|11 VE|58|10|10 VN|84|9|10 VI|1340|7|7 YE|967|7|9 ZM|260|9|9 ZW|263|9|9`;

// Countries that dial a trunk "0" before national numbers (removed before checking the length).
const TRUNK0 = new Set('AF AL DZ AR AM AU AT AZ BD BY BE BA BW BR BG KH CM CN CO HR CY EG EE ET FI FR GF PF GE DE GH GP GG HU IN ID IR IQ IE IM IL JP JE JO KZ KE KR KW KG LA LB LY LT LU MK MG MW MY MQ MU YT MD MC MN ME MA MZ MM NA NP NL NZ NG PK PS PE PH PL PT RE RO RU RW SA RS SL SK SI SO ZA SS ES LK SD SE CH SY TW TJ TZ TH TN TR TM UG UA AE GB UZ VN YE ZM ZW'.split(' '));

// Stricter national patterns (whole national significant number), where the plan is unambiguous.
const NANP = /^[2-9]\d{2}[2-9]\d{6}$/;                    // North America: area and exchange codes never start with 0/1
const STRICT = {
  US: NANP, CA: NANP,
  IL: /^(?:5\d{8}|[23489]\d{7}|7\d{8})$/,                  // mobile 5X-XXXXXXX, landline 2/3/4/8/9 + 7 digits, 7X VoIP
  PS: /^(?:5[69]\d{7}|[2489]\d{7})$/,                      // mobile 59/56, landline
  JO: /^(?:7[789]\d{7}|[2356]\d{7})$/,                     // mobile 77/78/79
  SA: /^(?:5\d{8}|1\d{7})$/,
  AE: /^(?:5[0-8]\d{7}|[2-79]\d{7})$/,
  EG: /^(?:1[0125]\d{8}|[2-9]\d{7,8})$/,
  GB: /^(?:7\d{9}|[1-3]\d{9}|8\d{9})$/,
  DE: /^[1-9]\d{5,10}$/,
  FR: /^[1-9]\d{8}$/,
  TR: /^(?:5\d{9}|[2-4]\d{9}|8\d{9})$/,
  IN: /^[6-9]\d{9}$/,
  LB: /^(?:[3]\d{6}|(?:7[0169]|8[1-9])\d{6}|[14-9]\d{6})$/,
  IQ: /^7[3-9]\d{8}$/,
  KW: /^[2569]\d{7}$/,
  QA: /^[3-7]\d{7}$/,
  BH: /^[136]\d{7}$/,
  OM: /^[279]\d{7}$/,
  MA: /^[5-7]\d{8}$/,
  DZ: /^(?:[5-7]\d{8}|[2-4]\d{7})$/,
  TN: /^[2-9]\d{7}$/,
  CN: /^1[3-9]\d{9}$/,
  RU: /^[3-9]\d{9}$/, KZ: /^[67]\d{9}$/,
};

/** Emoji flag from a two-letter ISO code (shown as the letters on systems without flag emoji, e.g. Windows). */
export const flagOf = (iso) => String(iso).toUpperCase().replace(/[A-Z]/g, (c) => String.fromCodePoint(0x1f1a5 + c.charCodeAt(0)));

export const COUNTRIES = RAW.trim().split(/\s+/).map((row) => {
  const [iso, dial, min, max] = row.split('|');
  return Object.freeze({ iso, dial, min: Number(min), max: Number(max), trunk0: TRUNK0.has(iso), flag: flagOf(iso) });
});
const BY_ISO = new Map(COUNTRIES.map((c) => [c.iso, c]));
export const countryByIso = (iso) => BY_ISO.get(String(iso || '').toUpperCase()) || null;

/** Localised country name (Intl.DisplayNames), falling back to the ISO code. */
// One formatter per language (v230): building one per country (≈400 on the sign-up page) cost ~100 ms on a phone.
const namers = new Map();
export function countryName(iso, lang = 'en') {
  try {
    let n = namers.get(lang); if (!n) { n = new Intl.DisplayNames([lang, 'en'], { type: 'region' }); namers.set(lang, n); }
    return n.of(iso) || iso;
  } catch { return iso; }
}

/**
 * Validates `raw` for country `iso`. → { ok: true, e164, national, iso, dial } or { ok: false, error }
 * error ∈ required · country · chars · prefix · short · long · format
 */
export function validatePhone(raw, iso) {
  const c = countryByIso(iso);
  if (!c) return { ok: false, error: 'country' };
  const s = String(raw ?? '').normalize('NFKC').trim();
  if (!s) return { ok: false, error: 'required' };
  if (s.length > 32) return { ok: false, error: 'long' };
  if (/[^\d\s().+\-]/.test(s)) return { ok: false, error: 'chars' };          // letters, symbols, invisible characters…
  if (s.indexOf('+') > 0 || (s.match(/\+/g) || []).length > 1) return { ok: false, error: 'chars' };
  let d = s.replace(/[\s().\-]/g, '');
  let international = false;
  if (d.startsWith('+')) { d = d.slice(1); international = true; }
  else if (d.startsWith('00')) { d = d.slice(2); international = true; }
  if (!/^\d+$/.test(d)) return { ok: false, error: 'chars' };
  if (international) {
    if (!d.startsWith(c.dial)) return { ok: false, error: 'prefix' };          // e.g. +44… typed while Jordan is selected
    d = d.slice(c.dial.length);
  } else if (c.dial.length > 1 && c.dial.startsWith('1') && d.length === c.min + 3 && d.startsWith(c.dial.slice(1))) {
    d = d.slice(c.dial.length - 1);                                             // Caribbean +1 XXX: area code typed with the number
  } else if (c.dial === '1' && d.length === 11 && d.startsWith('1')) {
    d = d.slice(1);                                                             // North America: leading 1 typed
  } else if (d.length > c.max && d.startsWith(c.dial) && d.length - c.dial.length >= c.min && d.length - c.dial.length <= c.max) {
    d = d.slice(c.dial.length);                                                 // country code typed without "+" (962 7…)
  }
  if (c.trunk0 && d.startsWith('0') && !(c.iso === 'IT' || c.iso === 'VA')) d = d.slice(1);   // Italy keeps its leading 0
  if (d.length < c.min) return { ok: false, error: 'short' };
  if (d.length > c.max || c.dial.length + d.length > 15) return { ok: false, error: 'long' };
  if (/^(\d)\1+$/.test(d)) return { ok: false, error: 'format' };
  const strict = STRICT[c.iso];
  if (strict && !strict.test(d)) return { ok: false, error: 'format' };
  if (!strict && /^0/.test(d) && c.iso !== 'IT' && c.iso !== 'VA') return { ok: false, error: 'format' };
  return { ok: true, e164: `+${c.dial}${d}`, national: d, iso: c.iso, dial: c.dial };
}

/** Re-checks an E.164 number with its country (server side): accepts only "+<dial><national>" that validates exactly. */
export function checkE164(e164, iso) {
  if (typeof e164 !== 'string' || !/^\+\d{6,15}$/.test(e164)) return { ok: false, error: 'format' };
  const r = validatePhone(e164, iso);
  return r.ok && r.e164 === e164 ? r : { ok: false, error: r.error || 'format' };
}

/** Best guess of the visitor's country from the browser language (e.g. "ar-JO" → JO), or null. */
export function guessCountry(langs = (typeof navigator !== 'undefined' && navigator.languages) || []) {
  for (const l of langs) { const m = /-([A-Z]{2})\b/i.exec(String(l)); if (m && countryByIso(m[1])) return m[1].toUpperCase(); }
  return null;
}
