// «توصية AI» (v234) — what the page keeps for its performance dashboard, each source separate and never mixed:
//  • paper: signals of the PAPER strategies, followed on real candles (never shown as a recommendation, never sent to MT5);
//  • decisions: the last analyses with their final result and the filters / reasons behind a NO TRADE;
//  • backtests: the last back-test runs, with their period, candles, costs and data source.
// Live results are the user's saved signals (services/assistTrades.js). Everything here stays on this device.
import { storage } from '../utils/storage.js';
import { auth } from './auth/index.js';
import { trackTrade } from './smcAssist.js';

const uid = () => auth.current()?.uid || 'guest';
const K = { paper: () => `ai-paper:${uid()}`, dec: () => `ai-decisions:${uid()}`, bt: () => `ai-bt:${uid()}` };
const list = (k) => { const v = storage.get(k, []); return Array.isArray(v) ? v : []; };
const CLOSED = ['done', 'stopped', 'breakeven'];

export const paperList = () => list(K.paper());
/** Records the PAPER signals of one analysis once each (same strategy + market + timeframe + candle → one record). */
export function recordPaper(items, { symbol, tf, style, barTime, costPct = 0 }) {
  if (!items?.length) return 0;
  const all = paperList(); const have = new Set(all.map((x) => x.id)); let n = 0;
  for (const it of items) {
    const s = it.signal; if (!s) continue;
    const id = `${it.id}|${symbol}|${tf}|${barTime}`; if (have.has(id)) continue;
    const risk = Math.abs(s.entry - s.stop); if (!(risk > 0)) continue;
    all.unshift({ id, strategy: it.id, symbol, tf, style, direction: s.direction, execution: 'market', entry: s.entry, stop: s.stop, targets: s.targets, rr: s.targets.map((t) => Math.round((Math.abs(t - s.entry) / risk) * 100) / 100),
      costR: Math.round((((s.entry * costPct) / 100) / risk) * 1000) / 1000, createdAt: barTime, status: 'active', hits: 0, resultR: null, closedAt: null, why: String(s.why || '').slice(0, 60) });
    n++;
  }
  storage.set(K.paper(), all.slice(0, 400));
  return n;
}
/** Follows open paper signals of this market / timeframe on real (closed) candles. */
export function refreshPaper(symbol, tf, candles, mode) {
  if (mode !== 'live' || !candles?.length) return 0;
  const all = paperList(); let n = 0;
  for (const x of all) {
    if (x.symbol !== symbol || x.tf !== tf || CLOSED.includes(x.status) || x.status === 'expired') continue;
    if (candles[0].time > x.createdAt) continue;
    const r = trackTrade(x, candles);
    if (r.status !== x.status || r.hits !== x.hits) { Object.assign(x, { status: r.status, hits: r.hits, closedAt: r.closedAt, resultR: r.resultR }); n++; }
  }
  if (n) storage.set(K.paper(), all);
  return n;
}

export const decisions = () => list(K.dec());
export function recordDecision(d) { storage.set(K.dec(), [{ at: Date.now(), ...d }, ...decisions()].slice(0, 30)); }

export const backtests = () => list(K.bt());
export function saveBacktest(res) {
  // keep the summary only (no trade lists) so the storage stays small
  const slim = { ...res, strategies: Object.fromEntries(Object.entries(res.strategies || {}).map(([k, v]) => [k, v.unavailable ? v : { all: v.all, train: v.train, validation: v.validation, test: v.test, windows: v.windows, positiveShare: v.positiveShare, meetsLive: v.meetsLive, fails: v.fails, engine: v.engine }])),
    baseline: res.baseline ? { all: res.baseline.all, test: res.baseline.test } : null };
  storage.set(K.bt(), [slim, ...backtests().filter((x) => !(x.symbol === res.symbol && x.tf === res.tf))].slice(0, 8));
  return slim;
}

/** Statistics of a list of closed results in R (wins / losses / breakeven, win rate with sample size, avg R, PF, max DD). */
export function rStats(rs) {
  const n = rs.length; if (!n) return { n: 0 };
  let eq = 0, peak = 0, dd = 0; for (const r of rs) { eq += r; peak = Math.max(peak, eq); dd = Math.max(dd, peak - eq); }
  const wins = rs.filter((r) => r > 0.02).length, losses = rs.filter((r) => r < -0.02).length;
  const gain = rs.filter((r) => r > 0).reduce((s, r) => s + r, 0), loss = -rs.filter((r) => r < 0).reduce((s, r) => s + r, 0);
  const k = (v) => Math.round(v * 1000) / 1000;
  return { n, wins, losses, be: n - wins - losses, winRate: k(wins / n), avgR: k(eq / n), totalR: k(eq), profitFactor: loss > 0 ? k(gain / loss) : null, maxDD: k(dd) };
}
/** Closed results grouped by a key. */
export function groupStats(items, keyOf) {
  const m = new Map(); for (const x of items) { const k = keyOf(x); if (!m.has(k)) m.set(k, []); m.get(k).push(x.resultR); }
  return [...m].map(([key, rs]) => ({ key, ...rStats(rs) })).sort((a, b) => b.n - a.n);
}
export const isClosed = (x) => CLOSED.includes(x.status) && Number.isFinite(x.resultR);
