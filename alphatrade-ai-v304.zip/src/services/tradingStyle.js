// v249: the user's trading style, chosen in the profile (scalp | swing). «توصية AI» follows ONLY this choice: its style step,
// timeframes, analysis and automatic watch all use it. Kept per account in this browser (like the language and the photo).
import { storage } from '../utils/storage.js';
import { auth } from './auth/index.js';

export const TRADING_STYLES = ['scalp', 'swing'];
const key = () => `trading-style:${auth.current()?.uid || auth.current()?.email || 'guest'}`;
const listeners = new Set();
/** 'scalp' | 'swing' | null (not chosen yet). */
export const getTradingStyle = () => { const v = storage.get(key(), null); return TRADING_STYLES.includes(v) ? v : null; };
export function setTradingStyle(v) {
  if (v != null && !TRADING_STYLES.includes(v)) return false;
  if (v) storage.set(key(), v); else storage.remove(key());
  listeners.forEach((fn) => { try { fn(v || null); } catch { /* a view error never breaks the others */ } });
  return true;
}
export const onTradingStyle = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
