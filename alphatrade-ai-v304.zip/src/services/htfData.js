// 4h and Daily candles for the SMC v2 higher-timeframe filter. The chart itself only holds 500
// candles, which on 1m / 5m / 15m is far less than one day, so the real 4h and Daily candles are
// loaded separately (Binance up to 1000 per request; Twelve Data one request each, cached 10 min).
import { getHistory } from './market/index.js';

const cache = new Map(); // symbol -> { ts, h4, d1 }
const pending = new Map();
const TTL = 10 * 60_000;

/** What is loaded for this symbol (sync). */
export function htfCandles(symbol) {
  const h = cache.get(symbol);
  return h ? { h4: h.h4, d1: h.d1 } : null;
}
export const htfSignature = (h) => (h ? `${h.h4?.length}|${h.h4?.at(-1)?.time}|${h.d1?.length}|${h.d1?.at(-1)?.time}` : 'none');

/** Loads the frames above `tfSec`. Resolves true when new data arrived. */
export async function prefetchHtf(symbol, tfSec) {
  if (tfSec >= 86400) return false;
  const h = cache.get(symbol);
  if (h && Date.now() - h.ts < TTL) return false;
  if (pending.has(symbol)) return pending.get(symbol);
  const job = (async () => {
    const [h4, d1] = await Promise.all([getHistory(symbol, '4h', 600), getHistory(symbol, '1D', 400)]);
    if (h4.mode !== 'live' || d1.mode !== 'live') return false; // never build a signal filter from demo data
    cache.set(symbol, { ts: Date.now(), h4: h4.candles, d1: d1.candles });
    return true;
  })().catch(() => false).finally(() => pending.delete(symbol));
  pending.set(symbol, job);
  return job;
}
