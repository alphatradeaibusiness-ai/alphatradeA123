// «توصية AI» (v234) — the page's execution layer on top of the multi-strategy engine (services/multiStrategy.js):
// Market vs Limit for every strategy and both styles, realistic pending-order distance, expiry bound to timeframe /
// volatility / distance / session, costs after spread + commission + slippage, extra safety filters, duplicate check.
// Pure functions (no DOM, no network) so every rule is tested in node. It never invents a level: every price comes from the
// strategy's own plan, the candles or the live quote passed in.
import { snapshot, makeCheck } from './multiStrategy.js';
import { limitCheck, chaseCheck, orderExpiry, costModel, distanceOf, RISK, EXEC } from '../config/aiSignalRules.js';

const r2 = (v) => Math.round(v * 100) / 100;
const r8 = (v) => (Number.isFinite(v) ? Math.round(v * 1e8) / 1e8 : v);
const PASS = 'pass', FAIL = 'fail', NA = 'unavailable';

/** R:R of every target from `entry`, gross and after a round-trip cost of `costPct` % of price. */
export function rrOf(entry, stop, targets, costPct = 0) {
  const risk = Math.abs(entry - stop);
  if (!(risk > 0)) return null;
  const rr = targets.map((t) => r2(Math.abs(t - entry) / risk));
  const costR = Math.round((((entry * costPct) / 100) / risk) * 1000) / 1000;
  return { risk, rr, rrNet: rr.map((v) => r2(v - costR)), costR };
}

/**
 * The strategy's own pending-order level (never moved towards the price to look "faster"):
 *  trend → the EMA 20 pullback zone; mean reversion → the band it is reverting from; SMC → the engine's zone entry.
 * Returns null when the strategy has no logical resting level right now.
 */
export function limitLevel(id, S, plan) {
  if (!S || !plan) return null;
  const i = S.i; const long = plan.direction === 'long';
  if (id === 'trend') { const v = S.e20[i]; return Number.isFinite(v) ? v : null; }
  if (id === 'mean_reversion') { const v = long ? (S.bb.lower?.[i] ?? S.bb[i]?.lower) : (S.bb.upper?.[i] ?? S.bb[i]?.upper); return Number.isFinite(v) ? v : null; }
  return null;
}

/**
 * Final execution of one qualified trade.
 * in: { id, plan (strategy plan), engineExec ('market'|'limit' for SMC), want ('market'|'limit'), style, asset, tf, tfSec,
 *       S (snapshot), atr, price (last close), live ({ price, bid, ask, at } | null), minRR, costPct, createdAt, session24, nowMs }
 * out: { ok, state: 'trade'|'wait'|'no_trade', reason, plan?, exec? } — exec explains the choice for the card and the AI.
 */
export function executionPlan(x) {
  const { id, plan, want = 'limit', style = 'scalp', asset = 'crypto', tf, tfSec = 900, S, atr: a, price, live, minRR = 0, costPct = 0, createdAt, session24 = false, nowMs = Date.now() } = x;
  if (!plan) return { ok: false, state: 'no_trade', reason: 'no_plan' };
  const long = plan.direction === 'long'; const sg = long ? 1 : -1;
  const quoteOk = live && Number.isFinite(live.price) && live.price > 0 && (!Number.isFinite(live.at) || nowMs - live.at <= 120_000);
  // the price a market order really pays: the ask for a buy, the bid for a sell (when the feed has them), else the last price
  const fillPx = quoteOk ? (long ? (Number.isFinite(live.ask) ? live.ask : live.price) : (Number.isFinite(live.bid) ? live.bid : live.price)) : null;
  const ref = fillPx ?? price;
  const base = { strategy: id, direction: plan.direction, stop: plan.stop, sources: plan.sources || plan.targets.map((_, k) => `TP${k + 1}`) };
  const rrMainOf = (rrNet) => {
    if (id === 'smc' && Array.isArray(plan.sources)) { const k = plan.sources.map((s, j) => (/R$/.test(String(s)) ? -1 : j)).filter((j) => j >= 0).at(-1); return rrNet[k ?? Math.min(1, rrNet.length - 1)]; }
    return rrNet[Math.min(1, rrNet.length - 1)];
  };
  const tryLimit = () => {
    // SMC: the engine's own zone entry; trend / mean reversion: their resting level, with the same stop
    const level = id === 'smc' ? (x.engineExec === 'limit' ? plan.entry : null) : limitLevel(id, S, plan);
    if (!Number.isFinite(level)) return { ok: false, reason: 'no_level' };
    const chk = limitCheck({ entry: level, price: ref, atr: a, style, asset, direction: plan.direction });
    if (!chk.ok) return { ok: false, reason: chk.reason, dist: chk.dist, limits: { atr: chk.maxAtr, pct: chk.maxPct } };
    const stop = plan.stop;
    if ((level - stop) * sg < (id === 'mean_reversion' ? 0.3 : 0.4) * a) return { ok: false, reason: 'stop_too_close' };
    // trend keeps its R-based targets from the new entry; the others keep their structural targets
    const targets = id === 'trend' ? [1.5, 2, 3].map((k) => level + sg * k * Math.abs(level - stop)) : plan.targets;
    if (!targets.every((t) => (t - level) * sg > 0)) return { ok: false, reason: 'target_behind' };
    const q = rrOf(level, stop, targets, costPct);
    const rrMain = rrMainOf(q.rrNet);
    if (!(rrMain >= minRR)) return { ok: false, reason: 'rr_low', rrMain };
    const exp = orderExpiry({ tf, style, distAtr: chk.dist.atr, createdAt, session24 });
    return { ok: true, plan: { ...base, execution: 'limit', entry: r8(level), targets: targets.map(r8), rr: q.rr, rrNet: q.rrNet, rrMain, costR: q.costR, risk: r8(q.risk), validUntil: exp.validUntil, createdAt },
      exec: { type: 'limit', why: id === 'smc' ? 'zone' : id === 'trend' ? 'ema20' : 'band', dist: chk.dist, expiry: exp, limits: { atr: chk.maxAtr, pct: chk.maxPct } } };
  };
  const tryMarket = () => {
    if (!quoteOk) return { ok: false, reason: 'no_price' };
    const planEntry = id === 'smc' && x.engineExec === 'limit' ? null : plan.entry;
    if (planEntry != null) { const ch = chaseCheck({ planEntry, live: fillPx, atr: a, style }); if (!ch.ok) return { ok: false, reason: 'chase', dist: ch.dist, max: ch.max }; }
    if ((fillPx - plan.stop) * sg <= 0) return { ok: false, reason: 'past_stop' };
    if ((plan.targets[0] - fillPx) * sg <= 0) return { ok: false, reason: 'past_tp1' };
    const q = rrOf(fillPx, plan.stop, plan.targets, costPct);
    const rrMain = rrMainOf(q.rrNet);
    if (!(rrMain >= minRR)) return { ok: false, reason: 'rr_low', rrMain };
    return { ok: true, plan: { ...base, execution: 'market', entry: r8(fillPx), targets: plan.targets, rr: q.rr, rrNet: q.rrNet, rrMain, costR: q.costR, risk: r8(q.risk), validUntil: createdAt + 2 * tfSec, createdAt },
      exec: { type: 'market', why: 'in_zone', dist: distanceOf(fillPx, plan.entry, a), side: long ? 'ask' : 'bid', quote: { price: live.price, bid: live.bid ?? null, ask: live.ask ?? null } } };
  };
  // SMC that the engine itself left as a resting order cannot be "upgraded" to market just because price is close
  if (id === 'smc' && x.engineExec === 'limit' && want === 'market') {
    const l = tryLimit();
    return l.ok ? { ok: true, state: 'trade', ...l, note: 'smc_zone_limit' } : { ok: false, state: 'wait', reason: l.reason, dist: l.dist, limits: l.limits };
  }
  if (want === 'limit') {
    const l = tryLimit(); if (l.ok) return { ok: true, state: 'trade', ...l };
    // no realistic resting level: a market entry only when it is still valid now (re-checked, not assumed)
    const m = tryMarket(); if (m.ok) return { ok: true, state: 'trade', ...m, note: `limit_${l.reason}` };
    return { ok: false, state: l.reason === 'too_far_atr' || l.reason === 'too_far_pct' ? 'wait' : 'no_trade', reason: l.reason, dist: l.dist, limits: l.limits, marketReason: m.reason };
  }
  const m = tryMarket(); if (m.ok) return { ok: true, state: 'trade', ...m };
  if (m.reason === 'chase') {
    const l = tryLimit(); if (l.ok) return { ok: true, state: 'trade', ...l, note: 'market_chase' };
    return { ok: false, state: 'wait', reason: 'chase', dist: m.dist, max: m.max };
  }
  return { ok: false, state: 'no_trade', reason: m.reason };
}

/** Extra safety filters of the page (added to the engine's global filters, same PASS rule). */
export function extraGlobals({ validation, open = [], riskPct = 1, asset = 'crypto', maxOpen = RISK.maxOpen.def }) {
  const g = [];
  if (validation) {
    const clean = validation.duplicates === 0 && validation.gaps <= Math.max(2, Math.round((validation.n || 0) * 0.01)) && validation.state !== 'bad';
    g.push(makeCheck('integrity', 'الشموع سليمة (بدون تكرار أو فجوات كبيرة)', 'Candles intact (no duplicates or large gaps)', clean ? PASS : FAIL, `${validation.gaps} gaps · ${validation.duplicates} duplicates`));
  }
  const openRisk = open.reduce((s, x) => s + (Number(x.riskPct) || 0), 0);
  g.push(makeCheck('total_open', `عدد الصفقات المفتوحة < ${maxOpen}`, `Open trades below ${maxOpen}`, open.length < maxOpen ? PASS : FAIL, `${open.length} / ${maxOpen}`));
  g.push(makeCheck('total_risk', `مجموع المخاطرة المفتوحة ≤ ${RISK.maxOpenRiskPct}%`, `Total open risk ≤ ${RISK.maxOpenRiskPct}%`, openRisk + riskPct <= RISK.maxOpenRiskPct ? PASS : FAIL, `${r2(openRisk)}% + ${riskPct}%`));
  const assetRisk = open.filter((x) => x.asset === asset).reduce((s, x) => s + (Number(x.riskPct) || 0), 0);
  g.push(makeCheck('asset_risk', `مخاطرة نفس فئة السوق ≤ ${RISK.maxAssetRiskPct}%`, `Same asset-class risk ≤ ${RISK.maxAssetRiskPct}%`, assetRisk + riskPct <= RISK.maxAssetRiskPct ? PASS : FAIL, `${r2(assetRisk)}% + ${riskPct}%`));
  return g;
}

/** A saved open signal with the same strategy, market, direction and (nearly) the same entry → a duplicate. */
export function isDuplicate(items, { symbol, strategy, direction, entry, atr: a }) {
  const tol = Number.isFinite(a) && a > 0 ? 0.25 * a : Math.abs(entry) * 0.0005;
  return (items || []).some((x) => x && x.mode === 'live' && ['pending', 'active'].includes(x.status) && x.symbol === symbol && (x.strategy || 'smc') === strategy && x.direction === direction && Math.abs(x.entry - entry) <= tol);
}

/** Cost model and the snapshot used by the execution layer, built once per analysis. */
export function prepare(candles, { htf = null, tfSec = 900, asset = 'crypto', spreadPct = null } = {}) {
  return { S: candles.length >= 60 ? snapshot(candles, { htf, tfSec }) : null, cost: costModel(asset, spreadPct) };
}

export const EXEC_STATES = { PASS, FAIL, NA };

/* ───────── v248: the «توصية AI» page pipeline, shared by the page and its tests ───────── */
/** Engine settings of the page: AI mode, the user's risk settings, and an unavailable news calendar as a warning (not a block). */
export function pageEngineCfg({ base = {}, style = 'scalp', costPct = 0, risk = {}, extra = [] } = {}) {
  return { ...base, ai: true, newsUnknown: 'warn', costPct, dailyLossPct: risk.dailyLossPct, pauseAfterLosses: risk.pauseAfterLosses, chaseMaxAtr: EXEC.chaseMaxAtr[style], extraGlobals: extra };
}
/** Results of the user's closed trades that count for the loss-streak pause: only the last `hours` (the pause expires). */
export function recentResultsFor(done, nowMs = Date.now(), hours = RISK.pauseHours) {
  const since = nowMs / 1000 - hours * 3600;
  return (done || []).filter((x) => Number(x.closedAt) >= since).map((x) => (x.resultR < 0 ? 'loss' : x.resultR > 0 ? 'win' : 'be'));
}
/**
 * Execution of EVERY qualified strategy trade, each on its own (one failing never touches the others). Mutates each trade:
 * x.exec = executionPlan(…); on success x.plan = the executable plan. Returns the executable ones, ranked: ready market entries
 * first, then the best reward-to-risk after costs.
 */
export function executeAll(trades, { smcPlan = null, want = 'limit', style = 'scalp', asset = 'crypto', tf, tfSec = 900, S, atr: a, price, live, minRR = 0, smcMinRR = 0, costPct = 0, createdAt, nowMs = Date.now(), weightOf = null } = {}) {
  for (const x of trades || []) {
    const isSmc = x.id === 'smc';
    const base = isSmc ? { ...x.plan, sources: smcPlan?.sources } : x.plan;
    try {
      x.exec = executionPlan({ id: x.id, plan: base, engineExec: isSmc ? smcPlan?.execution : null, want, style, asset, tf, tfSec, S, atr: a, price, live, minRR: isSmc ? smcMinRR : minRR, costPct, createdAt, session24: asset === 'crypto', nowMs });
    } catch { x.exec = { ok: false, state: 'no_trade', reason: 'error' }; }
    if (x.exec.ok) x.plan = { ...x.plan, ...x.exec.plan, quality: x.plan.quality };
  }
  // v250: weightOf (the hidden adaptive engine's bounded weight, 1 by default) only changes the ORDER of qualified trades
  const w = (x) => { try { const v = weightOf ? Number(weightOf(x)) : 1; return Number.isFinite(v) && v > 0 ? v : 1; } catch { return 1; } };
  return (trades || []).filter((x) => x.exec?.ok).sort((p, q) => (p.plan.execution === 'market' ? 0 : 1) - (q.plan.execution === 'market' ? 0 : 1) || (q.plan.rrMain || 0) * w(q) - (p.plan.rrMain || 0) * w(p));
}
