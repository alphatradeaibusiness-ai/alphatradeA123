// Face sign-in in the browser: the device's own face unlock (Face ID, Android face unlock, Windows Hello) unlocks a passkey.
// No camera picture is taken by the site and nothing about the face leaves the device.
import { apiRequest } from './ai/gateway.js';
import { auth } from './auth/index.js';
import { storage } from '../utils/storage.js';

const b2a = (s) => { const b = s.replace(/-/g, '+').replace(/_/g, '/'); return Uint8Array.from(atob(b + '==='.slice((b.length + 3) % 4)), (c) => c.charCodeAt(0)); };
const a2b = (buf) => { let s = ''; for (const x of new Uint8Array(buf)) s += String.fromCharCode(x); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
const fail = (code) => Object.assign(new Error(code), { code });

/** true when this device has a built-in biometric authenticator (face or fingerprint). */
export async function faceSupported() {
  try { return Boolean(window.PublicKeyCredential && await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()); } catch { return false; }
}
export const faceHint = () => Boolean(storage.get('face-on-device', false));
export const faceStatus = () => apiRequest('GET', '/api/face/status', undefined, 10000);

/** Turn on face sign-in for THIS device (the account must have signed in within the last 10 minutes). */
export async function enrollFace(name) {
  const o = await apiRequest('POST', '/api/face/register/options', {}, 15000);
  const pk = o.publicKey;
  let cred;
  try { cred = await navigator.credentials.create({ publicKey: { ...pk, challenge: b2a(pk.challenge), user: { ...pk.user, id: b2a(pk.user.id) }, excludeCredentials: (pk.excludeCredentials || []).map((c) => ({ ...c, id: b2a(c.id) })) } }); }
  catch (e) { throw fail(e?.name === 'InvalidStateError' ? 'already_registered' : 'cancelled'); }
  if (!cred) throw fail('cancelled');
  const r = await apiRequest('POST', '/api/face/register', { challengeId: o.challengeId, name, credential: { id: cred.id, rawId: a2b(cred.rawId), type: cred.type, response: { clientDataJSON: a2b(cred.response.clientDataJSON), attestationObject: a2b(cred.response.attestationObject) } } }, 15000);
  storage.set('face-on-device', true);
  return r;
}

/** Sign in with the face: the device asks for Face ID / face unlock, the server checks the signature and returns a sign-in token. */
export async function faceSignIn() {
  const o = await apiRequest('POST', '/api/face/login/options', {}, 15000);
  if (!o.configured) throw fail('not_configured');
  const pk = o.publicKey;
  let a;
  try { a = await navigator.credentials.get({ publicKey: { ...pk, challenge: b2a(pk.challenge), allowCredentials: [] }, mediation: 'optional' }); }
  catch { throw fail('cancelled'); }
  if (!a) throw fail('cancelled');
  const r = await apiRequest('POST', '/api/face/login', { challengeId: o.challengeId, credential: { id: a.id, type: a.type, response: { clientDataJSON: a2b(a.response.clientDataJSON), authenticatorData: a2b(a.response.authenticatorData), signature: a2b(a.response.signature), userHandle: a.response.userHandle ? a2b(a.response.userHandle) : null } } }, 15000);
  await auth.signInWithToken(r.token);
  storage.set('face-on-device', true);
  return auth.current();
}
export const removeFace = (id = null) => apiRequest('DELETE', '/api/face', id ? { id } : {}, 10000);
