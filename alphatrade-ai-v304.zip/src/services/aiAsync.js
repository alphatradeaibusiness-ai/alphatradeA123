// Runs the chart's AI analysis in a Web Worker (aiWorker.js) instead of on the main thread.
// - Same inputs and same code as before (aiRun), so the numbers do not change; only where they are computed.
// - One job at a time; while one runs, only the NEWEST request waits (older ones are dropped, never queued up).
// - Until the new result arrives, the previous result for the same chart stays on screen (no flicker); then onReady() fires.
// - No Worker support, or the worker fails → falls back to computing on the main thread exactly as before.
import { aiJob, aiJobKey, aiRun } from './aiLive.js';

const results = new Map();   // job key → result (small LRU)
const latest = new Map();    // "symbol|tf" → last result shown for that chart
let worker = null; let broken = typeof Worker === 'undefined';
let inflight = null; let waiting = null; let seq = 0;

const remember = (k, chart, r) => { results.set(k, r); latest.set(chart, r); if (results.size > 24) results.delete(results.keys().next().value); };

function getWorker() {
  if (broken) return null;
  if (worker) return worker;
  try {
    worker = new Worker(new URL('./aiWorker.js', import.meta.url), { type: 'module' });
    worker.onmessage = (e) => finish(e.data);
    worker.onerror = (e) => { e.preventDefault?.(); fail(); };
    return worker;
  } catch { broken = true; return null; }
}

function fail() {
  broken = true; try { worker?.terminate(); } catch { /* already gone */ }
  worker = null;
  const jobs = [inflight, waiting].filter(Boolean); inflight = waiting = null;
  for (const j of jobs) { try { remember(j.k, j.job.base.key, aiRun(j.job)); } catch { /* leave it empty */ } j.onReady?.(); }
}

function finish(msg) {
  const j = inflight; inflight = null;
  if (j && msg?.id === j.id) {
    if (msg.error) { fail(); return; }
    remember(j.k, j.job.base.key, msg.result);
    j.onReady?.();
  }
  pump();
}

function pump() {
  if (inflight || !waiting) return;
  const w = getWorker();
  inflight = waiting; waiting = null;
  if (!w) { const j = inflight; inflight = null; remember(j.k, j.job.base.key, aiRun(j.job)); j.onReady?.(); return; }
  try { w.postMessage({ id: inflight.id, job: inflight.job }); } catch { fail(); }
}

/**
 * Result for the open chart. Returns the finished result when this exact input was already computed; otherwise starts
 * (or queues) the job and returns the previous result of the same chart (or null), calling onReady() when the new one is in.
 */
export function aiForAnalysisAsync(dataset, an, onReady) {
  const job = aiJob(dataset, an);
  if (!job) return null;
  const k = aiJobKey(job);
  if (results.has(k)) return results.get(k);
  if (broken) { const r = aiRun(job); remember(k, job.base.key, r); return r; }
  if (inflight?.k !== k && waiting?.k !== k) { waiting = { id: ++seq, k, job, onReady }; pump(); }
  const prev = latest.get(job.base.key);
  return prev ? { ...prev, pending: true } : null;
}

