// Display helpers for bank amounts (integers in minor units). Mirrors server/bank/money.js; the server is always the authority.
export const CURRENCIES = { USD: { decimals: 2, kind: 'fiat' }, EUR: { decimals: 2, kind: 'fiat' }, USDT: { decimals: 6, kind: 'crypto', networks: ['TRC20', 'ERC20', 'BEP20'] }, BTC: { decimals: 8, kind: 'crypto', networks: ['BTC'] } };
export function fmtMinor(n, cur, trim = true) {
  const d = CURRENCIES[cur]?.decimals ?? 2; const neg = n < 0; const a = Math.abs(n);
  const i = Math.floor(a / 10 ** d); let f = String(a % 10 ** d).padStart(d, '0');
  if (trim && d > 2) f = f.replace(/0+$/, '').padEnd(2, '0');
  return `${neg ? '−' : ''}${i.toLocaleString('en-US')}${d ? `.${f}` : ''}`;
}
