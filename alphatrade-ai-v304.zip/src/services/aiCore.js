// The AI engine's heavy step for the open chart, kept free of DOM / storage / network so it runs the same
// on the main thread and inside the Web Worker (src/services/aiWorker.js).
import { aiAnalyze, bestSide } from './aiEngine.js';

/** Same inputs → same result: identifies a job without its candles (the engine itself only looks at CLOSED candles). */
export function aiJobKey(j) {
  const c = j.candles; const last = c[c.length - 2] || c[c.length - 1];
  return [j.base.key, c.length, last?.time, last?.close, j.rrs.map((r) => Number(r).toFixed(2)).join(','), Number(j.base.riskAtr).toFixed(2), j.base.volumeKind, j.planSide || '-', j.deep ? 'd' : 's', j.trades?.length || 0].join('|');
}

/** The heavy part: trains and tests the models (pure, no DOM / storage). */
export function aiRun(j) {
  const { candles, base, rrs, trades } = j;
  const main = aiAnalyze(candles, { ...base, rr1: rrs[0], strategyTrades: trades });
  if (!main.ready) return { ready: false, reason: main.reason, need: main.need, have: main.have };
  const side = j.planSide || bestSide(main) || ((main.long?.p ?? 0) >= (main.short?.p ?? 0) ? 'long' : 'short');
  const tp = [main[side] || null];
  for (const r of rrs.slice(1)) tp.push(aiAnalyze(candles, { ...base, rr1: r, skipForecast: true })[side] || null);
  const m = tp[0];
  return {
    ready: Boolean(m), side, planned: Boolean(j.planSide), tp, rrs, riskAtr: base.riskAtr, m,
    forecast: main.forecast, strategy: main.strategy, deep: j.deep, bars: candles.length, demo: j.demo,
    edgeSide: bestSide(main),
  };
}

