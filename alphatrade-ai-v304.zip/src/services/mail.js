// Asks the server to send the welcome / sign-in e-mail for the account that just signed in (the server decides which one, and does nothing without its mail key).
import { apiRequest } from './ai/gateway.js';
export const mailSignin = () => { try { apiRequest('POST', '/api/mail/signin', {}, 8000).catch(() => {}); } catch { /* offline */ } };
