// v297: asks the server which plan this account really has (the browser cannot be trusted to say), and whether plans are enforced.
import { apiRequest } from './ai/gateway.js';
import { setEnforce, setVerifiedPlan } from '../config/entitlements.js';

/** Resolves once the server answered (or after 4 s). Never throws: when the server cannot be reached nothing is locked in the page. */
export async function syncPlan() {
  setVerifiedPlan(null);   // never keep the previous account's plan
  try {
    const me = await Promise.race([apiRequest('GET', '/api/billing/me', undefined, 4000), new Promise((_, no) => setTimeout(() => no(new Error('timeout')), 4500))]);
    if (me?.enforce) { setEnforce(true); setVerifiedPlan(me.owner ? 'max' : (me.plan || 'free')); }
  } catch { /* offline or not signed in */ }
}
