// The channel's publishing bar (pure: no DOM, no storage) — shared by services/signals.js and the scan Web Worker.
import { summarize } from './backtest.js';

export const MIN_ACCURACY = 62;      // no recommendation from a combination below 62% real accuracy
export const MIN_TRADES = 30; // 20 trades at 62% still leaves a 95% range of roughly 45–84%: too wide to call it an edge
// Honest check: the newest 40% of the trades were not used to choose the combination.
export const MIN_OOS_TRADES = 10;
export const MIN_OOS_ACC = 60;
// "Under watch" tier: a positive combination that has not yet reached the full bar above. It is published so setups
// reach the site, but always labelled as unproven (tier: 'watch'), never with the qualified wording.
export const WATCH_ACCURACY = 55;
export const WATCH_TRADES = 20;

/**
 * Decides if a strategy/timeframe may publish signals. Besides the overall result it must also hold on
 * the newest 40% of its trades (out-of-sample), so a lucky streak in the past is not enough.
 * The accuracy shown is the LOWER of the two.
 */
export function evaluateCombo(trades, minAcc = MIN_ACCURACY) {
  const sorted = [...trades].sort((a, b) => a.closeTime - b.closeTime);
  const all = summarize(sorted).total;
  const oos = summarize(sorted.slice(Math.floor(sorted.length * 0.6))).total;
  // A stricter strategy (LBR: 65%) asks the same bar of its newest trades too.
  const oosMin = minAcc > MIN_ACCURACY ? minAcc : MIN_OOS_ACC;
  const qualified = all.trades >= MIN_TRADES && all.winRate >= minAcc && all.points > 0 && all.r > 0 // a high win rate with a negative R still loses money
    && oos.trades >= MIN_OOS_TRADES && oos.winRate >= oosMin && oos.points > 0 && oos.r > 0;
  const watch = !qualified && all.trades >= WATCH_TRADES && all.winRate >= WATCH_ACCURACY && all.points > 0 && all.r > 0
    && oos.trades >= 5 && oos.points > 0;
  return { all, oos, qualified, watch, accuracy: Math.min(all.winRate, oos.winRate) };
}
