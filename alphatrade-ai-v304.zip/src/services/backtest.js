// Strategy engine — used both for the live plan on the dashboard and for the backtest page,
// so what the results page counts is exactly what the dashboard would have shown.
//
// Classic strategy (improved after testing on 21 months of real BTC data):
//   • Entry only on a fresh signal: momentum crosses up through 60 (buy) or down through 40 (sell).
//   • Trend filter: buy only above the 200 EMA, sell only below it.
//   • Stop: 2 × ATR(14) (moves with market volatility) — or a fixed number of points if the user
//     chooses "fixed points" in Settings. Targets: 1R / 2R / 3.5R — or fixed points.
// SMC strategy: entry at the order block, stop beyond it, targets at liquidity (indicators/smc.js),
//   with the same 200 EMA trend filter (on by default).
//
// Trade management (both):
//   • A third of the position closes at each target; after TP1 the stop moves to the entry.
//   • If one candle touches the stop and a target, the stop is assumed first (conservative).
//   • Optional round-trip fee (percent of price) is subtracted from every trade.
// A trade counts as a win once TP1 is reached; a loss when the stop is hit before TP1.
import { trailUpdate } from './quant.js';
import { can } from '../config/entitlements.js';
import { rsi, ema, atr, momentumScore, pressureSeries, pressureTotals } from '../indicators/index.js';

import { prepare as smc2Prepare, evaluate as smc2Evaluate, SMC2_DEFAULTS, SMC2_OPTS } from './smc2.js';
import { prepareExec, execBlock, normalizeExec } from './execFilters.js';
import { regimeSeries, isBlocked } from './regime.js';
import { prepare as zonePrepare, evaluate as zoneEvaluate, ZONE_DEFAULTS } from './zoneStrategy.js';

export const WARMUP = 210;
const MOMENTUM_WINDOW = 200;

export const DEFAULT_RULES = {
  stopMode: 'atr', atrMult: 3, htfTrendHours: 200, tpR: [1, 2, 3.5], slPoints: 30, tpPoints: [50, 80, 130],
  buyAbove: 60, sellBelow: 40, trendFilter: true, feePct: 0, tpGapPts: 50, tp3GapPts: 30,
};

/** Points earned (before fees) by a trade that ends at `exit` after `hits` targets. */
function tradePoints(t, exit, pointSize) {
  const sign = t.direction === 'long' ? 1 : -1;
  let pts = 0;
  for (let k = 0; k < t.hits; k++) pts += ((t.targets[k] - t.entry) * sign) / pointSize / 3;
  pts += (((exit - t.entry) * sign) / pointSize) * ((3 - t.hits) / 3);
  return pts;
}

function finish(t, c, outcome, exit, o) {
  const fee = (((o.feePct || 0) + (o.slipPct || 0)) / 100) * t.entry / o.pointSize;
  const points = tradePoints(t, exit, o.pointSize) - fee;
  return { ...t, outcome, closeTime: c.time, exit, points, fee, feeR: fee / (t.risk / o.pointSize), r: points / (t.risk / o.pointSize) };
}

/** Advance an open trade by one candle; returns the closed trade or null while it stays open. */
function stepOpen(t, c, o) {
  const long = t.direction === 'long';
  if (long ? c.low <= t.stop : c.high >= t.stop) return finish(t, c, t.hits === 0 && !t.beMoved ? 'sl' : 'be', t.stop, o);
  while (t.hits < 3 && (long ? c.high >= t.targets[t.hits] : c.low <= t.targets[t.hits])) {
    t.hits++;
    if (t.hits === 1) t.stop = t.entry; // breakeven after TP1
  }
  if (t.hits === 3) return finish(t, c, 'tp3', t.targets[2], o);
  // Optional earlier breakeven: once price has moved `beAtR` x the risk in our favour the stop goes to the
  // entry. If the same candle also came back to the entry we cannot know the order, so we assume the worst.
  if (o.beAtR > 0 && !t.beMoved && t.hits === 0 && (long ? c.high >= t.entry + o.beAtR * t.risk : c.low <= t.entry - o.beAtR * t.risk)) {
    t.beMoved = true; t.stop = t.entry;
    if (long ? c.low <= t.entry : c.high >= t.entry) return finish(t, c, 'be', t.entry, o);
  }
  // Optional ATR trailing stop after target 1 / early breakeven (see services/quant.js)
  if (trailUpdate(t, c, o)) return finish(t, c, 'be', t.stop, o);
  return null;
}

/**
 * Monthly loss cap (in points/pips). A new trade is refused when the month's realised loss (UTC calendar month,
 * counted when trades CLOSE) plus the worst case of this trade (its full stop distance plus the fee) would go past the cap.
 * Because the stop is the most a trade can lose, the monthly realised loss can then never exceed the cap
 * (assuming fills at the stop; a price gap or slippage through the stop is not covered).
 */
export function monthBlocks(trades, c, o, risk, entry) {
  if (!(o.monthlyCapPts > 0)) return false;
  const d = new Date(c.time * 1000); const m = d.getUTCFullYear() * 12 + d.getUTCMonth();
  let net = 0;
  for (let k = trades.length - 1; k >= 0; k--) {
    const e = new Date(trades[k].closeTime * 1000);
    const mk = e.getUTCFullYear() * 12 + e.getUTCMonth();
    if (mk < m) break;
    if (mk === m) net += trades[k].points;
  }
  const worst = risk / o.pointSize + (((o.feePct || 0) + (o.slipPct || 0)) / 100) * entry / o.pointSize;
  return Math.max(0, -net) + worst > o.monthlyCapPts;
}

/** Daily loss cap in points: refuses a trade when today's realised loss (UTC day, by close time) + its worst case would pass the cap. */
export function dayBlocks(trades, c, o, risk, entry) {
  if (!(o.dailyCapPts > 0)) return false;
  const day = Math.floor(c.time / 86400); let net = 0;
  for (let k = trades.length - 1; k >= 0; k--) {
    const d = Math.floor(trades[k].closeTime / 86400);
    if (d < day) break;
    if (d === day) net += trades[k].points;
  }
  const worst = risk / o.pointSize + (((o.feePct || 0) + (o.slipPct || 0)) / 100) * entry / o.pointSize;
  return Math.max(0, -net) + worst > o.dailyCapPts;
}

/** Daily circuit breaker for the backtest: no new entries on a UTC day once its closed trades lost `dailyStopR`. */
function dailyHalt(trades, c, o) {
  if (!(o.dailyStopR > 0)) return false;
  const day = Math.floor(c.time / 86400);
  let r = 0;
  for (let k = trades.length - 1; k >= 0; k--) {
    const d = Math.floor(trades[k].closeTime / 86400);
    if (d < day) break;
    if (d === day) r += trades[k].r || 0;
  }
  return r <= -o.dailyStopR;
}

/** Targets always run outward from the entry in the trade direction: TP1 nearest, TP3 farthest, no duplicates. */
export function orderTargets(direction, entry, risk, targets) {
  const sign = direction === 'long' ? 1 : -1;
  const step = risk * 0.25;
  const sorted = targets.filter(Number.isFinite).sort((a, b) => (a - b) * sign);
  const out = [];
  for (let k = 0; k < 3; k++) {
    const prev = k ? out[k - 1] : entry;
    let v = sorted[k] ?? prev + sign * risk;
    if ((v - prev) * sign < step) v = prev + sign * Math.max(step, risk * 0.5);
    out.push(v);
  }
  return out;
}

/**
 * Spaces the targets exactly: Target 2 is `gap12` points beyond Target 1, Target 3 is `gap23` points beyond Target 2 (every strategy,
 * every chart). A gap of 0 leaves that step as computed (Target 3 then keeps its own distance, at least the Target 1-2 gap).
 */
export function applyTpGap(direction, targets, pointSize, gap12 = 50, gap23 = 30) {
  if (!(pointSize > 0) || targets.length < 3 || !(gap12 > 0 || gap23 > 0)) return targets;
  const s = direction === 'long' ? 1 : -1;
  const t2 = gap12 > 0 ? targets[0] + s * gap12 * pointSize : targets[1];
  const t3 = gap23 > 0 ? t2 + s * gap23 * pointSize : t2 + s * Math.max(gap12 * pointSize, (targets[2] - targets[1]) * s);
  return [targets[0], t2, t3];
}

function levels(direction, entry, risk, o) {
  const s = direction === 'long' ? 1 : -1;
  const targets = o.stopMode === 'points' ? o.tpPoints.map((p) => entry + s * p * o.pointSize) : o.tpR.map((m) => entry + s * m * risk);
  return { stop: entry - s * risk, initialStop: entry - s * risk, targets: applyTpGap(direction, orderTargets(direction, entry, risk, withFirstTarget(targets, direction, entry, risk, o)), o.pointSize, o.tpGapPts, o.tp3GapPts) };
}

/**
 * Higher-timeframe trend per candle, without look-ahead: candles are grouped `factor` at a time
 * (e.g. 4 × 1h = 4h); each candle sees only HTF bars that were already closed before its group.
 * Returns +1 (HTF close above its EMA), -1 (below) or 0 (not enough data).
 */
export function htfTrend(candles, factor = 4, period = 50) {
  const out = new Array(candles.length).fill(0);
  if (candles.length < 2 || factor < 2) return out;
  const step = candles[1].time - candles[0].time;
  const span = step * factor;
  const groups = []; // { key, close }
  const groupOf = new Array(candles.length);
  for (let i = 0; i < candles.length; i++) {
    const key = Math.floor(candles[i].time / span);
    if (!groups.length || groups.at(-1).key !== key) groups.push({ key, close: candles[i].close });
    else groups.at(-1).close = candles[i].close;
    groupOf[i] = groups.length - 1;
  }
  const e = ema(groups.map((g) => g.close), period);
  for (let i = 0; i < candles.length; i++) {
    const g = groupOf[i] - 1; // last closed HTF bar
    if (g >= 0 && e[g] != null) out[i] = groups[g].close > e[g] ? 1 : -1;
  }
  return out;
}

/** Filters shared by both strategies: higher-timeframe trend and minimum stop size (fees vs risk). */
function passesFilters(direction, i, entry, risk, o, htf) {
  if (htf && htf[i] !== (direction === 'long' ? 1 : -1)) return false;
  if (o.minRiskPct > 0 && (risk / entry) * 100 < o.minRiskPct) return false;
  return true;
}

/** Momentum score (0–100) for every candle, computed only from data up to that candle. */
export function momentumSeries(candles, volumeKind = 'none') {
  const closes = candles.map((c) => c.close);
  const rsiAll = rsi(closes, 14);
  const pAll = volumeKind !== 'none' ? pressureSeries(candles, volumeKind) : null;
  const out = new Array(candles.length).fill(null);
  for (let i = 60; i < candles.length; i++) {
    const from = Math.max(0, i - MOMENTUM_WINDOW + 1);
    out[i] = momentumScore({ candles: candles.slice(from, i + 1), rsiValues: rsiAll.slice(from, i + 1), pressure: pAll ? pressureTotals(pAll.slice(from, i + 1)) : null })?.score ?? null;
  }
  return out;
}

const dayOf = (sec) => Math.floor(sec / 86400);

/** Optional closer first target (o.firstTargetR × risk), kept below the second target. */
function withFirstTarget(targets, direction, entry, risk, o) {
  if (!(o.firstTargetR > 0) || o.stopMode === 'points') return targets;
  const s = direction === 'long' ? 1 : -1;
  const tp1 = entry + s * o.firstTargetR * risk;
  return (targets[1] - tp1) * s > 0 ? [tp1, targets[1], targets[2]] : targets;
}

/**
 * Trend gate shared by the strategies: with `hours` > 0 a long is refused while price is below the N-hour EMA, a short while above it.
 * The EMA comes from REAL 4h closes (o.htfCandles.h4) when loaded, else from the chart's own closes (only once there is enough history).
 * Only candles that were already closed at bar i are used. Returns (i, dir, price) => true when the trade must be skipped.
 */
function trendGate(candles, o, hours) {
  if (!(hours > 0)) return () => false;
  const tfSec = edhStep(candles);
  const h4 = o.htfCandles?.h4;
  if (h4?.length) {
    const e4 = ema(h4.map((x) => x.close), Math.max(2, Math.round(hours / 4)));
    let p = -1;
    return (i, dir, price) => {
      const end = candles[i].time + tfSec;
      while (p + 1 < h4.length && h4[p + 1].time + 14400 <= end) p++;
      const ref = p >= 0 ? e4[p] : null;
      return ref != null && (dir === 'long' ? price < ref : price > ref);
    };
  }
  const per = Math.max(2, Math.round((hours * 3600) / tfSec));
  const eo = ema(candles.map((c) => c.close), per);
  return (i, dir, price) => i >= per && eo[i] != null && (dir === 'long' ? price < eo[i] : price > eo[i]);
}

/**
 * Classic strategy over a candle series.
 * @returns {{ trades: object[], open: object|null }}  `open` is the trade still running at the last candle.
 */
export function backtestClassic(candles, opts) {
  const o = { ...DEFAULT_RULES, openOnLast: true, forced: null, volumeKind: 'none', ...opts };
  const closes = candles.map((c) => c.close);
  const atrAll = atr(candles, 14);
  const e200 = ema(closes, 200);
  const mom = momentumSeries(candles, o.volumeKind);
  const htf = o.htfFactor > 1 ? htfTrend(candles, o.htfFactor, o.htfPeriod || 50) : null;
  const R = o.regimeBlock?.length ? (o.regimeR || regimeSeries(candles)) : null;
  const X = prepareExec(candles, o.exec);
  const tg = trendGate(candles, o, o.htfTrendHours);
  const trades = [];
  const perDay = new Map();
  let open = null;
  let prev = null;
  for (let i = Math.min(WARMUP, Math.max(60, candles.length - 1)); i < candles.length; i++) {
    const c = candles[i];
    if (open) {
      const done = stepOpen(open, c, o);
      if (done) { trades.push(done); open = null; }
    }
    const score = mom[i];
    if (score == null) continue;
    const up = prev != null && prev < o.buyAbove && score >= o.buyAbove;
    const down = prev != null && prev > o.sellBelow && score <= o.sellBelow;
    prev = score;
    if (open || (!up && !down) || (i === candles.length - 1 && !o.openOnLast)) continue;
    const direction = up ? 'long' : 'short';
    if (o.forced && o.forced !== direction) continue;
    if (o.trendFilter && e200[i] != null && (direction === 'long' ? c.close < e200[i] : c.close > e200[i])) continue;
    if (tg(i, direction, c.close)) continue;
    const risk = o.stopMode === 'points' ? o.slPoints * o.pointSize : o.atrMult * (atrAll[i] || 0);
    if (!(risk > 0) || !passesFilters(direction, i, c.close, risk, o, htf)) continue;
    if (monthBlocks(trades, c, o, risk, c.close) || dayBlocks(trades, c, o, risk, c.close)) continue;
    if (X && execBlock(X, i, direction, c.close)) continue;
    if (R && isBlocked(R, o.regimeBlock, i, direction)) continue;
    if (o.maxPerDay > 0 && (perDay.get(dayOf(c.time)) || 0) >= o.maxPerDay) continue;
    if (dailyHalt(trades, c, o)) continue;
    perDay.set(dayOf(c.time), (perDay.get(dayOf(c.time)) || 0) + 1);
    open = { strategy: 'classic', direction, entry: c.close, risk, hits: 0, openTime: c.time, atrE: atrAll[i], ...levels(direction, c.close, risk, o) };
  }
  return { trades, open };
}

/**
 * SMC v2 over a candle series (see services/smc2.js): HTF alignment, liquidity sweep, quality order
 * block, CHoCH + FVG confirmation, kill zones, volume profile and a 0–100 score. The trade opens
 * AT MARKET on the confirmation candle's close — there are no pending orders — only when the score
 * reaches `smcMinScore` (default 80).  version.
 * @returns {{ trades: object[], open: object|null, pending: null, rejects: object }}
 */
export function backtestSmc(candles, opts) {
  const o = { ...DEFAULT_RULES, openOnLast: true, forced: null, smcMinScore: SMC2_DEFAULTS.minScore, smcKillZone: true, smcHtf: true, ...opts };
  const S = smc2Prepare(candles, { htf: o.htfCandles || null });
  S.o = { ...S.o, minScore: o.smcMinScore, killZone: o.smcKillZone, htf: o.smcHtf, ...(o.smcOpts || {}) };
  const R = o.regimeBlock?.length ? (o.regimeR || regimeSeries(candles)) : null;
  const X = prepareExec(candles, o.exec);
  const trades = [];
  const perDay = new Map();
  const used = new Set();
  const rejects = { htf: 0, session: 0, score: 0 };
  let open = null;
  for (let i = Math.min(WARMUP, Math.max(60, candles.length - 1)); i < candles.length; i++) {
    const c = candles[i];
    if (open) {
      const done = stepOpen(open, c, o);
      if (done) { trades.push(done); open = null; }
      // Time stop: a trade that has not even reached target 1 after N candles is closed at the close.
      else if (o.smcTimeStop > 0 && open.hits === 0 && (c.time - open.openTime) / S.tfSec >= o.smcTimeStop) { trades.push(finish(open, c, 'time', c.close, o)); open = null; }
    }
    if (open || (i === candles.length - 1 && !o.openOnLast)) continue;
    if (o.maxPerDay > 0 && (perDay.get(dayOf(c.time)) || 0) >= o.maxPerDay) continue;
    if (dailyHalt(trades, c, o)) continue;
    const { setup: s, rejected } = smc2Evaluate(S, i, { forced: o.forced });
    if (!s) { if (rejected && !used.has(`r|${rejected.setup.key}`)) { used.add(`r|${rejected.setup.key}`); rejects[rejected.reason]++; } continue; }
    if (used.has(s.key)) continue;
    if (o.minRiskPct > 0 && (s.risk / s.entry) * 100 < o.minRiskPct) continue;
    if (monthBlocks(trades, c, o, s.risk, s.entry) || dayBlocks(trades, c, o, s.risk, s.entry)) continue;
    { const xb = X && execBlock(X, i, s.direction, s.entry); if (xb) { rejects['x_' + xb] = (rejects['x_' + xb] || 0) + 1; continue; } }
    if (R && isBlocked(R, o.regimeBlock, i, s.direction)) { rejects.regime = (rejects.regime || 0) + 1; continue; }
    used.add(s.key);
    perDay.set(dayOf(c.time), (perDay.get(dayOf(c.time)) || 0) + 1);
    open = {
      strategy: 'smc', v2: true, direction: s.direction, entry: s.entry, risk: s.risk, hits: 0, openTime: c.time, atrE: S.atr[i],
      stop: s.stop, initialStop: s.stop, targets: applyTpGap(s.direction, orderTargets(s.direction, s.entry, s.risk, s.targets), o.pointSize, o.tpGapPts, o.tp3GapPts),
      createdTime: s.createdTime, score: s.score, scoreParts: s.scoreParts, scoreNa: s.scoreNa,
      sweepType: s.sweep.type, sweepLevel: s.sweep.level, ob: s.ob, zone: s.zone, htf: s.htf, chochLevel: s.choch.level,
    };
  }
  return { trades, open, pending: null, rejects };
}

/**
 * Zone strategy over a candle series (see services/zoneStrategy.js): supply/demand zone reaction,
 * volume + fixed volume profile, RSI and Fibonacci, scored out of 100 (minimum `zoneMinScore`,
 * default 80). Opens AT MARKET on the reaction candle's close; targets from the Fibonacci leg.
 * @returns {{ trades: object[], open: object|null, pending: null, rejects: object }}
 */
export function backtestZone(candles, opts) {
  const o = { ...DEFAULT_RULES, openOnLast: true, forced: null, zoneMinScore: ZONE_DEFAULTS.minScore, zoneHtf: true, zoneRequireVp: true, zoneMinVol: ZONE_DEFAULTS.minVolRatio, zoneMinRR: ZONE_DEFAULTS.minRR, ...opts };
  const S = zonePrepare(candles);
  S.o = { ...S.o, minScore: o.zoneMinScore, htf: o.zoneHtf, requireVp: o.zoneRequireVp, minVolRatio: o.zoneMinVol, minRR: o.zoneMinRR, tp1Cap: o.zoneTp1Cap || 0, quant: o.zoneQuant !== false, regimeWeights: o.zoneRegimeW !== false, zGate: o.zoneZGate || 0, flowGate: !!o.zoneFlowGate };
  const R = o.regimeBlock?.length ? (o.regimeR || regimeSeries(candles)) : null;
  const X = prepareExec(candles, o.exec);
  const trades = [];
  const perDay = new Map();
  const used = new Set();
  const rejects = {};
  let open = null;
  for (let i = Math.min(WARMUP, Math.max(60, candles.length - 1)); i < candles.length; i++) {
    const c = candles[i];
    if (open) {
      const done = stepOpen(open, c, o);
      if (done) { trades.push(done); open = null; }
      else if (o.zoneTimeStop > 0 && open.hits === 0 && (i - open.openIndex) >= o.zoneTimeStop) { trades.push(finish(open, c, 'time', c.close, o)); open = null; }
    }
    if (open || (i === candles.length - 1 && !o.openOnLast)) continue;
    if (o.maxPerDay > 0 && (perDay.get(dayOf(c.time)) || 0) >= o.maxPerDay) continue;
    if (dailyHalt(trades, c, o)) { rejects.daily = (rejects.daily || 0) + 1; continue; }
    const { setup: s, rejected } = zoneEvaluate(S, i, { forced: o.forced });
    if (!s) { if (rejected) rejects[rejected.reason] = (rejects[rejected.reason] || 0) + 1; continue; }
    if (used.has(s.key)) continue;
    if (o.minRiskPct > 0 && (s.risk / s.entry) * 100 < o.minRiskPct) { rejects.fees = (rejects.fees || 0) + 1; continue; }
    { const xb = X && execBlock(X, i, s.direction, s.entry); if (xb) { rejects['x_' + xb] = (rejects['x_' + xb] || 0) + 1; continue; } }
    if (dayBlocks(trades, c, o, s.risk, s.entry)) { rejects.dailyPts = (rejects.dailyPts || 0) + 1; continue; }
    if (monthBlocks(trades, c, o, s.risk, s.entry)) { rejects.monthly = (rejects.monthly || 0) + 1; continue; }
    if (R && isBlocked(R, o.regimeBlock, i, s.direction)) { rejects.regime = (rejects.regime || 0) + 1; continue; }
    used.add(s.key);
    perDay.set(dayOf(c.time), (perDay.get(dayOf(c.time)) || 0) + 1);
    open = {
      strategy: 'zone', direction: s.direction, entry: s.entry, risk: s.risk, hits: 0, openTime: c.time, openIndex: i, atrE: S.atr[i],
      regime: s.regime, zscore: s.zscore, flowKinds: s.flow?.kinds || [],
      stop: s.stop, initialStop: s.stop, targets: applyTpGap(s.direction, orderTargets(s.direction, s.entry, s.risk, s.targets), o.pointSize, o.tpGapPts, o.tp3GapPts),
      createdTime: c.time, score: s.score, scoreParts: s.scoreParts, scoreNa: s.scoreNa,
      zone: { top: s.zone.top, bottom: s.zone.bottom, dir: s.zone.dir, time: s.zone.time, touch: s.touchNo },
      fibRatio: s.ratio, htfDir: s.htf, zoneDisp: s.zone.disp, wickShare: s.wick, vpHit: s.vpHit, volRatio: s.vr, rsiAt: s.rsi, divergence: s.div,
    };
  }
  return { trades, open, pending: null, rejects };
}

/* ───────── EDH: previous-day high/low break confirmed by a 5-minute close ───────── */
export const EDH_DEFAULTS = { m1: { t1Pips: 30, t2Pips: 70, slPips: 30 }, m5: { t1Pips: 45, t2Pips: 80, slPips: 60 }, maxPerSide: 1, trendHours: 200, confirm5: true, showZones: true, pivLen: 5, dispMult: 2, maxOb: 2, maxSw: 3 };

/** Distinct targets per chart timeframe: the 1-minute chart uses `m1`, 5-minute and slower charts use `m5`. Limits: T1 >= 30 pips, T2 70-80. */
export function edhTargets(E, tfSec) {
  const P = (tfSec <= 60 ? E?.m1 : E?.m5) || (tfSec <= 60 ? EDH_DEFAULTS.m1 : EDH_DEFAULTS.m5);
  const D = tfSec <= 60 ? EDH_DEFAULTS.m1 : EDH_DEFAULTS.m5;
  return {
    t1: Math.max(30, Number(P.t1Pips) || D.t1Pips),
    t2: Math.min(80, Math.max(70, Number(P.t2Pips) || D.t2Pips)),
    sl: Number(P.slPips) > 0 ? Number(P.slPips) : D.slPips,
  };
}

/** Day -> {hi, lo}. Real daily candles (when given) win over the intraday candles, which on 1m / 5m rarely cover a whole day. */
function edhDayRanges(candles, daily) {
  const m = new Map();
  for (const c of candles) {
    const k = Math.floor(c.time / 86400); const d = m.get(k);
    if (!d) m.set(k, { hi: c.high, lo: c.low }); else { d.hi = Math.max(d.hi, c.high); d.lo = Math.min(d.lo, c.low); }
  }
  for (const c of daily || []) m.set(Math.floor(c.time / 86400), { hi: c.high, lo: c.low, full: true });
  return m;
}
export const edhStep = (candles) => { const n = candles.length; return n > 6 ? Math.max(1, Math.round(median3(candles, n))) : 60; };
function median3(candles, n) { const a = []; for (let i = n - 1; i > Math.max(0, n - 12); i--) a.push(candles[i].time - candles[i - 1].time); a.sort((x, y) => x - y); return a[Math.floor(a.length / 2)]; }

/** The levels in force on the newest candle: yesterday's high / low (UTC day), when yesterday is fully covered by the candles. */
export function edhLevels(candles, daily) {
  if (!candles?.length) return null;
  const c = candles[candles.length - 1]; const k = Math.floor(c.time / 86400);
  const p = edhDayRanges(candles, daily).get(k - 1);
  if (!p || (!p.full && candles[0].time > (k - 1) * 86400 + edhStep(candles))) return null;
  return { high: p.hi, low: p.lo, dayStart: k * 86400 };
}

/**
 * EDH over a candle series. Levels = previous UTC day's high / low. SELL when a 5-minute candle CLOSES below the low
 * (the previous 5-minute close was at/above it); BUY when one closes above the high. On 1m candles only the last minute of every
 * 5-minute slot counts. Stop `slPips`, Target 1 `t1Pips` (>= 30), Target 2 `t2Pips` (70-80). The engine splits thirds: 1/3 at
 * Target 1 and 2/3 at Target 2, and the stop moves to the entry after Target 1.
 */
export function backtestEdh(candles, opts) {
  const o = { ...DEFAULT_RULES, openOnLast: true, forced: null, volumeKind: 'none', edhPipPts: 1, ...opts };
  const E = { ...EDH_DEFAULTS, ...(o.edh || {}) };
  const trades = []; let open = null;
  if (candles.length < 40) return { trades, open, pending: null, rejects: {} };
  const tfSec = edhStep(candles);
  const step5 = tfSec >= 300 ? 1 : Math.max(1, Math.round(300 / tfSec));
  const days = edhDayRanges(candles, o.edhDaily || o.htfCandles?.d1);
  const t0 = candles[0].time;
  const X = prepareExec(candles, o.exec);
  const pip = (o.edhPipPts || 1) * o.pointSize;
  const { t1, t2, sl: slP } = edhTargets(E, tfSec);
  const risk = slP * pip;
  const tg = trendGate(candles, o, E.trendHours);
  const perDay = new Map(); const rejects = {};
  for (let i = step5 + 1; i < candles.length; i++) {
    const c = candles[i];
    if (open) {
      // Entry is taken on the 1-minute candle that closes the 5-minute breakout candle; stop and Target 1 are checked on every 1-minute
      // candle. Target 2 (when confirm5 is on and the data is finer than 5m) only counts if a 5-minute candle CLOSES beyond it.
      const long = open.direction === 'long'; const gate = E.confirm5 !== false && tfSec < 300;
      const keep = open.targets.slice();
      if (gate) {
        const onClose = (c.time % 300) === 300 - tfSec;
        for (const k of [1, 2]) open.targets[k] = onClose && (long ? c.close >= keep[k] : c.close <= keep[k]) ? keep[k] : (long ? 1e18 : -1e18);
      }
      const done = stepOpen(open, c, o);
      if (gate) { open.targets[1] = keep[1]; open.targets[2] = keep[2]; }
      if (done) { trades.push(done); open = null; }
    }
    if (tfSec < 300 && (c.time % 300) !== 300 - tfSec) continue;      // only on the close of a 5-minute slot
    if (open || (i === candles.length - 1 && !o.openOnLast)) continue;
    const k = Math.floor(c.time / 86400);
    const prev = days.get(k - 1);
    if (!prev || (!prev.full && t0 > (k - 1) * 86400 + tfSec)) continue;
    const c5 = c.close; const c5p = candles[i - step5].close;
    let direction = null;
    if (c5 < prev.lo && c5p >= prev.lo) direction = 'short'; else if (c5 > prev.hi && c5p <= prev.hi) direction = 'long';
    if (!direction) continue;
    if (o.forced && o.forced !== direction) continue;
    // Trend filter (the only EDH add-on that improved results on every timeframe tested): trade with the 200-hour EMA, not against it.
    if (tg(i, direction, c.close)) { rejects.trend = (rejects.trend || 0) + 1; continue; }
    const cnt = perDay.get(k) || { long: 0, short: 0 };
    if (cnt[direction] >= Math.max(1, E.maxPerSide)) continue;
    // The stop is the user's own pips, so the fee-vs-stop guard of the other strategies is not applied; fees are still charged on every trade.
    if (dayBlocks(trades, c, o, risk, c.close) || monthBlocks(trades, c, o, risk, c.close)) { rejects.cap = (rejects.cap || 0) + 1; continue; }
    { const xb = X && execBlock(X, i, direction, c.close); if (xb) { rejects['x_' + xb] = (rejects['x_' + xb] || 0) + 1; continue; } }
    cnt[direction]++; perDay.set(k, cnt);
    const s = direction === 'long' ? 1 : -1;
    open = {
      strategy: 'edh', direction, entry: c.close, risk, hits: 0, openTime: c.time, atrE: null, stop: c.close - s * risk, initialStop: c.close - s * risk,
      t2: c.close + s * t2 * pip, targets: applyTpGap(direction, [c.close + s * t1 * pip, c.close + s * t2 * pip, c.close + s * t2 * pip], o.pointSize, o.tpGapPts, o.tp3GapPts), level: direction === 'long' ? prev.hi : prev.lo,
    };
  }
  return { trades, open, pending: null, rejects };
}

/* ───────── LBR: London opening-range breakout, entered on the retest ─────────
 * Found by a search on real Bitstamp BTC/USD 1-minute data (Jan 2025 → Oct 2026): chosen on the first 9 months only, then checked on
 * two later periods it never saw. Rules (UTC, 5-minute candles):
 *   1. Range = high / low of 07:00–07:30. Skip the day if it is narrower than `minW` or wider than `maxW` pips.
 *   2. The first 5-minute candle that CLOSES outside the range within `windowH` hours gives the side — only if the 1-hour EMA50 is on
 *      the same side of the 1-hour EMA200 (closed hours only). Otherwise no trade that day.
 *   3. Limit order at the broken edge; it fills only if price comes back to it within `retestMin` minutes.
 *   4. One target `tp1` pips, stop `sl` pips, everything closes after `maxMin` minutes. One trade a day.
 * If the candle that fills the order also reaches the stop, it counts as a loss (we cannot see the order inside a candle).
 * 1 pip = 10 points on crypto / gold (the platform's EDH pip). Researched on BTC only, so by default it runs on BTCUSDT only.
 */
export const LBR_DEFAULTS = { startH: 7, rangeMin: 30, minW: 15, maxW: 80, windowH: 2, retestMin: 60, tp1: 30, sl: 60, maxMin: 480, symbols: ['BTCUSDT'], minAccuracy: 65 };

/** Hourly EMA50 vs EMA200 built from the candles themselves; returns (ts) → +1 | -1 | 0 using only hours closed by `ts`. */
function lbrTrend(candles) {
  const hours = []; let cur = -1;
  for (const c of candles) { const h = Math.floor(c.time / 3600); if (h !== cur) { cur = h; hours.push({ h, close: c.close }); } else hours[hours.length - 1].close = c.close; }
  const cl = hours.map((x) => x.close); const e50 = ema(cl, 50), e200 = ema(cl, 200);
  let p = -1;
  return (ts) => {
    while (p + 1 < hours.length && (hours[p + 1].h + 1) * 3600 <= ts) p++;
    if (p < 0 || e200[p] == null || e50[p] == null) return 0;
    return e50[p] > e200[p] ? 1 : e50[p] < e200[p] ? -1 : 0;
  };
}

export function backtestLbr(candles, opts) {
  const o = { ...DEFAULT_RULES, openOnLast: true, forced: null, edhPipPts: 1, ...opts };
  const L = { ...LBR_DEFAULTS, ...(o.lbr || {}) };
  const trades = []; const rejects = {}; let open = null; let pending = null;
  if (!candles?.length || candles.length < 300) return { trades, open, pending, rejects };
  const tfSec = edhStep(candles);
  if (tfSec !== 300) return { trades, open, pending, rejects: { tf: 1 } };   // rules are defined on 5-minute candles
  const pip = (o.edhPipPts || 1) * o.pointSize;
  const trend = lbrTrend(candles);
  const n = candles.length; const lastUsable = o.openOnLast ? n - 1 : n - 2;   // the newest candle may still be forming
  const barsMax = Math.round(L.maxMin / 5); const retestBars = Math.round(L.retestMin / 5);
  let day = null;   // state of the current UTC day
  for (let i = 0; i < n; i++) {
    const c = candles[i];
    if (open) {
      const long = open.direction === 'long';
      if (long ? c.low <= open.stop : c.high >= open.stop) { trades.push(finish(open, c, 'sl', open.stop, o)); open = null; }
      else if (long ? c.high >= open.targets[0] : c.low <= open.targets[0]) { open.hits = 1; trades.push(finish(open, c, 'tp1', open.targets[0], o)); open = null; }
      else if (i - open.openIndex >= barsMax) { trades.push(finish(open, c, 'time', c.close, o)); open = null; }
    }
    const d = Math.floor(c.time / 86400);
    const s = d * 86400 + L.startH * 3600; const e = s + L.rangeMin * 60;
    if (!day || day.d !== d) day = { d, hi: -Infinity, lo: Infinity, bars: 0, state: 'range' };
    if (c.time >= s && c.time < e) { day.hi = Math.max(day.hi, c.high); day.lo = Math.min(day.lo, c.low); day.bars++; continue; }
    if (c.time < e || day.state === 'done') continue;
    if (day.state === 'range') {
      if (day.bars < Math.round(L.rangeMin / 5)) { day.state = 'done'; continue; }   // gap in the data: no range
      const w = (day.hi - day.lo) / pip;
      if (w < L.minW || w > L.maxW) { rejects.width = (rejects.width || 0) + 1; day.state = 'done'; continue; }
      day.state = 'watch';
    }
    if (i > lastUsable) continue;
    if (day.state === 'watch') {
      if (c.time >= e + L.windowH * 3600) { day.state = 'done'; continue; }
      const dir = c.close > day.hi ? 1 : c.close < day.lo ? -1 : 0;
      if (!dir) continue;
      const direction = dir > 0 ? 'long' : 'short';
      if (trend(c.time + 300) !== dir) { rejects.trend = (rejects.trend || 0) + 1; day.state = 'done'; continue; }
      if ((o.forced && o.forced !== direction) || open) { day.state = 'done'; continue; }
      const edge = dir > 0 ? day.hi : day.lo;
      day.state = 'retest'; day.dir = dir; day.edge = edge; day.until = i + retestBars; day.breakTime = c.time;
      continue;
    }
    if (day.state === 'retest') {
      if (i > day.until) { rejects.noRetest = (rejects.noRetest || 0) + 1; day.state = 'done'; continue; }
      const { dir, edge } = day; const long = dir > 0;
      if (!(long ? c.low <= edge : c.high >= edge)) continue;
      day.state = 'done';
      const risk = L.sl * pip; const stop = edge - dir * risk; const tp = edge + dir * L.tp1 * pip;
      if (dayBlocks(trades, c, o, risk, edge) || monthBlocks(trades, c, o, risk, edge)) { rejects.cap = (rejects.cap || 0) + 1; continue; }
      const t = { strategy: 'lbr', direction: long ? 'long' : 'short', entry: edge, risk, hits: 0, openTime: c.time, openIndex: i, atrE: null, stop, initialStop: stop,
        targets: [tp, tp, tp], level: edge, range: { high: day.hi, low: day.lo }, breakTime: day.breakTime };
      // the filling candle: only the stop is checked (worst case), the target counts from the next candle
      if (long ? c.low <= stop : c.high >= stop) { trades.push(finish(t, c, 'sl', stop, o)); continue; }
      open = t;
    }
  }
  // Waiting for the retest on the newest candle → the limit order that is still working.
  if (!open && day?.state === 'retest' && n - 1 <= day.until) {
    const dir = day.dir; const risk = L.sl * pip;
    pending = { strategy: 'lbr', direction: dir > 0 ? 'long' : 'short', entry: day.edge, risk, stop: day.edge - dir * risk, initialStop: day.edge - dir * risk,
      targets: Array(3).fill(day.edge + dir * L.tp1 * pip), createdTime: day.breakTime, expiresTime: day.breakTime + 300 + L.retestMin * 60 };
  }
  return { trades, open, pending, rejects };
}

/** One entry point for the strategies: 'classic' | 'smc' | 'zone' | 'edh' | 'lbr'. */
export function runStrategy(strategy, candles, rules) {
  return (strategy === 'smc' ? backtestSmc : strategy === 'zone' ? backtestZone : strategy === 'edh' ? backtestEdh : strategy === 'lbr' ? backtestLbr : backtestClassic)(candles, rules);
}

const monthKey = (t) => { const d = new Date(t * 1000); return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`; };
// A win is a trade that ended with a net profit after fees (not just "touched TP1").
export const isWin = (t) => t.points > 0;

/** Wins / losses / win rate / net points, overall and per calendar month (UTC), newest month first. */
export function summarize(trades) {
  const agg = (list) => {
    const wins = list.filter(isWin).length;
    const points = list.reduce((a, t) => a + t.points, 0);
    const gross = list.filter((t) => t.points > 0).reduce((a, t) => a + t.points, 0);
    const loss = -list.filter((t) => t.points < 0).reduce((a, t) => a + t.points, 0);
    return {
      trades: list.length, wins, losses: list.length - wins, winRate: list.length ? (wins / list.length) * 100 : 0, points, grossWin: gross, grossLoss: loss,
      tp1: list.filter((t) => t.hits >= 1).length, tp2: list.filter((t) => t.hits >= 2).length, tp3: list.filter((t) => t.hits >= 3).length,
      profitFactor: loss > 0 ? gross / loss : gross > 0 ? Infinity : 0,
      // risk-normalised result: R is 1 = the amount risked per trade, so it compares timeframes and symbols fairly
      r: list.reduce((a, t) => a + (t.r || 0), 0), expectancy: list.length ? list.reduce((a, t) => a + (t.r || 0), 0) / list.length : 0,
      fees: list.reduce((a, t) => a + (t.fee || 0), 0),
      feeR: list.length ? list.reduce((a, t) => a + (t.feeR || 0), 0) / list.length : 0, // average fee cost per trade, in units of risk
    };
  };
  const byMonth = new Map();
  for (const t of trades) {
    const k = monthKey(t.closeTime);
    if (!byMonth.has(k)) byMonth.set(k, []);
    byMonth.get(k).push(t);
  }
  const months = [...byMonth.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1)).map(([month, list]) => ({ month, ...agg(list) }));
  const byDay = new Map();
  for (const t of trades) {
    const k = new Date(t.closeTime * 1000).toISOString().slice(0, 10);
    if (!byDay.has(k)) byDay.set(k, []);
    byDay.get(k).push(t);
  }
  const days = [...byDay.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1)).map(([day, list]) => ({ day, ...agg(list) }));
  let cum = 0;
  const equity = [...trades].sort((a, b) => a.closeTime - b.closeTime).map((t) => ({ time: t.closeTime, value: (cum += t.points) }));
  return { total: agg(trades), months, days, equity };
}

/** Rules from the user's settings (Settings → trading plan). */
/** Daily loss limit in R: the account % limit divided by the risk per trade (e.g. 2% / 1% = 2R). */
export function dailyStopR(settings) {
  const r = settings?.risk || {};
  const lim = Number(r.dailyLossPct); const per = Number(r.riskPct);
  return lim > 0 && per > 0 ? lim / per : 0;
}

export function rulesFrom(settings, inst) {
  const p = settings?.plan || {};
  // Default cost per round trip: ~0.1% on crypto (exchange fees), ~0.03% on gold/indices (spread).
  const defFee = inst?.type === 'crypto' ? 0.1 : 0.03;
  return {
    stopMode: p.stopMode === 'points' ? 'points' : 'atr',
    atrMult: Number(p.atrMult) > 0 ? Number(p.atrMult) : DEFAULT_RULES.atrMult,
    htfTrendHours: p.htfTrendHours != null && p.htfTrendHours !== '' && Number.isFinite(Number(p.htfTrendHours)) ? Math.max(0, Number(p.htfTrendHours)) : DEFAULT_RULES.htfTrendHours,
    tpGapPts: p.tpGapPts != null && p.tpGapPts !== '' && Number.isFinite(Number(p.tpGapPts)) ? Math.max(0, Number(p.tpGapPts)) : DEFAULT_RULES.tpGapPts,
    tp3GapPts: p.tp3GapPts != null && p.tp3GapPts !== '' && Number.isFinite(Number(p.tp3GapPts)) ? Math.max(0, Number(p.tp3GapPts)) : DEFAULT_RULES.tp3GapPts,
    tpR: Array.isArray(p.tpR) && p.tpR.length === 3 ? p.tpR.map(Number) : DEFAULT_RULES.tpR,
    trendFilter: p.trendFilter !== false,
    feePct: p.feePct != null && p.feePct !== '' && Number.isFinite(Number(p.feePct)) ? Number(p.feePct) : defFee,
    forced: p.direction === 'long' || p.direction === 'short' ? p.direction : null,
    // "High accuracy": first target at 0.35R — raises the win rate (TP1 is reached more often),
    // but tested on real data it does not raise the net result.
    // Close first target (0.35R): touches TP1 more often, but after fees most of those trades
    // still lose money — so it is off by default.
    firstTargetR: p.closeFirstTarget ? 0.35 : 0,
    maxPerDay: Number(p.maxPerDay) > 0 ? Math.round(Number(p.maxPerDay)) : 0,
    // Tested on real BTC data 2023–2026: skipping trades whose stop is smaller than 5× the fee
    // (fees would eat the profit) and, for SMC, following the trend of a 4× higher timeframe
    // cut losses on 15m/1h by roughly half to 90%.
    minRiskPct: 5 * (p.feePct != null && p.feePct !== '' && Number.isFinite(Number(p.feePct)) ? Number(p.feePct) : defFee),
    // SMC v2 (services/smc2.js)
    smcMinScore: Number.isFinite(Number(settings?.smc2?.minScore)) ? Math.max(0, Math.min(100, Number(settings.smc2.minScore))) : SMC2_DEFAULTS.minScore,
    smcKillZone: settings?.smc2?.killZone !== false,
    smcHtf: settings?.smc2?.htf !== false,
    // Optional SMC rules (Settings → SMC v2); the defaults are the original strict ones.
    smcOpts: (() => {
      const q = settings?.smc2 || {}; const n = (v, d, lo, hi) => (Number.isFinite(Number(v)) && v !== '' && v !== null && v !== undefined ? Math.max(lo, Math.min(hi, Number(v))) : d);
      return { htfMode: ['both', 'h4', 'd1'].includes(q.htfMode) ? q.htfMode : SMC2_OPTS.htfMode, reversal: !!q.reversal, rsiGate: !!q.rsiGate,
        minDisp: n(q.minDisp, SMC2_OPTS.minDisp, 0.3, 4), fvgMin: n(q.fvgMin, SMC2_OPTS.fvgMin, 0, 2), maxAfterTap: Math.round(n(q.maxAfterTap, SMC2_OPTS.maxAfterTap, 3, 60)),
        stopBufAtr: n(q.stopBufAtr, SMC2_OPTS.stopBufAtr, 0, 2), maxRiskAtr: n(q.maxRiskAtr, SMC2_OPTS.maxRiskAtr, 1, 10) };
    })(),
    zoneMinScore: Number.isFinite(Number(settings?.zone?.minScore)) ? Math.max(0, Math.min(100, Number(settings.zone.minScore))) : ZONE_DEFAULTS.minScore,
    zoneHtf: settings?.zone?.htf !== false,
    zoneRequireVp: settings?.zone?.requireVp !== false,
    zoneMinVol: Number(settings?.zone?.minVolRatio) > 0 ? Number(settings.zone.minVolRatio) : ZONE_DEFAULTS.minVolRatio,
    zoneMinRR: Number(settings?.zone?.minRR) >= 0 && settings?.zone?.minRR !== '' && settings?.zone?.minRR != null ? Number(settings.zone.minRR) : ZONE_DEFAULTS.minRR,
    zoneTimeStop: 0,
    zoneQuant: settings?.zone?.quant !== false && can('quant'),
    zoneRegimeW: settings?.zone?.regimeWeights !== false,
    zoneZGate: Number(settings?.zone?.zGate) > 0 ? Number(settings.zone.zGate) : 0,
    zoneFlowGate: settings?.zone?.flowGate === true,
    trailAtr: Number(p.trailAtr) > 0 ? Number(p.trailAtr) : 0, // 0 = no ATR trailing stop
    dailyStopR: dailyStopR(settings),
    // 0 = no monthly cap. One number cannot suit every asset (a point is $1 on BTC, $0.1 on ETH, $0.01 on SOL), so a per-symbol value wins.
    edh: { ...EDH_DEFAULTS, ...(settings?.edh || {}) },
    lbr: { ...LBR_DEFAULTS, ...(settings?.lbr || {}) },
    edhPipPts: inst?.type === 'index' ? 1 : 10, // 1 pip = 10 points (gold, crypto); 1 point on indices
    exec: settings?.exec ? normalizeExec(settings.exec) : null,
    dailyCapPts: Number(settings?.risk?.dailyLossPts) > 0 ? Number(settings.risk.dailyLossPts) : 0,
    monthlyCapPts: Number(settings?.risk?.monthlyLossBySymbol?.[inst?.symbol]) > 0 ? Number(settings.risk.monthlyLossBySymbol[inst.symbol]) : (Number(settings?.risk?.monthlyLossPts) > 0 ? Number(settings.risk.monthlyLossPts) : 0),
    beAtR: Number(p.beAtR) > 0 ? Number(p.beAtR) : 0, // 0 = breakeven only after target 1
    smcTimeStop: 0, // optional time stop (candles without reaching target 1); off by default
  };
}
