// Custom alerts. Checked every 5 seconds while the app is open (any page):
//  • price above / below a level;
//  • 24h change above / below a percentage;
//  • high-impact economic news (Forex Factory calendar) N minutes before release.
// A triggered alert shows an in-app toast and a phone/desktop notification (same channel as signals).
import { storage } from '../utils/storage.js';
import { getTickers, getCandles } from './market/index.js';
import { ruleMetrics, testRule, volatilityState } from './radarAnalytics.js';
import { INSTRUMENTS } from '../config/instruments.js';
import { getCalendar } from './news.js';
import { notify } from './signals.js';
import { t } from '../i18n/index.js';
import { fmtNum } from '../utils/dom.js';
import { getInstrument } from '../config/instruments.js';

const KEY = 'alerts';
const LOG_KEY = 'alerts-log';
const CHECK_MS = 5000;
export const ALERT_KINDS = ['above', 'below', 'chgUp', 'chgDown'];

const state = {
  alerts: storage.get(KEY, []),
  log: storage.get(LOG_KEY, []),
  news: storage.get('alerts-news', { enabled: false, minutes: 15, impact: 'High', ccys: ['USD'] }),
  prices: {},          // symbol → { price, changePct, mode }
  rules: storage.get('alerts-rules', []),   // multi-condition rules
  ruleStatus: {},      // rule id → { ok, results, at }
  volWatch: storage.get('alerts-vol', { enabled: false, tf: '15m' }),
  lastCheck: null,
};
const notifiedNews = new Set(storage.get('alerts-news-sent', []));
const listeners = new Set();
let timer = null;

export const alertState = () => state;
export const onAlerts = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = () => listeners.forEach((fn) => { try { fn(state); } catch (e) { console.error(e); } });
const save = () => { storage.set(KEY, state.alerts); storage.set(LOG_KEY, state.log.slice(0, 50)); };

export function addAlert({ symbol, kind, value, repeat = false, note = '' }) {
  const a = { id: `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`, symbol, kind, value: Number(value), repeat: !!repeat, note: String(note || '').slice(0, 80), active: true, armed: true, createdAt: Date.now(), triggeredAt: null, count: 0 };
  state.alerts.unshift(a);
  save(); emit(); check();
  return a;
}
export function removeAlert(id) { state.alerts = state.alerts.filter((a) => a.id !== id); save(); emit(); }
export function toggleAlert(id) {
  const a = state.alerts.find((x) => x.id === id);
  if (a) { a.active = !a.active; a.armed = true; save(); emit(); }
}
export function clearLog() { state.log = []; save(); emit(); }
export function setNewsAlerts(patch) {
  state.news = { ...state.news, ...patch };
  storage.set('alerts-news', state.news);
  emit(); checkNews();
}

export function describeAlert(a) {
  const p = getInstrument(a.symbol).precision;
  if (a.kind === 'above') return t('tools.alerts.descAbove', { s: a.symbol, v: fmtNum(a.value, p) });
  if (a.kind === 'below') return t('tools.alerts.descBelow', { s: a.symbol, v: fmtNum(a.value, p) });
  if (a.kind === 'chgUp') return t('tools.alerts.descChgUp', { s: a.symbol, v: fmtNum(a.value, 2) });
  return t('tools.alerts.descChgDown', { s: a.symbol, v: fmtNum(Math.abs(a.value), 2) });
}

function condition(a, tk) {
  if (a.kind === 'above') return tk.price >= a.value;
  if (a.kind === 'below') return tk.price <= a.value;
  if (a.kind === 'chgUp') return tk.changePct >= a.value;
  return tk.changePct <= -Math.abs(a.value);
}

function fire(a, tk) {
  const p = getInstrument(a.symbol).precision;
  const title = t('tools.alerts.firedTitle', { s: a.symbol });
  const body = `${describeAlert(a)}\n${t('tools.alerts.nowPrice')}: ${fmtNum(tk.price, p)}${a.note ? `\n${a.note}` : ''}`;
  a.triggeredAt = Date.now();
  a.count = (a.count || 0) + 1;
  state.log.unshift({ at: Date.now(), title, body, symbol: a.symbol });
  notify(title, body, `alert-${a.id}`);
}

export async function check() {
  const active = state.alerts.filter((a) => a.active);
  if (!active.length) { state.lastCheck = Date.now(); return; }
  let tk;
  try { tk = await getTickers([...new Set(active.map((a) => a.symbol))]); } catch { return; }
  let changed = false;
  for (const a of active) {
    const q = tk[a.symbol];
    if (!q || q.mode !== 'live' || !Number.isFinite(q.price)) continue;
    state.prices[a.symbol] = { price: q.price, changePct: q.changePct, mode: q.mode };
    const on = condition(a, q);
    if (on && a.armed) {
      fire(a, q);
      a.armed = false;
      if (!a.repeat) a.active = false;
      changed = true;
    } else if (!on && !a.armed && a.repeat) { a.armed = true; changed = true; } // re-arm once the condition clears
  }
  state.lastCheck = Date.now();
  if (changed) save();
  emit();
}

export async function checkNews() {
  if (!state.news.enabled) return;
  let cal;
  try { cal = await getCalendar(); } catch { return; }
  const now = Date.now();
  const lead = Math.max(1, Number(state.news.minutes) || 15) * 60_000;
  const impacts = state.news.impact === 'Medium' ? ['High', 'Medium'] : ['High'];
  for (const e of cal.events) {
    if (!impacts.includes(e.impact)) continue;
    if (state.news.ccys?.length && !state.news.ccys.includes(e.country)) continue;
    const dt = e.time - now;
    if (dt <= 0 || dt > lead || notifiedNews.has(e.id)) continue;
    notifiedNews.add(e.id);
    const mins = Math.max(1, Math.round(dt / 60_000));
    const title = t('tools.alerts.newsTitle', { c: e.country, m: mins });
    const body = `${e.title}${e.forecast ? ` · ${t('tools.cal.forecast')}: ${e.forecast}` : ''}${e.previous ? ` · ${t('tools.cal.previous')}: ${e.previous}` : ''}`;
    state.log.unshift({ at: now, title, body, symbol: e.country });
    notify(title, body, `news-${e.id}`);
  }
  storage.set('alerts-news-sent', [...notifiedNews].slice(-200));
  save(); emit();
}

let newsTick = 0;
/* ───────── Multi-condition rules (checked every 30 s) ───────── */
const saveRules = () => storage.set('alerts-rules', state.rules);
export function addRule(rule) {
  state.rules.unshift({ id: `r${Date.now().toString(36)}`, active: true, armed: true, count: 0, lastFired: null, cooldownMin: 30, logic: 'and', ...rule });
  saveRules(); emit(); checkRules();
}
export function removeRule(id) { state.rules = state.rules.filter((r) => r.id !== id); delete state.ruleStatus[id]; saveRules(); emit(); }
export function toggleRule(id) { const r = state.rules.find((x) => x.id === id); if (r) { r.active = !r.active; r.armed = true; saveRules(); emit(); } }

let rulesBusy = false;
export async function checkRules() {
  const active = state.rules.filter((r) => r.active);
  if (!active.length || rulesBusy) return;
  rulesBusy = true;
  try {
    const keys = [...new Set(active.flatMap((r) => r.conds.map((c) => `${r.symbol}|${c.tf || r.tf}`)))];
    const metrics = {};
    for (const k of keys) {
      const [sym, tf] = k.split('|');
      try { const ds = await getCandles(sym, tf); if (ds.mode === 'live' && ds.candles.length > 210) metrics[k] = ruleMetrics(ds.candles); } catch { /* skip */ }
    }
    let changed = false;
    for (const r of active) {
      const res = testRule(r, metrics);
      state.ruleStatus[r.id] = { ...res, at: Date.now(), price: metrics[`${r.symbol}|${r.tf}`]?.price };
      const cool = !r.lastFired || Date.now() - r.lastFired >= (r.cooldownMin || 30) * 60_000;
      if (res.ok && r.armed && cool) {
        r.armed = false; r.lastFired = Date.now(); r.count = (r.count || 0) + 1; changed = true;
        const title = t('tools.rules.firedTitle', { n: r.name || r.symbol });
        const body = `${r.symbol} · ${t(`perf.tfShort.${r.tf}`)} — ${t(r.logic === 'or' ? 'tools.rules.anyMet' : 'tools.rules.allMet', { n: r.conds.length })}`;
        state.log.unshift({ at: Date.now(), title, body, symbol: r.symbol });
        notify(title, body, `rule-${r.id}`);
        if (r.once) r.active = false;
      } else if (!res.ok && !r.armed) { r.armed = true; changed = true; }
    }
    if (changed) { saveRules(); save(); }
    emit();
  } finally { rulesBusy = false; }
}

/* ───────── Volatility watch (every minute) ───────── */
const volSent = new Map();
export async function checkVol() {
  if (!state.volWatch.enabled) return;
  for (const inst of INSTRUMENTS) {
    try {
      const ds = await getCandles(inst.symbol, state.volWatch.tf);
      if (ds.mode !== 'live') continue;
      const v = volatilityState(ds.candles);
      const bar = ds.candles.at(-1).time;
      if (v?.state === 'spike' && volSent.get(inst.symbol) !== bar) {
        volSent.set(inst.symbol, bar);
        const title = t('tools.vol.alertTitle', { s: inst.symbol });
        const body = t('tools.vol.alertBody', { r: fmtNum(v.ratio, 1), tf: t(`perf.tfShort.${state.volWatch.tf}`) });
        state.log.unshift({ at: Date.now(), title, body, symbol: inst.symbol });
        notify(title, body, `vol-${inst.symbol}`);
        save(); emit();
      }
    } catch { /* skip */ }
  }
}

export function startAlerts() {
  if (timer) return;
  check();
  checkNews();
  setTimeout(() => { checkRules(); checkVol(); }, 3000);
  timer = setInterval(() => {
    check();
    if (newsTick % 6 === 5) checkRules(); // every 30 s
    if (newsTick % 12 === 11) checkVol(); // every minute
    if (++newsTick % 12 === 0) checkNews(); // every minute
  }, CHECK_MS);
}
export function stopAlerts() { clearInterval(timer); timer = null; }
