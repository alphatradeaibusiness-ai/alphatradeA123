// Switching strategies. Turning SMC on saves which indicator overlays were on and switches
// them off, so the chart only shows the SMC drawings; turning it off restores them.
import { store } from '../state/store.js';

const TOOLS = ['vp', 'frvp', 'fib', 'zones', 'ema', 'rsi'];

export function setStrategy(next) {
  const s = structuredClone(store.get('settings'));
  if (next === s.strategy) return;
  if (next === 'smc' || next === 'zone' || next === 'edh') {
    // switching between smc and zone keeps the tools saved when the first one was turned on
    if (s.strategy === 'classic' || !s.preSmc) {
      s.preSmc = Object.fromEntries(TOOLS.map((k) => [k, Boolean(s[k]?.enabled)]));
      TOOLS.forEach((k) => { if (s[k]) s[k].enabled = false; });
    }
    s.strategy = next;
  } else {
    if (s.preSmc) TOOLS.forEach((k) => { if (s[k] && k in s.preSmc) s[k].enabled = s.preSmc[k]; });
    s.preSmc = null;
    s.strategy = 'classic';
  }
  store.set('settings', s);
}
