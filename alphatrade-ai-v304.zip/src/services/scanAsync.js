// Runs a scan job (scanJobs.js) in the scan Web Worker and resolves with its result. No Worker (the headless server
// worker, tests, old browsers) or a worker failure → the same job runs on the current thread, so nothing is ever lost.
let worker = null; let broken = typeof Worker === 'undefined' || typeof window === 'undefined';
let seq = 0; const pending = new Map();
let jobsMod = null;
const local = async (kind, payload) => { jobsMod ||= await import('./scanJobs.js'); return jobsMod.SCAN_JOBS[kind](payload); };

function getWorker() {
  if (broken) return null;
  if (worker) return worker;
  try {
    worker = new Worker(new URL('./scanWorker.js', import.meta.url), { type: 'module' });
    worker.onmessage = (e) => { const p = pending.get(e.data?.id); if (!p) return; pending.delete(e.data.id); e.data.error ? p.reject(new Error(e.data.error)) : p.resolve(e.data.result); };
    worker.onerror = (e) => { e.preventDefault?.(); fail(); };
    return worker;
  } catch { broken = true; return null; }
}
function fail() {
  broken = true; try { worker?.terminate(); } catch { /* gone */ }
  worker = null;
  const jobs = [...pending.values()]; pending.clear();
  for (const j of jobs) local(j.kind, j.payload).then(j.resolve, j.reject);
}

/** Resolves with SCAN_JOBS[kind](payload), computed off the main thread when possible. */
export function scanJob(kind, payload) {
  const w = getWorker();
  if (!w) return local(kind, payload);
  return new Promise((resolve, reject) => {
    const id = ++seq; pending.set(id, { kind, payload, resolve, reject });
    try { w.postMessage({ id, kind, payload }); } catch { pending.delete(id); local(kind, payload).then(resolve, reject); }
  });
}
