// EDH add-on: liquidity-sweep zones and order blocks, drawn beside yesterday's high/low and usable as optional entry filters.
//  - Sweep: a confirmed swing high/low (5 bars each side) that a later candle wicked beyond but closed back inside (the stop hunt).
//    A sell sweep (swing high taken) leans bearish; a buy sweep (swing low taken) leans bullish.
//  - Order block: the last opposite candle before a displacement (a move of >= 2 x ATR inside 3 candles); valid until a candle closes through it.
// edhTimeline() keeps the index at which each item became known, so a backtest never uses the future.
import { atr } from '../indicators/index.js';

export function edhTimeline(candles, { pivot = 5, lookAhead = 40, disp = 2 } = {}) {
  const n = candles.length;
  if (n < pivot * 2 + 20) return { sweeps: [], obs: [] };
  const A = atr(candles, 14);
  const sweeps = [];
  for (let i = pivot; i < n - pivot; i++) {
    const c = candles[i];
    let isH = true; let isL = true;
    for (let k = 1; k <= pivot; k++) {
      if (candles[i - k].high >= c.high || candles[i + k].high > c.high) isH = false;
      if (candles[i - k].low <= c.low || candles[i + k].low < c.low) isL = false;
    }
    if (!isH && !isL) continue;
    for (let j = i + pivot + 1; j < Math.min(n, i + pivot + 1 + lookAhead); j++) {
      const d = candles[j];
      if (isH && d.high > c.high) { if (d.close < c.high) sweeps.push({ dir: 'sell', price: c.high, extreme: d.high, time: c.time, sweepTime: d.time, idx: j }); break; }
      if (isL && d.low < c.low) { if (d.close > c.low) sweeps.push({ dir: 'buy', price: c.low, extreme: d.low, time: c.time, sweepTime: d.time, idx: j }); break; }
    }
  }
  const obs = [];
  for (let i = 1; i < n - 3; i++) {
    const a = A[i]; if (!a) continue;
    const c = candles[i];
    const maxH = Math.max(candles[i + 1].high, candles[i + 2].high, candles[i + 3].high);
    const minL = Math.min(candles[i + 1].low, candles[i + 2].low, candles[i + 3].low);
    let dir = null;
    if (c.close < c.open && maxH - c.high >= disp * a && maxH > c.high) dir = 'bull';
    else if (c.close > c.open && c.low - minL >= disp * a && minL < c.low) dir = 'bear';
    if (!dir) continue;
    let mitigated = false; let dead = null;
    for (let j = i + 4; j < n; j++) {
      if (dir === 'bull') { if (candles[j].close < c.low) { dead = j; break; } if (candles[j].low <= c.high) mitigated = true; }
      else { if (candles[j].close > c.high) { dead = j; break; } if (candles[j].high >= c.low) mitigated = true; }
    }
    obs.push({ dir, top: c.high, bottom: c.low, time: c.time, from: i + 3, dead, mitigated });
  }
  return { sweeps, obs };
}

export function edhZones(candles, { maxSweeps = 3, maxObs = 2, ...tl } = {}) {
  const { sweeps, obs } = edhTimeline(candles, tl);
  const last = (arr, k) => arr.slice(-k);
  const alive = obs.filter((o) => o.dead == null);
  return {
    sweeps: [...last(sweeps.filter((s) => s.dir === 'sell'), maxSweeps), ...last(sweeps.filter((s) => s.dir === 'buy'), maxSweeps)],
    obs: [...last(alive.filter((o) => o.dir === 'bull'), maxObs), ...last(alive.filter((o) => o.dir === 'bear'), maxObs)],
  };
}
