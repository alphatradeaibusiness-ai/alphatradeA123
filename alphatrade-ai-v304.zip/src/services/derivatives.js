// Futures positioning: funding rate and open interest (Binance USDT-M, public endpoints, no key).
// Read together with price they show crowding and liquidation sweeps:
//   • crowded longs  (funding high / OI building)  → buying here is buying where everyone already is
//   • crowded shorts (funding negative)            → selling here is selling where everyone already is
//   • long flush     (price falls, OI collapses)   → longs were liquidated; selling after it is chasing
//   • short squeeze  (price jumps, OI collapses)   → shorts were liquidated; buying after it is chasing
// This cannot be back-tested (the exchange keeps only ~30 days of open-interest history), so it only
// works as a LIVE gate on new signals — never as a claim about historical accuracy.
import { marketConfig } from '../config/market.js';
import { fetchJson } from '../utils/http.js';

export const DERIV_SYMBOLS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT'];
export const TH = {
  fundingHot: 0.0003,    // 0.03% per 8h: longs are paying a lot
  fundingExtreme: 0.0005,
  fundingCold: -0.0001,  // shorts are paying
  oiBuild4h: 3,          // % open interest growth over 4h that adds weight to funding
  flushOi1h: -1.5,       // % OI drop in 1h
  flushPrice1h: 0.6,     // % price move in 1h that goes with it
};
const TTL = 60_000;
const memo = new Map();

const pct = (a, b) => (b ? ((a - b) / b) * 100 : null);

/** Funding rate, open-interest change (1h / 4h) and price change (1h) for one symbol; null if unavailable. */
export async function getDerivs(symbol) {
  if (!DERIV_SYMBOLS.includes(symbol)) return null;
  const hit = memo.get(symbol);
  if (hit && Date.now() - hit.at < TTL) return hit.data;
  const base = marketConfig.binanceFuturesUrl;
  const o = { timeoutMs: marketConfig.requestTimeoutMs };
  let data = null;
  try {
    const [prem, oi, kl] = await Promise.all([
      fetchJson(`${base}/fapi/v1/premiumIndex?symbol=${symbol}`, o),
      fetchJson(`${base}/futures/data/openInterestHist?symbol=${symbol}&period=15m&limit=17`, o),
      fetchJson(`${base}/fapi/v1/klines?symbol=${symbol}&interval=5m&limit=13`, o),
    ]);
    const oiv = (Array.isArray(oi) ? oi : []).map((r) => +r.sumOpenInterest).filter(Number.isFinite);
    const closes = (Array.isArray(kl) ? kl : []).map((r) => +r[4]).filter(Number.isFinite);
    data = {
      symbol, at: Date.now(),
      funding: Number.isFinite(+prem.lastFundingRate) ? +prem.lastFundingRate : null,
      oiChange1h: oiv.length >= 5 ? pct(oiv.at(-1), oiv.at(-5)) : null,
      oiChange4h: oiv.length >= 2 ? pct(oiv.at(-1), oiv[0]) : null,
      priceChange1h: closes.length >= 2 ? pct(closes.at(-1), closes[0]) : null,
    };
    if (data.funding == null && data.oiChange1h == null) data = null;
  } catch { data = null; }
  memo.set(symbol, { at: Date.now(), data });
  return data;
}

/** Pure reading of the numbers: which of the four situations is on. */
export function readDerivs(d) {
  if (!d) return null;
  const f = d.funding;
  const oiUp = d.oiChange4h != null && d.oiChange4h >= TH.oiBuild4h;
  const crowdedLongs = f != null && (f >= TH.fundingExtreme || (f >= TH.fundingHot && (oiUp || d.oiChange4h == null)) );
  const crowdedShorts = f != null && f <= TH.fundingCold;
  const oiCollapse = d.oiChange1h != null && d.oiChange1h <= TH.flushOi1h;
  const longFlush = oiCollapse && d.priceChange1h != null && d.priceChange1h <= -TH.flushPrice1h;
  const shortSqueeze = oiCollapse && d.priceChange1h != null && d.priceChange1h >= TH.flushPrice1h;
  return { ...d, crowdedLongs, crowdedShorts, longFlush, shortSqueeze };
}

/** May a new trade in `direction` be opened right now? `{ ok:true }` or `{ ok:false, key, params }`. */
export function derivCheck(read, direction) {
  if (!read) return { ok: true };
  const f = read.funding != null ? `${(read.funding * 100).toFixed(3)}%` : '—';
  if (direction === 'long') {
    if (read.crowdedLongs) return { ok: false, key: 'crowdedLongs', params: { f } };
    if (read.shortSqueeze) return { ok: false, key: 'shortSqueeze', params: { f } };
  } else {
    if (read.crowdedShorts) return { ok: false, key: 'crowdedShorts', params: { f } };
    if (read.longFlush) return { ok: false, key: 'longFlush', params: { f } };
  }
  return { ok: true };
}
