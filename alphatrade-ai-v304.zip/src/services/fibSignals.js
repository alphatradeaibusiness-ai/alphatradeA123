// What the Fibonacci lines are telling right now:
//
//   breaks  — a candle CLOSED through a line: down through it = "sell" (the label goes under the line),
//             up through it = "buy" (the label goes above the line). The forming candle can show the same
//             as a provisional break ("live") that is only confirmed when the candle closes. A break only
//             counts when the close is clearly beyond the line (0.1 ATR) so a wick or a hair-width cross is
//             ignored, and it disappears again if price closes back on the other side.
//   strong  — a Fibonacci line where other, independent levels sit at the same price: the volume profile's
//             point of control or a high-volume node, a supply/demand zone, a swing high/low that price
//             reacted at twice or more, an EMA 50/200, an SMC order block. The more of them, the stronger.
//             A strong zone below price is support, above price resistance.
// Pure functions — nothing here reads the store or the network.
import { atr, ema, volumeProfile } from '../indicators/index.js';
import { findSwings } from '../indicators/smc.js';
import { prepare as zonePrepare } from './zoneStrategy.js';

const MARGIN_ATR = 0.1;   // how far beyond the line a close must be to count as a break
const MAX_AGE = 40;       // candles a break label stays on the chart
const SCAN = 90;          // candles scanned for breaks
const TOL_ATR = 0.35;     // price distance (in ATR) within which two levels count as the same place
export const CONFLUENCE_KEYS = ['poc', 'hvn', 'zone', 'swing', 'ema', 'ob'];

/**
 * Fibonacci anchors that follow the market: the newest confirmed swing leg (last swing high + last swing low,
 * confirmed 3 candles later), with the leg's end stretched to the newest extreme (including the forming candle).
 * Every new swing — which is what follows each buy/sell break — redraws the Fibonacci on the new leg.
 * Returns null when there are no swings or the leg is smaller than 2 ATR (the caller falls back to the
 * lookback extremes).
 */
export function legAnchors(candles, lookback = 120) {
  const n = candles.length;
  if (n < 40) return null;
  const closed = candles.slice(0, -1);
  const from = Math.max(0, closed.length - Math.max(lookback, 60));
  const sw = findSwings(closed, 3).filter((s) => s.index >= from);
  const H = [...sw].reverse().find((s) => s.type === 'high');
  const L = [...sw].reverse().find((s) => s.type === 'low');
  if (!H || !L) return null;
  let high = H.price, highTime = H.time, low = L.price, lowTime = L.time;
  for (let k = H.index + 1; k < n; k++) if (candles[k].high > high) { high = candles[k].high; highTime = candles[k].time; }
  for (let k = L.index + 1; k < n; k++) if (candles[k].low < low) { low = candles[k].low; lowTime = candles[k].time; }
  const a = atr(candles, 14)[n - 2] || 0;
  if (!(high > low) || (high - low) < 2 * a) return null;
  return { high, highTime, low, lowTime };
}

/**
 * Latest valid break of every Fibonacci line.
 * @param candles all candles (the last one may still be forming)
 * @param levels  [{ ratio, price }]
 * @param htf     optional higher-timeframe trend per candle (+1 / -1) — adds `htfAgrees` to every break
 * @returns [{ ratio, price, dir:'buy'|'sell', time, index, live, htfAgrees }]
 */
export function fibBreaks(candles, levels, { margin = MARGIN_ATR, maxAge = MAX_AGE, htf = null } = {}) {
  const n = candles.length;
  if (n < 30 || !levels?.length) return [];
  const a = atr(candles, 14);
  const out = [];
  for (const lv of levels) {
    let side = 0; let ev = null;
    for (let k = Math.max(1, n - SCAN); k < n; k++) {
      const m = margin * (a[k] || a[k - 1] || 0);
      const d = candles[k].close - lv.price;
      const s = d > m ? 1 : d < -m ? -1 : 0;
      if (!s) continue;
      if (side && s !== side) ev = { ratio: lv.ratio, price: lv.price, dir: s > 0 ? 'buy' : 'sell', time: candles[k].time, index: k, live: k === n - 1, htfAgrees: htf ? (htf[Math.min(k, htf.length - 1)] || 0) === (s > 0 ? 1 : -1) : null };
      side = s;
    }
    // valid only while price is still on the broken side, and recent enough
    if (ev && n - 1 - ev.index <= maxAge) {
      const now = candles[n - 1].close - lv.price;
      if (ev.dir === 'buy' ? now > 0 : now < 0) out.push(ev);
    }
  }
  return out;
}

/** Levels (price + kind) that can sit on a Fibonacci line. Computed from CLOSED candles only. */
function otherLevels(closed, { smc = null, hasVolume = true } = {}) {
  const lv = [];
  const n = closed.length;
  const last = n - 1;
  const closes = closed.map((c) => c.close);
  if (hasVolume && n >= 60) {
    const vp = volumeProfile(closed, { rows: 40, from: Math.max(0, n - 200), to: last, valueAreaPct: 70 });
    if (vp) {
      lv.push({ key: 'poc', lo: vp.poc - vp.step / 2, hi: vp.poc + vp.step / 2 });
      vp.bins.forEach((b) => { if (b.volume >= 0.7 * vp.maxVolume && !(b.low <= vp.poc && vp.poc <= b.high)) lv.push({ key: 'hvn', lo: b.low, hi: b.high }); });
    }
  }
  // swing highs / lows that price reacted at at least twice (within a small distance of each other)
  const a = atr(closed, 14)[last] || 0;
  const sw = findSwings(closed, 2).filter((s) => s.index >= n - 300);
  for (const s of sw) {
    const same = sw.filter((o) => Math.abs(o.price - s.price) <= TOL_ATR * a).length;
    if (same >= 2) lv.push({ key: 'swing', lo: s.price, hi: s.price });
  }
  // supply / demand zones that are still alive and fresh
  if (n >= 150) {
    const S = zonePrepare(closed);
    for (const z of S.zones) {
      if (z.dead <= last || last - z.known > 400) continue;
      if (z.episodes.filter((e) => e <= last).length > 2) continue;
      lv.push({ key: 'zone', lo: z.bottom, hi: z.top, dir: z.dir });
    }
  }
  for (const [p, arr] of [[50, ema(closes, 50)], [200, ema(closes, 200)]]) { const v = arr[last]; if (v != null) lv.push({ key: 'ema', lo: v, hi: v, p }); }
  for (const o of smc?.obs || []) lv.push({ key: 'ob', lo: o.bottom, hi: o.top });
  return lv;
}

/**
 * Fibonacci lines with other levels at the same price. Strength = number of different kinds of level
 * that match (+1 for the golden pocket 0.5 / 0.618, where reversals are most often looked for).
 * @returns [{ ratio, price, top, bottom, side:'support'|'resistance', kinds:[...], strength }]  strongest first
 */
export function strongZones(closed, levels, opts = {}) {
  const n = closed.length;
  if (n < 60 || !levels?.length) return [];
  const a = atr(closed, 14)[n - 1];
  if (!(a > 0)) return [];
  const others = otherLevels(closed, opts);
  const price = closed[n - 1].close;
  const tol = TOL_ATR * a;
  const out = [];
  for (const lv of levels) {
    const kinds = new Set();
    let lo = lv.price - 0.25 * a; let hi = lv.price + 0.25 * a;
    for (const o of others) {
      if (o.lo - tol <= lv.price && lv.price <= o.hi + tol) {
        kinds.add(o.key);
        if (o.key === 'zone' || o.key === 'ob') { lo = Math.min(lo, o.lo); hi = Math.max(hi, o.hi); }
      }
    }
    const golden = lv.ratio === 0.5 || lv.ratio === 0.618;
    const strength = kinds.size + (golden ? 1 : 0);
    if (opts.all || (kinds.size >= 1 && strength >= 2)) out.push({ ratio: lv.ratio, price: lv.price, top: hi, bottom: lo, side: lv.price <= price ? 'support' : 'resistance', kinds: CONFLUENCE_KEYS.filter((k) => kinds.has(k)), strength });
  }
  out.sort((x, y) => y.strength - x.strength);
  return opts.all ? out : out.slice(0, 3);
}
