// Pure analytics used by the Alpha Radar sections: best timeframe, volatility monitor, liquidity
// detector, automatic risk sizing, multi-condition alert evaluation and radar-call scoring.
import { ema, rsi, atr } from '../indicators/index.js';
import { findSwings, findStructure, findLiquidity } from '../indicators/smc.js';

const mean = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0);
const std = (a) => { const m = mean(a); return Math.sqrt(mean(a.map((x) => (x - m) ** 2))); };

/** Kaufman efficiency ratio: |net move| ÷ path length (1 = clean trend, ~0 = noise). */
export function efficiencyRatio(candles, n = 50) {
  const c = candles.slice(-n - 1).map((x) => x.close);
  if (c.length < 3) return 0;
  let path = 0;
  for (let i = 1; i < c.length; i++) path += Math.abs(c[i] - c[i - 1]);
  return path ? Math.abs(c.at(-1) - c[0]) / path : 0;
}



/** Volatility monitor for one candle series. */
export function volatilityState(candles, period = 14) {
  const n = candles.length;
  if (n < 120) return null;
  const a = atr(candles, period);
  const closes = candles.map((c) => c.close);
  const atrPct = a.map((v, i) => (v ? (v / closes[i]) * 100 : null));
  const recent = atrPct.slice(-100).filter((v) => v != null);
  const now = atrPct[n - 1];
  const avg = mean(recent);
  const ratio = avg ? now / avg : 1;
  const pctRank = recent.filter((v) => v <= now).length / recent.length * 100;
  // Bollinger band width (20, 2) and its percentile over the last 120 candles → squeeze.
  const bbw = [];
  for (let i = 19; i < n; i++) {
    const w = closes.slice(i - 19, i + 1);
    const m = mean(w); const s = std(w);
    bbw.push(m ? (4 * s) / m * 100 : 0);
  }
  const bwNow = bbw.at(-1);
  const bwRecent = bbw.slice(-120);
  const bwRank = bwRecent.filter((v) => v <= bwNow).length / bwRecent.length * 100;
  const rets = closes.slice(-51).map((c, i, arr) => (i ? Math.log(c / arr[i - 1]) : 0)).slice(1);
  const realized = std(rets) * 100; // per-candle %
  const lastRange = (candles[n - 1].high - candles[n - 1].low) / (a[n - 2] || a[n - 1]);
  let state = 'normal';
  if (bwRank <= 10) state = 'squeeze';
  else if (ratio >= 1.8 || lastRange >= 3) state = 'spike';
  else if (ratio >= 1.25) state = 'high';
  else if (ratio <= 0.75) state = 'low';
  return { atrPct: now, avgAtrPct: avg, ratio, pctRank, bbw: bwNow, bwRank, realized, lastRange, state, history: atrPct.slice(-80).map((v) => v ?? 0) };
}

/** Liquidity detector: resting pools (equal highs/lows), recent sweeps (stop hunts), volume spikes. */
export function liquidityScan(candles, { len = 3, lookback = 60 } = {}) {
  const n = candles.length;
  if (n < 60) return null;
  const swings = findSwings(candles, len);
  const liq = findLiquidity(candles, swings);
  const a = atr(candles, 14)[n - 1];
  const tol = a * 0.25;
  // Equal highs / lows: several untaken swings within a quarter ATR = a stronger pool.
  const pools = (list, side) => {
    const out = [];
    for (const s of list) {
      const g = out.find((p) => Math.abs(p.price - s.price) <= tol);
      if (g) { g.count++; g.price = (g.price * (g.count - 1) + s.price) / g.count; } else out.push({ side, price: s.price, count: 1, time: s.time });
    }
    return out.sort((x, y) => (side === 'bsl' ? x.price - y.price : y.price - x.price)).slice(0, 4);
  };
  const price = candles[n - 1].close;
  const bsl = pools(liq.bsl, 'bsl').map((p) => ({ ...p, distPct: (p.price / price - 1) * 100 }));
  const ssl = pools(liq.ssl, 'ssl').map((p) => ({ ...p, distPct: (p.price / price - 1) * 100 }));
  // Sweeps: a wick through a prior swing that closed back inside (within the last `lookback` candles).
  const sweeps = [];
  for (const s of swings) {
    for (let j = Math.max(s.index + len + 1, n - lookback); j < n; j++) {
      const c = candles[j];
      if (s.type === 'high' && c.high > s.price && c.close < s.price) { sweeps.push({ side: 'bsl', price: s.price, time: c.time, ago: n - 1 - j, bias: 'bear' }); break; }
      if (s.type === 'low' && c.low < s.price && c.close > s.price) { sweeps.push({ side: 'ssl', price: s.price, time: c.time, ago: n - 1 - j, bias: 'bull' }); break; }
      if (s.type === 'high' ? c.close > s.price : c.close < s.price) break; // taken for real
    }
  }
  sweeps.sort((x, y) => x.ago - y.ago);
  const vols = candles.map((c) => c.volume || 0);
  const avgVol = mean(vols.slice(-100));
  const spikes = [];
  if (avgVol > 0) for (let j = n - lookback; j < n; j++) if (vols[j] >= avgVol * 2.5) spikes.push({ time: candles[j].time, ratio: vols[j] / avgVol, up: candles[j].close >= candles[j].open, ago: n - 1 - j });
  return { price, bsl, ssl, sweeps: sweeps.slice(0, 6), spikes: spikes.slice(-6).reverse(), hasVolume: avgVol > 0 };
}

/** Order book walls and imbalance from a Binance depth snapshot ([[price, qty], …]). */
export function bookStats(depth, price, bandPct = 1) {
  const within = (side) => side.map(([p, q]) => [+p, +q]).filter(([p]) => Math.abs(p / price - 1) * 100 <= bandPct);
  const bids = within(depth.bids || []); const asks = within(depth.asks || []);
  const sum = (l) => l.reduce((s, [p, q]) => s + p * q, 0);
  const bidUsd = sum(bids); const askUsd = sum(asks);
  const wall = (l) => l.reduce((m, x) => (x[0] * x[1] > (m ? m[0] * m[1] : 0) ? x : m), null);
  const avgLevel = (bidUsd + askUsd) / Math.max(1, bids.length + asks.length);
  const bw = wall(bids); const aw = wall(asks);
  return {
    bidUsd, askUsd, imbalance: bidUsd + askUsd ? ((bidUsd - askUsd) / (bidUsd + askUsd)) * 100 : 0,
    bidWall: bw ? { price: bw[0], usd: bw[0] * bw[1], x: (bw[0] * bw[1]) / avgLevel } : null,
    askWall: aw ? { price: aw[0], usd: aw[0] * aw[1], x: (aw[0] * aw[1]) / avgLevel } : null,
  };
}

/**
 * Automatic risk: starts from the user's base risk % and scales it down for conditions that make a
 * trade riskier. Returns the multiplier and the reasons.
 */
export function riskAdjust({ baseRiskPct, vol, newsMins, lossStreak, sameDirCorrelated, score, dailyUsedPct = 0, dailyLimitPct = 3 }) {
  let m = 1;
  const reasons = [];
  if (vol?.state === 'spike') { m *= 0.5; reasons.push(['volSpike', 0.5]); } else if (vol?.state === 'high') { m *= 0.75; reasons.push(['volHigh', 0.75]); }
  if (newsMins != null && newsMins <= 60) { m *= 0.5; reasons.push(['news', 0.5]); }
  if (lossStreak >= 3) { m *= 0.5; reasons.push(['streak', 0.5]); } else if (lossStreak === 2) { m *= 0.75; reasons.push(['streak2', 0.75]); }
  if (sameDirCorrelated > 0) { const f = 1 / (1 + sameDirCorrelated); m *= f; reasons.push(['corr', f]); }
  if (score != null && score < 40) { m *= 0.75; reasons.push(['weakScore', 0.75]); } else if (score >= 70) { m *= 1.25; reasons.push(['strongScore', 1.25]); }
  let pct = Math.min(baseRiskPct * m, baseRiskPct * 1.25, 2);
  const left = Math.max(0, dailyLimitPct - dailyUsedPct);
  if (pct > left) { pct = left; reasons.push(['daily', left / Math.max(1e-9, baseRiskPct)]); }
  return { mult: baseRiskPct ? pct / baseRiskPct : 0, riskPct: pct, reasons };
}

/** Values a multi-condition rule can test, computed once per symbol/timeframe. */
export function ruleMetrics(candles) {
  const n = candles.length;
  const closes = candles.map((c) => c.close);
  const r = rsi(closes, 14);
  const e50 = ema(closes, 50); const e200 = ema(closes, 200);
  const sw = findSwings(candles, 3);
  const { events } = findStructure(candles, sw, 3);
  const last = events.at(-1);
  const vol = volatilityState(candles);
  const vols = candles.map((c) => c.volume || 0);
  const avgVol = mean(vols.slice(-51, -1));
  return {
    price: closes[n - 1], rsi: r[n - 1], prevRsi: r[n - 2], ema50: e50[n - 1], ema200: e200[n - 1],
    trend: closes[n - 1] > e200[n - 1] ? 'up' : 'down',
    event: last && n - 1 - last.index <= 3 ? `${last.kind}_${last.dir}` : null,
    atrRatio: vol?.ratio ?? 1, squeeze: vol?.state === 'squeeze',
    volRatio: avgVol ? vols[n - 1] / avgVol : 0,
    chgPct: (closes[n - 1] / closes[n - 2] - 1) * 100,
  };
}

/** One condition → true/false. cond = { type, op, value } */
export function testCondition(cond, m) {
  const v = Number(cond.value);
  switch (cond.type) {
    case 'price': return cond.op === 'gt' ? m.price >= v : m.price <= v;
    case 'rsi': return cond.op === 'gt' ? m.rsi >= v : m.rsi <= v;
    case 'chg': return cond.op === 'gt' ? m.chgPct >= v : m.chgPct <= -Math.abs(v);
    case 'trend': return m.trend === cond.op;
    case 'ema': return cond.op === 'above' ? m.price > m.ema50 : m.price < m.ema50;
    case 'smc': return m.event === cond.op;
    case 'vol': return m.atrRatio >= v;
    case 'squeeze': return m.squeeze;
    case 'volume': return m.volRatio >= v;
    default: return false;
  }
}

export function testRule(rule, metricsByKey) {
  const results = rule.conds.map((c) => {
    const m = metricsByKey[`${rule.symbol}|${c.tf || rule.tf}`];
    return m ? testCondition(c, m) : null;
  });
  if (results.some((x) => x === null)) return { ok: false, results };
  return { ok: rule.logic === 'or' ? results.some(Boolean) : results.every(Boolean), results };
}

/** Did a radar call work? +1 ATR in its direction before −1 ATR against, within `bars` candles. */
export function scoreCall(call, candles, bars = 24) {
  const start = candles.findIndex((c) => c.time > call.time);
  if (start < 0) return null;
  const up = call.direction === 'long';
  const end = Math.min(candles.length, start + bars);
  for (let i = start; i < end; i++) {
    const c = candles[i];
    const hitT = up ? c.high >= call.price + call.atr : c.low <= call.price - call.atr;
    const hitS = up ? c.low <= call.price - call.atr : c.high >= call.price + call.atr;
    if (hitS) return 'loss'; // stop first when both in one candle
    if (hitT) return 'win';
  }
  return end - start >= bars ? 'flat' : null;
}
