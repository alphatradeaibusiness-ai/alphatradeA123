// «توصية AI» (v234) — additional strategies, every one PAPER (research): evaluated on the same real candles, tracked on real
// prices, back-tested, but NEVER a recommendation until it meets the promotion rules (config/aiSignalRules.js).
//
// No look-ahead, by construction:
//  • every series is causal (the value at bar i uses bars ≤ i only);
//  • a pivot (swing high / low with k bars on each side) is used only from bar `p + k` on, when it is really confirmed;
//  • the Ichimoku cloud at bar i is the one projected 26 bars earlier;
//  • strategies read bar i (its close) and earlier; the back-test fills on the NEXT bar's open.
// Defaults are textbook values, not tuned. Strategies that need real volume run only on feeds with exchange volume.
import { ema, rsi, atr, bollinger } from '../indicators/index.js';
import { adx, macd } from './multiStrategy.js';

const K = 3;   // pivot strength (bars on each side)

/** All series the paper strategies need, computed once (causal). */
export function paperSeries(cs, { volumeKind = 'none' } = {}) {
  const n = cs.length; const c = cs.map((x) => x.close); const h = cs.map((x) => x.high); const l = cs.map((x) => x.low);
  const e20 = ema(c, 20), e50 = ema(c, 50), e200 = ema(c, 200), r = rsi(c, 14), a = atr(cs, 14), bb = bollinger(c, 20, 2), d = adx(cs, 14), m = macd(c);
  const hh = (src, len, i) => { let v = -Infinity; for (let j = Math.max(0, i - len); j < i; j++) v = Math.max(v, src[j]); return v; };       // prior bars only
  const ll = (src, len, i) => { let v = Infinity; for (let j = Math.max(0, i - len); j < i; j++) v = Math.min(v, src[j]); return v; };
  const don20h = new Array(n).fill(null), don20l = new Array(n).fill(null);
  for (let i = 20; i < n; i++) { don20h[i] = hh(h, 20, i); don20l[i] = ll(l, 20, i); }
  // Keltner (EMA 20 ± 1.5 ATR)
  const kU = c.map((_, i) => (e20[i] != null && a[i] != null ? e20[i] + 1.5 * a[i] : null)), kL = c.map((_, i) => (e20[i] != null && a[i] != null ? e20[i] - 1.5 * a[i] : null));
  // Z-score vs the 50-bar mean
  const z = new Array(n).fill(null), mean50 = new Array(n).fill(null);
  for (let i = 49; i < n; i++) { let s = 0, s2 = 0; for (let j = i - 49; j <= i; j++) { s += c[j]; s2 += c[j] * c[j]; } const mu = s / 50; const sd = Math.sqrt(Math.max(0, s2 / 50 - mu * mu)); mean50[i] = mu; z[i] = sd > 0 ? (c[i] - mu) / sd : 0; }
  // Ichimoku 9 / 26 / 52; span A/B computed at bar j are drawn at j + 26 → the cloud at bar i comes from bar i - 26
  const mid = (len, i) => (i >= len - 1 ? (Math.max(...h.slice(i - len + 1, i + 1)) + Math.min(...l.slice(i - len + 1, i + 1))) / 2 : null);
  const tenkan = c.map((_, i) => mid(9, i)), kijun = c.map((_, i) => mid(26, i)), spanB0 = c.map((_, i) => mid(52, i));
  const spanA = c.map((_, i) => (i >= 26 && tenkan[i - 26] != null && kijun[i - 26] != null ? (tenkan[i - 26] + kijun[i - 26]) / 2 : null));
  const spanB = c.map((_, i) => (i >= 26 ? spanB0[i - 26] : null));
  // daily VWAP (UTC day) and its standard deviation — only meaningful with real exchange volume
  const realVol = volumeKind === 'taker';
  const vwap = new Array(n).fill(null), vsd = new Array(n).fill(null);
  if (realVol) {
    let day = null, pv = 0, vv = 0, p2v = 0;
    for (let i = 0; i < n; i++) {
      const dd = Math.floor(cs[i].time / 86400); if (dd !== day) { day = dd; pv = 0; vv = 0; p2v = 0; }
      const tp = (h[i] + l[i] + c[i]) / 3; const v = Number(cs[i].volume) || 0; pv += tp * v; vv += v; p2v += tp * tp * v;
      if (vv > 0) { vwap[i] = pv / vv; vsd[i] = Math.sqrt(Math.max(0, p2v / vv - vwap[i] ** 2)); }
    }
  }
  const vol = cs.map((x) => Number(x.volume) || 0);
  const vavg = new Array(n).fill(null); for (let i = 20; i < n; i++) { let s = 0; for (let j = i - 20; j < i; j++) s += vol[j]; vavg[i] = s / 20; }
  // pivots with the bar at which each one is confirmed
  const piv = [];
  for (let i = K; i < n - K; i++) {
    let isH = true, isL = true;
    for (let j = i - K; j <= i + K; j++) { if (j === i) continue; if (h[j] >= h[i]) isH = false; if (l[j] <= l[i]) isL = false; }
    if (isH) piv.push({ i, at: i + K, type: 'high', price: h[i], rsi: r[i] });
    if (isL) piv.push({ i, at: i + K, type: 'low', price: l[i], rsi: r[i] });
  }
  return { cs, n, c, h, l, e20, e50, e200, r, a, bb, d, m, don20h, don20l, kU, kL, z, mean50, tenkan, kijun, spanA, spanB, vwap, vsd, realVol, vol, vavg, piv, volumeKind };
}
/** Pivots confirmed at bar i (never a pivot whose right side is still in the future). */
const pivotsAt = (T, i, type) => T.piv.filter((p) => p.at <= i && (!type || p.type === type));

const plan3 = (dir, entry, stop, R = [1.5, 2, 3]) => { const sg = dir === 'long' ? 1 : -1; const risk = (entry - stop) * sg; return risk > 0 ? { direction: dir, entry, stop, targets: R.map((k) => entry + sg * k * risk), risk } : null; };
const validStop = (risk, a, lo = 0.3, hi = 4) => a > 0 && risk > lo * a && risk < hi * a;
const trendDir = (T, i) => (T.e50[i] == null ? null : T.c[i] > T.e50[i] && (T.e50[i] - (T.e50[i - 5] ?? T.e50[i])) > 0 ? 'long' : T.c[i] < T.e50[i] && (T.e50[i] - (T.e50[i - 5] ?? T.e50[i])) < 0 ? 'short' : null);
const utcMin = (sec) => { const d = new Date(sec * 1000); return d.getUTCHours() * 60 + d.getUTCMinutes(); };

/* ───────── the strategies: (T, i, ctx) → signal | null ───────── */
export const PAPER = {
  // 1. Breakout & retest: a close beyond the 20-bar range in the last 2–8 bars, then a retest of that level that holds.
  breakout_retest(T, i) {
    const a = T.a[i]; if (!a || T.d[i] == null) return null;
    for (const dir of ['long', 'short']) {
      const long = dir === 'long';
      for (let b = i - 8; b <= i - 2; b++) {
        if (b < 21) continue;
        const lvl = long ? T.don20h[b] : T.don20l[b]; if (lvl == null) continue;
        if (!(long ? T.c[b] > lvl && T.c[b - 1] <= lvl : T.c[b] < lvl && T.c[b - 1] >= lvl)) continue;
        if (T.cs[b].high - T.cs[b].low < 1.0 * a) continue;                            // a real breakout candle, not a drift
        const touched = long ? T.l[i] <= lvl + 0.2 * a && T.c[i] > lvl : T.h[i] >= lvl - 0.2 * a && T.c[i] < lvl;
        const held = T.c.slice(b, i + 1).every((x) => (long ? x > lvl - 0.3 * a : x < lvl + 0.3 * a));
        if (touched && held && T.d[i] >= 18) { const p = plan3(dir, T.c[i], lvl - (long ? 1 : -1) * 0.6 * a); if (p && validStop(p.risk, a)) return { ...p, why: `level ${lvl.toFixed(5)}` }; }
      }
    }
    return null;
  },
  // 2. Liquidity sweep reversal: a wick beyond a confirmed swing, a close back inside, and a break of the minor swing.
  sweep_reversal(T, i) {
    const a = T.a[i]; if (!a) return null;
    for (const dir of ['long', 'short']) {
      const long = dir === 'long';
      const sw = pivotsAt(T, i - 1, long ? 'low' : 'high').filter((p) => i - p.i <= 60 && i - p.i >= 5).at(-1); if (!sw) continue;
      for (let s = i - 3; s <= i - 1; s++) {
        const swept = long ? T.l[s] < sw.price && T.c[s] > sw.price : T.h[s] > sw.price && T.c[s] < sw.price; if (!swept) continue;
        const minor = long ? Math.max(...T.h.slice(s - 3, s)) : Math.min(...T.l.slice(s - 3, s));
        if (long ? T.c[i] > minor : T.c[i] < minor) { const ext = long ? Math.min(...T.l.slice(s, i + 1)) : Math.max(...T.h.slice(s, i + 1)); const p = plan3(dir, T.c[i], ext - (long ? 1 : -1) * 0.2 * a); if (p && validStop(p.risk, a)) return { ...p, why: `swept ${sw.price.toFixed(5)}` }; }
      }
    }
    return null;
  },
  // 3. VWAP: reversion from ±2σ in a range (ADX < 20), or a pullback to VWAP in a trend (ADX ≥ 25). Real volume only.
  vwap(T, i) {
    if (!T.realVol || T.vwap[i] == null || !T.vsd[i] || !T.a[i]) return null;
    const a = T.a[i], v = T.vwap[i], sd = T.vsd[i], adxV = T.d[i] ?? 20;
    if (adxV < 20) {
      if (T.l[i - 1] <= v - 2 * sd && T.c[i] > v - 2 * sd && T.c[i] > T.cs[i].open) { const p = { ...plan3('long', T.c[i], Math.min(T.l[i - 1], T.l[i]) - 0.2 * a), targets: [v - sd, v, v + sd] }; if (p.risk > 0 && p.targets[0] > p.entry && validStop(p.risk, a)) return { ...p, why: 'reversion' }; }
      if (T.h[i - 1] >= v + 2 * sd && T.c[i] < v + 2 * sd && T.c[i] < T.cs[i].open) { const p = { ...plan3('short', T.c[i], Math.max(T.h[i - 1], T.h[i]) + 0.2 * a), targets: [v + sd, v, v - sd] }; if (p.risk > 0 && p.targets[0] < p.entry && validStop(p.risk, a)) return { ...p, why: 'reversion' }; }
    } else if (adxV >= 25) {
      const dir = trendDir(T, i); if (!dir) return null; const long = dir === 'long';
      if (long ? T.l[i] <= v && T.c[i] > v : T.h[i] >= v && T.c[i] < v) { const p = plan3(dir, T.c[i], v - (long ? 1 : -1) * 0.8 * a); if (p && validStop(p.risk, a)) return { ...p, why: 'trend pullback' }; }
    }
    return null;
  },
  // 4. Previous day / week high-low: a close-based break-and-hold, or a rejection wick with a close back inside.
  pdh_pdl(T, i, ctx) {
    const a = T.a[i]; if (!a || ctx.tfSec >= 86400) return null;
    const day = Math.floor(T.cs[i].time / 86400); let pdh = -Infinity, pdl = Infinity, found = false;
    for (let j = i; j >= 0; j--) { const dd = Math.floor(T.cs[j].time / 86400); if (dd === day) continue; if (dd < day - 1) break; found = true; pdh = Math.max(pdh, T.h[j]); pdl = Math.min(pdl, T.l[j]); }
    if (!found) return null;
    const dir = trendDir(T, i);
    if (dir === 'long' && T.c[i - 1] > pdh && T.l[i] <= pdh + 0.15 * a && T.c[i] > pdh) { const p = plan3('long', T.c[i], pdh - 0.5 * a); if (p && validStop(p.risk, a)) return { ...p, why: `PDH ${pdh.toFixed(5)} hold` }; }
    if (dir === 'short' && T.c[i - 1] < pdl && T.h[i] >= pdl - 0.15 * a && T.c[i] < pdl) { const p = plan3('short', T.c[i], pdl + 0.5 * a); if (p && validStop(p.risk, a)) return { ...p, why: `PDL ${pdl.toFixed(5)} hold` }; }
    if (T.h[i] > pdh && T.c[i] < pdh && T.c[i] < T.cs[i].open && dir !== 'long') { const p = plan3('short', T.c[i], T.h[i] + 0.2 * a); if (p && validStop(p.risk, a)) return { ...p, why: `PDH ${pdh.toFixed(5)} rejection` }; }
    if (T.l[i] < pdl && T.c[i] > pdl && T.c[i] > T.cs[i].open && dir !== 'short') { const p = plan3('long', T.c[i], T.l[i] - 0.2 * a); if (p && validStop(p.risk, a)) return { ...p, why: `PDL ${pdl.toFixed(5)} rejection` }; }
    return null;
  },
  // 5. Opening range breakout: the first 30 minutes of the session, then a close outside it (within 3 hours of the open).
  orb(T, i, ctx) {
    const a = T.a[i]; if (!a || ctx.tfSec > 900) return null;
    const opens = ctx.assetClass === 'crypto' ? [0] : ctx.assetClass === 'index' ? [13 * 60 + 30, 7 * 60] : [7 * 60, 13 * 60];
    const t = T.cs[i].time; const dayStart = Math.floor(t / 86400) * 86400;
    for (const om of opens) {
      const o = dayStart + om * 60; if (t < o + 1800 || t > o + 3 * 3600) continue;
      let hi = -Infinity, lo = Infinity, n = 0;
      for (let j = i; j >= 0 && T.cs[j].time >= o; j--) if (T.cs[j].time < o + 1800) { hi = Math.max(hi, T.h[j]); lo = Math.min(lo, T.l[j]); n++; }
      if (!n || hi - lo <= 0) continue;
      const first = (lvl, up) => { for (let j = i - 1; j >= 0 && T.cs[j].time >= o + 1800; j--) if (up ? T.c[j] > lvl : T.c[j] < lvl) return false; return true; };
      if (T.c[i] > hi && first(hi, true)) { const p = plan3('long', T.c[i], Math.max(lo, T.c[i] - 2 * a)); if (p && validStop(p.risk, a)) return { ...p, why: `ORB ${hi.toFixed(5)}` }; }
      if (T.c[i] < lo && first(lo, false)) { const p = plan3('short', T.c[i], Math.min(hi, T.c[i] + 2 * a)); if (p && validStop(p.risk, a)) return { ...p, why: `ORB ${lo.toFixed(5)}` }; }
    }
    return null;
  },
  // 6. Donchian / Turtle: a close beyond the 20-bar channel, ATR in a normal band, 2 ATR stop.
  donchian(T, i) {
    const a = T.a[i]; if (!a || T.don20h[i] == null) return null;
    const atrs = T.a.slice(Math.max(0, i - 100), i).filter((v) => v != null).sort((x, y) => x - y); const p90 = atrs[Math.floor(atrs.length * 0.9)] ?? a;
    if (a > p90 * 1.2) return null;
    if (T.c[i] > T.don20h[i] && T.c[i - 1] <= (T.don20h[i - 1] ?? Infinity)) { const p = plan3('long', T.c[i], T.c[i] - 2 * a, [1, 2, 3]); if (p) return { ...p, why: 'channel high' }; }
    if (T.c[i] < T.don20l[i] && T.c[i - 1] >= (T.don20l[i - 1] ?? -Infinity)) { const p = plan3('short', T.c[i], T.c[i] + 2 * a, [1, 2, 3]); if (p) return { ...p, why: 'channel low' }; }
    return null;
  },
  // 7. Keltner squeeze: Bollinger inside Keltner for ≥ 5 bars, then a close outside Bollinger in the EMA 50 direction.
  squeeze(T, i) {
    const a = T.a[i]; if (!a) return null;
    const inK = (j) => T.bb.upper[j] != null && T.kU[j] != null && T.bb.upper[j] < T.kU[j] && T.bb.lower[j] > T.kL[j];
    let run = 0; for (let j = i - 1; j >= Math.max(0, i - 30) && inK(j); j--) run++;
    if (run < 5 || inK(i)) return null;
    const dir = trendDir(T, i); if (!dir) return null;
    if (dir === 'long' && T.c[i] > T.bb.upper[i] && (T.m.hist[i] ?? 0) > 0) { const p = plan3('long', T.c[i], T.e20[i] - 0.5 * a); if (p && validStop(p.risk, a)) return { ...p, why: `squeeze ${run} bars` }; }
    if (dir === 'short' && T.c[i] < T.bb.lower[i] && (T.m.hist[i] ?? 0) < 0) { const p = plan3('short', T.c[i], T.e20[i] + 0.5 * a); if (p && validStop(p.risk, a)) return { ...p, why: `squeeze ${run} bars` }; }
    return null;
  },
  // 8. Ichimoku: price beyond the (already projected) cloud and a fresh Tenkan / Kijun cross the same way.
  ichimoku(T, i) {
    const a = T.a[i]; if (!a || T.spanA[i] == null || T.spanB[i] == null || T.tenkan[i - 1] == null || T.kijun[i - 1] == null) return null;
    const top = Math.max(T.spanA[i], T.spanB[i]), bot = Math.min(T.spanA[i], T.spanB[i]);
    const up = T.tenkan[i] > T.kijun[i] && T.tenkan[i - 1] <= T.kijun[i - 1], dn = T.tenkan[i] < T.kijun[i] && T.tenkan[i - 1] >= T.kijun[i - 1];
    if (up && T.c[i] > top) { const p = plan3('long', T.c[i], Math.min(T.kijun[i], T.c[i] - 0.5 * a) - 0.3 * a); if (p && validStop(p.risk, a)) return { ...p, why: 'TK cross above cloud' }; }
    if (dn && T.c[i] < bot) { const p = plan3('short', T.c[i], Math.max(T.kijun[i], T.c[i] + 0.5 * a) + 0.3 * a); if (p && validStop(p.risk, a)) return { ...p, why: 'TK cross below cloud' }; }
    return null;
  },
  // 9. RSI divergence: regular divergence between the last two CONFIRMED pivots, then a confirmation candle.
  divergence(T, i) {
    const a = T.a[i]; if (!a) return null;
    for (const dir of ['long', 'short']) {
      const long = dir === 'long';
      const ps = pivotsAt(T, i, long ? 'low' : 'high'); const [p1, p2] = ps.slice(-2); if (!p1 || !p2 || p2.i - p1.i < 5 || i - p2.at > 3) continue;
      const priceDiv = long ? p2.price < p1.price : p2.price > p1.price; const rsiDiv = long ? p2.rsi > p1.rsi : p2.rsi < p1.rsi;
      const conf = long ? T.c[i] > T.cs[i].open && T.c[i] > T.h[i - 1] : T.c[i] < T.cs[i].open && T.c[i] < T.l[i - 1];
      if (priceDiv && rsiDiv && p1.rsi != null && p2.rsi != null && conf) { const p = plan3(dir, T.c[i], p2.price - (long ? 1 : -1) * 0.2 * a); if (p && validStop(p.risk, a)) return { ...p, why: `RSI ${p1.rsi.toFixed(0)}→${p2.rsi.toFixed(0)}` }; }
    }
    return null;
  },
  // 10. Support / resistance rejection: a level touched by ≥ 3 confirmed pivots, a rejection wick and a close away.
  sr_rejection(T, i) {
    const a = T.a[i]; if (!a) return null;
    const ps = pivotsAt(T, i).filter((p) => i - p.i <= 150);
    for (const dir of ['long', 'short']) {
      const long = dir === 'long'; const near = long ? T.l[i] : T.h[i];
      const lvls = ps.filter((p) => Math.abs(p.price - near) <= 0.35 * a);
      if (lvls.length < 3) continue;
      const lvl = lvls.reduce((s, p) => s + p.price, 0) / lvls.length;
      const body = Math.abs(T.c[i] - T.cs[i].open); const wick = long ? Math.min(T.c[i], T.cs[i].open) - T.l[i] : T.h[i] - Math.max(T.c[i], T.cs[i].open);
      if (wick >= 1.5 * body && (long ? T.c[i] > lvl : T.c[i] < lvl)) { const p = plan3(dir, T.c[i], (long ? T.l[i] : T.h[i]) - (long ? 1 : -1) * 0.2 * a); if (p && validStop(p.risk, a)) return { ...p, why: `${lvls.length} touches ${lvl.toFixed(5)}` }; }
    }
    return null;
  },
  // 11. Z-score range: beyond ±2 and turning, only when the 50-bar mean is nearly flat (a stationarity proxy).
  zscore(T, i) {
    const a = T.a[i]; if (!a || T.z[i] == null || T.z[i - 1] == null || T.mean50[i - 20] == null) return null;
    if (Math.abs(T.mean50[i] - T.mean50[i - 20]) > 1.0 * a) return null;
    if (T.z[i - 1] <= -2 && T.z[i] > T.z[i - 1] && T.c[i] > T.cs[i].open) { const p = { ...plan3('long', T.c[i], Math.min(T.l[i], T.l[i - 1]) - 0.3 * a) }; if (p.risk > 0) { p.targets = [T.c[i] + (T.mean50[i] - T.c[i]) / 2, T.mean50[i], T.mean50[i] + (T.mean50[i] - T.c[i]) / 2]; if (p.targets[0] > p.entry && validStop(p.risk, a)) return { ...p, why: `z ${T.z[i - 1].toFixed(2)}` }; } }
    if (T.z[i - 1] >= 2 && T.z[i] < T.z[i - 1] && T.c[i] < T.cs[i].open) { const p = { ...plan3('short', T.c[i], Math.max(T.h[i], T.h[i - 1]) + 0.3 * a) }; if (p.risk > 0) { p.targets = [T.c[i] - (T.c[i] - T.mean50[i]) / 2, T.mean50[i], T.mean50[i] - (T.c[i] - T.mean50[i]) / 2]; if (p.targets[0] < p.entry && validStop(p.risk, a)) return { ...p, why: `z ${T.z[i - 1].toFixed(2)}` }; } }
    return null;
  },
  // 12. Session momentum: in the first hour of London (07:00 UTC) or New York (13:30 UTC), a displacement candle with the trend.
  session_momentum(T, i, ctx) {
    const a = T.a[i]; if (!a || ctx.tfSec > 900 || ctx.assetClass === 'crypto') return null;
    const m = utcMin(T.cs[i].time); const inFirst = (m >= 420 && m < 480) || (m >= 810 && m < 870); if (!inFirst) return null;
    const dir = trendDir(T, i); if (!dir) return null;
    const rng = T.h[i] - T.l[i]; const body = Math.abs(T.c[i] - T.cs[i].open);
    if (rng >= 1.5 * a && body >= 0.6 * rng && (dir === 'long' ? T.c[i] > T.cs[i].open : T.c[i] < T.cs[i].open)) { const p = plan3(dir, T.c[i], dir === 'long' ? T.l[i] - 0.1 * a : T.h[i] + 0.1 * a); if (p && validStop(p.risk, a, 0.3, 3)) return { ...p, why: 'session displacement' }; }
    return null;
  },
  // 13. Volume momentum: real exchange volume ≥ 2× its average with a strong close in the trend direction.
  volume_momentum(T, i) {
    if (!T.realVol || !T.vavg[i] || !T.a[i]) return null;
    const a = T.a[i]; const dir = trendDir(T, i); if (!dir) return null;
    const rng = T.h[i] - T.l[i]; const pos = rng > 0 ? (T.c[i] - T.l[i]) / rng : 0.5;
    if (T.vol[i] >= 2 * T.vavg[i] && (dir === 'long' ? pos >= 0.75 : pos <= 0.25)) { const p = plan3(dir, T.c[i], dir === 'long' ? T.l[i] - 0.2 * a : T.h[i] + 0.2 * a); if (p && validStop(p.risk, a, 0.3, 3)) return { ...p, why: `volume ×${(T.vol[i] / T.vavg[i]).toFixed(1)}` }; }
    return null;
  },
};

/** Why a paper strategy cannot run on this market / timeframe (null = it can). */
export function unavailableReason(id, { volumeKind, assetClass, tf }) {
  if ((id === 'vwap' || id === 'volume_momentum') && volumeKind !== 'taker') return 'no_real_volume';
  if ((id === 'orb' || id === 'session_momentum') && !['1m', '5m', '15m'].includes(tf)) return 'timeframe';
  if (id === 'session_momentum' && assetClass === 'crypto') return 'no_sessions';
  if (id === 'pdh_pdl' && tf === '1D') return 'timeframe';
  return null;
}

/** Every paper strategy at the last closed bar. → [{ id, status: 'signal'|'none'|'unavailable', reason?, signal? }] */
export function runPaper(candles, { volumeKind = 'none', assetClass = 'crypto', tf = '15m', tfSec = 900 } = {}) {
  if (!candles || candles.length < 120) return Object.keys(PAPER).map((id) => ({ id, status: 'unavailable', reason: 'data' }));
  const T = paperSeries(candles, { volumeKind }); const i = candles.length - 1; const ctx = { assetClass, tf, tfSec };
  return Object.keys(PAPER).map((id) => {
    const why = unavailableReason(id, { volumeKind, assetClass, tf }); if (why) return { id, status: 'unavailable', reason: why };
    let s = null; try { s = PAPER[id](T, i, ctx); } catch { s = null; }
    return s ? { id, status: 'signal', signal: s } : { id, status: 'none' };
  });
}
