// Recommendation channel: the client's preferred strategy (EDH, SMC or the Confluence strategy = zones confirmed by a fixed
// volume profile + RSI + Fibonacci) and the REAL track record of every signal the channel published over the last month.
// Pips are realised pips only: a stop = −risk, each target hit = a third of the distance to that target, the rest of a trade
// closed at breakeven = 0. Fees and slippage are not included. Open trades count as signals but add only the thirds already hit.
import { storage } from '../utils/storage.js';
import { getInstrument, INSTRUMENTS } from '../config/instruments.js';
import { pipPoints } from './pips.js';

// Active strategies only. Classic, SMC and Zones were retired (v173): on real BTC data (Jan 2025 → Oct 2026, fees included) Classic won
// 49–52% and lost money, SMC v2 and Zones made 0–4 trades (nothing to prove). Their code stays (lab pages, old signals) — not published.
export const CHANNEL_STRATEGIES = ['edh', 'lbr'];
export const RETIRED_STRATEGIES = ['smc', 'classic', 'zone'];
const PREF = 'chan-pref', HIST = 'sig-history', MAX = 8000;
const ARCH = 'sig-archive', ARCH_MAX = 4000;   // older closed signals (kept small: localStorage space is limited)

// The client's choice: one strategy, or 'auto' = the best strategy of each symbol THIS month (see recommendAuto below).
export const channelPref = () => { const p = storage.get(PREF, 'edh'); return CHANNEL_STRATEGIES.includes(p) || p === 'auto' ? p : 'edh'; };
export const setChannelPref = (s) => { if (CHANNEL_STRATEGIES.includes(s) || s === 'auto') storage.set(PREF, s); return channelPref(); };

/** Realised points of a signal (price distance / point size). */
export function realisedPoints(s) {
  const ps = s.pointSize || 1, sign = s.direction === 'long' ? 1 : -1;
  if (s.status === 'sl' && !s.hits) return -Math.abs(s.entry - s.stop) / ps;
  let pts = 0;
  for (let k = 0; k < Math.min(3, s.hits || 0); k++) pts += ((s.targets[k] - s.entry) * sign) / ps / 3;
  return pts;
}
export function realisedPips(s) {
  const inst = getInstrument(s.symbol);
  return realisedPoints(s) / pipPoints(inst);
}

const DAY = 86400_000;
// A limit order that never filled (pending / expired / cancelled) is not a trade: it is neither a win nor a loss.
export const NOT_TRADED = ['active', 'pending', 'expired', 'cancelled'];
const closedTrade = (r) => !NOT_TRADED.includes(r.status);
export const OPEN_CAP = 0;           // no limit on signals per day / open at once (0 = off): every setup that passes the strategy's own conditions is published
export const WINDOW_DAYS = 30;       // the mistake review looks at the last 30 days
/** Start of the PREVIOUS calendar month (local time): the results panel covers that month up to now, nothing older. */
export const statsSince = (now = Date.now()) => { const d = new Date(now); return new Date(d.getFullYear(), d.getMonth() - 1, 1).getTime(); };
export const PAUSE_MS = 3 * DAY;     // a combination that keeps losing rests this long, then gets another chance
const MIN_REVIEW = 4;                // closed signals needed before a combination can be judged
const slim = (s) => ({ id: s.id, symbol: s.symbol, tf: s.tf, strategy: s.strategy, direction: s.direction, createdAt: s.createdAt, closedAt: s.closedAt || null, status: s.status, hits: s.hits || 0, pips: Math.round(realisedPips(s) * 10) / 10 });

/** Adds or updates signals in the log (one read and one write for the whole batch). Rows older than the start of the previous month are dropped. */
export function logSignals(list, now = Date.now()) {
  if (!list?.length) return;
  const h = signalHistory().slice();
  for (const s of list) {
    const i = h.findIndex((x) => x.id === s.id);
    const row = slim(s);
    if (i >= 0) h[i] = row; else h.unshift(row);
  }
  const since = statsSince(now);
  const keep = h.filter((x) => x.createdAt >= since);
  const drop = h.filter((x) => x.createdAt < since && x.status !== 'active').concat(keep.slice(MAX));
  storage.set(HIST, keep.slice(0, MAX));
  // Rows leaving the working log (older than last month) are kept in a separate archive for the full signal history.
  if (drop.length) {
    const arch = storage.get(ARCH, []);
    const ids = new Set(arch.map((x) => x.id));
    storage.set(ARCH, drop.filter((x) => !ids.has(x.id)).concat(arch).sort((a, b) => b.createdAt - a.createdAt).slice(0, ARCH_MAX));
  }
  clearPicks();
}
/** Adds or updates one signal in the log. */
export const logSignal = (s, now = Date.now()) => logSignals([s], now);

// The log can hold thousands of rows and the channel page reads it several times a second: parse it only when its text changed.
let histMemo = { raw: undefined, rows: [] };
/** The signal log (newest first). Shared, read-only array: copy it before changing anything. */
export const signalHistory = () => {
  const raw = storage.raw(HIST);
  if (raw === histMemo.raw) return histMemo.rows;
  let rows = [];
  if (raw !== null) { try { rows = JSON.parse(raw); } catch { rows = []; } }
  histMemo = { raw, rows };
  return rows;
};

/** Signals of this strategy that are still open. */
export const openCount = (strategy, history = signalHistory()) => history.filter((r) => r.strategy === strategy && r.status === 'active').length;

/**
 * "Learning from mistakes": over the last month, a symbol+timeframe+strategy that has at least 4 closed signals, wins fewer than
 * half of them (a win = TP1 reached) and has negative net pips is paused for 3 days after its latest close, then gets another chance.
 * Returns the paused combinations (still resting) and the reason figures.
 */
export function reviewMistakes(history = signalHistory(), now = Date.now()) {
  const by = new Map();
  for (const r of history) {
    if (!closedTrade(r) || now - r.createdAt > WINDOW_DAYS * DAY) continue;
    const k = `${r.symbol}|${r.tf}|${r.strategy}`;
    const c = by.get(k) || { symbol: r.symbol, tf: r.tf, strategy: r.strategy, n: 0, wins: 0, pips: 0, last: 0 };
    c.n++; c.pips += r.pips; if (r.hits >= 1) c.wins++; c.last = Math.max(c.last, r.closedAt || r.createdAt);
    by.set(k, c);
  }
  return [...by.values()].filter((c) => c.n >= MIN_REVIEW && c.wins / c.n < 0.5 && c.pips < 0 && now < c.last + PAUSE_MS)
    .map((c) => ({ ...c, winRate: (100 * c.wins) / c.n, until: c.last + PAUSE_MS }));
}

/** May this signal be published? Open-signal cap first, then the mistake review. */
export function channelCheck(strategy, symbol, tf, history = signalHistory(), now = Date.now()) {
  if (OPEN_CAP > 0 && openCount(strategy, history) >= OPEN_CAP) return { ok: false, key: 'openCap', params: { n: OPEN_CAP } };
  const hit = reviewMistakes(history, now).find((c) => c.strategy === strategy && c.symbol === symbol && c.tf === tf);
  if (hit) return { ok: false, key: 'paused', params: { n: hit.n, rate: Math.round(hit.winRate), pips: Math.round(hit.pips) } };
  return { ok: true };
}

/** Current + previous calendar month only: per strategy, signals published, closed, wins (TP1 reached), losses and net pips. */
export function lastDaysSummary(history = signalHistory(), now = Date.now(), strategies = CHANNEL_STRATEGIES) {
  const out = Object.fromEntries(strategies.map((k) => [k, { signals: 0, closed: 0, wins: 0, losses: 0, pips: 0 }]));
  const since = statsSince(now);
  for (const r of history) {
    if (!out[r.strategy] || r.createdAt < since || ['expired', 'cancelled'].includes(r.status)) continue;
    const c = out[r.strategy];
    c.signals++; c.pips += r.pips;
    if (closedTrade(r)) { c.closed++; if (r.hits >= 1) c.wins++; else c.losses++; }
  }
  return out;
}

/* ───────── Automatic choice: the best strategy per symbol, from this month's REAL closed signals ───────── */
const AUTO_MIN = 'auto-min';
export const DEFAULT_AUTO_MIN = 5;
export const autoMinTrades = () => { const v = Math.round(Number(storage.get(AUTO_MIN, DEFAULT_AUTO_MIN))); return Number.isFinite(v) && v >= 1 ? Math.min(100, v) : DEFAULT_AUTO_MIN; };
/** Start of the current calendar month (local time). */
export const monthStartOf = (now = Date.now()) => { const d = new Date(now); return new Date(d.getFullYear(), d.getMonth(), 1).getTime(); };

/** Per symbol and strategy, over the signals CLOSED this month: trades, wins (TP1 reached), net pips, and the largest peak-to-trough fall of the running pips. Open signals are not counted. */
export function monthStrategyStats(history = signalHistory(), now = Date.now()) {
  const from = monthStartOf(now);
  const closed = history.filter((r) => closedTrade(r) && (r.closedAt || r.createdAt) >= from && CHANNEL_STRATEGIES.includes(r.strategy))
    .sort((a, b) => (a.closedAt || a.createdAt) - (b.closedAt || b.createdAt));
  const out = {};
  for (const r of closed) {
    const c = ((out[r.symbol] ||= {})[r.strategy] ||= { symbol: r.symbol, strategy: r.strategy, trades: 0, wins: 0, netPips: 0, maxDrawdown: 0, _eq: 0, _pk: 0 });
    c.trades++; if (r.hits >= 1) c.wins++;
    c._eq += r.pips; c._pk = Math.max(c._pk, c._eq); c.maxDrawdown = Math.max(c.maxDrawdown, c._pk - c._eq); c.netPips = c._eq;
  }
  for (const by of Object.values(out)) for (const c of Object.values(by)) { c.winRate = c.trades ? (100 * c.wins) / c.trades : 0; delete c._eq; delete c._pk; }
  return out;
}

/**
 * Recommendation per symbol. A strategy is eligible with at least `minTrades` closed signals this month AND a positive net result;
 * eligible ones are ranked by net pips per unit of drawdown (net / (1 + max drawdown)), so a high win rate alone never wins, then by more trades.
 * Symbols without any eligible strategy get no pick: 'noData' (no strategy reached the minimum) or 'noPositive' (enough trades, none profitable).
 */
export function recommendAuto(symbols, history = signalHistory(), now = Date.now(), minTrades = autoMinTrades()) {
  const stats = monthStrategyStats(history, now);
  return symbols.map((symbol) => {
    const rows = CHANNEL_STRATEGIES.map((k) => stats[symbol]?.[k]).filter(Boolean);
    const enough = rows.filter((r) => r.trades >= minTrades);
    const eligible = enough.filter((r) => r.netPips > 0).map((r) => ({ ...r, score: r.netPips / (1 + r.maxDrawdown) }))
      .sort((a, b) => b.score - a.score || b.trades - a.trades);
    return { symbol, rows, best: eligible[0] || null, reason: eligible.length ? 'ok' : enough.length ? 'noPositive' : 'noData', from: monthStartOf(now), to: now };
  });
}

/** Does the channel show / notify this signal for the client? One chosen strategy, or the symbol's pick in automatic mode. */
let pickCache = null;   // per-symbol picks, rebuilt only when a signal is logged, the minimum changes or the month turns (this runs for every signal every second)
const clearPicks = () => { pickCache = null; };
export function channelWants(symbol, strategy, history = null, now = Date.now()) {
  if (!CHANNEL_STRATEGIES.includes(strategy)) return true;   // the AI engine's strategies (trend / mean reversion / SMC) always reach the client
  const pref = channelPref();
  if (pref !== 'auto') return strategy === pref;
  const key = `${autoMinTrades()}|${monthStartOf(now)}`;
  if (history || !pickCache || pickCache.key !== key) {
    const picks = Object.fromEntries(recommendAuto(INSTRUMENTS.map((i) => i.symbol), history || signalHistory(), now).map((r) => [r.symbol, r.best?.strategy || null]));
    if (history) return picks[symbol] === strategy;
    pickCache = { key, picks };
  }
  // No month history for this market yet: nothing to choose between, so the setup is shown rather than silently dropped.
  return pickCache.picks[symbol] == null || pickCache.picks[symbol] === strategy;
}

