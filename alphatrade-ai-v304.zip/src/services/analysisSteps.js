// The stages of the full analysis for the selected asset, read from the analysis that was really computed
// (candles → SMC structure → order blocks / FVG → ICT liquidity, sessions, kill zone, OTE → RSI → Bollinger → plan).
// Pure: no DOM, no network. Every value comes from the loaded candles; a stage with no data says so ('na').
import { killZone } from './smc2.js';

const num = (v) => (Number.isFinite(v) ? v : null);

/** ICT optimal trade entry band (62%–79% retracement) of the current dealing range, in the direction of the last break. */
export function oteBand(range, trend) {
  if (!range || !(range.high > range.low) || (trend !== 'bull' && trend !== 'bear')) return null;
  const span = range.high - range.low;
  const a = trend === 'bull' ? range.high - 0.62 * span : range.low + 0.62 * span;
  const b = trend === 'bull' ? range.high - 0.79 * span : range.low + 0.79 * span;
  return { from: Math.min(a, b), to: Math.max(a, b), dir: trend };
}

/**
 * @returns {{ key: string, status: 'done'|'na', p: object }[]}
 */
export function analysisSteps(an, dataset, settings = {}) {
  if (!an || !dataset?.candles?.length) return [];
  const candles = dataset.candles;
  const closed = candles.length > 1 ? candles[candles.length - 2] : candles[candles.length - 1];
  const last = candles[candles.length - 1];
  const steps = [];

  steps.push({ key: 'data', status: 'done', p: { n: candles.length, mode: an.mode === 'live' ? 'live' : 'demo', price: num(last.close), closedTime: closed.time } });

  const liq = an.liq || an.smc || null;
  const ev = liq?.recentEvents?.at(-1) || liq?.events?.at(-1) || null;
  steps.push(liq && (liq.trend || ev)
    ? { key: 'structure', status: 'done', p: { trend: liq.trend || (ev ? ev.dir : null), kind: ev?.kind || null, dir: ev?.dir || null, level: num(ev?.level) } }
    : { key: 'structure', status: 'na', p: {} });

  if (liq) {
    const obs = (liq.obs || (liq.ob ? [liq.ob] : [])).filter((o) => !o.mitigated);
    const fvgs = liq.fvgs || (liq.fvg ? [liq.fvg] : []);
    steps.push({ key: 'blocks', status: 'done', p: { ob: obs.length, fvg: fvgs.length, obDir: obs[0]?.dir || null, obTop: num(obs[0]?.top), obBottom: num(obs[0]?.bottom) } });
  } else steps.push({ key: 'blocks', status: 'na', p: {} });

  if (liq) {
    const bsl = liq.bsl?.[0]; const ssl = liq.ssl?.[0];
    const kz = killZone(closed.time);
    steps.push({
      key: 'ict', status: 'done',
      p: {
        zone: liq.range?.zone || null, eq: num(liq.range?.eq),
        bsl: num(bsl?.price ?? bsl), ssl: num(ssl?.price ?? ssl),
        sessions: (an.sessions || []).length, kz, ote: oteBand(liq.range, liq.trend),
      },
    });
  } else steps.push({ key: 'ict', status: 'na', p: {} });

  const rv = an.rsi ? an.rsi[an.rsi.length - 1] : null;
  const ob = settings.rsi?.overbought ?? 70; const os = settings.rsi?.oversold ?? 30;
  steps.push(num(rv) != null
    ? { key: 'rsi', status: 'done', p: { v: rv, state: rv >= ob ? 'over' : rv <= os ? 'under' : 'mid' } }
    : { key: 'rsi', status: 'na', p: {} });

  const i = (candles.length > 1 ? candles.length - 2 : 0);
  const u = an.bb?.upper?.[i]; const l = an.bb?.lower?.[i]; const m = an.bb?.mid?.[i];
  if (num(u) != null && num(l) != null && u > l) {
    const pb = (closed.close - l) / (u - l);
    steps.push({ key: 'bb', status: 'done', p: { pb: pb * 100, width: m ? ((u - l) / m) * 100 : null, state: closed.close > u ? 'above' : closed.close < l ? 'below' : pb >= 0.5 ? 'upper' : 'lower' } });
  } else steps.push({ key: 'bb', status: 'na', p: {} });

  const plan = an.plan || an.proposal || null;
  if (plan) {
    steps.push({ key: 'plan', status: 'done', p: { direction: plan.direction, state: plan.status || 'proposal', entry: num(plan.entry), stop: num(plan.initialStop ?? plan.stop), targets: (plan.targets || []).map(num), strategy: an.strategy } });
  } else {
    steps.push({ key: 'plan', status: 'na', p: { blockers: (an.gate?.blockers || []).filter((b) => b !== 'levels'), rejected: Boolean(an.gate?.rejected), strategy: an.strategy } });
  }
  return steps;
}
