// Web Worker: trains the chart's AI models off the main thread, so the page (chart, scrolling, animations) never
// freezes while it runs. Receives a plain job from aiAsync.js and answers with the same result aiRun gives on the main thread.
import { aiRun } from './aiCore.js';

self.onmessage = (e) => {
  const { id, job } = e.data || {};
  try { self.postMessage({ id, result: aiRun(job) }); } catch (err) { self.postMessage({ id, error: String(err?.message || err) }); }
};
