import { defineConfig, loadEnv } from 'vite';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const apiPort = env.SERVER_PORT || 8787;
  // Every VITE_ variable is compiled into the public JavaScript. Refuse to build when one looks like a secret
  // (AI / market / payment keys belong in server variables without the VITE_ prefix). The Firebase web config is public by design.
  const PUBLIC_OK = new Set(['VITE_FIREBASE_API_KEY']);
  const leaked = Object.keys(env).filter((k) => k.startsWith('VITE_') && !PUBLIC_OK.has(k) && env[k]
    && /(SECRET|TOKEN|PASSWORD|PRIVATE|API_KEY|ANTHROPIC|OPENAI|STRIPE|TWELVEDATA_API_KEY|RESEND|TELEGRAM)/i.test(k));
  if (leaked.length) throw new Error(`Refusing to build: ${leaked.join(', ')} would be published in the browser bundle. Use the server variable without VITE_ (e.g. TWELVEDATA_API_KEY) or the owner page.`);
  return {
    server: {
      port: 5173,
      host: true,
      allowedHosts: ['terminal.local'],
      // The AI assistant proxy (server/index.js) keeps the AI key off the browser.
      proxy: { '/api': `http://localhost:${apiPort}`, '/ff': `http://localhost:${apiPort}` },
    },
    build: { target: 'es2022', chunkSizeWarningLimit: 1200 },
    // The chart's AI training runs in a module Web Worker (src/services/aiWorker.js).
    worker: { format: 'es' },
  };
});
