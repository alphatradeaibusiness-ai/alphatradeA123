import { listTrades, onTrades } from '../services/assistTrades.js';
import { historyStats } from '../services/smcAssist.js';
import { apiRequest } from '../services/ai/gateway.js';
import { scopedRawKey } from '../utils/storage.js';
// Profile page: photo, name and password.
import { h, esc } from '../utils/dom.js';
import { icons, logoMark } from '../components/icons.js';
import { t, getLang, setLang, LANGS } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { auth, validate } from '../services/auth/index.js';
import { authErrorMessage } from '../services/auth/errors.js';
import { authConfig } from '../config/auth.js';
import { getAvatar, setAvatar, resizeImage, avatarInner } from '../services/profile.js';
import { toast } from '../components/ui.js';
import { renderHistory } from '../components/smcAssistPanel.js';
import { accountDataHtml, bindAccountData } from '../components/accountData.js';
import { faceCard } from '../components/faceCard.js';
import { getTradingStyle, setTradingStyle } from '../services/tradingStyle.js';
import { UTC_KEY, userTz, tzLabel, tzOffset } from '../services/aiSignalUtil.js';
import { COUNTRY_ZONES } from '../config/countryZones.js';
import { getTraderWay, setTraderWay } from '../services/tradingStyle.js';

function pwField(name, labelKey, autocomplete) {
  return `<div class="field-wrap">
    <label class="field"><span class="visually-hidden">${esc(t(labelKey))}</span>
      <span class="field-icon">${icons.lock}</span>
      <input name="${name}" type="password" placeholder="${esc(t(labelKey))}" autocomplete="${autocomplete}"/>
      <button type="button" class="field-action" data-toggle-pw aria-label="show/hide">${icons.eye}</button>
    </label>
    <p class="field-error" data-error-for="${name}" role="alert"></p>
  </div>`;
}

export function renderProfile() {
  const user = auth.current() || {};
  const providerKey = auth.mode === 'local' ? 'local' : user.provider || 'password';
  const providerName = t(`profile.providers.${providerKey}`);
  const canPw = auth.canChangePassword();

  const el = h(`<section class="subpage profile pf418 page-enter">
    <header class="pf418-head"><div class="pf418-brand">${logoMark(38)}<b dir="ltr">GoTriva <span>Trade AI</span></b></div><h1>${esc(t('profile.title'))}</h1><i aria-hidden="true"></i></header>
    <div class="profile-grid">
      <article class="card profile-card profile-photo fade-in">
        
        <div class="pp-wrap">
          <button type="button" class="pp-avatar" data-pick aria-label="${esc(t('profile.change'))}">
            <span class="pp-img">${avatarInner(user)}</span>
            <span class="pp-cam">${icons.camera}</span>
          </button>
          <div class="pf418-person"><div class="pp-name">${esc(user.name || user.email || '')}</div>
          <div class="pf418-plan" data-pf-plan>${esc(tx({ar:'جاري التحقق من الاشتراك…',en:'Checking subscription…'}))}</div><div class="muted mono pp-email">${esc(user.email || '')}</div></div>
        </div>
        <input type="file" accept="image/*" data-file hidden/>
        <div class="pp-actions">
          <button type="button" class="btn btn-primary btn-sm" data-pick>${icons.camera}<span>${esc(t('profile.change'))}</span></button>
          <button type="button" class="btn btn-sm btn-ghost" data-remove ${getAvatar(user) ? '' : 'hidden'}>${icons.trash}<span>${esc(t('profile.remove'))}</span></button>
        </div>
        <p class="muted pp-hint">${esc(t('profile.photoHint'))}</p>
      </article>

      <article class="card profile-card fade-in" style="animation-delay:60ms">
        <h2 class="card-title">${esc(t('profile.info'))}</h2>
        <form class="auth-form" data-name-form novalidate>
          <div class="field-wrap">
            <label class="field"><span class="visually-hidden">${esc(t('profile.name'))}</span><span class="field-icon">${icons.user}</span>
              <input name="name" type="text" maxlength="60" autocomplete="name" placeholder="${esc(t('profile.name'))}" value="${esc(user.name || '')}"/></label>
            <p class="field-error" data-error-for="name" role="alert"></p>
          </div>
          <dl class="kv-list">
            <div><dt>${esc(t('profile.email'))}</dt><dd class="mono">${esc(user.email || '')}</dd></div>
            <div><dt>${esc(t('profile.via'))}</dt><dd>${esc(providerName)}</dd></div>
          </dl>
          <button class="btn btn-primary" type="submit"><span data-label>${esc(t('profile.saveName'))}</span></button>
        </form>
      </article>

      <article class="card profile-card fade-in" style="animation-delay:120ms">
        <h2 class="card-title">${esc(t('profile.password'))}</h2>
        ${canPw ? `<form class="auth-form" data-pw-form novalidate>
          ${pwField('current', 'profile.current', 'current-password')}
          ${pwField('password', 'profile.next', 'new-password')}
          ${pwField('confirm', 'profile.confirm', 'new-password')}
          <div data-form-msg></div>
          <button class="btn btn-primary" type="submit"><span data-label>${esc(t('profile.updatePassword'))}</span></button>
        </form>` : `<div class="alert alert-info">${icons.info}<div>${esc(t('profile.noPassword', { provider: providerName }))}</div></div>`}
      </article>
    </div>
  </section>`);

  const $ = (s) => el.querySelector(s);

  // Photo
  const file = $('[data-file]');
  el.querySelectorAll('[data-pick]').forEach((b) => b.addEventListener('click', () => file.click()));
  file.addEventListener('change', async () => {
    const f = file.files[0];
    file.value = '';
    if (!f) return;
    try {
      const url = await resizeImage(f, 256);
      setAvatar(user, url);
      $('.pp-img').innerHTML = avatarInner(user);
      $('[data-remove]').hidden = false;
      toast(t('profile.photoSaved'), 'success');
    } catch (e) {
      toast(t(e.message === 'size' ? 'profile.photoSize' : e.message === 'type' ? 'profile.photoType' : 'profile.photoRead'), 'error');
    }
  });
  $('[data-remove]').addEventListener('click', () => {
    setAvatar(user, null);
    $('.pp-img').innerHTML = avatarInner(user);
    $('[data-remove]').hidden = true;
    toast(t('profile.photoRemoved'), 'info');
  });

  // Show/hide password
  el.querySelectorAll('[data-toggle-pw]').forEach((b) => b.addEventListener('click', () => {
    const input = b.parentElement.querySelector('input');
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    b.innerHTML = show ? icons.eyeOff : icons.eye;
  }));

  const setErr = (form, name, key, params) => {
    const p = form.querySelector(`[data-error-for="${name}"]`);
    if (!p) return;
    p.textContent = key ? t(`auth.err.${key}`, params) : '';
    p.closest('.field-wrap').querySelector('.field').classList.toggle('has-error', Boolean(key));
  };
  const busy = (form, on, labelKey) => {
    const b = form.querySelector('[type=submit]');
    b.disabled = on;
    b.querySelector('[data-label]').textContent = t(on ? 'profile.saving' : labelKey);
  };

  // Name
  const nameForm = $('[data-name-form]');
  nameForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = nameForm.elements.namedItem('name').value.trim();
    setErr(nameForm, 'name', name ? null : 'nameRequired');
    if (!name) return;
    busy(nameForm, true, 'profile.saveName');
    try {
      await auth.updateName(name);
      $('.pp-name').textContent = name;
      document.querySelectorAll('[data-user-name]').forEach((n) => { n.textContent = name; });
      toast(t('profile.nameSaved'), 'success');
    } catch (err) { toast(authErrorMessage(err, t), 'error'); }
    busy(nameForm, false, 'profile.saveName');
  });

  // Password
  const pwForm = $('[data-pw-form]');
  if (pwForm) {
    pwForm.addEventListener('input', (e) => setErr(pwForm, e.target.name, null));
    pwForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const v = Object.fromEntries(new FormData(pwForm));
      ['current', 'password', 'confirm'].forEach((n) => setErr(pwForm, n, null));
      pwForm.querySelector('[data-form-msg]').innerHTML = '';
      if (!v.current) { setErr(pwForm, 'current', 'passwordRequired'); return; }
      const errs = validate({ password: v.password, confirm: v.confirm }, 'reset');
      if (errs.password) { setErr(pwForm, 'password', errs.password, { n: authConfig.minPasswordLength }); return; }
      if (errs.confirm) { setErr(pwForm, 'confirm', errs.confirm); return; }
      if (v.password === v.current) { setErr(pwForm, 'password', 'samePassword'); return; }
      busy(pwForm, true, 'profile.updatePassword');
      try {
        await auth.changePassword(v.current, v.password);
        pwForm.reset();
        toast(t('profile.passwordSaved'), 'success');
      } catch (err) {
        if (err?.code === 'wrongPassword') setErr(pwForm, 'current', 'wrongPassword');
        else pwForm.querySelector('[data-form-msg]').innerHTML = `<div class="alert alert-error">${icons.alert}<div>${esc(authErrorMessage(err, t))}</div></div>`;
      }
      busy(pwForm, false, 'profile.updatePassword');
    });
  }
  // Language of the whole app (also auto-detected from the browser on the first visit / at sign-up).
  const langCard = h(`<article class="card profile-card fade-in"><h2 class="card-title">${icons.globe}<span>${esc(tx({ ar: 'لغة التطبيق', en: 'App language', he: 'שפת האפליקציה', es: 'Idioma de la app', zh: '应用语言' }))}</span></h2>
    <div class="seg profile-langs" role="radiogroup">${LANGS.map(([k, n]) => `<button type="button" data-set-lang="${k}" class="${getLang() === k ? 'is-on' : ''}" role="radio" aria-checked="${getLang() === k}">${n}</button>`).join('')}</div>
    <p class="muted">${esc(tx({ ar: 'بتتغيّر كل القوائم والأزرار والرسائل فورًا. اتجاه الصفحة بيتغيّر لحاله للعربي والعبري.', en: 'Menus, buttons and messages change at once. The page direction switches automatically for Arabic and Hebrew.', he: 'התפריטים, הכפתורים וההודעות משתנים מיד. כיוון העמוד מתחלף אוטומטית לערבית ועברית.', es: 'Los menús, botones y mensajes cambian al instante. La dirección cambia sola para árabe y hebreo.', zh: '菜单、按钮和消息立即切换。阿拉伯语和希伯来语自动从右到左显示。' }))}</p></article>`);
  langCard.addEventListener('click', (e) => { const b = e.target.closest('[data-set-lang]'); if (b) setLang(b.dataset.setLang); });
  el.append(langCard);
  // v249: trading style — «توصية AI» follows only this choice
  const TS = () => [['scalp', icons.bolt || '', tx({ ar: 'سكالب', en: 'Scalping', he: 'סקאלפינג', es: 'Scalping', zh: '短线' }), tx({ ar: 'صفقات سريعة على فريم 1–15 دقيقة.', en: 'Quick trades on 1–15 minute charts.', he: 'עסקאות מהירות בגרפים של 1–15 דקות.', es: 'Operaciones rápidas en gráficos de 1–15 minutos.', zh: '1–15 分钟图表上的快速交易。' })],
    ['swing', icons.trend || '', tx({ ar: 'سوينغ', en: 'Swing', he: 'סווינג', es: 'Swing', zh: '波段' }), tx({ ar: 'صفقات على فريم ساعة لـ يوم.', en: 'Trades on 1h–1D charts.', he: 'עסקאות בגרפים של שעה עד יום.', es: 'Operaciones en gráficos de 1h–1D.', zh: '1 小时至日线图表上的交易。' })]];
  const styleCard = h(`<article class="card profile-card fade-in" data-trading-style><h2 class="card-title">${icons.crosshair || ''}<span>${esc(tx({ ar: 'أسلوب التداول', en: 'Trading style', he: 'סגנון מסחר', es: 'Estilo de trading', zh: '交易风格' }))}</span></h2>
    <div class="seg profile-langs" role="radiogroup">${TS().map(([k, , n]) => `<button type="button" data-set-style="${k}" class="${getTradingStyle() === k ? 'is-on' : ''}" role="radio" aria-checked="${getTradingStyle() === k}">${esc(n)}</button>`).join('')}</div>
    <p class="muted" data-style-note></p></article>`);
  const styleNote = () => {
    const v = getTradingStyle(); const d = TS().find((x) => x[0] === v);
    styleCard.querySelector('[data-style-note]').textContent = d ? `${d[3]} ${tx({ ar: 'توصيات AI بتلتزم بهالأسلوب بس.', en: 'AI recommendations follow this style only.', he: 'המלצות ה-AI עוקבות אחרי הסגנון הזה בלבד.', es: 'Las recomendaciones de IA siguen solo este estilo.', zh: 'AI 推荐只遵循此风格。' })}`
      : tx({ ar: 'اختار أسلوبك، وتوصيات AI رح تلتزم فيه بس.', en: 'Choose your style; AI recommendations will follow it only.', he: 'בחר את הסגנון שלך; המלצות ה-AI יעקבו רק אחריו.', es: 'Elige tu estilo; las recomendaciones de IA solo lo seguirán.', zh: '选择你的风格；AI 推荐将只遵循它。' });
  };
  styleNote();
  styleCard.addEventListener('click', (e) => {
    const b = e.target.closest('[data-set-style]'); if (!b) return;
    setTradingStyle(b.dataset.setStyle);
    styleCard.querySelectorAll('[data-set-style]').forEach((x) => { const on = x === b; x.classList.toggle('is-on', on); x.setAttribute('aria-checked', String(on)); });
    styleNote(); toast(tx({ ar: 'انحفظ أسلوب التداول.', en: 'Trading style saved.', he: 'סגנון המסחר נשמר.', es: 'Estilo de trading guardado.', zh: '交易风格已保存。' }), 'success');
  });
  el.append(styleCard);
  // v403 «طريقتي بالتداول»: free text the AI reads, plus switches that really filter the tested strategies
  const way0 = getTraderWay();
  const W = (ar, en) => tx({ ar, en });
  const wayCard = h(`<article class="card profile-card fade-in" data-trader-way><h2 class="card-title">${icons.edit || icons.crosshair || ''}<span>${esc(W('طريقتي بالتداول', 'My way of trading'))}</span></h2>
    <label class="field"><span class="sr-only">${esc(W('اكتب طريقتك', 'Write your way'))}</span><textarea class="input" data-way-text rows="4" style="height:auto;min-height:96px;padding-block:10px;resize:vertical" maxlength="500" placeholder="${esc(W('مثلًا: بدخل مع الاتجاه بس، بحب ستوب قريب، ما بتداول وقت الأخبار، بفضّل الذهب بجلسة لندن…', 'e.g. I only trade with the trend, I like close stops, no trading around news, I prefer gold in the London session…'))}">${esc(way0.text)}</textarea></label>
    <p class="muted">${esc(W('نوع الدخول', 'Entry type'))}</p>
    <div class="seg profile-langs" data-way-entry role="radiogroup">${[['any', W('الاتنين', 'Both')], ['market', W('ماركت', 'Market')], ['limit', W('ليميت', 'Limit')]].map(([k, n]) => `<button type="button" data-entry="${k}" class="${way0.entry === k ? 'is-on' : ''}" role="radio" aria-checked="${way0.entry === k}">${esc(n)}</button>`).join('')}</div>
    <div class="seg profile-langs" data-way-flags>${[['trendOnly', W('مع الاتجاه بس', 'With the trend only')], ['tightStop', W('ستوب قريب', 'Close stop')], ['avoidNews', W('بلا أخبار', 'No news')]].map(([k, n]) => `<button type="button" data-flag="${k}" class="${way0[k] ? 'is-on' : ''}" aria-pressed="${way0[k]}">${esc(n)}</button>`).join('')}</div>
    <p class="muted">${esc(W('الـ AI بيقرأ طريقتك مع كل توصية، والخيارات بتحدد أي استراتيجيات مسموح تعطيك صفقة.', 'The AI reads your way with every recommendation, and the switches decide which strategies may give you a trade.'))}</p></article>`);
  const saved = () => toast(W('انحفظت طريقتك.', 'Your way is saved.'), 'success');
  let wt; wayCard.querySelector('[data-way-text]').addEventListener('input', (e) => { clearTimeout(wt); wt = setTimeout(() => { setTraderWay({ text: e.target.value }); saved(); }, 900); });
  wayCard.addEventListener('click', (e) => {
    const en = e.target.closest('[data-entry]'); const fl = e.target.closest('[data-flag]');
    if (en) { setTraderWay({ entry: en.dataset.entry }); wayCard.querySelectorAll('[data-entry]').forEach((x) => { const on = x === en; x.classList.toggle('is-on', on); x.setAttribute('aria-checked', String(on)); }); saved(); }
    if (fl) { const on = !getTraderWay()[fl.dataset.flag]; setTraderWay({ [fl.dataset.flag]: on }); fl.classList.toggle('is-on', on); fl.setAttribute('aria-pressed', String(on)); saved(); }
  });
  el.append(wayCard);
  // v395 my clock: every time in «توصية AI» (candles, validity, news) and what the AI is told uses this UTC offset
  const cur = (() => { try { return JSON.parse(localStorage.getItem(scopedRawKey(UTC_KEY)) || 'null'); } catch { return null; } })();
  // v402 pick by country (search in Arabic or English); the country's zone is saved, so summer time follows automatically
  const ccName = (c) => tx({ ar: c[1], en: c[0] });
  const offMin = (o) => { const m = /UTC([+-])(\d{2}):(\d{2})/.exec(o) || []; return (m[1] === '-' ? -1 : 1) * ((+m[2] || 0) * 60 + (+m[3] || 0)); };
  const zoneOpts = COUNTRY_ZONES.map((c) => ({ v: c[2], off: tzOffset(c[2]), name: ccName(c), find: `${c[0]} ${c[1]}`.toLowerCase() }))
    .sort((a, b) => offMin(a.off) - offMin(b.off) || a.name.localeCompare(b.name));
  const fixedOpts = Array.from({ length: 27 }, (_, i) => i - 12).map((n) => ({ v: String(n), off: `UTC${n >= 0 ? '+' : '−'}${String(Math.abs(n)).padStart(2, '0')}:00`, name: '', find: `utc${n >= 0 ? '+' : '-'}${n}` }));
  let curV = String(cur ?? '3');
  const optHtml = (q = '') => {
    const m = (o) => !q || o.find.includes(q) || o.off.toLowerCase().includes(q);
    const dev = `<option value="device" ${curV === 'device' ? 'selected' : ''}>${esc(tx({ ar: 'حسب جهازي', en: 'My device', he: 'לפי המכשיר', es: 'Mi dispositivo', zh: '跟随设备' }))}</option>`;
    const zs = zoneOpts.filter(m).map((o) => `<option value="${esc(o.v)}" ${curV === o.v ? 'selected' : ''}>${esc(`${o.off} · ${o.name}`)}</option>`).join('');
    const fx = fixedOpts.filter(m).map((o) => `<option value="${o.v}" ${curV === o.v ? 'selected' : ''}>${esc(o.off)}</option>`).join('');
    return dev + (zs ? `<optgroup label="${esc(tx({ ar: 'الدول', en: 'Countries' }))}">${zs}</optgroup>` : '') + (fx ? `<optgroup label="UTC">${fx}</optgroup>` : '');
  };
  const utcCard = h(`<article class="card profile-card fade-in"><h2 class="card-title">${icons.clock || icons.globe}<span>${esc(tx({ ar: 'توقيتي (UTC)', en: 'My time zone (UTC)', he: 'אזור הזמן שלי (UTC)', es: 'Mi zona horaria (UTC)', zh: '我的时区 (UTC)' }))}</span></h2>
    <label class="field"><span class="sr-only">${esc(tx({ ar: 'دوّر على دولتك', en: 'Search your country' }))}</span><input class="input" type="search" data-utc-q placeholder="${esc(tx({ ar: 'دوّر على دولتك…', en: 'Search your country…' }))}" autocomplete="off"></label>
    <label class="field"><span class="sr-only">UTC</span><select class="input" data-utc>${optHtml()}</select></label>
    <p class="muted" data-utc-now>${esc(tzLabel(userTz()))}</p></article>`);
  const sel = utcCard.querySelector('[data-utc]');
  utcCard.querySelector('[data-utc-q]').addEventListener('input', (e) => { sel.innerHTML = optHtml(e.target.value.trim().toLowerCase()); });
  sel.addEventListener('change', (e) => { curV = e.target.value; try { localStorage.setItem(scopedRawKey(UTC_KEY), JSON.stringify(e.target.value)); } catch { /* */ } utcCard.querySelector('[data-utc-now]').textContent = tzLabel(userTz()); toast(tx({ ar: `انحفظ: ${tzLabel(userTz())}`, en: `Saved: ${tzLabel(userTz())}` }), 'success'); });
  el.append(utcCard);
  // The user's SMC / ICT assistant trades (kept in their account when the server is reachable).
  const hist = h(`<article class="card profile-card sa-profile fade-in"><h2 class="card-title">${icons.crosshair}<span>${esc(t('sa.history.title'))}</span></h2><div data-sa-hist-full></div></article>`);
  el.append(hist);
  renderHistory(hist.querySelector('[data-sa-hist-full]'));
  const face = faceCard();
  const grid = $('.profile-grid');
  const [photo, info, password] = grid.children;
  const L = (ar,en) => tx({ar,en});
  const stats = h(`<section class="pf418-stats" aria-label="${esc(L('إحصائيات توصيات التداول المباشرة المحفوظة','Saved live-market trade recommendations'))}"></section>`);
  const paintStats = () => {
    const items = listTrades().filter(x => x.mode === 'live');
    const st = historyStats(items);
    const month = new Date(); month.setDate(1); month.setHours(0,0,0,0);
    const monthly = historyStats(items.filter(x => Number(x.closedAt)*1000 >= +month));
    const metrics = [[icons.crosshair,L('نسبة النجاح','Win rate'),st.winRate == null?'—':`${(st.winRate*100).toFixed(1)}%`],[icons.bars,L('نتيجة الشهر (R)','Monthly result (R)'),monthly.closed?`${monthly.totalR>0?'+':''}${monthly.totalR}R`:'—'],[icons.layers,L('الصفقات المحفوظة','Saved trades'),st.n],[icons.calendar,L('الصفقات المغلقة','Closed trades'),st.closed]];
    stats.innerHTML = metrics.map(([ic,label,value])=>`<div>${ic}<b dir="ltr">${esc(value)}</b><small>${esc(label)}</small></div>`).join('');
  };
  paintStats(); const off = onTrades(()=>{if(el.isConnected)paintStats();else off();});
  const settings = h(`<section class="pf418-settings"><h2>${icons.settings}${esc(L('إعدادات الحساب','Account settings'))}</h2></section>`);
  const wrap = (icon, title, desc, cards) => {
    const d=h(`<details class="pf418-item"><summary><span class="pf418-icon">${icon}</span><span class="pf418-copy"><b>${esc(title)}</b><small>${esc(desc)}</small></span><span class="pf418-arrow" aria-hidden="true">›</span></summary><div class="pf418-content"></div></details>`);
    d.lastElementChild.append(...cards); settings.append(d); return d;
  };
  const link = (icon,title,desc,route) => settings.append(h(`<a class="pf418-item pf418-link" href="${route}"><span class="pf418-icon">${icon}</span><span class="pf418-copy"><b>${esc(title)}</b><small>${esc(desc)}</small></span><span class="pf418-arrow" aria-hidden="true">›</span></a>`));
  const account = wrap(icons.user,L('بيانات الحساب','Account details'),L('الاسم والبريد الإلكتروني','Name and email'),[info]);
  wrap(icons.lock,L('الأمان وكلمة المرور','Security & password'),L('تغيير كلمة المرور','Change your password'),[password]);
  link(icons.layers,L('الاشتراك والباقات','Subscription & plans'),L('عرض وإدارة اشتراكك','View and manage your subscription'),'#/app/billing');
  link(icons.shield,L('سجل الأجهزة والدخول','Devices & sign-in history'),L('مراجعة عمليات تسجيل الدخول','Review recent sign-ins'),'#/app/connect');
  link(icons.bell,L('الإشعارات','Notifications'),L('تخصيص التنبيهات والربط','Manage alerts and integrations'),'#/app/connect');
  const appearance = h(`<article class="card profile-card"><button class="btn" type="button" data-pf-theme>${icons.moon}${esc(L('تبديل المظهر','Toggle appearance'))}</button></article>`);
  appearance.querySelector('button').onclick=()=>document.querySelector('[data-theme-toggle]')?.click();
  wrap(icons.globe,L('اللغة والمظهر','Language & appearance'),L('لغة التطبيق والوضع الليلي أو النهاري','App language and light or dark mode'),[langCard,appearance]);
  wrap(icons.candles,L('تفضيلات التداول','Trading preferences'),L('الأسلوب والتوقيت وطريقة التداول','Style, time zone and trading setup'),[styleCard,wayCard,utcCard]);
  wrap(icons.bars,L('سجل التداول','Trade history'),L('الصفقات والنتائج والتصدير','Trades, results and export'),[hist]);
  const edit=h(`<button class="pf418-edit" type="button">${icons.settings}${esc(L('تعديل','Edit'))}</button>`); photo.append(edit);
  edit.onclick=()=>{account.open=true;account.scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});account.querySelector('input')?.focus({preventScroll:true});};
  grid.replaceWith(photo,stats,face,settings);
  const planNode=photo.querySelector('[data-pf-plan]');
  apiRequest('GET','/api/billing/me',undefined,5000).then(me=>{
    if(!el.isConnected || auth.current()?.uid!==user.uid)return;
    planNode.textContent=me.owner?L('مالك الحساب','Owner'):me.subscription?.product?String(me.subscription.product).toUpperCase():me.enforce===false?L('وصول مفتوح','Open access'):me.plan==='free'?L('عضوية مجانية','Free membership'):L('عرض الاشتراك','View subscription');
  }).catch(()=>{if(el.isConnected)planNode.textContent=L('تعذر التحقق من الاشتراك','Subscription unavailable');});
  const data = h(accountDataHtml()); wrap(icons.shield,L('خصوصية الحساب','Account privacy'),L('تنزيل البيانات وإدارة الحساب','Export data and manage account'),[data]); bindAccountData(data);
  return el;
}
