// Face sign-in in the browser: the device's own face unlock (Face ID, Android face unlock, Windows Hello) unlocks a passkey.
// No camera picture is taken by the site and nothing about the face leaves the device.
import { apiRequest } from './ai/gateway.js';
import { auth } from './auth/index.js';
import { storage } from '../utils/storage.js';

import { decodeBase64url as b2a } from '../utils/base64url.js';
const a2b = (buf) => { let s = ''; for (const x of new Uint8Array(buf)) s += String.fromCharCode(x); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
const fail = (code) => Object.assign(new Error(code), { code });

/** true when the browser supports WebAuthn; the OS decides available verification methods. */
export async function faceSupported() {
  try { return Boolean(window.isSecureContext && auth.mode === 'firebase' && window.PublicKeyCredential && navigator.credentials?.create && navigator.credentials?.get); } catch { return false; }
}
export const faceHint = () => Boolean(storage.get('face-on-device', false));
export const faceHintId = () => { const v = storage.get('face-on-device'); return typeof v === 'string' ? v : null; };
export const prepareFaceEnrollment = () => apiRequest('POST', '/api/face/register/options', {}, 15000);
export async function prepareFaceSignIn() { const o = await apiRequest('POST', '/api/face/login/options', {}, 15000); if (!o.configured) throw fail('not_configured'); return o; }
const browserError = e => fail(({InvalidStateError:'already_registered', NotAllowedError:'cancelled', AbortError:'cancelled', SecurityError:'origin_mismatch', NotSupportedError:'unsupported', ConstraintError:'unsupported'})[e?.name] || 'device_error');
export const faceStatus = () => apiRequest('GET', '/api/face/status', undefined, 10000);

/** Turn on face sign-in for THIS device (the account must have signed in within the last 10 minutes). */
export async function enrollFace(name, o) {
  if (!o) o = await prepareFaceEnrollment();
  const pk = o.publicKey;
  let cred;
  try { cred = await navigator.credentials.create({ publicKey: { ...pk, challenge: b2a(pk.challenge), user: { ...pk.user, id: b2a(pk.user.id) }, excludeCredentials: (pk.excludeCredentials || []).map((c) => ({ ...c, id: b2a(c.id) })) } }); }
  catch (e) { throw browserError(e); }
  if (!cred) throw fail('cancelled');
  const r = await apiRequest('POST', '/api/face/register', { challengeId: o.challengeId, name, credential: { id: cred.id, rawId: a2b(cred.rawId), type: cred.type, response: { clientDataJSON: a2b(cred.response.clientDataJSON), attestationObject: a2b(cred.response.attestationObject) } } }, 15000);
  storage.set('face-on-device', r.id);
  return r;
}

/** Sign in with the face: the device asks for Face ID / face unlock, the server checks the signature and returns a sign-in token. */
export async function faceSignIn(o) {
  if (!o) o = await prepareFaceSignIn();
  const pk = o.publicKey;
  let a;
  try { a = await navigator.credentials.get({ publicKey: { ...pk, challenge: b2a(pk.challenge), allowCredentials: [] }, mediation: 'optional' }); }
  catch (e) { throw browserError(e); }
  if (!a) throw fail('cancelled');
  const r = await apiRequest('POST', '/api/face/login', { challengeId: o.challengeId, credential: { id: a.id, type: a.type, response: { clientDataJSON: a2b(a.response.clientDataJSON), authenticatorData: a2b(a.response.authenticatorData), signature: a2b(a.response.signature), userHandle: a.response.userHandle ? a2b(a.response.userHandle) : null } } }, 15000);
  await auth.signInWithToken(r.token);
  storage.set('face-on-device', r.id || true);
  return auth.current();
}
export const removeFace = (id = null) => apiRequest('DELETE', '/api/face', id ? { id } : {}, 10000);
