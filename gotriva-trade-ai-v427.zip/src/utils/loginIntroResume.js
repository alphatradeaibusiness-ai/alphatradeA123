const KEY = 'gt:login-intro-resume';
export function queueLoginIntro(storage, scope, now = Date.now()) {
  try { if (scope && scope !== 'guest') storage.setItem(KEY, JSON.stringify({ scope, at: now })); } catch {}
}
export function consumeLoginIntro(storage, scope, now = Date.now()) {
  try {
    const raw = storage.getItem(KEY); storage.removeItem(KEY);
    const pending = JSON.parse(raw || 'null');
    return Boolean(pending && scope && scope !== 'guest' && pending.scope === scope && Number.isFinite(pending.at) && now >= pending.at && now - pending.at < 120000);
  } catch { return false; }
}
