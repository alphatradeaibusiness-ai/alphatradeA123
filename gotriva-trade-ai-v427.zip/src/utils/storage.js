// Account namespace is fixed for the lifetime of the document. A session change
// reloads the app before another account can use its in-memory state.
const PREFIX = 'ata:';
const DEVICE = new Set(['demo-users','demo-session','demo-lock','lang','theme','ref-code','face-on-device','palette']);
let scope = '';
export function accountScope(user) { return user?.uid ? `firebase:${user.uid}` : user?.email ? `local:${user.email.toLowerCase()}` : 'guest'; }
export function bindStorageScope(user) {
  scope = accountScope(user);
  // Only migrate legacy keys whose original writer explicitly used this exact
  // account ID. Never migrate unowned journals, alerts or settings.
  const id = user?.uid || user?.email;
  if (!id) return;
  const owned = ['avatar','assist-trades','trading-style','trader-way'];
  if (user.uid) owned.push('ai-paper','ai-decisions','ai-bt','assist-settings','assist-watch','phone-pending','tour:v1');
  for (const name of owned) safe(() => {
    const key = `${name}:${id}`, old = PREFIX + key, next = full(key);
    const value = localStorage.getItem(old);
    if (value !== null && localStorage.getItem(next) === null) {
      JSON.parse(value); localStorage.setItem(next, value);
      localStorage.removeItem(old);
    }
  });
}
export function storageScope() { return scope; }
const prefix = (s = scope) => `${PREFIX}account:${encodeURIComponent(s)}:`;
const full = key => !scope || DEVICE.has(key) ? PREFIX + key : prefix() + key;
export const scopedRawKey = key => scope ? prefix() + 'raw:' + key : key;
function safe(fn, fallback) { try { return fn(); } catch { return fallback; } }
const setListeners = new Set();
export const storage = {
  get(key, fallback = null, area = 'local') { return safe(() => { const raw = (area === 'session' ? sessionStorage : localStorage).getItem(full(key)); return raw === null ? fallback : JSON.parse(raw); }, fallback); },
  raw(key) { return safe(() => localStorage.getItem(full(key)), null); },
  set(key, value, area = 'local') { safe(() => (area === 'session' ? sessionStorage : localStorage).setItem(full(key), JSON.stringify(value))); if (area === 'local') for (const fn of setListeners) { try { fn(key); } catch {} } },
  onSet(fn) { setListeners.add(fn); return () => setListeners.delete(fn); },
  remove(key) { safe(() => localStorage.removeItem(full(key))); safe(() => sessionStorage.removeItem(full(key))); },
};
// Never infer ownership of legacy unscoped records. Leave them intact for an
// explicit recovery workflow, rather than copying them to the first login.
export function exportAccountStorage(user) {
  const p = prefix(accountScope(user)); const out = Object.create(null);
  if (!user || accountScope(user) !== scope) return out;
  safe(() => { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (!k?.startsWith(p)) continue; const name = k.slice(p.length); if (/secret|token|password|stamp|lock|session|peerkey/i.test(name)) continue; const raw = localStorage.getItem(k); try { out[name] = JSON.parse(raw); } catch { out[name] = raw; } } });
  return out;
}
export function clearAccountStorage(user) {
  if (!user) return;
  const p = prefix(accountScope(user));
  for (const area of ['local','session']) safe(() => { const s = area === 'local' ? localStorage : sessionStorage; const keys = []; for (let i = 0; i < s.length; i++) { const k = s.key(i); if (k?.startsWith(p)) keys.push(k); } for (const k of keys) s.removeItem(k); });
}

// Cache keys use the fixed document account scope, never an API response identity.
export function chatCachePrefix() { return scopedRawKey('gt-cache:'); }
export function clearChatCache({ messagesOnly = false, keepOutbox = true } = {}) {
  if (!scope || scope === 'guest') return;
  const p = chatCachePrefix();
  safe(() => { const keys = []; for (let i=0;i<localStorage.length;i++) { const k=localStorage.key(i); if (k?.startsWith(p) && (!messagesOnly || k.startsWith(p+'m:')) && (!keepOutbox || k !== p+'outbox')) keys.push(k); } for (const k of keys) localStorage.removeItem(k); });
}
// Old cache keys were explicitly UID-owned; restrict migration to unambiguous IDs.
export function migrateChatCache(user) {
  const uid=user?.uid; if (!uid || accountScope(user)!==scope || !/^[A-Za-z0-9_-]+$/.test(uid)) return;
  const old='gt-cache:'+uid+':', next=chatCachePrefix();
  safe(() => { const keys=[]; for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i); if(k?.startsWith(old)) keys.push(k); } for(const k of keys){const suffix=k.slice(old.length); if(!/^(list|outbox|m:[^:]+)$/.test(suffix)) continue; const value=localStorage.getItem(k); if(value===null || localStorage.getItem(next+suffix)!==null) continue; try { JSON.parse(value); localStorage.setItem(next+suffix,value); localStorage.removeItem(k); } catch {} } });
}
