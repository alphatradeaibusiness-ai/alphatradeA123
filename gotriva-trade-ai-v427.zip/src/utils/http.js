// fetch() with a timeout and consistent, user-presentable errors.
export class RequestError extends Error {
  constructor(code, message, status) {
    super(message);
    this.code = code; // 'timeout' | 'http' | 'offline' | 'parse' | 'provider'
    this.status = status;
  }
}

export async function fetchJson(url, { timeoutMs = 9000, ...init } = {}) {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) throw new RequestError('offline', 'offline');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  let res, body;
  const { rejectStale, ...fetchInit } = init;
  const signal = init.signal ? AbortSignal.any([ctrl.signal, init.signal]) : ctrl.signal;
  try {
    res = await fetch(url, { ...fetchInit, signal });
    if (rejectStale && res.headers?.get('X-Cache') === 'STALE') throw new RequestError('provider', 'Stale market data');
    try { body = await res.json(); }
    catch (e) {
      if (signal.aborted) throw e;
      if (!res.ok) throw new RequestError('http', `HTTP ${res.status}`, res.status);
      throw new RequestError('parse', 'invalid JSON');
    }
  } catch (e) {
    if (e instanceof RequestError) throw e;
    if (ctrl.signal.aborted) throw new RequestError('timeout', 'timeout');
    if (init.signal?.aborted) throw new RequestError('cancelled', 'cancelled');
    let host = '';
    try { host = new URL(url, location.href).host; } catch { /* ignore */ }
    throw new RequestError('network', host || e.message || 'network error');
  } finally { clearTimeout(timer); }

  if (!res.ok) throw new RequestError('http', body?.error || body?.msg || body?.message || `HTTP ${res.status}`, res.status);
  return body;
}

/** Turn an error into a translated, short message. */
export function describeError(err, t) {
  if (!err) return '';
  if (err.code === 'timeout') return t('errors.timeout');
  if (err.code === 'offline') return t('errors.offline');
  if (err.code === 'network') return t('errors.network', { host: err.message });
  if (err.code === 'parse') return t('errors.parse');
  const m = String(err.message || '');
  if (/available starting with|upgrad/i.test(m)) return t('errors.planRequired');
  if (/symbol.*(missing|invalid)|invalid.*symbol/i.test(m)) return t('errors.symbolInvalid');
  if (/api ?key/i.test(m)) return t('errors.badKey');
  if (/run out of api credits|limit/i.test(m)) return t('errors.rateLimit');
  if (err.code === 'http') return `${t('errors.http', { status: err.status })}${err.message && !/^HTTP/.test(err.message) ? ` — ${err.message}` : ''}`;
  return err.message || String(err);
}
