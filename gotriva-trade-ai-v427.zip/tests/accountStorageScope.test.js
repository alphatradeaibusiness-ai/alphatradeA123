import test from 'node:test';
import assert from 'node:assert/strict';
import { storage, bindStorageScope, exportAccountStorage, clearAccountStorage, chatCachePrefix, clearChatCache, migrateChatCache } from '../src/utils/storage.js';
function memory(){ const m=new Map(); return {get length(){return m.size},key:i=>[...m.keys()][i]??null,getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k)}; }
test('legacy records never assigned to either account; scoped export and delete',()=>{
 globalThis.localStorage=memory(); globalThis.sessionStorage=memory();
 localStorage.setItem('ata:journal','["legacy"]'); localStorage.setItem('ata:demo-users','{"private":true}');
 const a={uid:'a'},b={uid:'a:b'};
 bindStorageScope(a); assert.deepEqual(storage.get('journal',[]),[]); storage.set('journal',['A']); storage.set('settings',{risk:1}); storage.set('alerts',['alertA'],'session');
 bindStorageScope(b); assert.deepEqual(storage.get('journal',[]),[]); assert.equal(storage.raw('settings'),null); storage.set('journal',['B']);
 assert.deepEqual({...exportAccountStorage(a)},{}); bindStorageScope(a); assert.deepEqual({...exportAccountStorage(a)},{journal:['A'],settings:{risk:1}}); bindStorageScope(b);
 clearAccountStorage(a); assert.deepEqual(storage.get('journal'),['B']); assert.equal(localStorage.getItem('ata:journal'),'["legacy"]'); assert.ok(localStorage.getItem('ata:demo-users'));
 bindStorageScope(a); assert.equal(storage.get('alerts',null,'session'),null); assert.equal(storage.get('journal'),null);
});
test('guest and local demo identity cannot see Firebase records',()=>{
 bindStorageScope({uid:'same'}); storage.set('risk',7); bindStorageScope({email:'same'}); assert.equal(storage.get('risk'),null); storage.set('risk',2); bindStorageScope(null); assert.equal(storage.get('risk'),null); bindStorageScope({uid:'same'}); assert.equal(storage.get('risk'),7);
});

test('chat cache migration and eviction stay within account',()=>{
 globalThis.localStorage=memory(); globalThis.sessionStorage=memory(); const a={uid:'a'},b={uid:'b'};
 localStorage.setItem('gt-cache:a:outbox','[1]'); localStorage.setItem('gt-cache:b:m:room','[2]');
 bindStorageScope(a); migrateChatCache(a); const ap=chatCachePrefix(); assert.equal(localStorage.getItem(ap+'outbox'),'[1]'); assert.equal(localStorage.getItem('gt-cache:a:outbox'),null); localStorage.setItem(ap+'m:room','[3]');
 bindStorageScope(b); migrateChatCache(b); const bp=chatCachePrefix(); assert.equal(localStorage.getItem(bp+'m:room'),'[2]'); clearChatCache({messagesOnly:true}); assert.equal(localStorage.getItem(ap+'m:room'),'[3]');
 bindStorageScope(a); clearChatCache(); assert.equal(localStorage.getItem(ap+'outbox'),'[1]'); assert.equal(localStorage.getItem(ap+'m:room'),null);
});
