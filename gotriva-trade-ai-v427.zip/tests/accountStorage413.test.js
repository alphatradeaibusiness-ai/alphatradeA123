import test from 'node:test';
import assert from 'node:assert/strict';
import { storage, bindStorageScope, exportAccountStorage, clearAccountStorage, scopedRawKey } from '../src/utils/storage.js';
class Memory { m = new Map(); get length(){return this.m.size;} key(i){return [...this.m.keys()][i]??null;} getItem(k){return this.m.get(k)??null;} setItem(k,v){this.m.set(k,String(v));} removeItem(k){this.m.delete(k);} }
globalThis.localStorage = new Memory(); globalThis.sessionStorage = new Memory();
test('legacy unowned records remain intact, new records isolated, exports and deletion limited to account',()=>{
 const A={uid:'a'},B={uid:'b'}; localStorage.setItem('ata:journal','["legacy"]');
 bindStorageScope(A); assert.deepEqual(storage.get('journal',[]),[]); storage.set('journal',['A']); storage.set('sync-ts',123); storage.set('theme','light'); storage.set('secret','private'); storage.set('bank-session','x','session');
 const rawA=scopedRawKey('gt:bank-session'); bindStorageScope(B); assert.notEqual(scopedRawKey('gt:bank-session'),rawA); assert.equal(storage.get('sync-ts',0),0); assert.deepEqual(storage.get('journal',[]),[]); assert.equal(storage.get('theme'),'light'); storage.set('journal',['B']); assert.deepEqual({...exportAccountStorage(B)},{journal:['B']}); assert.deepEqual({...exportAccountStorage(A)},{});
 bindStorageScope(A); assert.deepEqual(storage.get('journal'),['A']); assert.equal(exportAccountStorage(A).secret,undefined); clearAccountStorage(A); assert.equal(storage.get('bank-session',null,'session'),null); bindStorageScope(B); assert.deepEqual(storage.get('journal'),['B']); assert.equal(localStorage.getItem('ata:journal'),'["legacy"]');
});
test('local demo accounts and guest separated; demo auth storage stays available',()=>{ bindStorageScope({email:'A@x.co'}); storage.set('risk',1); storage.set('demo-session',{email:'A@x.co'}); bindStorageScope({email:'b@x.co'}); assert.equal(storage.get('risk'),null); assert.equal(storage.get('demo-session').email,'A@x.co'); bindStorageScope(null); assert.equal(storage.get('risk'),null); });
test('only exact previously owner-keyed legacy records migrate',()=>{localStorage.setItem('ata:avatar:a413','"old-a"');localStorage.setItem('ata:avatar:b413','"old-b"');localStorage.setItem('ata:journal','["unknown"]');bindStorageScope({uid:'a413'});assert.equal(storage.get('avatar:a413'),'old-a');assert.equal(storage.get('avatar:b413'),null);assert.equal(localStorage.getItem('ata:avatar:b413'),'"old-b"');assert.equal(localStorage.getItem('ata:journal'),'["unknown"]');});
