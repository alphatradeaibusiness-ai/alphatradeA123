import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { decodeBase64url } from '../src/utils/base64url.js';
test('WebAuthn base64url decodes 32-byte challenges and handles, and arbitrary credential lengths', () => {
 for(let n=0;n<=256;n++){const bytes=randomBytes(n);assert.deepEqual(Buffer.from(decodeBase64url(bytes.toString('base64url'))),bytes);}
});
