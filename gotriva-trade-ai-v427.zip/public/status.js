(function () {
  var sum = document.getElementById('sum'), rows = document.getElementById('rows');
  function row(cls, ar, en, val) { return '<div class="row ' + cls + '"><span><span class="dot"></span>' + ar + ' <small>· ' + en + '</small></span><b>' + val + '</b></div>'; }
  function load() {
    fetch('/api/health', { cache: 'no-store' }).then(function (r) { if (!r.ok) throw new Error("health HTTP " + r.status); return r.json(); }).then(function (h) {
      if (!h || h.ok !== true) throw new Error("invalid health response");
      var busy = h.load && h.load.overloaded;
      sum.className = 'card ' + (busy ? 'warn' : 'ok');
      sum.innerHTML = '<span class="dot"></span>' + (busy ? 'الموقع شغّال بس عليه ضغط · Up, under load' : 'السيرفر يستجيب · Server responding');
      var up = Math.round((h.uptimeS || 0) / 60);
      rows.innerHTML = row('ok', 'السيرفر', 'Server', 'شغّال · ' + up + ' min') +
        row(h.durable && h.durable.enabled ? (h.durable.ok === false || h.durable.stale ? 'warn' : 'ok') : 'warn', 'حفظ البيانات', 'Data copy', h.durable && h.durable.enabled ? (h.durable.ok === false ? 'Error' : h.durable.stale ? 'Stale' : 'On') : 'Local') +
        row('warn', 'الأسعار والتحليل', 'Prices & analysis', 'غير مفحوص · Not checked');
    }).catch(function () {
      sum.className = 'card bad'; sum.innerHTML = '<span class="dot"></span>الموقع مش متاح هلّق، بنشتغل عليه · The site is unavailable right now';
      rows.innerHTML = '';
    });
  }
  load(); setInterval(load, 30000);
})();
