(() => {
  let lang = 'ar';
  try { lang = JSON.parse(localStorage.getItem('ata:lang')) || (navigator.language || 'ar').slice(0,2); } catch {}
  const copy = { ar:['تحليل تداول للكريبتو والذهب والفوركس والمؤشرات','جاري التحميل…','نحضّر أدوات التحليل والتداول'], en:['Crypto, gold, forex and index analysis','Loading…','Preparing your trading and analysis tools'], he:['ניתוח קריפטו, זהב, מט״ח ומדדים','טוען…','מכינים את כלי המסחר והניתוח'], es:['Análisis de criptomonedas, oro, forex e índices','Cargando…','Preparando las herramientas de análisis'], zh:['加密货币、黄金、外汇和指数分析','正在加载…','正在准备交易分析工具'] };
  if (!copy[lang]) lang='ar';
  const panel = document.querySelector('.startup-panel');
  if (!panel) return;
  panel.lang=lang; panel.dir=['ar','he'].includes(lang)?'rtl':'ltr';
  ['.startup-tag','h2','.startup-hint'].forEach((sel,i)=>{const el=panel.querySelector(sel);if(el)el.textContent=copy[lang][i];});
})();
