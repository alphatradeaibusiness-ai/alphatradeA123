// Bounded, single-instance admission control. Edge WAF remains necessary.
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import crypto from 'node:crypto';
export function normalizeIp(value) {
  const s = String(value || '').trim().replace(/^::ffff:(?=\d)/i, '');
  if (net.isIP(s) === 4) return s;
  if (net.isIP(s) === 6 && !s.includes('%')) return new URL(`http://[${s}]/`).hostname.slice(1,-1);
  return null;
}
export function createSecurityShield({dir, now = Date.now, env = process.env} = {}) {
  const limit = (k,d,min,max) => Math.max(min,Math.min(max,Number.isFinite(Number(env[k])) && env[k] !== '' && env[k] != null ? Math.floor(Number(env[k])) : d));
  const cfg = { global:limit('SHIELD_GLOBAL_RPM',12000,100,1000000), ip:limit('SHIELD_IP_RPM',900,30,100000), active:limit('SHIELD_CONCURRENCY',250,10,5000), perIp:limit('SHIELD_IP_CONCURRENCY',40,4,500), maxKeys:limit('SHIELD_MAX_IPS',20000,100,100000), maxBody:limit('SHIELD_MAX_BODY',56*1024*1024,1024,128*1024*1024) };
  const file = dir && path.join(dir,'shield-policy.json');
  let emergency = false, storageError = false; const bans = new Map(), ips = new Map(), activeIps = new Map();
  const recent = [], audit = []; let total = 0, blocked = 0, active = 0, globalWindow = -1, globalCount = 0; const reasons = Object.create(null);
  const started = now();
  const originSecret=String(env.SHIELD_ORIGIN_SECRET||'');
  const edgeRequired=originSecret.length>=32;
  if(originSecret && !edgeRequired) throw new Error('SHIELD_ORIGIN_SECRET must be at least 32 characters');
  const peerOk=(req)=>{const h=Buffer.from(String(req.headers['x-gotriva-origin']||'')), k=Buffer.from(originSecret);return h.length===k.length&&crypto.timingSafeEqual(h,k);};
  if (file) try { const v = JSON.parse(fs.readFileSync(file,'utf8')); emergency = v.emergency === true; for(const b of (Array.isArray(v.bans)?v.bans:[]).slice(0,10000)) if(normalizeIp(b.ip) && Number.isFinite(b.until) && b.until>now()) bans.set(normalizeIp(b.ip),b); for(const a of (Array.isArray(v.audit)?v.audit:[]).slice(0,300)) audit.push(a); } catch(e){ if(e.code !== 'ENOENT') storageError=true; }
  function save() { if(!file) return; fs.mkdirSync(dir,{recursive:true,mode:0o700}); const tmp=file+'.tmp'; fs.writeFileSync(tmp,JSON.stringify({emergency,bans:[...bans.values()],audit}),{mode:0o600}); fs.renameSync(tmp,file); }
  function prune(t) { for(const [ip,b] of bans) if(b.until<=t) bans.delete(ip); }
  function deny(code,status,ip,req) { blocked++; reasons[code]=(reasons[code]||0)+1; recent.unshift({at:now(),code,status,ip,path:String(req.url||'').split('?')[0].slice(0,120).replace(/[\x00-\x1f\x7f]/g,'')}); if(recent.length>200) recent.pop(); return {code,status}; }
  function enter(req,res,rawIp) {
    total++; const ip=normalizeIp(rawIp)||'unknown', t=now(), w=Math.floor(t/60000), raw=String(req.url||'');
    if(raw==='/api/health' && req.method==='GET') return null; // cheap liveness, edge limits still apply
    if(!raw.startsWith('/') || raw.startsWith('//') || raw.length>8192 || /[\x00-\x20\x7f]/.test(raw)) return deny('invalid_target',400,ip,req);
    const p=raw.split('?')[0];
    if(edgeRequired && !peerOk(req) && !(env.SHIELD_ALLOW_LOCAL_ORIGIN==='1' && ['127.0.0.1','::1'].includes(normalizeIp(req.socket?.remoteAddress)))) return deny('origin_denied',403,ip,req);
    if(/^\/api(?:\/|$)/i.test(p) && /(?:^|\/)\.{1,2}(?:\/|$)|%2e|%2f|%5c|\\/i.test(p)) return deny('bad_path',400,ip,req);
    const len=req.headers['content-length']; if(len!==undefined && (!/^\d+$/.test(String(len)) || Number(len)>cfg.maxBody)) return deny('body_limit',413,ip,req);
    const b=bans.get(ip); if(b && b.until>t) return deny('ip_banned',403,ip,req); if(b) bans.delete(ip);
    if(globalWindow!==w){globalWindow=w;globalCount=0;ips.clear();} globalCount++;
    if(globalCount>(emergency?Math.floor(cfg.global/2):cfg.global)) return deny('global_rate',503,ip,req);
    if(!ips.has(ip)&&ips.size>=cfg.maxKeys) return deny('ip_capacity',503,ip,req);
    const n=(ips.get(ip)||0)+1;ips.set(ip,n); if(n>(emergency?Math.floor(cfg.ip/3):cfg.ip)) return deny('ip_rate',429,ip,req);
    if(active>=cfg.active || (activeIps.get(ip)||0)>=cfg.perIp) return deny('concurrency',503,ip,req);
    active++; activeIps.set(ip,(activeIps.get(ip)||0)+1);
    let released=false; const release=()=>{if(released)return;released=true;active--;const n=(activeIps.get(ip)||1)-1;if(n)activeIps.set(ip,n);else activeIps.delete(ip);};
    res.once('finish',release);res.once('close',release);return null;
  }
  function change(body,actor,sourceIp){
    const t=now();prune(t); const action=body?.action; const reason=typeof body?.reason==='string'?body.reason.trim().slice(0,200):'';
    if(!reason || !['ban','unban','emergency'].includes(action)) return {error:'invalid_action'};
    const ip=normalizeIp(body.ip); if(action!=='emergency' && (!ip || (action==='ban' && ip===normalizeIp(sourceIp)))) return {error:'invalid_or_self_ip'};
    if(action==='ban' && (!Number.isInteger(body.minutes)||body.minutes<1||body.minutes>43200||(!bans.has(ip)&&bans.size>=10000))) return {error:'invalid_duration_or_capacity'};
    if(action==='emergency'&&typeof body.enabled!=='boolean')return {error:'invalid_action'};
    const oldEmergency=emergency, oldBan=bans.get(ip), oldAudit=audit.slice();
    if(action==='ban') bans.set(ip,{ip,until:t+body.minutes*60000,reason}); else if(action==='unban') bans.delete(ip); else emergency=body.enabled;
    audit.unshift({at:t,actor:String(actor).slice(0,128),action,ip:ip||null,reason,enabled:action==='emergency'?emergency:undefined}); audit.length=Math.min(audit.length,300);
    try{save();storageError=false;}catch{emergency=oldEmergency;if(oldBan)bans.set(ip,oldBan);else bans.delete(ip);audit.splice(0,audit.length,...oldAudit);storageError=true;return {error:'storage_failed'};}
    return {ok:true};
  }
  function summary(){prune(now());return {started,at:now(),total,blocked,active,reasons:{...reasons},emergency,storageError,limits:cfg,bans:[...bans.values()].slice(0,500),banCount:bans.size,recent:recent.slice(0,100),audit:audit.slice(0,100),scope:'single_process',originGuardEnabled:edgeRequired,edgeVerified:false};}
  return {enter,change,summary};
}
