// v343 E-mail confirmation gate: a NEW account (e-mail/password or Google) opens only after the 6-digit code sent to its e-mail.
// The server decides who must confirm (old accounts, owners, or a server without an e-mail service are never asked).
// v381: the card is the shared code step (six glowing boxes); the sign-up page shows the same step in place.
import { getLang } from '../i18n/index.js';
import { auth } from '../services/auth/index.js';
import { accountCodeStep } from './codeStep.js';

let shown = false;
export async function maybeVerifyGate() {
  if (shown || auth.mode === 'local' || !auth.current()?.uid || document.querySelector('.cs')) return;
  shown = true;
  const el = document.createElement('div');
  el.className = 'vg-back'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.dir = getLang() === 'ar' ? 'rtl' : 'ltr';
  el.innerHTML = '<div class="vg-card"></div>';
  const done = await accountCodeStep(el.firstChild, {
    email: auth.current()?.email || '', onDone: () => { el.remove(); location.reload(); },
    onOut: async () => { el.remove(); shown = false; await auth.signOut(); location.hash = '#/login'; },
  });
  if (done) document.body.append(el); else shown = false;
}
