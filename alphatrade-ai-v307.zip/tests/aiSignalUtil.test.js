import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fmtTz, signalStatus, trackPos, hubItems, tzLabel, tzOffset, userTz } from '../src/services/aiSignalUtil.js';

test('user time zone clock (v234: the device zone, no fixed UTC+03:00)', () => {
  assert.equal(typeof userTz(), 'string');
  assert.match(tzLabel('Europe/Istanbul'), /^UTC\+03:00 \(Europe\/Istanbul\)$/);
  // daylight saving is followed: Jerusalem is +03:00 in July and +02:00 in November
  assert.equal(tzOffset('Asia/Jerusalem', Date.UTC(2026, 6, 1)), 'UTC+03:00');
  assert.equal(tzOffset('Asia/Jerusalem', Date.UTC(2026, 10, 4)), 'UTC+02:00');
  assert.equal(tzOffset('UTC'), 'UTC+00:00');
  // 2026-10-31 06:00 UTC → 09:00 in Istanbul, 06:00 in UTC
  assert.match(fmtTz(Date.UTC(2026, 9, 31, 6, 0) / 1000, 'en', 'Europe/Istanbul'), /09:00/);
  assert.match(fmtTz(Date.UTC(2026, 9, 31, 6, 0) / 1000, 'en', 'UTC'), /06:00/);
  assert.match(fmtTz(Date.UTC(2026, 6, 1, 21, 30) / 1000, 'en', 'Europe/Istanbul'), /00:30/);
  assert.equal(fmtTz(NaN), '');
});

test('status pills', () => {
  assert.equal(signalStatus({ status: 'pending' }).en, 'PENDING');
  assert.equal(signalStatus({ status: 'active', hits: 1 }).en, 'TP1 HIT');
  assert.equal(signalStatus({ status: 'active', hits: 0 }).en, 'ACTIVE');
  assert.equal(signalStatus({ status: 'stopped' }).cls, 'is-sl');
  assert.equal(signalStatus({ status: 'done' }).en, 'TARGET HIT');
});

test('price track from stop to last target, buy and sell', () => {
  const buy = trackPos({ direction: 'long', entry: 100, stop: 90, targets: [110, 120, 130] }, 110);
  assert.equal(buy.entry, 0.25); assert.equal(buy.price, 0.5);
  const sell = trackPos({ direction: 'short', entry: 100, stop: 110, targets: [90, 80] }, 95);
  assert.equal(sell.entry, 1 / 3); assert.equal(sell.price, 0.5);
  assert.equal(trackPos({ direction: 'long', entry: 100, stop: 90, targets: [110] }, 200).price, 1);
  assert.equal(trackPos({ direction: 'long', entry: 100, stop: 90, targets: [110] }).price, null);
  assert.equal(trackPos({ stop: 1, targets: [] }), null);
});

test('hub lists open signals first, live only', () => {
  const items = [
    { id: 'a', mode: 'live', status: 'done', savedAt: 5 }, { id: 'b', mode: 'live', status: 'active', savedAt: 1 },
    { id: 'c', mode: 'demo', status: 'active', savedAt: 9 }, { id: 'd', mode: 'live', status: 'pending', savedAt: 3 },
  ];
  const h = hubItems(items);
  assert.deepEqual(h.list.map((x) => x.id), ['d', 'b', 'a']); assert.equal(h.open, 2);
});

import { anchorMarket, MARKET_TOL_PTS } from '../src/services/aiSignalUtil.js';
test('market order fills at the live price, R:R recomputed', () => {
  const plan = { direction: 'long', entry: 100, stop: 90, targets: [120, 130, 150], sources: ['BSL', 'PDH', '5R'] };
  const a = anchorMarket(plan, 102, { pointSize: 1, minRR: 2 });
  assert.equal(a.ok, true); assert.equal(a.plan.entry, 102); assert.equal(a.plan.risk, 12); assert.equal(a.movedPts, 2);
  assert.deepEqual(a.plan.rr, [1.5, 2.33, 4]); assert.equal(a.plan.rrMain, 2.33); assert.equal(a.plan.marketFill.tolPts, MARKET_TOL_PTS);
  assert.equal(anchorMarket(plan, 89, { minRR: 0 }).reason, 'past_stop');
  assert.equal(anchorMarket(plan, 121, { minRR: 0 }).reason, 'past_tp1');
  assert.equal(anchorMarket(plan, 112, { minRR: 2 }).reason, 'rr_low');
  assert.equal(anchorMarket(plan, NaN).reason, 'no_price');
  const s = anchorMarket({ direction: 'short', entry: 100, stop: 110, targets: [90, 80], sources: ['SSL', '3R'] }, 99, { minRR: 0.5 });
  assert.equal(s.ok, true); assert.equal(s.plan.entry, 99); assert.deepEqual(s.plan.rr, [0.82, 1.73]);
});

test('v302: chartBrief gives the AI the last candles and three indicators', async () => {
  const { chartBrief } = await import('../src/services/aiSignalUtil.js');
  const cs = Array.from({ length: 80 }, (_, i) => ({ open: 100 + i, high: 102 + i, low: 99 + i, close: 101 + i }));
  const b = chartBrief(cs); assert.equal(b.bars, 40); assert.equal(b.candlesOHLC.length, 40); assert.equal(b.rsi14, 100); assert.ok(b.ema20 < b.lastClose && b.ema50 < b.ema20);
  assert.equal(chartBrief(cs.slice(0, 10)), null);
});

test('chart symbol: a stored/unknown symbol never reaches Binance raw (falls back to a real instrument)', async () => {
  const { getInstrument, findInstrument } = await import('../src/config/instruments.js');
  assert.equal(findInstrument('btcusdt'), null);
  assert.equal(findInstrument(''), null);
  assert.match(getInstrument('btc usdt ع').symbol, /^[A-Z0-9._-]{1,50}$/);
});
