import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { createDurable } from '../server/durable.js';

function fakeFirestore() {
  const docs = new Map(); let tokens = 0;
  const fetchImpl = async (url, opt = {}) => {
    const res = (status, body) => ({ ok: status < 300, status, json: async () => body });
    if (url.startsWith('https://oauth2.googleapis.com/token')) { tokens++; return res(200, { access_token: 't', expires_in: 3600 }); }
    assert.equal(opt.headers.authorization, 'Bearer t');
    const key = url.split('/documents/')[1];
    if (opt.method === 'PATCH') { docs.set(key, JSON.parse(opt.body)); return res(200, {}); }
    if (opt.method === 'GET') return docs.has(key) ? res(200, docs.get(key)) : res(404, {});
    if (opt.method === 'DELETE') { docs.delete(key); return res(200, {}); }
    return res(400, {});
  };
  return { docs, fetchImpl, tokens: () => tokens };
}
const { privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const SA = JSON.stringify({ client_email: 'svc@p.iam.gserviceaccount.com', private_key: privateKey.export({ type: 'pkcs8', format: 'pem' }), project_id: 'p' });

test('durable mirror: save → wiped disk → restore brings every file and the bank db back', async () => {
  const fake = fakeFirestore();
  const a = fs.mkdtempSync(path.join(os.tmpdir(), 'dur-a-'));
  fs.writeFileSync(path.join(a, 'members.json'), '{"x":1}'); fs.mkdirSync(path.join(a, 'trades')); fs.writeFileSync(path.join(a, 'trades', 'u1.json'), 'enc');
  fs.mkdirSync(path.join(a, 'backups')); fs.writeFileSync(path.join(a, 'backups', 'old.json'), 'skip');
  const d1 = createDurable({ dataDir: a, env: { FIREBASE_SERVICE_ACCOUNT: SA }, fetchImpl: fake.fetchImpl, log: {} });
  d1.setBankSnapshot((to) => fs.writeFileSync(to, 'BANKDB'));
  const s1 = await d1.save(); assert.equal(s1.ok, true, JSON.stringify(s1)); assert.equal(s1.files, 3);
  assert.deepEqual(await d1.save(), { skipped: 'unchanged' });
  fs.writeFileSync(path.join(a, 'members.json'), '{"x":2}');
  const s2 = await d1.save(); assert.equal(s2.ok, true);
  assert.equal([...fake.docs.keys()].filter((k) => k.includes('/c_')).length, s2.chunks, 'the previous copy was cleaned up');
  const b = fs.mkdtempSync(path.join(os.tmpdir(), 'dur-b-'));
  const d2 = createDurable({ dataDir: b, env: { FIREBASE_SERVICE_ACCOUNT: SA }, fetchImpl: fake.fetchImpl, log: {} });
  const r = await d2.restoreIfEmpty(); assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.files, 3);
  assert.equal(fs.readFileSync(path.join(b, 'members.json'), 'utf8'), '{"x":2}');
  assert.equal(fs.readFileSync(path.join(b, 'trades', 'u1.json'), 'utf8'), 'enc');
  assert.equal(fs.readFileSync(path.join(b, 'bank', 'bank.db'), 'utf8'), 'BANKDB');
  assert.equal(fs.existsSync(path.join(b, 'backups')), false);
  assert.deepEqual(await d2.restoreIfEmpty(), { skipped: 'has_data' }, 'a folder with data is never overwritten');
  assert.equal(fake.tokens(), 2, 'one access token per server, reused');
});

test('durable mirror stays off without a service account and never touches the network', async () => {
  let called = false; const d = createDurable({ dataDir: os.tmpdir(), env: {}, fetchImpl: async () => { called = true; }, log: {} });
  assert.deepEqual(await d.save(), { skipped: 'no_service_account' }); assert.deepEqual(await d.restoreIfEmpty(), { skipped: 'no_service_account' });
  assert.equal(called, false); assert.equal(d.status().enabled, false);
});

test('a corrupted copy is refused (checksum) and nothing is written', async () => {
  const fake = fakeFirestore(); const a = fs.mkdtempSync(path.join(os.tmpdir(), 'dur-c-')); fs.writeFileSync(path.join(a, 'm.json'), '1');
  const d1 = createDurable({ dataDir: a, env: { FIREBASE_SERVICE_ACCOUNT: SA }, fetchImpl: fake.fetchImpl, log: {} }); await d1.save();
  const meta = fake.docs.get('gotriva_mirror/meta'); meta.fields.sha.stringValue = '0'.repeat(64);
  const b = fs.mkdtempSync(path.join(os.tmpdir(), 'dur-d-'));
  const r = await createDurable({ dataDir: b, env: { FIREBASE_SERVICE_ACCOUNT: SA }, fetchImpl: fake.fetchImpl, log: {} }).restoreIfEmpty();
  assert.equal(r.ok, false); assert.match(r.error, /checksum/); assert.equal(fs.readdirSync(b).length, 0);
});
