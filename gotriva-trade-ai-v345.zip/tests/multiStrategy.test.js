// Multi-strategy engine for the AI signal page: every module runs on each request; a strategy qualifies only when every
// mandatory condition passes; global filters, news and conflicts turn the result into NO TRADE.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runAllStrategies, decide, smcStrategy, lstmStrategy, newsStrategy, relationStrategy, trendStrategy, meanReversionStrategy, snapshot, sessionState, adx, macd, swings, aggregate, PROFILES } from '../src/services/multiStrategy.js';

const NOW = Date.UTC(2026, 9, 28, 12, 0, 0);   // a Wednesday, 12:00 UTC
const HOUR = 3600;
function candles(n = 300, { start = 50000, drift = 0.0006, noise = 0.004, endMs = NOW } = {}) {
  const out = []; let p = start; let seed = 7;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647 - 0.5; };
  const last = Math.floor(endMs / 1000 / HOUR) * HOUR - HOUR;   // last CLOSED hour
  for (let i = 0; i < n; i++) {
    const o = p; p = p * (1 + drift + rnd() * noise); const c = p;
    out.push({ time: last - (n - 1 - i) * HOUR, open: o, close: c, high: Math.max(o, c) * 1.002, low: Math.min(o, c) * 0.998, volume: 100 });
  }
  const l = out.at(-1); if (l.close < l.open) { const t = l.open; l.open = l.close; l.close = t; }   // last candle bullish
  return out;
}
const INST = { type: 'crypto', provider: 'binance', precision: 2 };
const calClear = { events: [{ title: 'CPI', country: 'USD', impact: 'High', time: NOW + 10 * 3600_000 }], at: NOW - 60_000, stale: false };
function smcReading(cs, over = {}) {
  const px = cs.at(-1).close;
  return {
    verdict: 'trade', waiting: false, reasons: [], price: px, direction: 'long',
    sweep: { extreme: px * 0.98 }, zones: { liquidity: [{ price: px * 0.97 }], mss: { kind: 'BOS', level: px * 0.995 } },
    checks: [{ id: 'sweep', ok: true }, { id: 'mss', ok: true }, { id: 'poi', ok: true }, { id: 'risk', ok: true }],
    plan: { direction: 'long', execution: 'market', entry: px, stop: px * 0.99, targets: [px * 1.015, px * 1.02, px * 1.03], rr: [1.5, 2, 3], rrMain: 2, risk: px * 0.01, poi: { kind: 'OB', top: px, bottom: px * 0.995 }, confirm: null },
    ...over,
  };
}
const base = (cs, over = {}) => ({ symbol: 'BTCUSDT', inst: INST, tf: '1h', tfSec: HOUR, candles: cs, mode: 'live', htf: null, calendar: calClear, nowMs: NOW, account: { todayLossPct: 0, recentResults: [], openSameSymbol: 0, riskPct: 0.5 }, sizeFor: () => ({ units: 1 }), ...over });

test('every request runs all six modules, each independently', () => {
  const cs = candles();
  const r = runAllStrategies(base(cs, { reading: smcReading(cs) }));
  assert.deepEqual(r.strategies.map((s) => s.id), ['trend', 'mean_reversion', 'smc', 'lstm', 'news', 'relations']);
  for (const s of r.strategies) for (const c of s.checks) assert.ok(['pass', 'fail', 'unavailable'].includes(c.status), `${s.id}.${c.id}`);
  assert.equal(r.confidence, 'NOT CALIBRATED');
});

test('a fully passing strategy with all global filters passing gives BUY with evidence-based levels', () => {
  const cs = candles();
  const r = runAllStrategies(base(cs, { reading: smcReading(cs) }));
  assert.ok(r.qualified.includes('smc'), JSON.stringify(r.strategies.find((s) => s.id === 'smc').checks.filter((c) => c.status !== 'pass')));
  assert.deepEqual(r.globals.filter((g) => g.status !== 'pass').map((g) => g.id), []);
  assert.equal(r.final, 'buy');
  assert.equal(r.pick.id, 'smc');
  assert.ok(r.pick.plan.stop < r.pick.plan.entry && r.pick.plan.targets[0] > r.pick.plan.entry);
  assert.equal(r.dataQuality, 'good');
});

test('one failed mandatory condition stops the strategy from qualifying', () => {
  const cs = candles();
  const reading = smcReading(cs, { checks: [{ id: 'sweep', ok: false }, { id: 'mss', ok: true }, { id: 'poi', ok: true }, { id: 'risk', ok: true }] });
  const s = smcStrategy(reading, snapshot(cs, { tfSec: HOUR }));
  assert.equal(s.status, 'not_qualified');
  assert.equal(s.checks.find((c) => c.id === 'sweep').status, 'fail');
  assert.equal(s.plan, null);
  // the site engine's own failed check is also enough
  const s2 = smcStrategy(smcReading(cs, { reasons: ['rr'] }), snapshot(cs, { tfSec: HOUR }));
  assert.equal(s2.status, 'not_qualified');
  // waiting for the zone = no retest yet
  assert.equal(smcStrategy(smcReading(cs, { waiting: true }), snapshot(cs, { tfSec: HOUR })).status, 'not_qualified');
});

test('an UNAVAILABLE condition never counts as a pass', () => {
  const q = { id: 'x', status: 'qualified', direction: 'long', plan: { rrMain: 2 }, checks: [{ id: 'a', status: 'pass' }, { id: 'b', status: 'unavailable' }] };
  const r = decide([q], []);
  assert.equal(r.final, 'no_trade'); assert.equal(r.reason, 'no_strategy');
});

test('no qualified strategy → NO TRADE with the reason', () => {
  const cs = candles();
  const r = runAllStrategies(base(cs, { reading: smcReading(cs, { verdict: 'no_trade', reasons: ['bias'] }) }));
  if (!r.qualified.length) { assert.equal(r.final, 'no_trade'); assert.equal(r.reason, 'no_strategy'); assert.equal(r.pick, null); }
});

test('qualified strategies in opposite directions: each gets its own trade, flagged as a conflict', () => {
  const mk = (id, dir) => ({ id, status: 'qualified', direction: dir, plan: { rrMain: 2 }, checks: [{ id: 'a', status: 'pass' }] });
  const r = decide([mk('trend', 'long'), mk('mean_reversion', 'short')], [{ id: 'live', status: 'pass' }]);
  assert.equal(r.conflict, true); assert.equal(r.trades.length, 2);
  assert.deepEqual(r.trades.map((x) => x.direction).sort(), ['long', 'short']);
  const same = decide([mk('trend', 'long'), mk('smc', 'long')], [{ id: 'live', status: 'pass' }]);
  assert.equal(same.final, 'buy'); assert.equal(same.pick.id, 'smc'); assert.deepEqual(same.qualified, ['trend', 'smc']);
});

test('a qualified strategy still gives NO TRADE when any global filter fails', () => {
  const mk = { id: 'trend', status: 'qualified', direction: 'short', plan: { rrMain: 2 }, checks: [{ id: 'a', status: 'pass' }] };
  assert.equal(decide([mk], [{ id: 'spread', status: 'fail' }]).reason, 'global');
  assert.equal(decide([mk], [{ id: 'news', status: 'unavailable' }]).reason, 'news');
  assert.equal(decide([mk], [{ id: 'live', status: 'pass' }]).final, 'sell');
  assert.equal(decide([mk], [], () => null).reason, 'sizing');
});

test('global filters: demo prices, stale data, missing calendar, high-impact news, wide spread, closed market, loss limits', () => {
  const cs = candles();
  const reading = smcReading(cs);
  const fail = (over, id) => {
    const r = runAllStrategies(base(cs, { reading, ...over }));
    assert.equal(r.final, 'no_trade', id);
    assert.notEqual(r.globals.find((g) => g.id === id).status, 'pass', id);
  };
  fail({ mode: 'demo' }, 'live');
  fail({ nowMs: NOW + 10 * 3600_000 }, 'fresh');
  fail({ calendar: null }, 'news');
  fail({ calendar: { events: [{ title: 'FOMC', country: 'USD', impact: 'High', time: NOW + 10 * 60_000 }], at: NOW, stale: false } }, 'news');
  fail({ calendar: { events: [], at: NOW - 3 * 86400_000, stale: true } }, 'news');
  fail({ spread: { bidAskPct: 0.5 } }, 'spread');
  fail({ account: { todayLossPct: 1.6, recentResults: [] } }, 'daily');
  fail({ account: { todayLossPct: 0, recentResults: ['win', 'loss', 'loss'] } }, 'streak');
  fail({ account: { todayLossPct: 0, recentResults: [], openSameSymbol: 1 } }, 'exposure');
  fail({ inst: { type: 'gadget', provider: null } }, 'supported');
  // gold on a Saturday: market closed
  const sat = Date.UTC(2026, 9, 31, 12, 0, 0);
  const r = runAllStrategies(base(candles(300, { endMs: sat }), { inst: { type: 'metal', provider: 'twelvedata', precision: 2 }, symbol: 'XAUUSD', nowMs: sat, reading }));
  assert.equal(r.globals.find((g) => g.id === 'session').status, 'fail');
  assert.equal(r.final, 'no_trade');
});

test('not enough candles → NO TRADE (insufficient data), nothing invented', () => {
  const r = runAllStrategies(base(candles(40), { reading: null }));
  assert.equal(r.final, 'no_trade'); assert.equal(r.reason, 'insufficient_data'); assert.equal(r.dataQuality, 'insufficient');
});

test('LSTM is UNVALIDATED and the relations module is context only — neither can produce a signal', () => {
  const l = lstmStrategy();
  assert.equal(l.status, 'unvalidated'); assert.equal(l.plan, null);
  const S = snapshot(candles(), { tfSec: HOUR });
  const rel = relationStrategy(S, null);
  assert.equal(rel.status, 'context'); assert.equal(rel.plan, null);
  const rel2 = relationStrategy(S, { symbol: 'ETHUSDT', candles: candles(300, { start: 2500 }) });
  assert.equal(rel2.checks[0].status, 'pass');
  assert.equal(decide([l, rel2], []).final, 'no_trade');
});

test('news module: source, freshness and the ±30 min blackout', () => {
  const s = newsStrategy('XAUUSD', { events: [{ title: 'NFP', country: 'USD', impact: 'High', time: NOW + 20 * 60_000 }], at: NOW, stale: false }, NOW);
  assert.equal(s.newsStatus, 'blackout'); assert.equal(s.blackout.title, 'NFP');
  assert.equal(newsStrategy('XAUUSD', { events: [{ title: 'NFP', country: 'USD', impact: 'High', time: NOW + 2 * 3600_000 }], at: NOW, stale: false }, NOW).newsStatus, 'soon');
  assert.equal(newsStrategy('XAUUSD', null, NOW).newsStatus, 'unavailable');
});

test('instrument-specific settings: every asset class has its own profile and session rules', () => {
  for (const k of ['crypto', 'metal', 'energy', 'index', 'forex', 'stock']) assert.ok(PROFILES[k].atrPct[0] < PROFILES[k].atrPct[1], k);
  assert.notDeepEqual(PROFILES.crypto, PROFILES.metal);
  assert.equal(sessionState('crypto', Date.UTC(2026, 9, 31, 12)).open, true);
  assert.equal(sessionState('metal', Date.UTC(2026, 9, 31, 12)).open, false);   // Saturday
  assert.equal(sessionState('index', Date.UTC(2026, 9, 28, 21, 30)).open, false); // daily pause
  assert.equal(sessionState('stock', Date.UTC(2026, 9, 28, 15)).open, true);
});

test('trend and mean-reversion modules always return a full checklist for one direction', () => {
  const S = snapshot(candles(), { tfSec: HOUR });
  for (const s of [trendStrategy(S), meanReversionStrategy(S)]) {
    assert.ok(['qualified', 'not_qualified', 'unavailable', 'conflict'].includes(s.status));
    assert.ok(s.checks.length >= 7);
    if (s.status !== 'qualified') assert.equal(s.plan, null);
    else assert.ok(s.checks.every((c) => c.status === 'pass'));
  }
});

test('indicator helpers', () => {
  const cs = candles(200);
  const a = adx(cs, 14).filter((v) => v != null);
  assert.ok(a.length > 100 && a.every((v) => v >= 0 && v <= 100));
  const m = macd(cs.map((c) => c.close));
  assert.equal(m.hist.length, cs.length); assert.ok(m.hist.at(-1) != null);
  const sw = swings(candles(200, { drift: 0, noise: 0.03 }), 3); assert.ok(sw.hi.length > 0 && sw.lo.length > 0);
  assert.equal(aggregate(cs, 4).length, 50);
});

test('each strategy is independent: a qualified one is traded immediately, before the next module even runs', () => {
  const cs = candles();
  const order = [];
  // the SMC reading is lazy; when it is asked for, record whether onTrade already fired for the SMC module
  const r = runAllStrategies(base(cs, {
    reading: () => { order.push('smc-evaluated'); return smcReading(cs); },
    onTrade: (t) => order.push(`trade:${t.id}`),
  }));
  const smcTrade = order.indexOf('trade:smc');
  assert.ok(smcTrade >= 0 && smcTrade === order.indexOf('smc-evaluated') + 1);
  assert.ok(r.emitted.some((t) => t.id === 'smc'));
  assert.equal(r.emitted.length, r.trades.length);
});

test('an open trade from one strategy never blocks another strategy on the same market', () => {
  const cs = candles();
  const free = runAllStrategies(base(cs, { reading: smcReading(cs), account: { todayLossPct: 0, recentResults: [], openByStrategy: {} } }));
  const busyTrend = runAllStrategies(base(cs, { reading: smcReading(cs), account: { todayLossPct: 0, recentResults: [], openByStrategy: { trend: 1 } } }));
  assert.equal(busyTrend.globals.find((g) => g.id === 'exposure').status, 'pass');
  assert.ok(!busyTrend.emitted.some((t) => t.id === 'trend'));
  // whatever else qualified when nothing was open still qualifies with trend busy
  assert.deepEqual(busyTrend.emitted.map((t) => t.id), free.emitted.map((t) => t.id).filter((id) => id !== 'trend'));
  assert.ok(busyTrend.emitted.some((t) => t.id === 'smc'));
  const busySmc = runAllStrategies(base(cs, { reading: smcReading(cs), account: { todayLossPct: 0, recentResults: [], openByStrategy: { smc: 1 } } }));
  assert.ok(!busySmc.emitted.some((t) => t.id === 'smc'));
});

test('"more trades" preset loosens only the documented thresholds; normal is unchanged', async () => {
  const { presetCfg, DEFAULTS } = await import('../src/services/multiStrategy.js');
  assert.deepEqual(presetCfg('normal'), {});
  assert.deepEqual(presetCfg('anything'), {});
  const m = presetCfg('more');
  assert.ok(m.minRR < DEFAULTS.minRR && m.adxTrend < DEFAULTS.adxTrend && m.rsiLo > DEFAULTS.rsiLo && m.rsiHi < DEFAULTS.rsiHi);
  const cs = candles();
  const a = runAllStrategies(base(cs, { reading: smcReading(cs) }));
  const b = runAllStrategies(base(cs, { reading: smcReading(cs) }), m);
  // looser settings can only add qualified strategies, never remove one
  for (const id of a.qualified) assert.ok(b.qualified.includes(id), id);
  assert.match(b.strategies.find((s) => s.id === 'trend').checks.find((c) => c.id === 'momentum').label.en, /ADX ≥ 18/);
});

test('the engine runs the balanced preset: half-way between normal and "more"', async () => {
  const { presetCfg, DEFAULTS } = await import('../src/services/multiStrategy.js');
  const { engineMode } = await import('../src/services/engineMode.js');
  assert.equal(engineMode(), 'balanced');
  const b = presetCfg('balanced'), m = presetCfg('more');
  for (const k of ['minRR', 'adxTrend', 'rsiLo', 'rsiHi', 'adxRange']) assert.ok(Math.abs(b[k] - (DEFAULTS[k] + m[k]) / 2) < 1e-9, k);
});

test('every trade carries its market context for the learning engine', () => {
  const cs = candles();
  const r = runAllStrategies(base(cs, { reading: smcReading(cs) }));
  assert.ok(r.features && typeof r.features.session === 'string' && Number.isFinite(r.features.adx));
  for (const t of r.trades) assert.deepEqual(t.ctx, r.features);
  assert.equal(r.minRR, 1.5);
});

test('v344: an SMC limit at the zone stays a LIMIT order in the emitted trade (never relabelled market)', () => {
  const cs = candles(); const px = cs.at(-1).close;
  const rd = smcReading(cs); rd.plan = { ...rd.plan, execution: 'limit', entry: px * 0.996, validUntil: cs.at(-1).time + 12 * HOUR };
  const r = runAllStrategies(base(cs, { reading: rd }));
  const smc = r.emitted.find((x) => x.id === 'smc');
  assert.ok(smc, 'smc emitted');
  assert.equal(smc.plan.execution, 'limit'); assert.equal(smc.plan.validUntil, cs.at(-1).time + 12 * HOUR);
  const m = runAllStrategies(base(cs, { reading: smcReading(cs) })).emitted.find((x) => x.id === 'smc');
  assert.equal(m.plan.execution, 'market');
});
