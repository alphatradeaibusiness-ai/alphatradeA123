import test from 'node:test';
import assert from 'node:assert/strict';
import { createVoice, MENTOR_VOICES } from '../server/voice.js';

test('voice: off without a key, never calls out', async () => {
  let called = false; const v = createVoice({ env: {}, fetchImpl: async () => { called = true; } });
  assert.equal(v.enabled(), false);
  assert.equal((await v.tts('hi', {})).error, 'voice_not_configured');
  assert.equal((await v.stt(Buffer.alloc(5000), {})).error, 'voice_not_configured');
  assert.equal(called, false);
});

test('voice: each mentor speaks with its own voice + Levantine style for Arabic; speech-to-text sends the audio file', async () => {
  const calls = [];
  const fetchImpl = async (url, o) => {
    calls.push({ url, o });
    if (url.endsWith('/audio/speech')) return { ok: true, status: 200, arrayBuffer: async () => new Uint8Array([1, 2, 3]).buffer };
    return { ok: true, status: 200, json: async () => ({ text: '  شو الفرق بين BOS و CHoCH؟ ' }) };
  };
  const v = createVoice({ env: { OPENAI_API_KEY: 'sk-test' }, fetchImpl });
  const a = await v.tts('أهلا', { mentor: 'khaled-gold', lang: 'ar' });
  assert.deepEqual([...a.audio], [1, 2, 3]);
  const body = JSON.parse(calls[0].o.body);
  assert.equal(body.voice, MENTOR_VOICES['khaled-gold'].voice); assert.match(body.instructions, /Levantine/);
  assert.equal(calls[0].o.headers.authorization, 'Bearer sk-test');
  const s = await v.stt(Buffer.alloc(4000, 1), { mime: 'audio/mp4', lang: 'ar' });
  assert.equal(s.text, 'شو الفرق بين BOS و CHoCH؟');
  const fd = calls[1].o.body; assert.equal(fd.get('language'), 'ar'); assert.equal(fd.get('file').name, 'speech.m4a');
  assert.deepEqual(await v.stt(Buffer.alloc(100), {}), { text: '' }, 'a tap with no speech is not sent');
  assert.equal(new Set(Object.values(MENTOR_VOICES).map((x) => x.voice)).size, 6, 'six different voices');
});

test('voice: daily allowance per member, owners unlimited; provider errors are mapped', async () => {
  const v = createVoice({ env: { OPENAI_API_KEY: 'k', VOICE_TURNS_PER_DAY: '2' }, fetchImpl: async () => ({ ok: false, status: 401, json: async () => ({}) }) });
  assert.equal(v.allow('u', false), true); assert.equal(v.allow('u', false), true); assert.equal(v.allow('u', false), false);
  assert.equal(v.allow('o', true), true);
  assert.equal((await v.tts('x', {})).error, 'voice_bad_key');
});
