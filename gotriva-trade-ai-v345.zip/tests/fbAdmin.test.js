import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createFbAdmin } from '../server/fbAdmin.js';

const { privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const SA = JSON.stringify({ client_email: 's@p.iam.gserviceaccount.com', private_key: privateKey.export({ type: 'pkcs8', format: 'pem' }), project_id: 'p' });

test('fbAdmin: creation time + a confirmed mark that keeps other claims', async () => {
  const users = { u1: { localId: 'u1', createdAt: '1700000000000', customAttributes: '{"role":"x"}' } };
  const fetchImpl = async (url, o) => {
    const ok = (b) => ({ ok: true, status: 200, json: async () => b });
    if (url.includes('oauth2')) return ok({ access_token: 't', expires_in: 3600 });
    const b = JSON.parse(o.body);
    if (url.endsWith(':lookup')) return ok({ users: b.localId.map((id) => users[id]).filter(Boolean) });
    if (url.endsWith(':update')) { users[b.localId].customAttributes = b.customAttributes; return ok({}); }
    return { ok: false, status: 400, json: async () => ({}) };
  };
  const fa = createFbAdmin({ env: { FIREBASE_SERVICE_ACCOUNT: SA }, fetchImpl });
  assert.deepEqual(await fa.account('u1'), { createdAt: 1700000000000, confirmed: false });
  assert.equal(await fa.markConfirmed('u1'), true);
  assert.deepEqual(JSON.parse(users.u1.customAttributes), { role: 'x', gvMail: 1 });
  assert.equal((await fa.account('u1')).confirmed, true);
  assert.equal(await fa.account('nobody'), null);
  assert.equal(await createFbAdmin({ env: {} }).account('u1'), null);
});
