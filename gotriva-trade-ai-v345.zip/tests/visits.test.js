import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createVisits } from '../server/visits.js';

test('visits: sources grouped, unique counted once, own site is not a source, nothing personal kept', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vis-'));
  const v = createVisits({ dir, log: {} });
  v.record({ vid: 'a1', ref: 'https://www.google.com/search?q=x', dev: 'phone', tz: 'Asia/Amman', land: '#/signup?ref=AB' });
  v.record({ vid: 'a1', ref: 'https://l.instagram.com/', dev: 'phone', tz: 'Asia/Amman', utm_campaign: 'Launch' });
  v.record({ vid: 'b2', ref: 'https://gotriva.example/#/x', dev: 'desktop', tz: 'Mars/Base' }, { selfHost: 'gotriva.example' });
  v.signup();
  const s = v.summary();
  assert.equal(s.today.visits, 3); assert.equal(s.today.unique, 2); assert.equal(s.today.signups, 1);
  assert.deepEqual(Object.fromEntries(s.sources), { google: 1, instagram: 1, direct: 1 });
  assert.equal(s.places[0][2][1], 'Jordan'); assert.deepEqual(s.landing.find((r) => r[0] === 'signup'), ['signup', 1]);
  v.stop(); const raw = fs.readFileSync(path.join(dir, 'visits.json'), 'utf8');
  assert.equal(raw.includes('a1'), false, 'browser ids are hashed');
});
