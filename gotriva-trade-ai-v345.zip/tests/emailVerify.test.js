import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createEmailVerify, renderCodeMail } from '../server/emailVerify.js';

function setup(env = { RESEND_API_KEY: 're_x' }) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ev-'));
  let t = 1_000_000; const sent = [];
  const fetchImpl = async (url, o) => { sent.push(JSON.parse(o.body)); return { ok: true, status: 200 }; };
  const ev = createEmailVerify({ dir, secret: 's', env, fetchImpl, now: () => t, log: {} });
  return { ev, sent, dir, adv: (ms) => { t += ms; }, now: () => t };
}
const codeOf = (m) => /(\d{6})/.exec(m.subject)[1];

test('new account must confirm; correct code opens it; the code is never stored in clear', async () => {
  const { ev, sent, dir, adv, now } = setup();
  ev.status('x'); adv(1000);
  const ctx = { createdAt: now() };
  assert.equal(ev.required('u1', ctx), true);
  const r = await ev.send('u1', { email: 'person@example.com', lang: 'ar' });
  assert.equal(r.sent, true); assert.match(r.to, /^pe•+@example\.com$/);
  const code = codeOf(sent[0]);
  assert.equal(fs.readFileSync(path.join(dir, 'email-verify.json'), 'utf8').includes(code), false);
  assert.equal(ev.check('u1', '000000' === code ? '111111' : '000000').error, 'wrong_code');
  assert.deepEqual(ev.check('u1', code), { ok: true });
  assert.equal(ev.required('u1', ctx), false);
});

test('old accounts, owners and servers without mail are never blocked', () => {
  const { ev, adv } = setup(); ev.status('x'); adv(5000);
  assert.equal(ev.required('old', { createdAt: 1 }), false);
  assert.equal(ev.required('own', { owner: true, createdAt: Date.now() * 2 }), false);
  const { ev: off } = setup({});
  assert.equal(off.required('u', { createdAt: Date.now() * 2 }), false);
});

test('limits: 60 s between codes, 5 tries, 15 min expiry', async () => {
  const { ev, sent, adv } = setup();
  await ev.send('u', { email: 'a@b.co' });
  assert.equal((await ev.send('u', { email: 'a@b.co' })).error, 'too_soon');
  for (let i = 0; i < 5; i++) ev.check('u', '99999' + i === codeOf(sent[0]) ? '888888' : '99999' + i);
  assert.equal(ev.check('u', codeOf(sent[0])).error, 'too_many_tries');
  adv(61_000); await ev.send('u', { email: 'a@b.co' }); adv(16 * 60_000);
  assert.equal(ev.check('u', codeOf(sent[1])).error, 'expired');
});

test('mail escapes the name', () => { assert.equal(renderCodeMail('123456', { name: '<b>x' }).html.includes('<b>x'), false); });

test('the new key name GOTRIVA_MAIL_KEY turns the code on', () => {
  const { ev } = setup({ GOTRIVA_MAIL_KEY: 're_new' });
  assert.equal(ev.required('n', { createdAt: Date.now() * 2 }), true);
});
