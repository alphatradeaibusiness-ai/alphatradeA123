// v343 Small Firebase Auth admin client (service account): when an account was really created, and a durable
// "e-mail confirmed by code" mark kept on the Firebase account itself — so a wiped server disk never asks old or
// already-confirmed members for a code again. Without FIREBASE_SERVICE_ACCOUNT it is simply off (callers fall back).
import crypto from 'node:crypto';
import { parseServiceAccount } from './faceLogin.js';

export function createFbAdmin({ env = process.env, fetchImpl = globalThis.fetch, now = Date.now } = {}) {
  const sa = parseServiceAccount(env.FIREBASE_SERVICE_ACCOUNT);
  const project = sa?.projectId || env.FIREBASE_PROJECT_ID || null;
  const enabled = Boolean(sa && project && fetchImpl);
  const base = `https://identitytoolkit.googleapis.com/v1/projects/${project}`;
  let tok = null; let tokExp = 0; const cache = new Map();
  async function token() {
    if (tok && now() < tokExp - 60_000) return tok;
    const iat = Math.floor(now() / 1000); const b = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
    const unsigned = `${b({ alg: 'RS256', typ: 'JWT' })}.${b({ iss: sa.email, scope: 'https://www.googleapis.com/auth/identitytoolkit https://www.googleapis.com/auth/cloud-platform', aud: 'https://oauth2.googleapis.com/token', iat, exp: iat + 3600 })}`;
    const jwt = `${unsigned}.${crypto.sign('RSA-SHA256', Buffer.from(unsigned), sa.key).toString('base64url')}`;
    const r = await fetchImpl('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}` });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.access_token) throw new Error(`token ${r.status}`);
    tok = j.access_token; tokExp = now() + (Number(j.expires_in) || 3600) * 1000; return tok;
  }
  /** { createdAt, confirmed } for a Firebase account, or null when unknown / off. Cached 10 minutes. */
  async function account(uid) {
    if (!enabled || !uid) return null;
    const c = cache.get(uid); if (c && now() - c.at < 600_000) return c.v;
    try {
      const r = await fetchImpl(`${base}/accounts:lookup`, { method: 'POST', headers: { authorization: `Bearer ${await token()}`, 'content-type': 'application/json' }, body: JSON.stringify({ localId: [uid] }) });
      const j = await r.json().catch(() => ({})); const u = r.ok ? j.users?.[0] : null;
      if (!u) return null;
      let custom = {}; try { custom = JSON.parse(u.customAttributes || '{}'); } catch { /* */ }
      const v = { createdAt: Number(u.createdAt) || 0, confirmed: Boolean(custom.gvMail) };
      cache.set(uid, { at: now(), v }); if (cache.size > 20_000) cache.delete(cache.keys().next().value);
      return v;
    } catch { return null; }
  }
  /** Mark the account as confirmed (kept by Firebase, survives any server wipe). Keeps other custom claims. */
  async function markConfirmed(uid) {
    if (!enabled || !uid) return false;
    try {
      const r0 = await fetchImpl(`${base}/accounts:lookup`, { method: 'POST', headers: { authorization: `Bearer ${await token()}`, 'content-type': 'application/json' }, body: JSON.stringify({ localId: [uid] }) });
      const u = (await r0.json().catch(() => ({}))).users?.[0]; let custom = {}; try { custom = JSON.parse(u?.customAttributes || '{}'); } catch { /* */ }
      custom.gvMail = 1;
      const r = await fetchImpl(`${base}/accounts:update`, { method: 'POST', headers: { authorization: `Bearer ${await token()}`, 'content-type': 'application/json' }, body: JSON.stringify({ localId: uid, customAttributes: JSON.stringify(custom) }) });
      cache.delete(uid); return r.ok;
    } catch { return false; }
  }
  return { enabled, account, markConfirmed };
}
