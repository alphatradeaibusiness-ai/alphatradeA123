// v343 E-mail confirmation code for NEW accounts (e-mail/password and Google alike).
// After sign-up the person gets a 6-digit code by e-mail and the account opens only after entering it.
//   • the code is never stored — only an HMAC of it; valid 15 minutes, 5 tries, then a new code is needed
//   • sending is limited (one code per 60 s, at most 6 per hour per account) so nobody can spam an inbox through us
//   • accounts that existed before this feature, and the owners, are treated as confirmed (nobody gets locked out)
//   • without an e-mail service (RESEND_API_KEY) nothing is required: a code that cannot arrive must never block sign-up
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

// The feature start: accounts created before it are never asked. A wiped disk falls back to this date, not to "now".
const FEATURE_START = Date.parse('2026-11-14T00:00:00Z');
const TTL = 15 * 60_000; const GAP = 60_000; const HOURLY = 6; const TRIES = 5;
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function renderCodeMail(code, { name = '', lang = 'ar' } = {}) {
  const n = esc(String(name).split(' ')[0] || '');
  const subject = lang === 'ar' ? `رمز تأكيد حسابك: ${code} | GOTRIVA TRADE AI` : `Your confirmation code: ${code} | GOTRIVA TRADE AI`;
  const box = `<div style="font:700 34px/1 ui-monospace,Menlo,Consolas,monospace;letter-spacing:10px;background:#141128;color:#fff;border-radius:12px;padding:18px 0;text-align:center;margin:18px 0">${esc(code)}</div>`;
  const ar = `<div dir="rtl" style="text-align:right">أهلاً ${n}،<br/>هذا رمز تأكيد بريدك لإنشاء حسابك في GOTRIVA TRADE AI:${box}الرمز صالح 15 دقيقة. إذا ما طلبته أنت، تجاهل هالرسالة.</div>`;
  const en = `<div dir="ltr" style="text-align:left">Hi ${n},<br/>Here is the code to confirm your e-mail for your GOTRIVA TRADE AI account:${box}It is valid for 15 minutes. If you did not ask for it, ignore this e-mail.</div>`;
  const html = `<div style="background:#05040b;padding:24px;font:15px/1.7 system-ui,Segoe UI,Tahoma,sans-serif;color:#e8e6f5"><div style="max-width:520px;margin:auto;background:#0d0c19;border:1px solid #2a2550;border-radius:16px;padding:24px"><div style="font:800 18px system-ui;color:#fff;margin-bottom:12px">GOTRIVA TRADE AI</div>${lang === 'ar' ? ar + '<hr style="border:0;border-top:1px solid #2a2550;margin:20px 0"/>' + en : en + '<hr style="border:0;border-top:1px solid #2a2550;margin:20px 0"/>' + ar}</div></div>`;
  const text = `${lang === 'ar' ? `رمز التأكيد: ${code} (صالح 15 دقيقة)` : `Confirmation code: ${code} (valid 15 minutes)`}\nGOTRIVA TRADE AI`;
  return { subject, html, text };
}

export function createEmailVerify({ dir, secret = '', env = process.env, fetchImpl = globalThis.fetch, now = Date.now, log = console } = {}) {
  const file = dir ? path.join(dir, 'email-verify.json') : null;
  const hkey = crypto.createHash('sha256').update(`gotriva-email-code:${secret || 'dev'}`).digest();
  let st = null;
  const load = () => {
    if (st) return st;
    st = { since: 0, verified: {}, pending: {} };
    if (file) { try { st = { ...st, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch { /* first start */ } }
    if (!st.since) { st.since = Math.min(now(), Number(env.VERIFY_SINCE) || FEATURE_START); save(); }   // the moment the feature went live: accounts older than this are not asked
    return st;
  };
  function save() { if (!file || !st) return; try { fs.mkdirSync(dir, { recursive: true }); const tmp = `${file}.tmp`; fs.writeFileSync(tmp, JSON.stringify(st), { mode: 0o600 }); fs.renameSync(tmp, file); } catch (e) { log.error?.('[verify] save failed:', e?.message || e); } }
  const key = () => String(env.GOTRIVA_MAIL_KEY || env.RESEND_API_KEY || '').trim();
  const from = () => String(env.MAIL_FROM || 'GOTRIVA TRADE AI <onboarding@resend.dev>');
  const mac = (uid, code) => crypto.createHmac('sha256', hkey).update(`${uid}:${code}`).digest('hex');

  /** Is a confirmation still needed for this signed-in person? */
  function required(uid, { owner = false, createdAt = 0 } = {}) {
    if (!key() || owner || !uid) return false;
    const s = load();
    if (s.verified[uid]) return false;
    if (createdAt && createdAt < s.since) return false;   // existing customers keep working
    return true;
  }
  function status(uid, ctx) {
    const s = load(); const p = s.pending[uid];
    return { required: required(uid, ctx), verified: Boolean(s.verified[uid]), mail: Boolean(key()), pending: Boolean(p && p.exp > now()), retryInS: p ? Math.max(0, Math.ceil((p.last + GAP - now()) / 1000)) : 0 };
  }
  async function send(uid, { email, name = '', lang = 'ar' } = {}) {
    if (!key()) return { error: 'mail_not_configured' };
    if (!email) return { error: 'no_email' };
    const s = load(); const t = now();
    const p = s.pending[uid] || { sent: [] };
    p.sent = (p.sent || []).filter((x) => t - x < 3600_000);
    if (p.last && t - p.last < GAP) return { error: 'too_soon', retryInS: Math.ceil((p.last + GAP - t) / 1000) };
    if (p.sent.length >= HOURLY) return { error: 'too_many', retryInS: Math.ceil((p.sent[0] + 3600_000 - t) / 1000) };
    const code = String(crypto.randomInt(0, 1_000_000)).padStart(6, '0');
    const m = renderCodeMail(code, { name, lang });
    try {
      const r = await fetchImpl('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: `Bearer ${key()}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ from: from(), to: [email], subject: m.subject, html: m.html, text: m.text }) });
      if (!r.ok) return { error: `provider_${r.status}` };
    } catch { return { error: 'network' }; }
    s.pending[uid] = { h: mac(uid, code), exp: t + TTL, tries: 0, last: t, sent: [...p.sent, t] }; save();
    const [u, d] = String(email).split('@'); return { sent: true, to: `${u.slice(0, 2)}${'•'.repeat(Math.max(1, u.length - 2))}@${d}`, retryInS: GAP / 1000 };
  }
  function check(uid, code) {
    const s = load(); const p = s.pending[uid]; const c = String(code || '').replace(/\D/g, '');
    if (s.verified[uid]) return { ok: true };
    if (!p || !p.h || p.exp < now()) return { error: 'expired' };
    if (p.tries >= TRIES) return { error: 'too_many_tries' };
    p.tries++;
    const good = c.length === 6 && crypto.timingSafeEqual(Buffer.from(mac(uid, c)), Buffer.from(p.h));
    if (!good) { save(); return { error: 'wrong_code', left: TRIES - p.tries }; }
    s.verified[uid] = now(); delete s.pending[uid]; save();
    return { ok: true };
  }
  const markVerified = (uid) => { const s = load(); if (!s.verified[uid]) { s.verified[uid] = now(); delete s.pending[uid]; save(); } };
  const forget = (uid) => { const s = load(); delete s.verified[uid]; delete s.pending[uid]; save(); };
  const stats = () => { const s = load(); return { since: s.since, verified: Object.keys(s.verified).length, waiting: Object.values(s.pending).filter((p) => p.exp > now()).length, mail: Boolean(key()) }; };
  load();   // fix the feature start now (accounts created after this moment confirm their e-mail)
  return { required, status, send, check, forget, stats, markVerified };
}
