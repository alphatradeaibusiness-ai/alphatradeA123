// v345 Real voice for the AI mentors' calls (like a voice call in ChatGPT / Gemini): the person's speech is turned into text and
// each mentor answers in its OWN natural voice. Uses OpenAI's speech models with the key the owner puts on Render
// (OPENAI_API_KEY — never in chat, never in the page). Without the key the page falls back to the browser's own voices.
//   • speech → text: gpt-4o-mini-transcribe (VOICE_STT_MODEL), audio up to 3 MB / ~60 s, never stored
//   • text → speech: gpt-4o-mini-tts (VOICE_TTS_MODEL), one voice + speaking style per mentor
//   • a daily allowance per member (owners unlimited) so a call can never run up the bill
const STT_MODEL = () => process.env.VOICE_STT_MODEL || 'gpt-4o-mini-transcribe';
const TTS_MODEL = () => process.env.VOICE_TTS_MODEL || 'gpt-4o-mini-tts';

// Each mentor's voice and the way it speaks (the TTS model follows these instructions).
export const MENTOR_VOICES = {
  'sara-smc': { voice: 'nova', style: 'A calm, precise, warm female trading coach. Speak clearly at a relaxed pace, friendly and confident, with small natural pauses.' },
  'khaled-gold': { voice: 'onyx', style: 'An experienced, practical older male gold trader. Deep, steady, slightly slower voice, blunt but kind, like an uncle giving advice.' },
  'leo-crypto': { voice: 'echo', style: 'An energetic young male crypto trader. Upbeat and lively but disciplined, a bit faster pace, smiling tone.' },
  'nora-macro': { voice: 'coral', style: 'A structured, analytical female forex and macro mentor. Professional, articulate and composed, medium pace.' },
  'omar-risk': { voice: 'ash', style: 'A calm, methodical male risk coach. Reassuring, measured pace, says numbers slowly and clearly.' },
  'zen-mind': { voice: 'sage', style: 'A calm, encouraging mindset coach. Soft, warm and patient voice, slow pace, gentle pauses.' },
};
const ARABIC = 'When the text is Arabic, speak natural Levantine Arabic (Jordanian / Palestinian) pronunciation, not formal news Arabic. Read prices and numbers naturally.';

export function createVoice({ env = process.env, fetchImpl = globalThis.fetch, now = Date.now, perDay = 120 } = {}) {
  const key = () => String(env.OPENAI_API_KEY || '').trim();
  const base = () => String(env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, '');
  const used = new Map();   // uid → { day, turns }
  const day = () => new Date(now()).toISOString().slice(0, 10);

  /** false when the member used today's allowance (owners never limited). */
  function allow(uid, owner) {
    if (owner) return true;
    const d = day(); const u = used.get(uid);
    if (!u || u.day !== d) { used.set(uid, { day: d, turns: 1 }); if (used.size > 50_000) used.clear(); return true; }
    if (u.turns >= (Number(env.VOICE_TURNS_PER_DAY) || perDay)) return false;
    u.turns++; return true;
  }

  async function stt(buf, { mime = 'audio/webm', lang = 'ar' } = {}) {
    if (!key()) return { error: 'voice_not_configured' };
    if (!buf?.length || buf.length < 1200) return { text: '' };   // a tap with no speech
    const ext = /mp4|m4a|aac/.test(mime) ? 'm4a' : /mpeg|mp3/.test(mime) ? 'mp3' : /wav/.test(mime) ? 'wav' : /ogg/.test(mime) ? 'ogg' : 'webm';
    const fd = new FormData();
    fd.append('file', new Blob([buf], { type: mime.split(';')[0] || 'audio/webm' }), `speech.${ext}`);
    fd.append('model', STT_MODEL());
    if (/^(ar|en|he|es|zh)$/.test(lang)) fd.append('language', lang);
    fd.append('prompt', lang === 'ar' ? 'محادثة عن التداول باللهجة الشامية: ذهب، بيتكوين، سيولة، وقف خسارة، هدف، فوركس، SMC.' : 'A conversation about trading: gold, bitcoin, liquidity, stop loss, target, forex, SMC.');
    try {
      const r = await fetchImpl(`${base()}/audio/transcriptions`, { method: 'POST', headers: { authorization: `Bearer ${key()}` }, body: fd });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) return { error: r.status === 401 ? 'voice_bad_key' : r.status === 429 ? 'voice_rate_limit' : 'voice_provider' };
      return { text: String(j.text || '').trim().slice(0, 2000) };
    } catch { return { error: 'voice_network' }; }
  }

  async function tts(text, { mentor = '', lang = 'ar' } = {}) {
    if (!key()) return { error: 'voice_not_configured' };
    const t = String(text || '').trim().slice(0, 1200);
    if (!t) return { error: 'empty' };
    const v = MENTOR_VOICES[mentor] || { voice: 'alloy', style: 'A friendly, clear trading assistant.' };
    try {
      const r = await fetchImpl(`${base()}/audio/speech`, { method: 'POST', headers: { authorization: `Bearer ${key()}`, 'content-type': 'application/json' }, body: JSON.stringify({ model: TTS_MODEL(), voice: v.voice, input: t, instructions: `${v.style} ${lang === 'ar' ? ARABIC : ''}`.trim(), response_format: 'mp3' }) });
      if (!r.ok) return { error: r.status === 401 ? 'voice_bad_key' : r.status === 429 ? 'voice_rate_limit' : 'voice_provider' };
      return { audio: Buffer.from(await r.arrayBuffer()) };
    } catch { return { error: 'voice_network' }; }
  }
  return { enabled: () => Boolean(key()), allow, stt, tts };
}
