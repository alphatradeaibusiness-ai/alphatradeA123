// v343 Durable mirror — keeps the server's data alive when the disk is wiped (Render free plan wipes it on every deploy).
// Everything the server keeps (members, subscriptions, trades, channel, partners, settings — files stay encrypted exactly as
// on disk — plus a consistent snapshot of the bank database) is packed, gzipped and saved to the owner's Firebase project
// (Cloud Firestore) with the existing FIREBASE_SERVICE_ACCOUNT. On start, an EMPTY data folder is restored from that copy.
//   • saved every DURABLE_EVERY_MIN minutes (default 10) only when something changed, and once more on shutdown (deploys)
//   • a new copy is written next to the old one and only then made current, so a failed save never breaks the last good copy
//   • DURABLE_DISABLED=1 turns it off; without a service account it simply stays off (status says why)
// Needs: Firebase console → Build → Firestore Database → Create database (any location, production rules — the server
// writes with its service account, rules do not apply to it). Nothing else.
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import { parseServiceAccount } from './faceLogin.js';

const COL = 'gotriva_mirror';
const CHUNK = 900_000;   // Firestore keeps up to ~1 MiB per document
const SKIP_DIRS = new Set(['backups', 'bank', 'tmp']);

export function createDurable({ dataDir, bankDir = path.join(dataDir, 'bank'), env = process.env, fetchImpl = globalThis.fetch, now = Date.now, log = console }) {
  const sa = parseServiceAccount(env.FIREBASE_SERVICE_ACCOUNT);
  const project = sa?.projectId || env.FIREBASE_PROJECT_ID || null;
  const enabled = !!(sa && project && env.DURABLE_DISABLED !== '1' && fetchImpl);
  const why = env.DURABLE_DISABLED === '1' ? 'disabled' : !sa ? 'no_service_account' : !project ? 'no_project_id' : null;
  const base = `https://firestore.googleapis.com/v1/projects/${project}/databases/(default)/documents/${COL}`;
  let snapshotBank = null; let tok = null; let tokExp = 0;
  let lastHash = null; let lastAt = null; let lastError = null; let restored = null; let saving = null;

  async function token() {
    if (tok && now() < tokExp - 60_000) return tok;
    const iat = Math.floor(now() / 1000);
    const b = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
    const unsigned = `${b({ alg: 'RS256', typ: 'JWT' })}.${b({ iss: sa.email, scope: 'https://www.googleapis.com/auth/datastore', aud: 'https://oauth2.googleapis.com/token', iat, exp: iat + 3600 })}`;
    const jwt = `${unsigned}.${crypto.sign('RSA-SHA256', Buffer.from(unsigned), sa.key).toString('base64url')}`;
    const r = await fetchImpl('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}` });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.access_token) throw new Error(`token ${r.status}`);
    tok = j.access_token; tokExp = now() + (Number(j.expires_in) || 3600) * 1000; return tok;
  }
  async function call(method, url, body) {
    const r = await fetchImpl(url, { method, headers: { authorization: `Bearer ${await token()}`, 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    if (method === 'GET' && r.status === 404) return null;
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`firestore ${method} ${r.status}${j?.error?.status ? ` ${j.error.status}` : ''}`);
    return j;
  }

  /* ── pack / unpack ── */
  function collect() {
    const files = {};
    const walk = (dir, rel) => {
      let list = []; try { list = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const e of list) {
        const a = path.join(dir, e.name); const r = rel ? `${rel}/${e.name}` : e.name;
        if (e.isDirectory()) { if (!rel && SKIP_DIRS.has(e.name)) continue; walk(a, r); continue; }
        if (!e.isFile() || /\.(tmp|partial|lock)$/.test(e.name)) continue;
        try { files[r] = fs.readFileSync(a).toString('base64'); } catch { /* vanished meanwhile */ }
      }
    };
    walk(dataDir, '');
    if (snapshotBank) {
      const tmp = path.join(dataDir, `bank-mirror-${process.pid}.db.tmp`);
      try { fs.rmSync(tmp, { force: true }); snapshotBank(tmp); files['@bank/bank.db'] = fs.readFileSync(tmp).toString('base64'); } catch (e) { log.error?.('[durable] bank snapshot failed:', e?.message || e); } finally { fs.rmSync(tmp, { force: true }); }
    }
    return files;
  }
  const digest = (files) => { const h = crypto.createHash('sha256'); for (const k of Object.keys(files).sort()) h.update(k).update('\0').update(files[k]).update('\0'); return h.digest('hex'); };
  function hasData() {
    try { return fs.readdirSync(dataDir, { withFileTypes: true }).some((e) => e.isFile() ? /\.(json|jsonl)$/.test(e.name) && e.name !== 'ff-cache.json' : (e.isDirectory() && !SKIP_DIRS.has(e.name) && fs.readdirSync(path.join(dataDir, e.name)).length > 0)); } catch { return false; }
  }

  /** Save a copy now (skipped when nothing changed since the last save, unless force). */
  async function save({ force = false } = {}) {
    if (!enabled) return { skipped: why };
    if (saving) return saving;
    saving = (async () => {
      try {
        const files = collect(); const sha = digest(files);
        if (!force && sha === lastHash) return { skipped: 'unchanged' };
        const gz = zlib.gzipSync(Buffer.from(JSON.stringify({ v: 1, at: now(), files })), { level: 9 });
        const gen = `${now().toString(36)}${crypto.randomBytes(3).toString('hex')}`;
        const n = Math.max(1, Math.ceil(gz.length / CHUNK));
        for (let i = 0; i < n; i++) await call('PATCH', `${base}/c_${gen}_${i}`, { fields: { d: { bytesValue: gz.subarray(i * CHUNK, (i + 1) * CHUNK).toString('base64') } } });
        const prev = await call('GET', `${base}/meta`).catch(() => null);
        await call('PATCH', `${base}/meta`, { fields: { gen: { stringValue: gen }, chunks: { integerValue: String(n) }, at: { integerValue: String(now()) }, sha: { stringValue: crypto.createHash('sha256').update(gz).digest('hex') }, size: { integerValue: String(gz.length) }, files: { integerValue: String(Object.keys(files).length) } } });
        const pg = prev?.fields?.gen?.stringValue; const pn = Number(prev?.fields?.chunks?.integerValue || 0);
        if (pg && pg !== gen) for (let i = 0; i < pn; i++) await call('DELETE', `${base}/c_${pg}_${i}`).catch(() => {});
        lastHash = sha; lastAt = now(); lastError = null;
        return { ok: true, chunks: n, bytes: gz.length, files: Object.keys(files).length };
      } catch (e) { lastError = String(e?.message || e).slice(0, 140); log.error?.('[durable] save failed:', lastError); return { ok: false, error: lastError }; }
    })();
    const mine = saving; mine.finally(() => { if (saving === mine) saving = null; });   // cleared after assignment (a run with no await finishes synchronously)
    return mine;
  }

  /** On start: when the data folder is empty (fresh disk after a deploy), bring back the last saved copy. */
  async function restoreIfEmpty() {
    if (!enabled) return { skipped: why };
    if (hasData()) { restored = { skipped: 'has_data' }; return restored; }
    try {
      const meta = await call('GET', `${base}/meta`);
      if (!meta) { restored = { skipped: 'no_copy_yet' }; return restored; }
      const f = meta.fields || {}; const gen = f.gen?.stringValue; const n = Number(f.chunks?.integerValue || 0);
      const parts = [];
      for (let i = 0; i < n; i++) { const d = await call('GET', `${base}/c_${gen}_${i}`); if (!d) throw new Error(`missing chunk ${i}`); parts.push(Buffer.from(d.fields.d.bytesValue, 'base64')); }
      const gz = Buffer.concat(parts);
      if (f.sha?.stringValue && crypto.createHash('sha256').update(gz).digest('hex') !== f.sha.stringValue) throw new Error('checksum mismatch');
      const pack = JSON.parse(zlib.gunzipSync(gz).toString('utf8'));
      let count = 0;
      for (const [rel, b64] of Object.entries(pack.files || {})) {
        const isBank = rel.startsWith('@bank/');
        const target = isBank ? path.join(bankDir, rel.slice(6)) : path.join(dataDir, rel);
        const root = path.resolve(isBank ? bankDir : dataDir);
        if (!path.resolve(target).startsWith(root + path.sep)) continue;   // never write outside the data folders
        if (isBank && fs.existsSync(target)) continue;
        fs.mkdirSync(path.dirname(target), { recursive: true, mode: 0o700 }); fs.writeFileSync(target, Buffer.from(b64, 'base64'), { mode: 0o600 }); count++;
      }
      lastHash = digest(pack.files || {}); restored = { ok: true, files: count, from: pack.at };
      log.log?.(`[durable] restored ${count} files saved at ${new Date(pack.at).toISOString()}`);
      return restored;
    } catch (e) { lastError = String(e?.message || e).slice(0, 140); restored = { ok: false, error: lastError }; log.error?.('[durable] restore failed:', lastError); return restored; }
  }

  function start() {
    if (!enabled) return () => {};
    const every = Math.max(2, Math.min(120, Number(env.DURABLE_EVERY_MIN) || 10)) * 60_000;
    const first = setTimeout(() => save(), 90_000); first.unref?.();
    const t = setInterval(() => save(), every); t.unref?.();
    return () => { clearTimeout(first); clearInterval(t); };
  }
  const status = () => ({ enabled, reason: why, project: enabled ? project : null, lastAt, error: lastError, restored, stale: enabled && (!lastAt || now() - lastAt > 3 * 3600_000) });
  return { save, restoreIfEmpty, start, status, setBankSnapshot: (fn) => { snapshotBank = fn; }, enabled };
}
