// v343 Visitor analytics — where visitors come from, without cookies, IPs or personal data.
// The page sends ONE small beacon per browser session: referring site (host only), utm_source / utm_medium / utm_campaign,
// landing page (route name only), device class, language and the device's time zone (a rough country hint).
// Kept as daily totals for 120 days. Unique visitors per day are counted with a salted hash of a random browser id that
// rotates daily — nothing here can identify a person.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const KEEP_DAYS = 120;
const MAX_KEYS = 60;   // per breakdown per day; the rest is counted as "other"
const clean = (s, n = 60) => String(s ?? '').toLowerCase().replace(/[^a-z0-9._\-/+ ]/g, '').trim().slice(0, n);
const day = (t) => new Date(t).toISOString().slice(0, 10);

// Time zone → country (Arabic, English) for the zones most visitors use; others are shown by their zone name.
const TZ = {
  'Asia/Amman': ['الأردن', 'Jordan'], 'Asia/Riyadh': ['السعودية', 'Saudi Arabia'], 'Asia/Dubai': ['الإمارات', 'UAE'], 'Africa/Cairo': ['مصر', 'Egypt'],
  'Asia/Baghdad': ['العراق', 'Iraq'], 'Asia/Kuwait': ['الكويت', 'Kuwait'], 'Asia/Qatar': ['قطر', 'Qatar'], 'Asia/Bahrain': ['البحرين', 'Bahrain'],
  'Asia/Muscat': ['عُمان', 'Oman'], 'Asia/Beirut': ['لبنان', 'Lebanon'], 'Asia/Damascus': ['سوريا', 'Syria'], 'Asia/Gaza': ['فلسطين', 'Palestine'],
  'Asia/Hebron': ['فلسطين', 'Palestine'], 'Asia/Jerusalem': ['فلسطين / القدس', 'Jerusalem'], 'Africa/Casablanca': ['المغرب', 'Morocco'], 'Africa/Algiers': ['الجزائر', 'Algeria'],
  'Africa/Tunis': ['تونس', 'Tunisia'], 'Africa/Tripoli': ['ليبيا', 'Libya'], 'Africa/Khartoum': ['السودان', 'Sudan'], 'Asia/Aden': ['اليمن', 'Yemen'],
  'Europe/Istanbul': ['تركيا', 'Turkey'], 'Europe/London': ['بريطانيا', 'UK'], 'Europe/Berlin': ['ألمانيا', 'Germany'], 'Europe/Paris': ['فرنسا', 'France'],
  'Europe/Amsterdam': ['هولندا', 'Netherlands'], 'Europe/Stockholm': ['السويد', 'Sweden'], 'America/New_York': ['أمريكا (شرق)', 'USA (East)'],
  'America/Chicago': ['أمريكا (وسط)', 'USA (Central)'], 'America/Los_Angeles': ['أمريكا (غرب)', 'USA (West)'], 'America/Toronto': ['كندا', 'Canada'],
};
export const tzCountry = (tz) => TZ[tz] || null;

export function createVisits({ dir, now = Date.now, log = console } = {}) {
  const file = dir ? path.join(dir, 'visits.json') : null;
  let st = null; let dirty = false; let salt = crypto.randomBytes(16).toString('hex'); let saltDay = '';
  const load = () => {
    if (st) return st;
    st = { days: {} };
    if (file) { try { st = { days: {}, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch { /* first start */ } }
    return st;
  };
  function flush() {
    if (!dirty || !file || !st) return; dirty = false;
    try { fs.mkdirSync(dir, { recursive: true }); const tmp = `${file}.tmp`; fs.writeFileSync(tmp, JSON.stringify(st)); fs.renameSync(tmp, file); } catch (e) { log.error?.('[visits] save failed:', e?.message || e); }
  }
  const timer = setInterval(flush, 60_000); timer.unref?.();
  const bump = (obj, k) => { if (!k) return; if (!(k in obj) && Object.keys(obj).length >= MAX_KEYS) k = 'other'; obj[k] = (obj[k] || 0) + 1; };

  /** One beacon (one browser session). Returns false for junk. */
  function record(b = {}, { selfHost = '' } = {}) {
    const t = now(); const d = day(t); const s = load();
    const D = s.days[d] ||= { visits: 0, uniq: 0, seen: [], ref: {}, utm: {}, camp: {}, land: {}, dev: {}, lang: {}, tz: {}, signups: 0 };
    if (saltDay !== d) { saltDay = d; salt = crypto.randomBytes(16).toString('hex'); }
    let ref = clean(String(b.ref || '').replace(/^https?:\/\//, '').split(/[/?#]/)[0].replace(/^www\.|^m\.|^l\.|^lm\./, ''), 60);
    if (ref && selfHost && ref === clean(selfHost)) ref = '';
    if (/(^|\.)(google)\./.test(ref)) ref = 'google'; else if (/facebook|fb\.com/.test(ref)) ref = 'facebook'; else if (/instagram/.test(ref)) ref = 'instagram';
    else if (/(^|\.)t\.co$|twitter|x\.com/.test(ref)) ref = 'x / twitter'; else if (/tiktok/.test(ref)) ref = 'tiktok'; else if (/youtube|youtu\.be/.test(ref)) ref = 'youtube';
    else if (/telegram|t\.me/.test(ref)) ref = 'telegram'; else if (/whatsapp|wa\.me/.test(ref)) ref = 'whatsapp'; else if (/bing\./.test(ref)) ref = 'bing';
    D.visits++;
    const vid = clean(b.vid, 40);
    if (vid) { const h = crypto.createHash('sha256').update(`${salt}:${vid}`).digest('base64url').slice(0, 12); if (!D.seen.includes(h)) { if (D.seen.length < 20_000) D.seen.push(h); D.uniq++; } }
    else D.uniq++;
    bump(D.ref, ref || 'direct'); bump(D.utm, clean(b.utm_source, 40)); bump(D.camp, clean(b.utm_campaign, 60));
    bump(D.land, clean(String(b.land || '').replace(/^#?\/?/, '').split(/[?&]/)[0], 40) || 'home');
    bump(D.dev, ['phone', 'tablet', 'desktop'].includes(b.dev) ? b.dev : 'other'); bump(D.lang, clean(b.lang, 8));
    bump(D.tz, String(b.tz || '').replace(/[^A-Za-z_/+-]/g, '').slice(0, 40) || 'unknown');
    // keep only KEEP_DAYS days; old days lose their (already anonymous) hash list
    const keys = Object.keys(s.days).sort(); for (const k of keys.slice(0, Math.max(0, keys.length - KEEP_DAYS))) delete s.days[k];
    for (const k of keys) if (k !== d && s.days[k]?.seen?.length) s.days[k].seen = [];
    dirty = true; return true;
  }
  function signup() { const s = load(); const d = day(now()); (s.days[d] ||= { visits: 0, uniq: 0, seen: [], ref: {}, utm: {}, camp: {}, land: {}, dev: {}, lang: {}, tz: {}, signups: 0 }).signups++; dirty = true; }

  /** Owner view: totals for 1 / 7 / 30 days, a 30-day series and the top sources. */
  function summary(days = 30) {
    const s = load(); const t = now(); const list = [];
    for (let i = days - 1; i >= 0; i--) { const d = day(t - i * 86_400_000); list.push([d, s.days[d]]); }
    const sum = (n, f) => list.slice(-n).reduce((a, [, x]) => a + (x ? f(x) : 0), 0);
    const merge = (field, n = days) => { const o = {}; for (const [, x] of list.slice(-n)) if (x) for (const [k, v] of Object.entries(x[field] || {})) o[k] = (o[k] || 0) + v; return Object.entries(o).sort((a, b) => b[1] - a[1]).slice(0, 12); };
    const tz = merge('tz').map(([k, v]) => [k, v, tzCountry(k)]);
    const visits30 = sum(days, (x) => x.visits); const sign30 = sum(days, (x) => x.signups || 0);
    return {
      today: { visits: sum(1, (x) => x.visits), unique: sum(1, (x) => x.uniq), signups: sum(1, (x) => x.signups || 0) },
      d7: { visits: sum(7, (x) => x.visits), unique: sum(7, (x) => x.uniq), signups: sum(7, (x) => x.signups || 0) },
      d30: { visits: visits30, unique: sum(days, (x) => x.uniq), signups: sign30, conversionPct: visits30 ? +((sign30 / visits30) * 100).toFixed(1) : 0 },
      series: list.map(([d, x]) => ({ day: d, visits: x?.visits || 0, unique: x?.uniq || 0, signups: x?.signups || 0 })),
      sources: merge('ref'), utm: merge('utm'), campaigns: merge('camp'), landing: merge('land'), devices: merge('dev'), langs: merge('lang'), places: tz,
    };
  }
  return { record, signup, summary, flush, stop: () => { clearInterval(timer); flush(); } };
}
