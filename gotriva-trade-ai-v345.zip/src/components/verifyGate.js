// v343 E-mail confirmation gate: a NEW account (e-mail/password or Google) opens only after the 6-digit code sent to its e-mail.
// The server decides who must confirm (old accounts, owners, or a server without an e-mail service are never asked).
import { esc } from '../utils/dom.js';
import { tx } from '../i18n/tx.js';
import { getLang } from '../i18n/index.js';
import { apiRequest } from '../services/ai/gateway.js';
import { auth } from '../services/auth/index.js';

const L = (ar, en) => tx({ ar, en });
const ERR = {
  wrong_code: ['الرمز غلط.', 'Wrong code.'],
  expired: ['الرمز انتهى. اطلب رمز جديد.', 'The code expired. Ask for a new one.'],
  too_many_tries: ['محاولات كثيرة. اطلب رمز جديد.', 'Too many tries. Ask for a new one.'],
  too_soon: ['استنى شوي قبل ما تطلب رمز جديد.', 'Wait a little before asking again.'],
  too_many: ['طلبت رموز كثير. جرّب بعد ساعة.', 'Too many codes asked. Try again in an hour.'],
  mail_not_configured: ['خدمة البريد مش جاهزة هلّق.', 'E-mail service is not ready right now.'],
};
const msg = (code) => L(...(ERR[code] || ['صار خطأ. جرّب كمان مرة.', 'Something went wrong. Try again.']));

let shown = false;
export async function maybeVerifyGate() {
  if (shown || auth.mode === 'local' || !auth.current()?.uid) return;
  let s; try { s = await apiRequest('GET', '/api/me/verify', undefined, 15000); } catch { return; }   // server down: never lock anybody out
  if (!s?.required) return;
  shown = true;
  const email = auth.current()?.email || '';
  const el = document.createElement('div');
  el.className = 'vg-back'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.dir = getLang() === 'ar' ? 'rtl' : 'ltr';
  el.innerHTML = `<form class="vg-card" novalidate>
    <div class="vg-icon" aria-hidden="true">✉</div>
    <h2>${esc(L('أكّد بريدك الإلكتروني', 'Confirm your e-mail'))}</h2>
    <p class="vg-sub">${esc(L('بعتنالك رمز من 6 أرقام على', 'We sent a 6-digit code to'))} <b dir="ltr">${esc(email)}</b>. ${esc(L('اكتبه هون ليفتح حسابك. (شيّك على البريد غير المرغوب كمان)', 'Enter it here to open your account. (Check spam too.)'))}</p>
    <input class="input vg-code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" dir="ltr" placeholder="••••••" aria-label="${esc(L('رمز التأكيد', 'Confirmation code'))}">
    <p class="vg-err" role="alert" hidden></p>
    <button type="submit" class="btn btn-primary vg-go">${esc(L('تأكيد', 'Confirm'))}</button>
    <div class="vg-row"><button type="button" class="btn btn-sm btn-ghost" data-resend>${esc(L('ابعت رمز جديد', 'Send a new code'))}</button>
    <button type="button" class="btn btn-sm btn-ghost" data-out>${esc(L('تسجيل خروج', 'Sign out'))}</button></div>
  </form>`;
  document.body.append(el);
  const input = el.querySelector('.vg-code'); const err = el.querySelector('.vg-err'); const resend = el.querySelector('[data-resend]'); const go = el.querySelector('.vg-go');
  const showErr = (t) => { err.textContent = t; err.hidden = !t; };
  let tick = 0;
  const cool = (sec) => {
    clearInterval(tick); let left = sec; resend.disabled = true;
    const paint = () => { resend.textContent = left > 0 ? `${L('ابعت رمز جديد', 'Send a new code')} (${left})` : L('ابعت رمز جديد', 'Send a new code'); resend.disabled = left > 0; };
    paint(); tick = setInterval(() => { left--; paint(); if (left <= 0) clearInterval(tick); }, 1000);
  };
  const sendCode = async () => {
    showErr('');
    try { await apiRequest('POST', '/api/me/verify/send', { lang: getLang() }, 20000); cool(60); }
    catch (e) { showErr(msg(e.code)); if (e.code === 'too_soon') cool(60); }
  };
  if (s.pending && s.retryInS > 0) cool(s.retryInS); else sendCode();
  input.addEventListener('input', () => { input.value = input.value.replace(/\D/g, '').slice(0, 6); if (input.value.length === 6) el.querySelector('form').requestSubmit(); });
  el.querySelector('form').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (input.value.length !== 6) { showErr(L('اكتب الرمز كامل (6 أرقام).', 'Enter all 6 digits.')); return; }
    go.disabled = true; showErr('');
    try { await apiRequest('POST', '/api/me/verify/check', { code: input.value }, 15000); clearInterval(tick); el.remove(); location.reload(); }
    catch (x) { showErr(msg(x.code)); input.select(); }
    finally { go.disabled = false; }
  });
  resend.addEventListener('click', sendCode);
  el.querySelector('[data-out]').addEventListener('click', async () => { clearInterval(tick); el.remove(); shown = false; await auth.signOut(); location.hash = '#/login'; });
  setTimeout(() => input.focus(), 50);
}
