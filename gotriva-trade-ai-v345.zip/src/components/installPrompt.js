// v343 "Install the app" bar: shown once in a while when the browser offers installing (Android / desktop Chrome, Edge).
// iPhone has no install event, so it gets a one-time hint (Share → Add to Home Screen). Never shown inside the installed app.
import { tx } from '../i18n/tx.js';
import { esc } from '../utils/dom.js';

const L = (ar, en) => tx({ ar, en });
const KEY = 'gv-install-later';
const later = () => { try { return Number(localStorage.getItem(KEY) || 0) > Date.now(); } catch { return true; } };
const snooze = (days) => { try { localStorage.setItem(KEY, String(Date.now() + days * 86_400_000)); } catch { /* */ } };
const standalone = () => matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;

function bar(text, action, onAction) {
  const el = document.createElement('div'); el.className = 'ip-bar'; el.setAttribute('role', 'status');
  el.innerHTML = `<img src="/icon-192.png" alt="" width="36" height="36"><span>${esc(text)}</span>${action ? `<button type="button" class="btn btn-sm btn-primary" data-ip-go>${esc(action)}</button>` : ''}<button type="button" class="btn btn-sm btn-ghost" data-ip-x aria-label="${esc(L('إغلاق', 'Close'))}">✕</button>`;
  el.querySelector('[data-ip-x]').addEventListener('click', () => { snooze(14); el.remove(); });
  el.querySelector('[data-ip-go]')?.addEventListener('click', async () => { el.remove(); await onAction?.(); });
  document.body.append(el);
}

export function startInstallPrompt() {
  if (standalone()) return;
  let ev = null;
  addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault(); ev = e;
    if (later()) return;
    setTimeout(() => { if (ev && !document.querySelector('.ip-bar, .vg-back')) bar(L('ثبّت GOTRIVA TRADE AI على جهازك، بيفتح أسرع ومن غير متصفح.', 'Install GOTRIVA TRADE AI: opens faster, without the browser.'), L('ثبّت', 'Install'), async () => { ev.prompt(); const r = await ev.userChoice.catch(() => null); if (r?.outcome !== 'accepted') snooze(14); ev = null; }); }, 40_000);
  });
  const ios = /iphone|ipad|ipod/i.test(navigator.userAgent) && !/crios|fxios/i.test(navigator.userAgent);
  if (ios && !later()) setTimeout(() => { if (!document.querySelector('.ip-bar, .vg-back')) { bar(L('لتثبيت التطبيق: اكبس زر المشاركة ⬆︎ وبعدين «إضافة إلى الشاشة الرئيسية».', 'To install: tap Share ⬆︎ then “Add to Home Screen”.')); snooze(30); } }, 45_000);
}
