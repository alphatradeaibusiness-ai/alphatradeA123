// v345 Real voice call with an AI mentor (like the voice mode of ChatGPT / Gemini): the microphone is recorded in short turns,
// the end of a sentence is detected from the sound level, the words are turned into text on the site's server, the mentor
// answers, and the answer is spoken in that mentor's OWN natural voice (server text-to-speech). Works on iPhone Safari too
// (MediaRecorder + one <audio> element unlocked by the tap that starts the call). Recordings are never stored.
import { AI_BASE, AiError } from './ai/gateway.js';
import { auth } from './auth/index.js';

let statusP = null;
/** true when the server has real voices (OPENAI_API_KEY set by the owner). Cached for the page. */
export function realVoiceAvailable() {
  if (!statusP) statusP = fetch(`${AI_BASE}/voice/status`, { cache: 'no-store' }).then((r) => (r.ok ? r.json() : null)).then((j) => Boolean(j?.enabled)).catch(() => false);
  return statusP;
}
export const recorderSupported = () => typeof window !== 'undefined' && Boolean(navigator.mediaDevices?.getUserMedia) && typeof window.MediaRecorder !== 'undefined';

// a real, tiny silent WAV (built in the page) — playing it inside the tap unlocks the audio element on iPhone
function silentWav() {
  const n = 800; const b = new ArrayBuffer(44 + n * 2); const v = new DataView(b); const w = (o, t) => { for (let i = 0; i < t.length; i++) v.setUint8(o + i, t.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, 8000, true); v.setUint32(28, 16000, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
  return URL.createObjectURL(new Blob([b], { type: 'audio/wav' }));
}

async function authHeaders(extra = {}) {
  const h = { ...extra }; const tok = await auth.idToken().catch(() => null);
  if (tok) h.Authorization = `Bearer ${tok}`;
  return h;
}
async function postAudio(blob, lang) {
  const r = await fetch(`${AI_BASE}/voice/stt?lang=${encodeURIComponent(lang)}`, { method: 'POST', headers: await authHeaders({ 'Content-Type': blob.type || 'audio/webm' }), body: blob });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new AiError(j.code || `http_${r.status}`, r.status);
  return String(j.text || '').trim();
}
async function fetchSpeech(text, mentor, lang) {
  const r = await fetch(`${AI_BASE}/voice/tts`, { method: 'POST', headers: await authHeaders({ 'Content-Type': 'application/json' }), body: JSON.stringify({ text, mentor, lang }) });
  if (!r.ok) { const j = await r.json().catch(() => ({})); throw new AiError(j.code || `http_${r.status}`, r.status); }
  return URL.createObjectURL(await r.blob());
}

/**
 * Start a call. MUST be called from the tap / click handler (iPhone only allows sound and the microphone from a tap).
 * opts: { mentor, getLang, onAsk(text) → reply text, onState(state, detail), onHeard(text), onError(err) }
 * states: 'connect' | 'listen' | 'hear' (the person is talking) | 'think' | 'speak' | 'off'
 * Returns { stop(), interrupt() } — interrupt() cuts the mentor off and listens again.
 */
export function realCall({ mentor, getLang, onAsk, onState, onHeard, onError }) {
  let on = true; let stream = null; let ctx = null; let analyser = null; let rec = null; let raf = 0; let quietTurns = 0; let curUrl = null;
  const audio = new Audio(); audio.setAttribute('playsinline', ''); audio.preload = 'auto';
  try { audio.src = silentWav(); audio.play().catch(() => {}); } catch { /* unlock attempt */ }
  try { const AC = window.AudioContext || window.webkitAudioContext; ctx = new AC(); ctx.resume?.(); } catch { ctx = null; }

  const level = (() => { const buf = new Float32Array(1024); return () => { if (!analyser) return 0; analyser.getFloatTimeDomainData(buf); let s = 0; for (let i = 0; i < buf.length; i++) s += buf[i] * buf[i]; return Math.sqrt(s / buf.length); }; })();
  const end = (why) => {
    if (!on) return; on = false; cancelAnimationFrame(raf);
    try { rec && rec.state !== 'inactive' && rec.stop(); } catch { /* */ }
    try { audio.pause(); } catch { /* */ }
    if (curUrl) URL.revokeObjectURL(curUrl);
    stream?.getTracks().forEach((t) => t.stop()); ctx?.close?.().catch?.(() => {});
    onState?.('off', why || null);
  };

  function listen() {
    if (!on) return;
    onState?.('listen');
    const mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/aac', ''].find((t) => !t || MediaRecorder.isTypeSupported?.(t));
    const chunks = [];
    try { rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined); } catch (e) { onError?.(e); end('unsupported'); return; }
    rec.ondataavailable = (e) => { if (e.data?.size) chunks.push(e.data); };
    let started = false; let speechAt = 0; let lastLoud = 0; const t0 = performance.now(); let floor = 0.006; let samples = 0;
    rec.onstop = async () => {
      cancelAnimationFrame(raf);
      if (!on) return;
      if (!started) { if (++quietTurns > 5) { end('idle'); return; } listen(); return; }
      quietTurns = 0;
      const blob = new Blob(chunks, { type: (rec.mimeType || mime || 'audio/webm').split(';')[0] });
      onState?.('think');
      let text = '';
      try { text = await postAudio(blob, getLang()); } catch (e) { onError?.(e); if (['voice_not_configured', 'voice_daily_limit', 'voice_bad_key', 'plan_upgrade_required', 'email_unverified', 'ai_quota', 'no_plan'].includes(e.code)) { end(e.code); return; } }
      if (!on) return;
      if (!text) { listen(); return; }
      onHeard?.(text);
      let reply = '';
      try { reply = await onAsk(text); } catch { reply = ''; }
      if (!on) return;
      if (!reply) { listen(); return; }
      speak(reply);
    };
    rec.start(250);
    const tick = () => {
      if (!on || rec.state === 'inactive') return;
      const now = performance.now();
      if (!analyser) { if (!started) { started = true; speechAt = now; onState?.('hear'); } if (now - t0 > 7000) { try { rec.stop(); } catch { /* */ } return; } raf = requestAnimationFrame(tick); return; }   // no level meter: fixed 7 s turns
      const v = level();
      if (!started && now - t0 < 400) { floor = (floor * samples + v) / (samples + 1); samples++; }   // the room's background noise
      const thr = Math.max(0.018, Math.min(floor, 0.025) * 2.6);   // a person who starts talking at once must not raise the bar
      if (v > thr) { lastLoud = now; if (!started) { started = true; speechAt = now; onState?.('hear'); } }
      const silentFor = now - (lastLoud || t0);
      if ((started && silentFor > 1000 && now - speechAt > 450) || (started && now - speechAt > 30_000) || (!started && now - t0 > 12_000)) { try { rec.stop(); } catch { /* */ } return; }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
  }

  async function speak(text) {
    onState?.('speak', text);
    let url = null;
    try { url = await fetchSpeech(text, mentor, getLang()); } catch (e) { onError?.(e); }
    if (!on) { if (url) URL.revokeObjectURL(url); return; }
    if (!url) { listen(); return; }
    if (curUrl) URL.revokeObjectURL(curUrl); curUrl = url;
    audio.onended = () => { if (on) listen(); };
    audio.onerror = () => { if (on) listen(); };
    audio.src = url;
    try { await audio.play(); } catch { if (on) listen(); return; }
    // barge-in: talking clearly over the mentor cuts it off (echo cancellation keeps its own voice out of the microphone)
    let loudSince = 0;
    const watch = () => {
      if (!on || audio.paused || audio.ended) return;
      const v = level();
      if (v > 0.06) { loudSince ||= performance.now(); if (performance.now() - loudSince > 350) { audio.pause(); listen(); return; } } else loudSince = 0;
      raf = requestAnimationFrame(watch);
    };
    raf = requestAnimationFrame(watch);
  }

  (async () => {
    onState?.('connect');
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); }
    catch (e) { end(e?.name === 'NotAllowedError' || e?.name === 'SecurityError' ? 'not-allowed' : 'audio-capture'); return; }
    if (!on) { stream.getTracks().forEach((t) => t.stop()); return; }
    try { if (ctx) { const src = ctx.createMediaStreamSource(stream); analyser = ctx.createAnalyser(); analyser.fftSize = 2048; src.connect(analyser); } } catch { analyser = null; }
    listen();
  })();

  return {
    stop: () => end(null),
    interrupt: () => { if (!on) return; try { audio.pause(); } catch { /* */ } cancelAnimationFrame(raf); if (!rec || rec.state === 'inactive') listen(); },
    get on() { return on; },
  };
}
