// v343 One anonymous visit beacon per browser session: where the visitor came from (site + utm), landing page, device class,
// language and time zone. No cookies, no personal data; the random id only lets the server count unique visitors per day.
export function sendVisit() {
  try {
    if (sessionStorage.getItem('gv-sent')) return;
    sessionStorage.setItem('gv-sent', '1');
    let vid = ''; try { vid = localStorage.getItem('gv-id') || ''; if (!vid) { vid = Math.random().toString(36).slice(2, 12) + Date.now().toString(36); localStorage.setItem('gv-id', vid); } } catch { /* private window */ }
    const q = new URLSearchParams(location.search || (location.hash.split('?')[1] || ''));
    const w = Math.min(screen.width || innerWidth, innerWidth || 9999);
    const body = JSON.stringify({
      vid, ref: document.referrer || '', land: (location.hash || '#/').split('?')[0].slice(0, 40),
      utm_source: q.get('utm_source') || q.get('ref') ? (q.get('utm_source') || 'referral') : '', utm_medium: q.get('utm_medium') || '', utm_campaign: q.get('utm_campaign') || '',
      dev: w < 600 ? 'phone' : w < 1024 ? 'tablet' : 'desktop', lang: (navigator.language || '').slice(0, 5),
      tz: Intl.DateTimeFormat().resolvedOptions().timeZone || '',
    });
    fetch('/api/visit', { method: 'POST', headers: { 'content-type': 'application/json' }, body, keepalive: true }).catch(() => {});
  } catch { /* never break the page */ }
}
