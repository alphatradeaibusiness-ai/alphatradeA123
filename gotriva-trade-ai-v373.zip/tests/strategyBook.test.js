import test from 'node:test';
import assert from 'node:assert/strict';
import { runBook, bookPlan, BOOK, BOOK_SIZE, indicators, replay } from '../src/services/strategyBook.js';
import { strategyOf } from '../src/config/aiSignalRules.js';

function candles(n, drift, seed = 11) {
  let s = seed; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const out = []; let p = 100;
  for (let i = 0; i < n; i++) { const o = p; p *= 1 + (r() - 0.5) * 0.01 + drift; out.push({ time: 1700000000 + i * 300, open: o, high: Math.max(o, p) * (1 + r() * 0.003), low: Math.min(o, p) * (1 - r() * 0.003), close: p, volume: 50 + r() * 100 }); }
  return out;
}

test('the book has more than 100 strategies with unique ids and names', () => {
  assert.ok(BOOK_SIZE >= 100, `${BOOK_SIZE}`);
  assert.equal(new Set(BOOK.map((s) => s.id)).size, BOOK_SIZE);
  for (const s of BOOK) { assert.ok(s.name.ar && s.name.en, s.id); assert.ok(strategyOf(s.id)?.status === 'book', s.id); }
});

test('SMC and ICT rules are never mixed', () => {
  for (const s of BOOK) {
    const smc = /SMC/.test(s.name.en), ict = /ICT/.test(s.name.en);
    assert.ok(!(smc && ict), s.id);
    if (smc) assert.equal(s.school, 'smc'); if (ict) assert.equal(s.school, 'ict');
  }
});

test('a pick always exists on 220+ live candles, up and down markets, and no rule throws', () => {
  for (const drift of [0.0008, -0.0008, 0]) {
    const cs = candles(600, drift, 3 + Math.round(drift * 1e4));
    const r = runBook(cs, { style: 'scalp', costPct: 0.05 });
    assert.ok(r.pick, `no pick for drift ${drift}`);
    const I = indicators(cs); for (const s of BOOK) for (let i = 210; i < cs.length; i++) s.f(I, i);
  }
  assert.equal(runBook(candles(100, 0)).pick, null);
});

test('plan levels are on the right side for long and short', () => {
  const cs = candles(400, 0.0005);
  for (const dir of [1, -1]) for (const style of ['scalp', 'swing']) {
    const pl = bookPlan({ dir, rec: { n: 10, winRate: 0.5, avgR: 0.1 } }, cs, { style, price: 123, costPct: 0.05 });
    assert.equal(pl.entry, 123);
    if (dir > 0) { assert.ok(pl.stop < pl.entry); pl.targets.forEach((t) => assert.ok(t > pl.entry)); }
    else { assert.ok(pl.stop > pl.entry); pl.targets.forEach((t) => assert.ok(t < pl.entry)); }
    assert.ok(pl.quality >= 5 && pl.quality <= 95);
  }
});

test('replay counts costs and never looks ahead', () => {
  const cs = candles(500, 0.0003); const I = indicators(cs);
  const s = BOOK.find((x) => x.id === 'bk_ema_9_21');
  const a = replay(I, s, { costPct: 0 }), b = replay(I, s, { costPct: 0.2 });
  assert.ok(a.n > 0 && a.n === b.n); assert.ok(b.avgR < a.avgR);
  // changing a future candle does not change a signal computed at an earlier bar
  const I2 = indicators(cs.map((c, i) => (i === 450 ? { ...c, close: c.close * 1.2, high: c.high * 1.2 } : c)));
  for (let i = 220; i < 449; i++) assert.equal(s.f(I, i), s.f(I2, i));
});

test('the owner engine report renders when the main trade comes from the book (it used to throw and freeze the page)', async () => {
  const { engineHtml } = await import('../src/components/aiEngineReport.js');
  const { runAllStrategies } = await import('../src/services/multiStrategy.js');
  const cs = candles(600, 0.0002).map((c, i, a) => ({ ...c, time: Math.floor(Date.now() / 1000) - (a.length - i) * 300 }));
  const m = runAllStrategies({ symbol: 'XAUUSD', inst: { type: 'metal', provider: 'yahoo' }, tf: '5m', tfSec: 300, candles: cs, mode: 'live', reading: null, calendar: null }, { ai: true });
  m.pick = { id: 'bk_ema_9_21', plan: { direction: 'short', entry: 1, stop: 2, targets: [0.5, 0.4, 0.3], rrMain: 1.5 } }; m.final = 'sell';
  const h = engineHtml(m, 'ar');
  assert.ok(h.includes('EMA 9/21'));
});
