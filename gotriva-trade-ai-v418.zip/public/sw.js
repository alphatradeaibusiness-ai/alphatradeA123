// Service worker: shows signal notifications (with the GOTRIVA TRADE AI logo) and bank push messages, and opens the right page
// when a notification is tapped (the bank sends its own in-site path; everything else opens the signals channel).
// Bump VERSION on a release: the changed file makes browsers install this worker, and activating it empties every Cache Storage
// entry an older build (or an older worker) may have left, so nothing stale survives an update. This worker caches nothing itself.
// release: v418
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil((async () => {
  try { await Promise.all((await caches.keys()).map((k) => caches.delete(k))); } catch { /* Cache Storage unavailable */ }
  await self.clients.claim();
})()));
// Offline: page loads go to the network as usual; only when there is no connection a small bilingual page is shown
// (nothing is cached, so prices and balances are never stale).
const OFFLINE = `<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GOTRIVA TRADE AI</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#05040b;color:#ece9ff;font:15px/1.7 system-ui,sans-serif;text-align:center;padding:24px}
img{width:64px;height:64px;border-radius:16px}button{margin-top:14px;padding:10px 22px;border:0;border-radius:10px;background:#7c5cff;color:#fff;font:inherit;cursor:pointer}p{margin:6px 0;color:#a9a3c9}</style>
<div><img src="/icon-192.png" alt=""><h1 style="font-size:20px;margin:14px 0 4px">ما في اتصال بالإنترنت</h1><p>الأسعار والحساب بحاجة اتصال. جرّب كمان شوي.</p>
<p dir="ltr">You are offline — prices and your account need a connection.</p><button onclick="location.reload()">إعادة المحاولة · Retry</button></div></html>`;
// v365 share target: a photo, file or text shared from another app (the installed app's "Share" menu) is kept here for a
// moment in IndexedDB and the chat page picks it up (#/app/chat?share=1) to let you choose the conversation. Nothing is uploaded
// until you send it.
function shareStore(entry) {
  return new Promise((resolve) => { const r = indexedDB.open('gotriva-share', 1); r.onupgradeneeded = () => r.result.createObjectStore('s');
    r.onsuccess = () => { const t = r.result.transaction('s', 'readwrite'); t.objectStore('s').put(entry, 'last'); t.oncomplete = () => resolve(); t.onerror = () => resolve(); }; r.onerror = () => resolve(); });
}
self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url);
  if (e.request.method === 'POST' && u.origin === self.location.origin && u.pathname === '/share-target') {
    e.respondWith((async () => { try { const f = await e.request.formData(); const files = f.getAll('files').filter((x) => x && typeof x === 'object' && x.size).slice(0, 5);
      await shareStore({ at: Date.now(), title: String(f.get('title') || '').slice(0, 300), text: String(f.get('text') || '').slice(0, 4000), url: String(f.get('url') || '').slice(0, 1000), files }); } catch { /* nothing to keep */ }
      return Response.redirect('/#/app/chat?share=1', 303); })());
    return;
  }
  if (e.request.mode !== 'navigate') return;
  e.respondWith(fetch(e.request).catch(() => new Response(OFFLINE, { status: 503, headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' } })));
});
// Bank push (Web Push, encrypted end to end; the browser has already decrypted it here).
self.addEventListener('push', (e) => {
  let d = {}; try { d = e.data ? e.data.json() : {}; } catch { d = { body: e.data ? e.data.text() : '' }; }
  const url = typeof d.url === 'string' && d.url.startsWith('/#/') ? d.url : '/#/app/bank';
  e.waitUntil(self.registration.showNotification(String(d.title || 'GOTRIVA TRADE AI').slice(0, 80), {
    // v354/v356: one notification per private channel; the newest replaces the older and still buzzes
    body: String(d.body || '').slice(0, 200), tag: String(d.tag || 'bank').slice(0, 40), renotify: /^chat-/.test(String(d.tag || '')), timestamp: Date.now(), icon: typeof d.icon === 'string' && /^\/[a-z0-9/_-]+\.png$/.test(d.icon) ? d.icon : '/icon-192.png', badge: '/icon-192.png', data: { url },
  }));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const target = e.notification.data?.url && String(e.notification.data.url).startsWith('/#/') ? e.notification.data.url : '/#/app/signals';
  e.waitUntil((async () => {
    const all = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const c of all) { if ('focus' in c) { c.navigate?.(target); return c.focus(); } }
    return self.clients.openWindow(target);
  })());
});
