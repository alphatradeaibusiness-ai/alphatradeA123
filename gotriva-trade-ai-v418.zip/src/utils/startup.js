export async function withStartupDeadline(promise, ms = 20000) {
  let timer;
  try {
    return await Promise.race([promise, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Startup timed out')), ms);
    })]);
  } finally { clearTimeout(timer); }
}
export function showStartupError(doc = document, retry = () => location.reload()) {
  const root = doc.getElementById('app');
  if (!root) return;
  const panel = doc.createElement('section'); panel.className = 'startup-panel';
  panel.setAttribute('role', 'alert');
  const inner = doc.createElement('div'); inner.className = 'startup-inner';
  const logo = doc.createElement('img'); logo.className = 'startup-logo'; logo.src = '/auth-logo.svg'; logo.alt = '';
  const title = doc.createElement('h2'); title.textContent = 'تعذّر تشغيل التطبيق · Could not start the app';
  const msg = doc.createElement('p'); msg.textContent = 'تحقق من الاتصال بالإنترنت وأعد المحاولة. · Check your connection and retry.';
  const button = doc.createElement('button'); button.type = 'button'; button.textContent = 'إعادة المحاولة · Retry'; button.addEventListener('click', retry);
  inner.append(logo, title, msg, button); panel.append(inner); root.replaceChildren(panel);
}
