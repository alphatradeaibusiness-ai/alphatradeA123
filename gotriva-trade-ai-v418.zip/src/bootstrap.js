// Authenticate before importing modules which hydrate account-specific state.
import { showStartupError, withStartupDeadline } from './utils/startup.js';
let switching = false;
try {
  const [{ auth }, { accountScope, bindStorageScope }] = await withStartupDeadline(Promise.all([
    import('./services/auth/index.js'), import('./utils/storage.js'),
  ]));
  // Fail closed: do not initialise account storage as guest when Firebase is unavailable.
  await withStartupDeadline(auth.init());
  const initial = accountScope(auth.current());
  bindStorageScope(auth.current());
  auth.onChange(user => {
    if (accountScope(user) === initial || switching) return;
    switching = true;
    document.getElementById('app')?.replaceChildren();
    document.documentElement.style.visibility = 'hidden';
    location.reload();
  });
  await import('./main.js');
} catch (error) {
  console.error('App initialisation failed', error);
  if (!switching) showStartupError();
}
