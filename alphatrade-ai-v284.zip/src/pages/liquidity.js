// v253 Live Liquidity Map (Bookmap-style) + Wall Intelligence + DOM + Anomaly Radar.
// Heatmap = REAL resting orders from the exchange order book over time (Binance: REST snapshot + diff stream over
// WebSocket, REST polling as a fallback); bubbles = REAL trades (aggTrade); walls are followed over time with refills,
// absorption by real trades and how they ended (held / broken / pulled / filled). Hidden (iceberg) size is not visible in
// any order book — only refills are shown, labelled as such. Markets without a public order book (forex, gold, indices
// on this platform) get no heatmap rather than a fake one. History lives in this tab only (it starts when you open it).
import { h, esc, fmtNum } from '../utils/dom.js';
import { icons } from '../components/icons.js';
import { getLocale } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { toast } from '../components/ui.js';
import { marketConfig, TIMEFRAMES } from '../config/market.js';
import { INSTRUMENTS, getInstrument } from '../config/instruments.js';
import { fetchBinanceBook, fetchBinanceTrades, fetchBinanceUsdtPairs } from '../services/market/binance.js';
import { venueOf, rawOf, VALID_ID, tradfiName, fetchTradfiFutures, fetchFutBook, fetchFutTrades, FUT_WS, fetchHlMarkets, fetchHlBook, hlToSnap, hlTrade, HL_WS } from '../services/market/tradfiBooks.js';
import { getHistory } from '../services/market/index.js';
import { LocalBook, niceStep, bucket, imbalance, WallTracker, liquidityStrength, anomalyOf, orderFlowRead, SetupTracker } from '../services/orderBook.js';
import { onUnmount } from './tools/common.js';
import { pageHead } from './community.js';
import '../styles/rooms.css';
import '../styles/lqmarkets.css';

const L = (ar, en) => tx({ ar, en });
const CRYPTO = INSTRUMENTS.filter((i) => i.provider === 'binance').map((i) => i.symbol);
const MAXCOL = 900;
const STOPS = [[0, [8, 18, 44]], [0.12, [10, 50, 110]], [0.3, [24, 150, 220]], [0.48, [80, 220, 230]], [0.62, [245, 230, 90]], [0.76, [250, 160, 30]], [0.88, [240, 60, 50]], [1, [255, 255, 255]]];
const LUT = Array.from({ length: 96 }, (_, i) => { const t = i / 95; let k = 1; while (k < STOPS.length - 1 && STOPS[k][0] < t) k++; const [t0, c0] = STOPS[k - 1], [t1, c1] = STOPS[k]; const f = (t - t0) / (t1 - t0 || 1);
  return `rgb(${c0.map((c, j) => Math.round(c + (c1[j] - c) * f)).join(',')})`; });
const clock = (ms) => new Date(ms).toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit', second: '2-digit' });
const money = (v) => (v >= 1e6 ? `$${fmtNum(v / 1e6, 2)}M` : v >= 1e3 ? `$${fmtNum(v / 1e3, 1)}K` : `$${fmtNum(v, 0)}`);

/** Real-time feed: WebSocket diff depth + aggTrade with a synced local book; REST polling when the socket is blocked. */
function createFeed(id, { onTrade, onState }) {
  if (venueOf(id) === 'hl') return createHlFeed(rawOf(id), { onTrade, onState });
  const fut = venueOf(id) === 'fut'; const symbol = rawOf(id);
  const fetchBook = fut ? fetchFutBook : fetchBinanceBook, fetchTrades = fut ? fetchFutTrades : fetchBinanceTrades;
  const book = new LocalBook(); let ws = null, closed = false, mode = 'connecting', poll = null, syncing = false, lastTradeId = 0, wsTimer = null;
  const s = symbol.toLowerCase();
  const setMode = (m) => { mode = m; onState?.(m); };
  async function resync() {
    if (syncing || closed) return; syncing = true;
    try { const snap = await fetchBook(symbol, 1000); if (!book.snapshot(snap)) { syncing = false; setTimeout(resync, 500); return; } } catch { /* try again on the next gap */ }
    syncing = false;
  }
  function rest() {
    if (closed || poll) return; try { ws?.close(); } catch { /* */ } setMode('rest');
    const tick = async () => {
      try { const snap = await fetchBook(symbol, 500); book.replace(snap); } catch { setMode('error'); return; }
      try { const tr = await fetchTrades(symbol, lastTradeId ? 500 : 100); for (const t of tr) if (t.id > lastTradeId) { lastTradeId = t.id; onTrade(t); } } catch { /* trades optional */ }
      if (mode !== 'rest') setMode('rest');
    };
    tick(); poll = setInterval(tick, 2000);
  }
  function wsStart() {
    if (typeof WebSocket === 'undefined') return rest();
    try { ws = new WebSocket(`${fut ? FUT_WS : marketConfig.binanceWsUrl}/stream?streams=${s}@depth@100ms/${s}@aggTrade`); } catch { return rest(); }
    wsTimer = setTimeout(() => { if (mode !== 'ws') rest(); }, 7000);
    ws.onopen = () => { resync(); };
    ws.onmessage = (ev) => {
      let m; try { m = JSON.parse(ev.data)?.data; } catch { return; } if (!m) return;
      if (m.e === 'depthUpdate') { if (book.apply(m) === false) resync(); else if (book.ready && mode !== 'ws') { clearTimeout(wsTimer); setMode('ws'); } }
      else if (m.e === 'aggTrade') onTrade({ id: m.a, price: +m.p, qty: +m.q, time: +m.T, buy: !m.m });
    };
    ws.onerror = () => { if (!closed && mode !== 'ws') rest(); };
    ws.onclose = () => { if (!closed && mode === 'ws') { setMode('connecting'); setTimeout(() => { if (!closed) { book.ready = false; wsStart(); } }, 2000); } };
  }
  wsStart();
  return { book, get mode() { return mode; }, close() { closed = true; clearInterval(poll); clearTimeout(wsTimer); try { ws?.close(); } catch { /* */ } } };
}

/** v279 Hyperliquid (trade.xyz indices / commodities): every l2Book message is a full top-20 snapshot; trades over the same socket. */
function createHlFeed(coin, { onTrade, onState }) {
  const book = new LocalBook(); let ws = null, closed = false, mode = 'connecting', poll = null, wsTimer = null, ping = null, lastTid = 0;
  const setMode = (m) => { mode = m; onState?.(m); };
  function rest() {
    if (closed || poll) return; try { ws?.close(); } catch { /* */ } clearInterval(ping); setMode('rest');
    const tick = async () => { try { book.replace(await fetchHlBook(coin)); if (mode !== 'rest') setMode('rest'); } catch { setMode('error'); } };
    tick(); poll = setInterval(tick, 2000);
  }
  function wsStart() {
    if (typeof WebSocket === 'undefined') return rest();
    try { ws = new WebSocket(HL_WS); } catch { return rest(); }
    wsTimer = setTimeout(() => { if (mode !== 'ws') rest(); }, 7000);
    ws.onopen = () => { for (const type of ['l2Book', 'trades']) ws.send(JSON.stringify({ method: 'subscribe', subscription: { type, coin } })); ping = setInterval(() => { try { ws.send('{"method":"ping"}'); } catch { /* */ } }, 45_000); };
    ws.onmessage = (ev) => {
      let m; try { m = JSON.parse(ev.data); } catch { return; }
      if (m?.channel === 'l2Book' && m.data?.coin === coin) { book.replace(hlToSnap(m.data)); if (mode !== 'ws') { clearTimeout(wsTimer); setMode('ws'); } }
      else if (m?.channel === 'trades' && Array.isArray(m.data)) for (const t of m.data) { if (t.coin !== coin) continue; const x = hlTrade(t); if (x.id && x.id <= lastTid) continue; lastTid = Math.max(lastTid, x.id); onTrade(x); }
    };
    ws.onerror = () => { if (!closed && mode !== 'ws') rest(); };
    ws.onclose = () => { clearInterval(ping); if (!closed && mode === 'ws') { setMode('connecting'); setTimeout(() => { if (!closed) wsStart(); }, 2000); } };
  }
  wsStart();
  return { book, get mode() { return mode; }, close() { closed = true; clearInterval(poll); clearInterval(ping); clearTimeout(wsTimer); try { ws?.close(); } catch { /* */ } } };
}

const GROUPS = [['crypto', ['عملات رقمية', 'Crypto']], ['metal', ['معادن', 'Metals']], ['energy', ['طاقة ونفط', 'Energy & oil']], ['index', ['مؤشرات', 'Indices']], ['stock', ['أسهم', 'Stocks']]];
const SRC = { spot: 'Binance Spot', fut: 'Binance Futures · TradFi', hl: 'Hyperliquid · trade.xyz' };
const label = (p) => { if (p.venue === 'spot' || !p.venue) return p.symbol; const n = tradfiName(p.base); const nm = n ? L(n[0], n[1]) : p.base; return `${nm} · ${p.symbol}`; };

export function renderLiquidity() {
  const root = h(`<section class="subpage tool cm rm lq page-enter">${pageHead('layers', L('خريطة السيولة الحية', 'Live liquidity map'), L('أوامر حقيقية من دفتر الأوامر عبر الزمن (Heatmap)، صفقات حقيقية كفقاعات، تتبّع الجدران، ورادار الحركات غير العادية. ولا رقم مقدّر بهالصفحة.', 'Real resting orders over time (heatmap), real trades as bubbles, wall tracking and an anomaly radar. Nothing on this page is estimated.'))}
    <nav class="rm-tabs"><button type="button" class="rm-tab is-on" data-tab="map">${icons.layers}<span>${L('الخريطة الحية', 'Live map')}</span></button><button type="button" class="rm-tab" data-tab="anom">${icons.radar}<span>${L('رادار الشذوذ', 'Anomaly radar')}</span></button><a class="rm-tab" href="#/app/council">${icons.brain}<span>${L('مجلس AI و X-Ray', 'AI council & X-Ray')}</span></a></nav>
    <div data-body></div></section>`);
  const body = root.querySelector('[data-body]');
  let stopMap = null;
  const tab = (id) => { root.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('is-on', b.dataset.tab === id)); stopMap?.(); stopMap = null; if (id === 'map') stopMap = mapView(body); else anomaly(body); };
  root.querySelector('.rm-tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) tab(b.dataset.tab); });
  onUnmount(root, () => stopMap?.());
  tab('map');
  return root;
}

/* ───────────────────────── live map ───────────────────────── */
function mapView(body) {
  const sym0 = CRYPTO.includes('BTCUSDT') ? 'BTCUSDT' : CRYPTO[0];
  body.innerHTML = `
    <div class="lq-bar card">
      <div class="lq-cls" data-cls role="tablist">${[['all', L('الكل', 'All')], ...GROUPS.map(([k, n]) => [k, L(n[0], n[1])])].map(([k, t], i) => `<button type="button" class="lq-ct${i ? '' : ' is-on'}" data-c="${k}">${esc(t)}</button>`).join('')}</div>
      <div class="lq-row">
        <span class="lq-pick">${icons.search || ''}<input type="search" data-q placeholder="${L('ابحث: عملة، ذهب، نفط، مؤشر…', 'Search: coin, gold, oil, index…')}" autocomplete="off" spellcheck="false" dir="ltr" aria-label="${L('ابحث عن سوق', 'Search market')}"><i></i><select data-sym aria-label="${L('العملة', 'Coin')}">${CRYPTO.map((s) => `<option${s === sym0 ? ' selected' : ''}>${s}</option>`).join('')}</select></span>
        <small class="lq-cnt" data-cnt></small>
        <span class="lq-src" data-src>…</span>
        <button type="button" class="lq-ibtn" data-pause title="${L('إيقاف مؤقت', 'Pause')}" aria-label="${L('إيقاف مؤقت', 'Pause')}"><svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg></button>
      </div>
      <div class="lq-row lq-row2">
        <span class="lq-layers">${[['heat', 'Heatmap'], ['bub', L('الصفقات', 'Trades')], ['walls', L('الجدران', 'Walls')], ['cvd', 'CVD']].map(([k, t]) => `<label class="lq-chip"><input type="checkbox" data-ly="${k}" checked><span>${esc(t)}</span></label>`).join('')}</span>
        <label class="lq-ctl"><span>${L('تكبير', 'Zoom')}</span><input type="range" min="0.25" max="3" step="0.05" value="0.8" data-zoom></label>
        <label class="lq-ctl"><span>${L('شدة', 'Intensity')}</span><input type="range" min="0.3" max="3" step="0.1" value="1" data-int></label>
        <label class="lq-ctl"><span>${L('خانة', 'Bin')}</span><select data-bps><option value="1">1bp</option><option value="2" selected>2bp</option><option value="5">5bp</option><option value="10">10bp</option></select></label>
      </div></div>
    <details class="card lq-howto"><summary>${icons.info} ${L('كيف تقرأ الخريطة؟ (دقيقة وحدة)', 'How to read the map (1 minute)')}</summary><ul>
      <li><b class="lq-k1">${L('الخطوط الأصفر/الأحمر/الأبيض', 'Yellow / red / white bands')}</b> — ${L('أوامر كبيرة قاعدة بالدفتر (جدران). كل ما الخط أقوى وأطول = أوامر أكبر وأثبت.', 'big resting orders (walls). Brighter and longer = bigger and more stable.')}</li>
      <li><b class="lq-k2">${L('الأزرق الغامق', 'Dark blue')}</b> — ${L('سيولة خفيفة، السعر بيمرق منها بسهولة.', 'thin liquidity — price moves through it easily.')}</li>
      <li><b class="up">${L('فقاعة خضرا', 'Green bubble')}</b> / <b class="down">${L('حمرا', 'red')}</b> — ${L('صفقات حقيقية: المشترين ضربوا بقوة / البائعين ضربوا بقوة. كبر الفقاعة = حجم الصفقات.', 'real trades: aggressive buyers / sellers. Size = traded volume.')}</li>
      <li>${L('السعر بينزل على جدار شراء أصفر، بتطلع فقاعات حمرا بس الجدار ما بيختفي = <b>امتصاص</b> (البائعين عم يخسروا قوتهم). إذا اختفى الجدار فجأة قبل ما يوصله السعر = <b>انسحب</b> (فخ).', 'Price falls onto a yellow bid wall, red bubbles hit it but it stays = <b>absorption</b>. If the wall vanishes before price reaches it = <b>pulled</b> (a trap).')}</li>
      <li>${L('العمود يمين (COB) = الدفتر الحالي: أحمر أوامر بيع فوق، أخضر أوامر شراء تحت.', 'Right column (COB) = the current book: red asks above, green bids below.')}</li></ul></details>
    <div class="lq-grid">
      <div class="lq-main card"><div class="lq-badge" data-badge><i class="lq-spin"></i>${L('عم نجمع بيانات…', 'Collecting…')}</div><canvas class="lq-heat" data-heat></canvas><canvas class="lq-cvd" data-cvd></canvas><div class="lq-tip" data-tip hidden></div></div>
      <aside class="lq-side">
        <div class="card lq-box"><h3>${icons.shield} ${L('ذكاء الجدران', 'Wall intelligence')}</h3><div class="rm-seg" data-wseg><button type="button" class="is-on" data-w="active">${L('نشطة', 'Active')}</button><button type="button" data-w="done">${L('انتهت', 'Ended')}</button></div><div data-walls class="lq-walls"></div></div>
        <div class="card lq-box"><h3>${icons.bars} ${L('دفتر الأوامر (DOM)', 'Order book (DOM)')}</h3><div data-dom class="lq-dom"></div></div>
      </aside>
    </div>
    <section class="lq-read" data-read></section>
    <div class="lq-stats" data-stats></div>
    <p class="mk-sub" data-srcnote></p><p class="mk-sub">${icons.info} ${L(' الأحجام المخفية (Iceberg) ما بتبيّن بأي دفتر أوامر — اللي بنعرضه هو "إعادة التعبئة" لما الجدار يرجع بعد ما ينضرب. الجدار ممكن ينسحب بأي لحظة؛ هاد مش توقع ولا نصيحة.', 'Hidden (iceberg) size is not visible in any order book — we show “refills” when a wall comes back after being hit. Walls can be pulled at any moment; this is not a forecast or advice.')}</p>`;
  const $ = (s) => body.querySelector(s);
  const S = { spreads: [], setups: new SetupTracker(), marks: [], lastState: null, read: null, sym: sym0, cols: [], cur: null, feed: null, walls: null, step: 0, paused: false, cvd: 0, depthSum: 0, depthN: 0, wtab: 'active', ly: new Set(['heat', 'bub', 'walls', 'cvd']), lastPx: null, lastAt: 0, view: null };
  const cv = $('[data-heat]'), cc = $('[data-cvd]');
  function start() {
    S.feed?.close(); S.spreads = []; S.setups = new SetupTracker(); S.marks = []; S.lastState = null; S.read = null; S.cols = []; S.cvd = 0; S.depthSum = 0; S.depthN = 0; S.step = 0; S.walls = new WallTracker({ mult: 4 }); S.cur = null; S.lastPx = null;
    $('[data-src]').textContent = L('عم نتصل…', 'Connecting…');
    const v = venueOf(S.sym);
    $('[data-srcnote]').innerHTML = `${icons.info} ${v === 'spot' ? L('المصدر: دفتر أوامر Binance Spot العام وصفقاته.', 'Source: Binance Spot public order book and trades.')
      : v === 'fut' ? L('المصدر: دفتر أوامر عقود Binance Futures الدائمة (TradFi) وصفقاتها — عقد بيتبع سعر الأصل، مش السوق النقدي نفسه. السوق بيسكّر حسب جدول الأصل (مثلاً نهاية الأسبوع).', 'Source: Binance Futures TradFi perpetual order book and trades — a contract that tracks the asset, not the cash market itself. It closes on the asset’s schedule (e.g. weekends).')
      : L('المصدر: دفتر أوامر Hyperliquid (سوق trade.xyz) العام وصفقاته — أعلى 20 مستوى بكل جهة فقط، فالخريطة أضيق. عقد دائم بيتبع المؤشر، مش المؤشر نفسه.', 'Source: Hyperliquid (trade.xyz market) public order book and trades — top 20 levels per side only, so the map is narrower. A perpetual that tracks the index, not the index itself.')}`;
    S.feed = createFeed(S.sym, {
      onTrade(t) { if (S.paused) return; S.lastPx = t.price; S.lastAt = t.time; const c = S.cur || (S.cur = { buy: 0, sell: 0, pv: 0, v: 0, big: [], lo: t.price, hi: t.price }); c.lo = Math.min(c.lo, t.price); c.hi = Math.max(c.hi, t.price); if (t.buy) c.buy += t.qty; else c.sell += t.qty; c.pv += t.price * t.qty; c.v += t.qty; if (c.big.length < 40) c.big.push(t); S.cvd += t.buy ? t.qty : -t.qty; S.walls.trade(t); },
      onState(m) { const map = { ws: [L('مباشر', 'Live'), '100ms', L('WebSocket — تحديث كل 100ms', 'WebSocket — 100 ms updates')], rest: [L('مباشر', 'Live'), '2s', L('تحديث كل ثانيتين (الـWebSocket محجوب)', '2 s polling (WebSocket blocked)')], connecting: [L('عم نتصل', 'Connecting'), '', ''], error: [L('غير متصل', 'Offline'), '', L('ما قدرنا نوصل لدفتر الأوامر', 'Could not reach the order book')] }; const [t, r, full] = map[m] || [m, '', '']; const el = $('[data-src]'); el.innerHTML = `<b></b>${esc(t)}${r ? `<em>${r}</em>` : ''}`; el.title = full ? `${SRC[venueOf(S.sym)]} · ${full}` : SRC[venueOf(S.sym)]; el.className = `lq-src is-${m}`; },
    });
  }
  function column() {
    if (S.paused || !S.feed?.book.ready && S.feed?.mode !== 'rest') return;
    const book = S.feed.book; const { bid, ask } = book.best(); if (bid == null || ask == null) return;
    const mid = (bid + ask) / 2; if (!S.step) S.step = niceStep(mid, +$('[data-bps]').value);
    const b = bucket(book, mid, S.step, 3); const now = Date.now(); const tr = S.cur || { buy: 0, sell: 0, pv: 0, v: 0, big: [] }; S.cur = null;
    const im = imbalance(book, mid, 0.5); S.depthSum += im.bid + im.ask; S.depthN++;
    S.cols.push({ t: now, mid, bid, ask, bins: b.bins, buy: tr.buy, sell: tr.sell, vwap: tr.v ? tr.pv / tr.v : null, px: S.lastPx ?? mid, cvd: S.cvd, big: tr.big });
    if (S.cols.length > MAXCOL) S.cols.shift();
    S.walls.update(b, mid, now);
    S.spreads.push(ask - bid); if (S.spreads.length > 600) S.spreads.shift(); const sm = [...S.spreads].sort((x, y) => x - y)[Math.floor(S.spreads.length / 2)];
    S.setups.price(Math.min(tr.lo ?? mid, bid), Math.max(tr.hi ?? mid, ask), now);
    const read = orderFlowRead({ mid, step: S.step, walls: S.walls.list(), cols: S.cols, im, spread: ask - bid, spreadMed: sm, live: ['ws', 'rest'].includes(S.feed.mode), now });
    if ((read.state === 'buy_setup' || read.state === 'sell_setup') && read.state !== S.lastState) { if (S.setups.add(read, mid, now)) S.marks.push({ t: now, dir: read.best.dir, px: mid }); }
    S.lastState = read.state; S.read = read;
    draw(); panels(book, mid, im); renderRead(mid);
  }
  function draw() {
    const dpr = window.devicePixelRatio || 1; const W = cv.clientWidth, H = cv.clientHeight; if (!W) return;
    cv.width = W * dpr; cv.height = H * dpr; const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.fillStyle = '#03060f'; g.fillRect(0, 0, W, H);
    const cols = S.cols; if (!cols.length) { g.fillStyle = '#7f93bd'; g.font = '14px system-ui'; g.fillText(L('عم نجمع البيانات الحية…', 'Collecting live data…'), 20, 32); return; }
    const mobile = W < 560; const cobW = mobile ? 52 : 92, axW = mobile ? 58 : 70; const plotW = W - cobW - axW; const volH = Math.round(H * 0.12); const PH = H - volH;
    const last = cols.at(-1); const zoom = +$('[data-zoom]').value / 100; const lo = last.mid * (1 - zoom), hi = last.mid * (1 + zoom);
    const y = (p) => (1 - (p - lo) / (hi - lo)) * PH;
    const n = Math.min(cols.length, Math.max(60, Math.floor(plotW / 2))); const vis = cols.slice(-n); const cw = plotW / Math.max(vis.length, 50); const x0 = plotW - vis.length * cw;
    S.view = { lo, hi, y, cw, x0, vis, padR: cobW + axW, W, H: PH };
    // colour reference = 96th percentile over all visible columns (stable colours)
    const sample = []; for (let i = 0; i < vis.length; i += Math.max(1, Math.floor(vis.length / 80))) for (const [p, v] of vis[i].bins) if (p >= lo && p <= hi) sample.push(Math.max(v.bid, v.ask));
    sample.sort((a2, b2) => a2 - b2); const med = (sample[Math.floor(sample.length * 0.5)] || 1) / +$('[data-int]').value; const LG = Math.log(25);   // median = normal liquidity (blue); ≥4× yellow, ≥12× red, ≥25× white
    const bh = Math.max(1.5, Math.abs(y(lo + S.step) - y(lo)));
    if (S.ly.has('heat')) {
      vis.forEach((c, i) => { const x = x0 + i * cw; for (const [p, v] of c.bins) { if (p < lo || p > hi + S.step) continue; const q = Math.max(v.bid, v.ask); if (!q) continue; const t = Math.max(0.07, Math.min(1, 0.25 + (0.75 * Math.log(q / med)) / LG)); g.fillStyle = LUT[Math.round(t * 95)]; g.fillRect(x, y(p + S.step), cw + 0.6, bh + 0.6); } });
    }
    // grid
    g.strokeStyle = 'rgba(120,150,210,.08)'; g.lineWidth = 1; for (let k = 1; k < 8; k++) { const yy = (PH * k) / 8; g.beginPath(); g.moveTo(0, yy); g.lineTo(plotW, yy); g.stroke(); }
    // price line
    g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 4; const line = () => { g.beginPath(); vis.forEach((c, i) => { const xx = x0 + i * cw + cw / 2; if (i) g.lineTo(xx, y(c.px)); else g.moveTo(xx, y(c.px)); }); g.stroke(); };
    line(); g.strokeStyle = '#c4b5fd'; g.lineWidth = 2; line();
    if (S.ly.has('bub')) {
      const vols = vis.map((c) => c.buy + c.sell).filter(Boolean).sort((a2, b2) => a2 - b2); const vref = vols[Math.floor(vols.length * 0.85)] || 1;
      vis.forEach((c, i) => { const v = c.buy + c.sell; if (!v || !c.vwap) return; const r = Math.min(26, 3 + 11 * Math.sqrt(v / vref)); if (v < vref * 0.35) return;
        const xx = x0 + i * cw + cw / 2, yy = y(c.vwap); const buy = c.buy >= c.sell; const gr = g.createRadialGradient(xx - r / 3, yy - r / 3, 1, xx, yy, r);
        gr.addColorStop(0, buy ? '#d9f99d' : '#fecdd3'); gr.addColorStop(0.55, buy ? '#22c55e' : '#e11d48'); gr.addColorStop(1, buy ? '#14532d' : '#7f1d1d');
        g.fillStyle = gr; g.beginPath(); g.arc(xx, yy, r, 0, Math.PI * 2); g.fill(); g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 1; g.stroke(); });
    }
    // setup markers + the open idea (entry / stop / target)
    g.font = 'bold 12px system-ui';
    for (const m of S.marks) { const i = vis.findIndex((c) => c.t >= m.t); if (i < 0) continue; const xx = x0 + i * cw + cw / 2, yy = y(m.px) + (m.dir > 0 ? 22 : -22);
      g.fillStyle = m.dir > 0 ? '#22c55e' : '#ef4444'; g.beginPath(); if (m.dir > 0) { g.moveTo(xx, yy - 9); g.lineTo(xx - 8, yy + 5); g.lineTo(xx + 8, yy + 5); } else { g.moveTo(xx, yy + 9); g.lineTo(xx - 8, yy - 5); g.lineTo(xx + 8, yy - 5); } g.closePath(); g.fill(); g.strokeStyle = '#000'; g.stroke(); }
    const open = S.setups.items.find((x) => !x.result);
    if (open) { const lines = [[open.target, '#22c55e', L('هدف', 'TARGET')], [open.entry, '#e2e8f0', L('دخول', 'ENTRY')], [open.stop, '#ef4444', L('وقف', 'STOP')]];
      for (const [p, col, t] of lines) { if (p < lo || p > hi) continue; const yy = y(p); g.strokeStyle = col; g.lineWidth = 1.5; g.setLineDash([6, 4]); g.beginPath(); g.moveTo(0, yy); g.lineTo(plotW, yy); g.stroke(); g.setLineDash([]);
        g.fillStyle = col; g.fillRect(4, yy - 9, 64, 18); g.fillStyle = '#03060f'; g.fillText(t, 9, yy + 4); } }
    if (S.ly.has('walls')) {
      g.font = '11px system-ui'; for (const w of S.walls.list().active.slice(0, 6)) { if (w.price < lo || w.price > hi) continue; const yy = y(w.price + w.step / 2); const col = w.side === 'ask' ? '#fb7185' : '#34d399';
        const t = `${w.side === 'ask' ? 'ASK' : 'BID'} ${money(w.size * w.price)}${w.refills ? ` ↻${w.refills}` : ''}`; const tw = g.measureText(t).width + 10; const lx = plotW - tw - 6;
        g.fillStyle = 'rgba(3,6,15,.85)'; g.fillRect(lx, yy - 9, tw, 18); g.strokeStyle = col; g.lineWidth = 1; g.strokeRect(lx, yy - 9, tw, 18); g.fillStyle = col; g.fillText(t, lx + 5, yy + 4); }
    }
    // volume bars (bottom)
    g.fillStyle = '#060b18'; g.fillRect(0, PH, plotW, volH); const vmax = Math.max(1e-9, ...vis.map((c) => c.buy + c.sell));
    vis.forEach((c, i) => { const x = x0 + i * cw; const hb = (c.buy / vmax) * (volH - 4), hs = (c.sell / vmax) * (volH - 4); g.fillStyle = '#16a34a'; g.fillRect(x, H - hb, Math.max(1, cw - 0.6), hb); g.fillStyle = '#dc2626'; g.fillRect(x, H - hb - hs, Math.max(1, cw - 0.6), hs); });
    // price axis
    const dig = last.mid > 1000 ? 1 : last.mid > 10 ? 2 : 4; g.fillStyle = '#0a1226'; g.fillRect(plotW, 0, axW, H); g.fillStyle = '#9fb2d8'; g.font = `${mobile ? 10 : 11}px ui-monospace, monospace`;
    for (let k = 0; k <= 8; k++) { const p = lo + ((hi - lo) * k) / 8; g.fillText(p.toFixed(dig), plotW + 4, y(p) + 4); }
    g.fillStyle = '#7c3aed'; g.fillRect(plotW, y(last.px) - 9, axW, 18); g.fillStyle = '#fff'; g.font = `bold ${mobile ? 10 : 11}px ui-monospace, monospace`; g.fillText(last.px.toFixed(dig), plotW + 4, y(last.px) + 4);
    // COB: the current book per bin (asks red above, bids green below)
    const cx = plotW + axW; g.fillStyle = '#050a17'; g.fillRect(cx, 0, cobW, H); let cmax = 1e-12; for (const [p, v] of last.bins) if (p >= lo && p <= hi) cmax = Math.max(cmax, v.bid, v.ask);
    for (const [p, v] of last.bins) { if (p < lo || p > hi) continue; const q = v.ask || v.bid; if (!q) continue; const wv = Math.max(1, (q / cmax) * (cobW - 4)); g.fillStyle = v.ask ? 'rgba(244,63,94,.85)' : 'rgba(34,197,94,.85)'; g.fillRect(cx + 2, y(p + S.step), wv, Math.max(1, bh - 0.5)); }
    g.fillStyle = '#9fb2d8'; g.font = '10px system-ui'; g.fillText('COB', cx + 4, 12);
    g.fillStyle = '#5b6f96'; g.font = '10.5px system-ui'; [0.02, 0.35, 0.68].forEach((f) => { const i = Math.floor(vis.length * f); if (vis[i]) g.fillText(clock(vis[i].t), x0 + i * cw + 2, PH - 4); });
    drawCvd(vis, x0, cw, cobW + axW);
  }
  function renderRead(mid) {
    const r = S.read; const el = $('[data-read]'); if (!r || !el) return; const dig = mid > 1000 ? 1 : mid > 10 ? 2 : 4;
    if (r.state === 'collecting') { const bd = $('[data-badge]'); if (bd) bd.innerHTML = `<i class="lq-spin"></i>${esc(L(`عم نجمع بيانات… ${r.need} ث`, `Collecting… ${r.need} s`))}`; el.innerHTML = `<div class="lq-verdict is-wait"><b><i class="lq-spin"></i>${L('عم نجمع بيانات حيّة…', 'Collecting live data…')}</b><span>${L(`لسا ${r.need} ثانية قبل أول قراءة`, `${r.need} s before the first read`)}</span></div>`; return; }
    const V = { buy_setup: ['is-buy', '✅', L('شروط الشراء متوفرة', 'Buy conditions are present')], sell_setup: ['is-sell', '🔻', L('شروط البيع متوفرة', 'Sell conditions are present')], wait: ['is-wait', '⏸', L('استنى — الشروط قرّبت بس مش كاملة', 'Wait — conditions are close but not complete')], no_trade: ['is-no', '⛔', L('لا تشتري ولا تبيع هلّق', 'Do not buy or sell now')] }[r.state];
    const b = r.best; const ck = (sd) => `<ul>${sd.checks.map((c) => `<li class="${c.ok ? 'ok' : 'no'}">${c.ok ? '✓' : '✗'} ${esc(tx(c))}</li>`).join('')}</ul>`;
    const plan = (r.state === 'buy_setup' || r.state === 'sell_setup' || r.state === 'wait') && b.stop ? `<div class="lq-plan"><div><small>${L('منطقة الدخول', 'Entry zone')}</small><b dir="ltr">${fmtNum(b.entry[0], dig)} – ${fmtNum(b.entry[1], dig)}</b></div><div><small>${L('الوقف (ورا الجدار)', 'Stop (beyond the wall)')}</small><b class="down">${fmtNum(b.stop, dig)}</b></div><div><small>${L('الهدف (قبل الجدار المعاكس)', 'Target (before the opposite wall)')}</small><b class="up">${fmtNum(b.target, dig)}</b></div><div><small>${L('عائد/مخاطرة', 'R:R')}</small><b>${b.rr ? b.rr.toFixed(2) : '—'}</b></div></div>` : '';
    const st = S.setups.stats();
    const bd = $('[data-badge]'); if (bd) { bd.className = `lq-badge ${V[0]}`; bd.innerHTML = `${V[1]} ${esc(V[2])}${plan && b.stop ? ` · <span dir="ltr">SL ${fmtNum(b.stop, dig)} · TP ${fmtNum(b.target, dig)}</span>` : ''} <a href="#" data-goread>${L('ليش؟', 'Why?')}</a>`; }
    el.innerHTML = `<div class="lq-verdict ${V[0]}"><b>${V[1]} ${esc(V[2])}</b><span>${r.blockers.length ? r.blockers.map((x) => esc(tx(x))).join(' · ') : r.state === 'no_trade' ? L('ما في جدار ثابت ومدافَع عنه مع هجوم بنفس الاتجاه — يعني ما في سبب واضح للدخول.', 'No stable, defended wall with aggression in the same direction — no clear reason to enter.') : r.state === 'wait' ? L(`${Math.max(r.long.n, r.short.n)} من 6 شروط — راقب الشرط الناقص.`, `${Math.max(r.long.n, r.short.n)} of 6 conditions — watch the missing one.`) : L('الشروط الستة (أو 5 منها مع الأساسية) تحققت. خطّتك: الدخول قريب من الجدار، الوقف وراه.', 'All core conditions met. Plan: enter near the wall, stop beyond it.')}</span></div>
      ${plan}
      <div class="lq-checks"><div><h4 class="up">${L('شروط الشراء', 'Buy conditions')} (${r.long.n}/6)</h4>${ck(r.long)}</div><div><h4 class="down">${L('شروط البيع', 'Sell conditions')} (${r.short.n}/6)</h4>${ck(r.short)}</div></div>
      <p class="lq-track">${icons.trophy} ${L('سجل هالجلسة (حقيقي، بيتابع السعر بعد كل إشارة)', 'This session’s record (real, follows price after each signal)')}: <b>${st.total}</b> ${L('إشارة', 'signals')} · <span class="up">${st.wins} ${L('وصلت الهدف', 'hit target')}</span> · <span class="down">${st.losses} ${L('ضربت الوقف', 'hit stop')}</span> · ${st.open} ${L('مفتوحة', 'open')}</p>
      <p class="mk-sub">${icons.info} ${L('هاي قراءة تعليمية لتدفق الأوامر من بيانات حقيقية — مش توصية ولا ضمان. الجدران بتنسحب، والسوق ممكن يعكس. التزم بالوقف وما تخاطر بأكتر من 1–2% من حسابك.', 'An educational order-flow read from real data — not a recommendation or a guarantee. Walls get pulled and markets reverse. Respect the stop and risk no more than 1–2 % of your account.')}</p>`;
  }
  function drawCvd(vis, x0, cw, padR) {
    const dpr = window.devicePixelRatio || 1; const W = cc.clientWidth, H = cc.clientHeight; cc.width = W * dpr; cc.height = H * dpr; const g = cc.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.fillStyle = '#070d1f'; g.fillRect(0, 0, W, H); if (!S.ly.has('cvd') || !vis.length) return;
    const vmax = Math.max(1e-9, ...vis.map((c) => c.buy + c.sell)); vis.forEach((c, i) => { const v = c.buy + c.sell; const hh = (v / vmax) * (H * 0.45); g.fillStyle = c.buy >= c.sell ? 'rgba(34,197,94,.55)' : 'rgba(239,68,68,.55)'; g.fillRect(x0 + i * cw, H - hh, Math.max(1, cw - 0.5), hh); });
    const lo = Math.min(...vis.map((c) => c.cvd)), hi = Math.max(...vis.map((c) => c.cvd)); const yy = (v) => 6 + (1 - (v - lo) / (hi - lo || 1)) * (H * 0.5);
    g.strokeStyle = '#22d3ee'; g.lineWidth = 1.3; g.beginPath(); vis.forEach((c, i) => { const xx = x0 + i * cw + cw / 2; if (i) g.lineTo(xx, yy(c.cvd)); else g.moveTo(xx, yy(c.cvd)); }); g.stroke();
    g.fillStyle = '#8ea3c9'; g.font = '10.5px system-ui'; g.fillText(`CVD ${fmtNum(vis.at(-1).cvd, 3)} · ${L('حجم الصفقات', 'trade volume')}`, 8, 13);
    g.fillStyle = 'rgba(5,10,25,.92)'; g.fillRect(W - padR, 0, padR, H);
  }
  function panels(book, mid, im) {
    const dig = mid > 1000 ? 1 : mid > 10 ? 2 : 4; const { bids, asks } = book.sorted(12); const mx = Math.max(...bids.map((x) => x[1]), ...asks.map((x) => x[1]), 1e-9);
    $('[data-dom]').innerHTML = `${asks.reverse().map(([p, q]) => `<div class="lq-lv is-ask"><i style="width:${(q / mx) * 100}%"></i><span>${p.toFixed(dig)}</span><b>${fmtNum(q, 4)}</b></div>`).join('')}
      <div class="lq-mid">${fmtNum(mid, dig)} <small>${L('السبريد', 'spread')} ${fmtNum(((asks.at(-1)?.[0] ?? mid) - (bids[0]?.[0] ?? mid)), dig + 1)}</small></div>
      ${bids.map(([p, q]) => `<div class="lq-lv is-bid"><i style="width:${(q / mx) * 100}%"></i><span>${p.toFixed(dig)}</span><b>${fmtNum(q, 4)}</b></div>`).join('')}`;
    const wl = S.walls.list(); const items = S.wtab === 'active' ? wl.active : wl.done;
    const st = { active: L('نشط', 'active'), broken: L('انكسر', 'broken'), pulled: L('انسحب', 'pulled'), filled: L('انضرب بالكامل', 'filled') };
    $('[data-walls]').innerHTML = items.slice(0, 10).map((w) => `<div class="lq-wall is-${w.side}"><div><b>${w.side === 'ask' ? L('جدار بيع', 'Ask wall') : L('جدار شراء', 'Bid wall')}</b> <span class="mono">${fmtNum(w.price, dig)}–${fmtNum(w.price + w.step, dig)}</span><em class="is-${w.status}">${st[w.status]}</em></div>
      <dl><dt>${L('الحجم', 'Size')}</dt><dd>${fmtNum(w.size, 3)} (${money(w.size * w.price)})</dd><dt>${L('أعلى حجم', 'Peak')}</dt><dd>${fmtNum(w.max, 3)}</dd><dt>${L('العمر', 'Age')}</dt><dd>${Math.round(((w.end || w.last) - w.first) / 1000)}s</dd>
      <dt>${L('إعادة تعبئة', 'Refills')}</dt><dd>${w.refills}</dd><dt>${L('امتصّ', 'Absorbed')}</dt><dd>${fmtNum(w.absorbed, 3)}</dd></dl></div>`).join('') || `<p class="mk-sub">${S.wtab === 'active' ? L('ما في جدران كبيرة قريبة هلّق (≥ 4× متوسط الحجم ضمن ±1%).', 'No large walls nearby now (≥ 4× median size within ±1 %).') : L('لسا ما انتهى ولا جدار بهالجلسة.', 'No wall has ended yet in this session.')}</p>`;
    const avg = S.depthSum / (S.depthN || 1); const ls = liquidityStrength(im.bid + im.ask, avg); const ab = S.walls.absorbed; const abT = ab.buy + ab.sell; const s2 = wl.stats; const ended = s2.broken + s2.pulled + s2.filled;
    const mins = Math.max(1, Math.round((Date.now() - (S.cols[0]?.t || Date.now())) / 60000));
    $('[data-stats]').innerHTML = `
      <div class="card lq-stat"><h4>${L('قوة السيولة', 'Liquidity strength')}</h4><div class="lq-gauge" style="--v:${ls ?? 0}"><b>${ls ?? '—'}</b><small>/100</small></div><small>${L('عمق ±0.5% مقارنة بمتوسط هالجلسة', 'depth ±0.5 % vs this session’s average')}</small></div>
      <div class="card lq-stat"><h4>${L('ميزان الدفتر ±0.5%', 'Book balance ±0.5 %')}</h4><div class="lq-split"><i style="width:${(im.bid / (im.bid + im.ask || 1)) * 100}%"></i></div><p><span class="up">${L('شراء', 'Bids')} ${money(im.bid)}</span> · <span class="down">${L('بيع', 'Asks')} ${money(im.ask)}</span></p></div>
      <div class="card lq-stat"><h4>${L('الامتصاص بالجدران', 'Absorption at walls')}</h4><p><span class="up">${L('شراء', 'Buy')} ${abT ? Math.round((ab.buy / abT) * 100) : 0}%</span> · <span class="down">${L('بيع', 'Sell')} ${abT ? Math.round((ab.sell / abT) * 100) : 0}%</span></p><small>${L('صفقات حقيقية انضربت بالجدران', 'real trades executed into walls')}</small></div>
      <div class="card lq-stat"><h4>${L('أحداث الجدران', 'Wall events')}</h4><p>${L('صمد', 'held')} ${s2.held} · ${L('انكسر', 'broken')} ${s2.broken} · ${L('انسحب', 'pulled')} ${s2.pulled} · ${L('انضرب', 'filled')} ${s2.filled}</p><small>${ended ? L(`من ${ended} جدار انتهى: ${Math.round((s2.broken / ended) * 100)}% انكسر`, `of ${ended} ended: ${Math.round((s2.broken / ended) * 100)}% broken`) : L('لسا ما في عيّنة كافية', 'no sample yet')} · ${mins} ${L('دقيقة', 'min')}</small></div>
      <div class="card lq-stat"><h4>${L('آخر تحديث', 'Last update')}</h4><p class="mono">${clock(Date.now())}</p><small>${L('آخر صفقة', 'last trade')} ${S.lastAt ? clock(S.lastAt) : '—'}</small></div>`;
  }
  // hover inspect
  cv.addEventListener('mousemove', (e) => {
    const v = S.view; if (!v) return; const r = cv.getBoundingClientRect(); const x = e.clientX - r.left, yy = e.clientY - r.top; const i = Math.floor((x - v.x0) / v.cw); const c = v.vis[i]; const tip = $('[data-tip]');
    if (!c || x > v.W - v.padR || yy > v.H) { tip.hidden = true; return; } const p = v.lo + (1 - yy / v.H) * (v.hi - v.lo); const k = Math.round(Math.floor(p / S.step + 1e-9) * S.step * 1e8) / 1e8; const bin = c.bins.get(k);
    tip.hidden = false; tip.style.left = `${Math.min(x + 12, v.W - 200)}px`; tip.style.top = `${yy + 12}px`;
    tip.innerHTML = `<b>${clock(c.t)}</b><br>${L('السعر', 'Price')} ${fmtNum(k, 2)}–${fmtNum(k + S.step, 2)}<br>${L('أوامر شراء', 'Bids')} ${fmtNum(bin?.bid || 0, 4)} · ${L('بيع', 'Asks')} ${fmtNum(bin?.ask || 0, 4)}<br>${L('صفقات', 'Trades')}: <span class="up">${fmtNum(c.buy, 4)}</span> / <span class="down">${fmtNum(c.sell, 4)}</span>`;
  });
  body.addEventListener('click', (e) => { if (e.target.closest('[data-goread]')) { e.preventDefault(); $('[data-read]').scrollIntoView({ behavior: 'smooth', block: 'start' }); } });
  cv.addEventListener('mouseleave', () => { $('[data-tip]').hidden = true; });
  $('[data-sym]').addEventListener('change', (e) => { if (!VALID_ID.test(e.target.value)) return; S.sym = e.target.value; S.auto = false; start(); });
  // v266: every Binance USDT pair (real public order book for each), most traded first; search filters the list.
  // v279: + metals / energy / indices / stocks with their own real order books (Binance TradFi perps, Hyperliquid trade.xyz).
  let ALL = CRYPTO.map((s) => ({ id: s, symbol: s, base: s.replace(/USDT$/, ''), cls: 'crypto', venue: 'spot', qv: 0 })); let TF = [];
  const ALIAS = { GOLD: ['XAU', 'GOLD'], ذهب: ['XAU', 'GOLD'], SILVER: ['XAG', 'SILVER'], فضة: ['XAG', 'SILVER'], OIL: ['CL', 'BZ'], نفط: ['CL', 'BZ'], NASDAQ: ['XYZ100'], ناسداك: ['XYZ100'], SPX: ['SP500'] };
  const fillSyms = () => {
    const q = $('[data-q]').value.trim().toUpperCase(); const sel = $('[data-sym]'); const all = [...TF, ...ALL];
    const al = ALIAS[q] || ALIAS[$('[data-q]').value.trim()] || [];
    const nm = (p) => { const n = tradfiName(p.base); return n ? `${n[0]} ${n[1]}`.toUpperCase() : ''; };
    const hit = all.filter((p) => (S.cls === 'all' || p.cls === S.cls) && (!q || p.base.toUpperCase().includes(q) || p.symbol.toUpperCase().includes(q) || nm(p).includes(q) || al.includes(p.base.toUpperCase()))).slice(0, 700);
    const cur = all.find((p) => p.id === S.sym) || { id: S.sym, symbol: rawOf(S.sym), base: rawOf(S.sym), cls: 'crypto', venue: venueOf(S.sym) };
    if (!hit.some((p) => p.id === S.sym) && (S.cls === 'all' || cur.cls === S.cls)) hit.unshift(cur);
    const opt = (p) => `<option value="${esc(p.id)}"${p.id === S.sym ? ' selected' : ''}>${esc(label(p))}</option>`;
    sel.innerHTML = GROUPS.map(([k, n]) => { const g = hit.filter((p) => p.cls === k); const top = k === 'index' ? 'hl' : 'fut'; if (k !== 'crypto') g.sort((x, y) => (y.venue === top) - (x.venue === top)); /* deeper book first: Binance futures for metals, energy, stocks; Hyperliquid for indices */ return g.length ? `<optgroup label="${esc(L(n[0], n[1]))}">${g.map(opt).join('')}</optgroup>` : ''; }).join('');
    const tot = S.cls === 'all' ? all.length : all.filter((p) => p.cls === S.cls).length;
    $('[data-cnt]').textContent = q ? `${hit.length}/${tot}` : `${tot}`; $('[data-cnt]').title = `${tot} ${L('سوق', 'markets')}`;
  };
  S.cls = 'all';
  $('[data-cls]').addEventListener('click', (e) => { const b = e.target.closest('[data-c]'); if (!b) return; S.cls = b.dataset.c; body.querySelectorAll('[data-c]').forEach((x) => x.classList.toggle('is-on', x === b)); fillSyms();
    const first = $('[data-sym]').options[0]?.value; const curCls = [...TF, ...ALL].find((p) => p.id === S.sym)?.cls; if (S.cls !== 'all' && curCls !== S.cls && first && first !== S.sym) { S.sym = first; S.auto = true; fillSyms(); start(); } });
  const addTF = (list) => { if (!body.isConnected || !list?.length) return; const seen = new Set(TF.map((p) => p.id)); TF = [...TF, ...list.filter((p) => !seen.has(p.id))]; fillSyms();
    const first = $('[data-sym]').options[0]?.value; if (S.cls !== 'all' && first && first !== S.sym && (S.auto || [...TF, ...ALL].find((p) => p.id === S.sym)?.cls !== S.cls)) { S.sym = first; S.auto = true; fillSyms(); start(); } };
  fetchTradfiFutures().then(addTF).catch(() => { /* futures blocked on this network: Hyperliquid still lists indices + commodities */ });
  fetchHlMarkets('xyz').then(addTF).catch(() => { /* */ });
  $('[data-q]').addEventListener('input', fillSyms);
  $('[data-q]').addEventListener('keydown', (e) => { if (e.key !== 'Enter') return; e.preventDefault(); const v = $('[data-sym]').options[0]?.value; const first = [...$('[data-sym]').options].find((o) => o.value !== S.sym || $('[data-sym]').options.length === 1)?.value || v; if (first && first !== S.sym) { S.sym = first; S.auto = false; fillSyms(); start(); } });
  fetchBinanceUsdtPairs().then((rows) => { if (!body.isConnected || !rows.length) return; const list = rows.map((p) => ({ ...p, id: p.symbol, cls: 'crypto', venue: 'spot' })); const seen = new Set(list.map((p) => p.symbol)); ALL = [...list, ...ALL.filter((p) => !seen.has(p.symbol))]; fillSyms(); }).catch(() => { fillSyms(); });
  $('[data-bps]').addEventListener('change', () => { S.step = 0; S.cols = []; S.walls = new WallTracker({ mult: 4 }); });
  ['[data-zoom]', '[data-int]'].forEach((s) => $(s).addEventListener('input', draw));
  body.querySelectorAll('[data-ly]').forEach((c) => c.addEventListener('change', () => { c.checked ? S.ly.add(c.dataset.ly) : S.ly.delete(c.dataset.ly); draw(); }));
  $('[data-pause]').addEventListener('click', (e) => { S.paused = !S.paused; const bt = e.currentTarget; bt.innerHTML = S.paused ? '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/></svg>' : '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>'; bt.title = S.paused ? L('كمّل', 'Resume') : L('إيقاف مؤقت', 'Pause'); bt.setAttribute('aria-label', bt.title); bt.classList.toggle('is-on', S.paused); });
  $('[data-wseg]').addEventListener('click', (e) => { const b = e.target.closest('[data-w]'); if (!b) return; S.wtab = b.dataset.w; body.querySelectorAll('[data-w]').forEach((x) => x.classList.toggle('is-on', x === b)); });
  start(); const timer = setInterval(column, 1000); const ro = new ResizeObserver(draw); ro.observe(cv);
  return () => { clearInterval(timer); ro.disconnect(); S.feed?.close(); };
}

/* ───────────────────────── anomaly radar ───────────────────────── */
const ANOM = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT', 'XAUUSD', 'XAGUSD', 'EURUSD', 'GBPUSD', 'USDJPY', 'US100', 'SPX500', 'US30', 'GER40', 'USOIL'];
async function anomaly(body) {
  body.innerHTML = `<div class="card rm-sec"><h2>${icons.radar} ${L('رادار الحركات غير العادية', 'Market anomaly radar')} <small class="muted">${L('آخر شمعة ساعة مسكّرة مقارنة بآخر 50 شمعة لنفس السوق', 'last closed 1h candle vs the previous 50 on the same market')}</small></h2>
    <div data-an><div class="perf-loading"><span class="spinner"></span></div></div>
    <p class="mk-sub">${icons.info} ${L('"غير عادي" يعني بعيد إحصائيًا عن سلوك السوق الأخير — مش معناه تلاعب ولا إشارة دخول. z = عدد الانحرافات المعيارية.', '“Unusual” means statistically far from recent behaviour — not manipulation and not an entry signal. z = standard deviations.')}</p></div>`;
  const rows = []; const sec = TIMEFRAMES.find((x) => x.id === '1h')?.seconds || 3600;
  const run = async (s) => { try { const r = await getHistory(s, '1h', 200); const c = r.candles.filter((k) => (k.time + sec) * 1000 <= Date.now()); const a = anomalyOf(c); if (a) rows.push({ s, mode: r.mode, ...a }); } catch { /* skip */ } };
  const q = [...ANOM]; await Promise.all([0, 1, 2].map(async () => { while (q.length) await run(q.shift()); }));
  rows.sort((a, b) => b.score - a.score);
  const why = (r) => ({ range: L('مدى الشمعة أكبر من العادة', 'candle range unusually large'), move: L('حركة السعر أكبر من العادة', 'price move unusually large'), volume: L('حجم تداول أعلى من العادة', 'volume unusually high'), gap: L('فجوة سعرية بين الشمعتين', 'price gap between candles'), accel: L('تسارع بآخر 5 شموع', 'acceleration over the last 5 candles') }[r.top]);
  const el = body.querySelector('[data-an]'); if (!el) return;
  el.innerHTML = rows.length ? `<div class="rm-table-wrap"><table class="rm-table"><thead><tr><th>${L('السوق', 'Market')}</th><th>${L('الشدة', 'Severity')}</th><th>${L('السبب الأبرز', 'Main reason')}</th><th>z ${L('المدى', 'range')}</th><th>z ${L('الحركة', 'move')}</th><th>z ${L('الحجم', 'volume')}</th><th>${L('فجوة', 'gap')}</th><th>${L('الشمعة', 'Candle')}</th></tr></thead><tbody>
    ${rows.map((r) => `<tr><td><b>${esc(getInstrument(r.s)?.base || r.s)}</b> <small class="muted">${esc(r.s)}${r.mode === 'demo' ? ` · ${L('تجريبي', 'demo')}` : ''}</small></td><td><span class="lq-sev" style="--v:${r.score}">${r.score}</span></td><td>${esc(why(r))}</td><td>${r.rangeZ}</td><td>${r.retZ}</td><td>${r.volZ ?? '—'}</td><td>${r.gap}</td><td>${clock(r.time * 1000)}</td></tr>`).join('')}</tbody></table></div>` : `<p class="mk-sub">${L('ما قدرنا نجيب بيانات.', 'Could not load data.')}</p>`;
  if (!rows.length) toast(L('ما في بيانات للرادار هلّق.', 'No data for the radar now.'), 'error');
}
