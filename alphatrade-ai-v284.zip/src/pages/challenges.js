// v281 Funded-trader challenges page: programs & prices, checkout, the trader's own dashboard (results, target left, today's
// loss, trade ticket, positions, history), rewards (payout requests) and the owner's panel. Everything is enforced by the server
// (server/challenges.js); this page only shows what the server returns. Accounts are simulated on real market prices.
import { h, esc } from '../utils/dom.js';
import { icons, logoMark } from '../components/icons.js';
import { tx } from '../i18n/tx.js';
import { getLang } from '../i18n/index.js';
import { toast } from '../components/ui.js';
import { apiRequest } from '../services/ai/gateway.js';
import { auth } from '../services/auth/index.js';
import { isAdmin } from '../config/admin.js';
import { PROGRAMS, SIZES, CH_SYMBOLS, CONTRACTS, MAX_LOTS, PAYOUT_METHODS, productId, programById } from '../config/challenges.js';
import { pageHead } from './community.js';
import { payMethodsHtml } from '../components/payMethods.js';
import { whileMounted } from './tools/common.js';
import '../styles/challenges.css';

const L = (ar, en) => tx({ ar, en });
const usd = (v, d = 0) => (v == null || !Number.isFinite(+v) ? '—' : `${v < 0 ? '−' : ''}$${Math.abs(+v).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d })}`);
const k = (n) => `$${n >= 1000 ? `${n / 1000}K` : n}`;
const dt = (t) => (t ? new Date(t).toLocaleString(getLang() === 'ar' ? 'ar' : 'en-GB', { dateStyle: 'medium', timeStyle: 'short' }) : '—');
const pxFmt = (sym, v) => (v == null ? '—' : (+v).toFixed(/JPY/.test(sym) ? 3 : CONTRACTS[sym]?.cls === 'fx' ? 5 : (+v) > 1000 ? 2 : 4));
let billingP = null;
const billingOn = () => (billingP ||= fetch('/api/billing/status').then((r) => (r.ok ? r.json() : null)).then((j) => Boolean(j?.configured)).catch(() => false));
let pricesP = null;   // owner price overrides (same as every plan)
const livePrices = () => (pricesP ||= fetch('/api/plans').then((r) => (r.ok ? r.json() : null)).then((j) => Object.fromEntries((j?.items || []).filter((x) => x.kind === 'challenge').map((x) => [x.id, x]))).catch(() => ({})));

const STATUS = { active: ['نشط', 'Active', 'ok'], passed: ['ناجح', 'Passed', 'ok'], failed: ['منتهي', 'Ended', 'bad'], review: ['قيد المراجعة', 'In review', 'warn'], funded: ['ممول', 'Funded', 'gold'] };
const REASON = { daily_loss: ['تجاوز حد الخسارة اليومي', 'Daily loss limit breached'], max_loss: ['تجاوز حد الخسارة الكلي', 'Max loss limit breached'], review_rejected: ['ما انقبل بالمراجعة', 'Not approved at review'], closed_by_owner: ['انسكّر من الإدارة', 'Closed by the owner'], refunded: ['انسكّر بعد استرجاع رسوم التحدي', 'Closed after the fee was refunded'] };
const ERR = {
  market_closed: ['السوق مسكّر هلّق أو ما في سعر لحظي لهالأداة.', 'Market closed or no real-time price for this instrument.'], margin: ['الهامش ما بيكفي لهالحجم. صغّر اللوت.', 'Not enough margin for this size. Lower the lots.'],
  bad_lots: ['حجم اللوت مش صحيح.', 'Invalid lot size.'], bad_sl: ['وقف الخسارة لازم يكون بالجهة الصح من السعر.', 'Stop loss must be on the right side of the price.'], bad_tp: ['الهدف لازم يكون بالجهة الصح من السعر.', 'Take profit must be on the right side of the price.'],
  bad_levels: ['قيم الوقف/الهدف مش صحيحة.', 'Invalid SL/TP values.'], account_closed: ['الحساب مش نشط.', 'This account is not active.'], payout_pending: ['في طلب سحب قيد المراجعة — التداول موقوف لحد ما يخلص.', 'A payout is pending — trading is paused until it is done.'],
  too_many_positions: ['وصلت الحد الأقصى للصفقات المفتوحة.', 'Too many open positions.'], rate_limited: ['كتير طلبات ورا بعض، استنى دقيقة.', 'Too many requests, wait a minute.'],
  too_early: ['لسا ما إجا موعد السحب.', 'Not time for a payout yet.'], min_days: ['لازم تكمّل أقل عدد أيام تداول قبل أول سحب.', 'Complete the minimum trading days before the first payout.'], no_profit: ['ما في ربح للسحب.', 'No profit to withdraw.'], close_positions: ['سكّر كل الصفقات أول.', 'Close all positions first.'],
  bad_kyc: ['عبّي الاسم الكامل والدولة ووافق على الشروط.', 'Fill in full name and country and accept the terms.'], bad_email: ['الإيميل مش صحيح.', 'Invalid e-mail.'], no_card_numbers: ['ما منقبل أرقام بطاقات. بس الإيميل.', 'We never take card numbers — e-mail only.'],
  bad_iban: ['رقم IBAN مش صحيح.', 'Invalid IBAN.'], bad_holder: ['اكتب اسم صاحب الحساب.', 'Enter the account holder name.'], bad_address: ['عنوان المحفظة مش صحيح للشبكة.', 'Wallet address does not match the network.'], bad_network: ['اختار الشبكة.', 'Choose a network.'],
  no_secret: ['الخدمة مش جاهزة على السيرفر.', 'Service not ready on the server.'], forbidden: ['مش مسموح.', 'Not allowed.'], not_found: ['مش موجود.', 'Not found.'], user_not_found: ['ما في عضو بهالإيميل.', 'No member with that e-mail.'], reference_required: ['اكتب رقم مرجع التحويل.', 'Enter the transfer reference.'],
};
const errText = (e) => L(...(ERR[e?.code] || ['صار خطأ، جرّب كمان مرة.', 'Something went wrong, try again.']));

export function renderChallenges() {
  const root = h(`<section class="subpage tool cm ch page-enter">${pageHead('trophy', L('تحديات التمويل', 'Funded trader challenges'), L('أثبت مهارتك على حساب تجريبي بأسعار السوق الحقيقية، وبعد ما تنجح بتصير متداول ممول وبتاخد حصتك من الأرباح.', 'Prove your skill on a demo account with real market prices; pass and become a funded trader with a share of the profits.'))}
    <nav class="rm-tabs ch-tabs" role="tablist">
      <button type="button" class="rm-tab is-on" data-tab="programs">${icons.trophy}<span>${L('البرامج والأسعار', 'Programs & prices')}</span></button>
      <button type="button" class="rm-tab" data-tab="accounts">${icons.grid || icons.layers}<span>${L('حساباتي', 'My accounts')}</span></button>
      <button type="button" class="rm-tab" data-tab="payouts">${icons.wallet}<span>${L('السحوبات', 'Payouts')}</span></button>
      ${isAdmin() ? `<button type="button" class="rm-tab" data-tab="admin">${icons.lock}<span>${L('إدارة التحديات', 'Challenges admin')}</span></button>` : ''}
    </nav>
    <div class="ch-body" data-body></div></section>`);
  const body = root.querySelector('[data-body]');
  const S = { tab: 'programs', prog: 'step2', size: 25000, acc: null, accounts: [], view: null, busy: false };
  const q = new URLSearchParams(location.hash.split('?')[1] || '');
  if (/^AT-[A-Z2-9]{8}$/.test(q.get('acc') || '')) { S.tab = 'accounts'; S.acc = q.get('acc'); }
  if (q.get('paid') === '1') { S.tab = 'accounts'; toast(L('تم الدفع ✅ حسابك بينفتح خلال لحظات بعد ما يأكّد Stripe الدفع.', 'Paid ✅ your account opens a moment after Stripe confirms.'), 'success', 9000); }
  const setTab = (t) => { S.tab = t; root.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('is-on', b.dataset.tab === t)); draw(); };
  root.querySelector('.ch-tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) setTab(b.dataset.tab); });

  function draw() {
    root.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('is-on', b.dataset.tab === S.tab));
    if (S.tab === 'programs') return drawPrograms();
    if (S.tab === 'accounts') return drawAccounts();
    if (S.tab === 'payouts') return drawPayouts();
    if (S.tab === 'admin') return drawAdmin();
  }

  /* ───────── programs & prices ───────── */
  // v284: store-style layout — program tabs, account-size cards, one detail card with a rules switch (challenge / funded),
  // a real coupon box, quantity and buy. A crossed-out price only ever appears for a coupon that really applies.
  const ORDER = ['step2', 'step1', 'flex', 'instant'];
  const SUB = { step2: ['مرحلتين', '2-Step'], step1: ['مرحلة وحدة', '1-Step'], flex: ['مرن', 'Flex'], instant: ['تمويل فوري', 'Instant'] };
  S.rtab = 'challenge'; S.qty = 1; S.coupon = null;   // { code, pct, final (per unit, $), product }
  const info = (t) => `<i class="ch-i" tabindex="0" role="img" aria-label="${esc(t)}" data-tip="${esc(t)}">i</i>`;
  async function drawPrograms() {
    const over = await livePrices(); const price = (pp, size) => over[productId(pp.id, size)]?.price ?? pp.prices[size];
    const p = programById(S.prog); const ph = p.phases; const pid = productId(p.id, S.size);
    const cp = S.coupon && S.coupon.product === pid ? S.coupon : null; const unit = cp ? cp.final : price(p, S.size);
    const pctOf = (x) => usd(S.size * x / 100);
    const row = (lab, val, tip) => `<li><span>${info(tip)}${esc(lab)}</span><b>${esc(val)}</b></li>`;
    const chRows = ph.length ? [
      ...ph.map((x, i) => row(ph.length > 1 ? L(`هدف ربح المرحلة ${i + 1}`, `Phase ${i + 1} profit target`) : L('هدف الربح', 'Profit target'), `${x.target}%`, L(`لازم الرصيد المسكّر يوصل ${pctOf(x.target)} ربح.`, `Closed balance must reach ${pctOf(x.target)} profit.`))),
      row(L('حد الخسارة اليومي', 'Daily loss limit'), p.daily == null ? L('بدون', 'None') : `${p.daily}%`, p.daily == null ? L('ما في حد يومي.', 'No daily limit.') : L(`ما بتخسر أكتر من ${pctOf(p.daily)} باليوم (من أعلى رصيد/إكويتي الساعة 00:00 UTC).`, `No more than ${pctOf(p.daily)} lost in a day (from the higher of balance/equity at 00:00 UTC).`)),
      row(L('حد الخسارة الكلي', 'Maximum loss limit'), `${p.maxLoss}%`, L(`الإكويتي لازم يضل فوق ${usd(S.size - S.size * p.maxLoss / 100)}.`, `Equity must stay above ${usd(S.size - S.size * p.maxLoss / 100)}.`)),
      row(L('نوع السحب (Drawdown)', 'Drawdown type'), L('ثابت', 'Static'), L('حد الخسارة محسوب من رصيد البداية وما بيلحق الربح.', 'The loss limit is fixed from the starting balance; it does not trail profits.')),
      row(L('أقل عدد أيام تداول', 'Minimum trading days'), L(`${p.minDays} أيام`, `${p.minDays} days`), L('لكل مرحلة — يوم التداول = يوم فتحت فيه صفقة.', 'Per phase — a trading day is a day you opened a trade.')),
      row(L('مدة التحدي', 'Time limit'), L('بدون حد', 'Unlimited'), L('خذ وقتك.', 'Take your time.')),
      row(L('التداول وقت الأخبار', 'News trading'), L('مسموح', 'Allowed'), L('مسموح، بس الأسعار بتتحرك بسرعة والتنفيذ على سعر السوق.', 'Allowed; prices move fast and fills are at market.')),
      row(L('الاحتفاظ بنهاية الأسبوع', 'Weekend holding'), L('مسموح', 'Allowed'), L('الصفقة بتضل مفتوحة، والفجوة بتتسكّر على أول سعر.', 'Positions stay open; gaps fill at the first price.')),
    ] : [
      row(L('التحدي', 'Challenge'), L('ما في — ممول فوراً', 'None — funded now'), L('الحساب بيكون ممول من أول يوم.', 'The account is funded from day one.')),
      row(L('هدف الربح', 'Profit target'), L('بدون', 'None'), L('ما في هدف لازم توصله.', 'There is no target to reach.')),
      row(L('حد الخسارة الكلي', 'Maximum loss limit'), `${p.maxLoss}%`, L(`القاعدة الوحيدة: الإكويتي فوق ${usd(S.size - S.size * p.maxLoss / 100)}.`, `The only rule: equity above ${usd(S.size - S.size * p.maxLoss / 100)}.`)),
      row(L('حد الخسارة اليومي', 'Daily loss limit'), L('بدون', 'None'), L('ما في حد يومي.', 'No daily limit.')),
      row(L('نوع السحب (Drawdown)', 'Drawdown type'), L('ثابت', 'Static'), L('من رصيد البداية.', 'From the starting balance.')),
      row(L('التداول وقت الأخبار', 'News trading'), L('مسموح', 'Allowed'), ''),
    ];
    const fnRows = [
      row(L('حصة الأرباح', 'Profit split'), L(`حتى ${p.split}%`, `Up to ${p.split}%`), L('نسبتك من ربح الحساب الممول.', 'Your share of the funded account profit.')),
      row(L('موعد السحب', 'Payout frequency'), L(`كل ${p.payoutDays} يوم`, `Every ${p.payoutDays} days`), L('بدون صفقات مفتوحة وقت الطلب.', 'With no open positions at request time.')),
      ...(ph.length ? [] : [row(L('أقل أيام قبل أول سحب', 'Min days before first payout'), L(`${p.minDays} أيام`, `${p.minDays} days`), '')]),
      row(L('حد الخسارة اليومي', 'Daily loss limit'), p.daily == null ? L('بدون', 'None') : `${p.daily}%`, L('نفس قواعد التحدي على الحساب الممول.', 'Same rules as the challenge on the funded account.')),
      row(L('حد الخسارة الكلي', 'Maximum loss limit'), `${p.maxLoss}%`, ''),
      row(L('الرافعة', 'Leverage'), `1:${p.leverage.fx}`, L(`فوركس وذهب 1:${p.leverage.fx} · مؤشرات 1:${p.leverage.index} · كريبتو 1:${p.leverage.crypto}`, `FX & gold 1:${p.leverage.fx} · indices 1:${p.leverage.index} · crypto 1:${p.leverage.crypto}`)),
      row(L('طرق السحب', 'Payout methods'), 'PayPal · Visa · IBAN · USDT', L('البطاقة عبر المزوّد — ما منطلب رقم بطاقة.', 'Card via the provider — we never ask for a card number.')),
      row(L('التحقق من الهوية', 'Identity check'), ph.length ? L('قبل التمويل', 'Before funding') : L('بأول سحب', 'At first payout'), ''),
    ];
    requestAnimationFrame(() => { const on = body.querySelector('.ch-sz.is-on'); const bar = body.querySelector('.ch-sizes2'); if (!on || !bar) return; const o = on.getBoundingClientRect(), r = bar.getBoundingClientRect(); if (o.left < r.left || o.right > r.right) bar.scrollBy({ left: o.left < r.left ? o.left - r.left - 8 : o.right - r.right + 8 }); });
    body.innerHTML = `
      <div class="ch-prog" role="tablist">${ORDER.map((id) => { const x = programById(id); return `<button type="button" class="ch-pbtn${id === S.prog ? ' is-on' : ''}" data-prog="${id}" role="tab" aria-selected="${id === S.prog}"><small>Alpha</small><b>${esc(L(...SUB[id]))}</b>${x.popular ? `<em>${L('الأكثر طلباً', 'Popular')}</em>` : ''}</button>`; }).join('')}</div>
      <div class="ch-sizes2" role="radiogroup" aria-label="${esc(L('حجم الحساب', 'Account size'))}">${SIZES.map((sz) => { const pr = price(p, sz); const c = S.coupon && S.coupon.product === productId(p.id, sz) ? S.coupon : null; return `<button type="button" role="radio" aria-checked="${sz === S.size}" class="ch-sz${sz === S.size ? ' is-on' : ''}" data-size="${sz}">${c ? `<em>${c.pct}% ${L('خصم', 'OFF')}</em>` : ''}<small>${L('حساب', 'Account')}</small><b>${k(sz)}</b><span>${usd(c ? c.final : pr, 2)}</span>${c ? `<s>${usd(pr, 2)}</s>` : ''}</button>`; }).join('')}</div>
      <article class="card ch-detail">
        <div class="ch-dh"><div><h2>Alpha ${esc(L(...SUB[p.id]))} · <bdi>${k(S.size)}</bdi></h2><div class="ch-big"><b>${usd(unit, 2)}</b>${cp ? `<s>${usd(price(p, S.size), 2)}</s>` : ''}</div></div>
          <span class="plan-logo is-premium" aria-hidden="true"><i class="plan-logo-ring"></i>${logoMark(30)}<i class="plan-logo-sheen"></i></span></div>
        <form class="ch-coupon" data-cpn>${cp ? `<span class="ch-cp-on">${L(`وفّرت ${cp.pct}% بالكود`, `Saving ${cp.pct}% with code`)} <b>${esc(cp.code)}</b></span><button type="button" class="ch-cp-x" data-cpx aria-label="${esc(L('شيل الكود', 'Remove code'))}">×</button>`
          : `<input class="input" name="code" maxlength="24" autocomplete="off" spellcheck="false" placeholder="${esc(L('عندك كود خصم؟', 'Have a discount code?'))}"><button type="submit" class="btn btn-sm">${L('طبّق', 'Apply')}</button>`}</form>
        <div class="ch-rtabs" role="tablist"><button type="button" class="${S.rtab === 'challenge' ? 'is-on' : ''}" data-rtab="challenge" role="tab">${ph.length ? L('قواعد التحدي', 'Challenge rules') : L('قواعد الحساب', 'Account rules')}</button><button type="button" class="${S.rtab === 'funded' ? 'is-on' : ''}" data-rtab="funded" role="tab">${L('قواعد التمويل والمكافآت', 'Funded & reward rules')}</button></div>
        <ul class="ch-rlist">${(S.rtab === 'funded' ? fnRows : chRows).join('')}</ul>
        <div class="ch-cta">
          <div class="ch-qty" role="group" aria-label="${esc(L('العدد', 'Quantity'))}"><button type="button" data-qty="-1" aria-label="−" ${S.qty <= 1 ? 'disabled' : ''}>−</button><b aria-live="polite">${S.qty}</b><button type="button" data-qty="1" aria-label="+" ${S.qty >= 5 ? 'disabled' : ''}>+</button></div>
          <div class="ch-total"><small>${L('المجموع', 'Total')}</small><b>${usd(unit * S.qty, 2)}</b></div>
        </div>
        <button type="button" class="btn btn-primary ch-start" data-buy="${pid}">${ph.length ? L('ابدأ التحدي', 'Start challenge') : L('افتح الحساب', 'Get funded')}</button>
        ${payMethodsHtml()}
        <small class="ch-fine">${L('بالشراء بتوافق على', 'By buying you accept the')} <a href="#/app/legal/challenges">${L('شروط التحديات', 'challenge terms')}</a>. ${L('دفع مرة وحدة وآمن عبر Stripe. الطرق اللي بتطلع حسب بلدك وحسب المفعّل عند صاحب الموقع.', 'One-time secure payment by Stripe. Methods shown depend on your country and what the owner switched on.')}</small>
      </article>
      <div class="ch-main2">
        <aside class="card ch-how"><h3>${L('كيف بتشتغل؟', 'How it works')}</h3><ol>
          ${ph.length ? `<li><b>${L('اشتري التحدي', 'Buy a challenge')}</b><span>${L('بتختار البرنامج والحجم وبتدفع مرة وحدة.', 'Choose program and size, pay once.')}</span></li>
          <li><b>${L('تداول وحقق الهدف', 'Trade to the target')}</b><span>${L('على حساب تجريبي بأسعار حقيقية، بدون ما تكسر حدود الخسارة.', 'On a demo account with real prices, without breaking the loss limits.')}</span></li>
          <li><b>${L('مراجعة وتمويل', 'Review & funding')}</b><span>${L('بعد آخر مرحلة بنراجع الصفقات وبنتحقق من هويتك، وبينفتحلك الحساب الممول.', 'After the last phase we review trades and verify identity, then open your funded account.')}</span></li>`
          : `<li><b>${L('اشتري الحساب', 'Buy the account')}</b><span>${L('بتختار الحجم وبتدفع مرة وحدة، وبينفتحلك حساب ممول فوراً.', 'Choose the size, pay once, and a funded account opens right away.')}</span></li>
          <li><b>${L('تداول بدون هدف', 'Trade with no target')}</b><span>${L(`القاعدة الوحيدة: الإكويتي ما ينزل أكتر من ${p.maxLoss}% تحت رصيد البداية.`, `The only rule: equity must not fall more than ${p.maxLoss}% below the start.`)}</span></li>
          <li><b>${L('تحقق الهوية', 'Identity check')}</b><span>${L(`بعد ${p.minDays} أيام تداول وبأول طلب سحب، بنتحقق من هويتك وبنراجع الصفقات.`, `After ${p.minDays} trading days, at your first payout, we check identity and review trades.`)}</span></li>`}
          <li><b>${L('اسحب أرباحك', 'Get paid')}</b><span>${L(`بتاخد ${p.split}% من الربح كل ${p.payoutDays} يوم: PayPal، بطاقة، بنك أو USDT.`, `Take ${p.split}% of profit every ${p.payoutDays} days: PayPal, card, bank or USDT.`)}</span></li></ol></aside>
        <div class="card ch-compare"><h3>${L(`قارن البرامج — حساب ${k(S.size)}`, `Compare programs — ${k(S.size)} account`)}</h3><div class="ch-tbl-wrap"><table class="ch-tbl">
          <thead><tr><th></th>${ORDER.map((id) => `<th>${esc(L(...SUB[id]))}</th>`).join('')}</tr></thead><tbody>
          <tr><td>${L('السعر', 'Price')}</td>${ORDER.map((id) => `<td><b>${usd(price(programById(id), S.size))}</b></td>`).join('')}</tr>
          <tr><td>${L('الأهداف', 'Targets')}</td>${ORDER.map((id) => `<td>${programById(id).phases.map((y) => `${y.target}%`).join(' / ') || '—'}</td>`).join('')}</tr>
          <tr><td>${L('الخسارة اليومية', 'Daily loss')}</td>${ORDER.map((id) => `<td>${programById(id).daily == null ? '—' : `${programById(id).daily}%`}</td>`).join('')}</tr>
          <tr><td>${L('الخسارة الكلية', 'Max loss')}</td>${ORDER.map((id) => `<td>${programById(id).maxLoss}%</td>`).join('')}</tr>
          <tr><td>${L('حصة الأرباح', 'Profit share')}</td>${ORDER.map((id) => `<td>${programById(id).split}%</td>`).join('')}</tr>
        </tbody></table></div></div>
      </div>
      <p class="mk-sub ch-disc">${icons.info} ${L('حسابات التحدي والحسابات الممولة حسابات تجريبية (محاكاة) على أسعار سوق حقيقية — ما في تداول بفلوس حقيقية بالسوق. المكافآت بتندفع من الشركة حسب الشروط. رسوم التحدي مش استثمار، وأغلب المتداولين ما بينجحوا. الأداء السابق ما بيضمن نتائج.', 'Challenge and funded accounts are simulated (demo) accounts on real market prices — no real-money trading in the market. Rewards are paid by the company under the terms. The fee is not an investment and most traders do not pass. Past performance does not guarantee results.')}</p>`;
  }

  /* ───────── my accounts / dashboard ───────── */
  async function loadAccounts() { try { S.accounts = (await apiRequest('GET', '/api/challenges')).items || []; } catch (e) { S.accounts = []; if (e?.code !== 'unauthorized') toast(errText(e), 'error'); } }
  async function loadView() { if (!S.acc) { S.view = null; return; } try { S.view = (await apiRequest('GET', `/api/challenges/${S.acc}`)).account; } catch (e) { S.view = null; toast(errText(e), 'error'); } }
  const chip = (st) => { const s = STATUS[st] || [st, st, '']; return `<em class="ch-st is-${s[2]}">${esc(L(s[0], s[1]))}</em>`; };
  const phaseName = (a) => (a.phase === 'funded' ? L('ممول', 'Funded') : L(`المرحلة ${a.phase}`, `Phase ${a.phase}`));
  async function drawAccounts() {
    if (!auth.current()) { body.innerHTML = `<div class="card ch-empty">${L('سجّل دخول عشان تشوف حساباتك.', 'Sign in to see your accounts.')}</div>`; return; }
    body.innerHTML = `<div class="ch-loading">${L('عم نجيب حساباتك…', 'Loading your accounts…')}</div>`;
    await loadAccounts();
    if (!S.accounts.length) { body.innerHTML = `<div class="card ch-empty"><span class="plan-logo is-premium" aria-hidden="true"><i class="plan-logo-ring"></i>${logoMark(30)}<i class="plan-logo-sheen"></i></span><h3>${L('ما عندك حسابات لسا', 'No accounts yet')}</h3><p class="muted">${L('اختار برنامج وابدأ تحديك الأول.', 'Pick a program and start your first challenge.')}</p><button type="button" class="btn btn-primary" data-go="programs">${L('شوف البرامج', 'See programs')}</button></div>`; return; }
    if (!S.accounts.some((a) => a.id === S.acc)) S.acc = (S.accounts.find((a) => a.status === 'active' || a.status === 'funded') || S.accounts[0]).id;
    await loadView(); paintAccounts();
  }
  function paintAccounts() {
    const v = S.view; const list = S.accounts;
    body.innerHTML = `<div class="ch-acclist" role="tablist">${list.map((a) => `<button type="button" class="ch-accbtn${a.id === S.acc ? ' is-on' : ''}" data-acc="${a.id}"><span class="mono">${a.id}</span><b>${esc(programById(a.program)?.short || a.program)} · ${k(a.size)}</b><small>${esc(phaseName(a))}</small>${chip(a.status)}</button>`).join('')}</div>
      <div data-dash>${v ? dashHtml(v) : ''}</div>`;
    if (v) wireDash();
  }
  function bar(pct, cls) { return `<i class="ch-bar ${cls}"><i style="width:${Math.max(0, Math.min(100, pct || 0)).toFixed(1)}%"></i></i>`; }
  function chart(v) {
    const pts = v.snaps; if (pts.length < 2) return `<div class="ch-chart-empty muted">${L('المنحنى بيبيّن بعد أول صفقات.', 'The curve appears after your first trades.')}</div>`;
    const W = 640, H = 180, P = 8; const lines = [v.rules.floor, v.size, v.rules.target != null ? v.size + v.rules.target : null].filter((x) => x != null);
    const ys = [...pts.map((p) => p.e), ...lines]; const lo = Math.min(...ys), hi = Math.max(...ys); const t0 = pts[0].t, t1 = pts[pts.length - 1].t || t0 + 1;
    const X = (t) => P + ((t - t0) / Math.max(1, t1 - t0)) * (W - 2 * P); const Y = (y) => H - P - ((y - lo) / Math.max(1e-9, hi - lo)) * (H - 2 * P);
    const path = pts.map((p, i) => `${i ? 'L' : 'M'}${X(p.t).toFixed(1)},${Y(p.e).toFixed(1)}`).join('');
    const hl = (y, cls, lab) => `<line x1="${P}" x2="${W - P}" y1="${Y(y).toFixed(1)}" y2="${Y(y).toFixed(1)}" class="${cls}"/><text x="${W - P - 4}" y="${(Y(y) - 4).toFixed(1)}" text-anchor="end" class="${cls}-t">${esc(lab)}</text>`;
    return `<svg class="ch-chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="${esc(L('منحنى الرصيد', 'Equity curve'))}">
      ${hl(v.rules.floor, 'ch-l-bad', L('حد الخسارة', 'Max loss'))}${hl(v.size, 'ch-l-mid', L('البداية', 'Start'))}${v.rules.target != null ? hl(v.size + v.rules.target, 'ch-l-ok', L('الهدف', 'Target')) : ''}
      <path d="${path}L${X(t1).toFixed(1)},${H - P}L${P},${H - P}Z" class="ch-area"/><path d="${path}" class="ch-line"/></svg>`;
  }
  function dashHtml(v) {
    const r = v.rules, g = v.progress; const closed = v.status !== 'active' && v.status !== 'funded';
    const kpi = (lab, val, sub, cls = '') => `<div class="ch-kpi ${cls}"><small>${esc(lab)}</small><b>${val}</b>${sub ? `<span>${sub}</span>` : ''}</div>`;
    const symOpts = CH_SYMBOLS.map((s) => `<option value="${s}">${s}</option>`).join('');
    const fundedBox = v.funded ? `<div class="card ch-funded"><span class="plan-logo is-premium" aria-hidden="true"><i class="plan-logo-ring"></i>${logoMark(30)}<i class="plan-logo-sheen"></i></span>
      <h3>${L('مكافأتك', 'Your reward')}</h3><div class="ch-reward"><b>${usd(v.funded.reward, 2)}</b><small>${L(`${r.split}% من ربح ${usd(Math.max(0, v.profit), 2)}`, `${r.split}% of ${usd(Math.max(0, v.profit), 2)} profit`)}</small></div>
      <p class="muted">${v.funded.payoutPending ? L('طلب السحب قيد المراجعة. التداول موقوف لحد ما يخلص.', 'Your payout is in review. Trading is paused until it is done.') : L(`موعد السحب الجاي: ${dt(v.funded.nextPayoutAt)}`, `Next payout: ${dt(v.funded.nextPayoutAt)}`)} · ${L('انسحب لهلأ', 'Paid so far')}: <b>${usd(v.funded.paidTotal, 2)}</b></p>
      ${v.funded.canRequest ? payoutForm() : `<small class="muted">${(v.funded.minDays ? L(`لازم يكون في ربح، وما في صفقات مفتوحة، ويكون إجا موعد السحب، و${v.funded.minDays} أيام تداول على الأقل.`, `You need profit, no open positions, the payout date reached, and at least ${v.funded.minDays} trading days.`) : L('لازم يكون في ربح، وما في صفقات مفتوحة، ويكون إجا موعد السحب.', 'You need profit, no open positions, and the payout date reached.'))}</small>`}</div>` : '';
    return `
      <div class="card ch-head"><div><span class="mono ch-id">${v.id}</span><h2>${esc(tx(v.programName))} · ${usd(v.size)}</h2><small class="muted">${esc(phaseName(v))}${v.phases > 1 && v.phase !== 'funded' ? ` / ${v.phases}` : ''} · ${L('انفتح', 'Opened')} ${dt(v.createdAt)}</small></div>${chip(v.status)}</div>
      ${v.status === 'failed' ? `<div class="ch-note is-bad">${icons.info} ${L('انتهى الحساب', 'Account ended')}: ${esc(L(...(REASON[v.failReason] || [v.failReason || '', v.failReason || ''])))} — ${L('بتقدر تبلّش تحدي جديد بأي وقت.', 'You can start a new challenge any time.')} <button type="button" class="btn btn-sm" data-go="programs">${L('تحدي جديد', 'New challenge')}</button></div>` : ''}
      ${v.status === 'passed' && v.next ? `<div class="ch-note is-ok">🎉 ${L('نجحت بهالمرحلة! حساب المرحلة الجاية جاهز', 'Phase passed! Your next account is ready')}: <button type="button" class="btn btn-sm btn-primary" data-acc="${v.next}">${v.next}</button></div>` : ''}
      ${v.status === 'review' ? `<div class="ch-note is-warn">🏁 ${L('خلصت كل المراحل! الإدارة عم تراجع الصفقات وتتحقق من الهوية قبل ما ينفتح الحساب الممول.', 'All phases done! The team is reviewing trades and identity before opening your funded account.')}</div>` : ''}
      <div class="ch-kpis">
        ${kpi(L('الرصيد', 'Balance'), usd(v.balance, 2))}
        ${kpi(L('الإكويتي', 'Equity'), usd(v.equity, 2), v.floating ? `${L('عائم', 'Floating')} ${usd(v.floating, 2)}` : '', v.floating < 0 ? 'is-bad' : v.floating > 0 ? 'is-ok' : '')}
        ${kpi(L('الربح', 'Profit'), usd(v.profit, 2), `${((v.profit / v.size) * 100).toFixed(2)}%`, v.profit < 0 ? 'is-bad' : v.profit > 0 ? 'is-ok' : '')}
        ${kpi(L('أيام التداول', 'Trading days'), `<span dir="ltr">${g.days}${v.phase !== 'funded' || v.funded?.minDays ? ` / ${r.minDays}` : ''}</span>`)}
      </div>
      <div class="ch-goals">
        ${r.target != null ? `<div class="card ch-goal"><div class="ch-gh"><b>${L('هدف الربح', 'Profit target')}</b><span>${usd(Math.max(0, v.profit), 2)} / ${usd(r.target)}</span></div>${bar(g.targetPct, 'is-ok')}<small>${g.targetPct >= 100 ? (g.days < r.minDays ? L(`الهدف تحقق ✅ ضايلك ${r.minDays - g.days} يوم تداول`, `Target hit ✅ ${r.minDays - g.days} more trading day(s)`) : L('الهدف تحقق ✅ سكّر صفقاتك لتنجح', 'Target hit ✅ close positions to pass')) : L(`ضايلك ${usd(r.target - Math.max(0, v.profit), 2)}`, `${usd(r.target - Math.max(0, v.profit), 2)} to go`)}</small></div>` : ''}
        ${r.daily != null ? `<div class="card ch-goal"><div class="ch-gh"><b>${L('خسارة اليوم', "Today's loss")}</b><span>${usd(g.dailyUsed, 2)} / ${usd(r.daily)}</span></div>${bar((g.dailyUsed / r.daily) * 100, g.dailyUsed / r.daily > 0.7 ? 'is-bad' : 'is-warn')}<small>${L(`ضايلك ${usd(g.dailyLeft, 2)} لليوم · بيتصفّر 00:00 UTC`, `${usd(g.dailyLeft, 2)} left today · resets 00:00 UTC`)}</small></div>` : ''}
        <div class="card ch-goal"><div class="ch-gh"><b>${L('الخسارة الكلية', 'Max loss')}</b><span>${usd(g.maxUsed, 2)} / ${usd(r.maxLoss)}</span></div>${bar((g.maxUsed / r.maxLoss) * 100, g.maxUsed / r.maxLoss > 0.7 ? 'is-bad' : 'is-warn')}<small>${L(`الإكويتي لازم يضل فوق ${usd(r.floor)} · ضايلك ${usd(g.maxLeft, 2)}`, `Equity must stay above ${usd(r.floor)} · ${usd(g.maxLeft, 2)} left`)}</small></div>
      </div>
      <div class="card ch-curve"><div class="ch-gh"><b>${L('منحنى الإكويتي', 'Equity curve')}</b><small class="muted">${L('بيتحدّث كل كم ثانية', 'updates every few seconds')}</small></div>${chart(v)}</div>
      ${fundedBox}
      <div class="ch-trade">
        <form class="card ch-ticket" data-ticket ${closed || v.funded?.payoutPending ? 'inert aria-disabled="true"' : ''}>
          <h3>${L('صفقة جديدة', 'New order')}</h3>
          <label>${L('الأداة', 'Instrument')}<select class="input" name="sym">${symOpts}</select></label>
          <label>${L('اللوت', 'Lots')}<input class="input" name="lots" type="number" inputmode="decimal" min="0.01" max="${MAX_LOTS}" step="0.01" value="0.10" required></label>
          <div class="ch-2"><label>${L('وقف خسارة', 'Stop loss')}<input class="input" name="sl" type="number" inputmode="decimal" step="any" placeholder="${L('اختياري', 'optional')}"></label><label>${L('هدف', 'Take profit')}<input class="input" name="tp" type="number" inputmode="decimal" step="any" placeholder="${L('اختياري', 'optional')}"></label></div>
          <small class="muted" data-spec></small>
          <div class="ch-2"><button type="submit" class="btn ch-buyb" data-side="buy">${L('شراء', 'Buy')}</button><button type="submit" class="btn ch-sellb" data-side="sell">${L('بيع', 'Sell')}</button></div>
          <small class="ch-fine">${L('التنفيذ بسعر السوق اللي بيجيبه السيرفر لحظة الطلب (كريبتو من Binance، فوركس ومؤشرات من Yahoo، ذهب وفضة ونفط من Binance Futures). لو السعر مش لحظي، الطلب بينرفض.', 'Fills at the market price the server fetches at that moment (crypto: Binance; FX & indices: Yahoo; gold, silver, oil: Binance Futures). No real-time price → order refused.')}</small>
        </form>
        <div class="card ch-pos"><h3>${L('الصفقات المفتوحة', 'Open positions')} <small class="muted">(${v.positions.length})</small></h3>
          ${v.positions.length ? `<div class="ch-tbl-wrap"><table class="ch-tbl ch-ptbl"><thead><tr><th>${L('الأداة', 'Symbol')}</th><th>${L('النوع', 'Side')}</th><th>${L('لوت', 'Lots')}</th><th>${L('دخول', 'Entry')}</th><th>${L('السعر', 'Price')}</th><th>SL / TP</th><th>${L('ربح/خسارة', 'P&L')}</th><th></th></tr></thead><tbody>
            ${v.positions.map((p) => `<tr><td><b>${p.sym}</b></td><td><em class="ch-side is-${p.side}">${p.side === 'buy' ? L('شراء', 'Buy') : L('بيع', 'Sell')}</em></td><td>${p.lots}</td><td class="mono">${pxFmt(p.sym, p.entry)}</td><td class="mono">${pxFmt(p.sym, p.price)}</td><td class="mono">${p.sl ? pxFmt(p.sym, p.sl) : '—'} / ${p.tp ? pxFmt(p.sym, p.tp) : '—'}</td><td class="mono ${p.pnl < 0 ? 'neg' : 'pos'}">${usd(p.pnl, 2)}</td><td><button type="button" class="btn btn-sm" data-close="${p.id}" ${closed ? 'disabled' : ''}>${L('إغلاق', 'Close')}</button></td></tr>`).join('')}
          </tbody></table></div>` : `<p class="muted">${L('ما في صفقات مفتوحة.', 'No open positions.')}</p>`}
        </div>
      </div>
      <div class="card ch-hist"><h3>${L('سجل الصفقات', 'Trade history')}</h3>
        ${v.history.length ? `<div class="ch-tbl-wrap"><table class="ch-tbl"><thead><tr><th>${L('الأداة', 'Symbol')}</th><th>${L('النوع', 'Side')}</th><th>${L('لوت', 'Lots')}</th><th>${L('دخول', 'Entry')}</th><th>${L('خروج', 'Exit')}</th><th>${L('ربح/خسارة', 'P&L')}</th><th>${L('السبب', 'Reason')}</th><th>${L('الوقت', 'Time')}</th></tr></thead><tbody>
          ${v.history.map((x) => `<tr><td>${x.sym}</td><td><em class="ch-side is-${x.side}">${x.side === 'buy' ? L('شراء', 'Buy') : L('بيع', 'Sell')}</em></td><td>${x.lots}</td><td class="mono">${pxFmt(x.sym, x.entry)}</td><td class="mono">${pxFmt(x.sym, x.exit)}</td><td class="mono ${x.pnl < 0 ? 'neg' : 'pos'}">${usd(x.pnl, 2)}</td><td>${esc({ manual: L('يدوي', 'Manual'), sl: 'SL', tp: 'TP', daily_loss: L('حد يومي', 'Daily limit'), max_loss: L('حد كلي', 'Max limit') }[x.reason] || x.reason)}</td><td>${dt(x.closeAt)}</td></tr>`).join('')}
        </tbody></table></div>` : `<p class="muted">${L('لسا ما في صفقات مسكّرة.', 'No closed trades yet.')}</p>`}</div>`;
  }
  function payoutForm() {
    return `<form class="ch-payout" data-payout>
      <label>${L('طريقة السحب', 'Payout method')}<select class="input" name="method">${PAYOUT_METHODS.map((m) => `<option value="${m.id}">${esc(tx(m.name))}</option>`).join('')}</select></label>
      <div data-pfields></div>
      <div class="ch-2"><label>${L('الاسم الكامل (متل الهوية)', 'Full legal name')}<input class="input" name="fullName" required minlength="5" maxlength="80" autocomplete="name"></label><label>${L('الدولة (رمز من حرفين)', 'Country (2 letters)')}<input class="input" name="country" required maxlength="2" pattern="[A-Za-z]{2}" placeholder="JO" autocomplete="country"></label></div>
      <label class="ch-chk"><input type="checkbox" name="adult"> ${L('عمري 18 سنة أو أكثر', 'I am 18 or older')}</label>
      <label class="ch-chk"><input type="checkbox" name="terms"> ${L('بوافق على شروط التحدي والتحقق من هويتي قبل التحويل', 'I accept the challenge terms and an identity check before payment')}</label>
      <button type="submit" class="btn btn-primary">${icons.wallet}<span>${L('اطلب السحب', 'Request payout')}</span></button>
      <small class="ch-fine">${L('ما منطلب أرقام بطاقات أبداً. التحويل بيصير يدوياً من الإدارة عبر المزوّد، وبيوصلك إشعار مع رقم المرجع.', 'We never ask for card numbers. The transfer is made by the team through the provider; you get a notice with the reference.')}</small></form>`;
  }
  const PFIELDS = {
    paypal: () => `<label>${L('إيميل PayPal', 'PayPal e-mail')}<input class="input" name="email" type="email" required maxlength="120" autocomplete="email"></label>`,
    card: () => `<label>${L('إيميلك (بيوصلك رابط آمن من المزوّد لاستلام المبلغ على البطاقة)', 'Your e-mail (the provider sends a secure link to receive it on your card)')}<input class="input" name="email" type="email" required maxlength="120" autocomplete="email"></label>`,
    bank: () => `<label>IBAN<input class="input" name="iban" required maxlength="40" dir="ltr" autocomplete="off"></label><div class="ch-2"><label>${L('اسم صاحب الحساب', 'Account holder')}<input class="input" name="holder" required maxlength="80"></label><label>${L('اسم البنك', 'Bank')}<input class="input" name="bank" maxlength="80"></label></div>`,
    usdt: () => `<div class="ch-2"><label>${L('الشبكة', 'Network')}<select class="input" name="network"><option value="trc20">TRC20 (Tron)</option><option value="erc20">ERC20 (Ethereum)</option></select></label><label>${L('عنوان المحفظة', 'Wallet address')}<input class="input" name="address" required maxlength="64" dir="ltr" autocomplete="off"></label></div>`,
  };
  function wireDash() {
    const t = body.querySelector('[data-ticket]');
    const spec = () => { const s = t.sym.value; const c = CONTRACTS[s]; t.lots.min = c.min; t.querySelector('[data-spec]').textContent = L(`1 لوت = ${c.unit.toLocaleString('en')} وحدة · أقل حجم ${c.min}`, `1 lot = ${c.unit.toLocaleString('en')} units · min ${c.min}`); };
    if (t) { spec(); t.sym.addEventListener('change', spec); t.addEventListener('submit', async (e) => {
      e.preventDefault(); if (S.busy) return; const side = e.submitter?.dataset.side || 'buy'; const fd = new FormData(t);
      const n = (x) => (x === '' || x == null ? null : Number(x));
      S.busy = true; t.querySelectorAll('button').forEach((b) => { b.disabled = true; });
      try { const r = await apiRequest('POST', `/api/challenges/${S.acc}/order`, { sym: fd.get('sym'), side, lots: n(fd.get('lots')), sl: n(fd.get('sl')), tp: n(fd.get('tp')) }); toast(L(`انفتحت الصفقة على ${pxFmt(r.position.sym, r.position.entry)}`, `Filled at ${pxFmt(r.position.sym, r.position.entry)}`), 'success'); await refresh(); }
      catch (er) { toast(errText(er), 'error', 6000); }
      S.busy = false; t.querySelectorAll('button').forEach((b) => { b.disabled = false; });
    }); }
    const pf = body.querySelector('[data-payout]');
    if (pf) {
      const fields = () => { pf.querySelector('[data-pfields]').innerHTML = PFIELDS[pf.method.value](); }; fields(); pf.method.addEventListener('change', fields);
      pf.addEventListener('submit', async (e) => {
        e.preventDefault(); const fd = Object.fromEntries(new FormData(pf)); const m = fd.method;
        const details = m === 'bank' ? { iban: fd.iban, holder: fd.holder, bank: fd.bank } : m === 'usdt' ? { network: fd.network, address: fd.address } : { email: fd.email };
        try { const r = await apiRequest('POST', `/api/challenges/${S.acc}/payout`, { method: m, details, kyc: { fullName: fd.fullName, country: String(fd.country || '').toUpperCase(), adult: Boolean(fd.adult), terms: Boolean(fd.terms) } });
          toast(L(`انبعث طلب سحب ${usd(r.payout.amount, 2)} ✅`, `Payout request for ${usd(r.payout.amount, 2)} sent ✅`), 'success', 7000); await refresh(); }
        catch (er) { toast(errText(er), 'error', 6000); }
      });
    }
  }
  async function refresh() {
    if (S.tab !== 'accounts' || !S.acc) return;
    const focus = document.activeElement; if (focus && body.contains(focus) && /INPUT|SELECT|TEXTAREA/.test(focus.tagName)) return;   // don't redraw under the person's fingers
    const keep = body.querySelector('[data-ticket]') ? Object.fromEntries(new FormData(body.querySelector('[data-ticket]'))) : null;
    await loadView(); const i = S.accounts.findIndex((a) => a.id === S.acc); if (i >= 0 && S.view) S.accounts[i] = { ...S.accounts[i], status: S.view.status, balance: S.view.balance };
    if (S.tab !== 'accounts') return; const y = window.scrollY; paintAccounts();
    const t = body.querySelector('[data-ticket]'); if (t && keep) { for (const [n, val] of Object.entries(keep)) if (t[n]) t[n].value = val; t.sym.dispatchEvent(new Event('change')); }
    window.scrollTo(0, y);
  }
  whileMounted(root, () => { if (S.tab === 'accounts' && !document.hidden && S.view && (S.view.status === 'active' || S.view.status === 'funded')) refresh(); }, 5000);

  /* ───────── payouts ───────── */
  async function drawPayouts() {
    if (!auth.current()) { body.innerHTML = `<div class="card ch-empty">${L('سجّل دخول أول.', 'Sign in first.')}</div>`; return; }
    let items = []; try { items = (await apiRequest('GET', '/api/challenges/payouts')).items || []; } catch (e) { toast(errText(e), 'error'); }
    const st = { pending: ['قيد المراجعة', 'Pending', 'warn'], paid: ['انحوّل', 'Paid', 'ok'], rejected: ['مرفوض', 'Rejected', 'bad'] };
    body.innerHTML = `<div class="card"><h3>${L('طلبات السحب', 'Payout requests')}</h3>${items.length ? `<div class="ch-tbl-wrap"><table class="ch-tbl"><thead><tr><th>${L('الرقم', 'ID')}</th><th>${L('الحساب', 'Account')}</th><th>${L('المبلغ', 'Amount')}</th><th>${L('الطريقة', 'Method')}</th><th>${L('الحالة', 'Status')}</th><th>${L('التاريخ', 'Date')}</th><th>${L('مرجع/ملاحظة', 'Ref / note')}</th></tr></thead><tbody>
      ${items.map((w) => `<tr><td class="mono">${w.id}</td><td class="mono">${w.account}</td><td><b>${usd(w.amount, 2)}</b></td><td>${esc(tx(PAYOUT_METHODS.find((m) => m.id === w.method)?.name || { ar: w.method, en: w.method }))}</td><td><em class="ch-st is-${st[w.state]?.[2] || ''}">${esc(L(...(st[w.state] || [w.state, w.state])))}</em></td><td>${dt(w.at)}</td><td>${esc(w.reference || w.note || '—')}</td></tr>`).join('')}
    </tbody></table></div>` : `<p class="muted">${L('ما في طلبات سحب لسا. الطلب بينعمل من الحساب الممول.', 'No payout requests yet. Request one from a funded account.')}</p>`}</div>
    <div class="card ch-how"><h3>${L('طرق السحب', 'Payout methods')}</h3><div class="ch-paym">${PAYOUT_METHODS.map((m) => `<span class="ch-pm">${esc(tx(m.name))}</span>`).join('')}</div><p class="muted">${L('كل طلب بتراجعه الإدارة وبتتحقق من الهوية، وبعدها بيتحوّل المبلغ عبر المزوّد وبيوصلك رقم المرجع.', 'Each request is reviewed with an identity check, then paid through the provider with a reference.')}</p></div>`;
  }

  /* ───────── owner ───────── */
  async function drawAdmin() {
    if (!isAdmin()) { setTab('programs'); return; }
    let d; try { d = await apiRequest('GET', '/api/challenges/admin'); } catch (e) { body.innerHTML = `<div class="card ch-empty">${esc(errText(e))}</div>`; return; }
    const s = d.stats; const det = (x) => (x.method === 'bank' ? `${x.holder} · ${x.iban}` : x.method === 'usdt' ? `${x.network.toUpperCase()} · ${x.address}` : x.email);
    body.innerHTML = `
      <div class="ch-kpis">${[[L('كل الحسابات', 'All'), s.total], [L('نشطة', 'Active'), s.active], [L('ممولة', 'Funded'), s.funded], [L('مراجعة', 'Review'), s.review], [L('منتهية', 'Ended'), s.failed], [L('مبيوعة', 'Sold'), s.sold]].map(([a, b]) => `<div class="ch-kpi"><small>${esc(a)}</small><b>${b}</b></div>`).join('')}</div>
      <div class="card"><h3>${L('مراجعات التمويل', 'Funding reviews')} (${d.reviews.length})</h3>${d.reviews.length ? d.reviews.map((r) => `<div class="ch-adm-row"><div><b class="mono">${r.id}</b> · ${esc(r.email)} · ${esc(programById(r.program)?.short || '')} ${k(r.size)} · ${L('رصيد', 'balance')} ${usd(r.balance, 2)} · ${r.days} ${L('أيام', 'days')}</div><div class="ch-adm-act"><button type="button" class="btn btn-sm" data-view="${r.id}">${L('شوف الصفقات', 'View')}</button><button type="button" class="btn btn-sm btn-primary" data-act="review_approve" data-id="${r.id}">${L('موافقة وتمويل', 'Approve & fund')}</button><button type="button" class="btn btn-sm" data-act="review_reject" data-id="${r.id}">${L('رفض', 'Reject')}</button></div></div>`).join('') : `<p class="muted">${L('ما في مراجعات.', 'No reviews.')}</p>`}</div>
      <div class="card"><h3>${L('طلبات السحب', 'Payout requests')}</h3>${d.payouts.length ? d.payouts.map((w) => `<div class="ch-adm-row"><div><b class="mono">${w.id}</b> · <b>${usd(w.amount, 2)}</b> (${w.split}% ${L('من', 'of')} ${usd(w.profit, 2)}) · ${esc(w.kyc?.fullName || '')} · ${esc(w.kyc?.country || '')} · ${esc(tx(PAYOUT_METHODS.find((m) => m.id === w.details.method)?.name || { ar: '', en: '' }))}: <span class="mono" dir="ltr">${esc(det(w.details))}</span> · ${dt(w.at)} · <em class="ch-st">${esc(w.state)}</em>${w.reference ? ` · ${esc(w.reference)}` : ''}</div>${w.state === 'pending' ? `<div class="ch-adm-act"><button type="button" class="btn btn-sm" data-view="${w.account}">${L('شوف الحساب', 'View')}</button><button type="button" class="btn btn-sm btn-primary" data-act="payout_paid" data-id="${w.id}">${L('انحوّل (مع المرجع)', 'Mark paid (with ref)')}</button><button type="button" class="btn btn-sm" data-act="payout_reject" data-id="${w.id}">${L('رفض', 'Reject')}</button></div>` : ''}</div>`).join('') : `<p class="muted">${L('ما في طلبات.', 'No requests.')}</p>`}</div>
      <form class="card ch-grant" data-grant><h3>${L('إعطاء حساب تحدي لعضو', 'Give a challenge account to a member')}</h3><div class="ch-2"><label>${L('إيميل العضو', 'Member e-mail')}<input class="input" name="email" type="email" required></label><label>${L('البرنامج', 'Program')}<select class="input" name="program">${PROGRAMS.map((p) => `<option value="${p.id}">${p.short}</option>`).join('')}</select></label></div><label>${L('الحجم', 'Size')}<select class="input" name="size">${SIZES.map((x) => `<option value="${x}">${k(x)}</option>`).join('')}</select></label><button class="btn btn-primary">${L('أعطيه', 'Grant')}</button><small class="muted">${L('الأسعار بتتعدّل من «الاشتراكات والكوبونات» متل باقي الباقات.', 'Prices are edited in "Subscriptions & coupons" like every plan.')}</small></form>
      <div class="card"><h3>${L('الحسابات', 'Accounts')}</h3><div class="ch-tbl-wrap"><table class="ch-tbl"><thead><tr><th>ID</th><th>${L('العضو', 'Member')}</th><th>${L('البرنامج', 'Program')}</th><th>${L('المرحلة', 'Phase')}</th><th>${L('الحالة', 'Status')}</th><th>${L('الرصيد', 'Balance')}</th><th>${L('المصدر', 'Source')}</th><th></th></tr></thead><tbody>
        ${d.accounts.map((a) => `<tr><td class="mono">${a.id}</td><td>${esc(a.email)}</td><td>${esc(programById(a.program)?.short || '')} ${k(a.size)}</td><td>${esc(phaseName(a))}</td><td>${chip(a.status)}</td><td>${usd(a.balance, 2)}</td><td>${esc(a.source || '')}</td><td><button type="button" class="btn btn-sm" data-view="${a.id}">${L('شوف', 'View')}</button></td></tr>`).join('')}
      </tbody></table></div></div>`;
  }
  async function adminAct(b) { try { await apiRequest('POST', '/api/challenges/admin', b); toast(L('تم ✅', 'Done ✅'), 'success'); drawAdmin(); } catch (e) { toast(errText(e), 'error', 6000); } }

  body.addEventListener('click', async (e) => {
    const go = e.target.closest('[data-go]'); if (go) { setTab(go.dataset.go); return; }
    const pr = e.target.closest('[data-prog]'); if (pr) { S.prog = pr.dataset.prog; drawPrograms(); return; }
    const rt = e.target.closest('[data-rtab]'); if (rt) { S.rtab = rt.dataset.rtab; drawPrograms(); return; }
    const qb = e.target.closest('[data-qty]'); if (qb) { S.qty = Math.min(5, Math.max(1, S.qty + Number(qb.dataset.qty))); drawPrograms(); return; }
    if (e.target.closest('[data-cpx]')) { S.coupon = null; drawPrograms(); return; }
    const sz = e.target.closest('[data-size]'); if (sz) { S.size = Number(sz.dataset.size); drawPrograms(); return; }
    const ac = e.target.closest('[data-acc]'); if (ac) { S.acc = ac.dataset.acc; if (!S.accounts.some((a) => a.id === S.acc)) await loadAccounts(); await loadView(); paintAccounts(); return; }
    const cl = e.target.closest('[data-close]'); if (cl) { cl.disabled = true; try { const r = await apiRequest('POST', `/api/challenges/${S.acc}/close/${cl.dataset.close}`, {}); toast(r.pnl != null ? L(`انسكّرت: ${usd(r.pnl, 2)}`, `Closed: ${usd(r.pnl, 2)}`) : L('انسكّرت', 'Closed'), r.pnl < 0 ? 'info' : 'success'); } catch (er) { toast(errText(er), 'error'); } await refresh(); return; }
    const vw = e.target.closest('[data-view]'); if (vw) { S.tab = 'accounts'; S.acc = vw.dataset.view; root.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('is-on', b.dataset.tab === 'accounts')); await loadView(); S.accounts = S.view ? [{ id: S.view.id, program: S.view.program, size: S.view.size, phase: S.view.phase, status: S.view.status }] : []; paintAccounts(); return; }
    const act = e.target.closest('[data-act]');
    if (act) {
      const a = act.dataset.act; const b = { action: a, id: act.dataset.id };
      if (a === 'payout_paid') { const ref = prompt(L('رقم مرجع التحويل (من PayPal / البنك / المحفظة):', 'Transfer reference (PayPal / bank / wallet):')); if (!ref) return; b.reference = ref; }
      if (a === 'payout_reject' || a === 'review_reject') { const n = prompt(L('سبب الرفض (بيوصل للعضو):', 'Reason (sent to the member):')); if (n == null) return; b.note = n; }
      if (a === 'review_approve' && !confirm(L('متأكد؟ رح ينفتح حساب ممول لهالعضو.', 'Sure? A funded account will open for this member.'))) return;
      adminAct(b); return;
    }
    const buy = e.target.closest('[data-buy]');
    if (buy) {
      if (!auth.current()) { toast(L('سجّل دخول أول عشان تشتري.', 'Sign in first to buy.'), 'info'); return; }
      if (!(await billingOn())) { toast(L('الدفع لسا مش مفعّل — صاحب الموقع لازم يربط Stripe من صفحة «الدفع».', 'Payments are not switched on yet — the owner needs to connect Stripe.'), 'info', 7000); return; }
      buy.disabled = true;
      try { const r = await apiRequest('POST', '/api/billing/checkout', { product: buy.dataset.buy, quantity: buy.classList.contains('ch-start') ? S.qty : 1, coupon: S.coupon && S.coupon.product === buy.dataset.buy ? S.coupon.code : undefined }, 20000); if (r?.url && /^https:\/\/checkout\.stripe\.com\//.test(r.url)) { location.href = r.url; return; } toast(L('ما قدرنا نفتح صفحة الدفع.', 'Could not open checkout.'), 'error'); }
      catch (er) { toast(errText(er), 'error'); }
      buy.disabled = false;
    }
  });
  body.addEventListener('submit', async (e) => {
    const cf = e.target.closest('[data-cpn]');
    if (cf) {
      e.preventDefault(); const code = String(new FormData(cf).get('code') || '').trim().toUpperCase(); if (!code) return;
      if (!auth.current()) { toast(L('سجّل دخول أول.', 'Sign in first.'), 'info'); return; }
      const pid = productId(S.prog, S.size);
      try { const q = await apiRequest('POST', '/api/coupon/check', { code, product: pid }); const fin = q.finalCents / 100; const pct = Math.round((q.discountCents / (q.finalCents + q.discountCents)) * 100);
        S.coupon = { code, pct: Math.max(1, pct), final: fin, product: pid }; drawPrograms(); toast(L(`انطبق الكود: خصم ${pct}%`, `Code applied: ${pct}% off`), 'success'); }
      catch (er) { const m = { expired: ['الكود خلص.', 'Code expired.'], used_up: ['الكود انستعمل لآخره.', 'Code used up.'], not_for_plan: ['الكود مش لهالحساب.', 'Code not valid for this account.'], already_used: ['استعملت هالكود قبل.', 'You already used this code.'], not_started: ['الكود لسا ما بلّش.', 'Code not active yet.'] }[er?.code]; toast(m ? L(...m) : L('الكود مش صحيح.', 'Invalid code.'), 'error'); }
      return;
    }
    const g = e.target.closest('[data-grant]'); if (!g) return; e.preventDefault();
    const fd = Object.fromEntries(new FormData(g)); adminAct({ action: 'grant', email: fd.email, program: fd.program, size: Number(fd.size) });
  });
  draw();
  return root;
}
