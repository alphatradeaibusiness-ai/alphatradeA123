// "My subscription": the plan the server confirmed, days left, AI allowance this month, payment history, renew.
// Nothing renews by itself (one-time payments for a period), so the page says when access ends.
import { h, esc } from '../utils/dom.js';
import { t, getLang } from '../i18n/index.js';
import { icons } from '../components/icons.js';
import { apiRequest } from '../services/ai/gateway.js';
import { CHANNEL_PRODUCTS } from '../config/channelPlans.js';
import { toast } from '../components/ui.js';

const L = (ar, en) => (getLang() !== 'ar' ? en : ar);
const day = (ms) => new Date(ms).toLocaleDateString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { year: 'numeric', month: 'short', day: 'numeric' });
const usd = (c) => `$${(c / 100).toFixed(2).replace(/\.00$/, '')}`;
const prodName = (id) => {
  if (['monthly', 'quarterly', 'semiannual', 'annual', 'prime', 'apex', 'max'].includes(id)) return t(`pricing.plans.${id}`);
  const p = CHANNEL_PRODUCTS.find((x) => x.id === id);
  return p ? (p.kind === 'subscription' ? L('القناة', 'Channel') : L(`${p.count} توصية إضافية`, `${p.count} extra signals`)) : id;
};

export function renderBilling() {
  const el = h(`<section class="subpage billing page-enter">
    <header class="subpage-head"><h1>${esc(L('اشتراكي', 'My subscription'))}</h1><p class="muted">${esc(L('خطتك، وقديش ضايلها، وحصة الذكاء الاصطناعي، وكل دفعاتك.', 'Your plan, time left, AI allowance and every payment.'))}</p></header>
    <div data-b><article class="card tool-card"><p class="muted">…</p></article></div></section>`);
  const box = el.querySelector('[data-b]');
  apiRequest('GET', '/api/billing/me', undefined, 15000).then((m) => {
    const s = m.subscription; const now = Date.now();
    const left = s ? Math.max(0, Math.ceil((s.until - now) / 86_400_000)) : 0;
    const span = s ? Math.max(1, s.until - s.startsAt) : 1; const pct = s ? Math.min(100, Math.round(((s.until - now) / span) * 100)) : 0;
    const status = m.owner ? `<span class="badge badge-live">${esc(L('صاحب الموقع — كل شي مفتوح', 'Site owner — everything unlocked'))}</span>`
      : s ? `<span class="badge ${left <= 7 ? 'badge-warn' : 'badge-live'}">${esc(left <= 7 ? L('قرّب يخلص', 'Ending soon') : L('فعّال', 'Active'))}</span>` : `<span class="badge badge-muted">${esc(L('ما في اشتراك', 'No active plan'))}</span>`;
    const ai = m.ai || {};
    box.innerHTML = `
      <div class="bl-grid">
        <article class="card tool-card bl-plan">
          <div class="tool-head"><h2 class="card-title">${icons.crown || ''}<span>${esc(s ? prodName(s.product) : L('بدون اشتراك', 'No plan'))}</span></h2>${status}</div>
          ${s ? `<div class="bl-left"><b class="mono">${left}</b><span>${esc(L('يوم ضايل', left === 1 ? 'day left' : 'days left'))}</span></div>
            <div class="sa-progress"><span style="width:${pct}%"></span></div>
            <p class="muted tool-note">${esc(L(`من ${day(s.startsAt)} لحد ${day(s.until)}. الاشتراك ما بيتجدد لحاله — جدّده قبل ما يخلص حتى ما تنقطع.`, `From ${day(s.startsAt)} to ${day(s.until)}. It does not renew by itself — renew before it ends to keep access.`))}</p>`
          : `<p class="muted">${esc(m.lastSubscription ? L(`آخر اشتراك خلص بـ ${day(m.lastSubscription.until)}.`, `Your last plan ended on ${day(m.lastSubscription.until)}.`) : L('لسا ما اشتركت. الأدوات الأساسية مفتوحة، والمدفوعة بحاجة خطة.', 'You have not subscribed yet. Paid tools need a plan.'))}</p>`}
          <a class="btn btn-primary" href="#/app/pricing">${icons.crown || ''}<span>${esc(s ? L('جدّد أو رقّي', 'Renew or upgrade') : L('شوف الخطط', 'See plans'))}</span></a>
        </article>
        <article class="card tool-card">
          <h2 class="card-title">${icons.sparkle || ''}<span>${esc(L('الذكاء الاصطناعي هالشهر', 'AI this month'))}</span></h2>
          ${m.owner || !m.enforce ? `<p class="muted">${esc(m.owner ? L('بدون حد لصاحب الموقع.', 'No limit for the site owner.') : L('الحصص لسا مش مفعّلة على الموقع، فهلأ ما في حد.', 'Allowances are not enforced on this site yet, so there is no limit for now.'))}</p>`
          : `<div class="bl-left"><b class="mono">${ai.left ?? 0}</b><span>${esc(L(`من ${ai.total ?? 0} ضايلين`, `of ${ai.total ?? 0} left`))}</span></div>
            <div class="sa-progress"><span style="width:${ai.total ? Math.round(((ai.total - ai.used) / ai.total) * 100) : 0}%"></span></div>
            <p class="muted tool-note">${esc(m.enforce ? L('الحصة بتتجدد أول كل شهر، وبعض الخطط بتنقل الباقي للشهر الجاي.', 'Renews on the 1st; some plans carry the unused part over.') : L('الحصص لسا مش مفعّلة على الموقع — هلأ ما في حد.', 'Allowances are not enforced on this site yet — no limit for now.'))}</p>`}
          ${(m.addons || []).length ? `<p class="tool-note">${esc(L('توصيات إضافية فعّالة:', 'Active signal top-ups:'))} ${m.addons.map((a) => `<b class="mono">+${a.count}</b> <small class="muted">(${esc(day(a.until))})</small>`).join(' · ')}</p>` : ''}
        </article>
      </div>
      ${m.trial?.eligible && !m.owner ? `<article class="card tool-card bl-trial"><h2 class="card-title">${icons.gift || ''}<span>${esc(L(`جرّب كل شي مجانًا ${m.trial.days} أيام`, `Try everything free for ${m.trial.days} days`))}</span></h2>
        <p class="tool-note">${esc(L('الخطة الكاملة بدون بطاقة. مرة وحدة لكل حساب. لما تخلص بيوصلك تذكير، وما بينسحب منك شي.', 'The full plan, no card needed. Once per account. You get a reminder when it ends; nothing is charged.'))}</p>
        <button type="button" class="btn btn-primary" data-trial>${icons.sparkle || ''}<span>${esc(L('ابدأ التجربة المجانية', 'Start the free trial'))}</span></button></article>` : ''}
      ${m.referral ? `<article class="card tool-card bl-ref"><h2 class="card-title">${icons.gift || ''}<span>${esc(L('ادعُ أصحابك', 'Invite friends'))}</span></h2>
        <p class="tool-note">${esc(L(`لما حدا يشترك من رابطك، إنت وهو بتاخدوا ${m.referral.rewardDays} أيام مجانية.`, `When someone subscribes through your link, you both get ${m.referral.rewardDays} free days.`))}</p>
        <div class="cn-url"><input class="input mono" dir="ltr" readonly value="${esc(`${location.origin}/#/signup?ref=${m.referral.code}`)}" data-ref><button type="button" class="btn btn-sm" data-ref-copy>${esc(L('انسخ', 'Copy'))}</button></div>
        <p class="muted tool-note">${esc(L(`سجّلوا من رابطك: ${m.referral.invited} · أيام كسبتها: ${m.referral.earnedDays}${m.referral.creditDays ? ` · أيام محفوظة لأول دفعة: ${m.referral.creditDays}` : ''}`, `Signed up with your link: ${m.referral.invited} · days earned: ${m.referral.earnedDays}${m.referral.creditDays ? ` · days saved for your next payment: ${m.referral.creditDays}` : ''}`))}</p></article>` : ''}
      <article class="card tool-card">
        <h2 class="card-title">${icons.journal || ''}<span>${esc(L('الدفعات', 'Payments'))}</span></h2>
        ${m.payments?.length ? `<div class="sa-table-wrap"><table class="kv-table bl-table"><thead><tr><th>${esc(L('التاريخ', 'Date'))}</th><th>${esc(L('الخطة', 'Item'))}</th><th>${esc(L('المبلغ', 'Amount'))}</th><th>${esc(L('لحد', 'Until'))}</th></tr></thead>
          <tbody>${m.payments.map((p) => `<tr><td>${esc(day(p.at))}</td><td>${esc(prodName(p.product))}${p.live ? '' : ` <small class="badge badge-warn">${esc(L('تجريبي', 'test'))}</small>`}</td><td class="mono">${usd(p.cents)}</td><td>${p.until ? esc(day(p.until)) : '—'}</td></tr>`).join('')}</tbody></table></div>
          <p class="muted tool-note">${esc(L('الإيصال الرسمي بيوصلك من Stripe على إيميلك.', 'The official receipt is e-mailed to you by Stripe.'))}</p>`
        : `<p class="muted">${esc(L('ما في دفعات لسا.', 'No payments yet.'))}</p>`}
      </article>`;
    box.querySelector('[data-trial]')?.addEventListener('click', async (e) => {
      e.currentTarget.disabled = true;
      try { await apiRequest('POST', '/api/me/trial', {}); toast(L('بلّشت التجربة! كل شي مفتوح.', 'Trial started! Everything is unlocked.'), 'success'); setTimeout(() => location.reload(), 1200); }
      catch (x) { toast(x?.code === 'trial_used' ? L('التجربة استعملت قبل.', 'The trial was already used.') : L('التجربة مش متاحة لهالحساب.', 'The trial is not available for this account.'), 'error'); e.currentTarget.disabled = false; }
    });
    box.querySelector('[data-ref-copy]')?.addEventListener('click', async () => { const i = box.querySelector('[data-ref]'); try { await navigator.clipboard.writeText(i.value); toast(L('انسخ الرابط', 'Link copied'), 'success', 1500); } catch { i.select(); } });
  }).catch((e) => { box.innerHTML = `<article class="card tool-card"><p class="muted">${esc(e?.code === 'server_missing' || e?.code === 'server_unreachable' ? L('السيرفر مش متاح هلأ.', 'The server is not reachable right now.') : L('ما قدرنا نجيب معلومات الاشتراك. سجّل دخول من جديد وجرّب.', 'Could not load your subscription. Sign in again and retry.'))}</p></article>`; });
  return el;
}
