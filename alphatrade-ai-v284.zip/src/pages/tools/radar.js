// Alpha Radar: scans every instrument on one timeframe (real candles) and ranks the opportunities —
// trend (EMA 50/200), momentum, RSI, SMC structure, volatility, the strategies' recent accuracy and
// any open setup — into one score with a direction. Refreshes every minute.
import { esc, fmtNum } from '../../utils/dom.js';
import { icons, assetIcon } from '../../components/icons.js';
import { t } from '../../i18n/index.js';
import { storage } from '../../utils/storage.js';
import { store } from '../../state/store.js';
import { navigate } from '../../router.js';
import { INSTRUMENTS, getInstrument } from '../../config/instruments.js';
import { getCandles, isUnavailable } from '../../services/market/index.js';
import { radarScore } from '../../services/radarScore.js';
import { aiEnabled, aiQuick, prefetchHistory } from '../../services/aiLive.js';
import { prefetchHtf } from '../../services/htfData.js';
import { whileMounted, loading, dateStr } from './common.js';
import { getCalendar } from '../../services/news.js';
import { explainRadar, newsRisk } from '../../services/synthesis.js';
import { smartMoneyFlow, mtfAlignment, qualityScore, validateCandles, cleanCandles, quickBiasOf, RADAR_TFS } from '../../services/radarPro.js';
import { recordOpportunities } from '../../services/radarTracker.js';
import { L, PART, GRADE, DATA, whyText } from './radarText.js';
const TFS = ['5m', '15m', '1h', '4h', '1D'];
const HTF_SEC = { '5m': 300, '15m': 900, '1h': 3600, '4h': 14400, '1D': 86400 };
const pause = (ms) => new Promise((r) => setTimeout(r, ms));

export { radarScore };

export function mountOpps(el, body) {
  const st = { tf: 'all', showAll: false, ...storage.get('radar', {}) };
  let calEvents = null;   // economic calendar for the news-risk part of each explanation (null = unavailable)
  getCalendar().then((r) => { calEvents = r.events || []; if (lastOut) render(lastOut, lastFailed); }).catch(() => {});
  if (st.tf !== 'all' && !TFS.includes(st.tf)) st.tf = 'all';
  body.innerHTML = `
    <div class="card perf-controls fade-in radar-controls">
      <div class="perf-field"><span>${esc(t('perf.timeframe'))}</span><div class="seg" data-tfs><button type="button" data-tf="all" class="${st.tf === 'all' ? 'is-on' : ''}">${esc(t('rf.all'))}</button>${TFS.map((tf) => `<button type="button" data-tf="${tf}" class="${tf === st.tf ? 'is-on' : ''}">${esc(t(`perf.tfShort.${tf}`))}</button>`).join('')}</div></div>
      <label class="rd-toggle"><input type="checkbox" data-show-all ${st.showAll ? 'checked' : ''}><span>${esc(t('rf.showAll'))}</span></label>
      <div class="radar-scope" aria-hidden="true"><i></i><b></b></div>
      <div class="radar-status muted" data-status></div>
    </div>
    <div data-list>${loading()}</div>
    <p class="muted tool-note">${esc(t('tools.radar.note'))}</p>`;
  const $ = (s) => body.querySelector(s);
  let token = 0;

  $('[data-tfs]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tf]');
    if (!b || b.dataset.tf === st.tf) return;
    st.tf = b.dataset.tf; storage.set('radar', st);
    $('[data-tfs]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b));
    $('[data-list]').innerHTML = loading();
    scan();
  });
  $('[data-show-all]').addEventListener('change', (e) => { st.showAll = e.target.checked; storage.set('radar', st); if (lastOut) render(lastOut, lastFailed); });
  $('[data-list]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-open]');
    if (!b) return;
    store.set('timeframe', b.dataset.tf);
    store.set('symbol', b.dataset.open);
    navigate('#/app');
  });

  // Why this result exists: the parts that agree and the ones against it, from the same real data as the score.
  const txt = (it) => (it.key.startsWith('rf.') ? t(`rf.r.${it.key.slice(3)}`) : t(`rx.${it.key}`, it.params));
  const whyHtml = (r) => {
    const x = explainRadar(r, calEvents ? newsRisk(r.symbol, calEvents) : null);
    return `<div class="rd-explain is-${x.state}"><b>${esc(t(`rx.state.${x.state}`))}</b>
      ${x.pros.length ? `<p><span class="muted">${esc(t('rx.why'))}</span> ${x.pros.map((p) => `<span class="up">✓ ${esc(txt(p))}</span>`).join(' ')}</p>` : ''}
      ${x.cons.length ? `<p><span class="muted">${esc(t('rx.against'))}</span> ${x.cons.map((c) => `<span class="down">✕ ${esc(txt(c))}</span>`).join(' ')}</p>` : ''}</div>`;
  };

  const card = (r, i) => {
    const long = r.direction === 'long';
    const p = (v) => fmtNum(v, r.precision);
    const chip = (label, val, cls = '') => `<span class="rd-chip ${cls}"><small>${esc(label)}</small><b>${val}</b></span>`;
    const trendTxt = r.trend >= 1 ? t('tools.radar.up') : r.trend <= -1 ? t('tools.radar.down') : r.trend > 0 ? t('tools.radar.upWeak') : t('tools.radar.downWeak');
    return `<article class="card rd-card ${long ? 'is-long' : 'is-short'} fade-in" style="--i:${i}">
      <div class="rd-head">
        <span class="rd-rank mono">#${i + 1}</span>${assetIcon(getInstrument(r.symbol).icon, 26)}
        <div class="rd-name"><b class="mono">${esc(r.symbol)}</b><span class="muted mono">${p(r.price)}</span></div>
        <span class="badge ${long ? 'badge-live' : 'badge-error'}">${esc(t(long ? 'common.long' : 'common.short'))}</span>
        <span class="badge ${r.verdict === 'strong' ? 'badge-live' : r.verdict === 'unstable' ? 'badge-error' : 'badge-muted'}" title="${esc([...(r.filters?.unstable || []), ...(r.filters?.weak || [])].map((k) => t(`rf.r.${k}`)).join(' · '))}">${esc(t(`rf.v.${r.verdict}`))}</span>
        <span class="rd-score" style="--p:${(r.q?.score ?? r.score).toFixed(0)}" title="${esc(r.q ? GRADE()[r.q.grade] : '')}"><i></i><b class="mono">${(r.q?.score ?? r.score).toFixed(0)}</b></span>
      </div>
      <div class="rd-chips">
        ${chip(t('tools.radar.trend'), esc(trendTxt), r.trend > 0 ? 'up' : 'down')}
        ${chip('RSI', fmtNum(r.rsi, 0), r.rsi > 70 ? 'down' : r.rsi < 30 ? 'up' : '')}
        ${chip(t('tools.radar.momentum'), r.momentum != null ? fmtNum(r.momentum, 0) : '—', r.momentum > 55 ? 'up' : r.momentum < 45 ? 'down' : '')}
        ${chip('SMC', r.event ? `${r.event.kind} ${r.event.dir === 'bull' ? '↑' : '↓'} <small>(${r.event.ago})</small>` : '—', r.smcTrend === 'bull' ? 'up' : r.smcTrend === 'bear' ? 'down' : '')}
        ${chip(t('tools.radar.vol'), `${fmtNum(r.atrPct, 2)}%`)}
        ${r.filters ? chip('ATR', `×${fmtNum(r.filters.atrRatio, 2)}`, r.filters.unstable.includes('atrSpike') ? 'down' : '') : ''}
        ${r.filters ? chip(t('rf.volume'), r.filters.hasVolume ? `×${fmtNum(r.filters.volRatio, 2)}` : t('rf.noVolume'), r.filters.weak.includes('volThin') ? 'down' : r.filters.volRatio >= 1.2 ? 'up' : '') : ''}
        ${r.ai ? chip(t('aie.radarCol'), `${Math.round(r.ai.p * 100)}% <small>(${esc(r.ai.edge ? `${t('aie.quality')} ${r.ai.grade}` : t('aie.baseTag'))})</small>`, r.ai.edge ? (long ? 'up' : 'down') : '') : ''}
        ${chip(t('tools.radar.acc'), r.trades ? `${fmtNum(r.winRate, 0)}% <small>(${r.trades} · ${r.strategy === 'smc' ? 'SMC' : esc(t('perf.classic'))})</small>` : '—', r.winRate >= 55 ? 'up' : '')}
      </div>
      ${r.setup ? `<div class="rd-setup ${r.aligned ? 'is-aligned' : ''}"><span class="badge ${r.setup.status === 'active' ? 'badge-live' : 'badge-muted'}">${esc(t(r.setup.status === 'active' ? 'tools.radar.active' : 'tools.radar.pending'))} · ${esc(t(r.setup.direction === 'long' ? 'common.long' : 'common.short'))}</span>
        <span>${esc(t('plan.entry'))} <b class="mono">${p(r.setup.entry)}</b></span><span class="down">${esc(t('plan.stop'))} <b class="mono">${p(r.setup.stop)}</b></span>${r.setup.targets.map((x, k) => `<span class="up">TP${k + 1} <b class="mono">${p(x)}</b></span>`).join('')}</div>` : `<p class="muted rd-nosetup">${esc(t('tools.radar.noSetup'))}</p>`}
      ${r.mtf ? `<div class="rd-mtf">${TFS.map((tf) => { const m = r.mtf[tf]; return m ? `<span class="rd-tf ${m.verdict === 'strong' ? (m.direction === 'long' ? 'up' : 'down') : 'off'}" title="${esc(t(`rf.v.${m.verdict}`))}"><small>${esc(t(`perf.tfShort.${tf}`))}</small><b>${m.direction === 'long' ? '▲' : '▼'} ${m.score.toFixed(0)}</b></span>` : ''; }).join('')}</div>` : ''}
      ${r.q ? qualityHtml(r) : ''}
      ${whyHtml(r)}
      <div class="rd-foot">${r.mode !== 'live' ? `<span class="badge badge-demo">${esc(t('status.demo'))}</span>` : ''}<button type="button" class="btn btn-sm" data-open="${r.symbol}" data-tf="${r.tf}">${icons.candles}<span>${esc(t('tools.radar.open'))}</span></button></div>
    </article>`;
  };

  // v233: grade, data freshness, timeframe alignment and the 8 parts of the score (folded by default)
  const qualityHtml = (r) => {
    const q = r.q; const N = { '5m': '5m', '15m': '15m', '1h': '1H', '4h': '4H', '1D': '1D' };
    const dirTxt = (d) => (d === 'buy' ? L('شراء', 'BUY') : d === 'sell' ? L('بيع', 'SELL') : d === 'neutral' ? L('محايد', 'NEUTRAL') : '—');
    const al = r.align;
    return `<div class="rq">
      <div class="rq-top"><span class="rq-grade is-${q.grade}">${esc(GRADE()[q.grade])}</span>
        ${r.data && !r.data.live ? `<span class="rq-data is-${r.data.state}">${esc(DATA()[r.data.state] || r.data.state)}</span>` : ''}
        ${al?.score != null ? `<span class="rq-al ${al.htfAgainst ? 'is-bad' : al.score >= 70 ? 'is-good' : ''}">${esc(L('توافق الفريمات', 'TF alignment'))} <b>${al.score}%</b></span>` : ''}
        ${q.caps.includes('htfAgainst') ? `<span class="rq-warn">${esc(L('الفريم الأعلى عكس الصفقة', 'Higher timeframe disagrees'))}</span>` : ''}</div>
      ${al ? `<div class="rq-tfs">${al.rows.map((x) => `<span class="is-${x.dir || 'na'}${x.tf === r.tf ? ' is-entry' : ''}"><small>${N[x.tf]}</small><b>${esc(dirTxt(x.dir))}</b></span>`).join('')}</div>` : ''}
      <details class="rq-why"><summary>${esc(L('ليش هالدرجة؟', 'Why this score?'))} <small>${esc(L('جودة الإعداد — مش احتمال ربح', 'setup quality — not a win probability'))}</small></summary>
        <ul>${q.parts.map((p) => `<li><div class="rq-part"><span>${esc(PART()[p.key])}</span><b class="mono">${fmtNum(p.pts, 0)}/${p.max}</b></div><div class="rq-bar"><i style="width:${Math.round((p.pts / p.max) * 100)}%"></i></div><small>${p.why.map((w) => esc(whyText(w))).join(' · ')}</small></li>`).join('')}</ul></details>
    </div>`;
  };

  let lastOut = null; let lastFailed = [];
  function render(out, failed) {
    const strong = out.filter((r) => r.verdict === 'strong');
    const shown = st.showAll ? out : strong;
    const hidden = out.length - strong.length;
    $('[data-list]').innerHTML = shown.length ? `<div class="rd-list">${shown.map(card).join('')}</div>` : `<div class="card sig-empty">${icons.radar}<span>${esc(t('rf.noneStrong'))}</span></div>`;
    $('[data-status]').innerHTML = `${esc(t('tools.radar.updated', { time: dateStr(Date.now(), { hour: '2-digit', minute: '2-digit', second: '2-digit' }) }))}${hidden && !st.showAll ? ` · ${esc(t('rf.hidden', { n: hidden }))}` : ''}${failed.length ? ` · ${esc(t('tools.radar.skipped', { s: failed.join(', ') }))}` : ''}`;
  }

  async function analyse(inst, tf, settings) {
    const ds = await getCandles(inst.symbol, tf);
    if (ds.mode !== 'live') return { demo: true };
    if (inst.provider === 'binance') await prefetchHtf(inst.symbol, HTF_SEC[tf] || 3600);
    const r = radarScore(ds, settings);
    if (r) r._ds = ds;   // kept for the v233 quality pass (same candles, no second request)
    if (r && aiEnabled(settings)) {
      if (inst.provider === 'binance') await prefetchHistory(inst.symbol, tf);
      const pl = settings.plan || {};
      r.ai = aiQuick(ds, { direction: r.direction, risk: (pl.atrMult || 2) * (r.atrPct / 100) * r.price, rr1: pl.firstTargetR > 0 ? pl.firstTargetR : (pl.tpR?.[0] || 1) });
    }
    return { r };
  }

  // v233 — for the strong results (and the 8 best others): 8-part quality score, timeframe alignment, data freshness.
  async function enrich(out, frames, my) {
    const pick = [...out.filter((r) => r.verdict === 'strong'), ...out.filter((r) => r.verdict !== 'strong')].slice(0, 12);
    for (const r of pick) {
      if (my !== token || !el.isConnected) return;
      const ds = r._ds; if (!ds) continue;
      const candles = cleanCandles(ds.candles);
      r.data = validateCandles(candles, r.tf, { crypto: getInstrument(r.symbol).provider === 'binance' });
      const closed = candles.slice(0, -1);
      const smf = smartMoneyFlow(closed);
      // biases per timeframe: from this scan when every frame was scanned, otherwise fetched (cached) for the strong ones only
      const biases = {};
      if (r.mtf) for (const tf of RADAR_TFS) biases[tf] = r.mtf[tf]?.bias ?? null;
      else {
        biases[r.tf] = r.bias;
        if (r.verdict === 'strong') for (const tf of RADAR_TFS) {
          if (tf === r.tf) continue;
          try { const d = await getCandles(r.symbol, tf); biases[tf] = d.mode === 'live' ? quickBiasOf(cleanCandles(d.candles).slice(0, -1)) : null; } catch { biases[tf] = null; }
          await pause(15);
        }
      }
      r.align = mtfAlignment(biases, r.tf);
      r.q = qualityScore({ r, candles: closed, smf, mtf: r.align });
      r.smfBias = smf?.bias || null;
      // no strong signal against the higher timeframes, and never on a delayed feed
      if (r.verdict === 'strong' && (r.align.htfAgainst || !r.data.live)) r.verdict = 'weak';
      await pause(10);   // one market per task: the page stays responsive on phones
    }
  }

  async function scan() {
    const my = ++token;
    const settings = store.get('settings');
    const out = [];
    const failed = [];
    $('[data-status]').innerHTML = `<span class="spinner"></span> ${esc(t('tools.radar.scanning'))}`;
    el.classList.add('is-scanning');
    const frames = st.tf === 'all' ? TFS : [st.tf];
    for (const inst of INSTRUMENTS) {
      if (isUnavailable(inst.symbol)) continue;
      const per = {};
      let demo = false;
      for (const tf of frames) {
        try {
          const res = await analyse(inst, tf, settings);
          if (my !== token) return;
          if (res.demo) { demo = true; continue; }
          if (res.r) per[tf] = res.r;
        } catch { /* this frame is skipped */ }
        await pause(20);
      }
      const list = Object.values(per);
      if (!list.length) { if (demo || frames.length) failed.push(inst.symbol); continue; }
      // All-frames mode: the headline reading is the best STRONG frame (else the best of the rest); the other frames are shown as chips.
      const ranked = [...list].sort((x, y) => (y.verdict === 'strong') - (x.verdict === 'strong') || y.score - x.score);
      const head = { ...ranked[0] };
      if (frames.length > 1) {
        head.mtf = per;
        const strongSame = list.filter((x) => x.verdict === 'strong' && x.direction === head.direction).length;
        const strongOpp = list.filter((x) => x.verdict === 'strong' && x.direction !== head.direction).length;
        // a strong frame is dropped to "weak" when the other strong frames point the other way
        if (head.verdict === 'strong' && strongOpp >= strongSame && strongOpp > 0) head.verdict = 'weak';
      }
      out.push(head);
    }
    if (my !== token || !el.isConnected) return;
    el.classList.remove('is-scanning');
    out.sort((a, b) => b.score - a.score);
    lastOut = out; lastFailed = failed;
    render(out, failed);
    await enrich(out, frames, my);   // v233: quality score, real timeframe alignment, data freshness → then the tracker
    if (my !== token || !el.isConnected) return;
    out.sort((a, b) => (b.verdict === 'strong') - (a.verdict === 'strong') || (b.q?.score ?? b.score) - (a.q?.score ?? a.score));
    render(out, failed);
    recordOpportunities(out.filter((r) => r.verdict === 'strong' && r.q && r.q.score >= 60 && r.data?.live).map((r) => ({ r, q: r.q })));
  }
  scan();
  whileMounted(el, scan, 60_000);
}
