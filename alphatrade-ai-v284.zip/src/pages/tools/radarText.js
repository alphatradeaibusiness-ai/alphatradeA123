// Alpha Radar Pro (v233) — words for the new radar tabs (Arabic / English; other languages fall back to English).
import { tx } from '../../i18n/tx.js';
import { getLang } from '../../i18n/index.js';
import { INSTRUMENTS } from '../../config/instruments.js';
import { esc } from '../../utils/dom.js';
import '../../styles/radarPro.css';

export const L = (ar, en) => tx({ ar, en });
export const isAr = () => getLang() === 'ar';
export const TF_NAME = () => ({ '5m': L('5 دقايق', '5m'), '15m': L('15 دقيقة', '15m'), '1h': L('ساعة', '1h'), '4h': L('4 ساعات', '4h'), '1D': L('يوم', '1D') });

export const PART = () => ({ trend: L('قوة الاتجاه', 'Trend strength'), momentum: L('الزخم', 'Momentum'), structure: L('هيكل السوق', 'Market structure'), liquidity: L('السيولة', 'Liquidity'),
  entry: L('جودة الدخول', 'Entry quality'), mtf: L('توافق الفريمات', 'Timeframe alignment'), volatility: L('التقلّب', 'Volatility'), history: L('أداء الاستراتيجية تاريخياً', 'Historical strategy performance') });
export const GRADE = () => ({ exceptional: L('فرصة استثنائية', 'Exceptional setup'), strong: L('فرصة قوية', 'Strong setup'), good: L('فرصة جيدة', 'Good setup'), moderate: L('فرصة متوسطة', 'Moderate setup'), weak: L('فرصة ضعيفة', 'Weak setup') });
const ZONE = () => ({ premium: L('منطقة غالية (Premium)', 'premium'), discount: L('منطقة رخيصة (Discount)', 'discount') });
const SIDE = () => ({ buy: L('سيولة فوق القمم (BSL)', 'buy-side (BSL)'), sell: L('سيولة تحت القيعان (SSL)', 'sell-side (SSL)') });

/** One reason line of a score part. */
export function whyText(w) {
  const p = w.params || {};
  const m = {
    trendFull: L('الاتجاه كامل مع الصفقة (السعر و EMA 50 فوق/تحت EMA 200)', 'full trend with the trade (price and EMA 50 on the right side of EMA 200)'),
    trendPartial: L('اتجاه جزئي مع الصفقة', 'partial trend with the trade'), trendAgainst: L('الاتجاه ضد الصفقة', 'trend against the trade'),
    rsiOk: L(`RSI ${p.v} بمنطقة صحية`, `RSI ${p.v} in a healthy zone`), rsiOff: L(`RSI ${p.v} مش لصالح الصفقة`, `RSI ${p.v} not in favour`),
    macdWith: L('MACD مع الاتجاه', 'MACD with the trade'), macdRising: L('هيستوجرام MACD عم يقوى', 'MACD histogram strengthening'), macdAgainst: L('MACD ضد الصفقة', 'MACD against the trade'),
    momWith: L(`الزخم ${p.v} مع الصفقة`, `momentum ${p.v} with the trade`),
    structWith: L(`${p.kind} مع الصفقة قبل ${p.ago} شمعة`, `${p.kind} with the trade, ${p.ago} candles ago`), structAgainst: L(`آخر كسر (${p.kind}) ضد الصفقة`, `last break (${p.kind}) against the trade`), structNone: L('ما في كسر هيكل واضح', 'no clear structure break'),
    sweepWith: L(`سحب ${SIDE()[p.side]} قبل ${p.ago} شمعة`, `${SIDE()[p.side]} swept ${p.ago} candles ago`), roomToTarget: L(`مسافة للهدف السيولي ${p.atr}× ATR`, `room to the liquidity target ${p.atr}× ATR`),
    targetClose: L(`الهدف السيولي قريب (${p.atr}× ATR)`, `liquidity target close (${p.atr}× ATR)`), noTarget: L('ما في هدف سيولة مفتوح بالاتجاه', 'no open liquidity target in the direction'),
    zoneGood: L(`الدخول من ${ZONE()[p.zone]}`, `entry from ${ZONE()[p.zone]}`), zoneBad: L(`الدخول من ${ZONE()[p.zone]} (مش مثالي)`, `entry from ${ZONE()[p.zone]} (not ideal)`), atZone: L(`السعر عند ${p.kind} غير مُختبر`, `price at an untested ${p.kind}`),
    mtfScore: L(`توافق الفريمات ${p.v}%`, `timeframe alignment ${p.v}%`), htfAgainst: L('الفريم الأعلى ضد الصفقة — الدرجة محدودة بـ 59', 'a higher timeframe contradicts — score capped at 59'), mtfUnknown: L('الفريمات الأعلى ما انفحصت', 'higher timeframes not checked'),
    volOk: L(`تقلّب طبيعي (${p.pct}%)`, `normal volatility (${p.pct}%)`), volSpike: L('قفزة تقلّب — خطر', 'volatility spike — risky'), volDead: L('سوق ميت', 'dead market'), volUnknown: L('التقلّب غير معروف', 'volatility unknown'),
    histOk: L(`الاستراتيجية نجحت ${p.win}% بآخر ${p.n} صفقة اختبار`, `strategy won ${p.win}% of its last ${p.n} test trades`), histFew: L(`صفقات اختبار قليلة (${p.n})`, `few test trades (${p.n})`),
  };
  return m[w.key] || w.key;
}
export function scenarioText(s, fmt) {
  const tg = s.target != null ? fmt(s.target) : null; const inv = s.invalidation != null ? fmt(s.invalidation) : null;
  const m = {
    sweepReversalUp: L('انسحبت السيولة تحت القيعان ورجع السعر — سيناريو صعود محتمل', 'sell-side liquidity was swept and price came back — a possible move up'),
    sweepReversalDown: L('انسحبت السيولة فوق القمم ورجع السعر — سيناريو هبوط محتمل', 'buy-side liquidity was swept and price came back — a possible move down'),
    continuationUp: L('الهيكل صاعد — سيناريو استمرار صعود محتمل', 'bullish structure — a possible continuation up'), continuationDown: L('الهيكل هابط — سيناريو استمرار هبوط محتمل', 'bearish structure — a possible continuation down'),
    altDown: L('السيناريو البديل: هبوط', 'alternative: down'), altUp: L('السيناريو البديل: صعود', 'alternative: up'), range: L('ما في اتجاه واضح — السعر بين مناطق سيولة', 'no clear direction — price between liquidity areas'),
  };
  return `${m[s.key] || s.key}${tg ? L(` · هدف محتمل ${tg}`, ` · possible target ${tg}`) : ''}${inv ? L(` · يُلغى إذا تجاوز ${inv}`, ` · invalid beyond ${inv}`) : ''}`;
}
export const STATUS = () => ({ detected: L('مرصودة', 'Detected'), waiting: L('بانتظار الدخول', 'Waiting for entry'), triggered: L('تفعّل الدخول', 'Entry triggered'), tp1: L('الهدف 1', 'TP1 hit'), tp2: L('الهدف 2', 'TP2 hit'),
  tp3: L('الهدف 3', 'TP3 hit'), sl: L('وقف الخسارة', 'Stop loss hit'), cancelled: L('ملغاة', 'Cancelled'), expired: L('منتهية الصلاحية', 'Expired') });
export const DATA = () => ({ stale: L('السعر متأخر — مش مباشر', 'Price is delayed — not live'), closed: L('السوق مسكّر هلّق', 'Market closed now'), bad: L('بيانات تالفة', 'Corrupt data'),
  gaps: L('شموع ناقصة', 'Missing candles'), duplicates: L('شموع مكرّرة', 'Duplicate candles'), noLive: L('ما في بيانات حيّة لهالسوق هلّق', 'No live data for this market right now') });

export function marketSelect(name, value) {
  const groups = [['crypto', L('كريبتو', 'Crypto')], ['metal', L('معادن', 'Metals')], ['forex', L('فوركس', 'Forex')], ['index', L('مؤشرات', 'Indices')], ['energy', L('طاقة', 'Energy')]];
  return `<select class="input" data-${name} aria-label="${esc(L('السوق', 'Market'))}">${groups.map(([g, n]) => `<optgroup label="${esc(n)}">${INSTRUMENTS.filter((i) => i.type === g).map((i) => `<option value="${esc(i.symbol)}" ${i.symbol === value ? 'selected' : ''}>${esc(i.symbol)}</option>`).join('')}</optgroup>`).join('')}</select>`;
}
export function tfSeg(name, value, tfs = ['5m', '15m', '1h', '4h', '1D']) {
  const N = TF_NAME();
  return `<div class="seg" data-${name} role="group">${tfs.map((tf) => `<button type="button" data-v="${tf}" class="${tf === value ? 'is-on' : ''}" aria-pressed="${tf === value}">${esc(N[tf])}</button>`).join('')}</div>`;
}
