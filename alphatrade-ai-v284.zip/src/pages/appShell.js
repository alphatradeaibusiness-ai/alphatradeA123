// Authenticated app shell: header, Demo-Mode banner, dashboard and secondary pages.
import { h } from '../utils/dom.js';
import { restartClass } from '../utils/motion.js';
import { icons } from '../components/icons.js';
import { t } from '../i18n/index.js';
import { renderHeader, setActiveNav } from '../components/header.js';
import { createDashboard } from './dashboard.js';
import { appBackdrop } from '../components/appBackdrop.js';
import { createSignalBar } from '../components/signalBar.js';
import { startSignals, signalState, onSignals } from '../services/signals.js';
import { startElite } from '../services/eliteFeed.js';
import { startRadarTracker } from '../services/radarTracker.js';
// v144: AI keys live only on the server now — remove any key an older version kept in this browser.
try { ['aiKey', 'aiProvider'].forEach((k) => storage.remove(k)); } catch { /* storage unavailable */ }
import { storage } from '../utils/storage.js';
import { ENFORCE, canNav } from '../config/entitlements.js';
import { auth } from '../services/auth/index.js';
import { startMembers } from '../services/members.js';
import { startAiTradeWatch } from '../services/aiTradeWatch.js';
import { runUnmount } from './tools/common.js';
import { hubOf } from './tools/hubMap.js';
import { introDone } from '../components/loginIntro.js';
import { startAlerts } from '../services/alerts.js';

import '../styles/pro.css';

const SUB_ALIAS = { 'radar-risk': 'risk', learn: 'strategies' };

let loadToken = 0;
/** Each page is its own chunk, fetched the first time it is opened (the home dashboard is the only one in the first download). */
const PAGES = {
  guide: () => import('./subpages.js').then((m) => m.renderGuide()),
  strategies: () => import('./subpages.js').then((m) => m.renderStrategies()),
  markets: () => import('./markets.js').then((m) => m.renderMarkets()),
  indicators: (_, dash) => import('./subpages.js').then((m) => m.renderIndicators({ getDashboard: dash })),
  pricing: () => import('./pricing.js').then((m) => m.renderPricing()),
  profile: () => import('./profile.js').then((m) => m.renderProfile()),
  monthly: () => import('./monthly.js').then((m) => m.renderMonthly()),
  signals: () => import('./signals.js').then((m) => m.renderSignals()),
  elite: () => import('./elite.js').then((m) => m.renderElite()),
  trust: () => import('./trust.js').then((m) => m.renderTrust()),
  legal: () => import('./legal.js').then((m) => m.renderLegal()),
  'ai-key': () => import('./tools/aiKey.js').then((m) => m.renderAiKey()),
  payments: () => import('./tools/payments.js').then((m) => m.renderPayments()),
  billing: () => import('./billing.js').then((m) => m.renderBilling()),
  connect: () => import('./connect.js').then((m) => m.renderConnect()),
  contest: () => import('./contest.js').then((m) => m.renderContest()),
  'ai-signal': () => import('./aiSignal.js').then((m) => m.renderAiSignal()),
  academy: () => import('./academy.js').then((m) => m.renderAcademy()),
  bank: () => import('./tools/bank.js').then((m) => m.renderBank()),
  risk: (_, dash) => import('./tools/risk.js').then((m) => m.renderRisk({ getDashboard: dash })),
  alpha: (_, dash) => import('./alpha.js').then((m) => m.renderAlpha({ getDashboard: dash })),
  support: () => import('./community.js').then((m) => m.renderSupport()),
  live: () => import('./community.js').then((m) => m.renderLive()),
  feedback: () => import('./community.js').then((m) => m.renderFeedback()),
  rooms: () => import('./rooms.js').then((m) => m.renderRooms()),
  'rooms-admin': () => import('./rooms.js').then((m) => m.renderRoomsAdmin()),
  mentors: () => import('./mentors.js').then((m) => m.renderMentors()),
  challenges: () => import('./challenges.js').then((m) => m.renderChallenges()),
  studio: () => import('./studio.js').then((m) => m.renderStudio()),
  council: () => import('./council.js').then((m) => m.renderCouncil()),
  liquidity: () => import('./liquidity.js').then((m) => m.renderLiquidity()),
  partners: () => import('./partners.js').then((m) => m.renderPartners()),
  'partners-admin': () => import('./partners.js').then((m) => m.renderPartnersAdmin()),
  mt5: () => import('./mt5.js').then((m) => m.renderMt5()),
  'admin-dashboard': () => import('./adminDashboard.js').then((m) => m.renderAdminDashboard()),
  'admin-stats': () => import('./owner.js').then((m) => m.renderAdminStats()),
  'admin-plans': () => import('./owner.js').then((m) => m.renderAdminPlans()),
};
function loadPage(sub, hub, getDashboard) {
  // v276: pages above the person's plan show which plan opens them (only when plans are enforced; otherwise everyone has the top plan).
  if (!hub && ENFORCE && !canNav(sub)) return import('../components/gate.js').then((m) => m.lockedPage(sub));
  if (hub) return import('./tools/hub.js').then((m) => m.renderHub(sub, { getDashboard }));
  return (PAGES[sub] || PAGES.guide)(sub, getDashboard);
}

let stopAiWatch = () => {};
export function createAppShell(container) {
  const root = h(`<div class="app">${appBackdrop()}
    <div class="demo-banner" role="status" hidden>${icons.alert}<span data-banner-text></span><small class="demo-why" data-banner-why hidden></small></div>
    <main class="app-main"><div class="view-home"></div><div class="view-page" hidden></div></main>
  </div>`);
  const header = renderHeader('home');
  const sigBar = createSignalBar();
  root.querySelector('.demo-banner').before(sigBar.el);
  root.querySelector('.app-fx').after(header);
  // The first market scan runs a few hundred ms of backtests: start it after the welcome animation, not under it (it made the intro stutter on phones).
  introDone().then(() => setTimeout(() => { if (root.isConnected) { startSignals(); startElite(); startRadarTracker(); startAlerts(); stopAiWatch = startAiTradeWatch(); } }, 2500));
  // sign-in alert + message centre + referral + settings sync (server side)
  const stopMembers = startMembers({ onSynced: () => { try { location.reload(); } catch { /* */ } } });
  // first visit: a short skippable tour (once per account)
  introDone().then(() => setTimeout(() => { if (root.isConnected) import('../components/tour.js').then((m) => m.maybeTour(auth.current()?.uid)).catch(() => {}); }, 1500));   // and not in the same moment as the first chart render
  container.replaceChildren(root);

  const banner = root.querySelector('.demo-banner');
  const home = root.querySelector('.view-home');
  const page = root.querySelector('.view-page');
  const dashboard = createDashboard({
    onDemoChange: (symbols, all, reasons = []) => {
      banner.hidden = symbols.length === 0;
      // short: at most 3 names on screen; the full list and the technical reason stay in the tooltip
      const names = symbols.length > 3 ? `${symbols.slice(0, 3).join(', ')} +${symbols.length - 3}` : symbols.join(', ');
      const base = all ? t('status.demoBanner') : t('status.demoPartial', { symbols: names });
      banner.querySelector('[data-banner-text]').textContent = base;
      banner.title = [symbols.join(', '), ...reasons].filter(Boolean).join('\n');
      // v275: phones have no tooltips — a tap shows the technical reason (which source failed and how), so a demo fallback can be diagnosed.
      const why = banner.querySelector('[data-banner-why]'); const txt = [...new Set(reasons.filter(Boolean))].slice(0, 4).join(' · ');
      why.textContent = txt ? `${t('status.whyDemo')}: ${txt}` : ''; banner.classList.toggle('has-why', Boolean(txt)); if (!txt) why.hidden = true;
    },
  });
  banner.addEventListener('click', () => { const why = banner.querySelector('[data-banner-why]'); if (why.textContent) why.hidden = !why.hidden; });
  home.append(dashboard.el);
  const channelAllowed=new Set(['signals','profile','pricing','trust','legal']);
  const enforceChannel=()=>{
    if(!signalState().allowance?.channelOnly)return;
    const sub=(location.hash.split('/')[2]||'home').split('?')[0];
    if(!channelAllowed.has(sub))location.hash='#/app/signals';
  };
  const offChannel=onSignals(enforceChannel);

  return {
    show(rawSub) {
      const sub = SUB_ALIAS[rawSub] || rawSub;
      if(signalState().allowance?.channelOnly&&!channelAllowed.has(sub)){location.hash='#/app/signals';return;}
      const hub = hubOf(sub);
      setActiveNav(header, hub ? hub.hub : sub || 'home');
      if (!sub || sub === 'home') {
        loadToken++;
        page.hidden = true;
        runUnmount(page);
        page.replaceChildren();
        if (home.hidden) {
          home.hidden = false;
          restartClass(home, ['page-enter'], 'page-enter');
          dashboard.onShow();
        }
        return;
      }
      home.hidden = true;
      page.hidden = false;
      runUnmount(page);   // stop the old page's timers / listeners now, not on their next tick
      page.replaceChildren();
      const mine = ++loadToken;
      loadPage(sub, hub, () => dashboard).then((el) => {
        if (mine !== loadToken) return;   // the user already went somewhere else
        page.replaceChildren(el);
        window.scrollTo({ top: 0 });
      }).catch((err) => {
        if (mine !== loadToken) return;
        console.error('page load failed', sub, err);
        // A stale tab after a deploy asks for a chunk that no longer exists: one reload fetches the new build.
        try { if (!sessionStorage.getItem('ata:chunk-reload')) { sessionStorage.setItem('ata:chunk-reload', '1'); location.reload(); } } catch { /* ignore */ }
      });
    },
    destroy() {
      stopAiWatch(); stopAiWatch = () => {};
      loadToken++;
      offChannel();
      runUnmount(page);
      dashboard.destroy();
      sigBar.destroy();
      header._cleanup?.();
      stopMembers();
      document.querySelectorAll('.side-drawer, .drawer-backdrop').forEach((n) => n.remove());
      document.documentElement.classList.remove('drawer-lock');
    },
  };
}
