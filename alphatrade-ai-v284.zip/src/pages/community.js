// Community pages: live support (voice calls with the team), live broadcasts, and customer feedback & reports.
// Everything is checked on the server (server/community.js); owner controls here are only shown to owners and the server
// refuses them for everyone else.
import { h, esc } from '../utils/dom.js';
import { BUSINESS } from '../config/business.js';
import { icons } from '../components/icons.js';
import { getLocale } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { apiRequest, apiBlobUrl } from '../services/ai/gateway.js';
import { toast } from '../components/ui.js';
import { isAdmin } from '../config/admin.js';
import { whileMounted, onUnmount } from './tools/common.js';
import '../styles/community.css';

const when = (ms) => (ms ? new Date(ms).toLocaleString(getLocale(), { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '');
export const errText = (code) => tx(({
  signin_required: { ar: 'سجّل الدخول أولًا.', en: 'Please sign in first.', he: 'יש להתחבר קודם.', es: 'Inicia sesión primero.', zh: '请先登录。' },
  auth_not_configured: { ar: 'تسجيل الدخول على السيرفر مش مفعّل (FIREBASE_PROJECT_ID).', en: 'Server sign-in is not configured (FIREBASE_PROJECT_ID).', he: 'ההתחברות בשרת לא הוגדרה.', es: 'El inicio de sesión del servidor no está configurado.', zh: '服务器登录未配置。' },
  server_missing: { ar: 'السيرفر مش شغّال على هالاستضافة.', en: 'The server is not running on this host.', he: 'השרת לא פועל באחסון הזה.', es: 'El servidor no está activo en este alojamiento.', zh: '此主机上服务器未运行。' },
  server_unreachable: { ar: 'ما قدرنا نوصل للسيرفر.', en: 'Could not reach the server.', he: 'לא ניתן להגיע לשרת.', es: 'No se pudo contactar con el servidor.', zh: '无法连接服务器。' },
  no_secret: { ar: 'السيرفر ناقصه AI_KEY_SECRET.', en: 'The server is missing AI_KEY_SECRET.', he: 'לשרת חסר AI_KEY_SECRET.', es: 'Falta AI_KEY_SECRET en el servidor.', zh: '服务器缺少 AI_KEY_SECRET。' },
  not_owner: { ar: 'هاد القسم لأصحاب الشركة بس.', en: 'This section is for the owners only.', he: 'האזור הזה לבעלים בלבד.', es: 'Esta sección es solo para los propietarios.', zh: '此部分仅限所有者。' },
  rate_limited: { ar: 'طلبات كتير، استنى شوي.', en: 'Too many requests, wait a moment.', he: 'יותר מדי בקשות, המתן רגע.', es: 'Demasiadas solicitudes, espera un momento.', zh: '请求过多，请稍候。' },
  too_many: { ar: 'وصلت الحد اليومي.', en: 'Daily limit reached.', he: 'הגעת למגבלה היומית.', es: 'Límite diario alcanzado.', zh: '已达到每日上限。' },
  text_short: { ar: 'اكتب تفاصيل أكثر.', en: 'Please write a little more detail.', he: 'כתוב קצת יותר פרטים.', es: 'Escribe un poco más de detalle.', zh: '请多写一些细节。' },
  bad_rating: { ar: 'اختار تقييم من 1 لـ 5.', en: 'Choose a rating from 1 to 5.', he: 'בחר דירוג 1 עד 5.', es: 'Elige una valoración de 1 a 5.', zh: '请选择 1 到 5 的评分。' },
  image_too_large: { ar: 'الصورة كبيرة كتير.', en: 'The image is too large.', he: 'התמונה גדולה מדי.', es: 'La imagen es demasiado grande.', zh: '图片太大。' },
  bad_image: { ar: 'نوع الصورة مش مدعوم (PNG، JPG، WEBP).', en: 'Image type not supported (PNG, JPG, WEBP).', he: 'סוג התמונה לא נתמך.', es: 'Tipo de imagen no admitido.', zh: '不支持的图片类型。' },
  call_open: { ar: 'عندك مكالمة مفتوحة.', en: 'You already have a call open.', he: 'כבר יש לך שיחה פתוחה.', es: 'Ya tienes una llamada abierta.', zh: '你已有一个通话。' },
  bad_title: { ar: 'اكتب عنوان للبث.', en: 'Enter a title.', he: 'הזן כותרת.', es: 'Escribe un título.', zh: '请输入标题。' },
  not_live: { ar: 'البث خلص أو مش من الموقع.', en: 'The broadcast ended or is not an in-site one.', he: 'השידור הסתיים.', es: 'La emisión terminó.', zh: '直播已结束。' },
  full: { ar: 'البث وصل الحد الأقصى للمشاهدين (50). جرّب بعد شوي.', en: 'The broadcast is full (50 viewers). Try again shortly.', he: 'השידור מלא (50 צופים).', es: 'La emisión está llena (50).', zh: '直播已满（50 人）。' },
  bad_url: { ar: 'رابط البث لازم يبلّش بـ https://', en: 'The stream link must start with https://', he: 'הקישור חייב להתחיל ב-https://', es: 'El enlace debe empezar por https://', zh: '直播链接必须以 https:// 开头' },
}[code]) || { ar: `صار خطأ (${code})`, en: `Something went wrong (${code})`, he: `אירעה שגיאה (${code})`, es: `Algo salió mal (${code})`, zh: `出错了 (${code})` });

/** Page header in the same style as the tool pages (works in every language). */
export function pageHead(icon, title, sub) {
  return `<header class="tool-hero card fade-in"><span class="tool-ico">${icons[icon] || icons.sparkle}</span><div><h1>${esc(title)}</h1><p class="muted">${esc(sub)}</p></div><span class="tool-mark" aria-hidden="true">${icons[icon] || ''}</span></header>`;
}
const page = (cls, inner) => h(`<section class="subpage tool cm ${cls} page-enter">${inner}</section>`);

/* ───────────────────────── Live support ───────────────────────── */
const CALL_TXT = {
  idle: { ar: 'جاهز للاتصال', en: 'Ready to call', he: 'מוכן להתקשר', es: 'Listo para llamar', zh: '可以通话' },
  mic: { ar: 'عم نطلب إذن المايكروفون…', en: 'Asking for microphone access…', he: 'מבקש גישה למיקרופון…', es: 'Pidiendo acceso al micrófono…', zh: '正在请求麦克风权限…' },
  ringing: { ar: 'عم يرن عند الفريق…', en: 'Ringing the team…', he: 'מצלצל לצוות…', es: 'Llamando al equipo…', zh: '正在呼叫团队…' },
  connecting: { ar: 'عم نوصل…', en: 'Connecting…', he: 'מתחבר…', es: 'Conectando…', zh: '连接中…' },
  active: { ar: 'متصل', en: 'Connected', he: 'מחובר', es: 'Conectado', zh: '已接通' },
  ended: { ar: 'انتهت المكالمة', en: 'Call ended', he: 'השיחה הסתיימה', es: 'Llamada finalizada', zh: '通话结束' },
  noanswer: { ar: 'ما حدا رد. جرّب بعدين أو ابعتلنا رسالة.', en: 'No answer. Try later or send us a message.', he: 'אין מענה. נסה מאוחר יותר או שלח הודעה.', es: 'Sin respuesta. Inténtalo más tarde o envíanos un mensaje.', zh: '无人接听。请稍后再试或给我们留言。' },
  failed: { ar: 'ما قدرنا نوصل المكالمة.', en: 'The call could not connect.', he: 'לא ניתן לחבר את השיחה.', es: 'No se pudo conectar la llamada.', zh: '通话无法接通。' },
  nomic: { ar: 'لازم تسمح باستعمال المايكروفون.', en: 'Microphone access is needed.', he: 'נדרשת גישה למיקרופון.', es: 'Se necesita acceso al micrófono.', zh: '需要麦克风权限。' },
};
const waitIce = (pc, ms = 4000) => new Promise((ok) => { if (pc.iceGatheringState === 'complete') return ok(); const t = setTimeout(ok, ms); pc.addEventListener('icegatheringstatechange', () => { if (pc.iceGatheringState === 'complete') { clearTimeout(t); ok(); } }); });

/** One WebRTC voice call (caller or agent side). The full SDP (with ICE candidates) is exchanged once through the server. */
function callSession({ onState, audio }) {
  let pc = null; let stream = null; let id = null; let poll = null; let timer = null; let started = 0;
  const cleanup = () => { clearInterval(poll); clearInterval(timer); poll = null; try { stream?.getTracks().forEach((t) => t.stop()); } catch { /* */ } try { pc?.close(); } catch { /* */ } pc = null; stream = null; };
  async function media() { onState('mic'); stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); return stream; }
  function peer(iceServers) {
    pc = new RTCPeerConnection({ iceServers });
    stream.getTracks().forEach((t) => pc.addTrack(t, stream));
    pc.ontrack = (e) => { audio.srcObject = e.streams[0]; audio.play?.().catch(() => {}); };
    pc.onconnectionstatechange = () => {
      if (pc?.connectionState === 'connected') { started = Date.now(); onState('active'); timer = setInterval(() => onState('active', Math.round((Date.now() - started) / 1000)), 1000); }
      if (['failed'].includes(pc?.connectionState)) { onState('failed'); end(); }
      if (['disconnected', 'closed'].includes(pc?.connectionState) && started) { onState('ended'); end(); }
    };
  }
  async function call() {
    try { await media(); } catch { onState('nomic'); return; }
    const { iceServers } = await apiRequest('GET', '/api/support/ice');
    peer(iceServers);
    await pc.setLocalDescription(await pc.createOffer({ offerToReceiveAudio: true })); await waitIce(pc);
    const r = await apiRequest('POST', '/api/support/call', { offer: pc.localDescription.sdp });
    id = r.id; onState('ringing');
    const t0 = Date.now();
    poll = setInterval(async () => {
      try {
        const st = await apiRequest('GET', `/api/support/call/${id}`);
        if (st.status === 'active' && st.answer && pc && !pc.currentRemoteDescription) { onState('connecting'); await pc.setRemoteDescription({ type: 'answer', sdp: st.answer }); }
        if (st.status === 'ended') { onState(started ? 'ended' : 'noanswer'); end(false); }
      } catch (e) { if (e.code === 'not_found') { onState(started ? 'ended' : 'noanswer'); end(false); } }
      if (!started && Date.now() - t0 > 120_000 && pc && !pc.currentRemoteDescription) { onState('noanswer'); end(); }
    }, 1500);
  }
  async function answer(callId) {
    id = callId;
    const st = await apiRequest('GET', `/api/support/call/${id}`);
    try { await media(); } catch { onState('nomic'); return; }
    const { iceServers } = await apiRequest('GET', '/api/support/ice');
    peer(iceServers);
    await pc.setRemoteDescription({ type: 'offer', sdp: st.offer });
    await pc.setLocalDescription(await pc.createAnswer()); await waitIce(pc);
    await apiRequest('POST', `/api/support/call/${id}/answer`, { answer: pc.localDescription.sdp });
    onState('connecting');
    poll = setInterval(async () => { try { const s = await apiRequest('GET', `/api/support/call/${id}`); if (s.status === 'ended') { onState('ended'); end(false); } } catch { /* keep */ } }, 2500);
  }
  function end(tell = true) { if (tell && id) apiRequest('POST', `/api/support/call/${id}/end`).catch(() => {}); cleanup(); }
  const mute = (on) => stream?.getAudioTracks().forEach((t) => { t.enabled = !on; });
  return { call, answer, end, mute, get active() { return Boolean(pc); } };
}

export function renderSupport() {
  const owner = isAdmin();
  const el = page('cm-support', `${pageHead('chat', tx({ ar: 'الدعم المباشر', en: 'Live support', he: 'תמיכה חיה', es: 'Soporte en vivo', zh: '在线客服' }), tx({ ar: 'احكي مع فريق الشركة بمكالمة صوتية من الموقع مباشرة، أو ابعتلنا رسالة.', en: 'Talk to the company team with a voice call right from the site, or send us a message.', he: 'דבר עם צוות החברה בשיחה קולית ישירות מהאתר, או שלח הודעה.', es: 'Habla con el equipo de la empresa con una llamada de voz desde el sitio, o envíanos un mensaje.', zh: '直接在网站上与公司团队语音通话，或给我们留言。' }))}
    <div class="tool-body">
      <a class="card cm-mail" href="mailto:${esc(BUSINESS.email)}?subject=${encodeURIComponent('AlphaTrade AI — Support')}"><span class="cm-mail-ico">${icons.mail}</span><span><small>${esc(tx({ ar: 'إيميل الدعم الفني', en: 'Technical support e-mail', he: 'דוא״ל תמיכה טכנית', es: 'Correo de soporte técnico', zh: '技术支持邮箱' }))}</small><b dir="ltr">${esc(BUSINESS.email)}</b></span></a>
      <article class="card tool-card cm-call" data-call>
        <div class="cm-call-ring" data-ring><span>${icons.chat}</span></div>
        <h2 data-state>${esc(tx(CALL_TXT.idle))}</h2><p class="cm-timer mono" data-timer></p>
        <div class="cm-call-actions">
          <button type="button" class="btn cm-btn-call" data-start>${icons.chat}<span>${esc(tx({ ar: 'اتصل بالفريق', en: 'Call the team', he: 'התקשר לצוות', es: 'Llamar al equipo', zh: '呼叫团队' }))}</span></button>
          <button type="button" class="btn cm-btn-mute" data-mute hidden>${esc(tx({ ar: 'كتم', en: 'Mute', he: 'השתק', es: 'Silenciar', zh: '静音' }))}</button>
          <button type="button" class="btn cm-btn-end" data-end hidden>${esc(tx({ ar: 'إنهاء', en: 'End call', he: 'סיים שיחה', es: 'Colgar', zh: '挂断' }))}</button>
        </div>
        <audio data-audio autoplay playsinline></audio>
        <p class="muted tool-note">${esc(tx({ ar: 'الصوت بيروح مباشرة بين جهازك وجهاز الفريق ومشفّر (WebRTC). الفريق بيوصله إشعار على التلفون. إذا ما حدا رد خلال دقيقتين، ابعتلنا رسالة.', en: 'Audio goes directly between your device and the team, encrypted (WebRTC). The team gets a phone notification. If nobody answers within two minutes, send us a message.', he: 'השמע עובר ישירות בין המכשיר שלך לצוות, מוצפן (WebRTC). הצוות מקבל התראה לטלפון.', es: 'El audio va directo entre tu dispositivo y el equipo, cifrado (WebRTC). El equipo recibe un aviso en el móvil.', zh: '语音在你和团队之间直接传输并加密 (WebRTC)。团队会收到手机通知。' }))}</p>
      </article>
      <div class="tool-grid">
        <a class="card tool-card cm-link" href="#/app/feedback">${icons.journal}<div><b>${esc(tx({ ar: 'ابعت رسالة أو بلاغ', en: 'Send a message or report', he: 'שלח הודעה או דיווח', es: 'Enviar un mensaje o reporte', zh: '发送消息或报告' }))}</b><span class="muted">${esc(tx({ ar: 'مع صور، وبتتابع الرد من هون', en: 'With screenshots; follow the reply here', he: 'עם צילומי מסך; עקוב אחרי התשובה', es: 'Con capturas; sigue la respuesta aquí', zh: '可附截图，在此查看回复' }))}</span></div></a>
        <a class="card tool-card cm-link" href="#/app/alpha">${icons.sparkle}<div><b>Alpha AI</b><span class="muted">${esc(tx({ ar: 'جواب فوري على أي سؤال عن الموقع', en: 'Instant answers about using the site', he: 'תשובות מיידיות על השימוש באתר', es: 'Respuestas inmediatas sobre el sitio', zh: '即时解答网站使用问题' }))}</span></div></a>
      </div>
      ${owner ? `<article class="card tool-card"><h2 class="card-title">${icons.bell}<span>${esc(tx({ ar: 'مكالمات واردة (لأصحاب الشركة)', en: 'Incoming calls (owners)', he: 'שיחות נכנסות (בעלים)', es: 'Llamadas entrantes (propietarios)', zh: '来电（所有者）' }))}</span></h2><div data-queue class="cm-queue"></div></article>` : ''}
    </div>`);
  const $ = (s) => el.querySelector(s);
  const audio = $('[data-audio]');
  let session = null;
  const fmtT = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  const setState = (k, secs) => {
    $('[data-state]').textContent = tx(CALL_TXT[k] || CALL_TXT.idle);
    $('[data-timer]').textContent = k === 'active' && secs != null ? fmtT(secs) : '';
    const live = ['mic', 'ringing', 'connecting', 'active'].includes(k);
    $('[data-ring]').className = `cm-call-ring is-${k}`;
    $('[data-start]').hidden = live; $('[data-end]').hidden = !live; $('[data-mute]').hidden = k !== 'active';
    if (!live) { session = null; $('[data-mute]').classList.remove('is-on'); }
  };
  const fail = (e) => { toast(errText(e?.code || 'unknown'), 'error'); session?.end(); setState('failed'); };
  $('[data-start]').addEventListener('click', () => { if (session) return; session = callSession({ onState: setState, audio }); session.call().catch(fail); });
  $('[data-end]').addEventListener('click', () => { session?.end(); setState('ended'); });
  $('[data-mute]').addEventListener('click', (e) => { const on = !e.currentTarget.classList.contains('is-on'); e.currentTarget.classList.toggle('is-on', on); session?.mute(on); });
  onUnmount(el, () => session?.end());
  if (owner) {
    const q = $('[data-queue]');
    const draw = async () => {
      try {
        const r = await apiRequest('GET', '/api/support/calls');
        q.innerHTML = r.items.length ? r.items.map((c) => `<div class="cm-qrow is-${c.status}"><b>${esc(c.name)}</b><span class="muted">${esc(when(c.at))}</span><span class="badge ${c.status === 'ringing' ? 'badge-live' : 'badge-muted'}">${esc(tx(CALL_TXT[c.status] || CALL_TXT.idle))}</span>${c.status === 'ringing' ? `<button type="button" class="btn btn-sm cm-btn-call" data-answer="${esc(c.id)}">${esc(tx({ ar: 'رد', en: 'Answer', he: 'ענה', es: 'Contestar', zh: '接听' }))}</button>` : ''}</div>`).join('')
          : `<p class="muted">${esc(tx({ ar: 'ما في مكالمات هلق.', en: 'No calls right now.', he: 'אין שיחות כרגע.', es: 'No hay llamadas ahora.', zh: '当前没有来电。' }))}</p>`;
      } catch (e) { q.innerHTML = `<p class="muted">${esc(errText(e.code))}</p>`; }
    };
    q.addEventListener('click', (e) => { const b = e.target.closest('[data-answer]'); if (!b || session) return; session = callSession({ onState: setState, audio }); session.answer(b.dataset.answer).catch(fail); });
    draw(); whileMounted(el, draw, 3000);
  }
  return el;
}

/* ───────────────────────── Live broadcasts ───────────────────────── */
export function renderLive() {
  const owner = isAdmin();
  const el = page('cm-live', `${pageHead('pulse', tx({ ar: 'البث المباشر', en: 'Live broadcasts', he: 'שידורים חיים', es: 'Transmisiones en vivo', zh: '直播' }), tx({ ar: 'بثوث مباشرة من أصحاب الشركة. أول ما يبلّش بث بيوصلك إشعار على التلفون.', en: 'Live broadcasts from the company owners. You get a phone notification the moment one starts.', he: 'שידורים חיים מבעלי החברה. מקבלים התראה לטלפון ברגע שמתחיל שידור.', es: 'Transmisiones en vivo de los propietarios. Recibes un aviso en el móvil al empezar.', zh: '公司所有者的直播。直播开始时你会收到手机通知。' }))}
    <div class="tool-body"><div data-now></div><div class="card cm-stage" data-stage hidden><div class="cm-player cm-video"><video data-video playsinline autoplay></video></div><div class="cm-stage-bar" data-stagebar></div></div>
      <div class="card tool-card cm-push"><span>${esc(tx({ ar: 'فعّل إشعارات التلفون لتعرف أول ما يبلّش البث.', en: 'Turn on phone notifications to know when a broadcast starts.', he: 'הפעל התראות כדי לדעת כשמתחיל שידור.', es: 'Activa las notificaciones para saber cuándo empieza.', zh: '开启手机通知，直播开始时提醒你。' }))}</span><button type="button" class="btn btn-sm btn-primary" data-push>${icons.bell}<span>${esc(tx({ ar: 'فعّل الإشعارات', en: 'Enable notifications', he: 'הפעל התראות', es: 'Activar avisos', zh: '开启通知' }))}</span></button></div>
      ${owner ? `<article class="card tool-card"><h2 class="card-title">${icons.pulse}<span>${esc(tx({ ar: 'ابدأ بث (لأصحاب الشركة)', en: 'Start a broadcast (owners)', he: 'התחל שידור (בעלים)', es: 'Iniciar transmisión (propietarios)', zh: '开始直播（所有者）' }))}</span></h2>
        <form class="tf-grid" data-start>
          <label class="tf-field tf-wide"><span>${esc(tx({ ar: 'العنوان', en: 'Title', he: 'כותרת', es: 'Título', zh: '标题' }))}</span><input class="input" name="title" maxlength="120" required></label>
          <label class="tf-field tf-wide"><span>${esc(tx({ ar: 'الموضوع', en: 'Topic', he: 'נושא', es: 'Tema', zh: '主题' }))}</span><input class="input" name="topic" maxlength="400"></label>
          <label class="tf-field tf-wide"><span>${esc(tx({ ar: 'مصدر البث', en: 'Source', he: 'מקור', es: 'Fuente', zh: '来源' }))}</span><select class="input" name="src" data-src>
            <option value="camera">${esc(tx({ ar: 'من الموقع: كاميرا ومايك', en: 'From the site: camera & mic', he: 'מהאתר: מצלמה ומיקרופון', es: 'Desde el sitio: cámara y micrófono', zh: '网站内：摄像头和麦克风' }))}</option>
            <option value="screen">${esc(tx({ ar: 'من الموقع: مشاركة الشاشة ومايك', en: 'From the site: screen share & mic', he: 'מהאתר: שיתוף מסך ומיקרופון', es: 'Desde el sitio: pantalla y micrófono', zh: '网站内：共享屏幕和麦克风' }))}</option>
            <option value="link">${esc(tx({ ar: 'رابط خارجي (YouTube Live، Twitch…)', en: 'External link (YouTube Live, Twitch…)', he: 'קישור חיצוני', es: 'Enlace externo', zh: '外部链接' }))}</option></select></label>
          <label class="tf-field tf-wide" data-urlbox hidden><span>${esc(tx({ ar: 'رابط البث', en: 'Stream link', he: 'קישור לשידור', es: 'Enlace de la transmisión', zh: '直播链接' }))}</span><input class="input mono" name="url" inputmode="url" placeholder="https://www.youtube.com/live/…"></label>
          <div class="tf-field tf-end"><button class="btn btn-primary" type="submit">${icons.pulse}<span>${esc(tx({ ar: 'ابدأ البث وأرسل الإشعار', en: 'Go live & notify', he: 'התחל ושלח התראה', es: 'Emitir y avisar', zh: '开播并通知' }))}</span></button></div>
        </form><p class="muted tool-note">${esc(tx({ ar: 'البث من الموقع بيطلع مباشرة من متصفحك للعملاء (مشفّر، بدون أي خدمة خارجية). خلّي هالصفحة مفتوحة طول البث. مناسب لعشرات المشاهدين؛ لجمهور كبير جدًا استعمل رابط خارجي.', en: 'A broadcast from the site goes straight from your browser to the customers (encrypted, no outside service). Keep this page open while live. Suits tens of viewers; for a very large audience use an external link.', he: 'שידור מהאתר עובר ישירות מהדפדפן שלך ללקוחות (מוצפן). השאר את הדף פתוח. מתאים לעשרות צופים.', es: 'La emisión desde el sitio va directa de tu navegador a los clientes (cifrada). Mantén esta página abierta. Para decenas de espectadores.', zh: '网站内直播直接从你的浏览器发送给客户（加密）。直播期间请保持此页面打开。适合数十名观众。' }))}</p></article>` : ''}
      <article class="card tool-card"><h2 class="card-title">${icons.calendar}<span>${esc(tx({ ar: 'البثوث السابقة', en: 'Past broadcasts', he: 'שידורים קודמים', es: 'Transmisiones anteriores', zh: '往期直播' }))}</span></h2><div data-hist></div></article>
    </div>`);
  const $ = (s) => el.querySelector(s);
  let key = '';
  const draw = async () => {
    try {
      const r = await apiRequest('GET', '/api/live');
      const k = JSON.stringify([r.current?.id, r.history.length, hosting, Boolean(watch)]); if (k === key) return; key = k;
      const c = r.current;
      if (!c || c.mode !== 'site') { if (watch) stopWatch(); if (hosting && !c) stopHost(false); }
      $('[data-now]').innerHTML = c ? `<article class="card cm-onair"><div class="cm-onair-top"><span class="cm-live-badge">● LIVE</span><b>${esc(c.title)}</b><span class="muted">${esc(c.host)} · ${esc(when(c.startedAt))}</span></div>
          ${c.topic ? `<p>${esc(c.topic)}</p>` : ''}
          ${c.embed ? `<div class="cm-player"><iframe src="${esc(c.embed)}" title="${esc(c.title)}" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div>` : ''}
          ${c.mode === 'site' && !hosting && !watch ? `<button type="button" class="btn btn-primary" data-join>${icons.pulse}<span>${esc(tx({ ar: 'شاهد البث هون', en: 'Watch here', he: 'צפה כאן', es: 'Ver aquí', zh: '在此观看' }))}</span></button>` : ''}
          ${c.url ? `<a class="btn" href="${esc(c.url)}" target="_blank" rel="noopener noreferrer">${icons.external}<span>${esc(tx({ ar: 'افتح البث', en: 'Open the stream', he: 'פתח את השידור', es: 'Abrir la transmisión', zh: '打开直播' }))}</span></a>` : ''}
          ${r.owner ? `<button type="button" class="btn cm-btn-end" data-end-live>${esc(tx({ ar: 'إنهاء البث', en: 'End broadcast', he: 'סיים שידור', es: 'Finalizar', zh: '结束直播' }))}</button>` : ''}</article>`
        : `<div class="card sig-empty">${icons.pulse}<span>${esc(tx({ ar: 'ما في بث مباشر هلق.', en: 'No live broadcast right now.', he: 'אין שידור חי כרגע.', es: 'No hay transmisión en vivo ahora.', zh: '当前没有直播。' }))}</span></div>`;
      $('[data-hist]').innerHTML = r.history.length ? `<ul class="cm-hist">${r.history.map((x) => `<li><b>${esc(x.title)}</b><span class="muted">${esc(x.host)} · ${esc(when(x.startedAt))}</span>${x.url ? `<a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">${icons.external}</a>` : ''}</li>`).join('')}</ul>` : `<p class="muted">—</p>`;
    } catch (e) { $('[data-now]').innerHTML = `<div class="card sig-empty"><span>${esc(errText(e.code))}</span></div>`; }
  };
  el.addEventListener('click', async (e) => {
    if (e.target.closest('[data-push]')) { import('../services/bank/push.js').then((m) => m.enablePush()).then(() => toast(tx({ ar: 'تمام', en: 'Done', he: 'בוצע', es: 'Hecho', zh: '完成' }), 'success')).catch(() => { try { Notification.requestPermission(); } catch { /* */ } }); }
    if (e.target.closest('[data-end-live]')) { try { if (hosting) stopHost(false); await apiRequest('POST', '/api/live/end', {}); key = ''; draw(); } catch (er) { toast(errText(er.code), 'error'); } }
  });
  /* ── in-site broadcast (WebRTC) ── */
  const T = (o) => esc(tx(o));
  const video = $('[data-video]'); const stage = $('[data-stage]'); const bar = $('[data-stagebar]');
  let hosting = false; let stream = null; const peers = new Map(); let hostTimer = null;
  let watch = null;   // { id, pc, timer }
  const showStage = (on) => { stage.hidden = !on; if (!on) { video.srcObject = null; bar.innerHTML = ''; } };
  async function hostTick() {
    try {
      const r = await apiRequest('GET', '/api/live/viewers', undefined, 8000);
      for (const id of r.left || []) { peers.get(id)?.close(); peers.delete(id); }
      for (const v of r.waiting || []) {
        if (peers.has(v.id)) continue;
        const pc = new RTCPeerConnection({ iceServers: r.iceServers }); peers.set(v.id, pc);
        stream.getTracks().forEach((t) => pc.addTrack(t, stream));
        pc.onconnectionstatechange = () => { if (['failed', 'closed'].includes(pc.connectionState)) { pc.close(); peers.delete(v.id); } };
        await pc.setRemoteDescription({ type: 'offer', sdp: v.offer });
        await pc.setLocalDescription(await pc.createAnswer());
        await waitIce(pc);
        await apiRequest('POST', `/api/live/viewer/${v.id}/answer`, { answer: pc.localDescription.sdp }, 8000).catch(() => { pc.close(); peers.delete(v.id); });
      }
      const n = (r.watching || []).length;
      bar.querySelector('[data-viewers]') && (bar.querySelector('[data-viewers]').textContent = tx({ ar: `${n} عم يشاهدوا`, en: `${n} watching`, he: `${n} צופים`, es: `${n} viendo`, zh: `${n} 人观看` }));
    } catch { /* keep trying while live */ }
  }
  function stopHost(callServer = true) {
    clearInterval(hostTimer); hostTimer = null;
    for (const pc of peers.values()) pc.close(); peers.clear();
    stream?.getTracks().forEach((t) => t.stop()); stream = null; hosting = false; showStage(false);
    if (callServer) apiRequest('POST', '/api/live/end', {}).catch(() => {});
  }
  async function startHost(src) {
    stream = src === 'screen'
      ? await (async () => { const sc = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 24 }, audio: false }); try { const mic = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); mic.getAudioTracks().forEach((t) => sc.addTrack(t)); } catch { /* screen without voice */ } return sc; })()
      : await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 24 } }, audio: { echoCancellation: true, noiseSuppression: true } });
    hosting = true; video.muted = true; video.srcObject = stream; showStage(true);
    bar.innerHTML = `<span class="cm-live-badge">● LIVE</span><span data-viewers>${T({ ar: '0 عم يشاهدوا', en: '0 watching', he: '0 צופים', es: '0 viendo', zh: '0 人观看' })}</span>
      <button type="button" class="btn btn-sm" data-mic>${icons.mic || ''}<span>${T({ ar: 'كتم المايك', en: 'Mute mic', he: 'השתק', es: 'Silenciar', zh: '静音' })}</span></button>
      ${src === 'camera' ? `<button type="button" class="btn btn-sm" data-cam><span>${T({ ar: 'إطفاء الكاميرا', en: 'Camera off', he: 'כבה מצלמה', es: 'Apagar cámara', zh: '关闭摄像头' })}</span></button>` : ''}
      <button type="button" class="btn btn-sm cm-btn-end" data-end-live>${T({ ar: 'إنهاء البث', en: 'End broadcast', he: 'סיים שידור', es: 'Finalizar', zh: '结束直播' })}</button>`;
    stream.getVideoTracks()[0]?.addEventListener('ended', () => { stopHost(); key = ''; draw(); });   // the browser's "stop sharing"
    hostTimer = setInterval(hostTick, 2000); hostTick();
  }
  function stopWatch() {
    if (!watch) return; clearInterval(watch.timer); try { watch.pc.close(); } catch { /* */ }
    apiRequest('POST', `/api/live/watch/${watch.id}/leave`, {}).catch(() => {}); watch = null; showStage(false);
  }
  async function startWatch() {
    const pc = new RTCPeerConnection({ iceServers: (await apiRequest('GET', '/api/support/ice', undefined, 8000).catch(() => ({}))).iceServers || [{ urls: 'stun:stun.l.google.com:19302' }] });
    pc.addTransceiver('video', { direction: 'recvonly' }); pc.addTransceiver('audio', { direction: 'recvonly' });
    const remote = new MediaStream(); pc.ontrack = (ev) => { remote.addTrack(ev.track); video.srcObject = remote; };
    await pc.setLocalDescription(await pc.createOffer()); await waitIce(pc);
    const r = await apiRequest('POST', '/api/live/watch', { offer: pc.localDescription.sdp }, 8000);
    watch = { id: r.id, pc, timer: null }; video.muted = false; showStage(true);
    bar.innerHTML = `<span class="muted" data-wstate>${T({ ar: 'عم نوصل للبث…', en: 'Connecting…', he: 'מתחבר…', es: 'Conectando…', zh: '连接中…' })}</span><button type="button" class="btn btn-sm" data-leave>${T({ ar: 'خروج', en: 'Leave', he: 'יציאה', es: 'Salir', zh: '离开' })}</button>`;
    pc.onconnectionstatechange = () => { const st = bar.querySelector('[data-wstate]'); if (!st) return; st.textContent = pc.connectionState === 'connected' ? tx({ ar: '● مباشر', en: '● Live', he: '● חי', es: '● En vivo', zh: '● 直播中' }) : ['failed', 'disconnected'].includes(pc.connectionState) ? tx({ ar: 'انقطع الاتصال — جرّب مرة تانية', en: 'Connection lost — try again', he: 'החיבור נותק', es: 'Conexión perdida', zh: '连接中断' }) : st.textContent; };
    watch.timer = setInterval(async () => {
      if (!watch) return;
      try { const st = await apiRequest('GET', `/api/live/watch/${watch.id}`, undefined, 8000); if (st.answer && !pc.remoteDescription) await pc.setRemoteDescription({ type: 'answer', sdp: st.answer }); }
      catch (er) { if (er.code === 'not_found') { stopWatch(); toast(T({ ar: 'انتهى البث', en: 'The broadcast ended', he: 'השידור הסתיים', es: 'La emisión terminó', zh: '直播已结束' }), 'info'); key = ''; draw(); } }
    }, 2000);
  }
  el.addEventListener('click', async (e) => {
    if (e.target.closest('[data-join]')) { try { await startWatch(); draw(); } catch (er) { toast(errText(er.code || 'server_unreachable'), 'error'); } }
    if (e.target.closest('[data-leave]')) { stopWatch(); draw(); }
    const mic = e.target.closest('[data-mic]'); if (mic && stream) { const t = stream.getAudioTracks(); const on = !t[0]?.enabled; t.forEach((x) => { x.enabled = on; }); mic.querySelector('span').textContent = on ? tx({ ar: 'كتم المايك', en: 'Mute mic', he: 'השתק', es: 'Silenciar', zh: '静音' }) : tx({ ar: 'تشغيل المايك', en: 'Unmute mic', he: 'בטל השתקה', es: 'Activar micro', zh: '取消静音' }); }
    const cam = e.target.closest('[data-cam]'); if (cam && stream) { const t = stream.getVideoTracks(); const on = !t[0]?.enabled; t.forEach((x) => { x.enabled = on; }); cam.querySelector('span').textContent = on ? tx({ ar: 'إطفاء الكاميرا', en: 'Camera off', he: 'כבה מצלמה', es: 'Apagar cámara', zh: '关闭摄像头' }) : tx({ ar: 'تشغيل الكاميرا', en: 'Camera on', he: 'הפעל מצלמה', es: 'Encender cámara', zh: '打开摄像头' }); }
  });
  $('[data-src]')?.addEventListener('change', (e) => { $('[data-urlbox]').hidden = e.target.value !== 'link'; });
  $('[data-start]')?.addEventListener('submit', async (e) => {
    e.preventDefault(); const f = e.currentTarget; const b = f.querySelector('button'); b.disabled = true;
    const src = f.src.value;
    try {
      if (src !== 'link') await startHost(src);   // camera / screen permission first: nothing is announced if it is refused
      const r = await apiRequest('POST', '/api/live/start', { title: f.title.value, topic: f.topic.value, url: src === 'link' ? (f.url.value.trim() || undefined) : undefined });
      toast(tx({ ar: `بدأ البث، وانبعت إشعار لـ ${r.sent}`, en: `Live — ${r.sent} notified`, he: `בשידור — ${r.sent} קיבלו התראה`, es: `En vivo — ${r.sent} avisados`, zh: `已开播 — 已通知 ${r.sent} 人` }), 'success'); f.reset(); $('[data-urlbox]').hidden = true; key = ''; draw();
    } catch (er) {
      if (hosting) stopHost(false);
      toast(er?.name === 'NotAllowedError' ? tx({ ar: 'لازم تسمح للموقع بالكاميرا/الشاشة والمايك.', en: 'Allow the site to use the camera/screen and microphone.', he: 'יש לאשר גישה למצלמה ולמיקרופון.', es: 'Permite el acceso a la cámara/pantalla y al micrófono.', zh: '请允许网站使用摄像头/屏幕和麦克风。' }) : errText(er.code || 'server_unreachable'), 'error');
    }
    b.disabled = false;
  });
  // leaving the page ends what this page started
  onUnmount(el, () => { if (hosting) stopHost(); stopWatch(); });
  window.addEventListener('pagehide', () => { if (hosting) stopHost(); else stopWatch(); }, { once: true });
  draw(); whileMounted(el, draw, 5000);
  return el;
}

/* ───────────────────────── Feedback & reports ───────────────────────── */
const KIND = { rating: { ar: 'تقييم', en: 'Rating', he: 'דירוג', es: 'Valoración', zh: '评分' }, suggestion: { ar: 'اقتراح', en: 'Suggestion', he: 'הצעה', es: 'Sugerencia', zh: '建议' }, bug: { ar: 'مشكلة بالتطبيق', en: 'App problem', he: 'בעיה באפליקציה', es: 'Problema en la app', zh: '应用问题' } };
const STATUS = { new: { ar: 'جديد', en: 'New', he: 'חדש', es: 'Nuevo', zh: '新' }, review: { ar: 'قيد المراجعة', en: 'Under review', he: 'בבדיקה', es: 'En revisión', zh: '审核中' }, progress: { ar: 'قيد التنفيذ', en: 'In progress', he: 'בטיפול', es: 'En curso', zh: '处理中' }, resolved: { ar: 'تم الحل', en: 'Resolved', he: 'נפתר', es: 'Resuelto', zh: '已解决' } };

/** Shrinks a picture to ≤ 1600 px as JPEG so it stays under the server's 1.5 MB limit. */
function shrink(file) {
  return new Promise((ok, no) => {
    if (!/^image\/(png|jpeg|webp)$/.test(file.type)) { no(new Error('bad_image')); return; }
    const url = URL.createObjectURL(file); const img = new Image();
    img.onload = () => { const k = Math.min(1, 1600 / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); ok(c.toDataURL('image/jpeg', 0.85)); };
    img.onerror = () => { URL.revokeObjectURL(url); no(new Error('bad_image')); };
    img.src = url;
  });
}

export function renderFeedback() {
  const el = page('cm-feedback', `${pageHead('journal', tx({ ar: 'آراء العملاء والبلاغات', en: 'Feedback & reports', he: 'משוב ודיווחים', es: 'Opiniones y reportes', zh: '意见与问题反馈' }), tx({ ar: 'قيّم التطبيق، اقترح تحسينات، أو بلّغ عن مشكلة مع صور. بتتابع حالة كل بلاغ والرد عليه من هون.', en: 'Rate the app, suggest improvements or report a problem with screenshots. Follow each report\'s status and reply here.', he: 'דרג את האפליקציה, הצע שיפורים או דווח על בעיה עם צילומי מסך.', es: 'Valora la app, sugiere mejoras o reporta un problema con capturas.', zh: '为应用评分、提出建议或附截图报告问题。' }))}
    <div class="tool-body">
      <article class="card tool-card"><h2 class="card-title">${icons.plus}<span>${esc(tx({ ar: 'رسالة جديدة', en: 'New message', he: 'הודעה חדשה', es: 'Nuevo mensaje', zh: '新消息' }))}</span></h2>
        <form class="cm-fb" data-form>
          <div class="seg" data-kind>${Object.keys(KIND).map((k, i) => `<button type="button" data-v="${k}" class="${i === 2 ? 'is-on' : ''}">${esc(tx(KIND[k]))}</button>`).join('')}</div>
          <div class="cm-stars" data-stars hidden>${[1, 2, 3, 4, 5].map((n) => `<button type="button" data-star="${n}" aria-label="${n}">★</button>`).join('')}</div>
          <textarea class="input" name="text" rows="4" maxlength="2000" placeholder="${esc(tx({ ar: 'اكتب التفاصيل: شو صار، بأي صفحة، وعلى أي جهاز…', en: 'Describe it: what happened, on which page, on which device…', he: 'תאר: מה קרה, באיזה עמוד, באיזה מכשיר…', es: 'Descríbelo: qué pasó, en qué página, en qué dispositivo…', zh: '请描述：发生了什么、在哪个页面、什么设备…' }))}"></textarea>
          <label class="cm-attach">${icons.camera}<span>${esc(tx({ ar: 'أرفق صور (حتى 3)', en: 'Attach images (up to 3)', he: 'צרף תמונות (עד 3)', es: 'Adjuntar imágenes (hasta 3)', zh: '附加图片（最多 3 张）' }))}</span><input type="file" accept="image/png,image/jpeg,image/webp" multiple hidden data-files></label>
          <div class="cm-thumbs" data-thumbs></div>
          <button class="btn btn-primary" type="submit">${icons.send}<span>${esc(tx({ ar: 'إرسال', en: 'Send', he: 'שלח', es: 'Enviar', zh: '发送' }))}</span></button>
        </form></article>
      <article class="card tool-card"><div class="tool-head"><h2 class="card-title">${icons.bell}<span data-list-title></span></h2><div class="seg" data-filter hidden>${['all', ...Object.keys(STATUS)].map((k, i) => `<button type="button" data-f="${k}" class="${i ? '' : 'is-on'}">${esc(k === 'all' ? tx({ ar: 'الكل', en: 'All', he: 'הכול', es: 'Todos', zh: '全部' }) : tx(STATUS[k]))}</button>`).join('')}</div></div><div data-list class="cm-list"></div></article>
    </div>`);
  const $ = (s) => el.querySelector(s);
  const form = $('[data-form]');
  let kind = 'bug'; let rating = 0; let images = []; let owner = false; let filter = 'all'; let items = [];
  const thumbs = () => { $('[data-thumbs]').innerHTML = images.map((src, i) => `<span class="cm-thumb"><img src="${src}" alt=""><button type="button" data-rm="${i}" aria-label="remove">×</button></span>`).join(''); };
  $('[data-kind]').addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (!b) return; kind = b.dataset.v; $('[data-kind]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b)); $('[data-stars]').hidden = kind !== 'rating'; });
  $('[data-stars]').addEventListener('click', (e) => { const b = e.target.closest('[data-star]'); if (!b) return; rating = Number(b.dataset.star); $('[data-stars]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', Number(x.dataset.star) <= rating)); });
  $('[data-files]').addEventListener('change', async (e) => {
    for (const f of [...e.target.files].slice(0, 3 - images.length)) { try { images.push(await shrink(f)); } catch { toast(errText('bad_image'), 'error'); } }
    e.target.value = ''; thumbs();
  });
  $('[data-thumbs]').addEventListener('click', (e) => { const b = e.target.closest('[data-rm]'); if (b) { images.splice(Number(b.dataset.rm), 1); thumbs(); } });
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); const b = form.querySelector('[type=submit]'); b.disabled = true;
    try { await apiRequest('POST', '/api/feedback', { kind, rating: kind === 'rating' ? rating : undefined, text: form.text.value, images }, 60_000); toast(tx({ ar: 'وصلتنا رسالتك، شكرًا!', en: 'Thanks — we received it!', he: 'תודה — קיבלנו!', es: '¡Gracias, lo recibimos!', zh: '谢谢，我们已收到！' }), 'success'); form.reset(); images = []; rating = 0; thumbs(); load(); }
    catch (er) { toast(errText(er.code), 'error'); }
    b.disabled = false;
  });
  const draw = () => {
    $('[data-list-title]').textContent = owner ? tx({ ar: 'كل البلاغات (لأصحاب الشركة)', en: 'All reports (owners)', he: 'כל הדיווחים (בעלים)', es: 'Todos los reportes (propietarios)', zh: '所有报告（所有者）' }) : tx({ ar: 'رسائلي', en: 'My messages', he: 'ההודעות שלי', es: 'Mis mensajes', zh: '我的消息' });
    $('[data-filter]').hidden = !owner;
    const list = items.filter((x) => filter === 'all' || x.status === filter);
    $('[data-list]').innerHTML = list.length ? list.map((x) => `<div class="cm-item is-${x.status}">
        <div class="cm-item-top"><span class="badge">${esc(tx(KIND[x.kind]))}</span>${x.rating ? `<span class="cm-rate">${'★'.repeat(x.rating)}${'☆'.repeat(5 - x.rating)}</span>` : ''}<span class="cm-status is-${x.status}">${esc(tx(STATUS[x.status]))}</span><span class="muted">${owner && x.name ? `${esc(x.name)} · ` : ''}${esc(when(x.at))}</span></div>
        ${x.text ? `<p dir="auto">${esc(x.text)}</p>` : ''}
        ${x.images.length ? `<div class="cm-thumbs">${x.images.map((i) => `<span class="cm-thumb"><img data-img="${esc(i)}" alt=""></span>`).join('')}</div>` : ''}
        ${x.replies.map((r) => `<div class="cm-reply"><b>${esc(tx({ ar: 'رد الفريق', en: 'Team reply', he: 'תשובת הצוות', es: 'Respuesta del equipo', zh: '团队回复' }))}</b><p dir="auto">${esc(r.text)}</p><span class="muted">${esc(when(r.at))}</span></div>`).join('')}
        ${owner ? `<div class="cm-admin" data-id="${esc(x.id)}"><select class="select" data-status>${Object.keys(STATUS).map((k) => `<option value="${k}" ${k === x.status ? 'selected' : ''}>${esc(tx(STATUS[k]))}</option>`).join('')}</select><input class="input" data-reply maxlength="1000" placeholder="${esc(tx({ ar: 'رد على العميل (اختياري)', en: 'Reply to the customer (optional)', he: 'תשובה ללקוח (אופציונלי)', es: 'Responder al cliente (opcional)', zh: '回复客户（可选）' }))}"><button type="button" class="btn btn-sm btn-primary" data-save>${esc(tx({ ar: 'حفظ', en: 'Save', he: 'שמור', es: 'Guardar', zh: '保存' }))}</button></div>` : ''}
      </div>`).join('') : `<div class="sig-empty">${icons.journal}<span>${esc(tx({ ar: 'ما في رسائل لسا.', en: 'No messages yet.', he: 'אין הודעות עדיין.', es: 'Aún no hay mensajes.', zh: '暂无消息。' }))}</span></div>`;
    el.querySelectorAll('img[data-img]').forEach((img) => apiBlobUrl(`/api/feedback/img/${img.dataset.img}`).then((u) => { img.src = u; }).catch(() => {}));
  };
  $('[data-filter]').addEventListener('click', (e) => { const b = e.target.closest('[data-f]'); if (!b) return; filter = b.dataset.f; $('[data-filter]').querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b)); draw(); });
  $('[data-list]').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-save]'); if (!b) return; const row = b.closest('[data-id]');
    try { await apiRequest('PATCH', `/api/feedback/${row.dataset.id}`, { status: row.querySelector('[data-status]').value, reply: row.querySelector('[data-reply]').value }); toast(tx({ ar: 'انحفظ، وانبعت إشعار للعميل', en: 'Saved — the customer was notified', he: 'נשמר — הלקוח קיבל התראה', es: 'Guardado — se avisó al cliente', zh: '已保存 — 已通知客户' }), 'success'); load(); }
    catch (er) { toast(errText(er.code), 'error'); }
  });
  async function load() { try { const r = await apiRequest('GET', '/api/feedback'); owner = r.owner; items = r.items; draw(); } catch (e) { $('[data-list]').innerHTML = `<p class="muted">${esc(errText(e.code))}</p>`; } }
  load();
  return el;
}
