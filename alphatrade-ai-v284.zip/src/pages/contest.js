// Monthly contest: ranks only saved assistant trades that the SERVER judged on real prices and that were saved right away.
import { h, esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { icons } from '../components/icons.js';
import { toast } from '../components/ui.js';
import { apiRequest } from '../services/ai/gateway.js';

const L = (ar, en) => (getLang() !== 'ar' ? en : ar);
export function renderContest() {
  const el = h(`<section class="subpage contest page-enter">
    <header class="subpage-head"><h1>${esc(L('مسابقة الشهر', 'Monthly contest'))}</h1><p class="muted">${esc(L('مين بيعمل أحسن نتيجة هالشهر بصفقات المساعد؟ الأول بياخد شهر مجاني.', 'Who makes the best result this month with assistant trades? First place wins a free month.'))}</p></header>
    <div data-c><article class="card tool-card"><p class="muted">…</p></article></div></section>`);
  const box = el.querySelector('[data-c]');
  const load = () => apiRequest('GET', '/api/contest').then((c) => {
    box.innerHTML = `<div class="bl-grid">
      <article class="card tool-card">
        <h2 class="card-title">${icons.trophy || ''}<span>${esc(L('القواعد', 'Rules'))}</span></h2>
        <ul class="tool-list">
          <li>${esc(L('بتنحسب بس صفقات المساعد اللي انحفظت وقت الخطة، والسيرفر حكم عليها بأسعار Binance الحقيقية (كريبتو). ما في صفقات بتنكتب باليد.', 'Only assistant trades saved when the plan was made and judged by the server on real Binance prices (crypto). Hand-entered results never count.'))}</li>
          <li>${esc(L(`أقل شي ${c.minTrades} صفقات مسكّرة بالشهر. الترتيب حسب مجموع الـ R (كل صفقة بين −1.5R و +10R).`, `At least ${c.minTrades} closed trades in the month. Ranked by total R (each trade counted between −1.5R and +10R).`))}</li>
          <li>${esc(L('بيظهر اسمك المستعار بس. الجائزة شهر مجاني بيضيفه الأدمن للفائز.', 'Only your nickname is shown. The prize is a free month, added by the site owner.'))}</li>
          <li>${esc(L('المسابقة للتعلم والمنافسة، مش دليل إنه الاستراتيجية بتربح بالمستقبل.', 'It is for learning and fun, not proof that a strategy will win in future.'))}</li>
        </ul>
      </article>
      <article class="card tool-card">
        <h2 class="card-title">${icons.user || ''}<span>${esc(c.joined ? L(`إنت مشارك باسم «${c.nick}»`, `You are in as “${c.nick}”`) : L('شارك', 'Join'))}</span></h2>
        ${c.joined ? `<button type="button" class="btn btn-sm btn-ghost" data-leave>${esc(L('انسحب', 'Leave'))}</button>` : `<form class="ac-join" data-join><input class="input" name="nick" maxlength="20" placeholder="${esc(L('اسم مستعار', 'Nickname'))}" required><button class="btn btn-primary btn-sm" type="submit">${esc(L('شارك', 'Join'))}</button></form>`}
        <p class="muted tool-note">${esc(L(`${c.pending} مشارك لسا ما وصلوا ${c.minTrades} صفقات.`, `${c.pending} players have fewer than ${c.minTrades} trades so far.`))}</p>
      </article></div>
      <article class="card tool-card"><h2 class="card-title">${icons.bars || ''}<span>${esc(L(`الترتيب — ${c.month}`, `Leaderboard — ${c.month}`))}</span></h2>
        ${c.ranked.length ? `<div class="sa-table-wrap"><table class="kv-table bl-table"><thead><tr><th>#</th><th>${esc(L('الاسم', 'Name'))}</th><th>${esc(L('صفقات', 'Trades'))}</th><th>${esc(L('رابحة', 'Won'))}</th><th>R</th>${c.owner ? '<th></th>' : ''}</tr></thead><tbody>
        ${c.ranked.map((r, i) => `<tr class="${r.me ? 'is-me' : ''}"><td>${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : i + 1}</td><td>${esc(r.nick)}</td><td class="mono">${r.n}</td><td class="mono">${Math.round((r.wins / r.n) * 100)}%</td><td class="mono ${r.r >= 0 ? 'up' : 'down'}">${r.r > 0 ? '+' : ''}${r.r}</td>${c.owner ? `<td>${i === 0 ? `<button type="button" class="btn btn-sm" data-award="${esc(r.ref)}">${esc(L('أعطيه شهر', 'Award a month'))}</button>` : ''}</td>` : ''}</tr>`).join('')}</tbody></table></div>`
        : `<p class="muted">${esc(L('لسا ما حدا وصل للحد الأدنى هالشهر.', 'Nobody has reached the minimum this month yet.'))}</p>`}</article>`;
    box.querySelector('[data-join]')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      try { await apiRequest('POST', '/api/contest/join', { nick: e.target.nick.value }); load(); }
      catch (x) { toast(x?.code === 'nick_taken' ? L('الاسم مأخوذ، جرّب غيره.', 'That name is taken.') : L('اسم قصير أو غلط.', 'Name too short or invalid.'), 'error'); }
    });
    box.querySelector('[data-leave]')?.addEventListener('click', async () => { await apiRequest('DELETE', '/api/contest/join').catch(() => {}); load(); });
    box.querySelector('[data-award]')?.addEventListener('click', async (e) => {
      try { await apiRequest('POST', '/api/contest/award', { ref: e.currentTarget.dataset.award, days: 30 }); toast(L('انضاف شهر للفائز ✓', 'A month was added for the winner ✓'), 'success'); }
      catch (x) { toast(x?.code === 'already_awarded' ? L('الجائزة انعطت هالشهر.', 'Already awarded this month.') : L('ما زبط.', 'Failed.'), 'error'); }
    });
  }).catch(() => { box.innerHTML = `<article class="card tool-card"><p class="muted">${esc(L('المسابقة مش متاحة هلأ.', 'The contest is not available right now.'))}</p></article>`; });
  load();
  return el;
}
