// «توصية AI» (v234) — performance dashboard inside the section: every strategy with its status (LIVE / PAPER / DISABLED) and
// three sources kept apart — live saved signals, paper signals, back-tests — plus the reasons behind the last NO TRADE results.
// Nothing is estimated: an empty source says so. Uses the section's existing styles (aisg-*, aie-*) and a small table style.
import { esc, fmtNum } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { STRATEGIES, PROMOTION, ENGINE_VERSION } from '../config/aiSignalRules.js';
import { listTrades } from '../services/assistTrades.js';
import { paperList, decisions, backtests, rStats, groupStats, isClosed } from '../services/aiPaperJournal.js';
import { fmtTz, tzLabel } from '../services/aiSignalUtil.js';
import { pairName } from '../services/tradeMessages.js';

const L = (ar, en) => (getLang() !== 'ar' ? en : ar);
const ST = () => ({ live: L('LIVE · حيّة', 'LIVE'), paper: L('PAPER · تجريبية', 'PAPER'), disabled: L('DISABLED · موقوفة', 'DISABLED') });
const BADGE = { live: 'is-qualified', paper: 'is-paper', disabled: 'is-unvalidated' };
const num = (v, d = 2) => (v == null || !Number.isFinite(v) ? '—' : fmtNum(v, d));
const pct = (v) => (v == null ? '—' : `${Math.round(v * 100)}%`);
const nm = (s) => L(s.name.ar, s.name.en);
const FAIL = () => ({ test_sample: L(`صفقات الاختبار أقل من ${PROMOTION.minTestTrades}`, `fewer than ${PROMOTION.minTestTrades} test trades`), test_expectancy: L(`التوقّع بالاختبار ≤ ${PROMOTION.minExpectancyR}R`, `test expectancy ≤ ${PROMOTION.minExpectancyR}R`),
  test_pf: L(`معامل الربح بالاختبار < ${PROMOTION.minProfitFactor}`, `test profit factor < ${PROMOTION.minProfitFactor}`), unstable: L('فرق كبير بين التدريب والاختبار', 'large train / test gap'), walk_forward: L('أغلب نوافذ walk-forward مش موجبة', 'most walk-forward windows not positive') });
const UNAV = () => ({ no_real_volume: L('ما في حجم بورصة حقيقي لهالسوق', 'no real exchange volume for this market'), timeframe: L('مش مناسبة لهالفريم', 'not for this timeframe'), no_sessions: L('الكريبتو ما إله جلسات', 'crypto has no sessions'), not_enough_history: L('تاريخ مش كافي', 'not enough history'), data: L('بيانات مش كافية', 'not enough data') });

/** Live results: the saved signals of this section (v234+ carry `engine`; trend / mean reversion only come from here). */
export function liveSplit(items = listTrades()) {
  const live = items.filter((x) => x.mode === 'live');
  const mine = live.filter((x) => x.engine || ['trend', 'mean_reversion'].includes(x.strategy));
  const older = live.filter((x) => !mine.includes(x));
  return { mine, older };
}

function row(cells, cls = '') { return `<tr class="${cls}">${cells.map((c) => `<td>${c}</td>`).join('')}</tr>`; }
function statCells(s) { return s?.n ? [s.n, `${s.wins ?? 0}/${s.losses ?? 0}/${s.be ?? 0}`, `${pct(s.winRate)}${s.ci && s.ci[0] != null ? ` <small>(${pct(s.ci[0])}–${pct(s.ci[1])})</small>` : ''}`, num(s.avgR), num(s.profitFactor), num(s.maxDD)] : ['0', '—', '—', '—', '—', '—']; }
const head = () => `<tr><th>${esc(L('الاستراتيجية', 'Strategy'))}</th><th>${esc(L('الحالة', 'Status'))}</th><th>${esc(L('صفقات', 'Trades'))}</th><th>${esc(L('ربح/خسارة/تعادل', 'W/L/BE'))}</th><th>${esc(L('نسبة النجاح (95%)', 'Win rate (95%)'))}</th><th>${esc(L('متوسط R', 'Avg R'))}</th><th>PF</th><th>${esc(L('أقصى تراجع R', 'Max DD R'))}</th></tr>`;

export function dashHtml({ symbol, tf }) {
  const { mine, older } = liveSplit(); const paper = paperList(); const bts = backtests(); const dec = decisions();
  const live = STRATEGIES.filter((s) => s.status !== 'disabled');
  const liveRows = STRATEGIES.filter((s) => s.status === 'live').map((s) => { const list = mine.filter((x) => (x.strategy || 'smc') === s.id); const st = rStats(list.filter(isClosed).map((x) => x.resultR));
    return row([`<b>${esc(nm(s))}</b><small>${esc(L(`${list.length} إشارة · ${list.filter((x) => ['pending', 'active'].includes(x.status)).length} مفتوحة`, `${list.length} signals · ${list.filter((x) => ['pending', 'active'].includes(x.status)).length} open`))}</small>`, `<span class="aie-badge ${BADGE[s.status]}">${esc(ST()[s.status])}</span>`, ...statCells(st)]); }).join('');
  const paperRows = live.filter((s) => s.status === 'paper').map((s) => { const list = paper.filter((x) => x.strategy === s.id); const st = rStats(list.filter(isClosed).map((x) => x.resultR));
    return row([`<b>${esc(nm(s))}</b><small>${esc(L(`${list.length} إشارة`, `${list.length} signals`))}</small>`, `<span class="aie-badge ${BADGE.paper}">${esc(ST().paper)}</span>`, ...statCells(st)]); }).join('');
  const closedMine = mine.filter(isClosed);
  const grp = (title, rows) => (rows.length ? `<div><h5>${esc(title)}</h5><table class="aisd-table"><tbody>${rows.slice(0, 8).map((g) => row([esc(g.key), g.n, pct(g.winRate), num(g.avgR)])).join('')}</tbody></table></div>` : '');
  const bt = bts.find((x) => x.symbol === symbol && x.tf === tf) || bts[0] || null;
  const btRows = bt ? Object.entries(bt.strategies).map(([id, v]) => { const s = STRATEGIES.find((x) => x.id === id); const name = s ? nm(s) : id;
    if (v.unavailable) return row([`<b>${esc(name)}</b>`, `<span class="aie-badge ${BADGE[s?.status || 'paper']}">${esc(ST()[s?.status || 'paper'])}</span>`, `<span class="muted">${esc(UNAV()[v.unavailable] || v.unavailable)}</span>`, '', '', '', '', '']);
    return row([`<b>${esc(name)}</b>`, `<span class="aie-badge ${BADGE[s?.status || 'paper']}">${esc(ST()[s?.status || 'paper'])}</span>`, ...statCells(v.test)])
      + `<tr class="is-sub"><td colspan="8"><small>${esc(v.meetsLive ? L('بتحقق شروط LIVE بهالعيّنة', 'meets the LIVE criteria on this sample') : `${L('مش جاهزة لـ LIVE: ', 'not ready for LIVE: ')}${(v.fails || []).map((f) => FAIL()[f] || f).join(' · ')}`)} · ${esc(L(`تدريب ${v.train?.n ?? 0} · تحقق ${v.validation?.n ?? 0} · اختبار ${v.test?.n ?? 0} · نوافذ موجبة ${pct(v.positiveShare)}`, `train ${v.train?.n ?? 0} · validation ${v.validation?.n ?? 0} · test ${v.test?.n ?? 0} · positive windows ${pct(v.positiveShare)}`))}</small></td></tr>`; }).join('') : '';
  const D = { buy: L('شراء', 'BUY'), sell: L('بيع', 'SELL'), no_trade: L('لا صفقة', 'NO TRADE'), wait: L('استنى', 'WAIT') };
  return `<header class="aisg-head"><button type="button" class="aisg-back" data-back aria-label="${esc(L('رجوع', 'Back'))}">‹</button><div><small>${esc(L('توصية AI', 'AI signal'))}</small><b>${esc(L('لوحة الأداء', 'Performance'))}</b></div></header>
  <div class="aisg-body aisd">
    <p class="aisg-meta">${esc(L('ثلاث مصادر كل واحد لحاله: الإشارات الحية المحفوظة، الإشارات التجريبية (PAPER)، والباك تست. الخسارات محسوبة كلها، وما في أي رقم متوقّع أو مؤلف.', 'Three sources, each on its own: saved live signals, paper signals and back-tests. Every loss is counted; nothing is estimated or invented.'))}</p>
    <section class="aie-sec"><h4>${esc(L('الإشارات الحية (المحفوظة من هالقسم)', 'Live signals (saved from this section)'))}</h4>
      <div class="aisd-scroll"><table class="aisd-table">${head()}<tbody>${liveRows}</tbody></table></div>
      ${older.length ? `<p class="aie-note">${esc(L(`${older.length} إشارة محفوظة قبل v234 بدون علامة مصدر (ممكن تكون من لوحة SMC) — مش محسوبة هون، وبتلاقيها بسجل الصفقات.`, `${older.length} signals saved before v234 without a source mark (may come from the SMC panel) — not counted here; they are in the trade history.`))}</p>` : ''}
      ${closedMine.length ? `<details class="aie-strat"><summary><b>${esc(L('حسب السوق / الفريم / النمط', 'By market / timeframe / style'))}</b></summary><div class="aisd-groups">${grp(L('السوق', 'Market'), groupStats(closedMine, (x) => pairName(x.symbol)))}${grp(L('الفريم', 'Timeframe'), groupStats(closedMine, (x) => x.tf))}${grp(L('النمط', 'Style'), groupStats(closedMine, (x) => (x.style === 'swing' ? L('سوينغ', 'Swing') : L('سكالب', 'Scalp'))))}${grp(L('نوع الأمر', 'Order type'), groupStats(closedMine, (x) => x.execution))}</div></details>`
        : `<p class="aie-note">${esc(L('لسا ما في إشارات حية مكتملة — الأرقام بتطلع بس من نتائج حقيقية.', 'No completed live signals yet — numbers appear only from real outcomes.'))}</p>`}</section>
    <section class="aie-sec"><h4>${esc(L('الإشارات التجريبية (PAPER) — مش توصيات', 'Paper signals (PAPER) — not recommendations'))}</h4>
      <div class="aisd-scroll"><table class="aisd-table">${head()}<tbody>${paperRows}</tbody></table></div>
      <p class="aie-note">${esc(L('بتنسجل لما تطلب توصية، وبتنتابع على الشموع الحقيقية لما ترجع تحلّل نفس السوق والفريم. ما بتنبعت لـ MT5.', 'Recorded when you request a signal and followed on real candles when you analyse the same market and timeframe again. Never sent to MT5.'))}</p></section>
    <section class="aie-sec"><h4>${esc(L('الباك تست', 'Back-test'))}</h4>
      <div class="aisd-bt"><button type="button" class="btn btn-sm" data-bt>${esc(L(`شغّل باك تست · ${pairName(symbol)} · ${tf}`, `Run back-test · ${pairName(symbol)} · ${tf}`))}</button><div class="aisg-genbar" data-btbar hidden><i data-btfill></i><b class="mono" data-btpct>0%</b></div></div>
      <p class="aie-note" data-btmsg>${esc(L('على الشموع الحقيقية المتوفرة (لحد 1500)، كل استراتيجية لحالها، بإعداداتها الثابتة بدون أي ضبط. الدخول على افتتاح الشمعة الجاية، والتكاليف (سبريد + عمولة + انزلاق) محسوبة.', 'On the real candles available (up to 1,500), each strategy on its own with its fixed defaults, nothing tuned. Entry on the next candle\'s open; spread + commission + slippage included.'))}</p>
      ${bt ? `<p class="aisg-meta">${esc(`${pairName(bt.symbol)} · ${bt.tf} · ${bt.bars} ${L('شمعة', 'candles')} · ${fmtTz(bt.from, getLang())} → ${fmtTz(bt.to, getLang())} · ${L('تكلفة', 'cost')} ${num(bt.costPct, 3)}% · ${bt.source || ''} · ${L('آخر تشغيل', 'run')} ${fmtTz(Math.floor(bt.at / 1000), getLang())}`)}</p>
        <div class="aisd-scroll"><table class="aisd-table">${head()}<tbody>${btRows}${bt.baseline ? row([`<b>${esc(L('الأساس (EMA 200 كل 20 شمعة)', 'Baseline (EMA 200 every 20 bars)'))}</b>`, '—', ...statCells(bt.baseline.test)], 'is-base') : ''}</tbody></table></div>
        <p class="aie-note">${esc(L(`الأرقام من قسم الاختبار (آخر 20% من الفترة). شراء والاحتفاظ بنفس الفترة: ${num(bt.buyHoldPct)}%. الترقية لـ LIVE بتحتاج ≥ ${PROMOTION.minTestTrades} صفقة اختبار، توقّع > ${PROMOTION.minExpectancyR}R، PF ≥ ${PROMOTION.minProfitFactor}، استقرار بين التدريب والاختبار، و${Math.round(PROMOTION.minPositiveWindows * 100)}% من نوافذ walk-forward موجبة — وعلى أكتر من سوق وفترة، مش تشغيل واحد.`, `Numbers are from the test part (the last 20% of the period). Buy & hold over the same period: ${num(bt.buyHoldPct)}%. LIVE needs ≥ ${PROMOTION.minTestTrades} test trades, expectancy > ${PROMOTION.minExpectancyR}R, PF ≥ ${PROMOTION.minProfitFactor}, a stable train/test gap and ${Math.round(PROMOTION.minPositiveWindows * 100)}% positive walk-forward windows — on more than one market and period, not one run.`))}</p>
        <p class="aie-note">${esc(L('حدود: SMC بالباك تست على قواعد محرك الموقع ودخول ماركت، والفريمات الأعلى من شموع الشارت نفسها. ما في swap/تمويل. نتيجة الماضي مش توقّع.', 'Limits: SMC is back-tested on the site engine rules with market entries, higher frames from the chart\'s own candles. No swap / financing. Past results are not a forecast.'))}</p>` : ''}</section>
    <section class="aie-sec"><h4>${esc(L('حالة كل الاستراتيجيات', 'Every strategy and its status'))}</h4>
      ${STRATEGIES.map((s) => `<details class="aie-strat"><summary><b>${esc(nm(s))}</b><span class="aie-badge ${BADGE[s.status]}">${esc(ST()[s.status])}</span></summary><p class="aie-note">${esc(L(...(s.logic || s.why || ['', ''])))}</p></details>`).join('')}</section>
    <section class="aie-sec"><h4>${esc(L('آخر التحليلات وأسباب القرار', 'Latest analyses and why'))}</h4>
      ${dec.length ? `<ul class="aisd-dec">${dec.slice(0, 12).map((d) => `<li><b>${esc(pairName(d.symbol))} · ${esc(d.tf)} · ${esc(D[d.final] || d.final)}</b>${d.strategy ? ` <small>${esc(d.strategy)}</small>` : ''}<span>${esc(fmtTz(Math.floor(d.at / 1000), getLang()))}</span>${(d.reasons || []).length ? `<small>${(d.reasons || []).slice(0, 3).map(esc).join(' · ')}</small>` : ''}</li>`).join('')}</ul>` : `<p class="aie-note">${esc(L('لسا ما في تحليلات.', 'No analyses yet.'))}</p>`}</section>
    <p class="aisg-fine">${esc(`${ENGINE_VERSION} · ${tzLabel()}`)}</p>
  </div>`;
}
