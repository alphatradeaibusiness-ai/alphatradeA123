// Owners only (the server refuses everyone else): business analytics with the monthly reports, and plans & coupons.
import { h, esc, fmtNum } from '../utils/dom.js';
import { icons } from '../components/icons.js';
import { getLocale } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { apiRequest } from '../services/ai/gateway.js';
import { toast } from '../components/ui.js';
import { isAdmin } from '../config/admin.js';
import { downloadText, csvText } from './tools/common.js';
import { errText, pageHead } from './community.js';
import '../styles/community.css';

const OWN = { ar: 'هالقسم لأصحاب الشركة بس. ما بيبين للعملاء، والسيرفر بيرفض أي طلب من غيرهم.', en: 'Owners only. Hidden from customers, and the server refuses anyone else.', he: 'לבעלים בלבד. מוסתר מלקוחות והשרת דוחה כל אחד אחר.', es: 'Solo propietarios. Oculto a los clientes; el servidor rechaza a cualquier otro.', zh: '仅限所有者。对客户隐藏，服务器拒绝其他人。' };
const page = (cls, inner) => h(`<section class="subpage tool cm ${cls} page-enter">${inner}</section>`);
const money = (v) => (v == null ? '—' : `${v < 0 ? '−' : ''}$${fmtNum(Math.abs(v), 2)}`);
const signed = (v, d = 0, suf = '') => (v == null ? '—' : `${v > 0 ? '+' : v < 0 ? '−' : ''}${fmtNum(Math.abs(v), d)}${suf}`);
const monthName = (key) => new Date(`${key}-15T00:00:00Z`).toLocaleString(getLocale(), { month: 'long', year: 'numeric' });

/* ───────────────────────── Business analytics ───────────────────────── */
export function renderAdminStats() {
  const el = page('cm-admin', `${pageHead('trend', tx({ ar: 'تحليلات الأعمال', en: 'Business analytics', he: 'אנליטיקה עסקית', es: 'Analítica del negocio', zh: '业务分析' }), tx({ ar: 'نسبة نجاح توصيات الـ AI، كم توصية أخذها العملاء، النقاط والربح والخسارة — وتقرير أوتوماتيك كل آخر شهر.', en: 'AI recommendation success rate, how many recommendations customers took, points, profit and loss — and an automatic report at the end of every month.', he: 'אחוז הצלחת המלצות ה-AI, כמה המלצות לקחו הלקוחות, נקודות ורווח/הפסד — ודוח אוטומטי בסוף כל חודש.', es: 'Tasa de acierto de las señales IA, cuántas siguieron los clientes, puntos, ganancias y pérdidas — y un informe automático cada fin de mes.', zh: 'AI 推荐成功率、客户采用的推荐数、点数和盈亏 — 每月底自动生成报告。' }))}
    <div class="tool-body"><p class="muted cm-own">${icons.lock}<span>${esc(tx(OWN))}</span></p><div data-body><div class="perf-loading"><span class="spinner"></span></div></div></div>`);
  const body = el.querySelector('[data-body]');
  if (!isAdmin()) { body.innerHTML = `<div class="card sig-empty">${icons.lock}<span>${esc(errText('not_owner'))}</span></div>`; return el; }
  const kpi = (label, value, sub = '', cls = '') => `<div class="mini-kpi ${cls}"><span>${esc(label)}</span><b class="mono">${esc(value)}</b><small>${sub}</small></div>`;
  const delta = (cur, prev, d = 0, suf = '') => (cur == null || prev == null ? '' : `<bdi class="${cur - prev >= 0 ? 'up' : 'down'}">${esc(signed(cur - prev, d, suf))}</bdi> ${esc(tx({ ar: 'عن الشهر الماضي', en: 'vs last month', he: 'לעומת החודש הקודם', es: 'vs. mes anterior', zh: '较上月' }))}`);
  function exportCsv(r) {
    const head = [['month', r.month], ['recommendations_generated', r.recommendations.generated], ['buy', r.recommendations.buy], ['sell', r.recommendations.sell], ['no_trade', r.recommendations.noTrade], ['followed_by_customers', r.followed], ['executed_verified', r.executedVerified], ['closed', r.closed], ['wins', r.wins], ['losses', r.losses], ['success_rate_pct', r.successRate ?? ''], ['total_R', r.totalR], ['points', r.points], ['profit_usd', r.profitUsd], ['loss_usd', r.lossUsd], ['customers_total', r.customers.total], ['customers_active', r.customers.active], ['customers_new', r.customers.newThisMonth], []];
    const rows = [['customer_ref', 'symbol', 'direction', 'tf', 'strategy', 'entry', 'stop', 'status', 'targets_hit', 'result_R', 'points', 'usd', 'saved_at', 'closed_at'], ...(r.trades || []).map((x) => [csvText(x.ref), x.symbol, x.direction, x.tf, x.strategy, x.entry, x.stop, x.status, x.hits, x.resultR, x.points, x.usd ?? '', new Date(x.savedAt).toISOString(), x.closedAt ? new Date(x.closedAt).toISOString() : ''])];
    downloadText(`alphatrade-report-${r.month}.csv`, [...head, ...rows].map((a) => a.join(',')).join('\n'));
  }
  function exportPdf(r) {
    const w = window.open('', '_blank'); if (!w) { toast(tx({ ar: 'المتصفح منع النافذة', en: 'The browser blocked the window', he: 'הדפדפן חסם את החלון', es: 'El navegador bloqueó la ventana', zh: '浏览器阻止了窗口' }), 'error'); return; }
    const rowsHtml = (r.trades || []).map((x) => `<tr><td>${esc(new Date(x.closedAt || x.savedAt).toISOString().slice(0, 10))}</td><td>${esc(x.ref)}</td><td>${esc(x.symbol)}</td><td>${esc(x.direction)}</td><td>${esc(x.strategy)}</td><td>${x.entry}</td><td>${x.stop}</td><td>${esc(x.status)}</td><td>${x.resultR}</td><td>${x.points}</td><td>${x.usd ?? ''}</td></tr>`).join('');
    w.document.write(`<!doctype html><html lang="en"><head><meta charset="utf-8"><title>AlphaTrade AI — ${esc(r.month)}</title><style>body{font:13px system-ui,sans-serif;margin:28px;color:#111}h1{font-size:20px;margin:0 0 4px}table{border-collapse:collapse;width:100%;margin-top:14px}td,th{border:1px solid #ccc;padding:4px 6px;text-align:left;font-size:11.5px}.k{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:12px}.k div{border:1px solid #ddd;padding:8px;border-radius:6px}.k b{display:block;font-size:16px}small{color:#666}</style></head><body>
      <h1>AlphaTrade AI — monthly report ${esc(r.month)}</h1><small>Generated ${esc(new Date(r.generatedAt).toISOString())}. Recommendations are not executed trades: executions verified by a broker: ${r.executedVerified} (no broker connection).</small>
      <div class="k"><div>Recommendations<b>${r.recommendations.generated}</b></div><div>Followed by customers<b>${r.followed}</b></div><div>Closed<b>${r.closed}</b></div><div>Success rate<b>${r.successRate ?? '—'}%</b></div><div>Wins / losses<b>${r.wins} / ${r.losses}</b></div><div>Total R<b>${r.totalR}</b></div><div>Points<b>${r.points}</b></div><div>Profit / loss<b>${money(r.profitUsd)} / ${money(r.lossUsd)}</b></div><div>Customers<b>${r.customers.total}</b></div><div>Active<b>${r.customers.active}</b></div><div>New<b>${r.customers.newThisMonth}</b></div>${r.compare ? `<div>vs previous month<b>${signed(r.compare.totalR, 2, 'R')} · ${signed(r.compare.points, 0, ' pts')}</b></div>` : ''}</div>
      <table><thead><tr><th>Date</th><th>Customer</th><th>Symbol</th><th>Side</th><th>Strategy</th><th>Entry</th><th>Stop</th><th>Status</th><th>R</th><th>Points</th><th>USD</th></tr></thead><tbody>${rowsHtml || '<tr><td colspan="11">No closed trades</td></tr>'}</tbody></table></body></html>`);
    w.document.close(); setTimeout(() => { try { w.focus(); w.print(); } catch { /* */ } }, 300);
  }
  async function load() {
    try {
      const a = await apiRequest('GET', '/api/admin/analytics'); const c = a.current; const p = a.previous;
      body.innerHTML = `<article class="card tool-card"><h2 class="card-title">${icons.sparkle}<span>${esc(tx({ ar: 'أداء Alpha AI — ', en: 'Alpha AI performance — ', he: 'ביצועי Alpha AI — ', es: 'Rendimiento de Alpha AI — ', zh: 'Alpha AI 表现 — ' }))}${esc(monthName(c.month))}</span></h2>
        <div class="kpi-row">
          ${kpi(tx({ ar: 'نسبة نجاح التوصيات', en: 'AI success rate', he: 'אחוז הצלחה', es: 'Tasa de acierto IA', zh: 'AI 成功率' }), c.successRate == null ? '—' : `${fmtNum(c.successRate, 1)}%`, delta(c.successRate, p.successRate, 1, '%'), 'glow')}
          ${kpi(tx({ ar: 'توصيات انعملت', en: 'Recommendations generated', he: 'המלצות שנוצרו', es: 'Señales generadas', zh: '生成的推荐' }), String(c.recommendations.generated), `${c.recommendations.buy} ${esc(tx({ ar: 'شراء', en: 'buy', he: 'קנייה', es: 'compra', zh: '买' }))} · ${c.recommendations.sell} ${esc(tx({ ar: 'بيع', en: 'sell', he: 'מכירה', es: 'venta', zh: '卖' }))} · ${c.recommendations.noTrade} ${esc(tx({ ar: 'لا صفقة', en: 'no trade', he: 'ללא עסקה', es: 'sin operación', zh: '不交易' }))}`)}
          ${kpi(tx({ ar: 'توصيات أخدها العملاء', en: 'Taken by customers', he: 'נלקחו ע״י לקוחות', es: 'Seguidas por clientes', zh: '客户采用' }), String(c.followed), delta(c.followed, p.followed))}
          ${kpi(tx({ ar: 'صفقات منفّذة (موثّقة)', en: 'Executed trades (verified)', he: 'עסקאות שבוצעו (מאומת)', es: 'Operaciones ejecutadas (verificadas)', zh: '已执行交易（已验证）' }), String(c.executedVerified), esc(tx({ ar: 'ما في ربط مع وسيط، فما منحسب أي توصية كصفقة منفّذة', en: 'No broker connection — a recommendation is never counted as executed', he: 'אין חיבור לברוקר — המלצה לא נספרת כעסקה שבוצעה', es: 'Sin conexión con broker: nunca contamos una señal como ejecutada', zh: '未连接券商 — 推荐不计为已执行' })))}
          ${kpi(tx({ ar: 'رابحة / خاسرة', en: 'Wins / losses', he: 'רווח / הפסד', es: 'Ganadas / perdidas', zh: '盈 / 亏' }), `${c.wins} / ${c.losses}`, `${c.closed} ${esc(tx({ ar: 'مسكّرة', en: 'closed', he: 'נסגרו', es: 'cerradas', zh: '已平仓' }))}`)}
          ${kpi(tx({ ar: 'المجموع بالـ R', en: 'Total R', he: 'סה״כ R', es: 'Total R', zh: '总 R' }), signed(c.totalR, 2, 'R'), delta(c.totalR, p.totalR, 2, 'R'), c.totalR >= 0 ? 'good' : 'bad')}
          ${kpi(tx({ ar: 'النقاط', en: 'Points / pips', he: 'נקודות', es: 'Puntos / pips', zh: '点数' }), signed(c.points), delta(c.points, p.points), c.points >= 0 ? 'good' : 'bad')}
          ${kpi(tx({ ar: 'الربح / الخسارة', en: 'Profit / loss', he: 'רווח / הפסד', es: 'Ganancia / pérdida', zh: '盈利 / 亏损' }), `${money(c.profitUsd)} / ${money(c.lossUsd)}`, esc(tx({ ar: 'من المبلغ المخاطر فيه المسجّل', en: 'from the recorded amount at risk', he: 'לפי סכום הסיכון שנרשם', es: 'según el riesgo registrado', zh: '按记录的风险金额' })))}
          ${kpi(tx({ ar: 'العملاء', en: 'Customers', he: 'לקוחות', es: 'Clientes', zh: '客户' }), String(c.customers.total), `${c.customers.active} ${esc(tx({ ar: 'نشطين', en: 'active', he: 'פעילים', es: 'activos', zh: '活跃' }))} · ${c.customers.newThisMonth} ${esc(tx({ ar: 'جداد', en: 'new', he: 'חדשים', es: 'nuevos', zh: '新' }))}`)}
        </div>
        <div class="tool-actions"><button type="button" class="btn btn-sm" data-dl="${c.month}" data-fmt="csv">${icons.download}<span>Excel (CSV)</span></button><button type="button" class="btn btn-sm" data-dl="${c.month}" data-fmt="pdf">${icons.download}<span>PDF</span></button></div>
        <p class="muted tool-note">${esc(tx({ ar: 'النتائج من صفقات الـ AI اللي حفظها العملاء على أسعار حية وانحسبت نتيجتها على السيرفر. التوصيات التجريبية ما بتنحسب.', en: 'Results come from the AI trades customers saved on live prices, judged on the server. Demo-price trades are excluded.', he: 'התוצאות מעסקאות AI שלקוחות שמרו במחירים חיים. עסקאות הדגמה לא נספרות.', es: 'Resultados de las operaciones IA guardadas por clientes con precios reales. Se excluyen las de demo.', zh: '结果来自客户以实时价格保存的 AI 交易，演示交易不计入。' }))}</p></article>
        <article class="card tool-card"><h2 class="card-title">${icons.calendar}<span>${esc(tx({ ar: 'التقارير الشهرية', en: 'Monthly reports', he: 'דוחות חודשיים', es: 'Informes mensuales', zh: '月度报告' }))}</span></h2>
          ${a.reports.length ? `<ul class="cm-hist">${a.reports.map((k) => `<li><b>${esc(monthName(k))}</b><span class="muted">${esc(tx({ ar: 'انبعت لأصحاب الشركة', en: 'sent to the owners', he: 'נשלח לבעלים', es: 'enviado a los propietarios', zh: '已发送给所有者' }))}</span><button type="button" class="btn btn-sm" data-dl="${k}" data-fmt="csv">Excel</button><button type="button" class="btn btn-sm" data-dl="${k}" data-fmt="pdf">PDF</button></li>`).join('')}</ul>` : `<p class="muted">${esc(tx({ ar: 'أول تقرير بيطلع أوتوماتيك أول ما يخلص الشهر الحالي، وبيوصلكم إشعار وتيليغرام وإيميل (إذا RESEND_API_KEY مضاف).', en: 'The first report is built automatically when this month ends, and you get an in-app notice, Telegram and e-mail (when RESEND_API_KEY is set).', he: 'הדוח הראשון ייווצר אוטומטית בסוף החודש.', es: 'El primer informe se crea automáticamente al terminar el mes.', zh: '首份报告将在本月结束时自动生成。' }))}</p>`}
          <p class="muted tool-note">${esc(tx({ ar: `الشهر الماضي (${monthName(p.month)}): ${p.closed} صفقة مسكّرة، ${p.successRate ?? '—'}%، ${signed(p.totalR, 2, 'R')}، ${signed(p.points)} نقطة.`, en: `Last month (${monthName(p.month)}): ${p.closed} closed, ${p.successRate ?? '—'}%, ${signed(p.totalR, 2, 'R')}, ${signed(p.points)} points.`, he: `החודש הקודם: ${p.closed} נסגרו, ${p.successRate ?? '—'}%.`, es: `Mes anterior: ${p.closed} cerradas, ${p.successRate ?? '—'}%.`, zh: `上月：${p.closed} 笔平仓，${p.successRate ?? '—'}%。` }))}</p></article>`;
    } catch (e) { body.innerHTML = `<div class="card sig-empty">${icons.alert}<span>${esc(errText(e.code))}</span></div>`; }
  }
  body.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-dl]'); if (!b) return; b.disabled = true;
    try { const r = await apiRequest('GET', `/api/admin/report?month=${encodeURIComponent(b.dataset.dl)}`); if (b.dataset.fmt === 'pdf') exportPdf(r); else exportCsv(r); }
    catch (er) { toast(errText(er.code), 'error'); }
    b.disabled = false;
  });
  load();
  return el;
}

/* ───────────────────────── Plans & coupons ───────────────────────── */
const chName = (id) => { const m = /^ch-(step1|step2|flex|instant)-(\d+)k$/.exec(id); return m ? { ar: `تحدي ${m[1] === 'flex' ? 'Flex' : m[1] === 'instant' ? 'Instant' : m[1] === 'step1' ? 'Step 1' : 'Step 2'} · $${m[2]}K`, en: `Challenge ${m[1] === 'flex' ? 'Flex' : m[1] === 'instant' ? 'Instant' : m[1] === 'step1' ? 'Step 1' : 'Step 2'} · $${m[2]}K` } : { en: id }; };
const PLAN_NAME = { monthly: { ar: 'شهري', en: 'Monthly', he: 'חודשי', es: 'Mensual', zh: '月付' }, quarterly: { ar: '3 شهور', en: '3 months', he: '3 חודשים', es: '3 meses', zh: '3 个月' }, semiannual: { ar: '6 شهور', en: '6 months', he: '6 חודשים', es: '6 meses', zh: '6 个月' }, annual: { ar: 'سنوي', en: 'Yearly', he: 'שנתי', es: 'Anual', zh: '年付' }, prime: { ar: 'برايم · سنوي', en: 'Prime · yearly', he: 'פריים · שנתי', es: 'Prime · anual', zh: 'Prime · 年付' }, apex: { ar: 'أبكس · سنوي', en: 'Apex · yearly', he: 'אייפקס · שנתי', es: 'Apex · anual', zh: 'Apex · 年付' }, max: { ar: 'ماكس · سنوي', en: 'Max · yearly', he: 'מקס · שנתי', es: 'Max · anual', zh: 'Max · 年付' }, channel: { ar: 'قناة التوصيات', en: 'Signals channel', he: 'ערוץ איתותים', es: 'Canal de señales', zh: '信号频道' }, signals25: { ar: '+25 توصية', en: '+25 signals', he: '+25 איתותים', es: '+25 señales', zh: '+25 信号' }, signals50: { ar: '+50 توصية', en: '+50 signals', he: '+50 איתותים', es: '+50 señales', zh: '+50 信号' }, signals100: { ar: '+100 توصية', en: '+100 signals', he: '+100 איתותים', es: '+100 señales', zh: '+100 信号' } };
export function renderAdminPlans() {
  const T = (o) => esc(tx(o));
  const el = page('cm-plans', `${pageHead('crown', tx({ ar: 'الاشتراكات والكوبونات', en: 'Subscriptions & coupons', he: 'מנויים וקופונים', es: 'Suscripciones y cupones', zh: '订阅与优惠券' }), tx({ ar: 'غيّر سعر الاشتراكات ومددها، شغّل أو وقّف أي باقة، واعمل كوبونات خصم.', en: 'Change subscription prices and durations, turn plans on or off, and create discount coupons.', he: 'שנה מחירים ומשכי מנוי, הפעל או כבה תוכניות וצור קופוני הנחה.', es: 'Cambia precios y duraciones, activa o desactiva planes y crea cupones de descuento.', zh: '修改订阅价格和时长，开关套餐，创建优惠券。' }))}
    <div class="tool-body"><p class="muted cm-own">${icons.lock}<span>${T(OWN)}</span></p>
      <article class="card tool-card"><h2 class="card-title">${icons.crown}<span>${T({ ar: 'الباقات والأسعار', en: 'Plans & prices', he: 'תוכניות ומחירים', es: 'Planes y precios', zh: '套餐与价格' })}</span></h2><div class="table-scroll" data-plans></div>
        <p class="muted tool-note">${T({ ar: 'السعر الجديد بيتطبّق على أي دفع جديد فورًا. الدفعات القديمة ما بتتغيّر.', en: 'A new price applies to every new checkout at once. Past payments do not change.', he: 'מחיר חדש חל מיד על כל תשלום חדש.', es: 'El nuevo precio se aplica de inmediato a cada pago nuevo.', zh: '新价格立即适用于新的付款。' })}</p></article>
      <article class="card tool-card"><h2 class="card-title">${icons.gift || icons.plus}<span>${T({ ar: 'كوبون جديد / تعديل', en: 'New / edit coupon', he: 'קופון חדש / עריכה', es: 'Nuevo / editar cupón', zh: '新建 / 编辑优惠券' })}</span></h2>
        <form class="tf-grid" data-coupon>
          <label class="tf-field"><span>${T({ ar: 'الكود', en: 'Code', he: 'קוד', es: 'Código', zh: '代码' })}</span><input class="input mono" name="code" maxlength="20" pattern="[A-Za-z0-9]{4,20}" required placeholder="RAMADAN20"></label>
          <label class="tf-field"><span>${T({ ar: 'النوع', en: 'Type', he: 'סוג', es: 'Tipo', zh: '类型' })}</span><select class="select" name="type"><option value="percent">%</option><option value="fixed">$</option></select></label>
          <label class="tf-field"><span>${T({ ar: 'القيمة', en: 'Value', he: 'ערך', es: 'Valor', zh: '数值' })}</span><input class="input mono" name="value" inputmode="decimal" required></label>
          <label class="tf-field"><span>${T({ ar: 'من تاريخ', en: 'Starts', he: 'מתחיל', es: 'Desde', zh: '开始' })}</span><input class="input" type="date" name="startsAt"></label>
          <label class="tf-field"><span>${T({ ar: 'لتاريخ', en: 'Ends', he: 'מסתיים', es: 'Hasta', zh: '结束' })}</span><input class="input" type="date" name="endsAt"></label>
          <label class="tf-field"><span>${T({ ar: 'أقصى عدد استخدام', en: 'Max uses', he: 'מקסימום שימושים', es: 'Usos máximos', zh: '最多使用次数' })}</span><input class="input mono" name="maxUses" inputmode="numeric" placeholder="∞"></label>
          <div class="tf-field tf-wide"><span>${T({ ar: 'الباقات (فاضي = الكل)', en: 'Plans (none = all)', he: 'תוכניות (ריק = הכול)', es: 'Planes (vacío = todos)', zh: '套餐（不选 = 全部）' })}</span><div class="cm-checks" data-plan-checks></div></div>
          <label class="tf-check"><input type="checkbox" name="active" checked><span>${T({ ar: 'مفعّل', en: 'Active', he: 'פעיל', es: 'Activo', zh: '启用' })}</span></label>
          <div class="tf-field tf-end"><button class="btn btn-primary" type="submit">${icons.check}<span>${T({ ar: 'حفظ الكوبون', en: 'Save coupon', he: 'שמור קופון', es: 'Guardar cupón', zh: '保存优惠券' })}</span></button></div>
        </form></article>
      <article class="card tool-card"><h2 class="card-title">${icons.layers}<span>${T({ ar: 'الكوبونات', en: 'Coupons', he: 'קופונים', es: 'Cupones', zh: '优惠券' })}</span></h2><div data-totals class="muted"></div><div class="table-scroll" data-coupons></div></article>
    </div>`);
  const $ = (s) => el.querySelector(s);
  if (!isAdmin()) { $('.tool-body').innerHTML = `<div class="card sig-empty">${icons.lock}<span>${esc(errText('not_owner'))}</span></div>`; return el; }
  const form = $('[data-coupon]'); let plans = [];
  const day = (ms) => (ms ? new Date(ms).toISOString().slice(0, 10) : '');
  async function loadPlans() {
    try {
      plans = (await apiRequest('GET', '/api/admin/plans')).items;
      $('[data-plans]').innerHTML = `<table class="kv-table perf-table"><thead><tr><th>${T({ ar: 'الباقة', en: 'Plan', he: 'תוכנית', es: 'Plan', zh: '套餐' })}</th><th>${T({ ar: 'السعر الأصلي', en: 'Base price', he: 'מחיר בסיס', es: 'Precio base', zh: '原价' })}</th><th>${T({ ar: 'السعر ($)', en: 'Price ($)', he: 'מחיר ($)', es: 'Precio ($)', zh: '价格 ($)' })}</th><th>${T({ ar: 'المدة (شهور)', en: 'Months', he: 'חודשים', es: 'Meses', zh: '月数' })}</th><th>${T({ ar: 'مفعّلة', en: 'On', he: 'פעיל', es: 'Activo', zh: '启用' })}</th><th></th></tr></thead><tbody>
        ${plans.map((p) => `<tr data-pid="${esc(p.id)}"><td>${T(PLAN_NAME[p.id] || chName(p.id))}</td><td class="mono">$${fmtNum(p.base / 100, 2)}</td><td><input class="input mono cm-num" data-price value="${p.cents / 100}" inputmode="decimal"></td><td>${p.kind === 'plan' ? `<input class="input mono cm-num" data-months value="${p.months}" inputmode="numeric">` : '—'}</td><td><input type="checkbox" data-active ${p.active ? 'checked' : ''}></td><td><button type="button" class="btn btn-sm btn-primary" data-save-plan>${T({ ar: 'حفظ', en: 'Save', he: 'שמור', es: 'Guardar', zh: '保存' })}</button></td></tr>`).join('')}</tbody></table>`;
      $('[data-plan-checks]').innerHTML = plans.map((p) => `<label class="tf-check"><input type="checkbox" value="${esc(p.id)}" data-pc><span>${T(PLAN_NAME[p.id] || chName(p.id))}</span></label>`).join('');
    } catch (e) { $('[data-plans]').innerHTML = `<p class="muted">${esc(errText(e.code))}</p>`; }
  }
  async function loadCoupons() {
    try {
      const r = await apiRequest('GET', '/api/admin/coupons');
      $('[data-totals]').textContent = tx({ ar: `استُخدمت ${r.totals.used} مرة · مجموع الخصومات $${fmtNum(r.totals.discountCents / 100, 2)}`, en: `Used ${r.totals.used} times · total discounts $${fmtNum(r.totals.discountCents / 100, 2)}`, he: `נוצלו ${r.totals.used} פעמים · סה״כ הנחות $${fmtNum(r.totals.discountCents / 100, 2)}`, es: `Usados ${r.totals.used} veces · descuentos $${fmtNum(r.totals.discountCents / 100, 2)}`, zh: `已使用 ${r.totals.used} 次 · 折扣总额 $${fmtNum(r.totals.discountCents / 100, 2)}` });
      $('[data-coupons]').innerHTML = r.items.length ? `<table class="kv-table perf-table"><thead><tr><th>${T({ ar: 'الكود', en: 'Code', he: 'קוד', es: 'Código', zh: '代码' })}</th><th>${T({ ar: 'الخصم', en: 'Discount', he: 'הנחה', es: 'Descuento', zh: '折扣' })}</th><th>${T({ ar: 'الفترة', en: 'Dates', he: 'תאריכים', es: 'Fechas', zh: '日期' })}</th><th>${T({ ar: 'الاستخدام', en: 'Used', he: 'שימושים', es: 'Usos', zh: '使用' })}</th><th>${T({ ar: 'مجموع الخصم', en: 'Total off', he: 'סה״כ הנחה', es: 'Total descontado', zh: '总折扣' })}</th><th>${T({ ar: 'الحالة', en: 'Status', he: 'סטטוס', es: 'Estado', zh: '状态' })}</th><th></th></tr></thead><tbody>
        ${r.items.map((c) => `<tr data-code="${esc(c.code)}"><td class="mono"><b>${esc(c.code)}</b></td><td class="mono">${c.type === 'percent' ? `${c.value}%` : `$${fmtNum(c.value, 2)}`}${c.plans.length ? `<small class="muted"> · ${esc(c.plans.join(', '))}</small>` : ''}</td><td class="mono">${esc(day(c.startsAt) || '—')} → ${esc(day(c.endsAt) || '∞')}</td><td class="mono">${c.used}${c.maxUses ? ` / ${c.maxUses}` : ''}</td><td class="mono">$${fmtNum(c.discountCents / 100, 2)}</td><td><span class="badge ${c.active ? 'badge-live' : 'badge-muted'}">${c.active ? T({ ar: 'مفعّل', en: 'Active', he: 'פעיל', es: 'Activo', zh: '启用' }) : T({ ar: 'موقوف', en: 'Off', he: 'כבוי', es: 'Inactivo', zh: '停用' })}</span></td>
          <td class="cm-row-actions"><button type="button" class="btn btn-sm" data-edit>${T({ ar: 'تعديل', en: 'Edit', he: 'ערוך', es: 'Editar', zh: '编辑' })}</button><button type="button" class="btn btn-sm" data-toggle>${c.active ? T({ ar: 'وقّف', en: 'Turn off', he: 'כבה', es: 'Desactivar', zh: '停用' }) : T({ ar: 'شغّل', en: 'Turn on', he: 'הפעל', es: 'Activar', zh: '启用' })}</button><button type="button" class="btn btn-sm btn-ghost" data-del aria-label="delete">${icons.trash}</button></td></tr>`).join('')}</tbody></table>` : `<p class="muted">${T({ ar: 'ما في كوبونات لسا.', en: 'No coupons yet.', he: 'אין קופונים עדיין.', es: 'Aún no hay cupones.', zh: '暂无优惠券。' })}</p>`;
      $('[data-coupons]')._items = r.items;
    } catch (e) { $('[data-coupons]').innerHTML = `<p class="muted">${esc(errText(e.code))}</p>`; }
  }
  const saveCoupon = async (b) => { await apiRequest('PUT', '/api/admin/coupons', b); toast(tx({ ar: 'انحفظ الكوبون', en: 'Coupon saved', he: 'הקופון נשמר', es: 'Cupón guardado', zh: '优惠券已保存' }), 'success'); loadCoupons(); };
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const b = { code: form.code.value.trim().toUpperCase(), type: form.type.value, value: Number(form.value.value), startsAt: form.startsAt.value || null, endsAt: form.endsAt.value ? `${form.endsAt.value}T23:59:59Z` : null, maxUses: form.maxUses.value ? Number(form.maxUses.value) : null, plans: [...form.querySelectorAll('[data-pc]:checked')].map((x) => x.value), active: form.active.checked };
    try { await saveCoupon(b); form.reset(); form.active.checked = true; } catch (er) { toast(errText(er.code), 'error'); }
  });
  el.addEventListener('click', async (e) => {
    const sp = e.target.closest('[data-save-plan]');
    if (sp) {
      const row = sp.closest('[data-pid]'); const body = { id: row.dataset.pid, price: Number(row.querySelector('[data-price]').value), active: row.querySelector('[data-active]').checked };
      const mo = row.querySelector('[data-months]'); if (mo) body.months = Number(mo.value);
      try { await apiRequest('PUT', '/api/admin/plans', body); toast(tx({ ar: 'انحفظ السعر', en: 'Price saved', he: 'המחיר נשמר', es: 'Precio guardado', zh: '价格已保存' }), 'success'); loadPlans(); } catch (er) { toast(errText(er.code), 'error'); }
      return;
    }
    const row = e.target.closest('[data-code]'); if (!row) return;
    const c = ($('[data-coupons]')._items || []).find((x) => x.code === row.dataset.code); if (!c) return;
    if (e.target.closest('[data-edit]')) {
      form.code.value = c.code; form.type.value = c.type; form.value.value = c.value; form.startsAt.value = day(c.startsAt); form.endsAt.value = day(c.endsAt); form.maxUses.value = c.maxUses ?? ''; form.active.checked = c.active;
      form.querySelectorAll('[data-pc]').forEach((x) => { x.checked = c.plans.includes(x.value); }); form.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    if (e.target.closest('[data-toggle]')) { try { await saveCoupon({ ...c, startsAt: c.startsAt ? new Date(c.startsAt).toISOString() : null, endsAt: c.endsAt ? new Date(c.endsAt).toISOString() : null, active: !c.active }); } catch (er) { toast(errText(er.code), 'error'); } }
    if (e.target.closest('[data-del]') && confirm(tx({ ar: `حذف ${c.code}؟`, en: `Delete ${c.code}?`, he: `למחוק את ${c.code}?`, es: `¿Eliminar ${c.code}?`, zh: `删除 ${c.code}？` }))) { try { await apiRequest('DELETE', `/api/admin/coupons?code=${encodeURIComponent(c.code)}`); loadCoupons(); } catch (er) { toast(errText(er.code), 'error'); } }
  });
  loadPlans(); loadCoupons();
  return el;
}
