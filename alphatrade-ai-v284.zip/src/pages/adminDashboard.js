// Owner control panel (v230): who is on line, sign-in activity, subscribers and revenue per plan (cheapest → highest).
// Owners only: hidden from customers in the menu, and the server answers 403 to anyone who is not a verified owner e-mail.
// Every value comes from GET /api/admin/dashboard (aggregates only; the recent sign-ins list is masked by the server).
// Everything is rendered with esc(); numbers are formatted here, nothing from the server is inserted as HTML.
import { h, esc, fmtNum } from '../utils/dom.js';
import { icons } from '../components/icons.js';
import { t, getLang, getLocale } from '../i18n/index.js';
import { tx } from '../i18n/tx.js';
import { apiRequest } from '../services/ai/gateway.js';
import { isAdmin } from '../config/admin.js';
import { errText, pageHead } from './community.js';
import '../styles/community.css';
import '../styles/adminDashboard.css';

const REFRESH_MS = 30_000;
const L = (ar, en) => tx({ ar, en });
// amounts are wrapped in Unicode isolates so "$" stays on the left of the number inside Arabic sentences
const usd = (cents, whole = false) => `\u2066$${fmtNum((Number(cents) || 0) / 100, whole || !((Number(cents) || 0) % 100) ? 0 : 2)}\u2069`;
const int = (n) => fmtNum(Number(n) || 0, 0);
const planName = (id) => (id === 'channel' ? L('القناة المستقلة', 'Channel only') : t(`pricing.plans.${id}`) || id);
const period = (m) => (m === 1 ? L('شهر', '1 month') : m === 12 ? L('سنة', '12 months') : L(`${m} أشهر`, `${m} months`));
const ago = (ms) => { const s = Math.max(0, Math.round((Date.now() - ms) / 1000)); if (s < 60) return L('هلّق', 'now'); const m = Math.round(s / 60); if (m < 60) return L(`قبل ${m} د`, `${m} min ago`); const hh = Math.round(m / 60); return hh < 48 ? L(`قبل ${hh} س`, `${hh} h ago`) : new Date(ms).toLocaleDateString(getLocale()); };

export function renderAdminDashboard() {
  const el = h(`<section class="subpage tool cm adm page-enter">
    ${pageHead('grid', L('لوحة التحكم', 'Control panel'), L('المتصلين، تسجيلات الدخول، والاشتراكات والأرباح — لحظياً.', 'Who is on line, sign-ins, subscriptions and revenue — live.'))}
    <div class="tool-body">
      <p class="muted cm-own">${icons.lock}<span>${esc(L('هالقسم لأصحاب الشركة بس. ما بيبين للعملاء، والسيرفر بيرفض أي طلب من غيرهم.', 'Owners only. Hidden from customers, and the server refuses anyone else.'))}</span></p>
      <div class="adm-bar"><span class="adm-live" data-live><i></i><span data-updated>${esc(L('جارٍ التحميل…', 'Loading…'))}</span></span><button type="button" class="btn btn-sm" data-refresh>${icons.refresh}<span>${esc(L('تحديث', 'Refresh'))}</span></button></div>
      <div data-body><div class="perf-loading"><span class="spinner"></span></div></div>
    </div></section>`);
  const body = el.querySelector('[data-body]');
  if (!isAdmin()) { body.innerHTML = `<div class="card sig-empty">${icons.lock}<span>${esc(errText('not_owner'))}</span></div>`; el.querySelector('.adm-bar').hidden = true; return el; }

  let timer = 0; let busy = false;
  const load = async () => {
    if (busy || !el.isConnected) return; busy = true;
    let d;
    try { d = await apiRequest('GET', '/api/admin/dashboard', undefined, 15000); }
    catch (e) {
      el.querySelector('[data-live]').classList.add('is-err');
      el.querySelector('[data-updated]').textContent = errText(e?.code || 'server_unreachable');
      if (!body.querySelector('.adm-grid')) body.innerHTML = `<div class="card sig-empty">${icons.alert}<span>${esc(errText(e?.code || 'server_unreachable'))}</span></div>`;
      busy = false; return;
    }
    try {
      body.innerHTML = view(d);
      el.querySelector('[data-updated]').textContent = L(`مباشر · آخر تحديث ${new Date(d.at).toLocaleTimeString(getLocale())}`, `Live · updated ${new Date(d.at).toLocaleTimeString(getLocale())}`);
      el.querySelector('[data-live]').classList.remove('is-err');
    } catch (e) {   // a rendering problem is reported as such (never disguised as a network error)
      console.error('[admin dashboard]', e);
      el.querySelector('[data-live]').classList.add('is-err');
      el.querySelector('[data-updated]').textContent = L('تعذّر عرض البيانات.', 'Could not display the data.');
    } finally { busy = false; }
  };
  const tick = () => { if (!el.isConnected) { clearInterval(timer); document.removeEventListener('visibilitychange', vis); return; } if (!document.hidden) load(); };
  const vis = () => { if (!document.hidden) load(); };
  el.querySelector('[data-refresh]').addEventListener('click', load);
  document.addEventListener('visibilitychange', vis);
  timer = setInterval(tick, REFRESH_MS);
  requestAnimationFrame(load);   // after the page is on screen (load() skips a detached page)
  return el;
}

function view(d) {
  const u = d.users; const lg = d.logins; const s = d.subscriptions;
  const onPct = u.members ? Math.round((u.online / u.members) * 100) : 0;
  const kpi = (cls, icon, label, value, sub = '') => `<div class="adm-kpi ${cls}"><span class="adm-kpi-ico">${icons[icon] || ''}</span><div><span class="adm-kpi-label">${esc(label)}</span><b>${esc(value)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</div></div>`;

  // 14-day sign-ins chart (inline SVG, no library): bars = sign-ins, dots = distinct members
  const series = lg.series || []; const max = Math.max(1, ...series.map((x) => x.logins));
  const W = 640, H = 170, pad = 22, bw = (W - pad * 2) / Math.max(1, series.length);
  const bars = series.map((x, i) => {
    const xi = pad + i * bw; /* time runs left → right in every language, like the other charts */ const hh = Math.round((x.logins / max) * (H - 50)); const uy = H - 26 - Math.round((x.users / max) * (H - 50));
    const label = new Date(`${x.day}T12:00:00Z`).toLocaleDateString(getLocale(), { day: 'numeric', month: 'numeric' });
    return `<g><rect x="${(xi + bw * 0.18).toFixed(1)}" y="${H - 26 - hh}" width="${(bw * 0.64).toFixed(1)}" height="${Math.max(hh, x.logins ? 2 : 0)}" rx="3" class="adm-b"><title>${esc(`${label}: ${x.logins} ${L('تسجيل دخول', 'sign-ins')} · ${x.users} ${L('عضو', 'members')} · ${x.signups} ${L('جديد', 'new')}`)}</title></rect>${x.users ? `<circle cx="${(xi + bw / 2).toFixed(1)}" cy="${uy}" r="3" class="adm-u"/>` : ''}${i % 2 === (series.length - 1) % 2 ? `<text x="${(xi + bw / 2).toFixed(1)}" y="${H - 8}" text-anchor="middle" class="adm-ax">${esc(label)}</text>` : ''}</g>`;
  }).join('');
  const devices = Object.entries(lg.devices || {}).sort((a, b) => b[1] - a[1]); const devTotal = devices.reduce((a, [, n]) => a + n, 0) || 1;

  const plans = s.plans || []; const maxSubs = Math.max(1, ...plans.map((p) => p.subscribers));
  const planRows = plans.map((p, i) => `<tr>
      <th scope="row"><div class="adm-pcell"><span class="adm-rank">${i + 1}</span><span class="adm-pn">${esc(planName(p.id))}</span>${p.onSale ? '' : `<em class="adm-off">${esc(L('موقوفة', 'off sale'))}</em>`}</div></th>
      <td class="num" data-label="${esc(L('السعر', 'Price'))}"><b>${esc(usd(p.priceCents))}</b><small>${esc(period(p.months))}</small></td>
      <td class="adm-subs" data-label="${esc(L('المشتركين', 'Subscribers'))}"><div class="adm-scell"><div class="adm-meter"><i style="width:${Math.round((p.subscribers / maxSubs) * 100)}%"></i></div><b class="num">${esc(int(p.subscribers))}</b></div></td>
      <td class="num" data-label="${esc(L('دخل شهري مكافئ', 'Monthly equiv.'))}">${esc(usd(p.mrrCents))}</td>
      <td class="num" data-label="${esc(L('أرباح هالشهر', 'This month'))}">${esc(usd(p.monthCents))}</td>
      <td class="num strong" data-label="${esc(L('إجمالي الأرباح', 'Total revenue'))}">${esc(usd(p.revenueCents))}</td>
    </tr>`).join('');
  const addonRev = (s.addons || []).reduce((a, x) => a + x.revenueCents, 0);

  return `<div class="adm-grid">
    <div class="adm-kpis">
      ${kpi('k-on', 'pulse', L('متصلين هلّق', 'Online now'), int(u.online), L(`${onPct}% من الأعضاء · آخر ${d.onlineWindowMin} دقايق`, `${onPct}% of members · last ${d.onlineWindowMin} min`))}
      ${kpi('k-off', 'user', L('غير متصلين', 'Offline'), int(u.offline), L(`نشطين آخر ساعة: ${int(u.lastHour)}`, `Active in the last hour: ${int(u.lastHour)}`))}
      ${kpi('k-mem', 'grid', L('إجمالي الأعضاء', 'Members'), int(u.members), L(`جدد اليوم: ${int(lg.signups?.today)}`, `New today: ${int(lg.signups?.today)}`))}
      ${kpi('k-sub', 'crown', L('المشتركين', 'Subscribers'), int(s.subscribers), L(`${s.conversionPct}% من الأعضاء`, `${s.conversionPct}% of members`))}
      ${kpi('k-mrr', 'trend', L('الدخل الشهري المتكرر', 'Monthly recurring'), usd(s.totals.mrrCents, true), L('من الاشتراكات الفعّالة', 'from active subscriptions'))}
      ${kpi('k-rev', 'wallet', L('أرباح هالشهر', 'Revenue this month'), usd(s.totals.monthCents, true), L(`الإجمالي ${usd(s.totals.revenueCents, true)}`, `All time ${usd(s.totals.revenueCents, true)}`))}
    </div>

    <section class="card adm-card adm-users">
      <h2>${icons.user}<span>${esc(L('المستخدمين', 'Users'))}</span></h2>
      <div class="adm-split" role="img" aria-label="${esc(L(`${u.online} متصل و ${u.offline} غير متصل`, `${u.online} online, ${u.offline} offline`))}"><i class="on" style="flex:${u.online || 0}"></i><i class="off" style="flex:${u.offline || (u.online ? 0 : 1)}"></i></div>
      <div class="adm-legend"><span class="on"><i></i>${esc(L('متصل', 'Online'))} <b>${esc(int(u.online))}</b></span><span class="off"><i></i>${esc(L('غير متصل', 'Offline'))} <b>${esc(int(u.offline))}</b></span></div>
      <dl class="adm-dl">
        <div><dt>${esc(L('نشطين آخر 24 ساعة', 'Active, last 24 h'))}</dt><dd>${esc(int(lg.active?.d1))}</dd></div>
        <div><dt>${esc(L('نشطين آخر 7 أيام', 'Active, last 7 days'))}</dt><dd>${esc(int(lg.active?.d7))}</dd></div>
        <div><dt>${esc(L('نشطين آخر 30 يوم', 'Active, last 30 days'))}</dt><dd>${esc(int(lg.active?.d30))}</dd></div>
      </dl>
      ${u.trackingSinceMin < 5 ? `<p class="adm-note">${esc(L('السيرفر اشتغل من شوي — عدد المتصلين بيكتمل خلال دقيقة أو دقيقتين.', 'The server started a moment ago — the online count fills in within a minute or two.'))}</p>` : ''}
    </section>

    <section class="card adm-card adm-logins">
      <h2>${icons.fingerprint}<span>${esc(L('إحصائيات تسجيل الدخول', 'Sign-in statistics'))}</span></h2>
      <div class="adm-trio">
        <div><b>${esc(int(lg.today))}</b><span>${esc(L('اليوم', 'Today'))}</span></div>
        <div><b>${esc(int(lg.d7))}</b><span>${esc(L('آخر 7 أيام', 'Last 7 days'))}</span></div>
        <div><b>${esc(int(lg.d30))}</b><span>${esc(L('آخر 30 يوم', 'Last 30 days'))}</span></div>
        <div><b>${esc(int(lg.signups?.d30))}</b><span>${esc(L('أعضاء جدد (30 يوم)', 'New members (30 d)'))}</span></div>
      </div>
      <svg class="adm-chart" dir="ltr" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(L('تسجيلات الدخول آخر 14 يوم', 'Sign-ins over the last 14 days'))}"><line x1="${pad}" x2="${W - pad}" y1="${H - 26}" y2="${H - 26}" class="adm-base"/>${bars}</svg>
      <p class="adm-key"><span><i class="b"></i>${esc(L('تسجيلات الدخول', 'Sign-ins'))}</span><span><i class="u"></i>${esc(L('أعضاء مختلفين', 'Distinct members'))}</span></p>
      ${devices.length ? `<div class="adm-dev">${devices.map(([k, n]) => `<div><span>${esc(k)}</span><div class="adm-meter"><i style="width:${Math.round((n / devTotal) * 100)}%"></i></div><b>${Math.round((n / devTotal) * 100)}%</b></div>`).join('')}</div>` : ''}
      <details class="adm-recent"><summary>${esc(L('آخر تسجيلات الدخول', 'Latest sign-ins'))} <small>(${esc(int(lg.recent?.length))})</small></summary>
        ${(lg.recent || []).length ? `<ul>${lg.recent.map((r) => `<li><span dir="ltr">${esc(r.who)}</span><span>${esc(r.device)}${r.newDevice ? ` <em>${esc(L('جهاز جديد', 'new device'))}</em>` : ''}</span><time>${esc(ago(r.at))}</time></li>`).join('')}</ul>` : `<p class="muted">${esc(L('ما في تسجيلات دخول آخر 7 أيام.', 'No sign-ins in the last 7 days.'))}</p>`}
      </details>
    </section>

    <section class="card adm-card adm-plans">
      <h2>${icons.crown}<span>${esc(L('الاشتراكات حسب الباقة', 'Subscriptions by plan'))}</span><small>${esc(L('من الأقل للأعلى', 'cheapest → highest'))}</small></h2>
      <div class="adm-table-wrap"><table class="adm-table">
        <thead><tr><th scope="col">${esc(L('الباقة', 'Plan'))}</th><th scope="col">${esc(L('السعر', 'Price'))}</th><th scope="col">${esc(L('المشتركين', 'Subscribers'))}</th><th scope="col">${esc(L('دخل شهري مكافئ', 'Monthly equiv.'))}</th><th scope="col">${esc(L('أرباح هالشهر', 'This month'))}</th><th scope="col">${esc(L('إجمالي الأرباح', 'Total revenue'))}</th></tr></thead>
        <tbody>${planRows || `<tr><td colspan="6" class="muted">${esc(L('ما في باقات.', 'No plans.'))}</td></tr>`}</tbody>
        <tfoot><tr><th scope="row">${esc(L('المجموع', 'Total'))}</th><td class="adm-empty"></td><td class="num" data-label="${esc(L('المشتركين', 'Subscribers'))}"><b>${esc(int(s.subscribers))}</b></td><td class="num" data-label="${esc(L('دخل شهري مكافئ', 'Monthly equiv.'))}">${esc(usd(s.totals.mrrCents))}</td><td class="num" data-label="${esc(L('أرباح هالشهر', 'This month'))}">${esc(usd(s.totals.monthCents))}</td><td class="num strong" data-label="${esc(L('إجمالي الأرباح', 'Total revenue'))}">${esc(usd(s.totals.revenueCents))}</td></tr></tfoot>
      </table></div>
      <p class="adm-note">${esc(L(`الإضافات (توصيات إضافية): ${usd(addonRev)} · «دخل شهري مكافئ» = سعر الباقة ÷ عدد أشهرها × المشتركين الفعّالين. الأرباح من المدفوعات الحقيقية المسجّلة بس${s.test.payments ? ` — ${s.test.payments} دفعة تجريبية (${usd(s.test.cents)}) مش محسوبة` : ''}.`,
        `Add-ons (extra recommendations): ${usd(addonRev)} · "Monthly equiv." = plan price ÷ its months × active subscribers. Revenue counts recorded live payments only${s.test.payments ? ` — ${s.test.payments} test payment(s) (${usd(s.test.cents)}) excluded` : ''}.`))}</p>
    </section>
  </div>`;
}
