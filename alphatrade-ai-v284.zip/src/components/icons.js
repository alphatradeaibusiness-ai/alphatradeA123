// Inline SVG icon set (stroke icons, 24×24 viewBox, currentColor).
const s = (body, extra = '') => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${body}</svg>`;

export const icons = {
  mail: s('<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m4 7 8 6 8-6"/>'),
  lock: s('<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/><circle cx="12" cy="15.5" r="1.2"/>'),
  user: s('<circle cx="12" cy="8" r="4"/><path d="M4 20c1.5-3.5 4.5-5 8-5s6.5 1.5 8 5"/>'),
  eye: s('<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>'),
  eyeOff: s('<path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4M6.6 6.6A17 17 0 0 0 2 12s3.6 7 10 7a9.6 9.6 0 0 0 5.4-1.6M9.9 9.9a3 3 0 0 0 4.2 4.2"/>'),
  arrow: s('<path d="M5 12h14M13 6l6 6-6 6"/>'),
  globe: s('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3Z"/>'),
  moon: s('<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z"/>'),
  sun: s('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'),
  chevronDown: s('<path d="m6 9 6 6 6-6"/>'),
  search: s('<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>'),
  crosshair: s('<path d="M12 3v6M12 15v6M3 12h6M15 12h6"/>'),
  trend: s('<path d="M4 20 20 4"/><circle cx="5" cy="19" r="1.6"/><circle cx="19" cy="5" r="1.6"/>'),
  hline: s('<path d="M3 12h18"/><circle cx="12" cy="12" r="1.6"/>'),
  fib: s('<path d="M3 5h18M3 9.5h18M3 14h18M3 19h18"/><path d="M6 5v14" stroke-dasharray="2 2"/>'),
  frvp: s('<path d="M4 4v16M20 4v16"/><path d="M4 7h7M4 10.5h11M4 14h8M4 17.5h5"/>'),
  ruler: s('<rect x="2.5" y="8" width="19" height="8" rx="1.5" transform="rotate(-35 12 12)"/><path d="m8 12.5 1.2 1.7M11 10.4l1.2 1.7M14 8.3l1.2 1.7"/>'),
  text: s('<path d="M5 6V4.5h14V6M12 4.5v15M9 19.5h6"/>'),
  zoomIn: s('<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2M11 8v6M8 11h6"/>'),
  zoomOut: s('<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2M8 11h6"/>'),
  reset: s('<path d="M4 12a8 8 0 1 0 2.3-5.7"/><path d="M4 4v4h4"/>'),
  trash: s('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'),
  settings: s('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/>'),
  camera: s('<path d="M4 8h3l2-3h6l2 3h3v11H4Z"/><circle cx="12" cy="13" r="3.5"/>'),
  candles: s('<path d="M7 3v3M7 16v5M17 3v5M17 15v6"/><rect x="5" y="6" width="4" height="10" rx="1"/><rect x="15" y="8" width="4" height="7" rx="1"/>'),
  lineChart: s('<path d="m3 17 5-6 4 4 5-7 4 5"/>'),
  indicators: s('<path d="M3 17 8 9l4 5 3-4 6 7"/><path d="M14 4h3v3"/><path d="M17 4l-4 4"/>'),
  shield: s('<path d="M12 3 5 6v5.5c0 4.3 3 8 7 9.5 4-1.5 7-5.2 7-9.5V6Z"/><path d="m9 12 2 2 4-4"/>'),
  bars: s('<path d="M4 20h16"/><rect x="5" y="12" width="3" height="6" rx=".6"/><rect x="10.5" y="8" width="3" height="10" rx=".6"/><rect x="16" y="4.5" width="3" height="13.5" rx=".6"/>'),
  bolt: s('<path d="M13 2 4 14h7l-1 8 9-12h-7Z"/>'),
  send: s('<path d="M4 12 20 4l-4 16-4-7Z"/><path d="m12 13 8-9"/>'),
  home: s('<path d="M4 11 12 4l8 7"/><path d="M6 10v10h12V10"/><path d="M10 20v-5h4v5"/>'),
  book: s('<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2Z"/><path d="M4 19V5M8 7h7"/>'),
  calendar: s('<rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/><path d="M8 14h2M12 14h2M16 14h.01M8 17h2"/>'),
  wallet: s('<path d="M4 7.5A2.5 2.5 0 0 1 6.5 5H18v3"/><rect x="4" y="8" width="16" height="11" rx="2.5"/><path d="M16 13.5h2"/>'),
  journal: s('<path d="M6 3.5h11a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2H6Z"/><path d="M6 3.5v17M9.5 8h6M9.5 11.5h6M9.5 15h4"/>'),
  radar: s('<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><path d="M12 12 18 6"/><circle cx="15.5" cy="9" r="1" fill="currentColor"/>'),
  alarm: s('<circle cx="12" cy="13" r="7"/><path d="M12 9.5V13l2.5 2M4 5l3-2.5M20 5l-3-2.5"/>'),
  flask: s('<path d="M9.5 3h5M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4a2 2 0 0 0 1.8-3l-5-9V3"/><path d="M7.5 14.5h9"/>'),
  grid: s('<rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/>'),
  bulb: s('<path d="M9 17h6M10 20.5h4"/><path d="M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3Z"/>'),
  news: s('<rect x="3.5" y="4.5" width="14" height="15" rx="2"/><path d="M17.5 8.5h3v9a2 2 0 0 1-2 2h-1M7 8.5h7M7 12h7M7 15.5h4"/>'),
  xlogo: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.8 3h3.1l-6.8 7.8L22 21h-6.2l-4.9-6.4L5.3 21H2.2l7.3-8.3L2 3h6.3l4.4 5.9Zm-1.1 16.2h1.7L7.4 4.7H5.6Z"/></svg>',
  brain: s('<path d="M9.5 4.5A2.5 2.5 0 0 0 7 7a2.6 2.6 0 0 0-2 4.3A2.8 2.8 0 0 0 6 16a2.6 2.6 0 0 0 3.5 3.3V4.5Z"/><path d="M14.5 4.5A2.5 2.5 0 0 1 17 7a2.6 2.6 0 0 1 2 4.3 2.8 2.8 0 0 1-1 4.7 2.6 2.6 0 0 1-3.5 3.3V4.5Z"/><path d="M9.5 9H8M14.5 9H16M9.5 14H8M14.5 14H16"/>'),
  levels: s('<path d="M3 6h18M3 12h18M3 18h18" stroke-dasharray="2.5 2.5"/><path d="M4 16l4-6 4 3 4-7 4 4"/>'),
  flame: s('<path d="M12 3c1 3.5 5 5.5 5 10a5 5 0 0 1-10 0c0-2.2 1.2-3.8 2.5-5 .2 1.7 1 2.8 2 3.2C11 9 11 6 12 3Z"/>'),
  pulse: s('<path d="M3 12h4l2-6 4 12 2-6h6"/>'),
  drop: s('<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11Z"/><path d="M9.5 15a2.5 2.5 0 0 0 2.5 2.5"/>'),
  layers: s('<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/>'),
  store: s('<path d="M4 9.5 5.5 4h13L20 9.5"/><path d="M4 9.5a2.7 2.7 0 0 0 5.3 0 2.7 2.7 0 0 0 5.4 0 2.7 2.7 0 0 0 5.3 0"/><path d="M5.5 12.5V20h13v-7.5M10 20v-4.5h4V20"/>'),
  plus: s('<path d="M12 5v14M5 12h14"/>'),
  download: s('<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>'),
  refresh: s('<path d="M20 11a8 8 0 1 0-2.3 5.7M20 5v6h-6"/>'),
  external: s('<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>'),
  bell: s('<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15Z"/><path d="M10 20a2 2 0 0 0 4 0"/>'),
  mic: s('<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0"/><path d="M12 17.5V21"/>'),
  card: s('<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M3 10h18"/><path d="M7 15h4"/>'),
  face: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2"/><path d="M9 9.5v1M15 9.5v1M12 9v4h-1M9.5 15.5c1.4 1.2 3.6 1.2 5 0"/></svg>',
  fingerprint: s('<path d="M7.5 19.5c1.2-2 1.8-4.5 1.8-7.5a2.7 2.7 0 0 1 5.4 0c0 1.2-.1 2.4-.3 3.5"/><path d="M5 16.5c.6-1.4.9-3 .9-4.5a6.1 6.1 0 0 1 9.8-4.8"/><path d="M18 9.3c.3.8.4 1.7.4 2.7 0 3-.6 5.6-1.6 7.7"/><path d="M12 12c0 3.2-.8 6-2.3 8.2"/>'),
  piggy: s('<path d="M5 11a7 6 0 0 1 12.6-3.5L20 7v3.5l1 .5v3l-2 .5a7 6 0 0 1-2.5 2.5V20h-3v-2h-3v2h-3v-3A6 6 0 0 1 5 11Z"/><circle cx="15.5" cy="10.5" r=".6"/>'),
  vault: s('<rect x="3.5" y="4" width="17" height="16" rx="2.5"/><circle cx="12" cy="12" r="3.5"/><path d="M12 8.5V7M12 17v-1.5M15.5 12H17M7 12h1.5"/>'),
  chat: s('<path d="M4.5 5.5h15v10h-9l-4 3.5v-3.5h-2Z"/>'),
  gift: s('<rect x="4" y="9" width="16" height="11" rx="1.5"/><path d="M3 9h18M12 9v11"/><path d="M12 9c-2-4-6-3.5-5-1s5 1 5 1Zm0 0c2-4 6-3.5 5-1s-5 1-5 1Z"/>'),
  swap: s('<path d="M7 7h12l-3-3M17 17H5l3 3"/>'),
  globe2: s('<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.6 2.5 14.4 0 17M12 3.5c-2.5 2.6-2.5 14.4 0 17"/>'),
  trophy: s('<path d="M8 4h8v5a4 4 0 0 1-8 0Z"/><path d="M8 6H5a3 3 0 0 0 3 4M16 6h3a3 3 0 0 1-3 4"/><path d="M12 13v4M8.5 20h7M10 17h4v3h-4Z"/>'),
  crown: s('<path d="m3 8 4.5 4L12 5l4.5 7L21 8l-2 11H5Z"/>'),
  menu: s('<path d="M4 7h16M4 12h16M4 17h16"/>'),
  close: s('<path d="M6 6l12 12M18 6 6 18"/>'),
  check: s('<path d="m5 12 5 5 9-10"/>'),
  alert: s('<path d="M12 3 2 20h20Z"/><path d="M12 10v4M12 17h.01"/>'),
  info: s('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>'),
  logout: s('<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>'),
  sparkle: s('<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/>'),
  google: `<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M22.6 12.3c0-.8-.1-1.5-.2-2.3H12v4.3h6a5.1 5.1 0 0 1-2.2 3.4v2.8h3.6c2-1.9 3.2-4.7 3.2-8.2Z"/><path fill="#34A853" d="M12 23c3 0 5.5-1 7.4-2.7l-3.6-2.8c-1 .7-2.3 1.1-3.8 1.1-2.9 0-5.4-2-6.3-4.6H2v2.9A11 11 0 0 0 12 23Z"/><path fill="#FBBC05" d="M5.7 14a6.6 6.6 0 0 1 0-4.1V7H2a11 11 0 0 0 0 9.9Z"/><path fill="#EA4335" d="M12 5.4c1.6 0 3.1.6 4.2 1.7l3.2-3.2A11 11 0 0 0 2 7l3.7 2.9C6.6 7.4 9.1 5.4 12 5.4Z"/></svg>`,
  apple: `<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M16.4 12.6c0-2.6 2.1-3.8 2.2-3.9a4.8 4.8 0 0 0-3.8-2c-1.6-.2-3.1.9-3.9.9-.8 0-2-.9-3.4-.9a5 5 0 0 0-4.2 2.6c-1.8 3.1-.5 7.7 1.3 10.2.8 1.2 1.8 2.6 3.1 2.6 1.2-.1 1.7-.8 3.2-.8s1.9.8 3.2.8 2.2-1.3 3-2.5a10.5 10.5 0 0 0 1.4-2.8 4.3 4.3 0 0 1-2.1-4.2ZM13.9 5a4.4 4.4 0 0 0 1-3.2 4.5 4.5 0 0 0-2.9 1.5 4.2 4.2 0 0 0-1.1 3.1A3.7 3.7 0 0 0 13.9 5Z"/></svg>`,
};

let logoId = 0;
/** The AlphaTrade mark (v170): an "A" shaped like a rising arrow, with a price line breaking upward through it, on a dark tile. */
export function logoMark(size = 36) {
  const id = `lg${++logoId}`;
  return `<svg class="logo-mark" width="${size}" height="${size}" viewBox="0 0 64 64" aria-hidden="true">
    <defs>
      <linearGradient id="${id}h" x1="6" y1="60" x2="58" y2="4" gradientUnits="userSpaceOnUse">
        <stop offset="0" class="lg-a0"/><stop offset=".55" class="lg-a3"/><stop offset="1" class="lg-b"/>
      </linearGradient>
      <linearGradient id="${id}a" x1="14" y1="52" x2="50" y2="12" gradientUnits="userSpaceOnUse">
        <stop offset="0" class="lg-a0"/><stop offset=".55" class="lg-a3"/><stop offset="1" class="lg-b"/>
      </linearGradient>
      <radialGradient id="${id}f" cx="32" cy="24" r="40" gradientUnits="userSpaceOnUse">
        <stop offset="0" class="lg-core"/><stop offset="1" stop-color="#07060f"/>
      </radialGradient>
      <linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".45"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
      <clipPath id="${id}k"><rect x="3" y="3" width="58" height="58" rx="15"/></clipPath>
    </defs>
    <rect x="3" y="3" width="58" height="58" rx="15" fill="url(#${id}f)"/>
    <g clip-path="url(#${id}k)"><g transform="skewX(-20)"><rect class="lm-sheen" x="-34" y="0" width="16" height="64" fill="url(#${id}s)"/></g></g>
    <rect class="lm-hex" x="3" y="3" width="58" height="58" rx="15" fill="none" stroke="url(#${id}h)" stroke-width="2" pathLength="200" opacity=".85"/>
    <path class="lm-a" d="M14.5 50 32 13.5 49.5 50" fill="none" stroke="url(#${id}a)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" pathLength="80"/>
    <path class="lm-line" d="M21 40.5 28.5 33.5 34 37.5 43.5 27" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round" pathLength="40"/>
    <path class="lm-line" d="M38.5 26.5H44V32" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round" pathLength="40"/>
    <circle class="lm-ping lg-bfill" cx="44" cy="26.5" r="3.2"/>
  </svg>`;
}

/** Asset icons for the listed instruments. */
export function assetIcon(kind, size = 26) {
  const box = (inner, bg) => `<svg width="${size}" height="${size}" viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="16" fill="${bg}"/>${inner}</svg>`;
  switch (kind) {
    case 'btc':
      return box('<path fill="#fff" d="M21.6 14.1c.3-2-1.2-3-3.3-3.8l.7-2.7-1.6-.4-.7 2.6-1.3-.3.7-2.7-1.6-.4-.7 2.7-1-.3-2.3-.5-.4 1.7s1.2.3 1.2.3c.7.2.8.6.8 1l-.8 3.2.2.1-.2-.1-1.1 4.4c-.1.2-.3.5-.8.4l-1.2-.3-.8 1.9 2.1.5 1.2.3-.7 2.8 1.6.4.7-2.7 1.3.3-.7 2.7 1.6.4.7-2.8c2.8.5 4.9.3 5.8-2.2.7-2-.1-3.2-1.5-4 1.1-.2 1.9-1 2.1-2.4Zm-3.8 5.3c-.5 2-3.9.9-5 .6l.9-3.6c1.1.3 4.6.8 4.1 3Zm.5-5.4c-.5 1.8-3.3.9-4.2.7l.8-3.2c.9.2 3.9.6 3.4 2.5Z"/>', '#F7931A');
    case 'eth':
      return box('<path fill="#c9b8ff" d="M16 5v8.1l6.8 3Z"/><path fill="#fff" d="M16 5 9.2 16.1l6.8-3Z"/><path fill="#c9b8ff" d="M16 21.5V27l6.8-9.5Z"/><path fill="#fff" d="M16 27v-5.5l-6.8-4Z"/><path fill="#8c7ae6" d="m16 20.2 6.8-4L16 13.1Z"/><path fill="#b3a4f5" d="m9.2 16.2 6.8 4v-7.1Z"/>', '#3c3c75');
    case 'sol':
      return `<svg width="${size}" height="${size}" viewBox="0 0 32 32" aria-hidden="true"><defs><linearGradient id="solg" x1="8" y1="24" x2="24" y2="8" gradientUnits="userSpaceOnUse"><stop stop-color="#9945FF"/><stop offset="1" stop-color="#14F195"/></linearGradient></defs><circle cx="16" cy="16" r="16" fill="#111827"/><path fill="url(#solg)" d="M10.4 19.8a.6.6 0 0 1 .4-.2h12.7c.3 0 .4.3.2.5l-2.1 2.2a.6.6 0 0 1-.4.2H8.5c-.3 0-.4-.3-.2-.5Zm0-8.6a.6.6 0 0 1 .4-.2h12.7c.3 0 .4.3.2.5l-2.1 2.2a.6.6 0 0 1-.4.2H8.5c-.3 0-.4-.3-.2-.5Zm11.2 4.2a.6.6 0 0 0-.4-.2H8.5c-.3 0-.4.3-.2.5l2.1 2.2c.1.1.3.2.4.2h12.7c.3 0 .4-.3.2-.5Z"/></svg>`;
    case 'bnb':
      return box('<path fill="#fff" d="m16 7.5 2.4 2.4-5.9 5.9-2.4-2.4Zm3.6 3.6 2.4 2.4-9.5 9.5-2.4-2.4Zm-11.2 2.4 2.4 2.4-2.4 2.4L6 16Zm15.2 0L26 16l-2.4 2.4-2.4-2.4ZM16 21.2l2.4 2.4-2.4 2.4-2.4-2.4Zm3.6-3.6 2.4 2.4-2.4 2.4-2.4-2.4Z" transform="rotate(0 16 16)"/>', '#F3BA2F');
    case 'us30':
    case 'us100':
    case 'spx500':
    case 'uk100':
    case 'ger40':
    case 'fra40':
    case 'eu50':
    case 'jp225':
    case 'hk50':
    case 'aus200':
    case 'spain35':
    case 'swiss20':
    case 'ned25':
    case 'kospi':
    case 'india50': {
      // Generic index badges (not exchange logos): short label on a coloured disc.
      const badges = {
        us30: ['30', '#1d4ed8'], us100: ['100', '#0f766e'], spx500: ['500', '#9f1239'],
        uk100: ['UK', '#b91c1c'], ger40: ['DAX', '#111827'], fra40: ['CAC', '#1e40af'],
        eu50: ['EU', '#0e7490'], jp225: ['JP', '#be123c'], hk50: ['HK', '#0f766e'],
        aus200: ['AUS', '#92400e'], spain35: ['IBEX', '#b45309'], swiss20: ['SMI', '#dc2626'],
        ned25: ['AEX', '#ea580c'], kospi: ['KR', '#7c3aed'], india50: ['N50', '#c2410c'],
      };
      const [label, bg] = badges[kind] || ['IDX', '#475569'];
      return box(`<path d="M7 21l5-5 4 3 7-8" fill="none" stroke="#fff" stroke-opacity=".35" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><text x="16" y="${label.length > 2 ? 19.6 : 20}" text-anchor="middle" font-family="Inter,Arial,sans-serif" font-weight="800" font-size="${label.length > 2 ? 10 : 12}" fill="#fff">${label}</text>`, bg);
    }
    case 'xag':
      return box('<path fill="#e5e7eb" d="M7 21.5 9.2 17h6.1l2.2 4.5Z"/><path fill="#9ca3af" d="M7 21.5h10.5V23H7Z"/><path fill="#e5e7eb" d="m14.5 21.5 2.2-4.5h6.1l2.2 4.5Z"/><path fill="#9ca3af" d="M14.5 21.5H25V23H14.5Z"/><path fill="#f3f4f6" d="m10.8 16 2.2-4.5h6.1l2.2 4.5Z"/><path fill="#9ca3af" d="M10.8 16h10.5v1.4H10.8Z"/>', '#4b5563');
    case 'xpt':
      return box('<path fill="#e5e7eb" d="M7 21.5 9.2 17h6.1l2.2 4.5Z"/><path fill="#6b7280" d="M7 21.5h10.5V23H7Z"/><path fill="#e5e7eb" d="m14.5 21.5 2.2-4.5h6.1l2.2 4.5Z"/><path fill="#6b7280" d="M14.5 21.5H25V23H14.5Z"/><path fill="#f3f4f6" d="m10.8 16 2.2-4.5h6.1l2.2 4.5Z"/><path fill="#6b7280" d="M10.8 16h10.5v1.4H10.8Z"/>', '#374151');
    case 'uso':
    case 'uko':
    case 'ng':
      return box('<path fill="#fff" d="M16 6c3.3 4.2 5.5 7.2 5.5 10.2a5.5 5.5 0 1 1-11 0C10.5 13.2 12.7 10.2 16 6Z"/><path fill="#f59e0b" d="M16 9.5c1.9 2.5 3.2 4.3 3.2 6.2a3.2 3.2 0 1 1-6.4 0c0-1.9 1.3-3.7 3.2-6.2Z"/>', kind === 'uko' ? '#7c2d12' : '#92400e');
    case 'copper':
      return box('<path fill="#fdba74" d="M7 21.5 9.2 17h6.1l2.2 4.5Z"/><path fill="#ea580c" d="M7 21.5h10.5V23H7Z"/><path fill="#fdba74" d="m14.5 21.5 2.2-4.5h6.1l2.2 4.5Z"/><path fill="#ea580c" d="M14.5 21.5H25V23H14.5Z"/><path fill="#ffedd5" d="m10.8 16 2.2-4.5h6.1l2.2 4.5Z"/><path fill="#ea580c" d="M10.8 16h10.5v1.4H10.8Z"/>', '#9a3412');
    case 'xrp':
      return box('<path fill="#fff" d="M9.5 12.2 16 18.7l6.5-6.5h2.4L16 21.1 7.1 12.2Zm0 5.6 6.5 6.5 6.5-6.5h2.4L16 26.7l-8.9-8.9Z" transform="translate(0 -2.5)"/>', '#111827');
    case 'doge':
      return box('<path fill="#fff" d="M12 8h4.5v4H12Zm0 6h4.5v4H12ZM9 10h2v6H9Zm7 0h2v6h-2Z"/>', '#c2a633');
    case 'ada':
      return box('<circle cx="16" cy="16" r="9" fill="none" stroke="#fff" stroke-width="1.8"/><circle cx="16" cy="16" r="4.5" fill="none" stroke="#fff" stroke-width="1.8"/><circle cx="16" cy="16" r="1.4" fill="#fff"/>', '#1e40af');
    case 'avax':
      return box('<path fill="#fff" d="m16 7 8 9-8 9-8-9Zm0 4.2L20.6 16 16 20.8 11.4 16Z"/>', '#e11d48');
    case 'link':
      return box('<path fill="#fff" d="M11 16a2.5 2.5 0 0 1 0-3.5l2.5-2.5a2.5 2.5 0 0 1 3.5 0 1.5 1.5 0 0 1-2.1 2.1l-.7.7A.9.9 0 1 1 13 12l.7-.7-1.4-1.4a2.5 2.5 0 0 0-3.5 3.5Zm10 0a2.5 2.5 0 0 1 0 3.5l-2.5 2.5a2.5 2.5 0 0 1-3.5 0 1.5 1.5 0 0 1 2.1-2.1l.7-.7a.9.9 0 1 1 1.3-1.3l-.7.7 1.4 1.4a2.5 2.5 0 0 0 3.5-3.5Z" transform="translate(0.5 -1)"/>', '#1d4ed8');
    case 'ltc':
      return box('<path fill="#fff" d="M13.2 9.5 11.5 19h2l-.6 3.5h2.2l.6-3.5h2.3l.4-2.2h-2.3l1.4-7.3Zm0 0" transform="translate(0.5 -1)"/>', '#64748b');
    case 'trx':
      return box('<path fill="#fff" d="m16 8 7 4.5L16 24 9 12.5Zm0 2.6-4.3 2.8L16 20.9l4.3-7.5Z"/>', '#dc2626');
    case 'dot':
      return box('<circle cx="16" cy="16" r="3.2" fill="#fff"/><circle cx="16" cy="16" r="8" fill="none" stroke="#fff" stroke-width="1.6" stroke-dasharray="3 2.4"/>', '#e6007a');
    case 'atom':
      return box('<circle cx="16" cy="16" r="2.6" fill="#fff"/><ellipse cx="16" cy="16" rx="9" ry="3.6" fill="none" stroke="#fff" stroke-width="1.5" transform="rotate(30 16 16)"/><ellipse cx="16" cy="16" rx="9" ry="3.6" fill="none" stroke="#fff" stroke-width="1.5" transform="rotate(-30 16 16)"/>', '#2d3e50');
    case 'near':
      return box('<path fill="#fff" d="M9.5 11.5a2 2 0 0 1 3.4 0l6.6 9a2 2 0 0 1-3.4 0Zm10 0a2 2 0 0 1 3.4 0l-2.5 3.4-1.7-2.3Z"/>', '#111827');
    case 'sui':
      return box('<path fill="#fff" d="M16 7c2.6 2.4 4 5 4 7.6 0 1.9-.8 3.4-2 3.4s-2-1.5-2-3.4c0-1.2.3-2.4.8-3.6-1.7 1.5-2.8 3.4-2.8 5.4 0 2.6 1.8 4.6 4 4.6s4-2 4-4.6c0-2.9-1.7-5.9-4-9.4Z"/>', '#0f766e');
    case 'pepe':
      return box('<path fill="#fff" d="M10 12c0-2.2 2.7-4 6-4s6 1.8 6 4v6c0 2.2-2.7 4-6 4s-6-1.8-6-4Zm2 .5V18c0 1.2 1.8 2.3 4 2.3s4-1.1 4-2.3v-5.5c-.9.9-2.4 1.4-4 1.4s-3.1-.5-4-1.4Z"/><circle cx="13.5" cy="14" r="1.1" fill="#4d7c0f"/><circle cx="18.5" cy="14" r="1.1" fill="#4d7c0f"/>', '#65a30d');
    case 'xau':
    default:
      return box('<path fill="#fde68a" d="M7 21.5 9.2 17h6.1l2.2 4.5Z"/><path fill="#f59e0b" d="M7 21.5h10.5V23H7Z"/><path fill="#fde68a" d="m14.5 21.5 2.2-4.5h6.1l2.2 4.5Z"/><path fill="#f59e0b" d="M14.5 21.5H25V23H14.5Z"/><path fill="#fef3c7" d="m10.8 16 2.2-4.5h6.1l2.2 4.5Z"/><path fill="#f59e0b" d="M10.8 16h10.5v1.4H10.8Z"/>', '#7c5a12');
  }
}
