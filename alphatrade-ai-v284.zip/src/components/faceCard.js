// Profile → "Face sign-in": turn it on for this device, see the devices that have it, remove them.
import { h, esc } from '../utils/dom.js';
import { getLang, t } from '../i18n/index.js';
import { icons } from './icons.js';
import { toast, openModal } from './ui.js';
import { auth } from '../services/auth/index.js';
import { authErrorMessage } from '../services/auth/errors.js';
import { faceSupported, faceStatus, enrollFace, removeFace, faceHint } from '../services/faceLogin.js';
import { storage } from '../utils/storage.js';
import { deviceName } from '../services/members.js';

const L = (ar, en) => (getLang() !== 'ar' ? en : ar);
const day = (ms) => new Date(ms).toLocaleDateString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { year: 'numeric', month: 'short', day: 'numeric' });

export function faceCard() {
  const el = h(`<article class="card profile-card fc-card fade-in"><h2 class="card-title">${icons.face}<span>${esc(L('الدخول بالوجه', 'Face sign-in'))}</span></h2><div data-f><p class="muted">…</p></div></article>`);
  const box = el.querySelector('[data-f]');
  const paint = async () => {
    const [ok, st] = await Promise.all([faceSupported(), faceStatus().catch((e) => ({ error: e?.code || 'x' }))]);
    if (st.error) { box.innerHTML = `<p class="muted">${esc(L('الخدمة مش متاحة هلأ.', 'Not available right now.'))}</p>`; return; }
    box.innerHTML = `
      <p class="tool-note">${esc(L('بعد ما تفعّله، بتدخل بنظرة وحدة بدون كلمة مرور. فحص الوجه بيصير على جهازك نفسه (Face ID أو فتح الوجه بالأندرويد أو Windows Hello) — الموقع ما بياخد صورة ولا بيحفظ أي شي عن وجهك، بيحفظ بس مفتاح أمان للجهاز.', 'Once on, you sign in with a glance — no password. The face check runs on your own device (Face ID, Android face unlock or Windows Hello). The site never takes a picture or stores anything about your face — only a security key for the device.'))}</p>
      ${!st.configured ? `<p class="sa-note down">${esc(L('صاحب الموقع لسا ما جهّز الدخول بالوجه (حساب خدمة Firebase).', 'The site owner has not set up face sign-in yet (Firebase service account).'))}</p>` : ''}
      ${!ok ? `<p class="sa-note">${esc(L('هالجهاز أو المتصفح ما فيه فتح بالوجه أو بالبصمة. جرّب من الجوال (Safari على iPhone أو Chrome على Android).', 'This device or browser has no built-in face or fingerprint unlock. Try on your phone (Safari on iPhone or Chrome on Android).'))}</p>` : ''}
      ${st.devices.length ? `<ul class="cn-logins">${st.devices.map((d) => `<li><span class="nt-ic">${icons.face}</span><span><b>${esc(d.name)}</b><small class="muted">${esc(L(`فعّلته ${day(d.createdAt)}`, `On since ${day(d.createdAt)}`))}${d.lastUsed ? ` · ${esc(L(`آخر دخول ${day(d.lastUsed)}`, `last used ${day(d.lastUsed)}`))}` : ''}</small></span><button type="button" class="btn btn-sm btn-ghost ad-danger" data-rm="${esc(d.id)}">${esc(L('شيل', 'Remove'))}</button></li>`).join('')}</ul>` : `<p class="muted">${esc(L('مش مفعّل على ولا جهاز.', 'Not on for any device.'))}</p>`}
      ${ok && st.configured && faceHint() && st.devices.length ? `<p class="tool-note"><span class="badge badge-live">${esc(L('مفعّل على هالجهاز', 'On for this device'))}</span></p>` : ''}
      ${ok && st.configured && !(faceHint() && st.devices.length) ? `<button type="button" class="btn btn-primary" data-on>${icons.face}<span>${esc(L('فعّل الدخول بالوجه على هالجهاز', 'Turn on face sign-in on this device'))}</span></button>` : ''}`;
    box.querySelector('[data-on]')?.addEventListener('click', start);
    box.querySelectorAll('[data-rm]').forEach((b) => b.addEventListener('click', async () => { await removeFace(b.dataset.rm).catch(() => {}); storage.remove('face-on-device'); toast(L('انشال', 'Removed'), 'success'); paint(); }));
  };
  const enroll = async () => {
    await enrollFace(deviceName());
    toast(L('تفعّل! المرة الجاي ادخل بالوجه من صفحة الدخول.', 'Done! Next time sign in with your face on the sign-in page.'), 'success', 6000); paint();
  };
  const start = async () => {
    try { await enroll(); }
    catch (e) {
      if (e?.code !== 'reauth_required') { toast(e?.code === 'already_registered' ? L('مفعّل أصلًا على هالجهاز.', 'Already on for this device.') : e?.code === 'cancelled' ? L('انلغى.', 'Cancelled.') : L('ما زبط التفعيل.', 'Could not turn it on.'), 'error'); return; }
      // needs a fresh sign-in first: confirm the password (or the Google / Apple window), then continue
      openModal(L('أكّد إنه إنت', 'Confirm it is you'), (body, close) => {
        const pw = auth.canChangePassword();
        body.innerHTML = `<form class="ad-form" data-r>${pw ? `<label class="field"><span>${esc(L('كلمة المرور', 'Password'))}</span><input class="input" type="password" name="pw" autocomplete="current-password" required></label>` : `<p class="muted">${esc(L('رح تنفتح نافذة تسجيل الدخول.', 'A sign-in window will open.'))}</p>`}<button class="btn btn-primary" type="submit">${esc(L('كمّل', 'Continue'))}</button></form>`;
        body.querySelector('[data-r]').addEventListener('submit', async (ev) => {
          ev.preventDefault();
          try { await auth.reauth(pw ? ev.target.pw.value : ''); close(); await enroll(); }
          catch (x) { toast(x?.code === 'cancelled' ? L('انلغى.', 'Cancelled.') : authErrorMessage(x, t), 'error'); }
        });
      });
    }
  };
  paint();
  return el;
}
