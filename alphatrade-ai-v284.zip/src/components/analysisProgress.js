// "Analysis" card: when an asset (or timeframe) is selected, the stages of the full analysis appear one by one —
// chart data, SMC structure, order blocks / FVG, ICT liquidity + kill zone + OTE, RSI, Bollinger, and the plan
// (entry, stop, three targets). Every line is read from the analysis that was computed on the loaded candles
// (services/analysisSteps.js). The staggered reveal only paces the display; it never delays or fakes a result.
import { h, esc, fmtNum } from '../utils/dom.js';
import { t } from '../i18n/index.js';
import { icons } from './icons.js';
import { store } from '../state/store.js';
import { analysisSteps } from '../services/analysisSteps.js';

const STAGES = ['data', 'structure', 'blocks', 'ict', 'rsi', 'bb', 'plan'];
const reduced = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;

function line(step, an) {
  const p = step.p; const f = (v) => fmtNum(v, an.precision ?? 2);
  if (step.status === 'na') {
    if (step.key === 'plan') {
      const why = p.blockers?.length ? p.blockers.map((b) => t(`cnf.b.${b}`)).join(' · ') : p.rejected ? t('cnf.noTrade') : t('ap.noSetup');
      return `${t('cnf.noTrade')} — ${why}`;
    }
    return an.strategy === 'edh' && ['structure', 'blocks', 'ict', 'bb'].includes(step.key) ? t('ap.edh') : t('ap.na');
  }
  switch (step.key) {
    case 'data': return `${t('ap.d.data', { n: p.n, mode: t(`ap.mode.${p.mode}`), price: f(p.price) })}`;
    case 'structure': return [t(`ap.trend.${p.trend || 'none'}`), p.kind ? t('ap.d.lastBreak', { kind: p.kind, dir: t(`ap.dir.${p.dir}`), level: f(p.level) }) : ''].filter(Boolean).join(' · ');
    case 'blocks': return [t('ap.d.blocks', { ob: p.ob, fvg: p.fvg }), p.obTop != null ? t('ap.d.nearOb', { dir: t(`ap.dir.${p.obDir}`), a: f(p.obBottom), b: f(p.obTop) }) : ''].filter(Boolean).join(' · ');
    case 'ict': return [
      p.zone ? t(`ap.zone.${p.zone}`, { eq: f(p.eq) }) : '',
      p.kz ? t(`ap.kz.${p.kz}`) : t('ap.kz.none'),
      p.bsl != null ? t('ap.d.bsl', { v: f(p.bsl) }) : '', p.ssl != null ? t('ap.d.ssl', { v: f(p.ssl) }) : '',
      p.ote ? t('ap.d.ote', { dir: t(`ap.dir.${p.ote.dir}`), a: f(p.ote.from), b: f(p.ote.to) }) : '',
      p.sessions ? t('ap.d.sessions', { n: p.sessions }) : '',
    ].filter(Boolean).join(' · ');
    case 'rsi': return `${fmtNum(p.v, 1)} — ${t(`ap.rsi.${p.state}`)}`;
    case 'bb': return `${t('ap.d.pb', { pb: fmtNum(p.pb, 0) })}${p.width != null ? ` · ${t('ap.d.bw', { w: fmtNum(p.width, 2) })}` : ''} — ${t(`ap.bb.${p.state}`)}`;
    case 'plan': {
      const long = p.direction === 'long';
      const tps = (p.targets || []).map((v, i) => `TP${i + 1} ${f(v)}`).join(' · ');
      return `${t(long ? 'common.long' : 'common.short')} (${t(`ap.state.${p.state === 'pending' ? 'pending' : p.state === 'active' ? 'active' : 'proposal'}`)}) · ${t('plan.entry')} ${f(p.entry)} · SL ${f(p.stop)} · ${tps}`;
    }
    default: return '';
  }
}

export function createAnalysisProgress() {
  const el = h(`<section class="card side-card ap-card fade-in" aria-live="polite">
    <div class="side-head"><h3 class="card-title">${icons.sparkle || ''}<span data-ap-title>${esc(t('ap.title'))}</span></h3>
      <button type="button" class="btn btn-sm btn-ghost" data-ap-toggle aria-pressed="true"></button></div>
    <p class="side-foot" data-ap-sub></p>
    <ol class="ap-list" data-ap-list></ol>
    <p class="side-foot" data-ap-note></p>
  </section>`);
  const $ = (s) => el.querySelector(s);
  let key = ''; let timers = []; let lastAn = null; let lastHtml = ''; let revealing = false; let lastDs = null;

  const syncToggle = () => {
    const on = store.get('settings').aview !== false;
    const b = $('[data-ap-toggle]'); b.setAttribute('aria-pressed', String(on));
    b.textContent = t(on ? 'ap.hide' : 'ap.show');
  };
  $('[data-ap-toggle]').addEventListener('click', () => store.updateSettings('aview', !(store.get('settings').aview !== false)));
  store.on('settings', () => { if (el.isConnected) syncToggle(); });
  syncToggle();

  const draw = (an, steps, shown, doneAll) => {
    const rows = STAGES.map((k, i) => {
      const st = steps.find((s) => s.key === k);
      if (!st) return '';
      const state = i < shown ? (st.status === 'na' ? 'na' : 'done') : i === shown && !doneAll ? 'now' : 'wait';
      const mark = state === 'done' ? icons.check : state === 'now' ? '<span class="spinner"></span>' : state === 'na' ? '–' : '';
      const body = state === 'done' || state === 'na' ? `<small class="${state === 'na' ? 'muted' : ''}">${esc(line(st, an))}</small>` : '';
      return `<li class="ap-step ${state}"><b class="ap-mark">${mark}</b><div><span>${esc(t(`ap.s.${k}`))}</span>${body}</div></li>`;
    }).join('');
    if (rows === lastHtml) return;
    lastHtml = rows; $('[data-ap-list]').innerHTML = rows;
  };

  return {
    el,
    update(an, dataset) {
      if (!an || !dataset?.candles?.length) return;
      lastAn = an; lastDs = dataset;
      const steps = analysisSteps(an, dataset, store.get('settings'));
      const k = `${an.symbol}|${an.tf}|${an.mode}`;
      $('[data-ap-sub]').textContent = t('ap.sub', { symbol: an.symbol, tf: an.tf, n: dataset.candles.length });
      $('[data-ap-note]').textContent = t('ap.note');
      if (k !== key) {
        key = k; timers.forEach(clearTimeout); timers = []; revealing = false;
        $('[data-ap-title]').textContent = t('ap.title');
        if (reduced() || document.hidden) { draw(an, steps, STAGES.length, true); $('[data-ap-title]').textContent = t('ap.done'); return; }
        let i = 0; revealing = true;
        const tick = () => {
          const cur = lastAn; const st = analysisSteps(cur, lastDs, store.get('settings'));
          const finished = i >= STAGES.length;
          draw(cur, st, i, finished);
          if (finished) { revealing = false; $('[data-ap-title]').textContent = t('ap.done'); return; }
          i++; timers.push(setTimeout(tick, 260));
        };
        tick();
      } else if (!revealing) draw(an, steps, STAGES.length, true);   // same asset: refresh the numbers in place
    },
  };
}
