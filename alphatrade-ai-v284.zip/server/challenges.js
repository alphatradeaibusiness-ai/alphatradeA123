// v281 Funded-trader challenges — server side. Every rule is enforced HERE; the page only shows what the server says.
//  • purchase: an account is created only from a payment Stripe confirmed (signed webhook, idempotent on the payment id) or
//    by the site owner (grant). Nothing is created from the browser.
//  • trading: a simulated (demo) account. Orders fill at the price THIS SERVER fetches at that moment (Binance for crypto,
//    Yahoo Finance for gold / forex / indices / oil); the browser never sends a price. Stale or missing prices → order refused.
//  • rules: profit target, daily loss (from the higher of balance / equity at 00:00 UTC), max total loss (static), minimum
//    trading days. Checked after every action and every few seconds on live prices; a breach closes all positions and fails
//    the account. Passing a phase opens the next phase; passing the last one waits for the owner's review (identity check).
//  • funded: same loss rules; the trader can request a reward of their profit share every N days, with no open positions.
//    The owner approves and pays it through the provider (PayPal / bank / USDT / card via the provider), then marks it paid.
// Storage: one AES-256-GCM encrypted file (key from AI_KEY_SECRET).
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { writeBehind } from './writeBehind.js';
import { PROGRAMS, programById, parseProduct, CONTRACTS, MAX_LOTS, pnlUsd, marginUsd, limitsOf, PAYOUT_METHODS } from '../src/config/challenges.js';

const DAY = 86_400_000;
const ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const rid = (n) => Array.from(crypto.randomBytes(n), (b) => ABC[b % ABC.length]).join('');
const clip = (s, n) => String(s ?? '').replace(/[\u0000-\u001f\u007f<>]/g, ' ').trim().slice(0, n);
const r2 = (v) => Math.round(v * 100) / 100;
const dayKey = (t) => new Date(t).toISOString().slice(0, 10);
export const ACC_RE = /^AT-[A-Z2-9]{8}$/;
const POS_RE = /^P[A-Z2-9]{8}$/;
const PAY_RE = /^W[A-Z2-9]{8}$/;
const STALE_MS = 3 * 60_000;             // a quote older than this = market closed / delayed feed → no fills
const MAX_POS = 20, MAX_ACCOUNTS = 30, ORDERS_PER_MIN = 30;

/* ───────── pure parts (tested directly) ───────── */
export function phaseLimits(a) { return limitsOf(programById(a.program), a.size, a.phase === 'funded' ? -1 : a.phase - 1); }

/** Floating P&L and equity of an account at the given prices (missing price → last known price, else entry). */
export function equityOf(a, px) {
  let floating = 0;
  for (const p of a.positions) { const price = px(p.sym) ?? p.last ?? p.entry; floating += pnlUsd(p.sym, p.side, p.lots, p.entry, price); }
  return { floating: r2(floating), equity: r2(a.balance + floating) };
}

/** Validates payout details for a method; returns a clean copy or { error }. No card numbers are ever accepted. */
export function cleanPayout(method, d = {}) {
  if (!PAYOUT_METHODS.some((m) => m.id === method)) return { error: 'bad_method' };
  const s = (v, n) => clip(v, n);
  if (method === 'paypal' || method === 'card') {
    const email = s(d.email, 120).toLowerCase(); if (!/^[^\s@]{1,64}@[^\s@]{1,80}\.[a-z]{2,24}$/.test(email)) return { error: 'bad_email' };
    if (/\d{12,}/.test(JSON.stringify(d))) return { error: 'no_card_numbers' };
    return { method, email };
  }
  if (method === 'bank') {
    const iban = s(d.iban, 40).replace(/\s+/g, '').toUpperCase(); const holder = s(d.holder, 80);
    if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(iban)) return { error: 'bad_iban' };
    if (holder.length < 3) return { error: 'bad_holder' };
    return { method, iban, holder, bank: s(d.bank, 80) };
  }
  const net = d.network === 'erc20' ? 'erc20' : d.network === 'trc20' ? 'trc20' : null; const address = s(d.address, 64);
  if (!net) return { error: 'bad_network' };
  if (net === 'trc20' ? !/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(address) : !/^0x[0-9a-fA-F]{40}$/.test(address)) return { error: 'bad_address' };
  return { method, network: net, address };
}

/**
 * Evaluate one account at time t with prices px(sym) → number|null. Mutates the account; returns events
 * [{ kind: 'sl'|'tp'|'failed'|'passed', … }]. Closing uses the current price (a gap fills at the market, like a real broker).
 */
export function evaluate(a, px, t) {
  const ev = []; if (a.status !== 'active' && a.status !== 'funded') return ev;
  const prog = programById(a.program); const lim = phaseLimits(a);
  for (const p of a.positions) { const price = px(p.sym); if (price > 0) p.last = price; }
  // stop loss / take profit
  for (const p of [...a.positions]) {
    const price = px(p.sym); if (!(price > 0)) continue;
    const hitSl = p.sl && (p.side === 'buy' ? price <= p.sl : price >= p.sl); const hitTp = p.tp && (p.side === 'buy' ? price >= p.tp : price <= p.tp);
    if (hitSl || hitTp) { closePos(a, p, price, t, hitSl ? 'sl' : 'tp'); ev.push({ kind: hitSl ? 'sl' : 'tp', pos: p.id }); }
  }
  let { equity } = equityOf(a, px);
  const k = dayKey(t); if (a.dayKey !== k) { a.dayKey = k; a.dayRef = r2(Math.max(a.balance, equity)); }
  // loss rules
  let why = null;
  if (equity <= lim.floor + 1e-9) why = 'max_loss';
  else if (lim.daily != null && equity <= a.dayRef - lim.daily + 1e-9) why = 'daily_loss';
  if (why) {
    for (const p of [...a.positions]) closePos(a, p, px(p.sym) ?? p.last ?? p.entry, t, why);
    a.status = 'failed'; a.failReason = why; a.endedAt = t; ev.push({ kind: 'failed', why }); equity = a.balance;
  }
  a.equity = r2(equity); a.minEquity = r2(Math.min(a.minEquity ?? a.size, equity)); a.maxEquity = r2(Math.max(a.maxEquity ?? a.size, equity));
  if (!a.snaps.length || t - a.snaps[a.snaps.length - 1].t >= 60_000 || why) { a.snaps.push({ t, b: r2(a.balance), e: r2(equity) }); if (a.snaps.length > 1440) a.snaps.splice(0, a.snaps.length - 1440); }
  // passing a phase: closed profit ≥ target, enough trading days, nothing open
  if (a.status === 'active' && lim.target != null && a.positions.length === 0 && a.balance - a.size >= lim.target - 1e-9 && a.days.length >= prog.minDays) {
    a.status = 'passed'; a.endedAt = t; ev.push({ kind: 'passed' });
  }
  return ev;
}
function closePos(a, p, price, t, reason) {
  const pnl = r2(pnlUsd(p.sym, p.side, p.lots, p.entry, price));
  a.balance = r2(a.balance + pnl); a.positions = a.positions.filter((x) => x !== p);
  a.history.unshift({ id: p.id, sym: p.sym, side: p.side, lots: p.lots, entry: p.entry, exit: price, pnl, openAt: p.openAt, closeAt: t, reason });
  if (a.history.length > 300) a.history.length = 300;
  return pnl;
}

/** Public view of an account (what the trader sees). */
export function viewOf(a, px, t = Date.now()) {
  const prog = programById(a.program); const lim = phaseLimits(a); const { floating, equity } = equityOf(a, px);
  const profit = r2(a.balance - a.size); const dailyUsed = lim.daily == null ? null : r2(Math.max(0, (a.dayKey === dayKey(t) ? a.dayRef : Math.max(a.balance, equity)) - equity));
  const payoutPending = Boolean(a.payoutPending);
  const nextPayoutAt = a.phase === 'funded' ? (a.lastPayoutAt || a.createdAt) + prog.payoutDays * DAY : null;
  return {
    id: a.id, program: a.program, programName: prog.name, size: a.size, phase: a.phase, phases: prog.phases.length, status: a.status, failReason: a.failReason || null,
    createdAt: a.createdAt, endedAt: a.endedAt || null, balance: a.balance, equity, floating, profit,
    rules: { target: lim.target, daily: lim.daily, maxLoss: lim.maxLoss, floor: lim.floor, minDays: prog.minDays, split: prog.split, payoutDays: prog.payoutDays, leverage: prog.leverage, targetPct: a.phase === 'funded' ? null : prog.phases[a.phase - 1].target, dailyPct: prog.daily, maxPct: prog.maxLoss },
    progress: { targetPct: lim.target ? Math.max(0, Math.min(100, (profit / lim.target) * 100)) : null, dailyUsed, dailyLeft: lim.daily == null ? null : r2(Math.max(0, lim.daily - dailyUsed)), maxUsed: r2(Math.max(0, a.size - equity)), maxLeft: r2(Math.max(0, equity - lim.floor)), days: a.days.length, dayRef: a.dayRef },
    positions: a.positions.map((p) => { const price = px(p.sym) ?? p.last ?? p.entry; return { ...p, price, pnl: r2(pnlUsd(p.sym, p.side, p.lots, p.entry, price)) }; }),
    history: a.history.slice(0, 100), snaps: a.snaps.slice(-720),
    funded: a.phase === 'funded' ? { reward: r2(Math.max(0, profit) * prog.split / 100), nextPayoutAt, minDays: prog.phases.length ? 0 : prog.minDays, canRequest: a.status === 'funded' && !payoutPending && a.positions.length === 0 && profit > 0 && t >= nextPayoutAt && (prog.phases.length > 0 || a.days.length >= prog.minDays), payoutPending, paidTotal: a.paidTotal || 0 } : null,
    next: a.nextId || null, parent: a.parentId || null,
  };
}

/* ───────── store + API ───────── */
export function createChallenges({ dir, secret, now = Date.now, priceOf = async () => null, isOwnerEmail = () => false, notify = () => {}, env = process.env, log = console } = {}) {
  const key = secret && String(secret).length >= 32 ? crypto.scryptSync(String(secret), 'alphatrade-challenges-v1', 32) : null;
  const file = path.join(dir, 'challenges.json');
  const enc = (buf) => { const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from('challenges')); const d = Buffer.concat([c.update(buf), c.final()]); return Buffer.concat([iv, c.getAuthTag(), d]); };
  const dec = (buf) => { const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12)); d.setAAD(Buffer.from('challenges')); d.setAuthTag(buf.subarray(12, 28)); return Buffer.concat([d.update(buf.subarray(28)), d.final()]); };
  let db = null;
  function load() {
    if (db) return db;
    db = { accounts: {}, payments: {}, payouts: [], reviews: [] };
    if (!key) return db;
    try { db = { ...db, ...JSON.parse(dec(fs.readFileSync(file)).toString('utf8')) }; } catch (e) { if (e.code !== 'ENOENT') log.error?.('[challenges] could not read the store:', String(e.message).slice(0, 80)); }
    return db;
  }
  const writer = writeBehind(() => {
    if (!key || !db) return;
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    const tmp = `${file}.${process.pid}.tmp`; fs.writeFileSync(tmp, enc(Buffer.from(JSON.stringify(db))), { mode: 0o600 }); fs.renameSync(tmp, file);
  }, { delayMs: env.NODE_ENV === 'test' ? 0 : 400, maxWaitMs: 1500 });
  const save = () => writer.schedule();
  const isOwner = (u) => Boolean(isOwnerEmail(u));
  const tell = (uid, title, body, id) => { try { notify(uid, title, body, `/#/app/challenges?acc=${id}`); } catch { /* best effort */ } };

  /* prices: fetched by the server, cached a few seconds */
  const cache = new Map();
  async function prices(syms, maxAge = 3000) {
    const t = now(); const out = {};
    await Promise.all([...new Set(syms)].map(async (s) => {
      const c = cache.get(s); if (c && t - c.got < maxAge) { out[s] = c; return; }
      const q = await priceOf(s).catch(() => null);
      if (q && q.price > 0) { const v = { price: q.price, at: q.at || t, got: t }; cache.set(s, v); out[s] = v; }
      else if (c) out[s] = c;
    }));
    return out;
  }
  const pxFn = (map) => (s) => { const q = map[s]; return q && now() - q.at < STALE_MS ? q.price : null; };

  function newAccount({ uid, email, name, program, size, phase, parentId = null, paymentId = null, source }) {
    const t = now(); const a = {
      id: `AT-${rid(8)}`, uid, email: clip(email, 120), name: clip(name, 60), program, size, phase, status: phase === 'funded' ? 'funded' : 'active',
      balance: size, equity: size, dayKey: dayKey(t), dayRef: size, positions: [], history: [], days: [], snaps: [{ t, b: size, e: size }],
      createdAt: t, parentId, paymentId, source, minEquity: size, maxEquity: size,
    };
    while (db.accounts[a.id]) a.id = `AT-${rid(8)}`;
    db.accounts[a.id] = a; if (parentId && db.accounts[parentId]) db.accounts[parentId].nextId = a.id;
    return a;
  }
  /** After evaluation: phase passed → next phase, or the owner's review before funding. */
  function afterEvents(a, ev) {
    for (const e of ev) {
      if (e.kind === 'failed') tell(a.uid, 'تحدي التمويل', `الحساب ${a.id} انتهى: ${e.why === 'daily_loss' ? 'تجاوز حد الخسارة اليومي' : 'تجاوز حد الخسارة الكلي'}.`, a.id);
      if (e.kind === 'passed') {
        const prog = programById(a.program);
        if (a.phase < prog.phases.length) { const n = newAccount({ uid: a.uid, email: a.email, name: a.name, program: a.program, size: a.size, phase: a.phase + 1, parentId: a.id, source: 'phase' }); tell(a.uid, 'نجحت بالمرحلة 🎉', `انفتح حساب المرحلة ${n.phase}: ${n.id}`, n.id); }
        else { a.status = 'review'; db.reviews.push({ id: a.id, uid: a.uid, at: now(), state: 'pending' }); tell(a.uid, 'نجحت بالتحدي 🎉', 'حسابك بانتظار مراجعة الإدارة قبل التمويل.', a.id); }
      }
    }
  }

  async function view(u, id) {
    load(); const a = db.accounts[id]; if (!ACC_RE.test(String(id)) || !a || (a.uid !== u.uid && !isOwner(u))) return { error: 'not_found' };
    const map = await prices(a.positions.map((p) => p.sym)); const px = pxFn(map);
    const ev = evaluate(a, px, now()); if (ev.length) { afterEvents(a, ev); save(); }
    return { account: viewOf(a, px, now()), quotesAt: Object.fromEntries(Object.entries(map).map(([s, q]) => [s, q.at])) };
  }
  function list(u) {
    load(); const t = now();
    const items = Object.values(db.accounts).filter((a) => a.uid === u.uid).sort((x, y) => y.createdAt - x.createdAt)
      .map((a) => ({ id: a.id, program: a.program, size: a.size, phase: a.phase, status: a.status, balance: a.balance, equity: a.equity ?? a.balance, createdAt: a.createdAt, failReason: a.failReason || null }));
    return { items, at: t };
  }

  const hits = new Map();
  const limited = (uid) => { const t = now(); const arr = (hits.get(uid) || []).filter((x) => t - x < 60_000); arr.push(t); hits.set(uid, arr); if (hits.size > 20000) hits.clear(); return arr.length > ORDERS_PER_MIN; };
  const own = (u, id) => { load(); const a = db.accounts[id]; return ACC_RE.test(String(id)) && a && a.uid === u.uid ? a : null; };
  const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);

  async function order(u, id, b = {}) {
    const a = own(u, id); if (!a) return { error: 'not_found' };
    if (limited(u.uid)) return { error: 'rate_limited' };
    if (a.status !== 'active' && a.status !== 'funded') return { error: 'account_closed' };
    if (a.payoutPending) return { error: 'payout_pending' };
    const sym = String(b.sym || ''); const c = CONTRACTS[sym]; if (!c) return { error: 'bad_symbol' };
    const side = b.side === 'buy' || b.side === 'sell' ? b.side : null; if (!side) return { error: 'bad_side' };
    const lots = num(b.lots); if (lots == null || lots < c.min || lots > MAX_LOTS || Math.abs(Math.round(lots * 100) - lots * 100) > 1e-6) return { error: 'bad_lots' };
    if (a.positions.length >= MAX_POS) return { error: 'too_many_positions' };
    const map = await prices([sym, ...a.positions.map((p) => p.sym)], 1000); const px = pxFn(map); const price = px(sym);
    if (!(price > 0)) return { error: 'market_closed' };
    const sl = b.sl == null || b.sl === '' ? null : num(b.sl); const tp = b.tp == null || b.tp === '' ? null : num(b.tp);
    if ((b.sl != null && b.sl !== '' && !(sl > 0)) || (b.tp != null && b.tp !== '' && !(tp > 0))) return { error: 'bad_levels' };
    if (sl && (side === 'buy' ? sl >= price : sl <= price)) return { error: 'bad_sl' };
    if (tp && (side === 'buy' ? tp <= price : tp >= price)) return { error: 'bad_tp' };
    // evaluate first (a breach or a passed phase ends trading), then margin check on equity
    const ev = evaluate(a, px, now()); if (ev.length) { afterEvents(a, ev); save(); if (a.status !== 'active' && a.status !== 'funded') return { error: 'account_closed' }; }
    const prog = programById(a.program); const { equity } = equityOf(a, px);
    const used = a.positions.reduce((s, p) => s + marginUsd(p.sym, p.lots, px(p.sym) ?? p.last ?? p.entry, prog), 0);
    if (used + marginUsd(sym, lots, price, prog) > equity) return { error: 'margin' };
    const t = now(); const p = { id: `P${rid(8)}`, sym, side, lots: r2(lots), entry: price, sl, tp, openAt: t, last: price };
    a.positions.push(p); const k = dayKey(t); if (!a.days.includes(k)) a.days.push(k);
    evaluate(a, px, t); save();
    return { ok: true, position: p };
  }
  async function close(u, id, posId) {
    const a = own(u, id); if (!a) return { error: 'not_found' };
    if (limited(u.uid)) return { error: 'rate_limited' };
    const p = a.positions.find((x) => x.id === posId && POS_RE.test(String(posId))); if (!p) return { error: 'not_found' };
    const map = await prices(a.positions.map((x) => x.sym), 1000); const px = pxFn(map); const price = px(p.sym);
    if (!(price > 0)) return { error: 'market_closed' };
    const ev1 = evaluate(a, px, now()); if (ev1.length) afterEvents(a, ev1);
    if (!a.positions.includes(p)) { save(); return { ok: true, closedBy: 'rules' }; }
    const pnl = closePos(a, p, price, now(), 'manual');
    const ev = evaluate(a, px, now()); if (ev.length) afterEvents(a, ev); save();
    return { ok: true, pnl };
  }
  function modify(u, id, posId, b = {}) {
    const a = own(u, id); if (!a) return { error: 'not_found' };
    const p = a.positions.find((x) => x.id === posId); if (!p) return { error: 'not_found' };
    const ref = p.last || p.entry; const sl = b.sl == null || b.sl === '' ? null : num(b.sl); const tp = b.tp == null || b.tp === '' ? null : num(b.tp);
    if ((b.sl != null && b.sl !== '' && !(sl > 0)) || (b.tp != null && b.tp !== '' && !(tp > 0))) return { error: 'bad_levels' };
    if (sl && (p.side === 'buy' ? sl >= ref : sl <= ref)) return { error: 'bad_sl' };
    if (tp && (p.side === 'buy' ? tp <= ref : tp >= ref)) return { error: 'bad_tp' };
    p.sl = sl; p.tp = tp; save(); return { ok: true };
  }

  function requestPayout(u, id, b = {}) {
    const a = own(u, id); if (!a) return { error: 'not_found' };
    if (a.phase !== 'funded' || a.status !== 'funded') return { error: 'not_funded' };
    const v = viewOf(a, () => null, now()); if (!v.funded.canRequest) return { error: v.funded.payoutPending ? 'payout_pending' : a.positions.length ? 'close_positions' : v.profit <= 0 ? 'no_profit' : now() < v.funded.nextPayoutAt ? 'too_early' : 'min_days' };
    const det = cleanPayout(String(b.method || ''), b.details || {}); if (det.error) return det;
    const kyc = { fullName: clip(b.kyc?.fullName, 80), country: clip(b.kyc?.country, 2).toUpperCase(), adult: b.kyc?.adult === true, terms: b.kyc?.terms === true };
    if (kyc.fullName.length < 5 || !/^[A-Z]{2}$/.test(kyc.country) || !kyc.adult || !kyc.terms) return { error: 'bad_kyc' };
    const prog = programById(a.program); const profit = r2(a.balance - a.size);
    const w = { id: `W${rid(8)}`, account: a.id, uid: a.uid, email: a.email, profit, split: prog.split, amount: r2(profit * prog.split / 100), details: det, kyc, state: 'pending', at: now() };
    db.payouts.unshift(w); a.payoutPending = w.id; save();
    return { ok: true, payout: { id: w.id, amount: w.amount, state: w.state } };
  }
  function myPayouts(u) { load(); return { items: db.payouts.filter((w) => w.uid === u.uid).map(({ uid, kyc, details, ...w }) => ({ ...w, method: details.method })) }; }

  /* owner */
  function admin(u) {
    if (!isOwner(u)) return { error: 'forbidden' }; load();
    const accs = Object.values(db.accounts);
    const by = (s) => accs.filter((a) => a.status === s).length;
    return {
      stats: { total: accs.length, active: by('active'), failed: by('failed'), passed: by('passed'), review: by('review'), funded: by('funded'), sold: accs.filter((a) => a.source === 'stripe').length },
      reviews: db.reviews.filter((r) => r.state === 'pending').map((r) => { const a = db.accounts[r.id]; return a ? { id: a.id, email: a.email, name: a.name, program: a.program, size: a.size, balance: a.balance, days: a.days.length, at: r.at, history: a.history.length } : null; }).filter(Boolean),
      payouts: db.payouts.slice(0, 200),
      accounts: accs.sort((x, y) => y.createdAt - x.createdAt).slice(0, 300).map((a) => ({ id: a.id, email: a.email, program: a.program, size: a.size, phase: a.phase, status: a.status, balance: a.balance, equity: a.equity ?? a.balance, source: a.source, createdAt: a.createdAt, failReason: a.failReason || null })),
    };
  }
  function adminAct(u, b = {}, findUser = () => null) {
    if (!isOwner(u)) return { error: 'forbidden' }; load(); const t = now();
    if (b.action === 'grant') {
      const prog = programById(b.program); const size = Number(b.size); if (!prog || !prog.prices[size]) return { error: 'bad_product' };
      const target = findUser(String(b.email || '').trim().toLowerCase()); if (!target) return { error: 'user_not_found' };
      const a = newAccount({ uid: target.uid, email: target.email, name: target.name, program: prog.id, size, phase: prog.phases.length ? 1 : 'funded', source: 'owner' }); save();
      tell(a.uid, 'حساب تحدي جديد', `انضافلك حساب ${prog.short} بحجم $${size.toLocaleString('en')}.`, a.id); return { ok: true, id: a.id };
    }
    if (b.action === 'review_approve' || b.action === 'review_reject') {
      const r = db.reviews.find((x) => x.id === b.id && x.state === 'pending'); const a = r && db.accounts[r.id]; if (!a) return { error: 'not_found' };
      r.state = b.action === 'review_approve' ? 'approved' : 'rejected'; r.by = u.email; r.doneAt = t; r.note = clip(b.note, 200);
      if (r.state === 'approved') { a.status = 'passed'; const f = newAccount({ uid: a.uid, email: a.email, name: a.name, program: a.program, size: a.size, phase: 'funded', parentId: a.id, source: 'funded' }); tell(a.uid, 'صرت متداول ممول 🏆', `انفتح حسابك الممول ${f.id}.`, f.id); save(); return { ok: true, id: f.id }; }
      a.status = 'failed'; a.failReason = 'review_rejected'; tell(a.uid, 'نتيجة المراجعة', `ما انقبل الحساب ${a.id} للتمويل${r.note ? `: ${r.note}` : ''}.`, a.id); save(); return { ok: true };
    }
    if (b.action === 'payout_paid' || b.action === 'payout_reject') {
      const w = db.payouts.find((x) => x.id === b.id && PAY_RE.test(String(b.id))); if (!w || w.state !== 'pending') return { error: 'not_found' };
      const a = db.accounts[w.account]; if (!a) return { error: 'not_found' };
      w.by = u.email; w.doneAt = t; a.payoutPending = null;
      if (b.action === 'payout_reject') { w.state = 'rejected'; w.note = clip(b.note, 200); tell(a.uid, 'طلب السحب', `انرفض طلب السحب${w.note ? `: ${w.note}` : ''}.`, a.id); save(); return { ok: true }; }
      const ref = clip(b.reference, 80); if (ref.length < 3) return { error: 'reference_required' };
      w.state = 'paid'; w.reference = ref;
      // the withdrawn profit leaves the account: back to the starting balance
      a.balance = r2(a.balance - w.profit); a.dayRef = Math.min(a.dayRef, a.balance); a.lastPayoutAt = t; a.paidTotal = r2((a.paidTotal || 0) + w.amount);
      tell(a.uid, 'تم تحويل أرباحك 💸', `انحوّل $${w.amount} (مرجع ${ref}).`, a.id); save(); return { ok: true };
    }
    if (b.action === 'close_account') {
      const a = db.accounts[b.id]; if (!a || !ACC_RE.test(String(b.id))) return { error: 'not_found' };
      if (a.positions.length) return { error: 'close_positions' };
      a.status = 'failed'; a.failReason = 'closed_by_owner'; a.endedAt = t; save(); return { ok: true };
    }
    return { error: 'bad_action' };
  }

  /** From a paid checkout (Stripe webhook) — idempotent on the payment id. */
  function purchase({ uid, email, name, product, paymentId, paymentIntent = null, quantity = 1 }) {
    load(); const p = parseProduct(product); if (!p || typeof uid !== 'string' || !uid) return { error: 'bad_product' };
    if (paymentId && db.payments[paymentId]) return { duplicate: true, id: [].concat(db.payments[paymentId])[0] };
    const n = Math.min(5, Math.max(1, Math.floor(Number(quantity) || 1)));
    if (Object.values(db.accounts).filter((a) => a.uid === uid).length + n > MAX_ACCOUNTS * 3) return { error: 'too_many_accounts' };
    const ids = [];
    for (let i = 0; i < n; i++) {
      const a = newAccount({ uid, email, name, program: p.program.id, size: p.size, phase: p.program.phases.length ? 1 : 'funded', paymentId, source: 'stripe' }); if (paymentIntent) a.pi = String(paymentIntent).slice(0, 80);
      ids.push(a.id);
    }
    if (paymentId) db.payments[paymentId] = n > 1 ? ids : ids[0]; save();
    tell(uid, 'حساب التحدي جاهز ✅', n > 1 ? `انفتحلك ${n} حسابات (${p.program.short} · $${p.size.toLocaleString('en')}).` : `حسابك ${ids[0]} (${p.program.short} · $${p.size.toLocaleString('en')}) جاهز للتداول.`, ids[0]);
    return { ok: true, id: ids[0], ids };
  }

  /** Live check of every open account (SL / TP / loss rules / day roll-over). */
  let ticking = false;
  async function tick() {
    if (ticking) return; ticking = true;
    try {
      load(); const live = Object.values(db.accounts).filter((a) => (a.status === 'active' || a.status === 'funded'));
      const syms = live.flatMap((a) => a.positions.map((p) => p.sym)); const map = syms.length ? await prices(syms, 2000) : {}; const px = pxFn(map);
      let changed = false; const t = now();
      for (const a of live) { if (!a.positions.length && a.dayKey === dayKey(t)) continue; const ev = evaluate(a, px, t); if (ev.length) afterEvents(a, ev); changed = true; }
      if (changed) save();
    } catch (e) { log.error?.('[challenges] tick:', String(e?.message || e).slice(0, 80)); } finally { ticking = false; }
  }
  /** Refund / chargeback of a challenge fee: that account and every account that grew out of it is closed. */
  function onRefund(pi) {
    load(); const roots = Object.values(db.accounts).filter((a) => a.pi && a.pi === pi); if (!roots.length) return null;
    let n = 0;
    for (const root of roots) { let a = root; while (a) { if (a.status === 'active' || a.status === 'funded' || a.status === 'review') { a.positions = []; a.status = 'failed'; a.failReason = 'refunded'; a.endedAt = now(); n++; } a = a.nextId ? db.accounts[a.nextId] : null; } }
    save(); return `closed_${n}`;
  }
  function forgetUser(uid) { load(); for (const [id, a] of Object.entries(db.accounts)) if (a.uid === uid) delete db.accounts[id]; db.payouts = db.payouts.filter((w) => w.uid !== uid); save(); }

  return { canSave: () => Boolean(key), onRefund, list, view, order, close, modify, requestPayout, myPayouts, admin, adminAct, purchase, tick, forgetUser, _db: () => load(), flush: () => writer.flush?.() };
}
export { PROGRAMS };
