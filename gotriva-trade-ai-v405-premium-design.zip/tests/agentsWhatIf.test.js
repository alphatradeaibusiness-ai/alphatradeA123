import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import { createAgents, liveOf } from '../server/agents.js';

const T = Date.UTC(2026, 10, 20, 12);
const nova = (id, entry, stop, target, status, closedAt) => ({ id, symbol: 'EURUSD', direction: 'long', entry, stop, initialStop: stop, targets: [target], target, status, createdAt: closedAt - 3600e3, activatedAt: closedAt - 3000e3, filledAt: closedAt - 3000e3, closedAt });

test('v389 what-if rows carry R from the real stop; live levels only when allowed', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'agw-'));
  const list = [{ id: 'live1', symbol: 'EURUSD', direction: 'long', entry: 1.1, stop: 1.095, targets: [1.11], status: 'active', price: 1.102, createdAt: T }];
  const a = createAgents({ dataDir: dir, sources: { nova: () => list }, now: () => T, log: { error() {} } });
  a.tick();
  const hidden = a.detail('nova', { levels: false }); assert.equal(hidden.live[0].entry, undefined);
  const shown = a.detail('nova', { levels: true }).live[0];
  assert.equal(shown.slPips, 50); assert.equal(shown.tpPips, 100); assert.equal(shown.pipsNow, 20); assert.equal(shown.id, 'nova:live1');
  assert.deepEqual(liveOf('nova', list)[0].entry, undefined);
});
