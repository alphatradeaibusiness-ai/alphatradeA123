// v390 money between members: requests, shared pots, recent people, round-up on every spend, profit-protect rule, auto-renew rules.
import test from 'node:test';
import assert from 'node:assert/strict';
import { openDb } from '../server/bank/db.js';
import { createVault } from '../server/bank/vault.js';
import { createBank } from '../server/bank/service.js';
import { renewAction } from '../server/bank/features/social.js';
import { TEST_DOCS, TEST_PHONE } from './kycDocs.fixture.js';

const ADDR = { country: 'DE', region: 'BE', city: 'Berlin', postal: '10115', line1: 'Invalidenstrasse 1' };
function setup() {
  let t = Date.UTC(2026, 9, 27, 12); const db = openDb(':memory:');
  const bank = createBank({ db, vault: createVault({ secret: 'z'.repeat(40) }), mode: 'sandbox', now: () => t, priceFn: async () => ({ price: 1, ts: t }) });
  return { db, bank, tick: (ms) => { t += ms; } };
}
const kyc = (b, uid, name = 'Ada Lovelace') => { b.submitKyc(uid, { tier: 1, fullName: name, dob: '1990-05-05', nationality: 'DE', address: ADDR, idType: 'passport', phone: TEST_PHONE, docs: TEST_DOCS, idNumber: 'C' + Buffer.from(uid + name).toString('hex').slice(0, 14), idExpiry: '2031-01-01', sourceOfFunds: 'salary', proofOfAddressRef: 'vend-123' }); b.reviewKyc({ uid: 'owner' }, uid, 'approve'); };
const fund = (b, uid, amt) => b.sandboxFund(uid, { currency: 'USD', amount: amt, idem: `fund-${uid}-${amt}` });
const usd = (b, uid) => b.wallet(uid).find((w) => w.currency === 'USD').available;
const code = (fn) => { try { fn(); } catch (e) { return e.code; } return 'NO_ERROR'; };

test('v390 money request: paid once through a normal transfer, then closed', () => {
  const { bank } = setup(); kyc(bank, 'u1', 'Rami Haddad'); kyc(bank, 'u2', 'Sara Khalil'); fund(bank, 'u2', '200');
  const S = bank.social;
  assert.equal(code(() => S.request('u1', 'u1', { amount: '10' })), 'bad_recipient');
  assert.equal(code(() => S.request('u1', 'u2', { amount: '700' })), 'p2p_limit_exceeded');
  const q = S.request('u1', 'u2', { amount: '45', note: 'dinner' });
  assert.equal(S.requests('u2').incoming.length, 1); assert.equal(S.requests('u2').incoming[0].other, 'u1');
  assert.equal(code(() => S.payRequest('u1', q.id)), 'not_found', 'only the asked person can pay');
  const p = S.payRequest('u2', q.id); assert.ok(p.txn);
  assert.equal(S.payRequest('u2', q.id).replay, true, 'paying twice never moves money twice');
  assert.equal(usd(bank, 'u1'), 4500); assert.equal(usd(bank, 'u2'), 15500);
  assert.equal(S.requests('u2').incoming.length, 0);
  const q2 = S.request('u1', 'u2', { amount: '5' }); S.closeRequest('u2', q2.id, 'decline');
  assert.equal(code(() => S.payRequest('u2', q2.id)), 'request_closed');
  assert.deepEqual(S.recent('u2'), ['u1']);
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
});

test('v390 shared pot: shares held apart, released to the creator when full, refunded on cancel', () => {
  const { bank } = setup(); for (const u of ['a', 'b', 'c']) { kyc(bank, u, `Name ${u}`); fund(bank, u, '300'); }
  const S = bank.social;
  assert.equal(code(() => S.createPot('a', { name: 'Signals yearly', share: '90' }, [])), 'bad_members');
  const p = S.createPot('a', { name: 'Signals yearly', share: '90' }, ['b', 'c']); assert.equal(p.target, 27000);
  S.payShare('b', p.id); assert.equal(usd(bank, 'b'), 21000); assert.equal(usd(bank, 'a'), 30000, 'the creator gets nothing until full');
  assert.equal(S.payShare('b', p.id).replay, true);
  S.payShare('a', p.id); const done = S.payShare('c', p.id);
  assert.equal(done.pot.status, 'done'); assert.equal(usd(bank, 'a'), 30000 - 9000 + 27000);
  assert.equal(code(() => S.cancelPot('a', p.id)), 'pot_closed');
  const p2 = S.createPot('a', { name: 'Gift', share: '10' }, ['b']); S.payShare('b', p2.id);
  assert.equal(code(() => S.cancelPot('b', p2.id)), 'not_found', 'only the creator cancels');
  S.cancelPot('a', p2.id); assert.equal(usd(bank, 'b'), 21000, 'the paid share came back');
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
});

test('v390 round-up on member transfers and a share of partner commissions to a pocket', () => {
  const { bank } = setup(); kyc(bank, 'u1'); kyc(bank, 'u2', 'Bob Stone'); fund(bank, 'u1', '100');
  const pk = bank.pockets.createPocket('u1', { name: 'Save', currency: 'USD' });
  bank.planning.createRule('u1', { kind: 'roundup', pocketId: pk.id, roundTo: 1 });
  bank.p2p('u1', 'u2', { amount: '10.30', idem: 'p2p-ru-000001' });
  const pkt = () => bank.pockets.listPockets('u1')[0].balance;
  assert.equal(pkt(), 70, '$10.30 rounds up to $11 → 70¢ saved');
  bank.planning.createRule('u1', { kind: 'commission', pocketId: pk.id, pct: 20 });
  bank.creditPartnerCommission('u1', { cents: 5000, payoutId: 'pabcdef12' });
  assert.equal(pkt(), 70 + 1000, '20% of a $50 commission');
  bank.creditPartnerCommission('u1', { cents: 5000, payoutId: 'pabcdef12' });
  assert.equal(pkt(), 1070, 'the same payout never saves twice');
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
});

test('v390 auto-renew decisions', () => {
  const D = 86_400_000, t = 1e12;
  assert.equal(renewAction({ on: true, until: t + 2 * D, price: 8000, balance: 5000 }, t), 'remind');
  assert.equal(renewAction({ on: true, until: t + 2 * D, price: 8000, balance: 9000 }, t), null, 'enough money: no reminder');
  assert.equal(renewAction({ on: true, until: t + 2 * D, price: 8000, balance: 5000, remindedFor: t + 2 * D }, t), null, 'one reminder per period');
  assert.equal(renewAction({ on: true, until: t + 5 * 3_600_000, price: 8000, balance: 9000 }, t), 'renew');
  assert.equal(renewAction({ on: true, until: t + 5 * 3_600_000, price: 8000, balance: 9000, renewedFor: t + 5 * 3_600_000 }, t), null, 'once per period');
  assert.equal(renewAction({ on: false, until: t + 3_600_000, price: 8000, balance: 9000 }, t), null);
  assert.equal(renewAction({ on: true, until: t - 1, price: 8000, balance: 9000 }, t), null, 'an ended plan is not renewed by itself');
});

test('v391 gift cards: money held until redeemed once; buyer can cancel an unused one; not by the buyer', () => {
  const { bank } = setup(); kyc(bank, 'g1', 'Gift Buyer'); kyc(bank, 'g2', 'Gift Taker'); fund(bank, 'g1', '200');
  const S = bank.social;
  assert.equal(code(() => S.createGift('g1', { amount: '5' })), 'below_minimum');
  const g = S.createGift('g1', { amount: '50', note: 'Happy birthday' }); assert.match(g.code, /^GFT-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/);
  assert.equal(usd(bank, 'g1'), 15000);
  assert.equal(S.gifts('g1')[0].code, g.code, 'the buyer can see the code again');
  assert.equal(code(() => S.redeemGift('g1', g.code)), 'own_gift');
  assert.equal(code(() => S.redeemGift('g2', 'GFT-AAAA-BBBB-CCCC')), 'gift_not_found');
  const r = S.redeemGift('g2', g.code.toLowerCase().replace(/-/g, ' ')); assert.equal(r.amount, 5000);
  assert.equal(usd(bank, 'g2'), 5000);
  assert.equal(code(() => S.redeemGift('g2', g.code)), 'gift_used');
  assert.equal(code(() => S.cancelGift('g1', g.id)), 'gift_used');
  const g2 = S.createGift('g1', { amount: '20' }); S.cancelGift('g1', g2.id); assert.equal(usd(bank, 'g1'), 15000);
  assert.equal(S.gifts('g1')[0].code, null, 'a closed gift no longer shows its code');
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
});
