import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createEmailVerify } from '../server/emailVerify.js';

function setup() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kc-'));
  let t = 1_000_000; const sent = [];
  const ev = createEmailVerify({ dir, secret: 's', env: { RESEND_API_KEY: 're_x' }, fetchImpl: async (u, o) => { sent.push(JSON.parse(o.body)); return { ok: true, status: 200 }; }, now: () => t, log: {} });
  return { ev, sent, adv: (ms) => { t += ms; } };
}
const codeOf = (m) => /(\d{6})/.exec(m.subject)[1];

test('bank application code: its own mail, checked without being used up, used up once, never confirms the account', async () => {
  const { ev, sent } = setup();
  assert.equal(ev.mailOn(), true);
  const r = await ev.send('u1', { email: 'p@example.com', lang: 'ar', purpose: 'kyc' }); assert.equal(r.sent, true);
  assert.match(sent[0].html, /البنك الرقمي/); assert.match(sent[0].subject, /طلب البنك/);
  const code = codeOf(sent[0]);
  assert.equal(ev.check('u1', code === '000000' ? '111111' : '000000', { purpose: 'kyc' }).error, 'wrong_code');
  assert.deepEqual(ev.check('u1', code, { purpose: 'kyc' }), { ok: true });
  assert.deepEqual(ev.check('u1', code, { purpose: 'kyc' }), { ok: true }, 'a form error before consume keeps the code valid');
  assert.equal(ev.status('u1').verified, false, 'the bank code does not stand in for the sign-up confirmation');
  ev.consume('u1', 'kyc');
  assert.equal(ev.check('u1', code, { purpose: 'kyc' }).error, 'expired');
});

test('bank application code: the account code and the bank code do not unlock each other', async () => {
  const { ev, sent, adv } = setup();
  await ev.send('u2', { email: 'p@example.com', purpose: 'kyc' }); adv(61_000);
  await ev.send('u2', { email: 'p@example.com' });
  const kyc = codeOf(sent[0]); const acct = codeOf(sent[1]);
  if (kyc !== acct) { assert.equal(ev.check('u2', acct, { purpose: 'kyc' }).error, 'wrong_code'); assert.equal(ev.check('u2', kyc).error, 'wrong_code'); }
  assert.deepEqual(ev.check('u2', kyc, { purpose: 'kyc' }), { ok: true });
});
