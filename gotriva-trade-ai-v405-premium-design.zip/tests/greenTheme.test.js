import test from 'node:test';
import assert from 'node:assert/strict';
import { greenify } from '../build/greenTheme.js';

test('violet becomes the bank green; brand (UPPERCASE), orange, red and blue stay', () => {
  const out = greenify('a{c:#6b13ec;d:rgba(107, 19, 236, .9);--a0-rgb: 124, 58, 237;e:#C9B8FF;f:#f7931a;g:#ef4444;h:#3b82f6;i:#5ee6a0}');
  assert.match(out, /c:#[0-9a-f]{6};/); assert.doesNotMatch(out, /#6b13ec|107, 19, 236|124, 58, 237/);
  for (const keep of ['#C9B8FF', '#f7931a', '#ef4444', '#3b82f6', '#5ee6a0']) assert.ok(out.includes(keep), keep);
  const [r, g, b] = out.match(/c:#(..)(..)(..)/).slice(1).map((x) => parseInt(x, 16)); assert.ok(g > r && g > b, 'green dominant');
});
