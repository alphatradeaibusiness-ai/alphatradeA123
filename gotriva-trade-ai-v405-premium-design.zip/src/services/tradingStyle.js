// v249: the user's trading style, chosen in the profile (scalp | swing). «توصية AI» follows ONLY this choice: its style step,
// timeframes, analysis and automatic watch all use it. Kept per account in this browser (like the language and the photo).
import { storage } from '../utils/storage.js';
import { auth } from './auth/index.js';

export const TRADING_STYLES = ['scalp', 'swing'];
const key = () => `trading-style:${auth.current()?.uid || auth.current()?.email || 'guest'}`;
const listeners = new Set();
/** 'scalp' | 'swing' | null (not chosen yet). */
export const getTradingStyle = () => { const v = storage.get(key(), null); return TRADING_STYLES.includes(v) ? v : null; };
export function setTradingStyle(v) {
  if (v != null && !TRADING_STYLES.includes(v)) return false;
  if (v) storage.set(key(), v); else storage.remove(key());
  listeners.forEach((fn) => { try { fn(v || null); } catch { /* a view error never breaks the others */ } });
  return true;
}
export const onTradingStyle = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };

// v403 the member's own way of trading, written in their words plus a few switches. The AI reads the text; the switches really
// filter which tested strategies may give the trade (entry type, with-trend only, close stops only, no trades before big news).
export const WAY_DEFAULT = { text: '', entry: 'any', trendOnly: false, tightStop: false, avoidNews: false };
const wayKey = () => `trader-way:${auth.current()?.uid || auth.current()?.email || 'guest'}`;
export function getTraderWay() {
  const v = storage.get(wayKey(), null) || {};
  return { text: typeof v.text === 'string' ? v.text.slice(0, 500) : '', entry: ['any', 'market', 'limit'].includes(v.entry) ? v.entry : 'any', trendOnly: v.trendOnly === true, tightStop: v.tightStop === true, avoidNews: v.avoidNews === true };
}
export function setTraderWay(patch) { const v = { ...getTraderWay(), ...patch }; v.text = String(v.text || '').slice(0, 500); storage.set(wayKey(), v); return getTraderWay(); }
