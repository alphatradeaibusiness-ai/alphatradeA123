import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';

test('server: a new account must confirm its e-mail code; owners are never blocked; visits reach the owner dashboard', async () => {
  const PROJECT = 'gotriva-test'; const KID = 'k-ver';
  const kp = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const b64u = (b) => Buffer.from(b).toString('base64url');
  const tok = (uid, email) => { const n = Math.floor(Date.now() / 1000); const h = b64u(JSON.stringify({ alg: 'RS256', kid: KID, typ: 'JWT' }));
    const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: uid, iat: n - 10, auth_time: n - 10, exp: n + 3600, email, email_verified: true, firebase: { sign_in_provider: 'google.com' } }));
    return `${h}.${p}.${b64u(crypto.sign('RSA-SHA256', Buffer.from(`${h}.${p}`), kp.privateKey))}`; };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ver-')); const certFile = path.join(dir, 'certs.json');
  fs.writeFileSync(certFile, JSON.stringify({ [KID]: kp.publicKey.export({ type: 'spki', format: 'pem' }) }));
  const mails = [];
  const fake = http.createServer((q, r) => { let s = ''; q.on('data', (c) => (s += c)); q.on('end', () => { mails.push(JSON.parse(s)); r.writeHead(200, { 'content-type': 'application/json' }); r.end('{"id":"m"}'); }); });
  await new Promise((r) => fake.listen(0, '127.0.0.1', r));
  const port = 20000 + Math.floor(Math.random() * 20000); const O = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), BANK_MASTER_KEY: '', ANTHROPIC_API_KEY: '', FIREBASE_PROJECT_ID: PROJECT, AI_TEST_CERTS_FILE: certFile, TELEGRAM_BOT_TOKEN: '', VERIFY_TEST: '1', RESEND_API_KEY: 're_test', MAIL_TEST_BASE: `http://127.0.0.1:${fake.address().port}` }, stdio: 'ignore' });
  const req = (p, { method = 'GET', body, t } = {}) => new Promise((resolve, reject) => {
    const d = body === undefined ? null : JSON.stringify(body);
    const r = http.request({ host: '127.0.0.1', port, path: p, method, headers: { ...(method !== 'GET' ? { origin: O } : {}), ...(d ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(d) } : {}), ...(t ? { authorization: `Bearer ${t}` } : {}) } }, (res) => { let s = ''; res.on('data', (c) => (s += c)); res.on('end', () => { let j = null; try { j = JSON.parse(s); } catch { /* */ } resolve({ status: res.statusCode, body: j }); }); });
    r.on('error', reject); if (d) r.write(d); r.end();
  });
  const owner = tok('own', 'shheahmad417@gmail.com'); const sam = tok('sam', 'sam@x.co');
  try {
    for (let i = 0; i < 80; i++) { try { await req('/api/health'); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    await new Promise((r) => setTimeout(r, 30));
    assert.equal((await req('/api/me/signin', { method: 'POST', t: sam, body: { device: 'x' } })).status, 200, 'sign-in report is allowed');
    assert.equal((await req('/api/me/verify', { t: sam })).body.required, true);
    assert.equal((await req('/api/me/connect', { t: sam })).body.code, 'email_unverified');
    assert.equal((await req('/api/billing/checkout', { method: 'POST', t: sam, body: { plan: 'monthly' } })).body.code, 'email_unverified', 'no payment before confirming');
    const s1 = await req('/api/me/verify/send', { method: 'POST', t: sam, body: { lang: 'en' } }); assert.equal(s1.body.sent, true, JSON.stringify(s1.body));
    assert.equal(mails.length, 1); assert.deepEqual(mails[0].to, ['sam@x.co']);
    assert.equal((await req('/api/me/verify/send', { method: 'POST', t: sam, body: {} })).status, 429);
    const code = /(\d{6})/.exec(mails[0].subject)[1];
    assert.equal((await req('/api/me/verify/check', { method: 'POST', t: sam, body: { code: code === '000000' ? '111111' : '000000' } })).body.code, 'wrong_code');
    assert.equal((await req('/api/me/verify/check', { method: 'POST', t: sam, body: { code } })).body.ok, true);
    assert.equal((await req('/api/me/connect', { t: sam })).status, 200, 'account open after the code');
    // owners never wait for a code
    await req('/api/me/signin', { method: 'POST', t: owner, body: {} });
    assert.equal((await req('/api/me/verify', { t: owner })).body.required, false);
    // visits
    assert.equal((await req('/api/visit', { method: 'POST', body: { vid: 'v1', ref: 'https://www.google.com/', dev: 'phone', tz: 'Asia/Amman', land: '#/login' } })).status, 204);
    const dash = (await req('/api/admin/dashboard', { t: owner })).body;
    assert.equal(dash.visits.today.visits, 1); assert.equal(dash.visits.today.signups, 2); assert.equal(dash.emailVerify.verified, 1);
    assert.equal((await req('/api/admin/dashboard', { t: sam })).status, 403);
  } finally { child.kill(); fake.close(); }
});
