// v367: morning summary, monthly journal report, public results, owner backup archive, public results endpoint.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import zlib from 'node:zlib';
import { spawn } from 'node:child_process';
import { createChannelAccess } from '../server/channelAccess.js';
import { createLedger } from '../server/ledger.js';
import { createUserTrades } from '../server/userTrades.js';
import { createGrowth } from '../server/growth.js';
import { createAgents } from '../server/agents.js';
import { createBackups, tarHeader } from '../server/backup.js';

const DAY = 86_400_000; const H = 3_600_000;
function setup(t0, { day = null } = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'v367-'));
  let t = t0;
  const access = createChannelAccess(dir); const ledger = createLedger({ dir }); const ut = createUserTrades({ dir, secret: 's'.repeat(40) });
  const fetchFn = async (url) => {
    const u = String(url);
    if (u.startsWith('http://cal/')) return { ok: true, json: async () => [{ title: 'CPI', country: 'USD', impact: 'High', date: new Date(t + 5 * H).toISOString() }] };
    if (u.startsWith('http://mail/')) return { ok: true, json: async () => ({ id: 'm' }) };
    throw new Error(`unexpected ${u}`);
  };
  const g = createGrowth({ dir, secret: 'g'.repeat(40), access, ledger, userTrades: ut, agentsDay: () => day, env: {}, fetchFn, now: () => t, calendarUrl: 'http://cal/x', log: { error() {} } });
  return { g, ut, dir, setT: (v) => { t = v; } };
}
const trade = (id, closedSec, { symbol = 'EURUSD', resultR = -1, stop = 1.09, tags = [] } = {}) => ({ id, symbol, tf: '1h', style: 'swing', direction: 'long', execution: 'market', account: 'demo', asset: 'forex',
  status: resultR > 0 ? 'done' : 'stopped', entry: 1.1, stop, risk: 0.01, targets: [1.12], rr: [2], createdAt: closedSec - 7200, savedAt: (closedSec - 7200) * 1000, updatedAt: closedSec * 1000, validUntil: null,
  filledAt: closedSec - 7000, closedAt: closedSec, hits: resultR > 0 ? 1 : 0, resultR, capital: null, riskPct: null, riskAmount: null, units: null, mode: 'live', costR: 0, tags, note: '' });

test('morning summary: once a day in the morning window, real numbers only, can be switched off', async () => {
  const t0 = Date.UTC(2026, 10, 18, 5, 30);   // 07:30 Jerusalem
  const s = setup(t0, { day: { n: 3, pips: 42.5 } });
  await s.g.signIn({ uid: 'a', email: 'a@x.co', name: 'a', authTime: 1 }, { lang: 'ar' });
  await s.g.signIn({ uid: 'b', email: 'b@x.co', name: 'b', authTime: 1 }, { lang: 'en' });
  s.g.prefs('b', { daily: false });
  const sec = Math.floor(t0 / 1000);
  assert.equal(s.ut.upsert('a', trade('tr_d0001', sec - 3600, { resultR: 2 })).error, undefined);
  await s.g.runJobs();
  const a = s.g.notices('a').items.filter((x) => x.kind === 'daily');
  assert.equal(a.length, 1);
  assert.match(a[0].body, /سكّرت 1 صفقة \(\+2\.00R\)/); assert.match(a[0].body, /3 مسكّرة، \+42\.5 نقطة/); assert.match(a[0].body, /1 خبر قوي/); assert.match(a[0].body, /مش نصيحة مالية/);
  assert.equal(s.g.notices('b').items.filter((x) => x.kind === 'daily').length, 0, 'switched off');
  await s.g.runJobs(); assert.equal(s.g.notices('a').items.filter((x) => x.kind === 'daily').length, 1, 'not twice the same day');
  s.setT(t0 + 6 * H); await s.g.runJobs();   // afternoon next run: nothing new
  assert.equal(s.g.notices('a').items.filter((x) => x.kind === 'daily').length, 1);
});

test('morning summary: nothing to say means nothing sent', async () => {
  const t0 = Date.UTC(2026, 10, 18, 5, 30);
  const s = setup(t0, { day: { n: 0, pips: 0 } });
  s.g.dailyBody('ar', {}); assert.equal(s.g.dailyBody('ar', {}), null);
  assert.equal(s.g.dailyBody('en', { day: { n: 0 } }), null);
});

test('monthly journal report: on the 1st, names the symbol that cost the most, the repeated tag and trades without a stop', async () => {
  const t0 = Date.UTC(2026, 11, 1, 6);   // 1 Dec, 08:00 Jerusalem
  const s = setup(t0);
  await s.g.signIn({ uid: 'm', email: 'm@x.co', name: 'm', authTime: 1 }, { lang: 'ar' });
  const sec = Math.floor(t0 / 1000);
  const rows = [['tr_m0001', 'GBPUSD', -1, ['fomo']], ['tr_m0002', 'GBPUSD', -1, ['fomo']], ['tr_m0003', 'EURUSD', 2, []], ['tr_m0004', 'XAUUSD', -0.5, ['late']]];
  rows.forEach(([id, symbol, r, tags], i) => assert.equal(s.ut.upsert('m', trade(id, sec - (i + 2) * 86400, { symbol, tags, resultR: r })).error, undefined));
  const ins = s.g.journalInsight('m', t0);
  assert.equal(ins.n, 4); assert.equal(ins.wins, 1); assert.equal(ins.worst.sym, 'GBPUSD'); assert.equal(ins.tag.name, 'fomo'); assert.equal(ins.tag.n, 2);
  await s.g.runJobs();
  const n = s.g.notices('m').items.filter((x) => x.kind === 'monthly');
  assert.equal(n.length, 1); assert.match(n[0].body, /GBPUSD/); assert.match(n[0].body, /«fomo» \(2 مرات\)/);
  await s.g.runJobs(); assert.equal(s.g.notices('m').items.filter((x) => x.kind === 'monthly').length, 1, 'once a month');
  assert.equal(s.g.journalInsight('nobody', t0), null, 'fewer than 3 trades: no report');
});

test('public results: closed trades only, no levels, no open trades; day() sums the last 24 hours', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'v367a-'));
  const t = Date.UTC(2026, 10, 16, 12);
  const elite = [
    { id: 'w', symbol: 'XAUUSD', direction: 'long', entry: 2000, initialStop: 1990, stop: 1990, targets: [2010, 2020, 2030], status: 'tp3', hits: 3, filledAt: t - 5 * H, createdAt: t - 6 * H, closedAt: t - 2 * H },
    { id: 'l', symbol: 'XAUUSD', direction: 'long', entry: 2000, initialStop: 1990, stop: 1990, targets: [2010, 2020, 2030], status: 'sl', hits: 0, filledAt: t - 40 * DAY, createdAt: t - 40 * DAY, closedAt: t - 40 * DAY },
    { id: 'o', symbol: 'XAUUSD', direction: 'short', entry: 2000, stop: 2010, targets: [1990, 1980, 1970], status: 'entry_hit', hits: 0, filledAt: t, createdAt: t, price: 1995 },
  ];
  const a = createAgents({ dataDir: dir, sources: { elite: () => elite, swing: () => null, nova: () => null, signals: () => null }, now: () => t });
  a.tick();
  const p = a.publicStats(); const e = p.agents.find((x) => x.id === 'elite');
  assert.equal(e.overall.signals, 2); assert.equal(e.m30.signals, 1); assert.equal(e.last.length, 2);
  const json = JSON.stringify(p);
  for (const k of ['"entry"', '"stop"', '"targets"', '"live"', 'entry_hit']) assert.equal(json.includes(k), false, `no ${k} in the public page`);
  assert.deepEqual(a.day(), { n: 1, pips: e.last[0].pips });
  fs.rmSync(dir, { recursive: true, force: true });
});

test('backup archive: newest finished day as a valid .tar.gz', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'v367b-'));
  fs.writeFileSync(path.join(dir, 'ai-config.json'), '{"enc":"x"}');
  fs.mkdirSync(path.join(dir, 'user-trades')); fs.writeFileSync(path.join(dir, 'user-trades', 'a.json'), '{"enc":"y"}');
  const b = createBackups({ dataDir: dir, env: {}, now: () => Date.UTC(2026, 0, 2), log: { error() {} } });
  assert.equal(b.latestArchive(), null, 'none yet');
  b.run();
  const a = b.latestArchive(); assert.equal(a.day, '2026-01-02');
  const tar = zlib.gunzipSync(a.gz); const names = [];
  for (let o = 0; o + 512 <= tar.length;) {
    const h = tar.subarray(o, o + 512); if (h.every((x) => x === 0)) break;
    assert.equal(h.subarray(257, 262).toString(), 'ustar');
    let sum = 0; for (let i = 0; i < 512; i++) sum += i >= 148 && i < 156 ? 32 : h[i];
    assert.equal(parseInt(h.subarray(148, 154).toString(), 8), sum, 'checksum');
    const name = h.subarray(0, 100).toString().replace(/\0.*$/s, ''); const size = parseInt(h.subarray(124, 135).toString(), 8);
    names.push(name); if (name.endsWith('a.json')) assert.equal(tar.subarray(o + 512, o + 512 + size).toString(), '{"enc":"y"}');
    o += 512 + Math.ceil(size / 512) * 512;
  }
  assert.ok(names.includes('gotriva-backup-2026-01-02/data/user-trades/a.json')); assert.ok(names.includes('gotriva-backup-2026-01-02/DONE'));
  assert.throws(() => tarHeader(`${'x'.repeat(120)}/${'y'.repeat(120)}`, 1), /name_too_long/);
  fs.rmSync(dir, { recursive: true, force: true });
});

const get = (port, p, headers = {}) => new Promise((resolve, reject) => {
  http.get({ host: '127.0.0.1', port, path: p, headers }, (res) => { let buf = ''; res.on('data', (c) => (buf += c)); res.on('end', () => { let j = null; try { j = JSON.parse(buf); } catch { /* */ } resolve({ status: res.statusCode, body: j, headers: res.headers }); }); }).on('error', reject);
});

test('server: /api/public/results needs no sign-in; the backup download needs the owner', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'v367s-'));
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), ANTHROPIC_API_KEY: '' } });
  child.stdout.on('data', () => {}); child.stderr.on('data', () => {});
  try {
    let r;
    for (let i = 0; i < 80; i++) { try { r = await get(port, '/api/public/results'); break; } catch { await new Promise((x) => setTimeout(x, 100)); } }
    assert.equal(r.status, 200); assert.deepEqual(r.body.agents.map((x) => x.id), ['elite', 'swing', 'nova', 'signals']);
    assert.match(r.headers['cache-control'], /max-age=60/);
    const b = await get(port, '/api/admin/backup/latest'); assert.ok([401, 503].includes(b.status), `no sign-in, no backup (${b.status})`);
  } finally { child.kill(); fs.rmSync(dir, { recursive: true, force: true }); }
});
