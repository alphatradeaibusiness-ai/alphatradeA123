// v369 Stripe rails for the bank: Issuing (real cards, real-time authorisation by our engine, renewal), Checkout top-ups,
// Connect withdrawals. Stripe is faked here (no network in the build sandbox); the request shapes follow Stripe's docs.
import test from 'node:test';
import assert from 'node:assert/strict';
import { openDb } from '../server/bank/db.js';
import { createVault } from '../server/bank/vault.js';
import { createBank } from '../server/bank/service.js';
import { createStripeRails, formEncode, mapIssuingEvent } from '../server/bank/stripeRails.js';

const OWNER = { uid: 'owner' };
const ADDR = { country: 'DE', region: 'BE', city: 'Berlin', postal: '10115', line1: 'Invalidenstrasse 1' };
const kyc = (b, uid, tier) => { for (let t = 1; t <= tier; t++) { if (b.kycStatus(uid).tier >= t) continue;
  b.submitKyc(uid, { tier: t, fullName: 'Ada Lovelace', dob: '1990-05-05', nationality: 'DE', address: ADDR, idType: 'passport', idNumber: 'C' + Buffer.from(String(uid)).toString('hex').slice(0, 14), idExpiry: '2031-01-01', sourceOfFunds: 'salary', proofOfAddressRef: 'vend-123' });
  b.reviewKyc(OWNER, uid, 'approve'); } };

function fakeStripe() {
  const calls = []; let seq = 0;
  const fetchFn = async (url, o) => {
    const u = new URL(url); const body = Object.fromEntries(new URLSearchParams(o.body || ''));
    calls.push({ method: o.method, path: u.pathname, body, idem: o.headers['idempotency-key'] || null, version: o.headers['stripe-version'] });
    const json = (j, status = 200) => ({ ok: status < 300, status, json: async () => j });
    if (u.pathname === '/v1/issuing/cardholders') return json({ id: `ich_${++seq}` });
    if (u.pathname === '/v1/issuing/cards') return json({ id: `ic_${++seq}`, last4: String(4000 + seq).slice(-4), exp_month: 9, exp_year: 2029, brand: 'Visa' });
    if (u.pathname.startsWith('/v1/issuing/cards/')) return json({ id: u.pathname.split('/').pop(), status: body.status });
    if (u.pathname === '/v1/ephemeral_keys') return json({ secret: 'ek_test_secret' });
    if (u.pathname === '/v1/checkout/sessions') return json({ id: `cs_test_${++seq}abcdef`, url: 'https://checkout.stripe.com/c/pay/x' });
    if (u.pathname === '/v1/accounts') return json({ id: 'acct_1TESTabcd' });
    if (u.pathname === '/v1/account_links') return json({ url: 'https://connect.stripe.com/setup/e/x' });
    if (u.pathname.startsWith('/v1/accounts/')) return json({ id: 'acct_1TESTabcd', payouts_enabled: fakeStripe.enabled, details_submitted: true, country: 'DE', default_currency: 'eur' });
    if (u.pathname === '/v1/transfers') return json({ id: 'tr_1TESTxyz' });
    return json({ error: { code: 'not_mocked' } }, 400);
  };
  return { fetchFn, calls };
}

function setup() {
  let t = Date.UTC(2026, 10, 20, 12); const db = openDb(':memory:'); const fk = fakeStripe();
  const env = { BANK_STRIPE_ISSUING: '1', BANK_STRIPE_TOPUP: '1', BANK_STRIPE_CONNECT: '1', STRIPE_PUBLISHABLE_KEY: 'pk_test_abcdefghijkl' };
  const rails = createStripeRails({ key: 'sk_test_abcdefghijklmnop', env, mode: 'sandbox', fetchFn: fk.fetchFn });
  const bank = createBank({ db, vault: createVault({ secret: 'z'.repeat(40) }), mode: 'sandbox', now: () => t, rails,
    priceFn: async () => ({ price: 50000, ts: t }), rateFn: async () => ({ usdPer: { USD: 1, EUR: 1.1, USDT: 1, BTC: 50000 }, ts: t, sources: {} }), config: { beneficiaryCooldown: 1000 } });
  let n = 0; const fund = (uid, amount) => bank.sandboxFund(uid, { currency: 'USD', amount, idem: `f-${++n}-abcdef` });
  return { bank, db, fk, fund, adv: (ms) => { t += ms; }, now: () => t };
}
const usd = (bank, uid) => bank.wallet(uid).find((w) => w.currency === 'USD');

test('form encoding and the key / mode guard', () => {
  assert.equal(decodeURIComponent(formEncode({ a: { b: 1 }, c: [{ d: 2 }], e: '', f: null })), 'a[b]=1&c[0][d]=2');
  assert.equal(createStripeRails({ key: 'sk_live_abcdefghijklmnop', mode: 'sandbox', env: {}, log: { error() {} } }), null, 'a live key never runs in sandbox');
  assert.equal(createStripeRails({ key: 'sk_test_abcdefghijklmnop', mode: 'live', env: {}, log: { error() {} } }), null, 'a test key never runs in live');
  assert.equal(createStripeRails({ key: 'nope', mode: 'sandbox' }), null);
  const r = createStripeRails({ key: 'sk_test_abcdefghijklmnop', mode: 'sandbox', env: {} }); assert.equal(r.issuer, null, 'each rail is off until switched on');
});

test('Issuing: a real card is created at Stripe; authorisations are decided by our engine; settlement; controls; renewal', async () => {
  const { bank, fk, fund } = setup(); kyc(bank, 'u1', 2); fund('u1', '300');
  const card = await bank.vcards.create('u1', { holder: 'Ada Lovelace', dob: '1990-05-05', label: 'Everyday' });
  assert.equal(card.last4.length, 4); assert.equal(card.exp, '09/29'); assert.equal(card.issuer, 'stripe'); assert.ok(card.issuerRef.startsWith('ic_'));
  const ch = fk.calls.find((c) => c.path === '/v1/issuing/cardholders'); assert.equal(ch.body.name, 'Ada Lovelace'); assert.equal(ch.body['billing[address][country]'], 'DE');
  assert.equal(bank.vcards.reveal('u1', card.id).pan, undefined, 'no card number ever on our server');
  const auth = (id, cents, extra = {}) => mapIssuingEvent({ type: 'issuing_authorization.request', data: { object: { id, amount: 0, pending_request: { amount: cents, currency: 'usd' }, card: { id: card.issuerRef, cardholder: { billing: { address: { country: 'DE' } } } }, merchant_data: { name: 'Cafe Berlin', category: 'eating_places_restaurants', country: 'DE' }, authorization_method: 'chip', ...extra } } });
  const a1 = bank.vcards.issuerEvent(auth('iauth_A1', 2500)); assert.equal(a1.approved, true);
  assert.equal(usd(bank, 'u1').available, 27500, '$25 held');
  assert.equal(bank.vcards.issuerEvent(mapIssuingEvent({ type: 'issuing_transaction.created', data: { object: { id: 'ipi_1abcdef', type: 'capture', authorization: 'iauth_A1' } } })).ok, true);
  assert.equal(bank.vcards.issuerEvent(auth('iauth_A2', 99999)).approved, false, 'more than the balance → declined by our engine');
  bank.vcards.update('u1', card.id, { allowAbroad: false });
  const abroad = mapIssuingEvent({ type: 'issuing_authorization.request', data: { object: { id: 'iauth_A3', pending_request: { amount: 500, currency: 'usd' }, card: { id: card.issuerRef, cardholder: { billing: { address: { country: 'DE' } } } }, merchant_data: { name: 'NY Deli', country: 'US' }, authorization_method: 'online' } } });
  assert.equal(abroad.abroad, true); assert.equal(abroad.channel, 'online'); assert.equal(bank.vcards.issuerEvent(abroad).reason, 'abroad_blocked');
  const renewed = await bank.vcards.renew('u1', card.id);
  const rep = fk.calls.filter((c) => c.path === '/v1/issuing/cards').at(-1); assert.equal(rep.body.replacement_for, card.issuerRef); assert.match(rep.body.cardholder, /^ich_/, 'the same cardholder');
  assert.notEqual(renewed.id, card.id); assert.equal(renewed.controls.abroad, false, 'settings carry over');
  assert.equal(bank.vcards.list('u1').some((x) => x.id === card.id), false, 'the old card is closed');
  const ek = await bank.vcards.ephemeral('u1', renewed.id, 'ephkn_pub_abcdef'); assert.equal(ek.secret, 'ek_test_secret'); assert.equal(ek.publishableKey, 'pk_test_abcdefghijkl');
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
});

test('automatic renewal: cards expiring within 30 days get a new number, CVV and expiry', async () => {
  const { bank, db, fk } = setup(); kyc(bank, 'u2', 2);
  const c = await bank.vcards.create('u2', { holder: 'Ada Lovelace', dob: '1990-05-05' });
  db.prepare("UPDATE vcards SET exp = '11/26' WHERE id = ?").run(c.id);   // expires at the end of this month
  assert.equal(await bank.vcards.renewExpiring(), 1);
  const now = bank.vcards.list('u2'); assert.equal(now.length, 1); assert.equal(now[0].exp, '09/29');
  assert.ok(fk.calls.some((x) => x.body.replacement_reason === 'expired'));
  assert.equal(await bank.vcards.renewExpiring(), 0, 'nothing left to renew');
});

test('Checkout top-up: credited once after Stripe confirms; amount must match; refund takes it back', async () => {
  const { bank, fk } = setup(); kyc(bank, 'u3', 1);
  await assert.rejects(bank.startTopup('u3', { amount: '2', origin: 'https://site.test' }), (e) => e.code === 'bad_amount');
  const s = await bank.startTopup('u3', { amount: '150', origin: 'https://site.test' }); assert.match(s.url, /^https:\/\/checkout\.stripe\.com\//);
  const cs = fk.calls.find((c) => c.path === '/v1/checkout/sessions'); assert.equal(cs.body['line_items[0][price_data][unit_amount]'], '15000'); assert.equal(cs.body['metadata[kind]'], 'bank_topup');
  assert.throws(() => bank.creditTopup({ uid: 'u3', cents: 15000, sessionId: s.id, amountTotal: 100, currency: 'usd' }), (e) => e.code === 'amount_mismatch');
  assert.equal(bank.creditTopup({ uid: 'u3', cents: 15000, sessionId: s.id, paymentIntent: 'pi_T1', amountTotal: 15000, currency: 'usd' }).replay, false);
  assert.equal(bank.creditTopup({ uid: 'u3', cents: 15000, sessionId: s.id, paymentIntent: 'pi_T1', amountTotal: 15000, currency: 'usd' }).replay, true, 'a repeated webhook never pays twice');
  assert.equal(usd(bank, 'u3').available, 15000);
  assert.equal(bank.topupReversed({ paymentIntent: 'pi_T1' }), 'reversed'); assert.equal(usd(bank, 'u3').available, 0);
  assert.equal(bank.topupReversed({ paymentIntent: 'pi_T1' }), 'duplicate');
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
});

test('Connect withdrawal: link → payouts on → destination after cooling-off → approved → one Stripe transfer → completed', async () => {
  const { bank, fk, fund, adv } = setup(); kyc(bank, 'u4', 1); fund('u4', '400');
  const s = await bank.startPayoutAccount('u4', { country: 'de', origin: 'https://site.test' }); assert.match(s.url, /^https:\/\/connect\.stripe\.com\//);
  fakeStripe.enabled = false; assert.equal((await bank.refreshPayoutAccount('u4')).payoutsEnabled, false);
  fakeStripe.enabled = true; const pa = await bank.refreshPayoutAccount('u4'); assert.equal(pa.payoutsEnabled, true); assert.ok(pa.beneficiaryId);
  adv(2000);
  const w = bank.requestWithdrawal('u4', { beneficiaryId: pa.beneficiaryId, currency: 'USD', amount: '100', idem: 'wd-key-abcdef' });
  await assert.rejects(bank.sendStripePayout(OWNER, w.id), (e) => e.code === 'bad_state', 'not before the owner approved');
  bank.reviewWithdrawal(OWNER, w.id, 'approve');
  assert.equal((await bank.sendStripePayout(OWNER, w.id)).ok, true);
  const tr = fk.calls.filter((c) => c.path === '/v1/transfers'); assert.equal(tr.length, 1); assert.equal(tr[0].body.amount, '10000'); assert.equal(tr[0].body.destination, 'acct_1TESTabcd'); assert.equal(tr[0].idem, `wd-${w.id}`);
  assert.equal(bank.listWithdrawals('u4')[0].status, 'completed');
  await assert.rejects(bank.sendStripePayout(OWNER, w.id), (e) => e.code === 'bad_state', 'never twice');
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
});

test('HTTP: the bank Stripe webhook checks the signature, the mode, and credits a top-up once', async () => {
  const { spawn } = await import('node:child_process'); const fs = await import('node:fs'); const os = await import('node:os'); const path = await import('node:path'); const crypto = await import('node:crypto');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bsr-')); const port = 30000 + Math.floor(Math.random() * 9000); const whsec = 'whsec_testsecretabcdef';
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), BANK_MASTER_KEY: 'm'.repeat(40),
    BANK_STRIPE_KEY: 'sk_test_abcdefghijklmnop', BANK_STRIPE_TOPUP: '1', BANK_STRIPE_WEBHOOK_SECRET: whsec }, stdio: ['ignore', 'pipe', 'pipe'] });
  const post = async (payload, sig) => { const r = await fetch(`http://127.0.0.1:${port}/api/bank/stripe/webhook`, { method: 'POST', headers: { 'content-type': 'application/json', 'stripe-signature': sig }, body: payload }); return { status: r.status, body: await r.json().catch(() => null) }; };
  const sign = (payload) => { const t = Math.floor(Date.now() / 1000); return `t=${t},v1=${crypto.createHmac('sha256', whsec).update(`${t}.${payload}`).digest('hex')}`; };
  try {
    for (let i = 0; i < 80; i++) { try { await fetch(`http://127.0.0.1:${port}/api/health`); break; } catch { await new Promise((x) => setTimeout(x, 100)); } }
    const ev = (live) => JSON.stringify({ id: 'evt_1', type: 'checkout.session.completed', livemode: live, data: { object: { id: 'cs_test_abcdef123', object: 'checkout.session', mode: 'payment', payment_status: 'paid', amount_total: 2500, currency: 'usd', payment_intent: 'pi_X1', client_reference_id: 'uidA', metadata: { kind: 'bank_topup', uid: 'uidA', cents: '2500' } } } });
    assert.equal((await post(ev(false), 't=1,v1=00')).status, 400, 'bad signature');
    assert.equal((await post(ev(true), sign(ev(true)))).body.result, 'wrong_mode', 'a live event never credits a test bank');
    assert.equal((await post(ev(false), sign(ev(false)))).body.result, 'credited');
    assert.equal((await post(ev(false), sign(ev(false)))).body.result, 'duplicate');
  } finally { child.kill(); fs.rmSync(dir, { recursive: true, force: true }); }
});
