// v351 Gotriva Agents: one page for every signal channel (Elite, Swing Pulse Pro, Nova Pulse, the recommendation channel).
// Read-only over each channel's own state file: it never changes how a channel picks, tracks or announces a signal.
// Every closed trade is copied once into an append-only ledger (DATA_DIR/agents-ledger.json) so the all-time numbers
// survive the channels pruning their own history. Only trades that really entered count (an unfilled limit is not a trade).
// Pips follow the site's convention (src/services/pips.js): price distance / point size / points per pip.
import fs from 'node:fs';
import path from 'node:path';
import { findInstrument } from '../src/config/instruments.js';
import { pipPoints } from '../src/services/pips.js';

export const AGENTS = ['elite', 'swing', 'nova', 'signals'];
const DAY = 86_400_000;
const MAX_ROWS = 20_000;
const r1 = (v) => Math.round(v * 10) / 10;

/** Price of one pip for a symbol (site convention; a safe guess for symbols the site does not list). */
export function pipPrice(symbol) {
  const inst = findInstrument(symbol);
  if (inst?.pointSize > 0) return inst.pointSize * pipPoints(inst);
  const s = String(symbol || '').toUpperCase();
  if (/JPY$/.test(s)) return 0.01;
  if (/^[A-Z]{6}$/.test(s) && !/^X(AU|AG|PT|PD)/.test(s)) return 0.0001;
  if (/^XAU/.test(s)) return 0.1;
  if (/^XAG/.test(s)) return 0.01;
  return 1;
}
const pipsOf = (symbol, dist) => dist / pipPrice(symbol);
const sign = (dir) => (dir === 'long' || dir === 'buy' ? 1 : -1);

/** A closed, really-entered trade as a ledger row — or null (still open, never filled, cancelled). */
export function closedRow(ch, s) {
  if (!s || typeof s.id !== 'string') return null;
  const sym = s.symbol || s.market; const dir = s.direction; const sg = sign(dir);
  const base = { id: `${ch}:${s.id}`, ch, sym, dir: sg > 0 ? 'long' : 'short', tf: s.tf || null, openedAt: s.filledAt || s.activatedAt || s.createdAt || null, closedAt: s.closedAt || null };
  const thirds = (n) => { let p = 0; for (let k = 0; k < Math.min(3, n); k++) p += pipsOf(sym, (s.targets[k] - s.entry) * sg) / 3; return p; };
  let pips = null, out = null;
  if (ch === 'elite') {
    if (!['tp3', 'sl', 'expired'].includes(s.status) || !Number.isFinite(s.filledAt)) return null;
    const stop0 = Number.isFinite(s.initialStop) ? s.initialStop : s.stop; const hits = s.hits || 0;
    if (s.status === 'tp3') { pips = thirds(3); out = 'tp'; }
    else if (s.status === 'sl') { pips = hits ? thirds(hits) : -pipsOf(sym, Math.abs(s.entry - stop0)); out = hits ? 'be' : 'sl'; }
    else { const rest = Number.isFinite(s.price) ? pipsOf(sym, (s.price - s.entry) * sg) * (3 - Math.min(3, hits)) / 3 : 0; pips = thirds(hits) + rest; out = 'time'; }
  } else if (ch === 'swing') {
    if (!['tp3', 'sl', 'closed'].includes(s.status) || !s.filledAt || !Number.isFinite(s.realizedPips)) return null;
    pips = s.realizedPips; out = s.status === 'tp3' ? 'tp' : s.status === 'sl' ? (pips >= 0 ? 'be' : 'sl') : 'time';
  } else if (ch === 'nova') {
    if (!['tp', 'sl', 'expired'].includes(s.status) || !Number.isFinite(s.result)) return null;
    pips = s.result * pipsOf(sym, Math.abs(s.entry - s.stop)); out = s.status === 'tp' ? 'tp' : s.status === 'sl' ? 'sl' : 'time';
  } else if (ch === 'signals') {
    if (!['tp3', 'sl', 'be'].includes(s.status)) return null;
    pips = s.status === 'sl' && !s.hits ? -pipsOf(sym, Math.abs(s.entry - s.stop)) : thirds(s.hits || 0); out = s.status === 'tp3' ? 'tp' : s.status === 'sl' && !s.hits ? 'sl' : 'be';
  } else return null;
  if (!Number.isFinite(pips) || !base.closedAt) return null;
  return { ...base, pips: r1(pips), out };
}

/** The trade a channel has open right now (entered), newest first; levels only for the open channels. */
export function liveOf(ch, list, { levels = false } = {}) {
  const LIVE = { elite: ['entry_hit', 'tp1', 'tp2'], swing: ['active', 'tp1', 'tp2'], nova: ['active'], signals: ['active'] }[ch] || [];
  const open = (list || []).filter((s) => s && LIVE.includes(s.status) && (ch !== 'swing' || s.filledAt)).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  return open.slice(0, 3).map((s) => {
    const sym = s.symbol || s.market; const sg = sign(s.direction);
    const row = { sym, dir: sg > 0 ? 'long' : 'short', tf: s.tf || null, since: s.filledAt || s.activatedAt || s.createdAt || null, hits: s.hits || 0 };
    if (levels) Object.assign(row, { entry: s.entry, stop: s.stop, targets: s.targets || (Number.isFinite(s.target) ? [s.target] : []),
      pipsNow: Number.isFinite(s.price) ? r1(pipsOf(sym, (s.price - s.entry) * sg)) : null });
    return row;
  });
}

/** Numbers for a list of closed rows (oldest first): the same figures for any time range. */
export function statsOf(rows) {
  const n = rows.length; let wins = 0, losses = 0, total = 0, streak = 0, best = 0;
  for (const r of rows) { total += r.pips; if (r.pips > 0) { wins++; streak++; best = Math.max(best, streak); } else { if (r.pips < 0) losses++; streak = 0; } }
  return { signals: n, wins, losses, winRate: n ? Math.round((wins / n) * 1000) / 10 : null, totalPips: r1(total), avgPips: n ? r1(total / n) : null, bestStreak: best };
}

/** Running total of pips for a chart (at most `max` points, the last one always kept). */
export function equityOf(rows, max = 120) {
  let eq = 0; const pts = rows.map((r) => { eq += r.pips; return [r.closedAt, r1(eq)]; });
  if (pts.length <= max) return pts;
  const step = pts.length / max; const out = []; for (let i = 0; i < max - 1; i++) out.push(pts[Math.floor(i * step)]); out.push(pts.at(-1)); return out;
}

/** Trading session of a moment (UTC hours), shown next to each closed trade. */
export function sessionOf(ms) {
  const h = new Date(ms).getUTCHours();
  return h < 7 ? 'TOKYO' : h < 12 ? 'LONDON' : h < 21 ? 'NY' : 'SYDNEY';
}

const RANGES = { today: null, '7': 7, '30': 30, '90': 90, all: Infinity };
export function rangeStart(range, now = Date.now()) {
  if (range === 'today') { const d = new Date(now); d.setUTCHours(0, 0, 0, 0); return d.getTime(); }
  const days = RANGES[range]; return days === Infinity || days == null ? 0 : now - days * DAY;
}

/**
 * sources: { elite, swing, nova, signals } → functions returning that channel's current signal list (or null when the channel
 * does not run here). levelsFor(ch, user) says if a member may see the open trade's levels on this page.
 */
export function createAgents({ dataDir, sources, now = Date.now, log = console }) {
  const file = path.join(dataDir, 'agents-ledger.json');
  let st = (() => { try { const j = JSON.parse(fs.readFileSync(file, 'utf8')); return { rows: Array.isArray(j.rows) ? j.rows : [], since: j.since || {} }; } catch { return { rows: [], since: {} }; } })();
  let ids = new Set(st.rows.map((r) => r.id));
  let dirty = false, timer = null;
  const save = () => { dirty = true; if (timer) return; timer = setTimeout(() => { timer = null; if (!dirty) return; dirty = false;
    try { fs.mkdirSync(dataDir, { recursive: true }); fs.writeFileSync(`${file}.tmp`, JSON.stringify(st)); fs.renameSync(`${file}.tmp`, file); } catch (e) { log.error?.('[agents] save failed:', e.message); } }, 2000); timer.unref?.(); };
  const read = (ch) => { try { const l = sources[ch]?.(); return Array.isArray(l) ? l : null; } catch { return null; } };

  /** Copies every newly closed trade of every channel into the ledger. Cheap: one pass over each channel's list. */
  function tick() {
    let added = 0;
    for (const ch of AGENTS) {
      const list = read(ch); if (!list) continue;
      if (!st.since[ch]) { st.since[ch] = Math.min(now(), ...list.map((s) => s?.closedAt || s?.createdAt || Infinity)); dirty = true; }
      for (const s of list) { const row = closedRow(ch, s); if (row && !ids.has(row.id)) { st.rows.push(row); ids.add(row.id); added++; } }
    }
    if (added) { st.rows.sort((a, b) => a.closedAt - b.closedAt); if (st.rows.length > MAX_ROWS) { st.rows = st.rows.slice(-MAX_ROWS); ids = new Set(st.rows.map((r) => r.id)); } }
    if (added || dirty) save();
    return added;
  }
  const rowsOf = (ch, from = 0) => st.rows.filter((r) => r.ch === ch && r.closedAt >= from);

  /** The hub: one card per channel. */
  function hub() {
    const t = now();
    return { at: t, agents: AGENTS.map((ch) => {
      const list = read(ch); const all = rowsOf(ch); const m30 = all.filter((r) => r.closedAt >= t - 30 * DAY);
      return { id: ch, running: Boolean(list), since: st.since[ch] || null, live: list ? liveOf(ch, list).length > 0 : false,
        allPips: statsOf(all).totalPips, m30Pips: statsOf(m30).totalPips, signals: all.length };
    }) };
  }

  /** One channel's page: stats for a range, the chart, the open trades and the latest closed ones. */
  function detail(ch, { range = '30', side = 'all', sym = 'all', levels = false } = {}) {
    if (!AGENTS.includes(ch)) return null;
    const t = now(); const list = read(ch); const all = rowsOf(ch);
    const inRange = all.filter((r) => r.closedAt >= rangeStart(range, t));
    const shown = inRange.filter((r) => (sym === 'all' || r.sym === sym) && (side === 'all' || (side === 'wins' ? r.pips > 0 : r.pips < 0)));
    const symbols = [...new Set(all.map((r) => r.sym))].sort();
    return { at: t, id: ch, running: Boolean(list), since: st.since[ch] || null,
      overall: statsOf(all), range, side, sym, symbols, period: { ...statsOf(shown), equity: equityOf(shown) },
      live: list ? liveOf(ch, list, { levels }) : [],
      recent: all.slice(-25).reverse().map((r) => ({ id: r.id, sym: r.sym, dir: r.dir, tf: r.tf, closedAt: r.closedAt, session: sessionOf(r.closedAt), pips: r.pips, out: r.out })) };
  }
  /** v367 public results page: closed-trade numbers only (no open trades, no levels, no symbols' live state). */
  function publicStats() {
    const t = now();
    return { at: t, agents: AGENTS.map((ch) => { const all = rowsOf(ch); const m30 = all.filter((r) => r.closedAt >= t - 30 * DAY);
      return { id: ch, since: st.since[ch] || null, overall: statsOf(all), m30: statsOf(m30), equity: equityOf(all, 60), last: all.slice(-8).reverse().map((r) => ({ sym: r.sym, dir: r.dir, closedAt: r.closedAt, pips: r.pips, out: r.out })) }; }) };
  }
  /** Closed trades of all channels in the last 24 hours (for the morning summary). */
  function day() { const from = now() - DAY; const l = st.rows.filter((r) => r.closedAt >= from); return { n: l.length, pips: r1(l.reduce((a, r) => a + r.pips, 0)) }; }
  return { tick, hub, detail, publicStats, day, _state: () => st };
}
