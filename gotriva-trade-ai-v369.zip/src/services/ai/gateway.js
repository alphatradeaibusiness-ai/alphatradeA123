// The ONLY way the browser reaches AI: the site's own server (/api/ai/*), which holds the owner's key (encrypted)
// and checks the signed-in user. The browser never sees, stores or sends an AI key.
import { aiConfig } from '../../config/ai.js';
import { auth } from '../auth/index.js';

export const AI_BASE = aiConfig.apiUrl.replace(/\/chat$/, '');

export class AiError extends Error {
  constructor(code, status = 0) { super(code); this.code = code; this.status = status; }
}

let last = null; const listeners = new Set();
export const onAiStatus = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
export const lastAiStatus = () => last;
function publish(st) { last = { ...st, at: Date.now() }; listeners.forEach((fn) => { try { fn(last); } catch { /* a view error must not break the others */ } }); return last; }

async function headers(json = true) {
  const h = json ? { 'Content-Type': 'application/json' } : {};
  const tok = await auth.idToken().catch(() => null);
  if (tok) h.Authorization = `Bearer ${tok}`;
  return h;
}

async function request(method, path, body, timeoutMs = 60000) { return apiRequest(method, `${AI_BASE}${path}`, body, timeoutMs); }

/** Same call for any of the site's own server routes (used by the market-data key too). Adds the sign-in token. */
export async function apiRequest(method, url, body, timeoutMs = 60000) {
  const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  let r;
  try {
    r = await fetch(url, { method, headers: await headers(body !== undefined), body: body === undefined ? undefined : JSON.stringify(body), signal: ctrl.signal, credentials: 'same-origin' });
  } catch (e) {
    throw new AiError(e?.name === 'AbortError' ? 'timeout' : 'server_unreachable');
  } finally { clearTimeout(timer); }
  const ct = r.headers.get('content-type') || '';
  if (ct.includes('text/html')) throw new AiError('server_missing', r.status);   // static host (e.g. Netlify) answered with the page, not the API
  const j = await r.json().catch(() => null);
  if (!j) throw new AiError(r.status === 404 ? 'server_missing' : 'bad_reply', r.status);   // a static host without the Node server answers 404 / HTML
  if (!r.ok) throw new AiError(j.code || (r.status === 401 ? 'signin_required' : 'unknown'), r.status);
  return j;
}

/** A signed-in GET that returns a blob URL (images the server only shows to their owner, e.g. feedback attachments). */
export async function apiBlobUrl(url) {
  const r = await fetch(url, { headers: await headers(false), credentials: 'same-origin' });
  if (!r.ok) throw new AiError(r.status === 404 ? 'not_found' : 'unknown', r.status);
  return URL.createObjectURL(await r.blob());
}

/** v361: raw bytes of a signed-in download (for files that are decrypted in the browser). */
export async function apiBuffer(url) {
  const r = await fetch(url, { headers: await headers(false), credentials: 'same-origin' });
  if (!r.ok) throw new AiError(r.status === 404 ? 'not_found' : 'unknown', r.status);
  return r.arrayBuffer();
}

/** Connection state for everyone; owner details when the signed-in user is the owner. */
export async function aiStatus() {
  try { return publish(await request('GET', '/status', undefined, 10000)); }
  catch (e) { return publish({ state: e.code === 'server_missing' || e.code === 'server_unreachable' || e.code === 'bad_reply' ? 'no_server' : 'unknown', error: e.code }); }
}

/** A feature request (chat, support, explain, vision, images/describe, images/match). */
export async function aiPost(path, body, { timeoutMs = 70000 } = {}) {
  try { return await request('POST', path, body, timeoutMs); }
  catch (e) {
    if (['not_configured', 'invalid_key', 'no_credit', 'vision_unsupported'].includes(e.code)) aiStatus();   // the owner changed something: refresh every view
    throw e;
  }
}

/* Owner actions. Each returns { ok, code, status } and publishes the new status to every view. */
export async function saveAiConfig(cfg) { const r = await request('PUT', '/config', cfg, 90000); publish(r.status); return r; }
export async function testAiConfig() { const r = await request('POST', '/config/test', {}, 90000); publish(r.status); return r; }
export async function deleteAiConfig() { const r = await request('DELETE', '/config', undefined, 20000); publish(r.status); return r; }

/** v354: sends raw bytes (a photo or video) with the sign-in token; onProgress(0..1) while uploading. Resolves with the JSON reply. */
export async function apiUpload(url, blob, onProgress = () => {}) {
  const hd = await headers(false);
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest(); x.open('POST', url); x.timeout = 10 * 60_000;
    for (const [k, v] of Object.entries(hd)) x.setRequestHeader(k, v);
    x.setRequestHeader('Content-Type', blob.type || 'application/octet-stream');
    x.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(e.loaded / e.total); };
    x.onload = () => { let j = null; try { j = JSON.parse(x.responseText); } catch { /* not JSON */ } if (x.status >= 200 && x.status < 300 && j) resolve(j); else reject(new AiError(j?.code || (x.status === 413 ? 'video_too_large' : 'unknown'), x.status)); };
    x.onerror = () => reject(new AiError('server_unreachable')); x.ontimeout = () => reject(new AiError('timeout'));
    x.send(blob);
  });
}
