// v348 Order Flow — footprint chart (bid × ask volume at every price inside every candle), delta / CVD, volume profile
// (POC, value area), liquidity levels from the real order book, large prints, and order-flow setups with alerts.
// Data: REAL exchange trades with their aggressor side and the real order book (Binance spot for crypto, Binance TradFi
// perpetuals for gold / silver / oil / indices / stocks), streamed over WebSocket; the recent past is filled from the
// exchange's trade history. Forex has no public trade tape, so it is not offered (nothing is simulated).
import { h, esc, fmtNum } from '../utils/dom.js';
import { getLang, getLocale } from '../i18n/index.js';
import { toast } from '../components/ui.js';
import { marketConfig } from '../config/market.js';
import { binanceGet, fetchBinanceBook } from '../services/market/binance.js';
import { futGet, fetchFutBook, FUT_WS, fetchTradfiFutures, tradfiName } from '../services/market/tradfiBooks.js';
import { Footprint, autoTick, candlePoc, imbalances, stacked, volumeProfile, liquidityLevels, setups, priceKey } from '../services/orderFlow.js';
import { onUnmount } from './tools/common.js';
import { prepare, signalAt, planFor, backtest, SETUP_NAMES } from '../services/ofStrategy.js';
import { fetchBinanceCandles } from '../services/market/binance.js';
import '../styles/orderflow.css';

const CRYPTO = [['BTCUSDT', 'BTC'], ['ETHUSDT', 'ETH'], ['SOLUSDT', 'SOL'], ['BNBUSDT', 'BNB'], ['XRPUSDT', 'XRP'], ['DOGEUSDT', 'DOGE']];
const TFS = [[60, '1m'], [300, '5m'], [900, '15m']];
const BACKFILL_PAGES = 8;   // up to 8 × 1000 recent trades fill the first candles (the exchange's own history)
const MAX_TRADES = 160_000;
const C = { bg: '#0a0816', grid: 'rgba(148,130,255,.07)', text: '#cbd5e1', dim: '#6b7394', buy: [34, 197, 94], sell: [240, 68, 79], poc: '#f5c451', va: 'rgba(124,140,255,.10)', bidWall: '#38bdf8', askWall: '#fb7185', last: '#a78bfa' };
const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
const kfmt = (v) => (v >= 1e6 ? `${(v / 1e6).toFixed(1)}M` : v >= 1e4 ? `${(v / 1e3).toFixed(0)}K` : v >= 1e3 ? `${(v / 1e3).toFixed(1)}K` : v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v >= 1 ? v.toFixed(2) : v.toFixed(3));

export function renderOrderFlow() {
  const AR = getLang() === 'ar'; const L = (ar, en) => (AR ? ar : en);
  const el = h(`<section class="subpage orderflow page-enter" dir="${AR ? 'rtl' : 'ltr'}">
    <header class="of-hero"><div><h1>Order Flow <span class="of-tag">${esc(L('تدفّق الأوامر', 'Live'))}</span></h1>
      <p class="muted">${esc(L('مخطط البصمة (Footprint): حجم البيع × الشراء عند كل سعر داخل كل شمعة، الدلتا والدلتا التراكمية، بروفايل الحجم، مستويات السيولة من دفتر الأوامر الحقيقي، والصفقات الكبيرة، مع تنبيهات ذكية. كل الأرقام من صفقات حقيقية على البورصة.', 'Footprint chart: sell × buy volume at every price inside every candle, delta and cumulative delta, volume profile, liquidity levels from the real order book, and large prints, with smart alerts. Every number comes from real exchange trades.'))}</p></div>
      <div class="of-conn" data-conn><i></i><span>${esc(L('عم يتصل…', 'Connecting…'))}</span></div></header>
    <div class="of-bar">
      <label class="of-sel"><span>${esc(L('السوق', 'Market'))}</span><select data-mkt>${CRYPTO.map(([s, b]) => `<option value="${s}">${b}/USDT</option>`).join('')}</select></label>
      <div class="of-seg" data-tfs>${TFS.map(([s, l], i) => `<button type="button" data-tf="${s}" aria-pressed="${i === 0}">${l}</button>`).join('')}</div>
      <div class="of-seg" data-ticks>${[1, 2, 5, 10].map((m, i) => `<button type="button" data-tk="${m}" aria-pressed="${i === 0}">×${m}</button>`).join('')}</div>
      <label class="of-chk"><input type="checkbox" data-snd> ${esc(L('صوت التنبيه', 'Alert sound'))}</label>
      <label class="of-chk"><input type="checkbox" data-ntf> ${esc(L('إشعار', 'Notify'))}</label>
      <button type="button" class="of-live" data-live hidden>${esc(L('رجوع للأحدث', 'Back to live'))}</button>
    </div>
    <div class="of-stats" data-stats></div>
    <section class="of-strat">
      <div class="of-card of-trade" data-trade><h3>${esc(L('استراتيجية Gotriva Order Flow', 'Gotriva Order Flow strategy'))}</h3><p class="muted">${esc(L('عم نجهّز…', 'Preparing…'))}</p></div>
      <div class="of-card of-bt" data-bt><h3>${esc(L('الاختبار التاريخي', 'Back-test'))}</h3><p class="muted">${esc(L('عم نجيب تاريخ البورصة…', 'Loading exchange history…'))}</p></div>
    </section>
    <div class="of-wrap">
      <div class="of-canvas" data-box><canvas data-cv aria-label="${esc(L('مخطط البصمة', 'Footprint chart'))}"></canvas><div class="of-tip" data-tip hidden></div><p class="of-empty" data-empty>${esc(L('عم نجيب آخر الصفقات من البورصة…', 'Loading the latest trades from the exchange…'))}</p></div>
      <aside class="of-side">
        <section class="of-card"><h3>${esc(L('تنبيهات تدفّق الأوامر', 'Order-flow alerts'))}</h3><ul class="of-alerts" data-alerts><li class="muted">${esc(L('التنبيهات بتطلع عند إغلاق كل شمعة.', 'Alerts appear as each candle closes.'))}</li></ul></section>
        <section class="of-card"><h3>${esc(L('مستويات السيولة (دفتر الأوامر)', 'Liquidity levels (order book)'))}</h3><div data-walls class="of-walls"></div></section>
        <section class="of-card"><h3>${esc(L('صفقات كبيرة', 'Large prints'))} <small class="muted">${esc(L('أكبر 1%', 'top 1%'))}</small></h3><ul class="of-tape" data-tape></ul></section>
      </aside>
    </div>
    <details class="of-help"><summary>${esc(L('كيف تقرأ الأداة', 'How to read it'))}</summary>
      <ul><li>${esc(L('كل خانة: يسار = حجم البيع (اللي ضرب على الـ Bid)، يمين = حجم الشراء (اللي رفع الـ Ask) عند هالسعر.', 'Each cell: left = sell volume (hit the bid), right = buy volume (lifted the ask) at that price.'))}</li>
      <li>${esc(L('الخانة المضيئة = اختلال قطري ≥ 300% (شراء مقابل بيع على السعر اللي تحته، أو العكس). 3 خانات متتالية = اختلال متراكم.', 'A highlighted cell = diagonal imbalance ≥ 300% (buy vs the sell one tick below, or the opposite). 3 in a row = stacked imbalance.'))}</li>
      <li>${esc(L('الإطار الأصفر = أعلى حجم بالشمعة (POC). تحت الشموع: الدلتا (شراء − بيع) والحجم. البروفايل على الطرف: POC والمنطقة القيمية 70%.', 'Yellow box = the candle\'s point of control. Under the candles: delta (buy − sell) and volume. The profile on the side: POC and the 70% value area.'))}</li>
      <li>${esc(L('الخطوط المتقطّعة = جدران سيولة حقيقية بدفتر الأوامر (×المتوسط). أوامر مخفية (آيسبيرغ) ما بتبين بأي دفتر.', 'Dashed lines = real resting liquidity walls in the order book (× average). Hidden (iceberg) orders are not visible in any book.'))}</li>
      <li>${esc(L('تحليل للتعليم مش نصيحة مالية. العقود الآجلة للذهب والمؤشرات بتتبع السعر وما هي السوق النقدي نفسه.', 'Education, not financial advice. Gold / index perpetuals track the asset and are not the cash market itself.'))}</li></ul></details>
  </section>`);

  const cv = el.querySelector('[data-cv]'); const box = el.querySelector('[data-box]'); const ctx = cv.getContext('2d');
  let mkt = 'BTCUSDT'; let tf = 60; let tkMul = 1; let baseTick = null; let fp = null; let trades = []; let ws = null; let closed = false; let gen = 0;
  let walls = null; let wallTimer = 0; let book = null; let scroll = 0; let drawQ = false; let lastSetupCandle = 0; const seen = new Set(); const alerts = [];
  let sound = false; let notify = false; let hover = null; let lastPrice = null;
  let K = []; let BT = null; let live = null; let lastSigTime = 0;   // v349 strategy: closed klines (with taker-buy volume), back-test, the open trade
  const fut = () => mkt.startsWith('F:'); const raw = () => mkt.replace(/^F:/, '');
  const prec = () => { const t = fp?.tick || 1; return Math.max(0, Math.min(8, -Math.floor(Math.log10(t)) + (String(t).includes('5') || String(t).includes('2') ? 1 : 0))); };
  const pf = (p) => fmtNum(p, prec());

  // markets: crypto spot + Binance TradFi perpetuals (gold, silver, oil, indices, stocks) when reachable
  fetchTradfiFutures().then((list) => {
    const keep = list.filter((x) => ['metal', 'energy', 'index'].includes(x.cls)).slice(0, 12);
    if (!keep.length || closed) return;
    el.querySelector('[data-mkt]').insertAdjacentHTML('beforeend', `<optgroup label="${esc(L('ذهب ونفط ومؤشرات (عقود Binance)', 'Gold, oil, indices (Binance perps)'))}">${keep.map((x) => { const n = tradfiName(x.base); return `<option value="${x.id}">${esc(n ? (AR ? n[0] : n[1]) : x.base)} · ${esc(x.symbol)}</option>`; }).join('')}</optgroup>`);
  }).catch(() => {});

  function setConn(state, txt) { const c = el.querySelector('[data-conn]'); c.dataset.state = state; c.querySelector('span').textContent = txt; }

  async function backfill(myGen) {
    const get = (q) => (fut() ? futGet(`/fapi/v1/aggTrades?symbol=${raw()}&${q}`) : binanceGet(`/api/v3/aggTrades?symbol=${raw()}&${q}`, { timeoutMs: 12000 }));
    const conv = (r) => ({ id: r.a, price: +r.p, qty: +r.q, time: +r.T, buy: !r.m });
    let all = (await get('limit=1000')).map(conv);
    for (let i = 1; i < BACKFILL_PAGES && all.length && myGen === gen; i++) {
      const from = all[0].id - 1000; if (from <= 0) break;
      const page = (await get(`fromId=${from}&limit=1000`)).map(conv).filter((t) => t.id < all[0].id);
      if (!page.length) break; all = page.concat(all);
      // stop once the window covers enough candles
      if ((all.at(-1).time - all[0].time) / 1000 > tf * 90) break;
    }
    return all;
  }
  function rebuild() {
    const px = trades.at(-1)?.price || 1; baseTick = autoTick(px, tf);
    fp = Footprint.from(trades, { tfSec: tf, tick: baseTick * tkMul, maxCandles: 240 }); seen.clear(); lastSetupCandle = fp.candles.at(-1)?.time || 0;
    scroll = 0; draw();
  }
  async function connect() {
    const my = ++gen; try { ws?.close(); } catch { /* */ } ws = null; trades = []; fp = null; walls = null; book = null; alerts.length = 0; paintAlerts(); paintWalls(); paintTape();
    el.querySelector('[data-empty]').hidden = false; setConn('wait', L('عم نجيب التاريخ…', 'Loading history…'));
    const queue = [];
    const s = raw().toLowerCase();
    try { ws = new WebSocket(`${fut() ? FUT_WS : marketConfig.binanceWsUrl}/stream?streams=${s}@aggTrade`); } catch { ws = null; }
    if (ws) {
      ws.onmessage = (ev) => { if (my !== gen) return; let m; try { m = JSON.parse(ev.data)?.data; } catch { return; } if (m?.e !== 'aggTrade') return; const t = { id: m.a, price: +m.p, qty: +m.q, time: +m.T, buy: !m.m }; if (!fp) queue.push(t); else onTrade(t); };
      ws.onopen = () => { if (my === gen && fp) setConn('ok', L('مباشر · كل صفقة لحظة بلحظة', 'Live · every trade as it happens')); };
      ws.onclose = () => { if (closed || my !== gen) return; setConn('bad', L('انقطع الاتصال، عم نرجع نتصل…', 'Disconnected, reconnecting…')); setTimeout(() => { if (!closed && my === gen) reconnectLive(my); }, 2500); };
    }
    try { trades = await backfill(my); } catch { if (my !== gen) return; setConn('bad', L('ما قدرنا نجيب صفقات البورصة. ممكن الشبكة حاجبة Binance.', 'Could not load exchange trades. The network may block Binance.')); el.querySelector('[data-empty]').textContent = L('ما في بيانات صفقات متاحة هلّق.', 'No trade data available right now.'); return; }
    if (my !== gen) return;
    rebuild(); for (const t of queue) onTrade(t); queue.length = 0;
    el.querySelector('[data-empty]').hidden = Boolean(fp?.candles.length);
    setConn(ws && ws.readyState === 1 ? 'ok' : 'wait', ws && ws.readyState === 1 ? L('مباشر · كل صفقة لحظة بلحظة', 'Live · every trade as it happens') : L('عم يتصل…', 'Connecting…'));
    loadWalls(my); loadStrategy(my);
  }
  function reconnectLive(my) {   // keep the footprint, resume the stream; the gap is filled from the exchange history
    const s = raw().toLowerCase();
    try { ws = new WebSocket(`${fut() ? FUT_WS : marketConfig.binanceWsUrl}/stream?streams=${s}@aggTrade`); } catch { return; }
    ws.onopen = async () => {
      if (my !== gen) return; setConn('ok', L('مباشر · كل صفقة لحظة بلحظة', 'Live · every trade as it happens'));
      try { const get = fut() ? futGet(`/fapi/v1/aggTrades?symbol=${raw()}&fromId=${fp.lastId + 1}&limit=1000`) : binanceGet(`/api/v3/aggTrades?symbol=${raw()}&fromId=${fp.lastId + 1}&limit=1000`, { timeoutMs: 12000 }); for (const r of await get) onTrade({ id: r.a, price: +r.p, qty: +r.q, time: +r.T, buy: !r.m }); } catch { /* the gap stays small */ }
    };
    ws.onmessage = (ev) => { if (my !== gen) return; let m; try { m = JSON.parse(ev.data)?.data; } catch { return; } if (m?.e === 'aggTrade') onTrade({ id: m.a, price: +m.p, qty: +m.q, time: +m.T, buy: !m.m }); };
    ws.onclose = () => { if (closed || my !== gen) return; setConn('bad', L('انقطع الاتصال، عم نرجع نتصل…', 'Disconnected, reconnecting…')); setTimeout(() => { if (!closed && my === gen) reconnectLive(my); }, 3000); };
  }
  function onTrade(t) {
    if (!fp) return;
    const before = fp.candles.at(-1)?.time; const bigN = fp.big.length;
    if (!fp.add(t)) return;
    trades.push(t); if (trades.length > MAX_TRADES) trades.splice(0, trades.length - MAX_TRADES);
    lastPrice = t.price;
    if (fp.big.length !== bigN) paintTape();
    const now = fp.candles.at(-1)?.time;
    if (before && now !== before && now !== lastSetupCandle) { lastSetupCandle = now; runSetups(); refreshStrategy(gen); }
    if (live && !live.done) trackLive(t.price);
    queueDraw();
  }
  async function loadWalls(my) {
    clearTimeout(wallTimer); if (closed || my !== gen) return;
    try { book = fut() ? await fetchFutBook(raw(), 1000) : await fetchBinanceBook(raw(), 1000); const mid = lastPrice || (+book.bids[0][0] + +book.asks[0][0]) / 2; walls = liquidityLevels(book, mid, (fp?.tick || 1) * 4, { top: 5, rangePct: fut() ? 2 : 1.2 }); paintWalls(); queueDraw(); }
    catch { /* the walls just stay as they were */ }
    if (!closed && my === gen) wallTimer = setTimeout(() => loadWalls(my), 10_000);
  }

  // ── alerts ──
  const KIND = { stack: L('اختلال متراكم', 'Stacked imbalance'), divergence: L('تباعد الدلتا', 'Delta divergence'), absorption: L('امتصاص', 'Absorption'), wall: L('اختبار جدار سيولة', 'Liquidity wall test') };
  const WHY = {
    stack: (a) => (a.side === 'buy' ? L(`${a.detail.rows} خانات شراء متتالية: مشترين مبادرين، دعم محتمل عند ${pf(a.price)}`, `${a.detail.rows} buy rows in a row: initiative buyers, possible support at ${pf(a.price)}`) : L(`${a.detail.rows} خانات بيع متتالية: بائعين مبادرين، مقاومة محتملة عند ${pf(a.price)}`, `${a.detail.rows} sell rows in a row: initiative sellers, possible resistance at ${pf(a.price)}`)),
    divergence: (a) => (a.side === 'sell' ? L('قمة جديدة بس الدلتا سالبة: الشراء ضعيف، احتمال انعكاس لتحت', 'New high with negative delta: weak buying, possible turn down') : L('قاع جديد بس الدلتا موجبة: البيع ضعيف، احتمال انعكاس لفوق', 'New low with positive delta: weak selling, possible turn up')),
    absorption: (a) => (a.side === 'buy' ? L(`حجم ×${fmtNum(a.detail.volX, 1)} وبيع قوي بس الشمعة سكّرت لفوق: أوامر شراء كبيرة امتصّت البيع`, `Volume ×${fmtNum(a.detail.volX, 1)} with heavy selling, yet the candle closed up: big bids absorbed it`) : L(`حجم ×${fmtNum(a.detail.volX, 1)} وشراء قوي بس الشمعة سكّرت لتحت: أوامر بيع كبيرة امتصّت الشراء`, `Volume ×${fmtNum(a.detail.volX, 1)} with heavy buying, yet the candle closed down: big offers absorbed it`)),
    wall: (a) => L(`السعر عند جدار ${a.side === 'buy' ? 'شراء' : 'بيع'} حجمه ×${fmtNum(a.detail.x, 1)} المتوسط عند ${pf(a.price)}`, `Price at a ${a.side === 'buy' ? 'bid' : 'ask'} wall ×${fmtNum(a.detail.x, 1)} the average at ${pf(a.price)}`),
  };
  function runSetups() {
    const list = setups(fp, { walls }).filter((a) => !seen.has(a.id));
    for (const a of list) { seen.add(a.id); alerts.unshift({ ...a, mkt, at: Date.now() }); }
    if (alerts.length > 40) alerts.length = 40;
    if (!list.length) return;
    paintAlerts(); const top = list.sort((a, b) => b.strength - a.strength)[0];
    const msg = `${mktLabel()} · ${KIND[top.kind]} · ${top.side === 'buy' ? L('شراء', 'buy') : L('بيع', 'sell')}`;
    toast(msg, top.side === 'buy' ? 'success' : 'info');
    if (sound) beep(top.side === 'buy' ? 880 : 520);
    if (notify && 'Notification' in window && Notification.permission === 'granted') { try { new Notification('Gotriva Order Flow', { body: `${msg}\n${WHY[top.kind](top)}`, icon: '/icon-192.png', tag: top.id }); } catch { /* */ } }
  }
  let actx = null;
  function beep(f) { try { actx ||= new (window.AudioContext || window.webkitAudioContext)(); const o = actx.createOscillator(); const g = actx.createGain(); o.frequency.value = f; g.gain.setValueAtTime(0.0001, actx.currentTime); g.gain.exponentialRampToValueAtTime(0.18, actx.currentTime + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + 0.35); o.connect(g).connect(actx.destination); o.start(); o.stop(actx.currentTime + 0.4); } catch { /* */ } }
  const mktLabel = () => { const o = el.querySelector(`[data-mkt] option[value="${CSS.escape(mkt)}"]`); return o?.textContent || mkt; };
  function paintAlerts() {
    const ul = el.querySelector('[data-alerts]');
    ul.innerHTML = alerts.length ? alerts.map((a) => `<li class="${a.side}"><b>${esc(KIND[a.kind])}<span class="of-str">${'●'.repeat(a.strength)}</span></b><span>${esc(WHY[a.kind](a))}</span><small class="muted">${esc(new Date(a.at).toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit' }))}</small></li>`).join('')
      : `<li class="muted">${esc(L('ما في إعداد واضح لهلّق. التنبيهات بتطلع عند إغلاق كل شمعة.', 'No clear setup yet. Alerts appear as each candle closes.'))}</li>`;
  }
  function paintWalls() {
    const box2 = el.querySelector('[data-walls]');
    if (!walls) { box2.innerHTML = `<p class="muted">${esc(L('عم نقرأ دفتر الأوامر…', 'Reading the order book…'))}</p>`; return; }
    const row = (w) => `<li class="${w.side}"><span class="mono" dir="ltr">${pf(w.price)}</span><i style="--w:${Math.min(100, w.x * 12)}%"></i><b class="mono" dir="ltr">${kfmt(w.qty)}</b><small dir="ltr">×${fmtNum(w.x, 1)} · ${w.distPct > 0 ? '+' : ''}${fmtNum(w.distPct, 2)}%</small></li>`;
    box2.innerHTML = `<h4>${esc(L('عروض بيع (مقاومة)', 'Asks (resistance)'))}</h4><ul>${walls.asks.map(row).join('')}</ul><h4>${esc(L('طلبات شراء (دعم)', 'Bids (support)'))}</h4><ul>${walls.bids.map(row).join('')}</ul>`;
  }
  function paintTape() {
    const ul = el.querySelector('[data-tape]'); const list = (fp?.big || []).slice(-12).reverse();
    ul.innerHTML = list.length ? list.map((t) => `<li class="${t.buy ? 'buy' : 'sell'}"><b dir="ltr">${t.buy ? '▲' : '▼'} ${kfmt(t.qty)}</b><span class="mono" dir="ltr">${pf(t.price)}</span><small class="muted">${esc(new Date(t.time).toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit', second: '2-digit' }))}</small></li>`).join('')
      : `<li class="muted">${esc(L('ما في صفقات كبيرة بعد.', 'No large prints yet.'))}</li>`;
  }
  function paintStats(c) {
    if (!c) return;
    const vol = c.buy + c.sell; const bp = vol ? (c.buy / vol) * 100 : 50;
    el.querySelector('[data-stats]').innerHTML = `
      <div><span>${esc(L('آخر سعر', 'Last'))}</span><b class="mono" dir="ltr">${pf(c.close)}</b></div>
      <div><span>${esc(L('دلتا الشمعة', 'Candle delta'))}</span><b class="mono ${c.delta >= 0 ? 'up' : 'down'}" dir="ltr">${c.delta >= 0 ? '+' : '−'}${kfmt(Math.abs(c.delta))}</b></div>
      <div><span>${esc(L('الدلتا التراكمية', 'Cumulative delta'))}</span><b class="mono ${fp.cvd >= 0 ? 'up' : 'down'}" dir="ltr">${fp.cvd >= 0 ? '+' : '−'}${kfmt(Math.abs(fp.cvd))}</b></div>
      <div><span>${esc(L('شراء / بيع', 'Buy / sell'))}</span><b class="mono" dir="ltr">${fmtNum(bp, 0)}% / ${fmtNum(100 - bp, 0)}%</b><i class="of-bs"><em style="width:${bp}%"></em></i></div>
      <div><span>${esc(L('حجم الشمعة', 'Candle volume'))}</span><b class="mono" dir="ltr">${kfmt(vol)}</b></div>
      <div><span>${esc(L('حجم الخانة', 'Row size'))}</span><b class="mono" dir="ltr">${pf(fp.tick)}</b></div>`;
  }

  // ── v349 strategy: entries / stops / targets from candle order flow, back-tested on the exchange's own history ──
  const IV = { 60: '1m', 300: '5m', 900: '15m' };
  const kl = (rows) => (rows || []).map((r) => (Array.isArray(r) ? { time: Math.floor(r[0] / 1000), open: +r[1], high: +r[2], low: +r[3], close: +r[4], volume: +r[5], buy: +r[9] } : { ...r, buy: r.buyVolume }));
  async function klines(limit, endTime) {
    if (fut()) return kl(await futGet(`/fapi/v1/klines?symbol=${raw()}&interval=${IV[tf]}&limit=${limit}${endTime ? `&endTime=${endTime}` : ''}`));
    return kl(await fetchBinanceCandles(raw(), IV[tf], limit, endTime));
  }
  const closedOnly = (cs) => cs.filter((c) => (c.time + tf) * 1000 <= Date.now());
  async function loadStrategy(my) {
    K = []; BT = null; paintBt(); paintTrade();
    try {
      let cs = await klines(1000);
      for (let k = 0; k < 2 && cs.length && my === gen; k++) { const older = await klines(1000, cs[0].time * 1000 - 1); if (!older.length) break; cs = older.concat(cs); }
      if (my !== gen) return;
      K = closedOnly(cs); BT = backtest(K, { feePct: fut() ? 0.05 : 0.04 });
    } catch { if (my === gen) { BT = { error: true }; } }
    if (my !== gen) return;
    paintBt(); checkSignal(true);
  }
  async function refreshStrategy(my) {
    if (!K.length) return;
    try { const fresh = closedOnly(await klines(5)); if (my !== gen) return; for (const c of fresh) { if (c.time > K.at(-1).time) K.push(c); } if (K.length > 3500) K.splice(0, K.length - 3500); checkSignal(false); } catch { /* next candle */ }
  }
  function checkSignal(first) {
    if (K.length < 60) { paintTrade(); return; }
    const P = prepare(K); const i = K.length - 1; const sig = signalAt(P, i);
    if (sig && sig.time !== lastSigTime && !(live && !live.done)) {
      const entry = lastPrice || K[i].close; const plan = planFor(sig, entry, P.a14[i]);
      if (plan) {
        lastSigTime = sig.time;
        const fc = fp?.candles.find((c) => c.time === sig.time);
        const conf = fc ? stacked(fc, fp.tick).some((x) => x.side === sig.side) : null;   // the footprint of the same candle shows initiative on our side
        live = { ...plan, side: sig.side, setup: sig.setup, why: sig.why, at: Date.now(), status: 'active', done: false, fpConfirm: conf, hist: BT?.stats?.[sig.setup] };
        if (!first) { const msg = `${mktLabel()} · ${sig.side === 'buy' ? L('شراء', 'BUY') : L('بيع', 'SELL')} · ${AR ? SETUP_NAMES[sig.setup].ar : SETUP_NAMES[sig.setup].en}`; toast(msg, 'success'); if (sound) beep(sig.side === 'buy' ? 990 : 440);
          if (notify && 'Notification' in window && Notification.permission === 'granted') { try { new Notification('Gotriva Order Flow', { body: `${msg}\n${L('دخول', 'Entry')} ${pf(plan.entry)} · SL ${pf(plan.stop)} · TP1 ${pf(plan.tp1)} · TP2 ${pf(plan.tp2)}`, icon: '/icon-192.png', tag: `of-${sig.time}` }); } catch { /* */ } } }
      }
    }
    paintTrade();
  }
  function trackLive(px) {
    const t = live; const long = t.side === 'buy'; let changed = false;
    if (long ? px <= t.stop : px >= t.stop) { t.done = true; t.status = t.status === 'tp1' ? 'be' : 'sl'; changed = true; }
    else if (t.status === 'active' && (long ? px >= t.tp1 : px <= t.tp1)) { t.status = 'tp1'; t.stop = t.entry; changed = true; }
    else if (t.status === 'tp1' && (long ? px >= t.tp2 : px <= t.tp2)) { t.status = 'tp2'; t.done = true; changed = true; }
    t.px = px;
    if (changed) { paintTrade(); toast(`${mktLabel()} · ${STAT[t.status]}`, t.status === 'sl' ? 'error' : 'success'); if (sound) beep(t.status === 'sl' ? 300 : 1200); }
    else if (!t._p || Date.now() - t._p > 1000) { t._p = Date.now(); paintTrade(); }
  }
  const STAT = { active: L('فعّالة', 'Active'), tp1: L('ضرب TP1، الوقف عالدخول', 'TP1 hit, stop at entry'), tp2: L('ضرب TP2 ✓', 'TP2 hit ✓'), sl: L('ضرب الوقف', 'Stopped out'), be: L('طلعت على الدخول بعد TP1', 'Closed at entry after TP1') };
  function paintTrade() {
    const box2 = el.querySelector('[data-trade]'); const t = live;
    const head = `<h3>${esc(L('استراتيجية Gotriva Order Flow', 'Gotriva Order Flow strategy'))} <small class="muted">${esc(IV[tf])}</small></h3>`;
    if (!t) { box2.innerHTML = `${head}<p class="of-nosig">${esc(K.length ? L('ما في إشارة على آخر شمعة مسكّرة. المحرك بيفحص كل شمعة بتسكّر وبيعطيك صفقة كاملة لما يتحقق إعداد.', 'No signal on the last closed candle. Each closing candle is checked and you get a full trade when a setup appears.') : L('عم نجيب الشموع…', 'Loading candles…'))}</p><ul class="of-rules"><li><b>A</b> ${esc(L('امتصاص: كسر قاع/قمة 20 شمعة بحجم ×2 وضغط عكسي، والإغلاق رجع لجوّا', 'Absorption: a sweep of the 20-bar extreme on ×2 volume against heavy aggression, closing back inside'))}</li><li><b>B</b> ${esc(L('تباعد: قمة/قاع جديد والدلتا والدلتا التراكمية عكسه', 'Divergence: a new extreme with delta and cumulative delta against it'))}</li><li><b>C</b> ${esc(L('اختراق: إغلاق برا 20 شمعة بدلتا ≥30% وحجم ×1.5 مع اتجاه EMA 50', 'Breakout: a close beyond 20 bars with ≥30% delta, ×1.5 volume, with the EMA-50 trend'))}</li></ul>`; return; }
    const long = t.side === 'buy'; const px = t.px ?? lastPrice; const r = px ? ((long ? px - t.entry : t.entry - px) / t.risk) : 0;
    const h = t.hist;
    box2.innerHTML = `${head}<div class="of-tt"><span class="of-side ${long ? 'buy' : 'sell'}" dir="ltr">${long ? 'BUY' : 'SELL'} · MARKET</span><span class="of-setup">${esc(t.setup)} · ${esc(AR ? SETUP_NAMES[t.setup].ar : SETUP_NAMES[t.setup].en)}</span><span class="of-st ${t.status}">${esc(STAT[t.status])}</span></div>
      <dl class="of-lv" dir="ltr"><div><dt>ENTRY</dt><dd>${pf(t.entry)}</dd></div><div><dt>STOP</dt><dd class="down">${pf(t.stop)}</dd></div><div><dt>TP1 · 1.5R</dt><dd class="up">${pf(t.tp1)}</dd></div><div><dt>TP2 · 3R</dt><dd class="up">${pf(t.tp2)}</dd></div></dl>
      <p class="of-now">${esc(L('هلّق', 'Now'))} <b class="mono ${r >= 0 ? 'up' : 'down'}" dir="ltr">${r >= 0 ? '+' : ''}${fmtNum(r, 2)}R</b>${t.fpConfirm ? ` · <span class="up">${esc(L('مؤكدة بالبصمة (اختلال متراكم) ✓', 'Footprint confirms (stacked imbalance) ✓'))}</span>` : ''}</p>
      <p class="muted of-why">${esc(L('نص الصفقة بيطلع عند TP1 والوقف بينتقل للدخول، والباقي عند TP2، أو بتسكّر بعد 24 شمعة.', 'Half off at TP1 with the stop moved to entry, the rest at TP2, or closed after 24 candles.'))}${h?.n ? ` ${esc(L(`تاريخياً هالإعداد: ${h.n} صفقة، ربح ${h.winRate}%، متوسط ${h.avgR}R.`, `Historically this setup: ${h.n} trades, ${h.winRate}% winners, average ${h.avgR}R.`))}` : ''}</p>`;
  }
  function paintBt() {
    const box2 = el.querySelector('[data-bt]'); const head = `<h3>${esc(L('الاختبار التاريخي', 'Back-test'))} <small class="muted">${esc(IV[tf])}</small></h3>`;
    if (!BT) { box2.innerHTML = `${head}<p class="muted">${esc(L('عم نجيب تاريخ البورصة…', 'Loading exchange history…'))}</p>`; return; }
    if (BT.error) { box2.innerHTML = `${head}<p class="muted">${esc(L('ما قدرنا نجيب تاريخ الشموع من البورصة.', 'Could not load the candle history from the exchange.'))}</p>`; return; }
    const days = ((BT.to - BT.from) / 86400).toFixed(1); const a = BT.stats.all;
    const row = (k, lab) => { const s2 = BT.stats[k]; return s2.n ? `<tr><th>${esc(lab)}</th><td>${s2.n}</td><td>${s2.winRate}%</td><td class="${s2.avgR >= 0 ? 'up' : 'down'}">${s2.avgR > 0 ? '+' : ''}${s2.avgR}</td><td class="${s2.totalR >= 0 ? 'up' : 'down'}">${s2.totalR > 0 ? '+' : ''}${s2.totalR}</td><td>${s2.pf ?? '—'}</td><td>${s2.maxDD}</td></tr>` : `<tr><th>${esc(lab)}</th><td colspan="6" class="muted">${esc(L('ما في صفقات', 'no trades'))}</td></tr>`; };
    const curve = a.curve || []; let svg = '';
    if (curve.length > 1) { const mn = Math.min(0, ...curve); const mx = Math.max(0, ...curve); const k = mx - mn || 1; const pts = curve.map((v, i) => `${(i / (curve.length - 1) * 100).toFixed(1)},${(38 - ((v - mn) / k) * 36).toFixed(1)}`).join(' ');
      svg = `<svg class="of-eq ${curve.at(-1) >= 0 ? 'up' : 'down'}" viewBox="0 0 100 40" preserveAspectRatio="none" aria-label="${esc(L('منحنى رأس المال بوحدات R', 'Equity curve in R'))}"><line x1="0" x2="100" y1="${(38 - ((0 - mn) / k) * 36).toFixed(1)}" y2="${(38 - ((0 - mn) / k) * 36).toFixed(1)}"/><polyline points="${pts}"/></svg>`; }
    box2.innerHTML = `${head}<p class="muted of-btp">${esc(L(`على بيانات ${fut() ? 'عقود' : ''} Binance الحقيقية لآخر ${days} يوم (${BT.bars} شمعة)، صفقة وحدة بالمرة، الدخول على فتح الشمعة اللي بعد الإشارة، وعمولة ${BT.feePct}% على كل صفقة. إذا الشمعة لمست الوقف والهدف سوا، بنحسبها وقف.`, `On real Binance ${fut() ? 'futures ' : ''}data for the last ${days} days (${BT.bars} candles), one trade at a time, entry on the next candle's open, ${BT.feePct}% fee per trade. A candle touching both stop and target counts as a stop.`))}</p>
      ${svg}<div class="of-tw"><table class="of-tbl"><thead><tr><th></th><th>${esc(L('صفقات', 'Trades'))}</th><th>${esc(L('رابحة', 'Win'))}</th><th>${esc(L('متوسط R', 'Avg R'))}</th><th>${esc(L('مجموع R', 'Total R'))}</th><th>PF</th><th>${esc(L('أقصى تراجع R', 'Max DD R'))}</th></tr></thead>
      <tbody>${row('all', L('الكل', 'All'))}${row('A', `A · ${AR ? SETUP_NAMES.A.ar : SETUP_NAMES.A.en}`)}${row('B', `B · ${AR ? SETUP_NAMES.B.ar : SETUP_NAMES.B.en}`)}${row('C', `C · ${AR ? SETUP_NAMES.C.ar : SETUP_NAMES.C.en}`)}</tbody></table></div>
      <p class="muted of-btp">${esc(L('R = قيمة المخاطرة بالصفقة (المسافة للوقف). نتائج الماضي ما بتضمن المستقبل، وفترة قصيرة ممكن ما تمثّل السوق. مش نصيحة مالية.', 'R = the amount risked (distance to the stop). Past results do not guarantee the future, and a short window may not represent the market. Not financial advice.'))}</p>`;
  }

  // ── drawing ──
  function queueDraw() { if (drawQ) return; drawQ = true; requestAnimationFrame(() => { drawQ = false; draw(); }); }
  let lastDraw = 0;
  function draw() {
    if (closed) return;
    const now = performance.now(); if (now - lastDraw < 120) { queueDraw(); return; } lastDraw = now;
    const W = box.clientWidth; const H = box.clientHeight; const dpr = Math.min(2, window.devicePixelRatio || 1);
    if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); cv.style.width = `${W}px`; cv.style.height = `${H}px`; }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.fillStyle = C.bg; ctx.fillRect(0, 0, W, H);
    if (!fp || !fp.candles.length) return;
    const narrow = W < 640; const colW = narrow ? 70 : 104; const axisW = narrow ? 58 : 72; const profW = narrow ? 56 : 110; const footH = 40; const timeH = 16;
    const plotW = W - axisW - profW; const plotH = H - footH - timeH;
    const n = Math.max(1, Math.floor(plotW / colW)); const total = fp.candles.length;
    scroll = Math.max(0, Math.min(scroll, Math.max(0, total - n))); el.querySelector('[data-live]').hidden = scroll === 0;
    const vis = fp.candles.slice(Math.max(0, total - n - scroll), total - scroll);
    let lo = Math.min(...vis.map((c) => c.low)); let hi = Math.max(...vis.map((c) => c.high));
    const pad = (hi - lo) * 0.06 || fp.tick * 4; lo -= pad; hi += pad;
    // rows: group ticks so a row is at least 14 px tall
    let m = 1; const tick = fp.tick; while ((plotH / ((hi - lo) / (tick * m))) < 14 && m < 400) m = m < 5 ? m + 1 : m * 2;
    const step = tick * m; const g = (k) => Math.round(Math.floor(k / step + 1e-9) * step * 1e8) / 1e8;
    const rows = Math.ceil((hi - lo) / step); const rowH = plotH / rows;
    const y = (p) => plotH - ((p - lo) / (hi - lo)) * plotH;
    // grid
    ctx.strokeStyle = C.grid; ctx.lineWidth = 1; ctx.font = `${narrow ? 10 : 11}px ui-monospace, Menlo, monospace`;
    const prof = volumeProfile(fp.profile);
    if (prof) { ctx.fillStyle = C.va; ctx.fillRect(0, y(prof.vah + tick), plotW, y(prof.val) - y(prof.vah + tick)); }
    // candles
    const x0 = plotW - vis.length * colW;
    vis.forEach((c, i) => {
      const x = x0 + i * colW; const grouped = new Map();
      for (const [k, r] of c.rows) { const gk = g(k); const a = grouped.get(gk) || { bid: 0, ask: 0 }; a.bid += r.bid; a.ask += r.ask; grouped.set(gk, a); }
      const im = imbalances({ rows: grouped }, step); const poc = candlePoc({ rows: grouped });
      let mx = 0; for (const r of grouped.values()) mx = Math.max(mx, r.bid, r.ask);
      for (const [k, r] of grouped) {
        const top = y(k + step); const hh = Math.max(1, y(k) - top); const half = (colW - 12) / 2;
        ctx.fillStyle = rgba(C.sell, 0.08 + 0.55 * (r.bid / mx)); ctx.fillRect(x + 8, top + 0.5, half, hh - 1);
        ctx.fillStyle = rgba(C.buy, 0.08 + 0.55 * (r.ask / mx)); ctx.fillRect(x + 8 + half, top + 0.5, half, hh - 1);
        const imb = im.get(k);
        if (imb) { ctx.strokeStyle = imb === 'buy' ? rgba(C.buy, 1) : rgba(C.sell, 1); ctx.lineWidth = 1.5; ctx.strokeRect(x + 8 + (imb === 'buy' ? half : 0) + 0.5, top + 1, half - 1, hh - 2); }
        if (k === poc) { ctx.strokeStyle = C.poc; ctx.lineWidth = 1.5; ctx.strokeRect(x + 8, top + 0.5, colW - 12, hh - 1); }
        if (hh >= 11) {
          ctx.fillStyle = imb === 'sell' ? '#fecdd3' : C.text; ctx.textAlign = 'right'; ctx.fillText(kfmt(r.bid), x + 8 + half - 3, top + hh / 2 + 4);
          ctx.fillStyle = imb === 'buy' ? '#bbf7d0' : C.text; ctx.textAlign = 'left'; ctx.fillText(kfmt(r.ask), x + 8 + half + 3, top + hh / 2 + 4);
        }
      }
      // candle body (thin) on the column's edge
      const up = c.close >= c.open; ctx.strokeStyle = up ? rgba(C.buy, 0.9) : rgba(C.sell, 0.9); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(x + 4, y(c.high)); ctx.lineTo(x + 4, y(c.low)); ctx.stroke();
      ctx.fillStyle = up ? rgba(C.buy, 0.9) : rgba(C.sell, 0.9); const bt = y(Math.max(c.open, c.close)); ctx.fillRect(x + 2, bt, 4, Math.max(1, y(Math.min(c.open, c.close)) - bt));
      // delta / volume rows
      const fy = plotH; const vol = c.buy + c.sell;
      ctx.fillStyle = c.delta >= 0 ? rgba(C.buy, 0.18) : rgba(C.sell, 0.18); ctx.fillRect(x + 2, fy + 2, colW - 4, 18);
      ctx.textAlign = 'center'; ctx.fillStyle = c.delta >= 0 ? '#86efac' : '#fda4af'; ctx.fillText(`${c.delta >= 0 ? '+' : '−'}${kfmt(Math.abs(c.delta))}`, x + colW / 2, fy + 15);
      ctx.fillStyle = C.dim; ctx.fillText(kfmt(vol), x + colW / 2, fy + 35);
      ctx.fillText(new Date(c.time * 1000).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }), x + colW / 2, plotH + footH + 12);
      ctx.strokeStyle = C.grid; ctx.beginPath(); ctx.moveTo(x + colW - 1, 0); ctx.lineTo(x + colW - 1, plotH + footH); ctx.stroke();
    });
    // liquidity walls
    if (walls) for (const w of [...walls.bids, ...walls.asks]) {
      if (w.price < lo || w.price > hi) continue; const yy = y(w.price);
      ctx.strokeStyle = w.side === 'bid' ? C.bidWall : C.askWall; ctx.setLineDash([5, 4]); ctx.lineWidth = Math.min(3, 1 + w.x / 4);
      ctx.beginPath(); ctx.moveTo(0, yy); ctx.lineTo(plotW, yy); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = w.side === 'bid' ? C.bidWall : C.askWall; ctx.textAlign = 'left'; ctx.fillText(`${w.side === 'bid' ? 'BID' : 'ASK'} ${kfmt(w.qty)} ×${fmtNum(w.x, 1)}`, 6, yy - 3);
    }
    // price axis
    ctx.fillStyle = '#0d0b1d'; ctx.fillRect(plotW, 0, axisW, plotH); ctx.textAlign = 'left'; ctx.fillStyle = C.dim;
    const every = Math.max(1, Math.ceil(16 / rowH)); let r0 = 0;
    for (let p = g(lo); p <= hi; p = Math.round((p + step) * 1e8) / 1e8, r0++) if (r0 % every === 0) ctx.fillText(pf(p), plotW + 4, y(p + step / 2) + 4);
    const last = fp.candles.at(-1).close; const ly = y(last);
    ctx.fillStyle = C.last; ctx.fillRect(plotW, ly - 9, axisW, 18); ctx.fillStyle = '#fff'; ctx.fillText(pf(last), plotW + 4, ly + 4);
    ctx.strokeStyle = 'rgba(167,139,250,.5)'; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.moveTo(0, ly); ctx.lineTo(plotW, ly); ctx.stroke(); ctx.setLineDash([]);
    // volume profile (whole loaded session)
    const px0 = plotW + axisW; ctx.fillStyle = '#0c0a1a'; ctx.fillRect(px0, 0, profW, plotH + footH + timeH);
    if (prof) {
      const pg = new Map(); for (const [k, b, a] of prof.rows) { const gk = g(k); const v = pg.get(gk) || { b: 0, a: 0 }; v.b += b; v.a += a; pg.set(gk, v); }
      let pm = 0; for (const v of pg.values()) pm = Math.max(pm, v.a + v.b);
      for (const [k, v] of pg) { if (k + step < lo || k > hi) continue; const top = y(k + step); const hh = Math.max(1, y(k) - top - 1); const wB = ((v.b) / pm) * (profW - 8); const wA = ((v.a) / pm) * (profW - 8);
        ctx.fillStyle = rgba(C.sell, 0.55); ctx.fillRect(px0 + 4, top, wB, hh); ctx.fillStyle = rgba(C.buy, 0.55); ctx.fillRect(px0 + 4 + wB, top, wA, hh);
        if (g(prof.poc) === k) { ctx.strokeStyle = C.poc; ctx.strokeRect(px0 + 3, top, profW - 6, hh); } }
      ctx.fillStyle = C.poc; ctx.textAlign = 'left'; ctx.fillText('POC', px0 + 4, Math.min(plotH - 2, Math.max(10, y(prof.poc) - 3)));
      ctx.fillStyle = C.dim; ctx.fillText('VAH', px0 + profW - 30, Math.max(10, y(prof.vah + tick) - 2)); ctx.fillText('VAL', px0 + profW - 30, Math.min(plotH - 2, y(prof.val) + 11));
    }
    ctx.fillStyle = C.dim; ctx.textAlign = 'left'; ctx.fillText('Δ', plotW + 4, plotH + 15); ctx.fillText('Vol', plotW + 4, plotH + 35);
    // hover
    if (hover && hover.x < plotW && hover.y < plotH) {
      const p = lo + ((plotH - hover.y) / plotH) * (hi - lo); const i = Math.floor((hover.x - x0) / colW); const c = vis[i]; const k = g(priceKey(p, tick));
      ctx.strokeStyle = 'rgba(255,255,255,.25)'; ctx.beginPath(); ctx.moveTo(0, hover.y); ctx.lineTo(plotW, hover.y); ctx.stroke();
      const tip = el.querySelector('[data-tip]');
      if (c) { let b = 0; let a = 0; for (const [kk, r] of c.rows) if (g(kk) === k) { b += r.bid; a += r.ask; }
        tip.hidden = false; tip.style.left = `${Math.min(hover.x + 14, W - 190)}px`; tip.style.top = `${Math.max(4, hover.y - 60)}px`;
        tip.innerHTML = `<b dir="ltr">${pf(k)}</b><span dir="ltr">${esc(L('بيع', 'Sell'))} ${kfmt(b)} · ${esc(L('شراء', 'Buy'))} ${kfmt(a)}</span><span dir="ltr">Δ ${a - b >= 0 ? '+' : '−'}${kfmt(Math.abs(a - b))} · ${new Date(c.time * 1000).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</span>`; }
      else el.querySelector('[data-tip]').hidden = true;
    } else el.querySelector('[data-tip]').hidden = true;
    paintStats(fp.candles.at(-1));
  }

  // ── controls ──
  el.querySelector('[data-mkt]').addEventListener('change', (e) => { mkt = e.target.value; connect(); });
  el.querySelector('[data-tfs]').addEventListener('click', (e) => { const b = e.target.closest('[data-tf]'); if (!b) return; tf = +b.dataset.tf; el.querySelectorAll('[data-tf]').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); if (trades.length) rebuild(); live = null; loadStrategy(gen); });
  el.querySelector('[data-ticks]').addEventListener('click', (e) => { const b = e.target.closest('[data-tk]'); if (!b) return; tkMul = +b.dataset.tk; el.querySelectorAll('[data-tk]').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); if (trades.length) rebuild(); });
  el.querySelector('[data-snd]').addEventListener('change', (e) => { sound = e.target.checked; if (sound) beep(660); });
  el.querySelector('[data-ntf]').addEventListener('change', async (e) => { notify = e.target.checked; if (notify && 'Notification' in window && Notification.permission === 'default') { try { await Notification.requestPermission(); } catch { /* */ } } if (notify && !('Notification' in window && Notification.permission === 'granted')) { notify = false; e.target.checked = false; toast(L('المتصفح ما سمح بالإشعارات.', 'The browser did not allow notifications.'), 'info'); } });
  el.querySelector('[data-live]').addEventListener('click', () => { scroll = 0; draw(); });
  box.addEventListener('wheel', (e) => { if (!fp) return; e.preventDefault(); scroll += (e.deltaY || e.deltaX) > 0 ? -1 : 1; if (AR) scroll += 0; queueDraw(); }, { passive: false });
  let drag = null;
  box.addEventListener('pointerdown', (e) => { drag = { x: e.clientX, s: scroll }; });
  window.addEventListener('pointerup', () => { drag = null; });
  box.addEventListener('pointermove', (e) => { const r = box.getBoundingClientRect(); hover = { x: e.clientX - r.left, y: e.clientY - r.top }; if (drag) { const colW = box.clientWidth < 640 ? 70 : 104; scroll = drag.s + Math.round((e.clientX - drag.x) / colW); } queueDraw(); });
  box.addEventListener('pointerleave', () => { hover = null; queueDraw(); });
  const ro = new ResizeObserver(() => queueDraw()); ro.observe(box);

  setTimeout(connect, 0);
  onUnmount(el, () => { closed = true; gen++; clearTimeout(wallTimer); ro.disconnect(); try { ws?.close(); } catch { /* */ } try { actx?.close(); } catch { /* */ } });
  return el;
}
