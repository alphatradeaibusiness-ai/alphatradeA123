import test from 'node:test';
import assert from 'node:assert/strict';
import { snapshot, runAllStrategies } from '../src/services/multiStrategy.js';
import { ictStrategy, asianRangeStrategy, fvgStrategy, patternStrategy, volumeProfileStrategy, volumeProfile, orderFlowStrategy, volumeNodes, NEW_STRATEGY_IDS } from '../src/services/extraStrategies.js';
import { STRATEGIES } from '../src/config/aiSignalRules.js';
import { ELITE_STRATEGIES } from '../src/services/eliteEngine.js';
import { limitLevel } from '../src/services/aiSignalEngine.js';

const DAY = 1_790_000_000 - (1_790_000_000 % 86400);
// flat noise around 100 on 15m candles ending at `endT`
const flat = (n, endT, px = 100, amp = 0.2) => Array.from({ length: n }, (_, k) => { const o = px + Math.sin(k * 1.7) * amp, c = px + Math.sin((k + 1) * 1.7) * amp; return { time: endT - (n - 1 - k) * 900, open: o, close: c, high: Math.max(o, c) + amp / 2, low: Math.min(o, c) - amp / 2, volume: 100 + (k % 7) * 10 }; });
const run = (f, cs, o = {}) => f(snapshot(cs, { tfSec: 900 }), { minRR: 1.2, costPct: 0, tfSec: 900, ...o });
const sane = (st) => { if (!st.plan) return; const p = st.plan; const sg = p.direction === 'long' ? 1 : -1; assert.ok((p.entry - p.stop) * sg > 0); assert.ok(p.targets.every((t) => (t - p.entry) * sg > 0)); assert.ok(p.rrMain >= 1.2); };

test('v319: every new strategy returns its own checklist and never a plan on flat noise', () => {
  const cs = flat(260, DAY + 9 * 3600);
  for (const f of [ictStrategy, asianRangeStrategy, fvgStrategy, patternStrategy, volumeProfileStrategy, orderFlowStrategy]) {
    const st = run(f, cs); assert.ok(NEW_STRATEGY_IDS.includes(st.id)); assert.ok(st.checks.length >= 4); assert.ok(st.checks.some((c) => c.id === 'rr'));
    if (st.status === 'qualified') sane(st); else assert.equal(st.plan, null);
  }
});

test('v319: Asian range breakout qualifies on a fresh close above the range and only in its window', () => {
  const end = DAY + 8 * 3600; const cs = flat(260, end);
  const last = cs.at(-1); last.open = 100.1; last.close = 100.75; last.high = 100.8; last.low = 100.05;
  const st = run(asianRangeStrategy, cs);
  assert.equal(st.status, 'qualified'); assert.equal(st.direction, 'long'); sane(st);
  assert.ok(st.plan.limitAt < st.plan.entry && st.plan.limitAt > st.plan.stop);
  assert.equal(limitLevel('asian_range', {}, st.plan), st.plan.limitAt);
  const late = cs.map((c) => ({ ...c, time: c.time + 12 * 3600 }));   // same candles at 20:00 UTC → outside the window
  assert.notEqual(run(asianRangeStrategy, late).status, 'qualified');
  assert.notEqual(run(asianRangeStrategy, cs, { tfSec: 14400 }).status, 'qualified');
});

test('v319: volume profile needs real volume and gives POC inside the value area', () => {
  const cs = flat(260, DAY + 9 * 3600); const vp = volumeProfile(cs, cs.length - 1);
  assert.ok(vp && vp.val < vp.poc && vp.poc < vp.vah);
  const noVol = cs.map((c) => ({ ...c, volume: 0 })); assert.equal(volumeProfile(noVol, noVol.length - 1), null);
  const st = run(volumeProfileStrategy, noVol); assert.equal(st.status, 'unavailable'); assert.equal(st.plan, null);
});

test('v319: the new strategies run on the AI page only, are marked new, and leave Alpha Elite on the three core ones', () => {
  const cs = flat(260, DAY + 9 * 3600); const base = { symbol: 'BTCUSDT', inst: { type: 'crypto', provider: 'binance' }, tf: '15m', tfSec: 900, candles: cs, mode: 'live', nowMs: (DAY + 9 * 3600 + 900) * 1000, reading: null };
  const ai = runAllStrategies(base, { ai: true }).strategies.map((s) => s.id); const plain = runAllStrategies(base, {}).strategies.map((s) => s.id);
  for (const id of NEW_STRATEGY_IDS) { assert.ok(ai.includes(id)); assert.ok(!plain.includes(id)); assert.equal(STRATEGIES.find((s) => s.id === id).status, 'new'); }
  assert.deepEqual([...ELITE_STRATEGIES].sort(), ['mean_reversion', 'smc', 'trend']);
});

test('v320: order flow needs real volume and qualifies on an absorbed return to a high-volume node', () => {
  const cs = flat(260, DAY + 9 * 3600); const noVol = cs.map((c) => ({ ...c, volume: 0 }));
  assert.equal(volumeNodes(noVol, noVol.length - 1), null); assert.equal(run(orderFlowStrategy, noVol).status, 'unavailable');
  for (const c of cs) if (Math.max(c.open, c.close) < 99.95) c.volume *= 6;   // most volume traded low in the range → a node there
  const nodes = volumeNodes(cs, cs.length - 1); assert.ok(nodes.length >= 1 && nodes.every((z) => z.top > z.bottom));
  const z = nodes[0]; const last = cs.at(-1);   // a wick into the lowest node on high volume, closing above it
  last.low = z.bottom + (z.top - z.bottom) / 2; last.open = z.top + 0.02; last.close = z.top + 0.12; last.high = last.close + 0.01; last.volume = 600;
  const prev = cs.at(-2); prev.low = last.low + 0.01; prev.open = z.top + 0.03; prev.close = z.top + 0.02; prev.high = z.top + 0.05;
  const st = run(orderFlowStrategy, cs);
  if (st.status === 'qualified') { sane(st); assert.equal(st.direction, 'long'); assert.ok(st.plan.stop < z.bottom + (z.top - z.bottom) / 2); }
  else assert.ok(st.checks.find((c) => c.id === 'node').status === 'pass');
});

test('v327: a pending short limit fills from the forming candle / live price, not only after the bar closes', async () => {
  const { trackTrade } = await import('../src/services/smcAssist.js');
  const T = 3600; const t0 = 1_700_000_000;
  const tr = { direction: 'short', execution: 'limit', entry: 100, stop: 103, targets: [97, 95, 93], rr: [1, 1.7, 2.3], createdAt: t0 + 600, validUntil: t0 + 99 * T };
  const closed = [{ time: t0 - T, open: 98, high: 99, low: 97.5, close: 98.5 }];
  const forming = { time: t0 + T, open: 99, high: 100.2, low: 98.8, close: 100.1 };
  assert.equal(trackTrade(tr, closed).status, 'pending');
  const r = trackTrade(tr, closed, { forming, price: 100.1, now: t0 + T + 600 });
  assert.equal(r.status, 'active'); assert.ok(r.filledAt);
  assert.equal(trackTrade(tr, closed, { price: 99.9, now: t0 + 700 }).status, 'pending');
  assert.equal(trackTrade(tr, closed, { price: 100, now: t0 + 700 }).status, 'active');
});

