// Simplified Chinese: the menus, buttons, sign-in, account, plans and page titles; everything else falls back to English.
import en from './en.js';
import { deepMerge } from './merge.js';
import b1 from './zh.b1.js';
import b2 from './zh.b2.js';

const base = deepMerge(en, {
  dir: 'ltr', langName: '中文',
  app: { tagline: "加密货币、黄金、外汇和指数的交易分析", subtagline: "实时图表、SMC / ICT 关键位，以及能解释每笔交易的 AI 助手。" },
  common: { or: '或', close: '关闭', save: '保存', cancel: '取消', reset: '重置', apply: '应用', on: '开', off: '关', loading: '加载中…', retry: '重试', demo: '演示模式', live: '实时', delayed: '延迟', lastUpdate: '最近更新', source: '来源', status: '状态', connected: '已连接', disconnected: '已断开', connecting: '连接中…', notConfigured: '未配置', signOut: '退出登录', clear: '清除', select: '选择', buy: '买入', sell: '卖出', long: '做多', short: '做空', price: '价格', level: '价位', bars: '根K线' },
  auth: {
    signInTitle: '登录', welcome: '欢迎使用 AlphaTrade AI', email: '电子邮箱', password: '密码', confirmPassword: '确认密码', name: '姓名', remember: '记住我', forgot: '忘记密码？', signIn: '登录',
    google: '使用 Google 继续', apple: '使用 Apple 继续', noAccount: '还没有账户？', createAccount: '创建新账户', haveAccount: '已有账户？', signUpTitle: '创建新账户', signUpSub: '创建账户以进入交易面板', signUp: '创建账户',
    resetTitle: '找回密码', resetSub: '输入邮箱以接收重置链接', sendReset: '发送重置链接', backToSignIn: '返回登录', newPassword: '新密码', setNewPassword: '设置密码',
    facts: [["实时行情", "加密货币价格直接来自 Binance。仍使用测试数据的品种会标注「演示」。"], ["可以随时提问的 AI 助手", "用阿拉伯语、英语、希伯来语、西班牙语或中文解释每个信号和你的交易。"], ["资金账户挑战", "账户规模从 $5K 到 $200K，每日亏损和最大亏损规则清楚明确。"]],
    slogan: ['人工智能驱动', '更好的机会', '更好的决策'], feature1: '数据安全\n强力保护', feature2: 'AI\n分析', feature3: '市场机会\n即时更新',
    resetSent: '如果该邮箱已注册，重置链接已发送。', resetDone: '密码已更新，现在可以登录。', signedUp: '账户创建成功。', signingIn: '登录中…', signingUp: '正在创建账户…', sending: '发送中…',
    err: { emailRequired: '请输入邮箱。', emailInvalid: '邮箱格式不正确。', passwordRequired: '请输入密码。', passwordShort: '密码至少需要 {n} 个字符。', passwordWeak: '密码请同时包含字母和数字。', passwordMismatch: '两次输入的密码不一致。', nameRequired: '请输入姓名。', invalidCredentials: '邮箱或密码错误。', emailInUse: '该邮箱已注册，请直接登录。', userNotFound: '该邮箱没有账户。', tooMany: '尝试次数过多，请稍后再试。', network: '无法连接登录服务，请检查网络。', popupClosed: '登录窗口在完成前被关闭。', unknown: '意外错误：{msg}' },
  },
  nav: { nova: 'NOVA PULSE', partners: 'ALPHA PARTNER CLUB', 'partners-admin': '合作伙伴俱乐部管理', liquidity: '实时流动性地图', rooms: '私人交易室', mentors: 'AI 导师市场', studio: '策略工作室与 DNA', council: 'AI 委员会与市场 X 光', 'rooms-admin': '交易室管理', elite: 'Alpha Elite Signals', 'admin-dashboard': '控制面板', mt5: 'MetaTrader 5 连接', 'ai-signal': 'AI 信号', alpha: 'Alpha AI', support: '在线客服', live: '直播', feedback: '意见与问题反馈', 'admin-stats': '业务分析', 'admin-plans': '订阅与优惠券', connect: '提醒与连接', contest: '月度比赛', academy: '学院', billing: '我的订阅', payments: '支付 (Stripe)', legal: '条款与隐私', bank: '数字银行', 'ai-key': 'AI 密钥', trust: '信任中心', monthly: '月度点数', lab: '策略实验室', risk: '风险管理', calendar: '经济日历', journal: '交易日志', radar: 'Alpha Radar', alerts: '自定义提醒', news: '新闻', signals: '信号频道', profile: '个人资料', pricing: '套餐', home: '首页', guide: '使用指南', strategies: '策略', markets: '市场', indicators: '指标', theme: '外观', menu: '菜单', smartlog: '智能日志', 'radar-rules': '多条件提醒', 'radar-multi': '多屏分析', 'radar-levels': '支撑与阻力', walkforward: '稳定性' },
  navShort: { nova: 'NOVA PULSE', partners: 'ALPHA PARTNER CLUB', 'partners-admin': '合作伙伴管理', liquidity: '流动性地图', rooms: '交易室', mentors: 'AI 导师', studio: '策略 DNA', council: 'AI 委员会', 'rooms-admin': '交易室管理', elite: 'Alpha Elite Signals', 'admin-dashboard': '控制面板', mt5: 'MT5 连接', 'ai-signal': 'AI 信号', alpha: 'Alpha AI', support: '客服', live: '直播', feedback: '反馈', 'admin-stats': '分析', 'admin-plans': '优惠券', notices: '通知', readAll: '全部标为已读', noNotices: '暂无通知。', now: '刚刚', home: '首页', bank: '银行', markets: '市场', indicators: '指标', strategies: '策略', guide: '指南', risk: '风险', journal: '日志', alerts: '提醒', signals: '信号', radar: 'Alpha Radar', lab: '实验室', monthly: '月度结果', news: '新闻', trust: '信任中心', legal: '条款', profile: '我的账户', 'ai-key': '密钥', payments: '支付', billing: '我的套餐', pricing: '套餐', connect: '提醒与连接', contest: '比赛', academy: '学院', collapse: '收起 / 展开菜单' },
  status: { live: '实时数据', demo: '演示', demoBanner: '演示模式 — 显示的价格是测试数据，不是真实市场价格。' },
  errors: { timeout: '请求超时', offline: '没有网络连接', parse: '响应无效' },
  profile: { title: '个人资料', sub: '管理你的头像、姓名和密码。', photo: '头像', change: '更换头像', remove: '移除头像', info: '账户', name: '姓名', email: '邮箱', saveName: '保存姓名', nameSaved: '姓名已保存。', via: '登录方式', password: '修改密码', current: '当前密码', next: '新密码', confirm: '确认新密码', updatePassword: '更新密码', passwordSaved: '密码已修改。', saving: '保存中…' },
  pricing: { title: '订阅', sub: '选择你的 AlphaTrade AI 套餐。', plans: { monthly: '月付', quarterly: '3 个月', semiannual: '6 个月', annual: '年付', prime: 'Prime · 年付', apex: 'Apex · 年付', max: 'Max · 年付' }, per: { monthly: '每月', quarterly: '每 3 个月', semiannual: '每 6 个月', annual: '每年', prime: '每年', apex: '每年', max: '每年' }, best: '最超值', subscribe: '订阅', disclaimer: '分析仅供学习，不构成投资建议。' },
  tools: {
    groups: { overview: '概览', ai: 'AI 与信号', analytics: '分析与市场', trading: '交易管理', performance: '业绩与比赛', learning: '学习与策略', community: '支持与社区', account: '账户与钱包', about: '关于平台', owner: '平台管理（所有者）', main: '主要', analysis: '分析与测试', info: '新闻与学习' },
    risk: { title: '风险管理', sub: '根据余额、风险比例和止损计算每笔交易的仓位。' }, journal: { title: '交易日志', sub: '记录交易，跟踪胜率和净利润。' },
    radar: { title: 'Alpha Radar', sub: '扫描所有市场并为机会排序。' }, alerts: { title: '自定义提醒', sub: '价格到达你的价位时手机提醒。' }, lab: { title: '策略实验室', sub: '策略测试的真实结果。' },
  },
});
export default deepMerge(deepMerge(base, b1), b2);
