// «توصية AI» (v234) — ONE source for the section's risk limits, execution rules, order expiry, trading costs and the
// strategy registry (LIVE / PAPER / DISABLED). The page, the engine options it passes and the AI context all read from here,
// so two services can no longer disagree (before v234 the daily loss limit was 1.5 % in one place and 3 % in another).
// Other sections (signals channel, SMC panel, Alpha Radar, EDH) keep their own settings and are not affected.
// Numbers are conservative defaults, NOT optimised values: nothing here was tuned on past results.
import { COSTS } from '../services/smcAssist.js';

export const ENGINE_VERSION = 'ai-signal-2.0 (v234)';

/* ───────── risk (one definition; the user can tighten or loosen within the bounds) ───────── */
export const RISK = {
  dailyLossPct: { def: 3, min: 0.5, max: 10 },       // v321: was 1.5 — with eight strategies saving trades it stopped every new signal for the rest of the day. realised loss today (in % of the account) that stops new signals
  pauseAfterLosses: { def: 2, min: 1, max: 6 },       // consecutive losing results that pause new signals
  maxOpen: { def: 3, min: 1, max: 10 },               // open + pending saved signals in total
  maxOpenRiskPct: 5,                                  // risk of all open signals together (sum of their risk %)
  maxAssetRiskPct: 3,                                 // risk of open signals in one asset class (all crypto coins = one bet)
  maxRiskPct: 5, warnRiskPct: 1,                      // per trade: hard cap (form) and the warning level
  perStrategyPerSymbol: 1,                            // one open trade per strategy on the same market
  pauseHours: 24,                                     // v248: the loss-streak pause ends 24 h after the last of those losses (it never lasted forever)
  maxHoldHours: { scalp: 48, swing: 336 },            // v248: an open saved trade nobody could follow any longer stops counting as open
};
const clampNum = (v, r) => { const n = Number(v); return Number.isFinite(n) ? Math.min(r.max, Math.max(r.min, n)) : r.def; };
/** The user's risk settings, cleaned (anything odd falls back to the default). */
export function riskSettings(p = {}) {
  return { dailyLossPct: Number(p.dailyLossPct) === 1.5 ? RISK.dailyLossPct.def : clampNum(p.dailyLossPct, RISK.dailyLossPct),   // 1.5 was the old default, so a saved 1.5 moves to the new one (any other value the user chose is kept)
    pauseAfterLosses: Math.round(clampNum(p.pauseAfterLosses, RISK.pauseAfterLosses)), maxOpen: Math.round(clampNum(p.maxOpen, RISK.maxOpen)) };
}

/* ───────── trading costs ───────── */
// Commission part of the round-trip cost (the rest of COSTS is the typical spread). Slippage is added separately.
export const COMMISSION_PCT = { crypto: 0.08, forex: 0, metal: 0, index: 0, energy: 0, stock: 0.02 };
export const SLIPPAGE_PCT = { crypto: 0.02, forex: 0.003, metal: 0.01, index: 0.01, energy: 0.02, stock: 0.02 };
/**
 * Round-trip cost in % of price: spread + commission + expected slippage.
 * spreadPct = a real bid/ask spread when the feed gives one, else the typical figure (then `estimated: true`).
 */
export function costModel(asset, spreadPct = null) {
  const a = COSTS[asset] != null ? asset : 'crypto';
  const est = !(Number.isFinite(spreadPct) && spreadPct >= 0);
  const spread = est ? Math.max(0, COSTS[a] - COMMISSION_PCT[a]) : spreadPct;
  const r = (v) => Math.round(v * 10000) / 10000;
  return { spreadPct: r(spread), commissionPct: COMMISSION_PCT[a], slippagePct: SLIPPAGE_PCT[a], totalPct: r(spread + COMMISSION_PCT[a] + SLIPPAGE_PCT[a]), estimated: est };
}

/* ───────── execution: Market vs Limit, per style ───────── */
export const EXEC = {
  // A pending order further than this from the current price is not realistic → WAIT / NO TRADE instead.
  limitMaxAtr: { scalp: 1.5, swing: 3 },
  limitMaxPct: { // and never further than this % of price (per asset class and style)
    crypto: { scalp: 1.2, swing: 5 }, forex: { scalp: 0.25, swing: 1 }, metal: { scalp: 0.6, swing: 2.5 },
    index: { scalp: 0.6, swing: 2.5 }, energy: { scalp: 1, swing: 4 }, stock: { scalp: 1, swing: 4 },
  },
  // A market entry this far from the strategy's own entry level is a chase → not allowed.
  chaseMaxAtr: { scalp: 0.8, swing: 1.1 },   // v314: a little more room to the EMA 20 before a trade counts as chasing (not back-tested)
  // An order quote older than this is not "the current price".
  quoteMaxAgeMs: 120_000,
};

/** Distance of a level from the current price. → { pts, pct, atr } */
export function distanceOf(level, price, atrV, pointSize = 0) {
  const d = Math.abs(level - price);
  return { abs: d, pts: pointSize > 0 ? Math.round((d / pointSize) * 10) / 10 : null, pct: price > 0 ? Math.round((d / price) * 100000) / 1000 : null, atr: atrV > 0 ? Math.round((d / atrV) * 100) / 100 : null };
}
/** Can a pending order at `entry` be reached in a reasonable horizon? → { ok, reason, dist } */
export function limitCheck({ entry, price, atr: a, style = 'scalp', asset = 'crypto', direction }) {
  const dist = distanceOf(entry, price, a);
  const long = direction !== 'short';
  // a buy limit must sit at or below price (a sell limit at or above), otherwise it would fill at once — that is a market entry
  if (long ? entry > price : entry < price) return { ok: false, reason: 'wrong_side', dist };
  const maxAtr = EXEC.limitMaxAtr[style] ?? 2; const maxPct = EXEC.limitMaxPct[asset]?.[style] ?? 2;
  if (dist.atr != null && dist.atr > maxAtr) return { ok: false, reason: 'too_far_atr', dist, maxAtr, maxPct };
  if (dist.pct != null && dist.pct > maxPct) return { ok: false, reason: 'too_far_pct', dist, maxAtr, maxPct };
  return { ok: true, reason: null, dist, maxAtr, maxPct };
}
/** Is a market entry now still the strategy's entry, or a chase? */
export function chaseCheck({ planEntry, live, atr: a, style = 'scalp' }) {
  const dist = distanceOf(planEntry, live, a);
  const max = EXEC.chaseMaxAtr[style] ?? 0.6;
  return { ok: dist.atr == null || dist.atr <= max, dist, max };
}

/* ───────── order expiry (bound to timeframe, volatility, distance and session) ───────── */
export const EXPIRY = {
  maxBars: { '1m': 30, '5m': 24, '15m': 16, '1h': 24, '4h': 12, '1D': 5 },   // hard ceiling per timeframe
  minBars: 3,
  atrPerBar: 0.35,       // assumed average progress of price towards the order per candle (in ATR)
  maxHours: { scalp: 6, swing: 120 },
};
const TF_SEC = { '1m': 60, '5m': 300, '15m': 900, '1h': 3600, '4h': 14400, '1D': 86400 };
/** Next FX-style weekend close (Friday 21:00 UTC) after `sec`. */
export function nextWeekendClose(sec) {
  const d = new Date(sec * 1000); const day = d.getUTCDay();
  const fri = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + ((5 - day + 7) % 7), 21, 0, 0)).getTime() / 1000;
  return fri > sec ? fri : fri + 7 * 86400;
}
/**
 * How long a pending order stays valid. → { bars, validUntil, why }
 * distAtr: distance from price to the order in ATR. session24: true for crypto (no weekend close).
 */
export function orderExpiry({ tf, style = 'scalp', distAtr = 1, createdAt, session24 = false }) {
  const sec = TF_SEC[tf] || 900;
  const need = Math.ceil((Number.isFinite(distAtr) ? distAtr : 1) / EXPIRY.atrPerBar) + 2;
  const cap = Math.min(EXPIRY.maxBars[tf] || 16, Math.floor((EXPIRY.maxHours[style] * 3600) / sec) || 1);
  const bars = Math.max(Math.min(EXPIRY.minBars, cap), Math.min(cap, need));
  let validUntil = createdAt + bars * sec; let why = 'distance';
  if (bars === cap) why = 'cap';
  if (!session24) { const close = nextWeekendClose(createdAt); if (validUntil > close) { validUntil = close; why = 'weekend'; } }
  return { bars, validUntil, why };
}

/* ───────── strategy registry ───────── */
// LIVE: issues recommendations. PAPER: evaluated and tracked on real prices, never a recommendation. DISABLED: not run.
// A PAPER strategy becomes LIVE only by changing this file after it met PROMOTION on enough markets and periods —
// a single back-test on the screen never promotes anything by itself.
export const PROMOTION = { minTestTrades: 30, minExpectancyR: 0.05, minProfitFactor: 1.15, maxTrainTestGapR: 0.5, minPositiveWindows: 0.6 };

const S = (id, status, ar, en, extra = {}) => ({ id, status, name: { ar, en }, ...extra });
export const STRATEGIES = [
  S('smc', 'live', 'سمارت موني (SMC)', 'Smart Money Concepts (SMC)', { kind: 'core', markets: 'all', tfs: 'all',
    logic: ['هيكل الفريم الأعلى + سيولة + منطقة (OB/FVG/Breaker/IFVG) بمنطقة Discount/Premium، مع تأكيدين على الأقل منهم سحب سيولة أو كسر هيكل.', 'Higher-frame structure + liquidity + a zone (OB/FVG/Breaker/IFVG) in discount/premium, with at least two confirmations, one of them a sweep or a structure break.'] }),
  S('trend', 'live', 'تتبّع الاتجاه', 'Trend following', { kind: 'core', markets: 'all', tfs: 'all',
    logic: ['EMA 20/50/200 مرتبة + قمم وقيعان + ADX/RSI/MACD + رجوع لـ EMA وشمعة تأكيد.', 'EMA 20/50/200 aligned + swings + ADX/RSI/MACD + a pullback to the EMAs and a confirmation candle.'] }),
  S('mean_reversion', 'live', 'الارتداد للمتوسط', 'Mean reversion', { kind: 'core', markets: 'all', tfs: 'all',
    logic: ['لمس حد بولينجر ورجوع جوّاه + RSI متطرف وعم يرجع + سوق عرضي (ADX منخفض) وما في اندفاع.', 'Bollinger band touch and close back inside + RSI extreme turning + a ranging market (low ADX) without a displacement candle.'] }),
  // v319 — 'new': issues recommendations on the «توصية AI» page like LIVE, but has no back-test or live record yet (the card says so).
  // Not 'live' on purpose: Alpha Elite and the channel keep using only the three core strategies.
  S('ict', 'new', 'ICT (سيولة ← إزاحة ← FVG)', 'ICT (liquidity → displacement → FVG)', { kind: 'new', markets: 'all', tfs: 'all',
    logic: ['سحب سيولة قمة/قاع مؤكد، ثم كسر هيكل وإزاحة بتترك فجوة، والدخول عند الرجوع للفجوة أو منطقة OTE. مستقلة عن محرك SMC.', 'A sweep of a confirmed swing, then a structure shift and a displacement that leaves a gap; entry on the return to the gap or the OTE zone. Independent of the SMC engine.'] }),
  S('asian_range', 'new', 'اختراق النطاق الآسيوي', 'Asian range breakout', { kind: 'new', markets: 'all', tfs: ['1m', '5m', '15m', '30m', '1h'],
    logic: ['نطاق 00:00–07:00 UTC، ثم إغلاق برا النطاق بين 07:00 و16:00 UTC. الوقف عند نص النطاق.', 'The 00:00–07:00 UTC range, then a close outside it between 07:00 and 16:00 UTC. Stop at the range midpoint.'] }),
  S('fvg', 'new', 'فجوة القيمة العادلة (FVG)', 'Fair value gap (FVG)', { kind: 'new', markets: 'all', tfs: 'all',
    logic: ['فجوة من شمعة اندفاع لسا مفتوحة، السعر رجعلها وطلع بشمعة تفاعل، بجهة EMA 50.', 'An open gap from a displacement candle; price returned into it and left with a reaction candle, on the EMA 50 side.'] }),
  S('patterns', 'new', 'نماذج السعر الكلاسيكية', 'Classic price patterns', { kind: 'new', markets: 'all', tfs: 'all',
    logic: ['قمة/قاع مزدوج أو رأس وكتفين من قمم وقيعان مؤكدة، والدخول بإغلاق ورا خط العنق.', 'Double top / bottom or head & shoulders from confirmed pivots; entry on a close beyond the neckline.'] }),
  S('volume_profile', 'new', 'بروفايل الحجم (POC / VAH / VAL)', 'Volume profile (POC / VAH / VAL)', { kind: 'new', markets: 'real-volume', tfs: 'all',
    logic: ['بروفايل آخر 120 شمعة: رفض عند حد منطقة القيمة (VAL/VAH) والهدف POC ثم الحد المقابل. بس لما المزوّد بيعطي حجم حقيقي.', 'Profile of the last 120 candles: a rejection at the value-area edge (VAL / VAH) targeting the POC, then the opposite edge. Only when the feed gives real volume.'] }),
  S('order_flow', 'new', 'تدفق أوامر المؤسسات (حجم)', 'Institutional order flow (volume)', { kind: 'new', markets: 'real-volume', tfs: 'all',
    logic: ['مناطق السيولة العميقة من بروفايل الحجم (عُقد الحجم العالي): رجوع للمنطقة مع امتصاص (حجم عالي وذيل رفض) ودلتا حجم تقديرية مع الصفقة. من حجم الشموع، مش من دفتر أوامر.', 'Deep-liquidity zones from the volume profile (high-volume nodes): a return to the zone with absorption (high volume, rejection wick) and an estimated volume delta with the trade. From candle volume, not an order book.'] }),
  S('breakout_retest', 'paper', 'اختراق وإعادة اختبار', 'Breakout & retest', { kind: 'paper', markets: 'all', tfs: 'all',
    logic: ['إغلاق فوق/تحت قمة أو قاع 20 شمعة، ثم رجوع للمستوى ورفض، مع زخم.', 'Close beyond the 20-bar high/low, then a retest of the level that holds, with momentum.'] }),
  S('sweep_reversal', 'paper', 'انعكاس بعد سحب السيولة', 'Liquidity sweep reversal', { kind: 'paper', markets: 'all', tfs: 'all',
    logic: ['ذيل فوق/تحت قمة أو قاع مؤكد ثم إغلاق رجوع وكسر أقرب قاع/قمة صغيرة.', 'A wick beyond a confirmed swing, a close back inside and a break of the nearest minor swing.'] }),
  S('vwap', 'paper', 'VWAP (ارتداد / اتجاه)', 'VWAP reversion / trend', { kind: 'paper', markets: 'real-volume', tfs: ['5m', '15m', '1h'],
    logic: ['VWAP يومي وانحرافاته: رجوع من ±2σ بسوق عرضي، أو رجوع لـ VWAP باتجاه. بس على حجم بورصة حقيقي.', 'Daily VWAP and its bands: reversion from ±2σ in a range, or a pullback to VWAP in a trend. Real exchange volume only.'] }),
  S('pdh_pdl', 'paper', 'قمة/قاع اليوم والأسبوع السابق', 'Previous day / week high-low', { kind: 'paper', markets: 'all', tfs: ['5m', '15m', '1h'],
    logic: ['اختراق أو رفض لمستوى PDH/PDL/PWH/PWL بإغلاق مؤكد، مش مجرد لمس.', 'A confirmed close-based break or rejection of PDH/PDL/PWH/PWL, not a mere touch.'] }),
  S('orb', 'paper', 'اختراق نطاق الافتتاح', 'Opening range breakout', { kind: 'paper', markets: 'all', tfs: ['5m', '15m'],
    logic: ['نطاق أول 30 دقيقة من الجلسة (لندن/نيويورك/اليوم للكريبتو)، ثم إغلاق برا النطاق.', 'The first 30 minutes of the session (London / New York / UTC day for crypto), then a close outside the range.'] }),
  S('donchian', 'paper', 'قناة دونشيان (السلاحف)', 'Donchian / Turtle breakout', { kind: 'paper', markets: 'all', tfs: ['1h', '4h', '1D'],
    logic: ['إغلاق فوق أعلى 20 شمعة (أو تحت أدنى 20) مع فلتر تقلب، ووقف 2 ATR.', 'Close above the 20-bar high (or below the low) with a volatility filter, 2 ATR stop.'] }),
  S('squeeze', 'paper', 'انضغاط كيلتنر', 'Keltner squeeze momentum', { kind: 'paper', markets: 'all', tfs: 'all',
    logic: ['بولينجر جوّا كيلتنر (انضغاط) ثم خروج مع زخم باتجاه EMA 50.', 'Bollinger inside Keltner (squeeze), then a release with momentum in the EMA 50 direction.'] }),
  S('ichimoku', 'paper', 'إيشيموكو', 'Ichimoku', { kind: 'paper', markets: 'all', tfs: ['1h', '4h', '1D'],
    logic: ['السعر فوق/تحت السحابة + تقاطع Tenkan/Kijun بنفس الاتجاه. إعدادات 9/26/52 بدون معايرة.', 'Price above/below the cloud + Tenkan/Kijun cross the same way. 9/26/52, not calibrated.'] }),
  S('divergence', 'paper', 'دايفرجنس RSI', 'RSI divergence', { kind: 'paper', markets: 'all', tfs: 'all',
    logic: ['دايفرجنس عادي بين آخر قاعين/قمتين مؤكدين (بعد 3 شموع) ثم شمعة تأكيد.', 'Regular divergence between the last two confirmed pivots (3 bars later), then a confirmation candle.'] }),
  S('sr_rejection', 'paper', 'رفض الدعم والمقاومة', 'Support / resistance rejection', { kind: 'paper', markets: 'all', tfs: 'all',
    logic: ['مستوى انلمس 3 مرات على الأقل (قمم/قيعان مؤكدة)، ثم ذيل رفض وإغلاق بعيد عنه.', 'A level touched at least 3 times (confirmed swings), then a rejection wick and a close away from it.'] }),
  S('zscore', 'paper', 'نطاق إحصائي (Z-Score)', 'Statistical range (Z-score)', { kind: 'paper', markets: 'all', tfs: 'all',
    logic: ['Z-score للسعر عن متوسط 50 أبعد من ±2 وعم يرجع، بس لما المتوسط شبه مستقر.', 'Price Z-score vs the 50-bar mean beyond ±2 and turning, only when the mean is nearly flat.'] }),
  S('session_momentum', 'paper', 'زخم الجلسة', 'Session momentum', { kind: 'paper', markets: 'sessions', tfs: ['5m', '15m'],
    logic: ['أول ساعة من لندن/نيويورك: شمعة اندفاع باتجاه EMA 50 وفوق متوسط المدى.', 'First hour of London / New York: a displacement candle in the EMA 50 direction, above the average range.'] }),
  S('volume_momentum', 'paper', 'زخم الحجم', 'Volume momentum', { kind: 'paper', markets: 'real-volume', tfs: 'all',
    logic: ['حجم بورصة حقيقي ≥ 2× متوسط 20 مع إغلاق قوي باتجاه EMA 50. بس Binance.', 'Real exchange volume ≥ 2× its 20-bar average with a strong close in the EMA 50 direction. Binance only.'] }),
  S('fib_ote', 'disabled', 'فيبوناتشي / OTE لحاله', 'Fibonacci / OTE (standalone)', { kind: 'disabled',
    why: ['OTE موجود كعامل تأكيد جوّا SMC. كإشارة منفردة ممنوع بالمواصفات.', 'OTE is a confirmation factor inside SMC; as a standalone signal it is not allowed.'] }),
  S('bos_choch', 'disabled', 'هيكل BOS/CHoCH مستقل', 'Standalone BOS / CHoCH', { kind: 'disabled',
    why: ['نفس إشارات SMC باسم تاني — تكرار.', 'The same signals as SMC under another name — a duplicate.'] }),
  S('lstm', 'disabled', 'تعلّم عميق (LSTM)', 'LSTM / deep learning', { kind: 'disabled',
    why: ['ما في نموذج مدرّب ومتحقق منه (خارج العينة / walk-forward). ما بيدخل بالقرار.', 'No trained, validated model (out-of-sample / walk-forward). Never part of the decision.'] }),
];
export const strategyOf = (id) => STRATEGIES.find((s) => s.id === id) || null;
export const statusOf = (id) => strategyOf(id)?.status || 'disabled';

/** Confidence tier from the setup quality score (0-100, NOT a win probability): scales the risked amount, never above the user's own limit. */
export function confidenceTier(q) {
  const v = Number(q);
  if (!Number.isFinite(v)) return { tier: 'low', mult: 0.5 };
  return v >= 75 ? { tier: 'high', mult: 1 } : v >= 60 ? { tier: 'medium', mult: 0.75 } : { tier: 'low', mult: 0.5 };
}
