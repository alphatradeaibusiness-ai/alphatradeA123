// What each subscription includes. Every plan gets the same core platform; longer plans add depth,
// automation and a bigger monthly allowance of deep AI analyses (LLM calls: screenshot analysis and
// the AI assistant). The built-in local analysis engine is unlimited on every plan.
//
// IMPORTANT: this site is static, so a plan can only be *enforced* once a backend confirms payments.
// Until then enforcement is OFF (VITE_ENFORCE_PLANS unset): everyone gets the top plan, nothing is
// locked, and the counters only show usage. When you add the backend, set VITE_ENFORCE_PLANS=true
// and have it write the user's plan with setPlan() (and keep the real AI counter server-side —
// anything stored in the browser can be edited by the user).
import { readBool, readEnv } from './env.js';
import { storage } from '../utils/storage.js';
import { CHANNEL_PLANS } from './channelPlans.js';

export let ENFORCE = readBool('VITE_ENFORCE_PLANS', false);
/** v297: the server says whether plans are enforced (ENFORCE_PLANS=1 on Render), so no rebuild is needed to switch it on. */
export const setEnforce = (v) => { ENFORCE = Boolean(v); };
export const PLAN_ORDER = ['monthly', 'quarterly', 'semiannual', 'annual', 'prime', 'apex', 'max'];

export const TIERS = {
  free: { rank: 0, name: 'free', aiPerMonth: 0, aiCarryMonths: 0, alerts: 3, signalsPerMonth: 0 },   // no paid plan (only when plans are enforced)
  channel: { rank: 0, name: 'channel', aiPerMonth: 0, aiCarryMonths: 0, alerts: 5, signalsPerMonth: 30 },
  monthly: { rank: 1, name: 'trader', aiPerMonth: 30, aiCarryMonths: 0, alerts: 5, signalsPerMonth: CHANNEL_PLANS.monthly.quota },
  quarterly: { rank: 2, name: 'pro', aiPerMonth: 60, aiCarryMonths: 1, alerts: 25, signalsPerMonth: CHANNEL_PLANS.quarterly.quota },
  semiannual: { rank: 3, name: 'elite', aiPerMonth: 100, aiCarryMonths: 1, alerts: 100, signalsPerMonth: CHANNEL_PLANS.semiannual.quota },
  annual: { rank: 4, name: 'institutional', aiPerMonth: 150, aiCarryMonths: 2, alerts: 0, signalsPerMonth: CHANNEL_PLANS.annual.quota },
  // v276 premium yearly plans (defaults — the owner can change prices from the plans admin page)
  prime: { rank: 5, name: 'prime', aiPerMonth: 200, aiCarryMonths: 2, alerts: 0, signalsPerMonth: CHANNEL_PLANS.prime.quota },
  apex: { rank: 6, name: 'apex', aiPerMonth: 300, aiCarryMonths: 2, alerts: 0, signalsPerMonth: CHANNEL_PLANS.apex.quota },
  max: { rank: 7, name: 'max', aiPerMonth: 500, aiCarryMonths: 3, alerts: 0, signalsPerMonth: CHANNEL_PLANS.max.quota },
};
// v276: the lowest plan that opens each side-menu page. Pages not listed are in every plan.
// Alpha Elite Signals and the EDH pages are deliberately NOT listed (their access rules are not changed).
export const NAV_RANK = { radar: 2, alerts: 2, contest: 2, lab: 3, mentors: 3, mt5: 4, studio: 5, council: 6, liquidity: 7 };
// v297: "Free Trading" (no paid plan, or only the signal channel) opens ONLY the signal channel and the AI recommendations,
// plus the account pages a person needs to buy a plan, read the rules and sign out. Alpha Elite Signals keeps its own access rules (unchanged).
export const FREE_PAGES = new Set(['signals', 'ai-signal', 'elite', 'nova', 'pricing', 'billing', 'profile', 'legal', 'trust', 'connect']);
export const navPlan = (id) => (NAV_RANK[id] ? PLAN_ORDER.find((p) => TIERS[p].rank >= NAV_RANK[id]) : null);
export const lockPlan = (id) => navPlan(id) || 'monthly';   // the plan named on a locked page (the cheapest one for pages every paid plan opens)
export const canNav = (id) => (rank() > 0 ? rank() >= (NAV_RANK[id] || 0) : FREE_PAGES.has(id));

// Minimum rank that unlocks each feature.
export const FEATURE_RANK = {
  frvp: 2, // fixed-range volume profile
  strategies: 2, // SMC v2 + Zone strategy
  radarFull: 2, // all Alpha Radar tools (plan 1: volatility, liquidity, opportunities)
  autotest: 2, // automatic optimisation / backtest lab
  derivGuard: 2,
  quant: 3, // loss analysis, regime learning, quant layer
  multiScreen: 3,
  earlyAccess: 4,
};
// Radar / hub tabs and what they need.
export const TAB_FEATURE = { 'radar-levels': 'radarFull', 'radar-corr': 'radarFull', 'radar-rules': 'radarFull', autotest: 'autotest', walkforward: 'autotest', 'radar-multi': 'multiScreen' };

let verifiedPlan=null;
export const setVerifiedPlan = id => { verifiedPlan=TIERS[id]?id:null; };
export function currentPlan() {
  if (verifiedPlan) return verifiedPlan;
  if (!ENFORCE) return PLAN_ORDER[PLAN_ORDER.length - 1];   // not enforced: everyone has the top plan, nothing is locked
  // enforced: only the plan the server confirmed counts (a plan written in browser storage could be edited by anyone)
  const d = readEnv('VITE_DEFAULT_PLAN', '');
  return TIERS[d] ? d : 'free';
}
/** Called by the backend/billing integration once a payment is confirmed. */
export function setPlan(id, until = null) { if (TIERS[id]) storage.set('plan', { id, until }); }

export const tier = () => TIERS[currentPlan()];
export const rank = () => tier().rank;
export const can = (feature) => rank() >= (FEATURE_RANK[feature] ?? 1);
export const planFor = (feature) => PLAN_ORDER.find((id) => TIERS[id].rank >= (FEATURE_RANK[feature] ?? 1));
export const canTab = (tabId) => !TAB_FEATURE[tabId] || can(TAB_FEATURE[tabId]);
export const limit = (key) => tier()[key];

/* ───────── AI allowance ───────── */
const monthKey = (d = new Date()) => `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
const prevKey = () => { const d = new Date(); d.setUTCMonth(d.getUTCMonth() - 1, 1); return monthKey(d); };

export function aiUsage() { return storage.get('ai-usage', {}); }
/** Allowance this month = plan quota + unused part of last month (capped by the plan's carry-over). */
export function aiAllowance(now = new Date()) {
  const t = tier();
  const u = aiUsage();
  const left = Math.max(0, t.aiPerMonth - (u[prevKey()] || 0));
  const carry = Math.min(left, t.aiPerMonth * t.aiCarryMonths);
  return { quota: t.aiPerMonth, carry, total: t.aiPerMonth + carry, used: u[monthKey(now)] || 0 };
}
export function aiRemaining() { const a = aiAllowance(); return Math.max(0, a.total - a.used); }
/** Count one deep AI analysis. Returns false (and counts nothing) when the allowance is used up and enforcement is on. */
export function consumeAi() {
  if (ENFORCE && aiRemaining() <= 0) return false;
  const u = aiUsage();
  const k = monthKey();
  u[k] = (u[k] || 0) + 1;
  // keep only the last 3 months
  for (const key of Object.keys(u).sort().slice(0, -3)) delete u[key];
  storage.set('ai-usage', u);
  return true;
}
