// v333: artwork and line icons for the Alpha AI page. Original vector art (drawn for AlphaTrade AI), no external images.
const s = (d, extra = '') => `<svg viewBox="0 0 24 24" aria-hidden="true" ${extra}>${d}</svg>`;

export const AX_ICONS = {
  target: s('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>'),
  headset: s('<path d="M4 14v-2a8 8 0 0116 0v2"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/><path d="M19 20a3 3 0 01-3 2h-3"/>'),
  bars: s('<path d="M4 20h16"/><rect x="5" y="12" width="3" height="6" rx=".8"/><rect x="10.5" y="8" width="3" height="10" rx=".8"/><rect x="16" y="4" width="3" height="14" rx=".8"/>'),
  rsi: s('<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/><text x="12" y="13.2" text-anchor="middle" font-size="6.2" font-weight="700" fill="currentColor" stroke="none" font-family="Inter, sans-serif">RSI</text>'),
  candles: s('<path d="M6 3v4M6 15v6M12 2v5M12 13v8M18 4v5M18 16v4"/><rect x="4" y="7" width="4" height="8" rx="1"/><rect x="10" y="7" width="4" height="6" rx="1"/><rect x="16" y="9" width="4" height="7" rx="1"/>'),
  alert: s('<path d="M12 3l9.5 17h-19z"/><path d="M12 10v4.5M12 17.4v.1"/>'),
  settings: s('<circle cx="12" cy="12" r="3"/><path d="M12 2.5l1.6 2.4 2.8-.7.7 2.8 2.4 1.6-1.3 2.6 1.3 2.6-2.4 1.6-.7 2.8-2.8-.7L12 21.5l-1.6-2.4-2.8.7-.7-2.8-2.4-1.6 1.3-2.6-1.3-2.6 2.4-1.6.7-2.8 2.8.7z"/>'),
  sliders: s('<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>'),
  clip: s('<path d="M20 11.5l-7.8 7.8a5 5 0 01-7.1-7.1l8.5-8.5a3.3 3.3 0 014.7 4.7l-8.5 8.5a1.7 1.7 0 01-2.4-2.4l7.8-7.8"/>'),
  chip: s('<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/><text x="12" y="14.3" text-anchor="middle" font-size="6" font-weight="800" fill="currentColor" stroke="none" font-family="Inter, sans-serif">AI</text>'),
  growth: s('<path d="M4 20h16"/><rect x="5" y="14" width="3" height="4" rx=".6"/><rect x="10.5" y="11" width="3" height="7" rx=".6"/><rect x="16" y="8" width="3" height="10" rx=".6"/><path d="M4 11l5-4 4 2 7-6M16 3h4v4"/>'),
  bolt: s('<path d="M13 2L4.5 13.5H11L10 22l8.5-11.5H12z"/>'),
  shieldBell: s('<path d="M12 2.5l8 3v6c0 5-3.4 8.6-8 10-4.6-1.4-8-5-8-10v-6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>'),
};

/* Hero: a cyber-knight bust (left), transparent candles and digital waves behind the title. */
export const HERO_ART = `<div class="ax-art" aria-hidden="true">
<svg class="ax-bg" viewBox="0 0 900 300" preserveAspectRatio="none">
  <defs><linearGradient id="axw" x1="0" x2="1"><stop offset="0" stop-color="#c000ff" stop-opacity="0"/><stop offset=".5" stop-color="#c000ff" stop-opacity=".55"/><stop offset="1" stop-color="#ec4dff" stop-opacity="0"/></linearGradient></defs>
  <g fill="none" stroke="url(#axw)" stroke-width="1.4">
    <path d="M0 230 C150 180 260 280 420 220 S700 170 900 220"/><path d="M0 245 C160 200 280 290 440 238 S720 190 900 238" opacity=".6"/><path d="M0 260 C170 220 300 300 460 256 S740 210 900 256" opacity=".35"/>
  </g>
  <g fill="#c000ff" opacity=".22">
    <rect x="720" y="120" width="8" height="40" rx="2"/><rect x="723" y="108" width="2" height="64"/><rect x="742" y="100" width="8" height="48" rx="2"/><rect x="745" y="88" width="2" height="72"/>
    <rect x="764" y="84" width="8" height="38" rx="2"/><rect x="767" y="70" width="2" height="62"/><rect x="786" y="60" width="8" height="46" rx="2"/><rect x="789" y="46" width="2" height="72"/>
    <rect x="808" y="72" width="8" height="30" rx="2"/><rect x="811" y="60" width="2" height="54"/><rect x="830" y="40" width="8" height="50" rx="2"/><rect x="833" y="26" width="2" height="76"/>
  </g>
</svg>
<svg class="ax-figure" viewBox="0 0 320 300">
  <defs>
    <linearGradient id="axa" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3a1466"/><stop offset=".55" stop-color="#1a0833"/><stop offset="1" stop-color="#0b0316"/></linearGradient>
    <linearGradient id="axr" x1="1" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f3c6ff"/><stop offset=".35" stop-color="#c000ff"/><stop offset="1" stop-color="#5a0fa8" stop-opacity="0"/></linearGradient>
    <radialGradient id="axg" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#c000ff" stop-opacity=".55"/><stop offset="1" stop-color="#c000ff" stop-opacity="0"/></radialGradient>
    <linearGradient id="axv" x1="0" x2="1"><stop offset="0" stop-color="#7b5cff"/><stop offset="1" stop-color="#f5d0ff"/></linearGradient>
  </defs>
  <circle cx="168" cy="118" r="120" fill="url(#axg)"/>
  <path d="M60 128 A112 112 0 0 1 230 30" fill="none" stroke="#d27bff" stroke-width="3" stroke-linecap="round" opacity=".9"/>
  <path d="M52 150 A120 120 0 0 1 70 80" fill="none" stroke="#ec4dff" stroke-width="1.5" stroke-linecap="round" opacity=".6"/>
  <!-- shoulders and chest -->
  <path d="M18 300 C24 238 54 206 104 194 L150 184 L214 190 C262 200 292 232 302 300 Z" fill="url(#axa)"/>
  <path d="M30 300 C40 250 66 224 108 212 L126 236 C94 248 72 270 66 300 Z" fill="#240b46"/>
  <path d="M290 300 C282 254 258 226 220 212 L202 238 C232 250 252 272 258 300 Z" fill="#240b46"/>
  <path d="M104 194 C86 186 66 190 48 206 C70 202 90 206 108 214 Z" fill="#5d1fa8" opacity=".85"/>
  <path d="M214 190 C236 182 260 186 278 202 C256 198 234 202 212 212 Z" fill="#7a2bd6"/>
  <path d="M120 212 L160 200 L200 212 L190 268 L160 284 L130 268 Z" fill="#14062a" stroke="#9b3bff" stroke-width="1.2" opacity=".95"/>
  <path d="M160 222 L142 262 H150 L154 252 H166 L170 262 H178 Z M157 244 L160 236 L163 244 Z" fill="#e7b6ff"/>
  <!-- neck -->
  <path d="M138 168 L182 168 L186 196 L134 196 Z" fill="#12052a"/>
  <path d="M140 176 H180 M139 184 H181" stroke="#6d2bc4" stroke-width="2"/>
  <!-- helmet -->
  <path d="M108 112 C104 70 128 36 170 32 C206 30 232 52 238 84 L246 108 L232 116 L236 140 C230 160 214 174 190 178 L132 176 C116 164 108 140 108 112 Z" fill="url(#axa)"/>
  <path d="M170 32 C206 30 232 52 238 84 L246 108 L232 116 C230 90 214 60 182 50 Z" fill="url(#axr)" opacity=".7"/>
  <path d="M120 70 C96 46 74 34 40 30 C66 44 84 60 100 86 Z" fill="#2c0d55"/>
  <path d="M126 60 C108 30 92 14 66 4 C86 24 100 44 108 72 Z" fill="#3a1170"/>
  <path d="M120 70 C96 46 74 34 40 30" fill="none" stroke="#c77dff" stroke-width="1.5" opacity=".8"/>
  <path d="M146 40 C150 26 160 16 172 10 C168 22 168 30 172 38 Z" fill="#5a1aa6"/>
  <!-- visor -->
  <path d="M168 104 L240 98 L238 112 L170 118 Z" fill="#0b0316"/>
  <path d="M176 107 L236 102" stroke="url(#axv)" stroke-width="4" stroke-linecap="round"/>
  <circle cx="226" cy="103" r="6" fill="#f0d8ff" opacity=".9"/><circle cx="226" cy="103" r="14" fill="#c000ff" opacity=".35"/>
  <path d="M176 128 L230 124 L222 150 L182 156 Z" fill="#160630" stroke="#7a2bd6" stroke-width="1"/>
  <path d="M188 134 L218 132 M190 142 L214 140" stroke="#9b3bff" stroke-width="1.6"/>
  <path d="M124 96 C130 84 144 76 160 76" fill="none" stroke="#a24cff" stroke-width="1.5" opacity=".7"/>
  <path d="M116 132 C126 150 140 160 158 164" fill="none" stroke="#5d1fa8" stroke-width="2"/>
</svg></div>`;

/* Bottom: a glowing wire-mesh wave. */
export const WAVE_ART = `<svg class="ax-wave" viewBox="0 0 900 90" preserveAspectRatio="none" aria-hidden="true">
  <defs><linearGradient id="axm" x1="0" x2="1"><stop offset="0" stop-color="#8000ff" stop-opacity=".1"/><stop offset=".5" stop-color="#c000ff" stop-opacity=".9"/><stop offset="1" stop-color="#ec4dff" stop-opacity=".15"/></linearGradient></defs>
  <g fill="none" stroke="url(#axm)" stroke-width="1">
    ${Array.from({ length: 9 }, (_, i) => `<path d="M0 ${80 - i * 2} C150 ${70 - i * 6} 250 ${30 + i * 2} 450 ${50 - i * 4} S750 ${80 - i * 5} 900 ${60 - i * 3}" opacity="${(0.25 + i * 0.08).toFixed(2)}"/>`).join('')}
    ${Array.from({ length: 30 }, (_, i) => `<path d="M${i * 31} 90 L${i * 31 + 8} 30" opacity=".18"/>`).join('')}
  </g></svg>`;
