// v250 — hidden adaptive learning engine (no UI). It learns ONLY from closed outcomes of the regular recommendations
// (the multi-strategy engine: trend / mean reversion / SMC — the channel's engine trades and the «توصية AI» trades the user
// saved, managed by the smart trade management: a third at each target, stop to entry after TP1). Alpha Elite Signals, EDH
// and LBR never feed it and are never affected by it.
//
// 1. Diagnose every closed outcome: TP3, TP2/TP1 then back to entry (BE), stop before TP1, quick stop, expired…
// 2. Find REPEATING error patterns: per strategy, every context feature and every pair of features is compared with the rest
//    of that strategy's outcomes (Welch t-test, one-sided), with a false-discovery-rate control (Benjamini–Hochberg, q = 10 %)
//    across all groups, a minimum sample, a minimum effect and a negative expectancy. One trade can never create a pattern.
// 3. Propose bounded weights: a strategy weight in [0.8, 1.2] from its shrunk expectancy (moved at most 0.05 per update) and a
//    context penalty in [0.75, 1] for each confirmed pattern. The weight only ever ranks trades, raises the required reward-to-
//    risk a little (≤ +0.3) or — below 0.8 — skips that context. It never loosens a strategy's own rules.
// 4. Validate before anything is used (shadow mode): the candidate is fitted on the older 70 % and must not be worse on the newer
//    30 % (out of sample) nor in a 3-fold walk-forward, keeping at least half of the trades; an optional back-test hook can
//    veto it. Then it runs in SHADOW on the next real outcomes (recording what it would have done, changing nothing) and is
//    promoted only if the trades it would have kept did at least as well as all trades. Otherwise it is discarded.
// Everything is kept in this browser's / the worker's own storage, with an internal log. Pure functions are exported for tests.
import { storage } from '../utils/storage.js';

export const AL = {
  strategies: ['trend', 'mean_reversion', 'smc', 'ict', 'asian_range', 'fvg', 'patterns', 'volume_profile', 'order_flow'],
  minStrategyN: 30,        // a strategy weight moves only with ≥ 30 closed outcomes
  minGroupN: 20,           // a pattern needs ≥ 20 outcomes in its group (pairs: 25)
  minPairN: 25,
  minEffectR: 0.2,         // and to be ≥ 0.2 R worse than the rest of the strategy
  fdrQ: 0.1,               // Benjamini–Hochberg false-discovery rate
  weightMin: 0.8, weightMax: 1.2, weightStep: 0.05, shrinkK: 20,
  penaltyMin: 0.75,
  skipBelow: 0.8,          // effective weight below this → that context is skipped
  rrAddMax: 0.3,
  refitEvery: 10,          // a new candidate is fitted after every 10 new outcomes
  oosShare: 0.3, minOosN: 15, minKeepShare: 0.5,
  shadowMinN: 20, shadowMaxN: 60,
  windowN: 300, windowDays: 120,   // fitted on the recent past only (markets change)
  penaltyDays: 30,                 // a live penalty expires after 30 days unless the recent data confirms it again
  keep: 1000,
};
const KEY = 'adaptive-v1';

/* ───────── 1. diagnosis of one closed outcome ───────── */
/** o: { r, hits?, status?, durMs?, tfSec? } → reason code */
export function diagnose(o) {
  const hits = Number(o.hits) || 0; const bars = o.durMs && o.tfSec ? o.durMs / (o.tfSec * 1000) : null;
  if (o.status === 'tp3' || hits >= 3) return 'full_target';
  if (hits >= 1 && o.r <= 0.35) return 'gave_back_after_tp';
  if (hits >= 1) return 'partial_target';
  if (o.status === 'expired' || o.status === 'result_flat') return o.r < 0 ? 'expired_loss' : 'expired_flat';
  if (o.r < 0 && bars != null && bars <= 3) return 'quick_stop';
  if (o.r < 0) return 'stop_before_tp1';
  return o.r > 0 ? 'win_other' : 'flat';
}

/* ───────── statistics ───────── */
const mean = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0);
const variance = (a) => { if (a.length < 2) return 0; const m = mean(a); return a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1); };
// standard normal CDF (Abramowitz–Stegun 7.1.26)
export function normCdf(z) { const t = 1 / (1 + 0.3275911 * Math.abs(z) / Math.SQRT2); const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-(z * z) / 2); return z >= 0 ? (1 + y) / 2 : (1 - y) / 2; }
/** One-sided p-value that group a has a LOWER mean than group b (Welch). */
export function pLower(a, b) {
  if (a.length < 2 || b.length < 2) return 1;
  const se = Math.sqrt(variance(a) / a.length + variance(b) / b.length);
  if (!(se > 0)) return mean(a) < mean(b) ? 0 : 1;
  return normCdf((mean(a) - mean(b)) / se);
}
/** Benjamini–Hochberg: indices of the tests that stay significant at false-discovery rate q. */
export function bh(ps, q = AL.fdrQ) {
  const idx = ps.map((p, i) => [p, i]).sort((x, y) => x[0] - y[0]); let k = -1;
  idx.forEach(([p], j) => { if (p <= ((j + 1) / idx.length) * q) k = j; });
  return new Set(idx.slice(0, k + 1).map(([, i]) => i));
}

/* ───────── 2. repeating error patterns ───────── */
const keysOf = (o) => {
  const f = (o.features || []).filter((x) => !x.startsWith('market=')).sort();   // single markets are too thin; pairs cover them
  const pairs = []; for (let i = 0; i < f.length; i++) for (let j = i + 1; j < f.length; j++) pairs.push(`${f[i]}&${f[j]}`);
  return [...f, ...(o.features || []).filter((x) => x.startsWith('market=')), ...pairs];
};
/** → [{ strategy, key, n, mean, base, effect, p, reason, reasonShare }] (only patterns that survive the FDR control) */
export function findPatterns(outcomes) {
  const tests = [];
  for (const st of AL.strategies) {
    const mine = outcomes.filter((o) => o.strategy === st && Number.isFinite(o.r));
    if (mine.length < AL.minGroupN * 2) continue;
    const groups = new Map();
    for (const o of mine) for (const k of keysOf(o)) { if (!groups.has(k)) groups.set(k, []); groups.get(k).push(o); }
    for (const [k, g] of groups) {
      const need = k.includes('&') ? AL.minPairN : AL.minGroupN;
      if (g.length < need || mine.length - g.length < need) continue;
      const set = new Set(g); const rest = mine.filter((o) => !set.has(o));
      const gr = g.map((o) => o.r); const rr = rest.map((o) => o.r);
      const effect = mean(rr) - mean(gr);
      const losses = g.filter((o) => o.r < 0); const why = {};
      for (const o of losses) { const d = o.reason || diagnose(o); why[d] = (why[d] || 0) + 1; }
      const top = Object.entries(why).sort((a, b) => b[1] - a[1])[0] || [null, 0];
      tests.push({ strategy: st, key: k, n: g.length, mean: +mean(gr).toFixed(3), base: +mean(rr).toFixed(3), effect: +effect.toFixed(3), p: pLower(gr, rr), reason: top[0], reasonShare: losses.length ? +(top[1] / losses.length).toFixed(2) : 0 });
    }
  }
  const sig = bh(tests.map((t) => t.p));
  return tests.filter((t, i) => sig.has(i) && t.effect >= AL.minEffectR && t.mean < 0).sort((a, b) => a.p - b.p);
}

/* ───────── 3. bounded weights ───────── */
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
/** A model from a list of outcomes, moved from `prev` at most one step. → { weights, penalties, n, at } */
export function recentWindow(outcomes, now = Date.now()) {
  return [...outcomes].sort((a, b) => b.at - a.at).filter((o) => now - o.at <= AL.windowDays * 86_400_000).slice(0, AL.windowN).sort((a, b) => a.at - b.at);
}
export function fitModel(outcomes, prev = null, now = Date.now()) {
  const weights = {};
  for (const st of AL.strategies) {
    const rs = outcomes.filter((o) => o.strategy === st && Number.isFinite(o.r)).map((o) => o.r);
    const cur = Number(prev?.weights?.[st]) || 1;
    if (rs.length < AL.minStrategyN) { weights[st] = cur; continue; }
    const shrunk = rs.reduce((s, x) => s + x, 0) / (rs.length + AL.shrinkK);   // pulled towards 0 R (no edge)
    const target = clamp(1 + 0.5 * shrunk, AL.weightMin, AL.weightMax);
    weights[st] = +clamp(target, cur - AL.weightStep, cur + AL.weightStep).toFixed(3);
  }
  const penalties = {};
  for (const p of findPatterns(outcomes)) {
    const m = clamp(1 - p.effect * 0.5, AL.penaltyMin, 1);
    penalties[`${p.strategy}|${p.key}`] = { m: +m.toFixed(3), n: p.n, mean: p.mean, base: p.base, p: +p.p.toFixed(4), reason: p.reason, reasonShare: p.reasonShare, since: now };
  }
  return { weights, penalties, n: outcomes.length, at: now };
}
/** Effective weight of one trade under a model. features: the trade's context keys (learning.featuresOf). */
export function weightFor(model, strategy, features = []) {
  if (!model || !AL.strategies.includes(strategy)) return { w: 1, hits: [] };
  let w = Number(model.weights?.[strategy]) || 1; const hits = [];
  const keys = keysOf({ features });
  for (const k of keys) { const p = model.penalties?.[`${strategy}|${k}`]; if (p) { hits.push(k); w *= p.m; } }
  return { w: clamp(w, 0.5, AL.weightMax), hits };
}
/** The decision for one trade → { ok, w, rrAdd, why? } */
export function decide(model, strategy, features, rr = null, baseRR = 0) {
  const { w, hits } = weightFor(model, strategy, features);
  if (w < AL.skipBelow) return { ok: false, w, rrAdd: 0, why: 'pattern', pattern: hits[0] || null };
  const rrAdd = w < 1 ? +Math.min(AL.rrAddMax, (1 - w) * 1.5).toFixed(2) : 0;
  if (rrAdd > 0 && Number.isFinite(rr) && rr < baseRR + rrAdd) return { ok: false, w, rrAdd, why: 'rr', need: +(baseRR + rrAdd).toFixed(2) };
  return { ok: true, w, rrAdd };
}

/* ───────── 4. validation ───────── */
/** Replays outcomes under a model: kept vs all. */
export function replay(model, outcomes) {
  const kept = outcomes.filter((o) => decide(model, o.strategy, o.features, Number.isFinite(o.rr) ? o.rr : null, Number(o.baseRR) || 0).ok);
  return { all: { n: outcomes.length, mean: mean(outcomes.map((o) => o.r)) }, kept: { n: kept.length, mean: mean(kept.map((o) => o.r)) } };
}
/**
 * Out-of-sample + walk-forward check of a candidate (fitted only on data before each test window).
 * → { pass, reasons[], oos, folds[], backtest? }
 */
export function validate(outcomes, prev = null, { backtest = null, now = Date.now() } = {}) {
  const sorted = [...outcomes].sort((a, b) => a.at - b.at); const reasons = [];
  const cut = Math.floor(sorted.length * (1 - AL.oosShare));
  const train = sorted.slice(0, cut), test = sorted.slice(cut);
  if (test.length < AL.minOosN) return { pass: false, reasons: ['oos_too_small'], oos: null, folds: [] };
  const m = fitModel(train, prev, now); const oos = replay(m, test);
  const noFilter = oos.kept.n === oos.all.n;
  if (!noFilter) {
    // the trades the candidate would skip must really lose OUT OF SAMPLE, and enough of them to tell
    const skipped = test.filter((o) => !decide(m, o.strategy, o.features, Number.isFinite(o.rr) ? o.rr : null, Number(o.baseRR) || 0).ok);
    const sm = mean(skipped.map((o) => o.r));
    if (skipped.length < 5) reasons.push('oos_no_evidence');
    else if (sm >= 0) reasons.push('oos_skipped_were_winners');
    if (oos.kept.mean < oos.all.mean + 0.02) reasons.push('oos_worse');
  }
  if (oos.kept.n < oos.all.n * AL.minKeepShare) reasons.push('oos_keeps_too_few');
  const folds = [];
  for (let f = 1; f <= 3; f++) {
    const a = Math.floor((sorted.length * (f + 1)) / 5), b = Math.floor((sorted.length * (f + 2)) / 5);
    const tr = sorted.slice(0, a), te = sorted.slice(a, b); if (te.length < 5) continue;
    const r = replay(fitModel(tr, prev, now), te); folds.push({ n: te.length, all: +r.all.mean.toFixed(3), kept: +r.kept.mean.toFixed(3), keptN: r.kept.n });
  }
  const worse = folds.filter((x) => x.keptN < x.n && x.kept < x.all).length;
  if (folds.length >= 2 && worse > folds.length / 2) reasons.push('walk_forward_worse');
  let bt = null;
  if (typeof backtest === 'function') { try { bt = backtest(fitModel(sorted, prev, now)); if (bt && bt.pass === false) reasons.push('backtest_worse'); } catch { reasons.push('backtest_error'); } }
  return { pass: reasons.length === 0, reasons, oos: { n: test.length, all: +oos.all.mean.toFixed(3), kept: +oos.kept.mean.toFixed(3), keptN: oos.kept.n }, folds, backtest: bt };
}

/* ───────── 5. lifecycle: observe → candidate → shadow → active ───────── */
const empty = () => ({ outcomes: [], seen: [], active: null, candidate: null, sinceFit: 0, log: [] });
export const adaptiveState = () => { const s = storage.get(KEY, null); return s && Array.isArray(s.outcomes) ? s : empty(); };
const save = (s) => storage.set(KEY, s);
const logIt = (s, e) => { s.log = [{ at: Date.now(), ...e }, ...(s.log || [])].slice(0, 200); };

/**
 * Pure step: one new closed outcome → the next state (shadow bookkeeping, refits, promotions). `opts.backtest` optional.
 * o: { id, strategy, r, at, features, hits?, status?, durMs?, tfSec?, rr?, baseRR?, src }
 */
export function step(state, o, opts = {}) {
  const s = state || empty(); const now = opts.now ?? (Number.isFinite(o?.at) ? o.at : Date.now());   // the outcomes' own clock
  if (!o || !AL.strategies.includes(o.strategy) || !Number.isFinite(o.r) || s.seen.includes(o.id)) return s;
  if (o.src === 'elite') return s;   // never: Alpha Elite Signals are not regular recommendations
  const rec = { ...o, reason: diagnose(o) };
  s.seen = [o.id, ...s.seen].slice(0, AL.keep * 2);
  s.outcomes = [rec, ...s.outcomes].slice(0, AL.keep);
  // a live penalty is never permanent: after penaltyDays it lapses (that context trades again and is watched); if the losses
  // are still there, the next refit finds the pattern again and it goes back through validation + shadow
  if (s.active?.penalties) for (const [k, p] of Object.entries(s.active.penalties)) if (now - (p.since || 0) > AL.penaltyDays * 86_400_000) { delete s.active.penalties[k]; logIt(s, { kind: 'penalty_expired', key: k }); }
  // shadow: what the candidate WOULD have done with this real outcome (nothing changes live)
  if (s.candidate?.stage === 'shadow') {
    const sh = s.candidate.shadow; const d = decide(s.candidate.model, rec.strategy, rec.features, Number.isFinite(rec.rr) ? rec.rr : null, Number(rec.baseRR) || 0);
    sh.n += 1; sh.sumAll += rec.r; if (d.ok) { sh.keptN += 1; sh.sumKept += rec.r; }
    if (sh.n >= AL.shadowMinN) {
      const all = sh.sumAll / sh.n, kept = sh.keptN ? sh.sumKept / sh.keptN : -Infinity;
      if (sh.keptN >= sh.n * AL.minKeepShare && kept >= all) { s.active = { ...s.candidate.model, promotedAt: now, shadow: { ...sh } }; logIt(s, { kind: 'promoted', shadow: { n: sh.n, all: +all.toFixed(3), kept: +kept.toFixed(3) } }); s.candidate = null; }
      else if (sh.n >= AL.shadowMaxN || kept < all - 0.05) { logIt(s, { kind: 'discarded_in_shadow', shadow: { n: sh.n, all: +all.toFixed(3), kept: +kept.toFixed(3) } }); s.candidate = null; }
    }
  }
  s.sinceFit += 1;
  if (s.sinceFit >= AL.refitEvery && !s.candidate) {
    s.sinceFit = 0;
    const sorted = recentWindow(s.outcomes, now);
    const v = validate(sorted, s.active, { backtest: opts.backtest, now });
    const model = fitModel(sorted, s.active, now);
    const same = JSON.stringify({ w: model.weights, p: Object.keys(model.penalties).sort() }) === JSON.stringify({ w: s.active?.weights || Object.fromEntries(AL.strategies.map((x) => [x, 1])), p: Object.keys(s.active?.penalties || {}).sort() });
    if (same) logIt(s, { kind: 'no_change' });
    else if (!v.pass) logIt(s, { kind: 'rejected', reasons: v.reasons, oos: v.oos });
    else { s.candidate = { stage: 'shadow', model, validation: v, since: now, shadow: { n: 0, keptN: 0, sumAll: 0, sumKept: 0 } }; logIt(s, { kind: 'shadow_started', oos: v.oos, patterns: Object.keys(model.penalties) }); }
  }
  return s;
}

/** Records one closed outcome (called by services/learning.js for every regular recommendation that closed). */
export function observe(o, opts = {}) { try { save(step(adaptiveState(), o, opts)); } catch { /* the learning never breaks a recommendation */ } }
/** The live decision: ONLY the promoted (validated + shadow-tested) model is ever used. */
export function adaptiveDecision(strategy, features, rr, baseRR) { const a = adaptiveState().active; return a ? decide(a, strategy, features, rr, baseRR) : { ok: true, w: 1, rrAdd: 0 }; }
export const adaptiveWeight = (strategy, features) => { const a = adaptiveState().active; return a ? weightFor(a, strategy, features).w : 1; };
export const resetAdaptive = () => save(empty());
