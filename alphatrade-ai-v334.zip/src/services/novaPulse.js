// NOVA PULSE (v317) — an independent 1-minute engine. It does not touch «توصية AI», EDH or Alpha Elite Signals: it only READS the
// shared market data and the causal strategy library (aiPaperStrategies.js) and keeps its own state file.
//
// How a signal is made, on every newly CLOSED 1-minute candle of each market:
//  1. every strategy is replayed over the loaded real 1m history (no look-ahead: the signal at bar i sees bars ≤ i, the trade
//     fills on the next bar's open, costs are paid, a bar that touches stop and target counts as the stop);
//  2. a strategy may speak only if its MEASURED win rate on that history is ≥ 67 % over at least 30 closed trades and its
//     average result after costs is positive;
//  3. if such a strategy has a signal on the newest closed candle, it is published at once.
// The percentage shown is that measured past win rate on this market — a description of the last days, never a promise.
// Nothing is published from demo, stale (delayed) or closed-market data.
import { paperSeries, PAPER, unavailableReason } from './aiPaperStrategies.js';
import { simulate, wilson } from './aiBacktest.js';
import { costModel } from '../config/aiSignalRules.js';
import { findInstrument } from '../config/instruments.js';

export const NOVA_BRAND = 'NOVA PULSE';
export const NOVA = { tf: '1m', barSec: 60, minWinRate: 0.67, minTrades: 30, targetR: 1, maxBars: 30, staleSec: 180, bars: 3000, warmup: 210, keepDays: 7, maxSignals: 300 };
// NAS100 and US100 are the same index (Nasdaq 100): one market, shown under both names.
export const NOVA_MARKETS = [
  { id: 'XAUUSD', symbol: 'XAUUSD' }, { id: 'XAGUSD', symbol: 'XAGUSD' }, { id: 'XPTUSD', symbol: 'XPTUSD' },
  { id: 'EURUSD', symbol: 'EURUSD' }, { id: 'GBPUSD', symbol: 'GBPUSD' }, { id: 'USDJPY', symbol: 'USDJPY' },
  { id: 'NAS100', symbol: 'US100', aka: 'US100' }, { id: 'US30', symbol: 'US30' }, { id: 'US500', symbol: 'SPX500' },
];
const ASSET = { metal: 'metal', index: 'index', forex: 'forex', energy: 'energy', crypto: 'crypto' };
export const LIVE = ['active'];
const r4 = (v) => (Number.isFinite(v) ? Math.round(v * 10000) / 10000 : null);

/** Measured record of one strategy on these candles (single target at `targetR`, costs paid). */
export function strategyRecord(cs, T, id, ctx, costPct) {
  const signalAt = (i) => {
    let s = null; try { s = PAPER[id](T, i, ctx); } catch { s = null; }
    if (!s || !Number.isFinite(s.stop) || !Number.isFinite(s.entry)) return null;
    const sg = s.direction === 'long' ? 1 : -1; const risk = (s.entry - s.stop) * sg; if (!(risk > 0)) return null;
    const tp = s.entry + sg * NOVA.targetR * risk;
    return { direction: s.direction, stop: s.stop, targets: [tp, tp, tp] };
  };
  const trades = simulate(cs, signalAt, { costPct, maxBars: NOVA.maxBars, warmup: NOVA.warmup, beAfterTp1: false });
  const n = trades.length; const wins = trades.filter((x) => x.r > 0.02).length;
  const avgR = n ? trades.reduce((a, x) => a + x.r, 0) / n : null;
  return { n, wins, winRate: n ? wins / n : null, ci: wilson(wins, n), avgR: r4(avgR) };
}

/**
 * One market on its newest closed candle. → { state: 'signal'|'no_signal'|'stale'|'insufficient', barTime, signal?, qualified, checked }
 * `candles` are real 1-minute candles, oldest first; the still-forming candle (if any) is dropped here.
 */
export function evaluateNova({ market, candles, volumeKind = 'none', nowMs = Date.now() }) {
  const inst = findInstrument(market.symbol); const asset = ASSET[inst?.type] || 'index';
  const nowSec = Math.floor(nowMs / 1000);
  const cs = (candles || []).filter((c) => c && Number.isFinite(c.close) && c.time + NOVA.barSec <= nowSec);
  if (cs.length < NOVA.warmup + 60) return { state: 'insufficient', barTime: cs.at(-1)?.time ?? null, qualified: [], checked: 0 };
  const last = cs.at(-1);
  if (nowSec - (last.time + NOVA.barSec) > NOVA.staleSec) return { state: 'stale', barTime: last.time, qualified: [], checked: 0 };   // delayed feed or closed market
  const T = paperSeries(cs, { volumeKind }); const ctx = { assetClass: asset, tf: '1m', tfSec: NOVA.barSec };
  const costPct = costModel(asset).totalPct; const i = cs.length - 1;
  const qualified = []; let checked = 0; let best = null;
  for (const id of Object.keys(PAPER)) {
    if (unavailableReason(id, { volumeKind, assetClass: asset, tf: '1m' })) continue;
    checked++;
    const rec = strategyRecord(cs, T, id, ctx, costPct);
    if (!(rec.n >= NOVA.minTrades && rec.winRate >= NOVA.minWinRate && rec.avgR > 0)) continue;
    qualified.push({ strategy: id, n: rec.n, winRate: r4(rec.winRate) });
    let s = null; try { s = PAPER[id](T, i, ctx); } catch { s = null; }
    if (!s) continue;
    const sg = s.direction === 'long' ? 1 : -1; const entry = last.close; const risk = (entry - s.stop) * sg; if (!(risk > 0)) continue;
    const cand = { strategy: id, direction: s.direction, entry, stop: s.stop, target: entry + sg * NOVA.targetR * risk, rec };
    if (!best || rec.winRate > best.rec.winRate || (rec.winRate === best.rec.winRate && rec.n > best.rec.n)) best = cand;
  }
  if (!best) return { state: 'no_signal', barTime: last.time, qualified, checked };
  const p = inst?.precision ?? 2; const rd = (v) => Number(v.toFixed(p));
  return {
    state: 'signal', barTime: last.time, qualified, checked,
    signal: {
      id: `nova-${market.id}-${last.time}`, market: market.id, symbol: market.symbol, tf: '1m', strategy: best.strategy, direction: best.direction,
      entry: rd(best.entry), stop: rd(best.stop), target: rd(best.target), rr: NOVA.targetR,
      winRate: r4(best.rec.winRate), sample: best.rec.n, wins: best.rec.wins, ci: best.rec.ci, avgR: best.rec.avgR,
      days: Math.max(1, Math.round((last.time - cs[0].time) / 86400)), barTime: last.time, createdAt: nowMs, status: 'active', closedAt: null, result: null,
    },
  };
}

/** Follows an open signal on later 1m candles. A candle touching stop and target counts as the stop. Mutates and returns it. */
export function trackNova(sig, candles, nowMs = Date.now()) {
  if (sig.status !== 'active') return sig;
  const long = sig.direction === 'long'; const nowSec = Math.floor(nowMs / 1000);
  const after = (candles || []).filter((c) => c.time > sig.barTime && c.time + NOVA.barSec <= nowSec);
  for (let k = 0; k < after.length; k++) {
    const c = after[k];
    if (long ? c.low <= sig.stop : c.high >= sig.stop) return Object.assign(sig, { status: 'sl', result: -1, closedAt: (c.time + NOVA.barSec) * 1000 });
    if (long ? c.high >= sig.target : c.low <= sig.target) return Object.assign(sig, { status: 'tp', result: sig.rr, closedAt: (c.time + NOVA.barSec) * 1000 });
    if (k + 1 >= NOVA.maxBars) { const risk = Math.abs(sig.entry - sig.stop); const r = risk > 0 ? ((c.close - sig.entry) * (long ? 1 : -1)) / risk : 0; return Object.assign(sig, { status: 'expired', result: Math.round(r * 100) / 100, closedAt: (c.time + NOVA.barSec) * 1000 }); }
  }
  return sig;
}

/** The engine's own forward record (signals it really published), separate from the historical measurement. */
export function novaSummary(signals) {
  const closed = (signals || []).filter((s) => s.status !== 'active');
  const wins = closed.filter((s) => s.result > 0.02).length;
  return { total: (signals || []).length, active: (signals || []).length - closed.length, closed: closed.length, wins, losses: closed.filter((s) => s.result < -0.02).length,
    winRate: closed.length ? r4(wins / closed.length) : null, totalR: Math.round(closed.reduce((a, s) => a + (s.result || 0), 0) * 100) / 100 };
}

export function novaAlertBody(s, lang = 'ar') {
  const ar = lang === 'ar'; const side = s.direction === 'long' ? (ar ? 'شراء' : 'BUY') : (ar ? 'بيع' : 'SELL'); const pct = Math.round(s.winRate * 100);
  return ar
    ? `${s.market} · ${side} · 1د — دخول ${s.entry} · وقف ${s.stop} · هدف ${s.target} · نسبة النجاح المقاسة ${pct}% على ${s.sample} صفقة سابقة`
    : `${s.market} · ${side} · 1m — entry ${s.entry} · stop ${s.stop} · target ${s.target} · measured win rate ${pct}% over ${s.sample} past trades`;
}

export async function defaultDeps() {
  const mk = await import('./market/index.js');
  return { getHistory: mk.getHistory };
}

/** store: { load(), save(state) } · onNew(signals) → { state(), scanOnce(), start(), stop() } */
export function createNovaScanner({ deps, store, onNew = () => {}, log = console, markets = NOVA_MARKETS, now = Date.now, everyMs = 20_000 } = {}) {
  const loaded = store?.load?.();
  const st = loaded && Array.isArray(loaded.signals) ? { signals: loaded.signals, markets: loaded.markets || {}, lastScan: loaded.lastScan || 0 } : { signals: [], markets: {}, lastScan: 0 };
  let D = deps || null; let timer = 0; let running = false; let busy = false;
  const save = () => { try { store?.save?.(st); } catch (e) { log.warn?.('[nova] save', e?.message); } };
  const prune = () => { const keep = now() - NOVA.keepDays * 86_400_000; st.signals = st.signals.filter((s) => s.status === 'active' || (s.closedAt || s.createdAt) >= keep).sort((a, b) => b.createdAt - a.createdAt).slice(0, NOVA.maxSignals); };

  async function scanOnce() {
    D ||= await defaultDeps();
    const added = [];
    for (const m of markets) {
      const ms = (st.markets[m.id] ||= { id: m.id, symbol: m.symbol, aka: m.aka || null, bar: 0 });
      try {
        const t = now(); const lastClosed = Math.floor(t / 1000 / NOVA.barSec) * NOVA.barSec - NOVA.barSec;
        const open = st.signals.filter((s) => s.market === m.id && s.status === 'active');
        if (ms.bar === lastClosed && !open.length) continue;   // this candle is done
        const ds = await D.getHistory(m.symbol, '1m', NOVA.bars);
        if (!ds || ds.mode !== 'live' || !ds.candles?.length) { Object.assign(ms, { state: 'unavailable', reason: ds?.mode === 'demo' ? 'demo_data' : 'no_data', at: t, bar: lastClosed }); continue; }
        for (const s of open) trackNova(s, ds.candles, t);
        if (ms.bar === lastClosed) continue;
        const r = evaluateNova({ market: m, candles: ds.candles, volumeKind: ds.volumeKind || 'none', nowMs: t });
        Object.assign(ms, { state: r.state === 'signal' || r.state === 'no_signal' ? 'live' : r.state, at: t, bar: lastClosed, lastBar: r.barTime, checked: r.checked, qualified: r.qualified, source: ds.source || null, price: ds.candles.at(-1)?.close ?? null });
        // one open signal per market; a new one only after the last is closed
        if (r.state === 'signal' && !st.signals.some((s) => s.market === m.id && (s.status === 'active' || s.id === r.signal.id))) { st.signals.unshift(r.signal); added.push(r.signal); }
      } catch (e) { Object.assign(ms, { state: 'error', reason: String(e?.message || e).slice(0, 80), at: now() }); log.warn?.(`[nova] ${m.id}: ${ms.reason}`); }
      await new Promise((res) => setTimeout(res, 15));   // never hog the process
    }
    prune(); st.lastScan = now(); save();
    if (added.length) { try { onNew(added); } catch (e) { log.warn?.('[nova] onNew', e?.message); } }
    return added;
  }
  const loop = async () => {
    if (!running) return;
    if (!busy) { busy = true; try { await scanOnce(); } catch (e) { log.warn?.('[nova] loop', e?.message); } finally { busy = false; } }
    if (running) timer = setTimeout(loop, everyMs);
  };
  return { state: () => st, scanOnce, start() { if (running) return; running = true; loop(); }, stop() { running = false; clearTimeout(timer); } };
}
