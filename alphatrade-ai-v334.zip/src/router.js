// Hash router: #/login, #/signup, #/forgot, #/app, #/app/<page>.
import { auth } from './services/auth/index.js';
import { renderAuthPage } from './pages/login.js';
import { createAppShell } from './pages/appShell.js';
import { stopSignals } from './services/signals.js';
import { stopAlerts } from './services/alerts.js';

let container;
let shell = null;
let planSynced = false;
let planWatch = false;

export function navigate(hash) {
  if (location.hash === hash) render();
  else location.hash = hash;
}

function parse() {
  const parts = (location.hash || '#/login').replace(/^#\/?/, '').split('/');
  return { top: (parts[0] || 'login').split('?')[0] || 'login', sub: (parts[1] || '').split('?')[0] || null };
}

export function render({ force = false } = {}) {
  const { top, sub } = parse();
  const user = auth.current();
  const authRoutes = { login: 'signin', signup: 'signup', forgot: 'forgot' };

  if (top === 'app') {
    if (!user) {
      // Keep a shared link (e.g. a signals feed) to open it right after signing in.
      if (sub) { try { sessionStorage.setItem('ata:after-login', location.hash); } catch { /* ignore */ } }
      location.replace('#/login'); return;
    }
    let pending = null;
    try { pending = sessionStorage.getItem('ata:after-login'); sessionStorage.removeItem('ata:after-login'); } catch { /* ignore */ }
    if (pending && pending !== location.hash) { location.replace(pending); return; }
    if (!planWatch) {   // v323: a plan bought, changed or expired while the app is open shows within minutes (menu + page redrawn)
      planWatch = true;
      const again = () => { if (!planSynced || document.hidden) return; import('./services/plan.js').then((m) => m.recheckPlan()).then((changed) => { if (changed) render({ force: true }); }).catch(() => {}); };
      setInterval(again, 5 * 60_000); document.addEventListener('visibilitychange', again);
    }
    if (!planSynced) { planSynced = true; import('./services/plan.js').then((m) => m.syncPlan()).finally(() => render({ force: true })); return; }   // v297: know the real plan before the menu is drawn
    if (!shell || force) {
      shell?.destroy();
      shell = createAppShell(container);
    }
    shell.show(sub);
    document.title = 'AlphaTrade AI';
    return;
  }
  planSynced = false;   // signed out: the next account asks the server again
  // Terms & privacy are public (linked from the sign-in pages).
  if (top === 'legal') {
    if (user) { location.replace(`#/app/legal${sub ? `/${sub}` : ''}`); return; }
    if (shell) { shell.destroy(); stopSignals(); stopAlerts(); }
    shell = null;
    import('./pages/legal.js').then((m) => { container.replaceChildren(m.renderLegal({ standalone: true })); window.scrollTo({ top: 0 }); });
    return;
  }
  if (user && authRoutes[top] && top !== 'forgot') { location.replace('#/app'); return; }
  // Signed out (or on a sign-in page): stop the background scanner and the alert checks too; they start again with the app.
  if (shell) { shell.destroy(); stopSignals(); stopAlerts(); }
  shell = null;
  window.scrollTo({ top: 0 });
  renderAuthPage(container, authRoutes[top] || 'signin');
}

export function startRouter(el) {
  container = el;
  window.addEventListener('hashchange', () => { render(); window.scrollTo({ top: 0 }); });
  render();
}
