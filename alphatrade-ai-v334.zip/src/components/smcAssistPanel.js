// SMC / ICT assistant — the sidebar panel. The user picks swing / scalp, asset type, market / limit, capital and account
// type; the chart is read automatically (services/smcAssist.js), the zones are drawn on the chart, and the plan (entry,
// stop, targets, R:R, size) is shown with its checklist. Plans can be saved to the user's own history (services/assistTrades.js).
import { h, esc, fmtNum } from '../utils/dom.js';
import { t, getLang } from '../i18n/index.js';
import { icons } from './icons.js';
import { storage } from '../utils/storage.js';
import { auth } from '../services/auth/index.js';
import { store } from '../state/store.js';
import { getInstrument } from '../config/instruments.js';
import { TIMEFRAMES } from '../config/market.js';
import { htfCandles, htfSignature, prefetchHtf } from '../services/htfData.js';
import { analyzeSmcIct, cleanInputs, STYLES, ACCOUNTS, ASSETS, COSTS, LTF, OPTIONAL, historyStats, sessionClock } from '../services/smcAssist.js';
import { getHistory } from '../services/market/index.js';
import { getCalendar } from '../services/news.js';
import { newsRisk } from '../services/synthesis.js';
import { notify } from '../services/signals.js';
import { renderBacktest, renderScanner, renderBreakdown, renderTopDown, lastBacktest, btKey } from './smcAssistTools.js';
import { sendToJournal, saveTrade, listTrades, removeTrade, updateTrade, pullTrades, refreshOutcomes, onTrades, syncState, tradesCsv, todayLossPct } from '../services/assistTrades.js';
import { explainSmc } from '../services/ai/client.js';
import { aiErrorText } from './aiKeyCard.js';
import { openModal, toast } from './ui.js';

const T = (k, p) => t(`sa.${k}`, p);
const TYPE_TO_ASSET = { crypto: 'crypto', metal: 'metal', index: 'index', energy: 'energy', forex: 'forex', stock: 'stock' };
const prefKey = () => `assist-settings:${auth.current()?.uid || 'guest'}`;
const DEFAULTS = { on: true, draw: true, style: 'swing', execution: 'limit', asset: 'auto', account: 'margin', capital: '', riskPct: 1, leverage: 10, open: true, costPct: '', maxDailyLossPct: '', maxOpen: '', require: [], alerts: true };
let moreOpen = false; let sizeOpen = true;   // the “More tools” group keeps its state while the reading refreshes
const loadPrefs = () => ({ ...DEFAULTS, ...(storage.get(prefKey(), {}) || {}) });
// Zone alerts: "tell me when price reaches this zone" (on this device; checked with the chart and once a minute).
const watchKey = () => `assist-watch:${auth.current()?.uid || 'guest'}`;
export const listWatches = () => (storage.get(watchKey(), []) || []).filter((w) => w.expires > Date.now() / 1000);
const saveWatches = (list) => storage.set(watchKey(), list.slice(0, 30));

/** Compact copy of a reading for the AI (numbers only, no personal data). */
export function aiContext(r, { symbol, tf, mode }) {
  return {
    symbol, timeframe: tf, mode, verdict: r.verdict, direction: r.direction || null, reasons: r.reasons, style: r.style, execution: r.inputs.execution, account: r.inputs.account,
    price: r.price, atr: r.atr, bias: r.bias, range: r.range, sweep: r.sweep ? { dir: r.sweep.dir, level: r.sweep.level } : null,
    liquidity: (r.zones?.liquidity || []).slice(0, 8).map((l) => ({ kind: l.kind, price: l.price })),
    poi: r.plan?.poi || (r.zones?.poi ? { kind: r.zones.poi.kind, top: r.zones.poi.top, bottom: r.zones.poi.bottom } : null),
    plan: r.plan ? { entry: r.plan.entry, stop: r.plan.stop, targets: r.plan.targets, rr: r.plan.rr, rrAfterCosts: r.plan.rrNet, costR: r.plan.costR, sources: r.plan.sources, orderType: r.plan.execution, ltfConfirmation: r.plan.confirm?.status || null } : null,
    backtest: r.backtest || null,
    size: r.size ? { riskAmount: r.size.riskAmount, riskPct: r.size.riskPctActual, units: r.size.units, lots: r.size.lots, capped: r.size.capped } : null,
    checks: (r.checks || []).map((c) => ({ id: c.id, ok: c.ok, required: c.mandatory })), score: r.score || null,
  };
}

export function createAssistPanel({ getChart, onTimeframe } = {}) {
  let prefs = loadPrefs();
  let ctx = null;          // { dataset }
  let reading = null;
  let lastSig = '';
  let lastRun = 0;
  let timer = 0;
  let pulled = false;
  let newsEvents = null; let newsAt = 0;   // economic calendar (this week), refreshed every 10 min
  let ltfKey = ''; let ltfAt = 0;

  const el = h(`<section class="card side-card sa-card fade-in" data-sa>
    <div class="side-head"><h3 class="card-title">${icons.crosshair}<span>${esc(T('title'))}</span></h3>
      <label class="sa-switch"><input type="checkbox" data-sa-on ${prefs.on ? 'checked' : ''}><span>${esc(T('on'))}</span></label></div>
    <p class="side-foot sa-sub">${esc(T('sub'))}</p>
    <details class="sa-set" ${prefs.open ? 'open' : ''}><summary><span class="sa-set-t">${icons.settings || ''}<b>${esc(t('settings.title'))}</b></span><span class="sa-set-sum" data-set-sum></span></summary>
      <form class="sa-form" data-sa-form autocomplete="off">
        <fieldset class="sa-grp"><legend>${esc(T('grp.trade'))}</legend>
          <div class="sa-fld"><span class="sa-lab">${esc(T('style.label'))}</span><div class="seg sa-seg" data-seg="style">${['swing', 'scalp'].map((v) => `<button type="button" data-v="${v}">${esc(T(`style.${v}`))}</button>`).join('')}</div></div>
          <div class="sa-fld"><span class="sa-lab">${esc(T('exec.label'))}</span><div class="seg sa-seg" data-seg="execution">${['market', 'limit', 'confirm'].map((v) => `<button type="button" data-v="${v}" title="${esc(T(`exec.${v}Tip`))}">${esc(T(`exec.${v}`))}</button>`).join('')}</div>
            <small class="sa-help" data-exec-help></small></div>
          <label class="sa-fld"><span class="sa-lab">${esc(T('asset.label'))}</span><select class="select" name="asset"><option value="auto"></option>${ASSETS.map((a) => `<option value="${a}">${esc(T(`asset.${a}`))}</option>`).join('')}</select></label>
          <label class="sa-fld"><span class="sa-lab">${esc(T('account.label'))}</span><select class="select" name="account">${Object.keys(ACCOUNTS).map((a) => `<option value="${a}">${esc(T(`account.${a}`))}</option>`).join('')}</select>
            <small class="sa-help" data-acc-note></small></label>
        </fieldset>
        <fieldset class="sa-grp"><legend>${esc(T('grp.risk'))}</legend>
          <label class="sa-fld"><span class="sa-lab">${esc(T('capital'))}</span><span class="sa-unit" data-u="$"><input class="input mono" dir="ltr" name="capital" inputmode="decimal" placeholder="10000" maxlength="14"></span></label>
          <div class="sa-two">
            <label class="sa-fld"><span class="sa-lab">${esc(T('grp.riskShort'))}</span><span class="sa-unit" data-u="%"><input class="input mono" dir="ltr" name="riskPct" inputmode="decimal" maxlength="5"></span></label>
            <label class="sa-fld" data-lev><span class="sa-lab">${esc(T('leverage'))}</span><span class="sa-unit" data-u="×"><input class="input mono" dir="ltr" name="leverage" inputmode="numeric" maxlength="4"></span></label>
          </div>
          <small class="sa-help" data-risk-help></small>
        </fieldset>
        <fieldset class="sa-grp sa-grp-tog"><legend>${esc(T('grp.show'))}</legend>
          <label class="sa-tog"><span>${esc(T('draw'))}</span><input type="checkbox" role="switch" name="draw"><i aria-hidden="true"></i></label>
          <label class="sa-tog"><span>${esc(T('alerts'))}<small>${esc(T('alertsHint'))}</small></span><input type="checkbox" role="switch" name="alerts"><i aria-hidden="true"></i></label>
        </fieldset>
        <details class="sa-adv"><summary>${esc(T('adv.title'))}</summary>
          <div class="sa-two">
            <label class="sa-fld"><span class="sa-lab">${esc(T('grp.cost'))}</span><span class="sa-unit" data-u="%"><input class="input mono" dir="ltr" name="costPct" inputmode="decimal" maxlength="5"></span></label>
            <label class="sa-fld"><span class="sa-lab">${esc(T('grp.daily'))}</span><span class="sa-unit" data-u="%"><input class="input mono" dir="ltr" name="maxDailyLossPct" inputmode="decimal" maxlength="4"></span></label>
          </div>
          <label class="sa-fld"><span class="sa-lab">${esc(T('adv.maxOpen'))}</span><input class="input mono" dir="ltr" name="maxOpen" inputmode="numeric" maxlength="2" placeholder="3"></label>
          <div class="sa-fld"><span class="sa-lab">${esc(T('grp.req'))}</span><small class="sa-help">${esc(T('adv.reqNote'))}</small>
            <div class="sa-chips">${OPTIONAL.map((id) => `<label class="sa-chip"><input type="checkbox" name="req" value="${id}"><span>${esc(T(`chip.${id}`))}</span></label>`).join('')}</div></div>
        </details>
      </form>
    </details>
    <div class="sa-out" data-sa-out aria-live="polite"></div>
    <div class="sa-hist" data-sa-hist></div>
  </section>`);
  const $ = (s) => el.querySelector(s);
  const form = $('[data-sa-form]');
  const offTrades = onTrades(() => paintHistory());

  function syncForm() {
    for (const seg of el.querySelectorAll('[data-seg]')) for (const b of seg.querySelectorAll('button')) {
      const on = prefs[seg.dataset.seg] === b.dataset.v; b.classList.toggle('is-on', on); b.setAttribute('aria-pressed', String(on));
    }
    form.asset.value = prefs.asset; form.account.value = prefs.account; form.capital.value = prefs.capital ?? '';
    form.riskPct.value = prefs.riskPct; form.leverage.value = prefs.leverage; form.draw.checked = prefs.draw !== false; form.alerts.checked = prefs.alerts !== false;
    const c = cleanInputs({ ...prefs, asset: assetOf() });
    form.costPct.value = prefs.costPct === '' ? '' : prefs.costPct; form.costPct.placeholder = String(COSTS[c.asset]);
    form.maxDailyLossPct.value = prefs.maxDailyLossPct === '' ? '' : prefs.maxDailyLossPct; form.maxDailyLossPct.placeholder = String(ACCOUNTS[prefs.account].dailyLossPct ?? 3);
    form.maxOpen.value = prefs.maxOpen === '' ? '' : prefs.maxOpen;
    for (const box of form.querySelectorAll('[name=req]')) box.checked = (prefs.require || []).includes(box.value);
    $('[data-lev]').hidden = prefs.account === 'spot';
    const sym = ctx?.dataset?.symbol || store.get('symbol');
    form.asset.options[0].textContent = T('asset.auto', { t: T(`asset.${TYPE_TO_ASSET[getInstrument(sym)?.type] || 'crypto'}`) });
    const acc = ACCOUNTS[prefs.account];
    $('[data-acc-note]').textContent = prefs.account === 'spot' ? T('account.spotNote') : prefs.account === 'prop' ? T('account.propNote', { d: acc.dailyLossPct, m: acc.maxLossPct }) : '';
    $('[data-acc-note]').hidden = !$('[data-acc-note]').textContent;
    $('[data-exec-help]').textContent = T(`exec.${prefs.execution}Tip`);
    const cap = Number(prefs.capital) || 0;
    $('[data-risk-help]').textContent = cap > 0 ? T('grp.riskIs', { v: `$${fmtNum(cap * (Number(c.riskPct) || 0) / 100, 2)}` }) : T('grp.riskNeed');
    $('[data-set-sum]').textContent = [T(`style.${prefs.style}`), T(`exec.${prefs.execution}`), `${Math.round(Number(c.riskPct) * 100) / 100}%`, prefs.account === 'spot' ? '' : `×${c.leverage}`].filter(Boolean).join(' · ');
  }
  function savePrefs() { storage.set(prefKey(), prefs); }
  function changed() { savePrefs(); syncForm(); lastSig = ''; ensureLtf(); run(true); }
  // Lower timeframe for the "confirm" entry: loaded when that mode is on, refreshed every 30 s.
  function ensureLtf() {
    const ds = ctx?.dataset; if (!ds || prefs.execution !== 'confirm' || ds.mode !== 'live') return;
    const ltfTf = LTF[ds.tf]; if (!ltfTf) return;
    const lk = `${ds.symbol}|${ltfTf}`;
    if (lk === ltfKey && Date.now() - ltfAt < 30_000) return;
    ltfKey = lk; ltfAt = Date.now();
    getHistory(ds.symbol, ltfTf, 300).then((l) => { if (l.mode === 'live' && ctx?.dataset?.symbol === ds.symbol) { ctx.ltf = { key: lk, candles: l.candles, at: Date.now() }; run(true); } }).catch(() => {});
  }

  for (const seg of el.querySelectorAll('[data-seg]')) seg.addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; prefs[seg.dataset.seg] = b.dataset.v; changed(); });
  form.addEventListener('change', () => {
    const num = (v) => (String(v).trim() === '' ? '' : Number(String(v).replace(/[, ]/g, '')));
    const cap = num(form.capital.value);
    const cost = num(form.costPct.value); const daily = num(form.maxDailyLossPct.value); const mo = num(form.maxOpen.value);
    prefs = { ...prefs, asset: form.asset.value, account: form.account.value, capital: cap === '' || !(cap >= 0) ? '' : Math.min(cap, 1e12), riskPct: num(form.riskPct.value) || ACCOUNTS[form.account.value].riskPct, leverage: num(form.leverage.value) || ACCOUNTS[form.account.value].leverage, draw: form.draw.checked,
      alerts: form.alerts.checked, costPct: cost === '' || !(cost >= 0) ? '' : Math.min(cost, 2), maxDailyLossPct: daily === '' || !(daily >= 0) ? '' : Math.min(daily, 50), maxOpen: mo === '' || !(mo >= 1) ? '' : Math.min(Math.round(mo), 20), require: [...form.querySelectorAll('[name=req]:checked')].map((x) => x.value) };
    if (prefs.alerts && !loadPrefs().alerts) {
      // push through the server too, so crypto trades are announced with the browser closed (needs the bank server for Web Push)
      import('../services/bank/push.js').then((m) => m.enablePush()).then(() => toast(T('alertsPushOn'), 'success'))
        .catch(() => { if (typeof Notification !== 'undefined' && Notification.permission === 'default') Notification.requestPermission().catch(() => {}); });
    }
    if (form.account.value !== loadPrefs().account) { prefs.riskPct = ACCOUNTS[prefs.account].riskPct; prefs.leverage = ACCOUNTS[prefs.account].leverage; }
    const c = cleanInputs(prefs); prefs.riskPct = c.riskPct; prefs.leverage = c.leverage;
    changed();
  });
  form.addEventListener('submit', (e) => e.preventDefault());
  $('[data-sa-on]').addEventListener('change', (e) => { prefs.on = e.target.checked; savePrefs(); lastSig = ''; if (!prefs.on) { reading = null; getChart?.()?.setAssist(null); paint(); } else run(true); });
  $('.sa-set').addEventListener('toggle', (e) => { prefs.open = e.target.open; savePrefs(); });

  const prec = () => getInstrument(ctx?.dataset?.symbol)?.precision ?? 2;
  const px = (v) => fmtNum(v, prec());
  const money = (v) => `$${fmtNum(v, 2)}`;
  const tfName = (id) => t(`perf.tfShort.${id}`) || id;

  function assetOf() { const sym = ctx?.dataset?.symbol || store.get('symbol'); return prefs.asset === 'auto' ? TYPE_TO_ASSET[getInstrument(sym)?.type] || 'crypto' : prefs.asset; }
  const newsNow = () => (ctx?.dataset ? newsRisk(ctx.dataset.symbol, newsEvents, Date.now()) : null);
  function inputs() {
    const ds = ctx.dataset;
    return { ...prefs, capital: Number(prefs.capital) || 0, asset: assetOf(), costPct: prefs.costPct === '' ? undefined : prefs.costPct, maxDailyLossPct: prefs.maxDailyLossPct === '' ? undefined : prefs.maxDailyLossPct,
      symbol: ds.symbol, tfSec: TIMEFRAMES.find((x) => x.id === ds.tf)?.seconds || 3600, htf: htfCandles(ds.symbol),
      ltf: ctx.ltf?.key === `${ds.symbol}|${LTF[ds.tf]}` ? ctx.ltf.candles : null, news: newsNow(), todayLossPct: todayLossPct(), exposure: exposureNow(), maxOpen: prefs.maxOpen === '' ? undefined : prefs.maxOpen };
  }
  function exposureNow() {
    const open = listTrades().filter((x) => x.mode === 'live' && ['pending', 'active'].includes(x.status));
    const asset = assetOf(); const same = open.filter((x) => x.asset === asset);
    return { open: open.length, sameAsset: { long: same.filter((x) => x.direction === 'long').length, short: same.filter((x) => x.direction === 'short').length } };
  }

  function run(force = false) {
    if (!prefs.on || !ctx?.dataset?.candles?.length) return;
    const ds = ctx.dataset; const last = ds.candles.at(-1);
    const sig = `${ds.symbol}|${ds.tf}|${ds.mode}|${last.time}|${last.close}|${htfSignature(htfCandles(ds.symbol))}|${JSON.stringify(prefs)}|${ctx.ltf?.at || 0}|${newsNow()?.level}|${todayLossPct()}|${JSON.stringify(exposureNow())}`;
    if (!force && sig === lastSig) return;
    const wait = 1000 - (Date.now() - lastRun);
    if (!force && wait > 0) { clearTimeout(timer); timer = setTimeout(() => run(), wait); return; }
    lastSig = sig; lastRun = Date.now();
    try { reading = analyzeSmcIct(ds.candles, inputs()); }
    catch (e) { console.error('[assist] analysis failed', e); reading = null; paint(); return; }   // never breaks the dashboard
    reading.ctx = { symbol: ds.symbol, tf: ds.tf, mode: ds.mode };
    reading.backtest = lastBacktest(btKey(ds.symbol, ds.tf, cleanInputs(prefs)));
    const chart = getChart?.();
    chart?.setAssist(prefs.draw !== false ? { zones: reading.zones, plan: reading.verdict === 'trade' || reading.verdict === 'wait' ? reading.plan : null,
      labels: { sweep: T('sweep'), entry: T('entryTag'), stop: T('stopTag'), market: T('marketTag'), limit: T('limitTag') } } : null);
    const changes = refreshOutcomes(ds.symbol, ds.tf, ds.candles, ds.mode, { price: last.close });
    if (changes.length) { alertChanges(changes); paintHistory(); }
    nearEntry(ds.symbol, ds.tf, last.close);
    checkWatches(ds.symbol, last);
    paint();
  }

  function paint() {
    const out = $('[data-sa-out]');
    if (!prefs.on) { out.innerHTML = ''; return; }
    if (!ctx?.dataset || !reading) { out.innerHTML = `<p class="muted sa-note">…</p>`; return; }
    const r = reading; const ds = ctx.dataset; const P = STYLES[r.style];
    const parts = [];
    if (!P.tfs.includes(ds.tf)) {
      const best = r.style === 'swing' ? '4h' : '15m';
      parts.push(`<div class="sa-hint">${esc(T('tfHint', { style: T(`style.${r.style}`), list: P.tfs.map(tfName).join(' / '), tf: tfName(ds.tf) }))} <button type="button" class="btn btn-sm" data-tf="${best}">${esc(T('tfSwitch', { tf: tfName(best) }))}</button></div>`);
    }
    if (ds.mode !== 'live') parts.push(`<div class="sa-demo">${icons.alert || ''}<span>${esc(T('demo'))}</span></div>`);
    const v = r.verdict;
    const head = v === 'trade' || v === 'wait' ? `${T(`verdict.${v}`)} · ${T(`dir.${r.direction}`)}` : T(`verdict.${v}`);
    const poiKind = r.plan?.poi ? (r.plan.poi.kind === 'OB' && r.plan.poi.withFvg ? 'OBFVG' : r.plan.poi.kind) : null;
    parts.push(`<div class="sa-verdict sa-v-${v} ${r.direction === 'short' ? 'is-short' : ''}"><b>${esc(head)}</b>${r.plan && v !== 'no_trade' ? `<span>${esc(T(`exec.${r.plan.execution}`))} · ${esc(T(`poiKind.${poiKind}`))}</span>` : ''}</div>`);
    // back-test of these exact settings on this market (if the user ran one)
    const bt = r.backtest;
    const ctxRows = [];
    ctxRows.push(bt ? `<p class="sa-bt-badge sa-bt-${bt.verdict}"><b>${esc(T(`bt.verdict.${bt.verdict}`))}</b> · ${esc(T('bt.badge', { n: bt.n, a: bt.avgR == null ? '—' : `${bt.avgR > 0 ? '+' : ''}${fmtNum(bt.avgR, 2)}`, w: bt.winRate == null ? '—' : Math.round(bt.winRate * 100) }))}</p>`
      : `<p class="sa-bt-badge"><span class="muted">${esc(T('bt.none'))}</span></p>`);
    // ICT windows (New York time): what is open now and what opens next
    { const sc = sessionClock(Math.floor(Date.now() / 1000)); const hm = (m) => `${Math.floor(m / 60) ? `${Math.floor(m / 60)}${T('clock.h')} ` : ''}${m % 60}${T('clock.m')}`;
      ctxRows.push(`<p class="sa-clock">${icons.clock || ''}<span>${sc.now.length ? esc(T('clock.now', { w: sc.now.map((x) => `${T(`clock.${x.id}`)} (${hm(x.endsIn)})`).join(' · ') })) : esc(T('clock.none'))}${sc.next ? ` · ${esc(T('clock.next', { w: T(`clock.${sc.next.id}`), t: hm(sc.next.in) }))}` : ''}</span></p>`); }
    // bias
    if (r.bias) {
      const fr = Object.entries(r.bias.frames || {});
      const pd = r.range ? (r.price > r.range.eq ? T('pd.premium') : T('pd.discount')) : '';
      ctxRows.push(`<p class="sa-bias"><span class="muted">${esc(T('bias.title'))}:</span> ${fr.length ? fr.map(([k, d]) => `<b>${esc(T(`bias.${k}`))}</b> ${esc(T(`bias.${d}`))}`).join(' · ') : esc(T('bias.chart'))}${r.bias.bias === 'mixed' ? ` · <b class="down">${esc(T('bias.mixed'))}</b>` : ''}${pd ? ` · ${esc(pd)}` : ''}</p>`);
    }
    parts.push(`<div class="sa-ctx">${ctxRows.join('')}</div>`);
    if (r.plan && v !== 'no_trade') {
      const p = r.plan;
      const rows = [
        [T('entry'), `<b class="mono">${px(p.entry)}</b>`],
        [T('stop'), `<b class="mono down">${px(p.stop)}</b> <small class="muted mono">(${px(p.risk)})</small>`],
        ...p.targets.map((tp, k) => [T('target', { n: k + 1 }), `<b class="mono up">${px(tp)}</b> <small class="mono">1:${fmtNum(p.rr[k], 2)}</small>${p.costR ? ` <small class="mono muted" title="${esc(T('netTip'))}">(${fmtNum(p.rrNet[k], 2)})</small>` : ''} <small class="muted">${esc(/R$/.test(p.sources[k] || '') ? '' : p.sources[k] || '')}</small>`]),
      ];
      if (p.costR) rows.push([T('costs'), `<span class="mono">${fmtNum(p.costR, 2)}R</span> <small class="muted">(${fmtNum(cleanInputs({ ...prefs, asset: assetOf(), costPct: prefs.costPct === '' ? undefined : prefs.costPct }).costPct, 2)}%)</small>`]);
      if (p.execution === 'limit') rows.push([T('validUntil'), `<span class="mono">${esc(new Date(p.validUntil * 1000).toLocaleString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }))}</span>`]);
      parts.push(`<h4 class="sa-h">${esc(T('ui.plan'))}</h4><table class="kv-table sa-plan"><tbody>${rows.map(([k, val]) => `<tr><td>${esc(k)}</td><td>${val}</td></tr>`).join('')}</tbody></table>`);
      const waitText = r.inputs.execution === 'confirm' ? T(`confirmNote.${p.confirm?.status || 'no_data'}`, { ref: p.confirm?.ref != null ? px(p.confirm.ref) : '—', ltf: tfName(LTF[ds.tf] || '') }) : T('waitNote');
      parts.push(`<p class="sa-note">${esc(v === 'wait' ? waitText : p.execution === 'limit' ? T('limitNote') : '')}</p>`);
      const exc = r.checks.find((c) => c.id === 'exposure');
      if (exc?.sameDir) parts.push(`<p class="sa-note">${esc(T('exposureNote', { n: exc.sameDir, dir: T(`dir.${p.direction}`) }))}</p>`);
      const nr = newsNow();
      if (nr?.level === 'high' || nr?.level === 'soon') parts.push(`<p class="sa-note ${nr.level === 'high' ? 'down' : ''}">${esc(T(`news.${nr.level}`, { m: Math.abs(nr.minutes), e: nr.event?.title || '' }))}</p>`);
      // size
      if (r.size) {
        const s = r.size;
        const srows = [[T('size.riskAmt'), `${money(s.riskAmount)} <small class="muted">(${fmtNum(s.riskPctActual, 2)}%)</small>`], [T('size.units'), `<span class="mono">${fmtNum(s.units, s.units < 1 ? 6 : s.units < 100 ? 4 : 2)}</span>`]];
        if (s.lots != null) srows.push([T('size.lots', { n: fmtNum(s.lotSize, 0) }), `<span class="mono">${fmtNum(s.lots, 2)}</span>`]);
        srows.push([T('size.notional'), money(s.notional)]);
        if (s.leverage > 1) srows.push([T('size.margin'), `${money(s.margin)} <small class="muted">×${s.leverage}</small>`]);
        srows.push([T('size.reward'), s.rewards.map(money).join(' · ')]);
        if (s.parts?.length > 1) srows.push([T('size.parts'), `<span class="mono">${fmtNum(s.parts[0], s.parts[0] < 1 ? 6 : 4)}</span> × ${s.parts.length}`]);
        parts.push(`<details class="sa-fold" ${sizeOpen ? 'open' : ''} data-fold="size"><summary><b>${esc(T('ui.size'))}</b><span class="mono">${esc(T('ui.riskLine', { v: money(s.riskAmount) }))}</span></summary><table class="kv-table"><tbody>${srows.map(([k, val]) => `<tr><td>${esc(k)}</td><td class="mono">${val}</td></tr>`).join('')}</tbody></table>
          ${s.capped ? `<p class="sa-note down">${esc(T(`size.${s.capped === 'capital' ? 'capped_capital' : 'capped_leverage'}`))}</p>` : ''}${s.lots != null ? `<p class="sa-note muted">${esc(T('size.lotNote'))}</p>` : ''}</details>`);
      } else parts.push(`<p class="sa-note muted">${esc(T('size.needCapital'))}</p>`);
    }
    if (v === 'no_trade' || v === 'insufficient') parts.push(`<ul class="sa-reasons">${r.reasons.map((x) => `<li>${esc(T(`reasons.${x}`))}</li>`).join('')}</ul>`);
    if (r.checks?.length) {
      const pct = r.score ? Math.round((r.score.passed / Math.max(1, r.score.total)) * 100) : 0;
      parts.push(`<details class="sa-checks sa-fold" ${v === 'no_trade' ? 'open' : ''}><summary><b>${esc(T('checks.title'))}</b><span class="sa-score"><span class="sa-bar"><i style="width:${pct}%"></i></span><span class="mono">${r.score ? `${r.score.passed}/${r.score.total}` : ''}</span></span></summary><ul>${r.checks.map((c) => `<li class="${c.ok ? 'ok' : 'no'}"><span aria-hidden="true">${c.ok ? '✓' : '✗'}</span> ${esc(T(`checks.${c.id}`))}${c.mandatory ? ` <small class="muted">· ${esc(T('checks.required'))}</small>` : ''}</li>`).join('')}</ul>${r.score ? `<p class="sa-note muted">${esc(T('checks.score', { p: r.score.passed, t: r.score.total }))}</p>` : ''}</details>`);
    }
    const canSave = r.plan && (v === 'trade' || v === 'wait');
    parts.push(`<div class="sa-actions sa-act-main">${canSave ? `<button type="button" class="btn btn-sm btn-primary sa-act-save" data-save ${ds.mode !== 'live' ? `disabled title="${esc(T('saveDemo'))}"` : ''}>${icons.plus || ''}<span>${esc(T('save'))}</span></button>` : ''}
      <button type="button" class="btn btn-sm" data-ai>${icons.brain || ''}<span>${esc(T('ai'))}</span></button>
      <button type="button" class="btn btn-sm" data-bt>${icons.flask || ''}<span>${esc(T('bt.open'))}</span></button></div>
      <details class="sa-more" ${moreOpen ? 'open' : ''}><summary>${esc(T('more'))}</summary><div class="sa-tools">
      ${canSave ? `<button type="button" class="btn btn-sm" data-copy>${icons.journal || ''}<span>${esc(T('copy'))}</span></button>` : ''}
      ${r.zones?.poi && ds.mode === 'live' ? `<button type="button" class="btn btn-sm" data-watch>${icons.bell || ''}<span>${esc(T('watch.add'))}</span></button>` : ''}
      <button type="button" class="btn btn-sm" data-scan>${icons.radar || ''}<span>${esc(T('scan.open2'))}</span></button>
      <button type="button" class="btn btn-sm" data-td>${icons.layers || ''}<span>${esc(T('td.open'))}</span></button>
      <button type="button" class="btn btn-sm" data-img>${icons.download || ''}<span>${esc(T('img'))}</span></button></div></details>
      ${canSave && ds.mode !== 'live' ? `<p class="sa-note muted">${esc(T('saveDemo'))}</p>` : ''}
      <div class="sa-ai-out" data-ai-out hidden></div>
      <details class="sa-legend"><summary>${icons.info || ''}<span>${esc(T('ui.legend'))}</span></summary><p class="side-foot">${esc(T('zones'))}</p></details><p class="side-foot sa-honest">${esc(T('honest'))}</p>`);
    out.innerHTML = parts.join('');
    out.querySelector('[data-tf]')?.addEventListener('click', (e) => onTimeframe?.(e.currentTarget.dataset.tf));
    out.querySelector('[data-fold=size]')?.addEventListener('toggle', (e) => { sizeOpen = e.currentTarget.open; });
    out.querySelector('.sa-more')?.addEventListener('toggle', (e) => { moreOpen = e.currentTarget.open; });
    out.querySelector('[data-save]')?.addEventListener('click', (e) => {
      if (ds.mode !== 'live') return;
      saveTrade(reading, reading.ctx); e.currentTarget.disabled = true; toast(T('saved'), 'success'); paintHistory();
    });
    out.querySelector('[data-watch]')?.addEventListener('click', (e) => {
      const z = r.zones.poi; const now = Math.floor(Date.now() / 1000);
      const list = listWatches().filter((w) => !(w.symbol === ds.symbol && w.top === z.top && w.bottom === z.bottom));
      list.unshift({ id: `w${now.toString(36)}${Math.random().toString(36).slice(2, 6)}`, symbol: ds.symbol, tf: ds.tf, dir: z.dir, kind: z.kind, top: z.top, bottom: z.bottom, createdAt: now, expires: now + 7 * 86400 });
      saveWatches(list); e.currentTarget.disabled = true; toast(T('watch.added'), 'success'); paintHistory();
      if (typeof Notification !== 'undefined' && Notification.permission === 'default') Notification.requestPermission().catch(() => {});
    });
    out.querySelector('[data-copy]')?.addEventListener('click', async () => {
      const p = r.plan; const sym = ds.symbol;
      const text = [`${sym} ${tfName(ds.tf)} · ${T(`dir.${p.direction}`)} ${T(`exec.${p.execution}`)} (${T(`style.${r.style}`)})`, `${T('entry')}: ${px(p.entry)}`, `${T('stop')}: ${px(p.stop)}`,
        ...p.targets.map((tp, k) => `${T('target', { n: k + 1 })}: ${px(tp)} (1:${fmtNum(p.rr[k], 2)})`), r.size ? `${T('size.riskAmt')}: ${money(r.size.riskAmount)} · ${T('size.units')}: ${fmtNum(r.size.units, 6)}` : '', 'AlphaTrade AI · SMC / ICT'].filter(Boolean).join('\n');
      try { await navigator.clipboard.writeText(text); toast(T('copied'), 'success'); } catch { toast(text, 'info', 9000); }
    });
    out.querySelector('[data-bt]')?.addEventListener('click', () => openModal(T('bt.title'), (body) => renderBacktest(body, { symbol: ds.symbol, tf: ds.tf, inputs: cleanInputs({ ...inputs(), htf: null, ltf: null }), onRequire: (req) => { prefs.require = req; changed(); }, onDone: () => { lastSig = ''; run(true); }, onApply: ({ execution, require }) => { prefs.execution = execution; prefs.require = require; changed(); }, onApplyRisk: (v) => { prefs.riskPct = Math.round(v * 100) / 100; changed(); toast(T('ra.applied', { r: prefs.riskPct }), 'success'); } }), { wide: true }));
    out.querySelector('[data-img]')?.addEventListener('click', () => { try { getChart?.()?.screenshot(`${ds.symbol}-${ds.tf}-smc-ict.png`); } catch { toast(T('imgFail'), 'error'); } });
    out.querySelector('[data-td]')?.addEventListener('click', () => openModal(T('td.title'), (body) => renderTopDown(body, { symbol: ds.symbol }), { wide: true }));
    out.querySelector('[data-scan]')?.addEventListener('click', () => openModal(T('scan.title'), (body, close) => renderScanner(body, { tf: ds.tf, inputs: { ...cleanInputs({ ...prefs, capital: Number(prefs.capital) || 0 }), asset: prefs.asset, costPct: prefs.costPct === '' ? undefined : prefs.costPct, maxDailyLossPct: 0 }, onPick: (sym) => { close(); store.set('symbol', sym); } }), { wide: true }));
    out.querySelector('[data-ai]')?.addEventListener('click', async (e) => {
      const btn = e.currentTarget; const box = out.querySelector('[data-ai-out]');
      btn.disabled = true; box.hidden = false; box.className = 'sa-ai-out muted'; box.textContent = t('syn.explaining');
      try {
        const text = await explainSmc(aiContext(reading, reading.ctx), getLang());
        box.className = 'sa-ai-out'; box.textContent = text; box.insertAdjacentHTML('beforeend', `<small class="muted">${esc(T('aiNote'))}</small>`);
      } catch (err) { box.className = 'sa-ai-out down'; box.textContent = err?.code && /^[a-z_]+$/.test(err.code) ? aiErrorText(err.code) : String(err?.message || err); }
      finally { btn.disabled = false; }
    });
  }

  /* ── alerts: a saved trade filled / hit a target / stopped / expired, and price getting close to a waiting entry ── */
  const fmtSym = (x) => `${x.symbol} ${tfName(x.tf)}`;
  function alertChanges(changes) {
    if (prefs.alerts === false) return;
    for (const { item: x, before } of changes) {
      let key = null;
      if (before.status === 'pending' && x.status === 'active') key = 'filled';
      else if (x.hits > (before.hits || 0) && x.status === 'active') key = 'target';
      else if (['done', 'stopped', 'breakeven', 'expired', 'missed'].includes(x.status)) key = x.status;
      if (!key) continue;
      const body = T(`alert.${key}`, { sym: fmtSym(x), dir: T(`dir.${x.direction}`), n: x.hits, r: x.resultR == null ? '' : `${x.resultR > 0 ? '+' : ''}${fmtNum(x.resultR, 2)}R` });
      notify(T('title'), body, `sa-${x.id}-${x.status}-${x.hits}`);
    }
  }
  function nearEntry(symbol, tf, price) {
    if (prefs.alerts === false || !(price > 0)) return;
    const done = new Set(storage.get('assist-near', []) || []);
    for (const x of listTrades()) {
      if (x.symbol !== symbol || x.tf !== tf || x.status !== 'pending' || x.mode !== 'live' || done.has(x.id)) continue;
      if (Math.abs(price - x.entry) <= 0.3 * x.risk) {
        done.add(x.id);
        notify(T('title'), T('alert.near', { sym: fmtSym(x), dir: T(`dir.${x.direction}`), p: fmtNum(x.entry, getInstrument(x.symbol)?.precision ?? 2) }), `sa-near-${x.id}`);
      }
    }
    storage.set('assist-near', [...done].slice(-200));
  }
  function checkWatches(symbol, bar) {
    if (!bar) return;
    const all = listWatches(); let hit = false;
    const left = all.filter((w) => {
      if (w.symbol !== symbol || !(bar.low <= w.top && bar.high >= w.bottom)) return true;
      hit = true;
      if (prefs.alerts !== false) notify(T('title'), T('alert.zone', { sym: `${w.symbol} ${tfName(w.tf)}`, k: T(`poiKind.${w.kind}`), lo: fmtNum(w.bottom, getInstrument(w.symbol)?.precision ?? 2), hi: fmtNum(w.top, getInstrument(w.symbol)?.precision ?? 2) }), `sa-zone-${w.id}`);
      return false;
    });
    if (hit || left.length !== (storage.get(watchKey(), []) || []).length) { saveWatches(left); paintHistory(); }
  }
  // Saved trades on other markets / timeframes are checked once a minute on real candles, even when the chart shows something else.
  async function watch() {
    for (const sym of [...new Set(listWatches().map((w) => w.symbol))].slice(0, 6)) {
      if (ctx?.dataset?.symbol === sym) continue;
      try { const w0 = listWatches().find((w) => w.symbol === sym); const d = await getHistory(sym, w0.tf, 50); if (d.mode === 'live') checkWatches(sym, d.candles.at(-1)); } catch { /* next minute */ }
    }
    const open = listTrades().filter((x) => x.mode === 'live' && ['pending', 'active'].includes(x.status));
    const groups = [...new Set(open.map((x) => `${x.symbol}|${x.tf}`))].slice(0, 6);
    for (const g of groups) {
      const [symbol, tf] = g.split('|');
      if (ctx?.dataset && ctx.dataset.symbol === symbol && ctx.dataset.tf === tf) continue;   // the chart already does this one
      const sec = TIMEFRAMES.find((x) => x.id === tf)?.seconds || 3600;
      const oldest = Math.min(...open.filter((x) => x.symbol === symbol && x.tf === tf).map((x) => x.createdAt));
      try {
        const ds = await getHistory(symbol, tf, Math.min(1500, Math.ceil((Date.now() / 1000 - oldest) / sec) + 30));
        const ch = refreshOutcomes(symbol, tf, ds.candles, ds.mode, { price: ds.candles.at(-1)?.close });
        if (ch.length) { alertChanges(ch); paintHistory(); }
        if (ds.mode === 'live') nearEntry(symbol, tf, ds.candles.at(-1)?.close);
      } catch { /* try again next minute */ }
    }
  }
  const watchTimer = setInterval(() => { if (el.isConnected) watch(); }, 60_000);
  setTimeout(() => { if (el.isConnected) watch(); }, 8000);

  function paintHistory() {
    const box = $('[data-sa-hist]');
    const items = listTrades(); const st = historyStats(items); const sync = syncState();
    const ws = listWatches();
    const watchHtml = ws.length ? `<div class="sa-watch"><h4 class="sa-h">${esc(T('watch.title'))}</h4><ul class="sa-hlist">${ws.map((w) => { const pp = getInstrument(w.symbol)?.precision ?? 2; return `<li><span class="mono">${esc(w.symbol)} ${esc(tfName(w.tf))}</span> <span class="${w.dir === 'bull' ? 'up' : 'down'}">${esc(T(`poiKind.${w.kind}`))}</span> <span class="mono">${fmtNum(w.bottom, pp)}–${fmtNum(w.top, pp)}</span> <button type="button" class="btn btn-sm btn-ghost" data-unwatch="${esc(w.id)}" aria-label="${esc(T('history.del'))}">×</button></li>`; }).join('')}</ul></div>` : '';
    box.innerHTML = `${watchHtml}<div class="side-head"><h4 class="sa-h">${esc(T('history.title'))}</h4><small class="muted">${esc(T(`history.sync.${sync.state}`))}</small></div>
      ${items.length ? `<p class="sa-note mono">${esc(T('history.stats', { n: st.n, c: st.closed, w: st.winRate == null ? '—' : Math.round(st.winRate * 100), r: fmtNum(st.totalR, 2) }))}</p>
      <ul class="sa-hlist">${items.slice(0, 4).map(rowHtml).join('')}</ul>
      <button type="button" class="btn btn-sm btn-ghost" data-all>${esc(T('history.all'))} (${items.length})</button>` : `<p class="muted sa-note">${esc(T('history.empty'))}</p>`}`;
    box.querySelectorAll('[data-unwatch]').forEach((b) => b.addEventListener('click', () => { saveWatches(listWatches().filter((w) => w.id !== b.dataset.unwatch)); paintHistory(); }));
    box.querySelector('[data-all]')?.addEventListener('click', () => openModal(T('history.title'), (body) => renderHistory(body), { wide: true }));
  }

  return {
    el,
    /** Called by the dashboard after every analysis refresh. */
    update(dataset) {
      if (!dataset?.candles?.length) return;
      const symbolChanged = ctx?.dataset?.symbol !== dataset.symbol;
      ctx = { dataset, ltf: ctx?.ltf };
      if (symbolChanged) syncForm();
      if (!pulled) { pulled = true; pullTrades().then(paintHistory); }
      // Higher-timeframe candles (4h / Daily) for the bias, loaded once per symbol; the reading reruns when they arrive.
      const tfSec = TIMEFRAMES.find((x) => x.id === dataset.tf)?.seconds || 3600;
      if (dataset.mode === 'live' && !htfCandles(dataset.symbol)) prefetchHtf(dataset.symbol, tfSec).then((fresh) => { if (fresh && ctx?.dataset?.symbol === dataset.symbol) run(true); });
      // Economic calendar (this week) for the news check, refreshed every 10 minutes.
      if (Date.now() - newsAt > 600_000) { newsAt = Date.now(); getCalendar().then((ev) => { newsEvents = Array.isArray(ev) ? ev : null; run(true); }).catch(() => { newsEvents = null; }); }
      ensureLtf();
      try { run(); } catch (e) { console.error('[assist] update failed', e); }
    },
    destroy() { clearTimeout(timer); clearInterval(watchTimer); offTrades(); getChart?.()?.setAssist(null); },
    init() { syncForm(); paintHistory(); paint(); },
  };
}

const rowHtml = (x) => {
  const inst = getInstrument(x.symbol); const p = inst?.precision ?? 2;
  const res = x.resultR == null ? '' : `<b class="mono ${x.resultR > 0 ? 'up' : x.resultR < 0 ? 'down' : ''}">${x.resultR > 0 ? '+' : ''}${fmtNum(x.resultR, 2)}R</b>`;
  return `<li><span class="mono">${esc(x.symbol)} ${esc(t(`perf.tfShort.${x.tf}`) || x.tf)}</span> <span class="${x.direction === 'long' ? 'up' : 'down'}">${esc(T(`dir.${x.direction}`))}</span> <span class="mono">${fmtNum(x.entry, p)}</span>
    <span class="badge sa-st sa-st-${x.status}">${esc(T(`history.status.${x.status}`))}${x.hits ? ` · TP${x.hits}` : ''}</span> ${res}</li>`;
};

/** Full history table (modal on the dashboard, and the profile page). */
export function renderHistory(body) {
  const draw = () => {
    const items = listTrades(); const st = historyStats(items);
    body.innerHTML = `<p class="sa-note mono">${esc(T('history.stats', { n: st.n, c: st.closed, w: st.winRate == null ? '—' : Math.round(st.winRate * 100), r: fmtNum(st.totalR, 2) }))} · <span class="muted">${esc(T(`history.sync.${syncState().state}`))}</span></p>
      <p class="sa-note muted">${esc(T('history.mgmt'))}</p>
      ${items.length ? `<div class="sa-table-wrap"><table class="kv-table sa-table"><thead><tr><th>${esc(T('history.cols.date'))}</th><th>${esc(T('history.cols.symbol'))}</th><th>${esc(T('history.cols.plan'))}</th><th>${esc(T('history.cols.status'))}</th><th>${esc(T('history.cols.result'))}</th><th>${esc(T('history.note'))}</th><th></th></tr></thead><tbody>
        ${items.map((x) => { const p = getInstrument(x.symbol)?.precision ?? 2; return `<tr><td class="mono">${esc(new Date(x.savedAt).toLocaleDateString(getLang() === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB'))}</td>
          <td class="mono">${esc(x.symbol)} · ${esc(t(`perf.tfShort.${x.tf}`) || x.tf)} · ${esc(T(`style.${x.style}`))}</td>
          <td><span class="${x.direction === 'long' ? 'up' : 'down'}">${esc(T(`dir.${x.direction}`))}</span> ${esc(T(`exec.${x.execution}`))} <span class="mono">${fmtNum(x.entry, p)} / ${fmtNum(x.stop, p)} → ${x.targets.map((v) => fmtNum(v, p)).join(' · ')}</span>${x.mode !== 'live' ? ' <small class="muted">demo</small>' : ''}</td>
          <td><span class="badge sa-st sa-st-${x.status}">${esc(T(`history.status.${x.status}`))}${x.hits ? ` · TP${x.hits}` : ''}</span></td>
          <td class="mono">${x.resultR == null ? '—' : `${x.resultR > 0 ? '+' : ''}${fmtNum(x.resultR, 2)}R`}</td>
          <td><input class="input sa-note-in" data-note="${esc(x.id)}" maxlength="200" value="${esc(x.note || '')}" placeholder="${esc(T('history.notePh'))}" aria-label="${esc(T('history.note'))}"></td>
          <td><button type="button" class="btn btn-sm btn-ghost" data-del="${esc(x.id)}" aria-label="${esc(T('history.del'))}">${icons.trash || '×'}</button></td></tr>`; }).join('')}
      </tbody></table></div>
      <button type="button" class="btn btn-sm" data-csv>${icons.download || ''}<span>${esc(T('history.csv'))}</span></button>
      <button type="button" class="btn btn-sm" data-journal>${icons.journal || ''}<span>${esc(T('history.toJournal'))}</span></button>
      <h3 class="sa-h sa-bd-title">${esc(T('bd.title'))}</h3><div data-bd></div>` : `<p class="muted">${esc(T('history.empty'))}</p>`}`;
    const bd = body.querySelector('[data-bd]'); if (bd) renderBreakdown(bd);
    body.querySelector('[data-journal]')?.addEventListener('click', () => { const n = sendToJournal(); toast(n ? T('history.sentJournal', { n }) : T('history.nothingJournal'), n ? 'success' : 'info'); });
    body.querySelectorAll('[data-note]').forEach((inp) => inp.addEventListener('change', () => updateTrade(inp.dataset.note, { note: inp.value.slice(0, 200) })));
    body.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', () => { if (window.confirm(T('history.confirmDel'))) { removeTrade(b.dataset.del); draw(); } }));
    body.querySelector('[data-csv]')?.addEventListener('click', () => {
      const blob = new Blob([`﻿${tradesCsv(listTrades())}`], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'alphatrade-smc-ict-trades.csv'; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
    });
  };
  draw();
  pullTrades().then(() => { if (body.isConnected) draw(); });
  const off = onTrades(() => { if (body.isConnected) draw(); else off(); });
}
