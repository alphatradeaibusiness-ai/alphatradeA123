// v382 The bank's own sign-in, on top of the site account: when the owner approves an application the person gets a bank
// username and a one-time temporary password by e-mail. The temporary one works once, for 24 hours, and only to set their
// own password (scrypt-hashed here; nobody, the owner included, ever sees it). After that a bank session token
// (HMAC, 12 h, tied to the password version) opens the bank. Accounts approved before v382 have no row and are not asked.
import crypto from 'node:crypto';

const TEMP_MS = 24 * 3600_000, SESSION_MS = 12 * 3600_000, CHANGE_MS = 15 * 60_000, LOCK_AFTER = 5, LOCK_MS = 15 * 60_000;
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
export class LoginError extends Error { constructor(code, status = 400, extra = {}) { super(code); this.code = code; this.status = status; Object.assign(this, extra); } }

const scrypt = (pw, salt) => crypto.scryptSync(String(pw).normalize('NFKC'), salt, 32, { N: 16384, r: 8, p: 1 }).toString('base64url');
export function strongEnough(pw) {
  const s = String(pw || '');
  return s.length >= 10 && s.length <= 128 && /[a-z]/.test(s) && /[A-Z]/.test(s) && /\d/.test(s);
}
function tempPassword() {   // 3 groups, e.g. kQ7-mX2p-9Fa: 11 random characters (~64 bits)
  const b = crypto.randomBytes(11); const c = [...b].map((x) => ALPHA[x % ALPHA.length]).join('');
  return `${c.slice(0, 3)}-${c.slice(3, 7)}-${c.slice(7)}`;
}

export function createBankLogin({ db, secret, now = Date.now }) {
  db.exec(`CREATE TABLE IF NOT EXISTS bank_logins (uid TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE, salt TEXT NOT NULL, hash TEXT NOT NULL,
    temp INTEGER NOT NULL, temp_exp INTEGER, ver INTEGER NOT NULL, fails INTEGER NOT NULL DEFAULT 0, locked_until INTEGER, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)`);
  const key = crypto.createHash('sha256').update(`bank-login:${secret}`).digest();
  const sign = (s) => crypto.createHmac('sha256', key).update(s).digest('base64url');
  const row = (uid) => db.prepare('SELECT * FROM bank_logins WHERE uid = ?').get(uid);
  const token = (uid, ver, kind, ms) => { const exp = now() + ms; return `${kind}.${exp}.${sign(`${uid}|${ver}|${kind}|${exp}`)}`; };
  const tokenOk = (uid, t, kind) => {
    const [k, exp, mac] = String(t || '').split('.'); const r = row(uid);
    if (!r || k !== kind || !(Number(exp) > now())) return false;
    const want = sign(`${uid}|${r.ver}|${kind}|${exp}`);
    return mac?.length === want.length && crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(want));
  };

  /** New (or fresh) credentials for an approved person → { username, password } to e-mail once. */
  function issue(uid) {
    const old = row(uid); const pw = tempPassword(); const salt = crypto.randomBytes(16).toString('base64url'); const t = now();
    let username = old?.username;
    for (let i = 0; !username && i < 20; i++) { const u = `GT-${crypto.randomInt(10000, 100000)}`; if (!db.prepare('SELECT 1 FROM bank_logins WHERE username = ?').get(u)) username = u; }
    if (!username) username = `GT-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    db.prepare(`INSERT INTO bank_logins (uid, username, salt, hash, temp, temp_exp, ver, fails, locked_until, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, 1, 0, NULL, ?, ?)
      ON CONFLICT(uid) DO UPDATE SET salt = excluded.salt, hash = excluded.hash, temp = 1, temp_exp = excluded.temp_exp, ver = bank_logins.ver + 1, fails = 0, locked_until = NULL, updated_at = excluded.updated_at`)
      .run(uid, username, salt, scrypt(pw, salt), t + TEMP_MS, t, t);
    return { username, password: pw };
  }
  function state(uid) { const r = row(uid); return r ? { required: true, username: r.username, mustChange: Boolean(r.temp) } : { required: false }; }

  /** username + password → { token } for the bank, or { change } (a 15-minute ticket that only sets a new password). */
  function login(uid, username, password) {
    const r = row(uid); if (!r) throw new LoginError('no_bank_login', 404);
    if (r.locked_until > now()) throw new LoginError('login_locked', 429, { retryInS: Math.ceil((r.locked_until - now()) / 1000) });
    const good = String(username || '').trim().toUpperCase() === r.username.toUpperCase() && crypto.timingSafeEqual(Buffer.from(scrypt(password, r.salt)), Buffer.from(r.hash));
    if (!good) {
      const fails = r.fails + 1; const lock = fails >= LOCK_AFTER ? now() + LOCK_MS : null;
      db.prepare('UPDATE bank_logins SET fails = ?, locked_until = ? WHERE uid = ?').run(lock ? 0 : fails, lock, uid);
      throw new LoginError(lock ? 'login_locked' : 'bad_login', lock ? 429 : 401, { left: lock ? 0 : LOCK_AFTER - fails });
    }
    if (r.temp && !(r.temp_exp > now())) throw new LoginError('temp_expired', 401);
    db.prepare('UPDATE bank_logins SET fails = 0, locked_until = NULL WHERE uid = ?').run(uid);
    return r.temp ? { change: token(uid, r.ver, 'c', CHANGE_MS) } : { token: token(uid, r.ver, 's', SESSION_MS) };
  }
  /** Sets the person's own password with a change ticket (after the temporary one) or with a valid bank session. */
  function setPassword(uid, ticket, next) {
    const r = row(uid); if (!r) throw new LoginError('no_bank_login', 404);
    if (!tokenOk(uid, ticket, 'c') && !tokenOk(uid, ticket, 's')) throw new LoginError('bank_login_required', 401);
    if (!strongEnough(next)) throw new LoginError('weak_password', 400);
    const salt = crypto.randomBytes(16).toString('base64url');
    db.prepare('UPDATE bank_logins SET salt = ?, hash = ?, temp = 0, temp_exp = NULL, ver = ver + 1, fails = 0, locked_until = NULL, updated_at = ? WHERE uid = ?').run(salt, scrypt(next, salt), now(), uid);
    return { token: token(uid, r.ver + 1, 's', SESSION_MS) };
  }
  /** True when this person may use the bank now: no bank login yet (older accounts) or a valid session token. */
  const allowed = (uid, t) => !row(uid) || tokenOk(uid, t, 's');
  /** v383 a bank session after another strong proof (a passkey / fingerprint); not while the temporary password is unchanged. */
  function sessionFor(uid) { const r = row(uid); if (!r) throw new LoginError('no_bank_login', 404); if (r.temp) throw new LoginError('set_password_first', 403); return { token: token(uid, r.ver, 's', SESSION_MS) }; }
  /** v383 devices that signed in to the bank: true the first time a device is seen (not for the very first device). */
  db.exec('CREATE TABLE IF NOT EXISTS bank_devices (uid TEXT NOT NULL, dev TEXT NOT NULL, first_at INTEGER NOT NULL, PRIMARY KEY (uid, dev))');
  function newDevice(uid, ua, ip) {
    const dev = crypto.createHmac('sha256', key).update(`${String(ua || '').slice(0, 300)}|${String(ip || '').split(/[.:]/).slice(0, 3).join('.')}`).digest('base64url').slice(0, 22);
    const known = db.prepare('SELECT COUNT(*) n FROM bank_devices WHERE uid = ?').get(uid).n;
    const r = db.prepare('INSERT OR IGNORE INTO bank_devices (uid, dev, first_at) VALUES (?, ?, ?)').run(uid, dev, now());
    return r.changes > 0 && known > 0;
  }
  /** v384 who has this bank username (for member transfers). */
  const uidOf = (username) => db.prepare('SELECT uid FROM bank_logins WHERE username = ? COLLATE NOCASE').get(String(username || '').trim())?.uid || null;
  return { issue, state, login, setPassword, allowed, sessionFor, newDevice, uidOf };
}
