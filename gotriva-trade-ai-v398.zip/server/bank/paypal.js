// v383 PayPal deposits through PayPal's Orders API (the company's PayPal business account). Off until PAYPAL_CLIENT_ID and
// PAYPAL_CLIENT_SECRET are set on the server; PAYPAL_MODE=live uses live PayPal, anything else the PayPal sandbox.
// Flow: the server creates an order → the person approves it on PayPal → back on the site the page asks the server to
// capture it → the server checks the captured amount, currency and that the order is this person's, then credits once.
export function createPaypal({ env = process.env, fetchImpl = fetch, base = '' } = {}) {
  const id = String(env.PAYPAL_CLIENT_ID || '').trim(); const secret = String(env.PAYPAL_CLIENT_SECRET || '').trim();
  if (!id || !secret) return null;
  const api = base || (env.PAYPAL_MODE === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com');
  let tok = null;
  async function token() {
    if (tok && tok.exp > Date.now() + 60_000) return tok.v;
    const r = await fetchImpl(`${api}/v1/oauth2/token`, { method: 'POST', headers: { Authorization: `Basic ${Buffer.from(`${id}:${secret}`).toString('base64')}`, 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'grant_type=client_credentials', signal: AbortSignal.timeout(10_000) });
    const j = await r.json().catch(() => ({})); if (!r.ok || !j.access_token) throw Object.assign(new Error('paypal_auth'), { code: 'paypal_unavailable' });
    tok = { v: j.access_token, exp: Date.now() + (Number(j.expires_in) || 300) * 1000 }; return tok.v;
  }
  async function call(method, path, body, idem) {
    const r = await fetchImpl(`${api}${path}`, { method, headers: { Authorization: `Bearer ${await token()}`, 'Content-Type': 'application/json', ...(idem ? { 'PayPal-Request-Id': idem } : {}) }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(15_000) });
    const j = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error('paypal'), { code: r.status === 422 ? 'paypal_declined' : 'paypal_unavailable' }); return j;
  }
  return {
    mode: env.PAYPAL_MODE === 'live' ? 'live' : 'sandbox',
    /** → { orderId, approveUrl } */
    async order({ uid, cents, origin }) {
      const j = await call('POST', '/v2/checkout/orders', {
        intent: 'CAPTURE', purchase_units: [{ custom_id: uid, description: 'GOTRIVA digital bank top-up', amount: { currency_code: 'USD', value: (cents / 100).toFixed(2) } }],
        payment_source: { paypal: { experience_context: { brand_name: 'GOTRIVA TRADE AI', user_action: 'PAY_NOW', shipping_preference: 'NO_SHIPPING', return_url: `${origin}/#/app/bank?paypal=return`, cancel_url: `${origin}/#/app/bank?paypal=cancel` } } },
      }, `gt-${uid}-${cents}-${Date.now()}`);
      const link = (j.links || []).find((l) => l.rel === 'payer-action' || l.rel === 'approve');
      if (!j.id || !link?.href) throw Object.assign(new Error('paypal'), { code: 'paypal_unavailable' });
      return { orderId: j.id, approveUrl: link.href };
    },
    /** Captures an approved order → { uid, cents, captureId } as PayPal reports them (the caller checks them). */
    async capture(orderId) {
      if (!/^[A-Z0-9]{8,40}$/.test(String(orderId || ''))) throw Object.assign(new Error('bad'), { code: 'bad_order' });
      const j = await call('POST', `/v2/checkout/orders/${orderId}/capture`, {}, `cap-${orderId}`);
      const pu = j.purchase_units?.[0]; const cap = pu?.payments?.captures?.[0];
      if (j.status !== 'COMPLETED' || cap?.status !== 'COMPLETED' || cap.amount?.currency_code !== 'USD') throw Object.assign(new Error('paypal'), { code: 'paypal_not_completed' });
      return { uid: cap.custom_id || pu.custom_id || '', cents: Math.round(Number(cap.amount.value) * 100), captureId: cap.id };
    },
  };
}
