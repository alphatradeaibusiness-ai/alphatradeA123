// v385 Invoices and receipts from the ledger: every money movement of a person gets a receipt (RC-YYYY-NNNNNN), every fee
// paid to GOTRIVA an invoice (INV-YYYY-NNNNNN). Numbers are sequential per year and assigned once (first time listed), so
// they never change. Each document has a verification code (HMAC of its number) anyone can check without seeing personal data.
import crypto from 'node:crypto';

const RECEIPT = ['deposit', 'withdrawal', 'partner_commission', 'sandbox_credit', 'fx_out', 'fx_in', 'invest_buy', 'invest_sell', 'cashback', 'card_purchase', 'card_refund', 'deposit_reversal', 'transfer_out', 'transfer_in', 'purchase_refund'];
const INVOICE = ['card_fee', 'purchase'];

export function createDocuments({ db, secret, now = Date.now }) {
  db.exec(`CREATE TABLE IF NOT EXISTS bank_docs (txn TEXT PRIMARY KEY, kind TEXT NOT NULL, year INTEGER NOT NULL, seq INTEGER NOT NULL, created_at INTEGER NOT NULL, code TEXT, UNIQUE (kind, year, seq)); CREATE INDEX IF NOT EXISTS bank_docs_code ON bank_docs (code)`);
  const key = crypto.createHash('sha256').update(`bank-docs:${secret}`).digest();
  const numberOf = (d) => `${d.kind === 'invoice' ? 'INV' : 'RC'}-${d.year}-${String(d.seq).padStart(6, '0')}`;
  const codeOf = (no) => { const h = crypto.createHmac('sha256', key).update(no).digest('hex').toUpperCase(); return `${h.slice(0, 4)}-${h.slice(4, 8)}-${h.slice(8, 12)}`; };
  const assign = db.prepare('INSERT OR IGNORE INTO bank_docs (txn, kind, year, seq, created_at) VALUES (?, ?, ?, (SELECT COALESCE(MAX(seq), 0) + 1 FROM bank_docs WHERE kind = ? AND year = ?), ?)');

  /** The person's documents, newest first (at most 200). */
  function list(uid) {
    const types = [...RECEIPT, ...INVOICE];
    const rows = db.prepare(`SELECT id, type, status, currency, amount, ext_ref, meta, created_at FROM txns WHERE uid = ? AND type IN (${types.map(() => '?').join(',')}) ORDER BY created_at DESC, rowid DESC LIMIT 200`).all(uid, ...types);
    db.exec('BEGIN IMMEDIATE');
    try {
      for (const r of [...rows].reverse()) { const kind = INVOICE.includes(r.type) ? 'invoice' : 'receipt'; const y = new Date(r.created_at).getUTCFullYear(); assign.run(r.id, kind, y, kind, y, now()); }
      for (const d of db.prepare('SELECT * FROM bank_docs WHERE code IS NULL').all()) db.prepare('UPDATE bank_docs SET code = ? WHERE txn = ?').run(codeOf(numberOf(d)).replace(/-/g, ''), d.txn);
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
    const get = db.prepare('SELECT * FROM bank_docs WHERE txn = ?');
    return rows.map((r) => {
      const d = get.get(r.id); const no = numberOf(d); let meta = {}; try { meta = JSON.parse(r.meta || '{}'); } catch { /* */ }
      return { number: no, kind: d.kind, verify: codeOf(no), txn: r.id, type: r.type, status: r.status, currency: r.currency, amount: r.amount, at: r.created_at, ref: r.ext_ref || '', fee: meta.fee || 0, provider: meta.provider || '', product: meta.product || '', note: meta.note || '', test: r.type === 'sandbox_credit' };
    });
  }
  /** Public check: is this document real? → minimal facts only (no name, no account). */
  function verify(code) {
    const c = String(code || '').toUpperCase().replace(/[^0-9A-F]/g, ''); if (c.length !== 12) return { valid: false };
    const d = db.prepare('SELECT d.*, t.currency, t.amount, t.created_at AS at FROM bank_docs d JOIN txns t ON t.id = d.txn WHERE d.code = ?').get(c);
    return d ? { valid: true, number: numberOf(d), currency: d.currency, amount: d.amount, at: d.at } : { valid: false };
  }
  return { list, verify, numberOf, codeOf };
}
