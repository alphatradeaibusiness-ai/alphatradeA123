// Notification centre + Web Push. Every notification is written AFTER the money change it reports has committed, so the
// user is never told about something that did not happen. Params hold ids, amounts and kinds only — no personal data.
// Security notifications cannot be switched off. Push is optional, per device, and can hide amounts on the lock screen.
import crypto from 'node:crypto';
import { fromMinor } from '../money.js';
import { generateVapid, cleanSubscription } from '../webpush.js';
import { bad } from '../validate.js';
import { tradeAlert } from '../../../src/services/tradeMessages.js';

export const GROUPS = { money: 1, cards: 1, planning: 1, rewards: 1, support: 1, kyc: 1, trading: 1, security: 0 };   // 0 = always on
export const KIND_GROUP = {
  partner_commission: 'money', deposit_confirmed: 'money', deposit_rejected: 'money', withdrawal_approved: 'money', withdrawal_rejected: 'money', withdrawal_completed: 'money',
  vault_released: 'money', converted: 'money', intl_quoted: 'money',
  card_purchase: 'cards', card_declined: 'cards', card_status: 'cards', card_refund: 'cards',
  budget_80: 'planning', budget_100: 'planning', subscription_due: 'planning', plan_skipped: 'planning', save_skipped: 'planning',
  points_earned: 'rewards', points_expiring: 'rewards', points_redeemed: 'rewards',
  ticket_reply: 'support', kyc_approved: 'kyc', kyc_rejected: 'kyc',
  trade_filled: 'trading', trade_target: 'trading', trade_done: 'trading', trade_stopped: 'trading', trade_breakeven: 'trading', trade_expired: 'trading', trade_missed: 'trading',
  passkey_added: 'security', passkey_removed: 'security', beneficiary_added: 'security', frozen: 'security', unfrozen: 'security',
  approval_needed: 'security', approval_result: 'security', vault_release_started: 'security', policy_changed: 'security', approver_added: 'security',
  money_request: 'money', pot_invite: 'money', pot_done: 'money', pot_cancelled: 'money', pot_reminder: 'money', request_paid: 'money', renew_done: 'money', renew_failed: 'money', renew_reminder: 'money', gift_redeemed: 'money', withdrawal_requested: 'money', transfer_sent: 'money', transfer_received: 'money', gift_bought: 'money', gift_received: 'money', pot_paid: 'money',   // v390 / v393
  ob_linked: 'security', security_changed: 'security', fraud_alert: 'security',
};
const T = {
  ar: {
    trade_filled: 'تفعّلت صفقة {symbol}', trade_target: '{symbol}: وصل الهدف {n}', trade_done: '{symbol}: كل الأهداف تحققت ({r}R)', trade_stopped: '{symbol}: ضرب الوقف ({r}R)', trade_breakeven: '{symbol}: طلعت على الدخول ({r}R)', trade_expired: '{symbol}: أمر الليميت انتهى بدون تفعيل', trade_missed: '{symbol}: السعر راح للهدف بدون ما يفعّل الأمر',
    title_trading: 'GOTRIVA TRADE · صفقاتي',
    withdrawal_requested: 'استلمنا طلب سحب {amt}', transfer_sent: 'حوّلت {amt} لـ {name}', transfer_received: 'وصلك {amt} من {name}', gift_bought: 'اشتريت بطاقة هدية {amt}', gift_received: 'وصلتك هدية {amt} من {name}', pot_paid: 'دفعت حصتك {amt} بصندوق «{merchant}»',
    gift_redeemed: '{name} استعمل بطاقة الهدية تبعتك ({amt})', money_request: '{name} طالب منك {amt}', request_paid: '{name} دفعلك {amt}', pot_invite: '{name} ضافك على صندوق «{merchant}»: حصتك {amt}', pot_reminder: 'تذكير: حصتك {amt} بصندوق «{merchant}»', pot_done: 'كمل صندوق «{merchant}» ونزل {amt} على محفظتك', pot_cancelled: 'انلغى صندوق «{merchant}» ورجعتلك حصتك',
    renew_done: 'تجدد اشتراكك من رصيدك ({amt})', renew_failed: 'ما قدرنا نجدد اشتراكك من الرصيد ({amt})، رصيدك ما بيكفي', renew_reminder: 'اشتراكك بيتجدد بعد 3 أيام ({amt}) ورصيدك ما بيكفي',
    partner_commission: 'وصلتك عمولة شريك {amt} على محفظتك', deposit_confirmed: 'وصل إيداع {amt}', deposit_rejected: 'انرفض طلب إيداع', withdrawal_approved: 'انوافق على سحب {amt}', withdrawal_rejected: 'انرفض سحب ورجع المبلغ',
    withdrawal_completed: 'انبعت سحب {amt}', vault_released: 'انفتح من الخزنة {amt}', converted: 'تحويل عملة {amt}', intl_quoted: 'تحويل دولي',
    card_purchase: 'شراء بالبطاقة {amt} · {merchant}', card_declined: 'انرفضت عملية بالبطاقة · {merchant}', card_status: 'تحديث على البطاقة', card_refund: 'استرجاع {amt} · {merchant}',
    budget_80: 'صرفت 80% من ميزانية {category}', budget_100: 'خلصت ميزانية {category}', subscription_due: 'اشتراك {merchant} بيتجدد قريب ({amt})',
    plan_skipped: 'خطة استثمار انتخطت', save_skipped: 'قاعدة ادخار انتخطت', points_earned: 'كسبت {pts} نقطة', points_expiring: '{pts} نقطة بتنتهي قريب', points_redeemed: 'استبدلت {pts} نقطة',
    ticket_reply: 'في رد على تذكرة الدعم', kyc_approved: 'انوثّق حسابك (مستوى {tier})', kyc_rejected: 'انرفض طلب التوثيق',
    passkey_added: 'انضافت بصمة جديدة لحسابك', passkey_removed: 'انشالت بصمة من حسابك', beneficiary_added: 'انضاف حساب سحب جديد', frozen: 'تجمّد حسابك', unfrozen: 'انفك تجميد حسابك',
    approval_needed: 'في طلب بحاجة موافقتك', approval_result: 'نتيجة طلب الموافقة: {result}', vault_release_started: 'بدأ فتح الخزنة ({amt}) — بتقدر تلغي', policy_changed: 'تغيّرت سياسة الموافقات', approver_added: 'انضاف موقّع جديد',
    ob_linked: 'انربط حساب بنك خارجي', security_changed: 'تغيّرت إعدادات أمان حسابك (المصادقة الثنائية)', fraud_alert: 'وقّفنا عملية مشبوهة على حسابك — راجعها', title: 'GOTRIVA TRADE · البنك', hidden: '••••',
  },
  en: {
    trade_filled: '{symbol} trade filled', trade_target: '{symbol}: target {n} reached', trade_done: '{symbol}: all targets hit ({r}R)', trade_stopped: '{symbol}: stop hit ({r}R)', trade_breakeven: '{symbol}: closed at entry ({r}R)', trade_expired: '{symbol}: limit order expired unfilled', trade_missed: '{symbol}: price reached the target without filling the order',
    title_trading: 'GOTRIVA TRADE · My trades',
    withdrawal_requested: 'Withdrawal request received: {amt}', transfer_sent: 'You sent {amt} to {name}', transfer_received: 'You received {amt} from {name}', gift_bought: 'You bought a {amt} gift card', gift_received: 'You received a {amt} gift from {name}', pot_paid: 'You paid your {amt} share in «{merchant}»',
    gift_redeemed: '{name} redeemed your gift card ({amt})', money_request: '{name} requested {amt} from you', request_paid: '{name} paid you {amt}', pot_invite: '{name} added you to the pot «{merchant}»: your share {amt}', pot_reminder: 'Reminder: your share {amt} in «{merchant}»', pot_done: 'The pot «{merchant}» is complete: {amt} is in your wallet', pot_cancelled: 'The pot «{merchant}» was cancelled and your share returned',
    renew_done: 'Plan renewed from your balance ({amt})', renew_failed: 'Could not renew from your balance ({amt}): not enough money', renew_reminder: 'Your plan renews in 3 days ({amt}) and your balance is short',
    partner_commission: 'Partner commission received in your wallet: {amt}', deposit_confirmed: 'Deposit received: {amt}', deposit_rejected: 'A deposit request was rejected', withdrawal_approved: 'Withdrawal approved: {amt}', withdrawal_rejected: 'Withdrawal rejected, money returned',
    withdrawal_completed: 'Withdrawal sent: {amt}', vault_released: 'Released from vault: {amt}', converted: 'Currency converted: {amt}', intl_quoted: 'International transfer',
    card_purchase: 'Card purchase {amt} · {merchant}', card_declined: 'Card payment declined · {merchant}', card_status: 'Card update', card_refund: 'Refund {amt} · {merchant}',
    budget_80: '80% of your {category} budget is spent', budget_100: 'Your {category} budget is used up', subscription_due: '{merchant} renews soon ({amt})',
    plan_skipped: 'An investment plan was skipped', save_skipped: 'A saving rule was skipped', points_earned: 'You earned {pts} points', points_expiring: '{pts} points expire soon', points_redeemed: 'You redeemed {pts} points',
    ticket_reply: 'Support replied to your ticket', kyc_approved: 'Identity verified (level {tier})', kyc_rejected: 'Identity check rejected',
    passkey_added: 'A new passkey was added to your account', passkey_removed: 'A passkey was removed from your account', beneficiary_added: 'A new withdrawal account was added', frozen: 'Your account is frozen', unfrozen: 'Your account is unfrozen',
    approval_needed: 'A request needs your approval', approval_result: 'Approval result: {result}', vault_release_started: 'Vault release started ({amt}) — you can cancel', policy_changed: 'Approval policy changed', approver_added: 'A new co-signer was added',
    security_changed: 'Your account security settings changed (two-factor)', fraud_alert: 'We stopped a suspicious operation on your account — please review', ob_linked: 'An external bank account was linked', title: 'GOTRIVA TRADE · Bank', hidden: '••••',
  },
};

export function createNotify(ctx) {
  const { db, now, ping, seal, open, rid } = ctx;
  const queue = [];
  let sending = false;

  function prefs(uid) {
    const r = db.prepare('SELECT prefs FROM user_flags WHERE uid = ?').get(uid);
    let p = {}; try { p = JSON.parse(r?.prefs || '{}') || {}; } catch { p = {}; }
    const groups = {}; for (const g of Object.keys(GROUPS)) groups[g] = GROUPS[g] === 0 ? true : p.groups?.[g] !== false;
    return { groups, push: p.push !== false, hideAmounts: p.hideAmounts === true, lang: p.lang === 'en' ? 'en' : 'ar' };
  }
  function setPrefs(uid, i) {
    const cur = prefs(uid);
    const groups = { ...cur.groups };
    if (i.groups && typeof i.groups === 'object') for (const g of Object.keys(GROUPS)) if (GROUPS[g] && typeof i.groups[g] === 'boolean') groups[g] = i.groups[g];
    const next = { groups, push: typeof i.push === 'boolean' ? i.push : cur.push, hideAmounts: typeof i.hideAmounts === 'boolean' ? i.hideAmounts : cur.hideAmounts, lang: i.lang === 'en' ? 'en' : i.lang === 'ar' ? 'ar' : cur.lang };
    db.prepare('INSERT INTO user_flags (uid, prefs) VALUES (?, ?) ON CONFLICT(uid) DO UPDATE SET prefs = excluded.prefs').run(uid, JSON.stringify(next));
    return prefs(uid);
  }
  // A trade event with its prices gets the short alert ("Take Profit 1 Smashed! 🎯 …"); anything else keeps the plain line.
  const TRADE_ALERT = { trade_target: 'tp', trade_done: 'final', trade_stopped: 'sl', trade_breakeven: 'be' };
  const tradeMsg = (lang, kind, p) => {
    if (!TRADE_ALERT[kind]) return null;
    const d = { symbol: p.symbol, direction: p.direction === 'short' ? 'short' : 'long', n: kind === 'trade_breakeven' ? Number(p.hits) || 0 : Number(p.n) || 0, price: p.price, entry: p.entry, stop: p.stop };
    return tradeAlert(TRADE_ALERT[kind], d, lang);
  };
  const text = (lang, kind, params, hide) => {
    const tm = tradeMsg(lang, kind, params);
    if (tm) return `${tm.title} ${tm.body}`;
    const t = T[lang] || T.ar; let s = t[kind] || kind;
    const amt = params.amount != null && params.currency ? `${fromMinor(params.amount, params.currency)} ${params.currency}` : '';
    s = s.replace('{amt}', hide ? t.hidden : amt).replace('{merchant}', String(params.merchant || '').slice(0, 40)).replace('{category}', String(params.category || '')).replace('{name}', String(params.name || '').slice(0, 30))
      .replace('{pts}', String(params.pts ?? '')).replace('{tier}', String(params.tier ?? '')).replace('{result}', String(params.result || ''))
      .replace('{symbol}', String(params.symbol || '').slice(0, 15)).replace('{n}', String(params.n ?? '')).replace('{r}', params.r == null ? '' : String(params.r));
    return s;
  };

  /** Call AFTER the change committed. Never throws (a notification must not undo or block money). */
  let mailHook = null;
  const NO_MAIL = new Set(['kyc_approved', 'kyc_rejected', 'points_earned']);   // KYC has its own e-mails; points are too frequent
  function notify(uid, kind, params = {}) {
    try {
      const group = KIND_GROUP[kind] || 'money'; const p = prefs(uid);
      if (!p.groups[group]) return;
      const clean = {}; for (const [k, v] of Object.entries(params)) if (['amount', 'currency', 'merchant', 'category', 'pts', 'tier', 'result', 'id', 'symbol', 'n', 'r', 'direction', 'entry', 'stop', 'price', 'hits', 'name'].includes(k)) clean[k] = typeof v === 'string' ? v.slice(0, 60) : v;
      db.prepare('INSERT INTO notifications (id, uid, kind, params, created_at) VALUES (?,?,?,?,?)').run(rid('ntf'), uid, kind, JSON.stringify(clean), now());
      db.prepare('DELETE FROM notifications WHERE uid = ? AND id NOT IN (SELECT id FROM notifications WHERE uid = ? ORDER BY created_at DESC LIMIT 200)').run(uid, uid);
      ping(uid, 'notify');
      if (mailHook && !NO_MAIL.has(kind) && group !== 'trading') { try { mailHook(uid, kind, clean, p.lang); } catch { /* the e-mail never blocks money */ } }   // v393 every money / security event also by e-mail
      if (p.push && ctx.pushSender) {
        const subs = db.prepare('SELECT id, sub FROM push_subs WHERE uid = ?').all(uid);
        for (const s of subs) queue.push({ subId: s.id, uid, sealed: s.sub, payload: group === 'trading' ? { ...(tradeMsg(p.lang, kind, clean) || { title: T[p.lang].title_trading, body: text(p.lang, kind, clean, false) }), tag: `trade-${clean.id || kind}`, url: '/#/app' } : { title: T[p.lang].title, body: text(p.lang, kind, clean, p.hideAmounts), tag: kind, url: '/#/app/bank' } });
        drain();
      }
    } catch (e) { console.error('[bank] notify failed:', e?.name, String(e?.message || '').slice(0, 80)); }
  }
  async function drain() {
    if (sending) return; sending = true;
    try {
      while (queue.length) {
        const j = queue.shift();
        try {
          const sub = open(j.sealed, `push:${j.uid}`);
          const r = await ctx.pushSender(sub, j.payload, vapid());
          if (r?.gone) db.prepare('DELETE FROM push_subs WHERE id = ?').run(j.subId);
        } catch { /* a push service error never affects the bank */ }
      }
    } finally { sending = false; }
  }
  const pending = () => queue.length + (sending ? 1 : 0);

  let vapidCache = null;
  function vapid() {
    if (vapidCache) return vapidCache;
    const row = db.prepare("SELECT v FROM meta WHERE k = 'vapid'").get();
    if (row) vapidCache = open(row.v, 'meta:vapid');
    else { vapidCache = generateVapid(); db.prepare("INSERT OR IGNORE INTO meta (k, v) VALUES ('vapid', ?)").run(seal(vapidCache, 'meta:vapid')); vapidCache = open(db.prepare("SELECT v FROM meta WHERE k = 'vapid'").get().v, 'meta:vapid'); }
    return vapidCache;
  }
  function subscribe(uid, sub) {
    const s = cleanSubscription(sub, { testBase: ctx.pushTestBase || '' }) ?? bad('bad_subscription');
    const hash = crypto.createHash('sha256').update(s.endpoint).digest('hex');
    if (db.prepare('SELECT COUNT(*) c FROM push_subs WHERE uid = ?').get(uid).c >= 10) bad('too_many_devices', 429);
    db.prepare('DELETE FROM push_subs WHERE endpoint_hash = ?').run(hash);   // one endpoint = one device = one owner
    db.prepare('INSERT INTO push_subs (id, uid, endpoint_hash, sub, created_at) VALUES (?,?,?,?,?)').run(rid('psh'), uid, hash, seal(s, `push:${uid}`), now());
    return { ok: true, devices: db.prepare('SELECT COUNT(*) c FROM push_subs WHERE uid = ?').get(uid).c };
  }
  function unsubscribe(uid, endpoint) {
    const hash = crypto.createHash('sha256').update(String(endpoint || '')).digest('hex');
    const r = db.prepare('DELETE FROM push_subs WHERE uid = ? AND endpoint_hash = ?').run(uid, hash);
    return { ok: true, removed: r.changes };
  }
  const list = (uid, { limit = 50 } = {}) => ({
    items: db.prepare('SELECT id, kind, params, read, created_at FROM notifications WHERE uid = ? ORDER BY created_at DESC LIMIT ?').all(uid, Math.min(100, Math.max(1, limit | 0))).map((n) => ({ ...n, params: JSON.parse(n.params), read: Boolean(n.read) })),
    unread: db.prepare('SELECT COUNT(*) c FROM notifications WHERE uid = ? AND read = 0').get(uid).c,
  });
  const markRead = (uid) => { db.prepare('UPDATE notifications SET read = 1 WHERE uid = ? AND read = 0').run(uid); return { ok: true }; };

  /** Push only (no bank notification row) — used by the members features: sign-in alerts, news, TradingView. Returns the number of devices. */
  function pushOnly(uid, { title, body, url = '/#/app', tag = 'gotriva', icon = null }) {
    try {
      if (!ctx.pushSender || prefs(uid).push === false) return 0;
      const subs = db.prepare('SELECT id, sub FROM push_subs WHERE uid = ?').all(uid);
      for (const s of subs) queue.push({ subId: s.id, uid, sealed: s.sub, payload: { title: String(title).slice(0, 120), body: String(body).slice(0, 300), tag: String(tag).slice(0, 40), url: String(url).startsWith('/#/') ? url : '/#/app', ...(typeof icon === 'string' && /^\/[a-z0-9/_-]+\.png$/.test(icon) ? { icon } : {}) } });
      if (subs.length) drain();
      return subs.length;
    } catch { return 0; }
  }
  return { setMailHook: (fn) => { mailHook = typeof fn === 'function' ? fn : null; }, notify, pushOnly, prefs, setPrefs, subscribe, unsubscribe, list, markRead, vapidPublicKey: () => vapid().publicKey, pendingPushes: pending, text };
}
