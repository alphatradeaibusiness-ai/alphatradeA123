// v390 money between members: recent people, money requests, shared pots, and the «renew my plan from the balance» setting.
// Every move is a normal balanced ledger transaction. Requests are paid through the same p2p transfer (same limits, same
// checks). A pot keeps the shares in its own system account until everyone paid: then it goes to the creator's wallet; if the
// creator cancels first, every paid share goes back. Nothing here creates money or touches another member's balance directly.
import { bad, str } from '../validate.js';
import crypto from 'node:crypto';
import { toMinor } from '../money.js';

const DAY = 86_400_000;

export const SOCIAL_SQL = `
CREATE TABLE IF NOT EXISTS pay_requests (id TEXT PRIMARY KEY, from_uid TEXT NOT NULL, to_uid TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL, status TEXT NOT NULL, txn TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS pay_requests_to ON pay_requests (to_uid, status);
CREATE INDEX IF NOT EXISTS pay_requests_from ON pay_requests (from_uid, created_at);
CREATE TABLE IF NOT EXISTS pots (id TEXT PRIMARY KEY, uid TEXT NOT NULL, name TEXT NOT NULL, share INTEGER NOT NULL, status TEXT NOT NULL, reminded_at INTEGER, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS pot_members (pot_id TEXT NOT NULL, uid TEXT NOT NULL, paid INTEGER NOT NULL DEFAULT 0, txn TEXT, PRIMARY KEY (pot_id, uid));
CREATE INDEX IF NOT EXISTS pot_members_uid ON pot_members (uid);
CREATE TABLE IF NOT EXISTS gift_cards (id TEXT PRIMARY KEY, code_hash TEXT NOT NULL UNIQUE, code TEXT NOT NULL, buyer TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL, status TEXT NOT NULL, redeemed_by TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS gift_cards_buyer ON gift_cards (buyer, created_at);
CREATE TABLE IF NOT EXISTS auto_renew (uid TEXT PRIMARY KEY, on_ INTEGER NOT NULL, reminded_for INTEGER, renewed_for INTEGER, updated_at INTEGER NOT NULL);
`;

/** What the renewal runner should do for one member now: 'renew' (in the last 24 h), 'remind' (3 days before, balance short) or null. */
export function renewAction({ on, until, price, balance, remindedFor, renewedFor }, t) {
  if (!on || !(until > t) || !(price > 0)) return null;
  if (until - t <= DAY) return renewedFor === until ? null : 'renew';
  if (until - t <= 3 * DAY && balance < price && remindedFor !== until) return 'remind';
  return null;
}

export function createSocial(ctx, { p2p, shortName }) {
  const { db, L, A, now, rid, commit, cfg, tier, needTier, seal, open } = ctx;
  db.exec(SOCIAL_SQL);
  const money = (v) => { const a = toMinor(v, 'USD') ?? bad('bad_amount'); if (a < 100) bad('below_minimum'); if (a > cfg.p2pMax) bad('p2p_limit_exceeded', 403); return a; };
  const note = (v) => (v ? str(v, { max: 60, code: 'bad_note' }) : '');
  const say = (uid, kind, p) => { try { ctx.notify(uid, kind, p); } catch { /* a missed notice never undoes money */ } };

  /** The last people this member sent money to (newest first): for the quick «send again» row. */
  function recent(uid, n = 6) {
    return db.prepare("SELECT json_extract(meta, '$.to') AS to_uid, MAX(created_at) AS at FROM txns WHERE uid = ? AND type = 'transfer_out' AND json_extract(meta, '$.to') IS NOT NULL GROUP BY to_uid ORDER BY at DESC LIMIT ?")
      .all(uid, n).map((r) => r.to_uid).filter((u) => tier(u) >= 1);
  }

  /* ── money requests ── */
  function request(uid, toUid, i = {}) {
    needTier(uid, 1); ctx.security.assertNotFrozen(uid);
    if (!toUid || toUid === uid) bad('bad_recipient'); if (tier(toUid) < 1) bad('recipient_unavailable', 409);
    const amount = money(i.amount); const n = note(i.note); const t = now();
    const r = commit(() => {
      if (db.prepare("SELECT COUNT(*) c FROM pay_requests WHERE from_uid = ? AND created_at > ?").get(uid, t - DAY).c >= 10) bad('velocity_limit', 429);
      if (db.prepare("SELECT COUNT(*) c FROM pay_requests WHERE from_uid = ? AND to_uid = ? AND status = 'pending'").get(uid, toUid).c >= 3) bad('too_many', 429);
      const id = rid('req');
      db.prepare('INSERT INTO pay_requests (id, from_uid, to_uid, amount, note, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)').run(id, uid, toUid, amount, n, 'pending', t, t);
      A.log(uid, 'request.create', id, { amount }); return { id, amount, note: n };
    }, uid);
    say(toUid, 'money_request', { amount, currency: 'USD', name: shortName(uid) });
    return r;
  }
  const expire = () => db.prepare("UPDATE pay_requests SET status = 'expired', updated_at = ? WHERE status = 'pending' AND created_at < ?").run(now(), now() - 7 * DAY);
  function requests(uid) {
    expire();
    const v = (r, other) => ({ id: r.id, amount: r.amount, note: r.note, status: r.status, at: r.created_at, other });
    return { incoming: db.prepare("SELECT * FROM pay_requests WHERE to_uid = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 20").all(uid).map((r) => v(r, r.from_uid)),
      outgoing: db.prepare('SELECT * FROM pay_requests WHERE from_uid = ? ORDER BY created_at DESC LIMIT 20').all(uid).map((r) => v(r, r.to_uid)) };
  }
  const reqOf = (id) => db.prepare('SELECT * FROM pay_requests WHERE id = ?').get(String(id || '')) ?? bad('not_found', 404);
  /** Pays a request through the normal p2p transfer. The transfer's key is the request id, so a retry can never pay twice. */
  function payRequest(uid, id) {
    expire(); const q = reqOf(id); if (q.to_uid !== uid) bad('not_found', 404);
    if (q.status === 'paid') return { ok: true, txn: q.txn, replay: true }; if (q.status !== 'pending') bad('request_closed', 409);
    const r = p2p(uid, q.from_uid, { amount: (q.amount / 100).toFixed(2), note: q.note, idem: `rq-${q.id}` }, { quietIn: true });   // the requester gets «your request was paid» instead
    db.prepare("UPDATE pay_requests SET status = 'paid', txn = ?, updated_at = ? WHERE id = ? AND status = 'pending'").run(r.txn, now(), q.id);
    if (!r.replay) say(q.from_uid, 'request_paid', { amount: q.amount, currency: 'USD', name: shortName(uid) });
    return { ok: true, txn: r.txn };
  }
  function closeRequest(uid, id, act) {
    const q = reqOf(id); if (q.status !== 'pending') bad('request_closed', 409);
    if (act === 'decline' ? q.to_uid !== uid : q.from_uid !== uid) bad('not_found', 404);
    db.prepare('UPDATE pay_requests SET status = ?, updated_at = ? WHERE id = ?').run(act === 'decline' ? 'declined' : 'cancelled', now(), q.id);
    A.log(uid, `request.${act}`, q.id, {}); return { ok: true };
  }

  /* ── shared pots ── */
  const potAcc = (id) => L.sys(`pot:${id}`, 'USD');
  const potOf = (id) => db.prepare('SELECT * FROM pots WHERE id = ?').get(String(id || '')) ?? bad('not_found', 404);
  const membersOf = (id) => db.prepare('SELECT * FROM pot_members WHERE pot_id = ? ORDER BY rowid').all(id);
  function potView(p) {
    const ms = membersOf(p.id); const paid = ms.filter((m) => m.paid).length;
    return { id: p.id, name: p.name, share: p.share, target: p.share * ms.length, collected: p.share * paid, status: p.status, at: p.created_at,
      creator: p.uid, members: ms.map((m) => ({ uid: m.uid, paid: Boolean(m.paid) })) };
  }
  function createPot(uid, i = {}, toUids = []) {
    needTier(uid, 1); ctx.security.assertNotFrozen(uid);
    const name = str(i.name, { max: 40, code: 'bad_name' }); const share = money(i.share);
    const others = [...new Set(toUids)].filter((u) => u && u !== uid);
    if (others.length < 1 || others.length > 9 || others.length !== toUids.length) bad('bad_members');
    if (others.some((u) => tier(u) < 1)) bad('recipient_unavailable', 409);
    const t = now();
    const id = commit(() => {
      if (db.prepare("SELECT COUNT(*) c FROM pots WHERE uid = ? AND status = 'open'").get(uid).c >= 5) bad('too_many', 429);
      const pid = rid('pot');
      db.prepare('INSERT INTO pots (id, uid, name, share, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?)').run(pid, uid, name, share, 'open', t, t);
      for (const u of [uid, ...others]) db.prepare('INSERT INTO pot_members (pot_id, uid) VALUES (?,?)').run(pid, u);
      A.log(uid, 'pot.create', pid, { share, members: others.length + 1 }); return pid;
    }, uid);
    for (const u of others) say(u, 'pot_invite', { amount: share, currency: 'USD', merchant: name, name: shortName(uid) });
    return potView(potOf(id));
  }
  const pots = (uid) => db.prepare("SELECT p.* FROM pots p JOIN pot_members m ON m.pot_id = p.id WHERE m.uid = ? AND (p.status = 'open' OR p.updated_at > ?) ORDER BY p.created_at DESC LIMIT 20").all(uid, now() - 30 * DAY).map(potView);
  /** A member pays their share into the pot. Counts like a transfer (daily limit, velocity). When the last share lands, the
   *  whole pot goes to the creator's wallet in the same transaction. */
  function payShare(uid, id) {
    needTier(uid, 1); ctx.security.assertNotFrozen(uid);
    const p = potOf(id); const me = db.prepare('SELECT * FROM pot_members WHERE pot_id = ? AND uid = ?').get(p.id, uid) ?? bad('not_found', 404);
    if (me.paid) return { ok: true, replay: true, pot: potView(p) }; if (p.status !== 'open') bad('pot_closed', 409);
    const t = now(); const l = ctx.limitsOf(uid).withdraw.USD;
    if (ctx.outToday(uid, 'USD', t) + p.share > l.limit) bad('daily_limit_exceeded', 403);
    const done = commit(() => {
      const o = L.post({ type: 'transfer_out', uid, currency: 'USD', amount: p.share, idem: `pot-${p.id}-${uid}`, meta: { pot: p.id, to: p.uid === uid ? null : p.uid, note: p.name },
        legs: [{ acc: L.account(uid, 'USD', 'wallet'), delta: -p.share }, { acc: potAcc(p.id), delta: p.share }] });
      db.prepare('UPDATE pot_members SET paid = 1, txn = ? WHERE pot_id = ? AND uid = ?').run(o.id, p.id, uid);
      A.log(uid, 'pot.pay', p.id, { amount: p.share });
      if (membersOf(p.id).some((m) => !m.paid)) return { txn: o.id, full: false };
      const total = potAcc(p.id).balance;
      L.post({ type: 'transfer_in', uid: p.uid, currency: 'USD', amount: total, idem: `pot-done-${p.id}`, meta: { pot: p.id, note: p.name },
        legs: [{ acc: potAcc(p.id), delta: -total }, { acc: L.account(p.uid, 'USD', 'wallet'), delta: total }] });
      db.prepare("UPDATE pots SET status = 'done', updated_at = ? WHERE id = ?").run(now(), p.id);
      return { txn: o.id, full: true, total };
    }, uid);
    ctx.ping?.(p.uid); ctx.emit('spend.settled', { uid, amount: p.share, id: done.txn }); say(uid, 'pot_paid', { amount: p.share, currency: 'USD', merchant: p.name });
    if (done.full) say(p.uid, 'pot_done', { amount: done.total, currency: 'USD', merchant: p.name });
    return { ok: true, txn: done.txn, pot: potView(potOf(p.id)) };
  }
  /** Only the creator, only while open: every paid share goes back to who paid it. */
  function cancelPot(uid, id) {
    const p = potOf(id); if (p.uid !== uid) bad('not_found', 404); if (p.status !== 'open') bad('pot_closed', 409);
    const back = commit(() => {
      const paid = membersOf(p.id).filter((m) => m.paid);
      for (const m of paid) L.post({ type: 'transfer_in', uid: m.uid, currency: 'USD', amount: p.share, idem: `pot-ref-${p.id}-${m.uid}`, meta: { pot: p.id, refund: true, note: p.name },
        legs: [{ acc: potAcc(p.id), delta: -p.share }, { acc: L.account(m.uid, 'USD', 'wallet'), delta: p.share }] });
      db.prepare("UPDATE pots SET status = 'cancelled', updated_at = ? WHERE id = ?").run(now(), p.id);
      A.log(uid, 'pot.cancel', p.id, { refunded: paid.length }); return paid.map((m) => m.uid);
    }, uid);
    for (const u of back) { ctx.ping?.(u); if (u !== uid) say(u, 'pot_cancelled', { merchant: p.name }); }
    return { ok: true, refunded: back.length };
  }
  function remindPot(uid, id) {
    const p = potOf(id); if (p.uid !== uid || p.status !== 'open') bad('not_found', 404);
    if (p.reminded_at && now() - p.reminded_at < 12 * 3_600_000) bad('too_soon', 429);
    db.prepare('UPDATE pots SET reminded_at = ? WHERE id = ?').run(now(), p.id);
    const late = membersOf(p.id).filter((m) => !m.paid && m.uid !== uid);
    for (const m of late) say(m.uid, 'pot_reminder', { amount: p.share, currency: 'USD', merchant: p.name });
    return { ok: true, reminded: late.length };
  }

  /* ── v391 gift cards: the buyer's money waits in the company's gift account until someone redeems the code ── */
  const ALPH = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const norm = (c) => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const hashOf = (c) => crypto.createHash('sha256').update(`gift|${norm(c)}`).digest('hex');
  const giftAcc = () => L.sys('gift_cards', 'USD');
  const fails = new Map();
  function createGift(uid, i = {}) {
    needTier(uid, 1); ctx.security.assertNotFrozen(uid);
    const amount = money(i.amount); if (amount < 1000) bad('below_minimum'); const n = note(i.note); const t = now();
    const l = ctx.limitsOf(uid).withdraw.USD; if (ctx.outToday(uid, 'USD', t) + amount > l.limit) bad('daily_limit_exceeded', 403);
    if (db.prepare("SELECT COUNT(*) c FROM gift_cards WHERE buyer = ? AND created_at > ?").get(uid, t - DAY).c >= 5) bad('velocity_limit', 429);
    const raw = Array.from(crypto.randomBytes(12), (b) => ALPH[b % ALPH.length]).join(''); const code = `GFT-${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8, 12)}`;
    const id = rid('gft');
    const r = commit(() => {
      const o = L.post({ type: 'transfer_out', uid, currency: 'USD', amount, idem: `gift-${id}`, meta: { gift: id, note: n }, legs: [{ acc: L.account(uid, 'USD', 'wallet'), delta: -amount }, { acc: giftAcc(), delta: amount }] });
      db.prepare('INSERT INTO gift_cards (id, code_hash, code, buyer, amount, note, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)').run(id, hashOf(code), seal(code, `gift:${id}`), uid, amount, n, 'active', t, t);
      A.log(uid, 'gift.create', id, { amount }); return { id, code, amount, note: n, txn: o.id };
    }, uid);
    ctx.emit('spend.settled', { uid, amount, id: r.txn }); say(uid, 'gift_bought', { amount, currency: 'USD' });
    return r;
  }
  function gifts(uid) {
    return db.prepare('SELECT * FROM gift_cards WHERE buyer = ? ORDER BY created_at DESC LIMIT 30').all(uid).map((g) => ({ id: g.id, amount: g.amount, note: g.note, status: g.status, at: g.created_at,
      code: g.status === 'active' ? (() => { try { return open(g.code, `gift:${g.id}`); } catch { return null; } })() : null }));
  }
  function redeemGift(uid, code) {
    needTier(uid, 1); ctx.security.assertNotFrozen(uid);
    const f = fails.get(uid) || { n: 0, at: 0 }; if (f.n >= 8 && now() - f.at < 3_600_000) bad('velocity_limit', 429);
    const g = db.prepare('SELECT * FROM gift_cards WHERE code_hash = ?').get(hashOf(code));
    if (!g || g.status !== 'active') { fails.set(uid, { n: (now() - f.at < 3_600_000 ? f.n : 0) + 1, at: now() }); bad(g ? 'gift_used' : 'gift_not_found', g ? 409 : 404); }
    if (g.buyer === uid) bad('own_gift', 409);
    const r = commit(() => {
      const upd = db.prepare("UPDATE gift_cards SET status = 'redeemed', redeemed_by = ?, updated_at = ? WHERE id = ? AND status = 'active'").run(uid, now(), g.id); if (!upd.changes) bad('gift_used', 409);
      const tx = L.post({ type: 'transfer_in', uid, currency: 'USD', amount: g.amount, idem: `gift-in-${g.id}`, meta: { gift: g.id, note: g.note }, legs: [{ acc: giftAcc(), delta: -g.amount }, { acc: L.account(uid, 'USD', 'wallet'), delta: g.amount }] });
      A.log(uid, 'gift.redeem', g.id, { amount: g.amount }); return { ok: true, amount: g.amount, note: g.note, txn: tx.id, from: shortName(g.buyer) };
    }, uid);
    ctx.ping?.(uid); say(g.buyer, 'gift_redeemed', { amount: g.amount, currency: 'USD', name: shortName(uid) }); say(uid, 'gift_received', { amount: g.amount, currency: 'USD', name: shortName(g.buyer) });
    return r;
  }
  function cancelGift(uid, id) {
    const g = db.prepare('SELECT * FROM gift_cards WHERE id = ? AND buyer = ?').get(String(id || ''), uid) ?? bad('not_found', 404);
    return commit(() => {
      const upd = db.prepare("UPDATE gift_cards SET status = 'cancelled', updated_at = ? WHERE id = ? AND status = 'active'").run(now(), g.id); if (!upd.changes) bad('gift_used', 409);
      L.post({ type: 'transfer_in', uid, currency: 'USD', amount: g.amount, idem: `gift-back-${g.id}`, meta: { gift: g.id, refund: true }, legs: [{ acc: giftAcc(), delta: -g.amount }, { acc: L.account(uid, 'USD', 'wallet'), delta: g.amount }] });
      A.log(uid, 'gift.cancel', g.id, {}); return { ok: true };
    }, uid);
  }

  /* ── renew my plan from the balance ── */
  const renewRow = (uid) => db.prepare('SELECT * FROM auto_renew WHERE uid = ?').get(uid) || null;
  function setAutoRenew(uid, on) {
    needTier(uid, 1);
    db.prepare('INSERT INTO auto_renew (uid, on_, updated_at) VALUES (?,?,?) ON CONFLICT(uid) DO UPDATE SET on_ = excluded.on_, updated_at = excluded.updated_at').run(uid, on ? 1 : 0, now());
    A.log(uid, on ? 'renew.on' : 'renew.off', uid, {}); return { on: Boolean(on) };
  }
  const autoRenewList = () => db.prepare('SELECT * FROM auto_renew WHERE on_ = 1').all();
  const markRenew = (uid, field, until) => db.prepare(`UPDATE auto_renew SET ${field === 'reminded' ? 'reminded_for' : 'renewed_for'} = ? WHERE uid = ?`).run(until, uid);

  return { recent, request, requests, payRequest, closeRequest, createPot, pots, payShare, cancelPot, remindPot, createGift, gifts, redeemGift, cancelGift,
    autoRenew: (uid) => ({ on: Boolean(renewRow(uid)?.on_) }), setAutoRenew, autoRenewList, markRenew, renewRow };
}
