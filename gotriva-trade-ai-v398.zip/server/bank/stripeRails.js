// v369 Real-money rails for the digital bank through Stripe (the company's own Stripe account):
//   • Issuing  — real virtual Visa/Mastercard cards issued by Stripe's partner bank; every card payment is approved or
//                declined in real time by OUR authorisation engine (balance, limits, freeze, online/abroad/contactless).
//                Card number / CVV never touch this server: the browser shows them inside Stripe's own secure iframe.
//   • Connect  — withdrawals: each person links a Stripe Express account (Stripe checks identity and the local bank account
//                in their country); an approved withdrawal becomes a Stripe transfer, and Stripe pays it out to that bank.
//   • Checkout — deposits: a card payment on Stripe's page tops up the USD wallet once Stripe confirms it.
// Each piece only runs when the owner switches it on (env) after Stripe has approved it for the account. A live key is only
// accepted when BANK_MODE=live; a test key is only accepted in sandbox, so test money and real money never mix.
// shortcut: the Stripe API shapes here follow Stripe's public docs (API 2024-06-20); they were not called from this build
// sandbox (no network) — run one test-mode card, top-up and payout before going live.
import crypto from 'node:crypto';

export const STRIPE_API_VERSION = '2024-06-20';
const KEY_RE = /^(sk|rk)_(live|test)_[A-Za-z0-9]{10,200}$/;

/** Stripe-style form encoding with nested keys: { a: { b: 1 }, c: [{ d: 2 }] } → a[b]=1&c[0][d]=2 */
export function formEncode(obj, prefix = '') {
  const out = [];
  for (const [k, v] of Object.entries(obj || {})) {
    if (v === undefined || v === null || v === '') continue;
    const key = prefix ? `${prefix}[${k}]` : k;
    if (Array.isArray(v)) v.forEach((x, i) => { if (x && typeof x === 'object') out.push(formEncode(x, `${key}[${i}]`)); else out.push(`${encodeURIComponent(`${key}[${i}]`)}=${encodeURIComponent(String(x))}`); });
    else if (typeof v === 'object') out.push(formEncode(v, key));
    else out.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(v))}`);
  }
  return out.filter(Boolean).join('&');
}

/** MCC group → our budget categories (rough, for budgets and insights only; never for a money decision). */
export function categoryOf(stripeCategory = '') {
  const c = String(stripeCategory);
  if (/grocery|supermarket/.test(c)) return 'groceries';
  if (/restaurant|eating|fast_food|bars|caterers/.test(c)) return 'dining';
  if (/taxi|transit|railroad|bus|airline|travel|hotel|car_rental|parking|tolls|gas|fuel/.test(c)) return /hotel|airline|travel|car_rental/.test(c) ? 'travel' : 'transport';
  if (/utilities|telecommunication|cable|electric/.test(c)) return 'bills';
  if (/digital|streaming|software|subscription/.test(c)) return 'subscriptions';
  if (/movie|amusement|entertainment|record_stores|video_game/.test(c)) return 'entertainment';
  if (/medical|doctor|dentist|hospital|pharmac|drug/.test(c)) return 'health';
  if (/school|college|education/.test(c)) return 'education';
  if (/store|shop|clothing|department|electronics/.test(c)) return 'shopping';
  return 'other';
}

/**
 * Stripe Issuing event → the bank's generic issuer event (see vcards.issuerEvent). Returns null for events we do not act on.
 * Abroad = the merchant's country differs from the cardholder's billing country (both are on the authorisation object).
 */
export function mapIssuingEvent(ev) {
  const o = ev?.data?.object || {};
  if (ev?.type === 'issuing_authorization.request') {
    const pr = o.pending_request || {}; const cents = Number(pr.amount ?? o.amount) || 0; const cur = String(pr.currency || o.currency || 'usd').toUpperCase();
    const home = o.card?.cardholder?.billing?.address?.country || null; const where = o.merchant_data?.country || null;
    const method = String(o.authorization_method || '');
    return { type: 'authorization.request', eventId: String(o.id || ''), cardRef: String(o.card?.id || o.card || ''), merchant: String(o.merchant_data?.name || 'unknown').slice(0, 40) || 'unknown',
      category: categoryOf(o.merchant_data?.category), amount: (cents / 100).toFixed(2), currency: cur,
      channel: method === 'online' ? 'online' : method === 'contactless' ? 'contactless' : method === 'chip' ? 'chip' : null, abroad: Boolean(home && where && home !== where) };
  }
  if (ev?.type === 'issuing_transaction.created') {
    const auth = typeof o.authorization === 'string' ? o.authorization : o.authorization?.id;
    if (!auth) return null;   // a "force capture" without an authorisation is left for the owner (shown in Stripe)
    return { type: o.type === 'refund' ? 'transaction.reversed' : 'transaction.settled', eventId: String(o.id || ''), authEventId: auth };
  }
  if (ev?.type === 'issuing_authorization.updated' && o.status === 'reversed') return { type: 'transaction.reversed', eventId: `${o.id}:rev`, authEventId: String(o.id || '') };
  return null;
}

export function createStripeRails({ key, env = process.env, fetchFn = fetch, api = 'https://api.stripe.com', mode = 'sandbox', log = console } = {}) {
  if (!KEY_RE.test(String(key || ''))) return null;
  const live = /_live_/.test(key);
  if (live !== (mode === 'live')) { log.error?.(`[bank] Stripe ${live ? 'live' : 'test'} key ignored: BANK_MODE is ${mode} (live keys only with BANK_MODE=live, test keys only in sandbox)`); return null; }
  const on = (k) => env[k] === '1';

  async function call(method, path, params = null, { idem = null, version = STRIPE_API_VERSION } = {}) {
    const headers = { authorization: `Bearer ${key}`, 'stripe-version': version };
    if (idem) headers['idempotency-key'] = idem;
    let url = `${api}${path}`; let body;
    if (method === 'GET') { if (params) url += `?${formEncode(params)}`; } else { headers['content-type'] = 'application/x-www-form-urlencoded'; body = formEncode(params || {}); }
    const r = await fetchFn(url, { method, headers, body, signal: AbortSignal.timeout(15_000) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(j?.error?.message || `stripe_${r.status}`); e.code = `stripe_${String(j?.error?.code || j?.error?.type || r.status).slice(0, 40)}`; e.status = r.status; throw e; }
    return j;
  }
  const expOf = (c) => `${String(c.exp_month).padStart(2, '0')}/${String(c.exp_year).slice(-2)}`;

  /* ── Issuing ── */
  const issuer = on('BANK_STRIPE_ISSUING') ? {
    name: 'stripe', async: true,
    /** holder: { name, address: { line1, city, postal, region, country } }, cardholder: an existing Stripe cardholder id */
    async create({ uid, label, holder, cardholder = null, limits = null }) {
      let ch = cardholder;
      if (!ch) {
        const a = holder?.address || {};
        const r = await call('POST', '/v1/issuing/cardholders', { type: 'individual', name: holder?.name, status: 'active',
          billing: { address: { line1: a.line1, city: a.city, postal_code: a.postal, state: a.region, country: a.country } },
          metadata: { uid } }, { idem: `ch-${crypto.createHash('sha256').update(String(uid)).digest('hex').slice(0, 24)}` });
        ch = r.id;
      }
      const card = await call('POST', '/v1/issuing/cards', { cardholder: ch, currency: 'usd', type: 'virtual', status: 'active', metadata: { uid, label: String(label || '').slice(0, 30) },
        ...(limits?.month ? { spending_controls: { spending_limits: [{ amount: limits.month, interval: 'monthly' }] } } : {}) });
      return { ref: card.id, last4: card.last4, exp: expOf(card), cardholder: ch, brand: card.brand || 'Visa' };
    },
    /** A renewal: Stripe issues a new number, CVV and expiry for the same person and links it to the old card. */
    async replace(ref, { cardholder, reason = 'expired' } = {}) {
      const card = await call('POST', '/v1/issuing/cards', { cardholder, currency: 'usd', type: 'virtual', status: 'active', replacement_for: ref, replacement_reason: reason });
      return { ref: card.id, last4: card.last4, exp: expOf(card), cardholder, brand: card.brand || 'Visa' };
    },
    async setStatus(ref, status) { return call('POST', `/v1/issuing/cards/${encodeURIComponent(ref)}`, { status: status === 'frozen' ? 'inactive' : status === 'closed' ? 'canceled' : 'active' }); },
    /** For Stripe's card-details iframe in the browser (the nonce comes from Stripe.js there). */
    async ephemeral(ref, nonce) { const r = await call('POST', '/v1/ephemeral_keys', { issuing_card: ref, nonce }); return { secret: r.secret, publishableKey: env.STRIPE_PUBLISHABLE_KEY || '' }; },
    reveal() { return { stripe: true }; },
  } : null;

  /* ── Connect (withdrawals to the person's own bank, in their country) ── */
  const connect = on('BANK_STRIPE_CONNECT') ? {
    async createAccount({ uid, country }) {
      return call('POST', '/v1/accounts', { type: 'express', country, business_type: 'individual', capabilities: { transfers: { requested: true } }, metadata: { uid } },
        { idem: `acct-${crypto.createHash('sha256').update(`${uid}:${country}`).digest('hex').slice(0, 24)}` });
    },
    async link(acct, origin) {
      const r = await call('POST', '/v1/account_links', { account: acct, type: 'account_onboarding', refresh_url: `${origin}/#/app/bank?payout=refresh`, return_url: `${origin}/#/app/bank?payout=done` });
      return r.url;
    },
    async account(acct) { const a = await call('GET', `/v1/accounts/${encodeURIComponent(acct)}`); return { id: a.id, payoutsEnabled: Boolean(a.payouts_enabled), detailsSubmitted: Boolean(a.details_submitted), country: a.country, currency: a.default_currency }; },
    async transfer({ acct, cents, withdrawalId }) { return call('POST', '/v1/transfers', { amount: cents, currency: 'usd', destination: acct, metadata: { withdrawalId } }, { idem: `wd-${withdrawalId}` }); },
  } : null;

  /* ── Checkout (deposits by card) ── */
  const topup = on('BANK_STRIPE_TOPUP') ? {
    async checkout({ uid, cents, origin }) {
      const meta = { kind: 'bank_topup', uid, cents: String(cents) };
      const s = await call('POST', '/v1/checkout/sessions', { mode: 'payment', client_reference_id: uid, success_url: `${origin}/#/app/bank?topup=done`, cancel_url: `${origin}/#/app/bank?topup=cancel`,
        line_items: [{ quantity: 1, price_data: { currency: 'usd', unit_amount: cents, product_data: { name: 'GOTRIVA wallet top-up' } } }],
        metadata: meta, payment_intent_data: { metadata: meta }, expires_at: Math.floor(Date.now() / 1000) + 31 * 60 });
      return { url: s.url, id: s.id };
    },
  } : null;

  return { live, issuer, connect, topup, call, publishableKey: /^pk_(live|test)_[A-Za-z0-9]{10,200}$/.test(String(env.STRIPE_PUBLISHABLE_KEY || '')) ? env.STRIPE_PUBLISHABLE_KEY : '' };
}
