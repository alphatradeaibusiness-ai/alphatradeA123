// v353 Private channels (القنوات الخاصة): approved moderators create private chat channels, choose who is in them, and
// members talk in real time with text and images; the whole history is kept.
//  • who may create: the site owners, and the moderators an owner approves by e-mail (approval can be withdrawn)
//  • membership: a channel admin adds people by the e-mail of their account, removes them, makes them admins; nobody can
//    join on their own, and every read / write checks membership on the server
//  • messages: text (up to 4000 characters) and images (JPEG / PNG / WebP, checked by their bytes, up to 2 MB, re-encoded in the
//    browser first so camera location data is dropped); delete your own, admins delete any; history kept (newest 5000 / channel)
//  • real time: long polling — a member's request waits up to 25 s and returns the moment a new message arrives
//  • storage: one AES-256-GCM encrypted file (key from AI_KEY_SECRET) + each image / logo as its own encrypted file, readable
//    only through the server after the membership check; the durable mirror carries both
//  • limits: 30 messages and 8 images a minute per person, 500 members and 20 channels per moderator; quiet push notices
//    (at most one per channel every 5 minutes, never while the person has the channel open)
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { writeBehind } from './writeBehind.js';
import dns from 'node:dns';
import http from 'node:http';
import https from 'node:https';
import net from 'node:net';

const clip = (s, n) => String(s ?? '').replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, ' ').trim().slice(0, n);
const clipText = (s, n) => String(s ?? '').replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, ' ').replace(/\n{4,}/g, '\n\n\n').trim().slice(0, n);
const hex = (n = 6) => crypto.randomBytes(n).toString('hex');
const ID_RE = /^c[0-9a-f]{12}$/;
const FILE_RE = /^f[0-9a-f]{16}$/;
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,24}$/;
const IMG_RE = /^data:image\/(png|jpeg|webp|gif);base64,([A-Za-z0-9+/=]+)$/;
export const CHAT_LIMITS = { maxVoice: 10_000_000, maxFile: 25_000_000, maxImage: 2_000_000, maxImageRaw: 8_000_000, maxVideo: 50_000_000, maxLogo: 400_000, callMax: 8, dailyBytes: 600_000_000, maxText: 4000, maxMembers: 500, maxChannelsPerMod: 20, keep: 5000, page: 80, waitMs: 25_000 };

/** What an image really is, from its first bytes (never from what the browser claims). */
export function sniffImage(buf) {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.length > 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buf.length > 12 && buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  if (buf.length > 6 && /^GIF8[79]a$/.test(buf.subarray(0, 6).toString('latin1'))) return 'image/gif';
  return null;
}

/** Video type from the first bytes: MP4 / MOV (ftyp box) or WebM (EBML). */
export function sniffVideo(buf) {
  if (buf.length > 12 && buf.subarray(4, 8).toString('latin1') === 'ftyp') return buf.subarray(8, 10).toString('latin1') === 'qt' ? 'video/quicktime' : 'video/mp4';
  if (buf.length > 4 && buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return 'video/webm';
  return null;
}
const COLOR_RE = /^#[0-9a-f]{6}$/i;
const INVITE_RE = /^[A-Za-z0-9_-]{10,24}$/;
const USERNAME_RE = /^[a-z][a-z0-9_]{4,31}$/;
const SLOW = [0, 10, 30, 60, 300, 900];
const TTLS = [0, 86_400, 604_800, 2_592_000];   // off, a day, a week, a month
export const ADMIN_PERMS = ['info', 'members', 'pin', 'delete', 'ban', 'invite'];
/** Audio type from the first bytes: WebM / Ogg (Chrome, Firefox) or MP4 (Safari). */
export function sniffAudio(buf) {
  if (buf.length > 4 && buf.subarray(0, 4).toString('latin1') === 'OggS') return 'audio/ogg';
  if (buf.length > 4 && buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return 'audio/webm';
  if (buf.length > 12 && buf.subarray(4, 8).toString('latin1') === 'ftyp') return 'audio/mp4';
  return null;
}
/** A file name safe to show and to send back in a header. */
const safeName = (n) => clip(String(n || 'file').replace(/[\\/:*?"<>|\u0000-\u001f\u007f]/g, '_').replace(/^\.+/, ''), 120) || 'file';
export const CHAT_CATEGORIES = ['official', 'signals', 'ai', 'forex', 'crypto', 'general', 'education', 'vip', 'support'];
export const CHAT_REACTIONS = ['👍', '❤️', '🔥', '😂', '😮', '🙏', '🚀', '📈'];
const pickCat = (v) => (CHAT_CATEGORIES.includes(v) ? v : 'general');
const pickRank = (v) => { const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.max(0, Math.min(7, n)) : 0; };

export function createChatChannels({ dir, secret, now = Date.now, revokeAll = null, isOwnerEmail = () => false, findMember = () => null, notify = null, langOf = () => 'ar', isProven = () => true, planRank = () => 99, translate = null, env = process.env } = {}) {
  const key = secret && String(secret).length >= 32 ? crypto.scryptSync(String(secret), 'gotriva-chat-v1', 32) : null;
  const file = path.join(dir, 'chat-channels.json'); const fdir = path.join(dir, 'chat-files');
  const enc = (buf, aad) => { const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key, iv); c.setAAD(Buffer.from(aad)); const d = Buffer.concat([c.update(buf), c.final()]); return Buffer.concat([iv, c.getAuthTag(), d]); };
  const dec = (buf, aad) => { const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12)); d.setAAD(Buffer.from(aad)); d.setAuthTag(buf.subarray(12, 28)); return Buffer.concat([d.update(buf.subarray(28)), d.final()]); };
  let db = null;
  function load() {
    if (db) return db;
    db = { mods: {}, channels: {} };
    if (!key) return db;
    try { db = { ...db, ...JSON.parse(dec(fs.readFileSync(file), 'chat').toString('utf8')) }; } catch { /* first start */ }
    if (!db.blocksMigrated) {   // v368: blocks made before pair blocks existed move onto the pair once
      db.blocks = db.blocks || {};
      for (const c of Object.values(db.channels)) if ((c.type === 'dm' || c.type === 'secret') && c.blocked) for (const [who, at] of Object.entries(c.blocked)) { const peer = Object.keys(c.members || {}).find((k) => k !== who); if (peer) db.blocks[`${who}|${peer}`] = at; }
      db.blocksMigrated = true;
    }
    return db;
  }
  const writer = writeBehind(() => {
    if (!key || !db) return;
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    const tmp = `${file}.${process.pid}.tmp`; fs.writeFileSync(tmp, enc(Buffer.from(JSON.stringify(db)), 'chat'), { mode: 0o600 }); fs.renameSync(tmp, file);
  }, { delayMs: env.NODE_ENV === 'test' ? 0 : 400, maxWaitMs: 1500 });
  const save = () => writer.schedule();

  /* ── real time: requests waiting for a channel's next change ── */
  const waiters = new Map();   // channel id → Set<fn>
  function wake(id) { const s = waiters.get(id); if (!s) return; waiters.delete(id); for (const fn of s) { try { fn(); } catch { /* the request already ended */ } } }
  /** Resolves when the channel changes after `rev`, or after waitMs. Returns a cancel function through onCancel. */
  function waitFor(id, rev, waitMs = CHAT_LIMITS.waitMs, onCancel = () => {}) {
    return new Promise((resolve) => {
      const c = load().channels[id]; if (!c || c.rev > rev) return resolve(true);
      let done = false; const fin = (v) => { if (done) return; done = true; clearTimeout(t); waiters.get(id)?.delete(fn); resolve(v); };
      const fn = () => fin(true); const t = setTimeout(() => fin(false), waitMs);
      if (!waiters.has(id)) waiters.set(id, new Set()); waiters.get(id).add(fn);
      onCancel(() => fin(false));
    });
  }

  /* ── helpers ── */
  const emailOf = (u) => String(u?.email || '').toLowerCase();
  const nameOf = (u) => clip(u?.name || emailOf(u).split('@')[0] || 'Member', 40);
  const isOwner = (u) => Boolean(isOwnerEmail(u));
  const own = (o, k) => Boolean(o) && Object.prototype.hasOwnProperty.call(o, k);   // never trust ids like __proto__ as map keys
  const canCreate = (u) => isOwner(u) || (own(load().mods, emailOf(u)) && isProven(u));   // an approved moderator must have a confirmed e-mail
  const ch = (id) => (ID_RE.test(String(id)) && own(load().channels, id) ? load().channels[id] : null);
  const roleOf = (c, uid) => (own(c?.members, uid) ? c.members[uid].role : null);
  // v357 who may open a channel: its members, plus — for a channel tied to a subscription level — everyone whose current plan
  // reaches it (checked on every request, so an expired subscription loses access at once). Banned people never.
  const planOk = (u, c) => isOwner(u) || planRank(u.uid) >= (Number(c.minRank) || 0);
  function peek(u, c) {
    if (!c || !u?.uid || own(c.banned, u.uid)) return false;
    if (own(c.members, u.uid)) return c.members[u.uid].via !== 'plan' || (c.access === 'plan' && planOk(u, c));
    return c.access === 'plan' && planOk(u, c);
  }
  function gate(u, id) {
    const c = ch(id); if (!peek(u, c)) return null;
    if (!own(c.members, u.uid)) { c.members[u.uid] = { role: 'member', via: 'plan', name: nameOf(u), email: emailOf(u), addedAt: now(), addedBy: null, lastRead: c.rev || 0 }; save(); }
    return c;
  }
  const isMember = (u, id) => peek(u, ch(id));
  const isAdmin = (c, u) => roleOf(c, u.uid) === 'admin';
  const isAdminUid = (c, uid) => roleOf(c, uid) === 'admin';
  /** What one admin may do. The creator and the site owners may do everything; other admins what the creator allowed (all by default). */
  function can(c, u, perm) {
    if (c.type === 'dm' || c.type === 'saved' || c.type === 'secret') return perm === 'pin' || perm === 'delete-own';
    if (!isAdmin(c, u)) return false; if (c.createdBy === u.uid || isOwner(u)) return true;
    const p = c.members[u.uid].perms; return !p || p[perm] !== false;
  }
  const permsOf = (c, uid) => (own(c.members, uid) ? Object.fromEntries(ADMIN_PERMS.map((k) => [k, can(c, { uid, email: c.members[uid].email }, k)])) : {});
  function logAct(c, u, act, target = null) { c.log = Array.isArray(c.log) ? c.log : []; c.log.push({ at: now(), by: nameOf(u), act, target: target ? clip(target, 60) : null }); if (c.log.length > 300) c.log.splice(0, c.log.length - 300); }
  const bump = (c) => { c.rev = (c.rev || 0) + 1; c.updatedAt = now(); return c.rev; };
  const rate = new Map();
  function limited(uid, kind, max, windowMs = 60_000) {
    const k = `${uid}:${kind}`; const t = now(); const l = (rate.get(k) || []).filter((x) => t - x < windowMs);
    if (l.length >= max) { rate.set(k, l); return true; } l.push(t); rate.set(k, l); if (rate.size > 20_000) rate.clear(); return false;
  }
  function putImage(raw, channelId, max) {
    const m = IMG_RE.exec(String(raw || '')); if (!m) return { error: 'bad_image' };
    const buf = Buffer.from(m[2], 'base64'); if (!buf.length) return { error: 'bad_image' }; if (buf.length > max) return { error: 'image_too_large' };
    const type = sniffImage(buf); if (!type) return { error: 'bad_image' };
    if (!key) return { error: 'no_secret' };
    const id = `f${hex(8)}`; fs.mkdirSync(fdir, { recursive: true, mode: 0o700 });
    fs.writeFileSync(path.join(fdir, `${id}.bin`), enc(Buffer.concat([Buffer.from(`${type}\n`), buf]), `chat:${channelId}:${id}`), { mode: 0o600 });
    return { id };
  }
  const pending = new Map();   // uploaded media not yet in a message: fid → { uid, ch, kind, at }
  // uid → { day, bytes } uploaded today; kept in the saved data (v364) so a restart doesn't reset anyone's daily limit
  const quota = { get: (uid) => { const q = load().quota; return q && own(q, uid) ? q[uid] : undefined; }, set: (uid, v) => { const d = load(); d.quota = d.quota || {}; const today = v.day; for (const [k, x] of Object.entries(d.quota)) if (x.day !== today) delete d.quota[k]; d.quota[uid] = v; save(); } };
  function writeFile(channelId, type, buf) {
    const id = `f${hex(8)}`; fs.mkdirSync(fdir, { recursive: true, mode: 0o700 });
    fs.writeFileSync(path.join(fdir, `${id}.bin`), enc(Buffer.concat([Buffer.from(`${type}\n`), buf]), `chat:${channelId}:${id}`), { mode: 0o600 });
    return id;
  }
  /** Raw upload (photo or video) → a file id the uploader then sends in a message. The bytes decide the type. */
  function upload(u, id, buf, { as = '', name = '' } = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!key) return { error: 'no_secret' };
    if (!buf?.length) return { error: 'bad_media' };
    if (as === 'voice' || as === 'file') return uploadOther(u, id, buf, as, name);
    const img = sniffImage(buf); const vid = img ? null : sniffVideo(buf);
    if (!img && !vid) return { error: 'bad_media' };
    if (img && buf.length > CHAT_LIMITS.maxImageRaw) return { error: 'image_too_large' };
    if (vid && buf.length > CHAT_LIMITS.maxVideo) return { error: 'video_too_large' };
    if (limited(u.uid, vid ? 'vid' : 'img', vid ? 4 : 8)) return { error: 'rate_limited' };
    let mine = 0; for (const v of pending.values()) if (v.uid === u.uid) mine++;
    if (mine >= 6) return { error: 'rate_limited' };   // at most 6 uploads waiting to be sent per person
    const day = new Date(now()).toISOString().slice(0, 10); const used = quota.get(u.uid); const sofar = used?.day === day ? used.bytes : 0;
    if (sofar + buf.length > CHAT_LIMITS.dailyBytes) return { error: 'quota_reached' };
    quota.set(u.uid, { day, bytes: sofar + buf.length });
    const fid = writeFile(id, img || vid, buf); pending.set(fid, { uid: u.uid, ch: id, kind: vid ? 'video' : 'image', at: now() });
    for (const [k, v] of pending) if (now() - v.at > 3600_000) { pending.delete(k); dropFile(k); }
    return { media: fid, kind: vid ? 'video' : 'image' };
  }
  /** A voice note (WebM / Ogg / MP4 audio, checked by its bytes) or any document (kept as plain bytes, always downloaded, never shown inline). */
  function uploadOther(u, id, buf, as, name) {
    let type;
    if (as === 'voice') { type = sniffAudio(buf); if (!type) return { error: 'bad_media' }; if (buf.length > CHAT_LIMITS.maxVoice) return { error: 'voice_too_large' }; }
    else { if (buf.length > CHAT_LIMITS.maxFile) return { error: 'file_too_large' }; type = 'application/octet-stream'; }
    if (limited(u.uid, as, as === 'voice' ? 12 : 6)) return { error: 'rate_limited' };
    let mine = 0; for (const v of pending.values()) if (v.uid === u.uid) mine++; if (mine >= 6) return { error: 'rate_limited' };
    const day = new Date(now()).toISOString().slice(0, 10); const used = quota.get(u.uid); const sofar = used?.day === day ? used.bytes : 0;
    if (sofar + buf.length > CHAT_LIMITS.dailyBytes) return { error: 'quota_reached' };
    quota.set(u.uid, { day, bytes: sofar + buf.length });
    const fid = writeFile(id, type, buf); pending.set(fid, { uid: u.uid, ch: id, kind: as, at: now(), name: as === 'file' ? safeName(name) : null, size: buf.length });
    return { media: fid, kind: as };
  }
  let diskAt = 0; let diskLow = false;
  const lowDisk = () => { const t = now(); if (t - diskAt > 60_000) { diskAt = t; try { const f = fs.statfsSync(dir); diskLow = f.bavail * f.bsize < Number(env.CHAT_MIN_FREE_MB || 300) * 1_048_576; } catch { diskLow = false; } } return diskLow; };
  function chargeQuota(u, bytes) {
    let mine = 0; for (const v of pending.values()) if (v.uid === u.uid) mine++; if (mine >= 6) return { error: 'rate_limited' };
    const day = new Date(now()).toISOString().slice(0, 10); const used = quota.get(u.uid); const sofar = used?.day === day ? used.bytes : 0;
    if (sofar + bytes > CHAT_LIMITS.dailyBytes) return { error: 'quota_reached' };
    if (lowDisk()) return { error: 'quota_reached' };   // v368: keep space for the site's own data (uploads stop below the reserve)
    quota.set(u.uid, { day, bytes: sofar + bytes }); return null;
  }
  /** Deletes encrypted files nobody refers to any more (unsent uploads after an hour, leftovers after a restart). */
  function sweepFiles() {
    try {
      const keep = new Set([...pending.keys()]);
      sweepStories(); for (const c of Object.values(load().channels)) expire(c);
      for (const c of Object.values(load().channels)) { if (c.logo) keep.add(c.logo); for (const m of c.messages) { if (m.file) keep.add(m.file); if (m.poster) keep.add(m.poster); } }
      for (const box of ['stickers', 'stories']) for (const l of Object.values(load()[box] || {})) for (const x of l) keep.add(x.fid);
      for (const p2 of Object.values(load().profiles || {})) if (p2.avatar) keep.add(p2.avatar);   // v359: kept outside the chats
      for (const [k, v] of pending) if (now() - v.at > 3600_000) { pending.delete(k); keep.delete(k); }
      for (const f of fs.existsSync(fdir) ? fs.readdirSync(fdir) : []) { const id = f.replace(/\.bin$/, ''); if (FILE_RE.test(id) && !keep.has(id)) { const st = fs.statSync(path.join(fdir, f)); if (now() - st.mtimeMs > 3600_000) fs.rmSync(path.join(fdir, f), { force: true }); } }
    } catch { /* next round */ }
  }
  if (env.NODE_ENV !== 'test') { const t = setInterval(sweepFiles, 15 * 60_000); t.unref?.(); setTimeout(sweepFiles, 60_000).unref?.(); }
  const dropFile = (fid) => { if (FILE_RE.test(String(fid || ''))) fs.rmSync(path.join(fdir, `${fid}.bin`), { force: true }); };
  const onlineOf = (c) => Object.values(c.members).filter((m) => now() - (m.seenAt || 0) < 70_000).length;
  const typeOf = (c) => (['channel', 'dm', 'saved', 'secret'].includes(c.type) ? c.type : 'group');
  const peerOf = (c, uid) => (c.type === 'dm' || c.type === 'secret' ? Object.keys(c.members).find((k) => k !== uid) || null : null);
  const card = (c, uid) => {
    const last = [...c.messages].reverse().find((m) => !m.deleted && !m.sys) || null; const me = own(c.members, uid) ? c.members[uid] : null;
    const peer = peerOf(c, uid); const pm = peer && own(c.members, peer) ? c.members[peer] : null;
    return { secret: c.type === 'secret' ? { keys: c.keys || {}, ready: Object.keys(c.keys || {}).length === 2, by: c.createdBy } : null,
      id: c.id, name: c.type === 'dm' || c.type === 'secret' ? (pm?.name || 'Member') : c.type === 'saved' ? 'Saved' : c.name, logo: c.type === 'dm' || c.type === 'saved' || c.type === 'secret' ? null : c.logo || null,
      peer: peer ? { ...pubProfile(peer), uid: peer, online: now() - (pm?.seenAt || 0) < 70_000, seenAt: pm?.seenAt || null, blockedMe: Boolean(c.blocked && own(c.blocked, peer)), iBlocked: Boolean(c.blocked && own(c.blocked, uid)) } : null,
      archived: Boolean(me?.archived), pinnedChat: me?.pinnedAt || 0, muteUntil: me ? (me.notify === false ? -1 : me.muteUntil > now() ? me.muteUntil : 0) : 0,
      commands: isPrivType(c) ? [] : Object.keys(c.members).filter((k) => k.startsWith('bot_')).flatMap((k) => { const bt = load().bots?.[k.slice(4)]; return bt ? (bt.commands || []).map((x) => ({ cmd: x.cmd, bot: bt.username })) : []; }).slice(0, 40),
      bigCall: c.bigCall && now() - c.bigCall.at < 6 * 3600_000 ? { at: c.bigCall.at, by: c.bigCall.by } : null, bigOn: bigOn(),
      perms: permsOf(c, uid), ttl: Number(c.ttl) || 0, topics: (c.topics || []).map((t) => ({ id: t.id, name: t.name, emoji: t.emoji || '' })), slow: Number(c.slow) || 0, filterLinks: Boolean(c.filterLinks), words: isAdminUid(c, uid) ? (c.words || []) : undefined,
      mentions: me ? c.messages.filter((m) => m.seq > (me.lastRead || 0) && !m.deleted && Array.isArray(m.mentions) && m.mentions.includes(uid)).length : 0,
      requests: isAdminUid(c, uid) && can(c, { uid }, 'invite') ? Object.keys(c.requests || {}).length : 0, color: c.color || null, call: callCard(c.id), role: me?.role || null, members: Object.keys(c.members).length, rev: c.rev, createdAt: c.createdAt,
      type: typeOf(c), category: pickCat(c.category), verified: Boolean(c.verified), access: c.access === 'plan' ? 'plan' : 'members', minRank: Number(c.minRank) || 0,
      description: c.description || '', rules: c.rules || '', online: onlineOf(c), admins: Object.entries(c.members).filter(([, m]) => m.role === 'admin').slice(0, 30).map(([k, m]) => ({ uid: k, name: m.name })), notify: me ? me.notify !== false : true, creator: c.createdBy === uid,
      unread: me ? c.messages.filter((m) => m.seq > (me.lastRead || 0) && m.uid !== uid && !m.deleted && !m.sys).length : 0,
      last: last ? { name: last.name, enc: Boolean(last.enc || last.encMedia), text: last.enc || last.encMedia ? null : last.file && !last.text ? null : clip(last.text || (last.poll ? `📊 ${last.poll.q}` : ''), 120), image: Boolean(last.file), video: last.kind === 'video', kind: last.kind || null, at: last.at } : null };
  };
  const msgView = (m, uid = null) => ({ id: m.id, seq: m.seq, uid: m.uid, name: m.name, text: m.deleted ? '' : m.text, file: m.deleted ? null : m.file || null, kind: m.deleted ? null : m.kind || (m.file ? 'image' : null), poster: m.deleted ? null : m.poster || null, dur: m.deleted ? null : m.dur || null, at: m.at, deleted: Boolean(m.deleted), sys: m.sys || null, a: m.a || null, b: m.b || null,
    edited: m.deleted ? null : m.edited || null, replyTo: m.deleted ? null : m.replyTo || null, fwd: m.deleted ? null : m.fwd || null, mentions: m.deleted ? [] : m.mentions || [],
    enc: m.deleted ? null : m.enc || null, encMedia: m.deleted ? null : m.encMedia || null, round: Boolean(m.round) && !m.deleted,
    comments: m.deleted ? 0 : Number(m.comments) || 0, bot: Boolean(m.bot), sticker: Boolean(m.sticker) && !m.deleted, topic: m.topic || null, exp: m.exp || null, fileName: m.deleted ? null : m.fileName || null, size: m.deleted ? null : m.size || null, poll: m.deleted || !m.poll ? null : pollView(m.poll, uid),
    reactions: m.deleted || !m.reactions ? [] : Object.entries(m.reactions).filter(([, l]) => l.length).map(([e, l]) => ({ e, n: l.length, mine: l.includes(uid) })) });
  function pollView(p, uid) {
    const total = new Set(p.options.flatMap((o) => o.v)).size;
    return { q: p.q, anon: Boolean(p.anon), multi: Boolean(p.multi), closed: Boolean(p.closed), total, voted: p.options.some((o) => o.v.includes(uid)),
      options: p.options.map((o) => ({ t: o.t, n: o.v.length, mine: o.v.includes(uid), who: p.anon ? [] : o.v.slice(0, 5).map((x) => p.names?.[x] || '') })) };
  }
  // system lines are stored as a kind + names; the page words them in the reader's language
  const sys = (c, kind, a, b = null) => { const seq = bump(c); c.messages.push({ id: `m${hex(6)}`, seq, uid: null, name: '', text: '', at: now(), sys: kind, a: clip(a, 40), b: b ? clip(b, 40) : null }); };
  function trim(c) { if (c.messages.length <= CHAT_LIMITS.keep) return; for (const m of c.messages.splice(0, c.messages.length - CHAT_LIMITS.keep)) { dropFile(m.file); dropFile(m.poster); } }

  /* ── channels ── */
  function list(u) {
    const d = load(); const mine = Object.values(d.channels).filter((c) => peek(u, c)).map((c) => { expire(c); return card(c, u.uid); }).sort((a, b) => ((b.pinnedChat ? 1 : 0) - (a.pinnedChat ? 1 : 0)) || (b.pinnedChat || 0) - (a.pinnedChat || 0) || (b.last?.at || b.createdAt) - (a.last?.at || a.createdAt));
    return { me: u.uid, canCreate: canCreate(u), owner: isOwner(u), channels: mine, enabled: Boolean(key), categories: CHAT_CATEGORIES, reactions: CHAT_REACTIONS, reports: isOwner(u) ? (d.reports || []).length : 0 };
  }
  function create(u, b = {}) {
    if (!key) return { error: 'no_secret' };
    if (!canCreate(u)) return { error: 'forbidden' };
    const name = clip(b.name, 60); if (name.length < 2) return { error: 'bad_name' };
    if (!isOwner(u) && Object.values(load().channels).filter((c) => c.createdBy === u.uid).length >= CHAT_LIMITS.maxChannelsPerMod) return { error: 'too_many_channels' };
    const id = `c${hex(6)}`; const c = { id, name, logo: null, createdBy: u.uid, createdAt: now(), rev: 0, members: { [u.uid]: { role: 'admin', name: nameOf(u), email: emailOf(u), addedAt: now(), addedBy: u.uid, lastRead: 0 } }, messages: [] };
    if (b.logo) { const f = putImage(b.logo, id, CHAT_LIMITS.maxLogo); if (f.error) return f; c.logo = f.id; }
    if (COLOR_RE.test(String(b.color || ''))) c.color = b.color.toLowerCase();
    applyMeta(u, c, b);
    load().channels[id] = c; sys(c, 'created', nameOf(u)); save();
    return { channel: card(c, u.uid) };
  }
  /** Type, category, description, rules, who can join (members only / a subscription level), official badge (owners only). */
  function applyMeta(u, c, b) {
    if (b.type != null && c.type !== 'dm' && c.type !== 'saved') c.type = b.type === 'channel' ? 'channel' : 'group';
    if (b.category != null) c.category = pickCat(b.category);
    if (b.description != null) c.description = clipText(b.description, 600);
    if (b.rules != null) c.rules = clipText(b.rules, 1500);
    if (b.access != null) c.access = b.access === 'plan' ? 'plan' : 'members';
    if (b.minRank != null) c.minRank = pickRank(b.minRank);
    if (b.verified != null && isOwner(u)) c.verified = Boolean(b.verified);
  }
  function update(u, id, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!can(c, u, 'info') || c.type === 'dm' || c.type === 'saved') return { error: 'forbidden' };
    if (b.slow != null) c.slow = SLOW.includes(Number(b.slow)) ? Number(b.slow) : 0;
    if (b.ttl != null) c.ttl = TTLS.includes(Number(b.ttl)) ? Number(b.ttl) : 0;
    if (b.filterLinks != null) c.filterLinks = Boolean(b.filterLinks);
    if (b.words != null) c.words = [...new Set(String(b.words).split(/[,،\n]/).map((w) => clip(w, 40).toLowerCase()).filter((w) => w.length >= 2))].slice(0, 100);
    logAct(c, u, 'settings');
    if (b.name != null) { const name = clip(b.name, 60); if (name.length < 2) return { error: 'bad_name' }; c.name = name; }
    if (b.color === null) c.color = null; else if (b.color != null) { if (!COLOR_RE.test(String(b.color))) return { error: 'bad_color' }; c.color = String(b.color).toLowerCase(); }
    applyMeta(u, c, b);
    if (b.logo === null) { dropFile(c.logo); c.logo = null; }
    else if (b.logo) { const f = putImage(b.logo, id, CHAT_LIMITS.maxLogo); if (f.error) return f; dropFile(c.logo); c.logo = f.id; }
    bump(c); save(); wake(id);
    return { channel: card(c, u.uid) };
  }
  function remove(u, id) {
    const c = ch(id); if (!c) return { error: 'not_found' };
    if (!(c.createdBy === u.uid && isAdmin(c, u)) && !isOwner(u) && !((c.type === 'dm' || c.type === 'saved' || c.type === 'secret') && own(c.members, u.uid))) return { error: 'forbidden' };
    dropFile(c.logo); for (const m of c.messages) { dropFile(m.file); dropFile(m.poster); }
    calls.delete(id); wake(`call:${id}`); delete load().channels[id]; save(); wake(id); return { ok: true };
  }

  /* ── members ── */
  function members(u, id) {
    const c = gate(u, id); if (!c) return { error: 'not_found' };
    const admin = isAdmin(c, u) && c.type !== 'dm';
    const muted = (uid) => Boolean(c.muted && own(c.muted, uid) && (!c.muted[uid].until || c.muted[uid].until > now()));
    return { requests: admin && can(c, u, 'invite') ? Object.entries(c.requests || {}).map(([k, v]) => ({ uid: k, name: v.name, email: isOwner(u) ? v.email : null, at: v.at })) : [],   /* v368: e-mails only for site owners */
      invites: admin && can(c, u, 'invite') ? Object.entries(c.invites || {}).filter(([, v]) => !v.expires || v.expires > now()).map(([k, v]) => ({ code: k, at: v.at, by: v.byName, expires: v.expires || null, max: v.max || null, uses: v.uses || 0, approve: Boolean(v.approve) })) : [],
      banned: admin ? Object.entries(c.banned || {}).map(([k, v]) => ({ uid: k, name: v.name, at: v.at })) : [], members: Object.entries(c.members).filter(([, m]) => m.via !== 'plan' || now() - (m.seenAt || 0) < 30 * 86_400_000).map(([uid, m]) => ({ uid, name: m.name, role: m.role, email: isOwner(u) ? m.email : null, addedAt: m.addedAt, me: uid === u.uid, av: avVer(uid), username: profOf(uid)?.username || null, online: now() - (m.seenAt || 0) < 70_000, seenAt: m.seenAt || null, muted: admin ? muted(uid) : undefined, via: m.via || null, bot: Boolean(m.bot), perms: m.role === 'admin' && admin ? permsOf(c, uid) : undefined, creator: uid === c.createdBy })).sort((a, b) => (a.role === b.role ? a.name.localeCompare(b.name) : a.role === 'admin' ? -1 : 1)) };
  }
  function addMember(u, id, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!can(c, u, 'members') || c.type === 'dm' || c.type === 'saved') return { error: 'forbidden' };
    const email = String(b.email || '').trim().toLowerCase(); if (!EMAIL_RE.test(email)) return { error: 'bad_email' };
    const who = findMember(email); if (!who?.uid) return { error: 'no_account' };   // they sign up first, then get added
    if (own(c.members, who.uid)) return { error: 'already_member' };
    if (c.banned && own(c.banned, who.uid)) { if (!can(c, u, 'ban')) return { error: 'banned' }; delete c.banned[who.uid]; }   // only an admin who may ban can lift a ban by adding back (v368)
    if (Object.keys(c.members).length >= CHAT_LIMITS.maxMembers) return { error: 'channel_full' };
    const role = b.role === 'admin' && (c.createdBy === u.uid || isOwner(u)) ? 'admin' : 'member';   // review fix: only the creator names admins
    c.members[who.uid] = { role, name: clip(who.name || email.split('@')[0], 40), email, addedAt: now(), addedBy: u.uid, lastRead: 0 };
    sys(c, 'added', nameOf(u), c.members[who.uid].name); logAct(c, u, 'add', c.members[who.uid].name); botWelcome(c, c.members[who.uid].name); if (c.requests) delete c.requests[who.uid]; save(); wake(id);
    if (!limited(`${who.uid}:${id}`, 'addnote', 1, 600_000)) notify?.(who.uid, { title: c.name, body: langOf(who.uid) === 'ar' ? `${nameOf(u)} ضافك على القناة الخاصة «${c.name}».` : `${nameOf(u)} added you to the private channel «${c.name}».`, url: `/#/app/chat?c=${id}`, tag: `chat-${id}` });
    return members(u, id);
  }
  function setRole(u, id, uid, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!isAdmin(c, u) || c.type === 'dm') return { error: 'forbidden' };
    if (c.createdBy !== u.uid && !isOwner(u)) return { error: 'forbidden' };   // only the creator names admins and what they may do
    if (!own(c.members, uid)) return { error: 'not_found' }; const m = c.members[uid]; if (uid === c.createdBy && b.role !== 'admin') return { error: 'creator_stays_admin' };
    const was = m.role; m.role = b.role === 'admin' ? 'admin' : 'member';
    if (m.role === 'admin' && b.perms && typeof b.perms === 'object') m.perms = Object.fromEntries(ADMIN_PERMS.map((k) => [k, b.perms[k] !== false]));
    if (m.role !== 'admin') delete m.perms;
    logAct(c, u, was === m.role ? 'perms' : m.role === 'admin' ? 'promote' : 'demote', m.name); bump(c); save(); wake(id); return members(u, id);
  }
  function removeMember(u, id, uid) {
    const c = gate(u, id); if (!c) return { error: 'not_found' };
    const self = uid === u.uid; if (!self && !can(c, u, 'members')) return { error: 'forbidden' };
    if (!self && c.type === 'dm') return { error: 'forbidden' };
    if (!self && own(c.members, uid) && c.members[uid].role === 'admin' && c.createdBy !== u.uid && !isOwner(u)) return { error: 'forbidden' };
    if (!own(c.members, uid)) return { error: 'not_found' }; const m = c.members[uid];
    if (uid === c.createdBy) return { error: 'creator_cannot_leave' };
    { const k = calls.get(id); if (k && own(k.peers, uid)) { delete k.peers[uid]; delete k.inbox[uid]; callBump(id, k); } }
    delete c.members[uid]; sys(c, self ? 'left' : 'removed', self ? m.name : nameOf(u), self ? null : m.name); if (!self) logAct(c, u, 'remove', m.name); save(); wake(id);
    return self ? { ok: true } : members(u, id);
  }

  /* ── messages ── */
  function read(u, id, { since = 0, before = 0 } = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; expire(c);
    let msgs;
    if (before > 0) msgs = c.messages.filter((m) => m.seq < before).slice(-CHAT_LIMITS.page);
    else if (since > 0) msgs = c.messages.filter((m) => m.seq > since || (m.rev2 || 0) > since);
    else msgs = c.messages.slice(-CHAT_LIMITS.page);
    if (since > 0 && msgs.length > 400) msgs = msgs.slice(-400);
    const oldest = c.messages[0]?.seq || 0;
    c.members[u.uid].seenAt = now();
    const pin = c.pinned ? c.messages.find((m) => m.id === c.pinned && !m.deleted) : null;
    let seenUpTo = 0; for (const [uid, mm] of Object.entries(c.members)) if (uid !== u.uid) seenUpTo = Math.max(seenUpTo, mm.lastRead || 0);
    const t = typing.get(id); const live = t ? [...t.entries()].filter(([uid, v]) => uid !== u.uid && v.until > now()) : []; const typers = live.map(([, v]) => v.name).slice(0, 3); const recording = live.some(([, v]) => v.kind === 'voice');
    msgs = msgs.filter((m) => !(Array.isArray(m.hiddenFor) && m.hiddenFor.includes(u.uid)));
    const avs = {}; for (const m of msgs) if (m.uid && !(m.uid in avs)) avs[m.uid] = avVer(m.uid);
    const mu = own(c.muted, u.uid) ? c.muted[u.uid] : null;
    return { avs, recording, scheduled: (c.scheduled || []).filter((x) => x.uid === u.uid).length, slowLeft: slowLeft(c, u), channel: card(c, u.uid), pinned: pin ? msgView(pin, u.uid) : null, typing: typers, seenUpTo, mutedUntil: mu && (!mu.until || mu.until > now()) ? (mu.until || -1) : 0, rev: c.rev, messages: msgs.map((m) => msgView(m, u.uid)), more: msgs.length ? msgs[0].seq > oldest : false, deleted: since > 0 ? c.messages.filter((m) => m.deleted && m.deletedRev > since).map((m) => m.id) : [] };
  }
  function post(u, id, b = {}, internal = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' };
    if (!key) return { error: 'no_secret' };
    if (c.type === 'channel' && !isAdmin(c, u)) return { error: 'admins_only' };   // a broadcast channel: only its admins post
    if ((c.type === 'dm' || c.type === 'secret') && c.blocked && Object.keys(c.blocked).length) return { error: own(c.blocked, u.uid) ? 'you_blocked' : 'blocked' };
    if ((c.type === 'dm' || c.type === 'secret') && load().blocks) { const peer = Object.keys(c.members).find((k) => k !== u.uid); const bl = load().blocks;   // v368: a block made in the other 1:1 chat counts here too
      if (peer && own(bl, `${peer}|${u.uid}`)) return { error: 'blocked' }; if (peer && own(bl, `${u.uid}|${peer}`)) return { error: 'you_blocked' }; }
    let enc = null, encMedia = null;
    if (c.type === 'secret') {   // end-to-end: only ciphertext reaches this server; it never sees the text, the photo or the file
      if (Object.keys(c.keys || {}).length !== 2) return { error: 'secret_pending' };
      if (b.text || b.image || b.poll || b.sticker || b.mentions?.length) return { error: 'bad_request' };
      enc = b.enc ? cleanEnc(b.enc) : null; if (b.enc && !enc) return { error: 'bad_request' };
      if (b.encMedia) { encMedia = cleanEnc(b.encMedia, true); if (!encMedia || !b.media) return { error: 'bad_request' }; }
      if (!enc && !b.media) return { error: 'empty' };
    } else if (b.enc || b.encMedia) return { error: 'bad_request' };
    { const left = slowLeft(c, u); if (left) return { error: 'slow_mode', wait: left }; }
    const mu = c.muted?.[u.uid]; if (own(c.muted, u.uid) && (!mu.until || mu.until > now())) return { error: 'muted', until: mu.until || null };
    const text = clipText(b.text, CHAT_LIMITS.maxText); const poll = b.poll ? makePoll(b.poll) : null;
    if (b.poll && !poll) return { error: 'bad_poll' };
    if (!text && !b.image && !b.media && !poll && !b.sticker && !enc) return { error: 'empty' };
    if (!isAdmin(c, u) && c.type !== 'dm' && c.type !== 'saved') {
      if (c.filterLinks && LINK_RE.test(text)) return { error: 'links_off' };
      const low = text.toLowerCase(); if ((c.words || []).some((w) => low.includes(w))) return { error: 'blocked_word' };
    }
    if (limited(u.uid, 'msg', 30)) return { error: 'rate_limited' };
    let replyTo = null;
    if (b.replyTo) { const r = c.messages.find((x) => x.id === String(b.replyTo) && !x.deleted && !x.sys); if (r) replyTo = { id: r.id, uid: r.uid, name: r.name, text: r.enc ? '' : clip(r.text, 140), kind: r.kind || (r.file ? 'image' : null), enc: Boolean(r.enc) }; }
    let fileId = null, kind = null, fileName = null, size = null;
    let poster = null; const dur = Number.isFinite(Number(b.dur)) && Number(b.dur) > 0 ? Math.min(3600, Math.round(Number(b.dur) * 10) / 10) : null;
    if (b.media) { const p = pending.get(String(b.media)); if (!p || p.uid !== u.uid || p.ch !== id) return { error: 'bad_media' }; pending.delete(String(b.media)); fileId = String(b.media); kind = p.kind; if (kind === 'file') { fileName = p.name; size = p.size; }
      // a video may bring its first frame as a poster (an image this person uploaded to this channel)
      if (kind === 'video' && b.poster) { const q = pending.get(String(b.poster)); if (q && q.uid === u.uid && q.ch === id && q.kind === 'image') { pending.delete(String(b.poster)); poster = String(b.poster); } } }
    else if (b.image) { if (limited(u.uid, 'img', 8)) return { error: 'rate_limited' }; const f = putImage(b.image, id, CHAT_LIMITS.maxImage); if (f.error) return f; fileId = f.id; kind = 'image'; }
    let topic = null; if (b.topic) { topic = (c.topics || []).find((t) => t.id === String(b.topic))?.id || null; if (!topic) return { error: 'bad_topic' }; }
    if (b.sticker) { if (fileId || b.media) return { error: 'bad_request' }; const st2 = stickerCopy(u, id, String(b.sticker)); if (st2.error) return st2; fileId = st2.fid; kind = 'image'; }
    const mentions = Array.isArray(b.mentions) ? [...new Set(b.mentions.map(String))].filter((x) => x !== u.uid && own(c.members, x)).slice(0, 20) : [];
    const seq = bump(c); const m = { id: `m${hex(6)}`, seq, uid: u.uid, name: c.members[u.uid].name || nameOf(u), text, file: fileId, kind, ...(replyTo ? { replyTo } : {}), ...(poster ? { poster } : {}), ...((kind === 'video' || kind === 'voice') && dur ? { dur } : {}),
      ...(fileName ? { fileName, size } : {}), ...(mentions.length ? { mentions } : {}), ...(poll ? { poll } : {}), ...(internal.fwd ? { fwd: { name: clip(internal.fwd.name, 60) } } : {}), ...(internal.bot ? { bot: true } : {}), ...(b.sticker ? { sticker: true } : {}), ...(enc ? { enc } : {}), ...(encMedia ? { encMedia } : {}), ...(b.round && kind === 'video' ? { round: true } : {}), ...(topic ? { topic } : {}), ...(c.ttl ? { exp: now() + c.ttl * 1000 } : {}), at: now() };
    c.members[u.uid].postedAt = now();
    c.messages.push(m); if (!internal.bot) botAuto(c, m); c.members[u.uid].lastRead = seq; trim(c); save(); wake(id);
    // one notice per channel, named after it: a newer one replaces the older (tag), at most one buzz a minute per channel
    clearTyping(id, u.uid);
    for (const [uid, mm] of Object.entries(c.members)) {
      const named = mentions.includes(uid);   // being mentioned gets through a muted group and the one-a-minute limit
      if (b.silent || internal.silent || uid.startsWith('bot_')) continue;
      if (!named && mm.muteUntil && mm.muteUntil > now()) continue;
      if (uid === u.uid || (mm.notify === false && !named) || now() - (mm.seenAt || 0) < 45_000 || (!named && now() - (mm.notifiedAt || 0) < 60_000)) continue;
      if (mm.via === 'plan' && !peekUid(c, uid)) continue;   // a lapsed subscription gets no notices either
      mm.notifiedAt = now(); pushChannel(c, uid, m);
    }
    return { message: msgView(m, u.uid), rev: c.rev };
  }
  const peekUid = (c, uid) => peek({ uid, email: c.members[uid]?.email || '' }, c);
  /* ── v357: edit, reactions, pin, typing, search, ban / mute, my notifications ── */
  const typing = new Map();   // channel id → Map(uid → { name, until })
  function clearTyping(id, uid) { typing.get(id)?.delete(uid); }
  function setTyping(u, id, kind = '') {
    const c = gate(u, id); if (!c) return { error: 'not_found' };
    if (!typing.has(id)) typing.set(id, new Map()); const t = typing.get(id); const was = t.get(u.uid);
    t.set(u.uid, { name: c.members[u.uid].name || nameOf(u), until: now() + 6000, kind: kind === 'voice' ? 'voice' : '' });
    if (!was || was.until - 6000 < now() - 2500) wake(id);   // tell the others at most every 2.5 s
    return { ok: true };
  }
  const findMsg = (c, mid) => c.messages.find((x) => x.id === String(mid) && !x.sys) || null;
  function editMessage(u, id, mid, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const m = findMsg(c, mid);
    if (!m || m.deleted) return { error: 'not_found' }; if (m.uid !== u.uid) return { error: 'forbidden' };
    if (now() - m.at > 48 * 3600_000) return { error: 'too_old' };
    if (c.type === 'secret') { if (limited(u.uid, 'edit', 20)) return { error: 'rate_limited' }; const e2 = cleanEnc(b.enc); if (!e2 || !m.enc) return { error: 'bad_request' }; m.enc = e2; m.edited = now(); m.rev2 = bump(c); save(); wake(id); return { message: msgView(m, u.uid), rev: c.rev }; }
    const text = clipText(b.text, CHAT_LIMITS.maxText); if (!text && !m.file) return { error: 'empty' };
    if (limited(u.uid, 'edit', 20)) return { error: 'rate_limited' };
    m.text = text; m.edited = now(); m.rev2 = bump(c); save(); wake(id); return { message: msgView(m, u.uid), rev: c.rev };
  }
  function react(u, id, mid, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const m = findMsg(c, mid); if (!m || m.deleted) return { error: 'not_found' };
    const e = String(b.emoji || ''); if (!CHAT_REACTIONS.includes(e)) return { error: 'bad_reaction' };
    if (limited(u.uid, 'react', 60)) return { error: 'rate_limited' };
    m.reactions = m.reactions && typeof m.reactions === 'object' ? m.reactions : {};
    for (const k of Object.keys(m.reactions)) if (k !== e) m.reactions[k] = m.reactions[k].filter((x) => x !== u.uid);   // one reaction per person
    const l = own(m.reactions, e) ? m.reactions[e] : (m.reactions[e] = []);
    if (l.includes(u.uid)) m.reactions[e] = l.filter((x) => x !== u.uid); else l.push(u.uid);
    for (const k of Object.keys(m.reactions)) if (!m.reactions[k].length) delete m.reactions[k];
    m.rev2 = bump(c); save(); wake(id); return { message: msgView(m, u.uid), rev: c.rev };
  }
  function pin(u, id, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!can(c, u, 'pin')) return { error: 'forbidden' };
    if (c.type !== 'dm' && c.type !== 'saved') logAct(c, u, b.id == null ? 'unpin' : 'pin');
    if (b.id == null) c.pinned = null; else { const m = findMsg(c, b.id); if (!m || m.deleted) return { error: 'not_found' }; c.pinned = m.id; }
    bump(c); save(); wake(id); return { ok: true, pinned: c.pinned };
  }
  function search(u, id, q) {
    const c = gate(u, id); if (!c) return { error: 'not_found' };
    const k = String(q || '').trim().toLowerCase().slice(0, 80); if (k.length < 2) return { results: [] };
    if (limited(u.uid, 'search', 30)) return { error: 'rate_limited' };
    return { results: c.messages.filter((m) => !m.deleted && !m.sys && (m.text || '').toLowerCase().includes(k)).slice(-50).reverse().map((m) => msgView(m, u.uid)) };
  }
  function moderate(u, id, uid, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!can(c, u, 'ban') || c.type === 'dm') return { error: 'forbidden' };
    if (uid === u.uid || uid === c.createdBy) return { error: 'forbidden' };
    if (own(c.members, uid) && c.members[uid].role === 'admin' && c.createdBy !== u.uid && !isOwner(u)) return { error: 'forbidden' };   // only the creator acts on other admins
    const act = String(b.action || ''); const name = own(c.members, uid) ? c.members[uid].name : (own(c.banned, uid) ? c.banned[uid].name : null);
    if (!name) return { error: 'not_found' };
    if (act === 'ban') { c.banned = c.banned || {}; c.banned[uid] = { name, at: now(), by: u.uid }; delete c.members[uid]; const k = calls.get(id); if (k && own(k.peers, uid)) { delete k.peers[uid]; callBump(id, k); } sys(c, 'banned', nameOf(u), name); }
    else if (act === 'unban') { if (!own(c.banned, uid)) return { error: 'not_found' }; delete c.banned[uid]; bump(c); }
    else if (act === 'mute') { if (!own(c.members, uid)) return { error: 'not_found' }; const mins = Math.max(0, Math.min(60 * 24 * 30, Math.round(Number(b.minutes) || 0))); c.muted = c.muted || {}; c.muted[uid] = { until: mins ? now() + mins * 60_000 : 0, by: u.uid }; sys(c, 'muted', nameOf(u), name); }
    else if (act === 'unmute') { if (c.muted && own(c.muted, uid)) delete c.muted[uid]; bump(c); }
    else return { error: 'bad_request' };
    logAct(c, u, act, name); save(); wake(id); return { ok: true, banned: Object.entries(c.banned || {}).map(([k, v]) => ({ uid: k, name: v.name, at: v.at })) };
  }
  function setNotify(u, id, on) { const c = gate(u, id); if (!c) return { error: 'not_found' }; c.members[u.uid].notify = Boolean(on); save(); return { ok: true, notify: Boolean(on) }; }
  /* ── v358: direct chats, saved messages, forwarding, polls, invites, join requests, slow mode, filters, admin log ── */
  const LINK_RE = /(https?:\/\/|www\.|t\.me\/|wa\.me\/|\b[a-z0-9-]{2,}\.(com|net|org|io|me|ly|xyz|app|link|gg|co)\b)/i;
  function slowLeft(c, u) {
    if (!c.slow || isAdmin(c, u) || c.type === 'dm' || c.type === 'saved') return 0;
    const last = c.members[u.uid]?.postedAt || 0; const left = Math.ceil((last + c.slow * 1000 - now()) / 1000); return left > 0 ? left : 0;
  }
  function makePoll(p) {
    const q = clip(p?.q, 200); const opts = Array.isArray(p?.options) ? [...new Set(p.options.map((o) => clip(o, 100)).filter(Boolean))].slice(0, 10) : [];
    if (q.length < 2 || opts.length < 2) return null;
    return { q, anon: Boolean(p.anon), multi: Boolean(p.multi), options: opts.map((t) => ({ t, v: [] })), names: {} };
  }
  function vote(u, id, mid, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const m = findMsg(c, mid); if (!m || m.deleted || !m.poll) return { error: 'not_found' };
    const p = m.poll; if (p.closed) return { error: 'poll_closed' };
    if (b.close) { if (m.uid !== u.uid && !can(c, u, 'delete')) return { error: 'forbidden' }; p.closed = true; }
    else {
      const i = Number(b.option); if (!Number.isInteger(i) || i < 0 || i >= p.options.length) return { error: 'bad_request' };
      if (limited(u.uid, 'vote', 30)) return { error: 'rate_limited' };
      const o = p.options[i]; const had = o.v.includes(u.uid);
      if (!p.multi) for (const x of p.options) x.v = x.v.filter((k) => k !== u.uid);
      o.v = had ? o.v.filter((k) => k !== u.uid) : [...o.v.filter((k) => k !== u.uid), u.uid];
      p.names = p.names || {}; p.names[u.uid] = c.members[u.uid].name || nameOf(u);
    }
    m.rev2 = bump(c); save(); wake(id); return { message: msgView(m, u.uid), rev: c.rev };
  }
  const dmKey = (a, b) => [a, b].sort().join('|');
  // v368: a member who came in through a plan counts only while that plan still opens the channel (lapsed = no DMs / stories through it)
  const active = (c, uid) => own(c.members, uid) && (c.members[uid].via !== 'plan' || peekUid(c, uid));
  const shareAny = (a, b) => Object.values(load().channels).some((c) => c.type !== 'dm' && c.type !== 'saved' && c.type !== 'secret' && active(c, a) && active(c, b));
  /** Opens (or finds) the direct chat between two people. Only between people who share a group, or with a site owner. */
  function openDm(u, b = {}) {
    if (!key) return { error: 'no_secret' };
    const to = String(b.uid || ''); if (!to || to === u.uid || !/^[A-Za-z0-9_-]{1,128}$/.test(to) || to === '__proto__') return { error: 'bad_request' };
    const d = load(); const k = dmKey(u.uid, to);
    const found = Object.values(d.channels).find((c) => c.type === 'dm' && c.dmKey === k); if (found) return { channel: card(found, u.uid) };
    let peer = null; for (const c of Object.values(d.channels)) if (own(c.members, to)) { peer = c.members[to]; break; }
    const pf = d.profiles && own(d.profiles, to) ? d.profiles[to] : null; if (!peer && pf) peer = { name: pf.name, email: pf.email };
    if (!peer) return { error: 'not_found' };
    const open = pf?.dmFrom === 'all' && pf.username;   // people who allow messages from everyone (Telegram style), found by their @username
    if (!isOwner(u) && !isOwnerEmail({ email: peer.email }) && !shareAny(u.uid, to) && !open) return { error: 'dm_closed' };
    if (limited(u.uid, 'dm', 10, 3600_000)) return { error: 'rate_limited' };
    const id = `c${hex(6)}`; const c = { id, type: 'dm', dmKey: k, name: '', logo: null, createdBy: u.uid, createdAt: now(), rev: 0, messages: [],
      members: { [u.uid]: { role: 'member', name: nameOf(u), email: emailOf(u), addedAt: now(), addedBy: u.uid, lastRead: 0 }, [to]: { role: 'member', name: clip(peer.name, 40), email: peer.email, addedAt: now(), addedBy: u.uid, lastRead: 0 } } };
    for (const [a, b2] of [[u.uid, to], [to, u.uid]]) if (d.blocks && own(d.blocks, `${a}|${b2}`)) { c.blocked = c.blocked || {}; c.blocked[a] = d.blocks[`${a}|${b2}`]; }   // v368: an earlier block carries over
    bump(c); d.channels[id] = c; save(); return { channel: card(c, u.uid) };
  }
  function openSaved(u) {
    if (!key) return { error: 'no_secret' };
    const d = load(); const k = `saved:${u.uid}`; let c = Object.values(d.channels).find((x) => x.type === 'saved' && x.dmKey === k);
    if (!c) { const id = `c${hex(6)}`; c = { id, type: 'saved', dmKey: k, name: '', logo: null, createdBy: u.uid, createdAt: now(), rev: 0, messages: [], members: { [u.uid]: { role: 'member', name: nameOf(u), email: emailOf(u), addedAt: now(), addedBy: u.uid, lastRead: 0 } } }; bump(c); d.channels[id] = c; save(); }
    return { channel: card(c, u.uid) };
  }
  function block(u, id, on) {
    const c = gate(u, id); if (!c || (c.type !== 'dm' && c.type !== 'secret')) return { error: 'not_found' };
    c.blocked = c.blocked || {}; if (on) c.blocked[u.uid] = now(); else delete c.blocked[u.uid];
    // v368 security: the block also lives on the pair of people, so deleting the chat and opening a new one does not lift it
    const peer = Object.keys(c.members).find((k) => k !== u.uid); const d = load(); d.blocks = d.blocks || {};
    if (peer) { if (on) d.blocks[`${u.uid}|${peer}`] = now(); else delete d.blocks[`${u.uid}|${peer}`]; }
    bump(c); save(); wake(id); return { ok: true, channel: card(c, u.uid) };
  }
  function report(u, id, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (limited(u.uid, 'report', 5, 3600_000)) return { error: 'rate_limited' };
    const m = b.mid ? findMsg(c, b.mid) : null; const d = load(); d.reports = Array.isArray(d.reports) ? d.reports : [];
    d.reports.push({ id: `r${hex(5)}`, at: now(), by: nameOf(u), byEmail: emailOf(u), byUid: u.uid, channel: c.type === 'dm' ? 'DM' : c.name, about: m ? m.name : clip(b.about, 60), text: m ? clip(m.text || m.kind || '', 300) : '', reason: clip(b.reason, 300) });
    if (d.reports.length > 500) d.reports.splice(0, d.reports.length - 500); save(); return { ok: true };
  }
  function reports(u) { if (!isOwner(u)) return { error: 'forbidden' }; return { reports: [...(load().reports || [])].reverse() }; }
  function clearReport(u, rid) { if (!isOwner(u)) return { error: 'forbidden' }; const d = load(); d.reports = (d.reports || []).filter((r) => r.id !== rid); save(); return reports(u); }
  /** Copies a message into another chat of the same person (the file is re-encrypted for the new chat). */
  function forward(u, id, mid, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const m = findMsg(c, mid); if (!m || m.deleted) return { error: 'not_found' };
    const to = String(b.to || ''); const t = gate(u, to); if (!t) return { error: 'not_found' };
    if (c.type === 'secret' || t.type === 'secret') return { error: 'secret_no_forward' };
    if (m.poll) return { error: 'bad_request' };
    // review fix: the target's rules and the limits are checked BEFORE any copy, and copied bytes count against the daily quota
    if (t.type === 'channel' && !isAdmin(t, u)) return { error: 'admins_only' };
    if ((t.type === 'dm') && t.blocked && Object.keys(t.blocked).length) return { error: 'blocked' };
    if (own(t.muted, u.uid) && (!t.muted[u.uid].until || t.muted[u.uid].until > now())) return { error: 'muted' };
    if (slowLeft(t, u)) return { error: 'slow_mode' };
    if (limited(u.uid, 'fwd', 20)) return { error: 'rate_limited' };
    if (m.file) { const f0 = getFile(u, id, m.file); if (!f0) return { error: 'not_found' }; const q = chargeQuota(u, f0.data.length + (m.poster ? 200_000 : 0)); if (q) return q; }
    let media = null, poster = null;
    const copy = (fid, kind, extra = {}) => { const f = getFile(u, id, fid); if (!f) return null; const nid = writeFile(to, f.type, f.data); pending.set(nid, { uid: u.uid, ch: to, kind, at: now(), ...extra }); return nid; };
    if (m.file) { media = copy(m.file, m.kind || 'image', m.kind === 'file' ? { name: m.fileName, size: m.size } : {}); if (!media) return { error: 'not_found' }; if (m.poster) poster = copy(m.poster, 'image'); }
    const r = post(u, to, { text: m.text, media, poster, dur: m.dur }, { fwd: { name: c.type === 'channel' ? c.name : m.name } });
    if (r.error) for (const x of [media, poster]) if (x && pending.has(x)) { pending.delete(x); dropFile(x); }   // re-review fix: a refused forward leaves no copies behind
    return r;
  }
  /* invites: an admin makes a link (optionally with an end date, a use limit, or admin approval); anyone signed in who opens it joins or asks */
  function makeInvite(u, id, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!can(c, u, 'invite') || c.type === 'dm' || c.type === 'saved') return { error: 'forbidden' };
    c.invites = c.invites || {}; if (Object.keys(c.invites).length >= 20) return { error: 'too_many_invites' };
    const code = crypto.randomBytes(12).toString('base64url'); const hours = Math.max(0, Math.min(24 * 90, Math.round(Number(b.hours) || 0))); const max = Math.max(0, Math.min(10_000, Math.round(Number(b.max) || 0)));
    c.invites[code] = { at: now(), by: u.uid, byName: nameOf(u), expires: hours ? now() + hours * 3600_000 : 0, max, uses: 0, approve: Boolean(b.approve) };
    logAct(c, u, 'invite'); save(); return { code, ...members(u, id) };
  }
  function dropInvite(u, id, code) { const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!can(c, u, 'invite')) return { error: 'forbidden' }; if (c.invites && own(c.invites, code)) { delete c.invites[code]; logAct(c, u, 'invite_off'); save(); } return members(u, id); }
  function findInvite(code) {
    if (!INVITE_RE.test(String(code))) return null;
    for (const c of Object.values(load().channels)) if (c.invites && own(c.invites, code)) { const v = c.invites[code]; if ((v.expires && v.expires < now()) || (v.max && v.uses >= v.max)) return null; return { c, v }; }
    return null;
  }
  function invitePeek(u, code) {
    const f = findInvite(code); if (!f) return { error: 'not_found' }; const { c, v } = f;
    return { name: c.name, type: typeOf(c), description: c.description || '', members: Object.keys(c.members).length, verified: Boolean(c.verified), color: c.color || null, approve: v.approve, member: own(c.members, u.uid), asked: Boolean(c.requests && own(c.requests, u.uid)), id: own(c.members, u.uid) ? c.id : null };
  }
  function joinInvite(u, code) {
    const f = findInvite(code); if (!f) return { error: 'not_found' }; const { c, v } = f;
    if (own(c.members, u.uid)) return { joined: true, id: c.id };
    if (c.banned && own(c.banned, u.uid)) return { error: 'banned' };
    if (!isProven(u)) return { error: 'email_unverified' };
    if (limited(u.uid, 'join', 10, 3600_000)) return { error: 'rate_limited' };
    if (Object.keys(c.members).length >= CHAT_LIMITS.maxMembers) return { error: 'channel_full' };
    if (v.approve) {
      c.requests = c.requests || {}; if (!own(c.requests, u.uid) && Object.keys(c.requests).length >= 300) return { error: 'rate_limited' };
      c.requests[u.uid] = { name: nameOf(u), email: emailOf(u), at: now() }; bump(c); save(); wake(id0(c));
      for (const [k, mm] of Object.entries(c.members)) if (mm.role === 'admin' && can(c, { uid: k, email: mm.email }, 'invite') && !limited(`${k}:${c.id}`, 'reqnote', 1, 600_000)) notify?.(k, { title: c.name, body: langOf(k) === 'ar' ? `${nameOf(u)} طالب ينضم.` : `${nameOf(u)} asked to join.`, url: `/#/app/chat?c=${c.id}`, tag: `chat-${c.id}` });
      return { asked: true };
    }
    v.uses = (v.uses || 0) + 1;
    c.members[u.uid] = { role: 'member', name: nameOf(u), email: emailOf(u), addedAt: now(), addedBy: v.by, lastRead: 0, via: 'link' };
    sys(c, 'joined', nameOf(u)); save(); wake(c.id); botWelcome(c, nameOf(u)); return { joined: true, id: c.id };
  }
  const id0 = (c) => c.id;
  function answerRequest(u, id, uid, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!can(c, u, 'invite')) return { error: 'forbidden' };
    if (!c.requests || !own(c.requests, uid)) return { error: 'not_found' }; const r = c.requests[uid]; delete c.requests[uid];
    if (b.accept) {
      if (Object.keys(c.members).length >= CHAT_LIMITS.maxMembers) return { error: 'channel_full' };
      c.members[uid] = { role: 'member', name: clip(r.name, 40), email: r.email, addedAt: now(), addedBy: u.uid, lastRead: 0, via: 'link' };
      sys(c, 'joined', r.name); logAct(c, u, 'accept', r.name); botWelcome(c, r.name);
      notify?.(uid, { title: c.name, body: langOf(uid) === 'ar' ? `انقبل طلبك. صرت عضو بـ«${c.name}».` : `You're in «${c.name}».`, url: `/#/app/chat?c=${c.id}`, tag: `chat-${c.id}` });
    } else logAct(c, u, 'decline', r.name);
    bump(c); save(); wake(id); return members(u, id);
  }
  function activity(u, id) { const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!isAdmin(c, u)) return { error: 'forbidden' }; return { log: [...(c.log || [])].reverse().slice(0, 200) }; }
  /* ── v359: disappearing messages, topics, stickers, stories, translation ── */
  function expire(c) {
    if (!c.messages.some((m) => m.exp && m.exp <= now())) return;
    for (const m of c.messages) if (m.exp && m.exp <= now()) { dropFile(m.file); dropFile(m.poster); if (c.pinned === m.id) c.pinned = null; }
    c.messages = c.messages.filter((m) => !m.exp || m.exp > now()); bump(c); save();
  }
  function setTtl(u, id, b = {}) {   // both people in a direct chat, or an admin with "info", choose how long new messages live
    const c = gate(u, id); if (!c) return { error: 'not_found' };
    if (c.type === 'dm' || c.type === 'secret' ? false : !can(c, u, 'info')) return { error: 'forbidden' };
    c.ttl = TTLS.includes(Number(b.ttl)) ? Number(b.ttl) : 0; sys(c, 'ttl', nameOf(u), String(c.ttl)); if (c.type !== 'dm' && c.type !== 'saved') logAct(c, u, 'ttl');
    save(); wake(id); return { channel: card(c, u.uid) };
  }
  function topicAdd(u, id, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!can(c, u, 'info') || c.type === 'dm' || c.type === 'saved') return { error: 'forbidden' };
    const name = clip(b.name, 40); if (name.length < 2) return { error: 'bad_name' }; c.topics = c.topics || []; if (c.topics.length >= 30) return { error: 'too_many_topics' };
    const emoji = /^\p{Extended_Pictographic}[️‍\p{Extended_Pictographic}]{0,6}$/u.test(String(b.emoji || '')) ? String(b.emoji) : '';
    c.topics.push({ id: `t${hex(4)}`, name, emoji }); logAct(c, u, 'topic', name); bump(c); save(); wake(id); return { channel: card(c, u.uid) };
  }
  function topicDel(u, id, tid) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!can(c, u, 'info')) return { error: 'forbidden' };
    const t = (c.topics || []).find((x) => x.id === tid); if (!t) return { error: 'not_found' };
    c.topics = c.topics.filter((x) => x.id !== tid); for (const m of c.messages) if (m.topic === tid) delete m.topic;   // its messages go back to General
    logAct(c, u, 'topic_off', t.name); bump(c); save(); wake(id); return { channel: card(c, u.uid) };
  }
  /* stickers: each person keeps up to 60 of their own (made from any photo); sending one copies it into the chat */
  const sAad = (uid, fid) => `sticker:${uid}:${fid}`;
  function myStickers(u) { return { stickers: (load().stickers?.[u.uid] || []).map((x) => x.fid) }; }
  function stickerAdd(u, buf) {
    if (!key) return { error: 'no_secret' }; if (!buf?.length) return { error: 'bad_image' };
    const type = sniffImage(buf); if (!type) return { error: 'bad_image' }; if (buf.length > 1_500_000) return { error: 'image_too_large' };
    if (limited(u.uid, 'sticker', 20)) return { error: 'rate_limited' };
    const d = load(); d.stickers = d.stickers || {}; const l = own(d.stickers, u.uid) ? d.stickers[u.uid] : (d.stickers[u.uid] = []);
    if (l.length >= 60) return { error: 'too_many_stickers' };
    const fid = `f${hex(8)}`; fs.mkdirSync(fdir, { recursive: true, mode: 0o700 });
    fs.writeFileSync(path.join(fdir, `${fid}.bin`), enc(Buffer.concat([Buffer.from(`${type}\n`), buf]), sAad(u.uid, fid)), { mode: 0o600 });
    l.push({ fid, at: now() }); save(); return myStickers(u);
  }
  function stickerFromMsg(u, id, mid) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const m = findMsg(c, mid); if (!m || m.deleted || !m.file || (m.kind && m.kind !== 'image')) return { error: 'not_found' };
    const f = getFile(u, id, m.file); if (!f) return { error: 'not_found' }; return stickerAdd(u, f.data);
  }
  function stickerFile(u, fid) {
    if (!FILE_RE.test(String(fid)) || !(load().stickers?.[u.uid] || []).some((x) => x.fid === fid)) return null;
    try { const buf = dec(fs.readFileSync(path.join(fdir, `${fid}.bin`)), sAad(u.uid, fid)); const nl = buf.indexOf(10); return { type: buf.subarray(0, nl).toString(), data: buf.subarray(nl + 1) }; } catch { return null; }
  }
  function stickerDel(u, fid) { const d = load(); const l = d.stickers?.[u.uid]; if (!l || !own(d.stickers, u.uid)) return myStickers(u); if (l.some((x) => x.fid === fid)) { d.stickers[u.uid] = l.filter((x) => x.fid !== fid); dropFile(fid); save(); } return myStickers(u); }
  function stickerCopy(u, id, fid) { const f = stickerFile(u, fid); if (!f) return { error: 'not_found' }; if (limited(u.uid, 'img', 8)) return { error: 'rate_limited' }; const q = chargeQuota(u, f.data.length); if (q) return q; return { fid: writeFile(id, f.type, f.data) }; }
  /* stories: a photo or short video that lives 24 hours; seen by the people who share a group or a direct chat with you */
  const STORY_MS = 86_400_000; const tAad = (uid, fid) => `story:${uid}:${fid}`;
  const circleOf = (uid) => { const s2 = new Set(); for (const c of Object.values(load().channels)) if (c.type !== 'saved' && active(c, uid) && !(c.type === 'dm' && c.blocked && Object.keys(c.blocked).length)) for (const k of Object.keys(c.members)) s2.add(k); s2.delete(uid); return s2; };
  function sweepStories() { const d = load(); if (!d.stories) return; let any = false; for (const [uid, l] of Object.entries(d.stories)) { const keep = l.filter((x) => x.at + STORY_MS > now()); if (keep.length !== l.length) { for (const x of l) if (!keep.includes(x)) dropFile(x.fid); d.stories[uid] = keep; any = true; } if (!keep.length) delete d.stories[uid]; } if (any) save(); }
  function storyAdd(u, buf, { caption = '' } = {}) {
    if (!key) return { error: 'no_secret' }; if (!buf?.length) return { error: 'bad_media' };
    const img = sniffImage(buf); const vid = img ? null : sniffVideo(buf); if (!img && !vid) return { error: 'bad_media' };
    if ((img && buf.length > CHAT_LIMITS.maxImageRaw) || (vid && buf.length > 30_000_000)) return { error: vid ? 'video_too_large' : 'image_too_large' };
    if (limited(u.uid, 'story', 10, 3600_000)) return { error: 'rate_limited' };
    sweepStories(); const d = load(); d.stories = d.stories || {}; const l = own(d.stories, u.uid) ? d.stories[u.uid] : (d.stories[u.uid] = []);
    if (l.length >= 20) return { error: 'too_many_stories' };
    const fid = `f${hex(8)}`; fs.mkdirSync(fdir, { recursive: true, mode: 0o700 });
    fs.writeFileSync(path.join(fdir, `${fid}.bin`), enc(Buffer.concat([Buffer.from(`${img || vid}\n`), buf]), tAad(u.uid, fid)), { mode: 0o600 });
    l.push({ fid, at: now(), kind: vid ? 'video' : 'image', caption: clip(caption, 200), name: nameOf(u), seen: {} }); save(); return stories(u);
  }
  function stories(u) {
    sweepStories(); const d = load(); const ring = circleOf(u.uid); ring.add(u.uid); const out = [];
    for (const [uid, l] of Object.entries(d.stories || {})) { if (!ring.has(uid) || !l.length) continue;
      out.push({ uid, name: l[l.length - 1].name, me: uid === u.uid, items: l.map((x) => ({ fid: x.fid, at: x.at, kind: x.kind, caption: x.caption, seen: own(x.seen, u.uid), views: uid === u.uid ? Object.values(x.seen).map((v) => v.name) : undefined })) }); }
    out.sort((a, b) => (b.me - a.me) || (a.items.every((x) => x.seen) - b.items.every((x) => x.seen)) || (b.items.at(-1).at - a.items.at(-1).at));
    return { stories: out };
  }
  function storyGet(u, owner, fid) {
    const l = load().stories?.[owner]; if (!l || !own(load().stories, owner)) return null; const x = l.find((y) => y.fid === fid); if (!x || x.at + STORY_MS < now()) return null;
    if (owner !== u.uid && !circleOf(u.uid).has(owner)) return null;
    if (owner !== u.uid && !own(x.seen, u.uid)) { x.seen[u.uid] = { name: nameOf(u), at: now() }; save(); }
    try { const buf = dec(fs.readFileSync(path.join(fdir, `${fid}.bin`)), tAad(owner, fid)); const nl = buf.indexOf(10); return { type: buf.subarray(0, nl).toString(), data: buf.subarray(nl + 1) }; } catch { return null; }
  }
  function storyDel(u, fid) { const d = load(); const l = d.stories?.[u.uid]; if (l && own(d.stories, u.uid) && l.some((x) => x.fid === fid)) { d.stories[u.uid] = l.filter((x) => x.fid !== fid); dropFile(fid); save(); } return stories(u); }
  /* translation through the site's own AI service (the result is marked as machine translation) */
  async function translateMsg(u, id, mid, lang) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const m = findMsg(c, mid); if (!m || m.deleted || !m.text || c.type === 'secret') return { error: 'not_found' };
    const to = lang === 'en' ? 'en' : 'ar'; m.tr = m.tr || {}; if (m.tr[to] && m.tr.src === m.text) return { text: m.tr[to], lang: to, ai: true };
    if (!translate) return { error: 'ai_off' }; if (limited(u.uid, 'translate', 20)) return { error: 'rate_limited' };
    const out = await translate(u, m.text, to); if (!out || out.error) return { error: out?.error || 'ai_off' };
    m.tr = { src: m.text, [to]: clip(out.text, CHAT_LIMITS.maxText) }; save(); return { text: m.tr[to], lang: to, ai: true };
  }
  /* ── v360: profiles, chat folders (archive / pin / mute for a while), global search, shared media, scheduled & silent, delete for me, readers ── */
  const profOf = (uid) => { const d = load(); return d.profiles && own(d.profiles, uid) ? d.profiles[uid] : null; };
  const avVer = (uid) => profOf(uid)?.avatar ? profOf(uid).av || 1 : 0;
  const pubProfile = (uid) => { const p2 = profOf(uid); return { username: p2?.username || null, bio: p2?.bio || '', av: p2?.avatar ? p2.av || 1 : 0 }; };
  function myProfile(u) { const p2 = profOf(u.uid) || {}; return { uid: u.uid, name: nameOf(u), username: p2.username || '', bio: p2.bio || '', dmFrom: p2.dmFrom === 'all' ? 'all' : 'groups', av: avVer(u.uid) }; }
  function setProfile(u, b = {}) {
    if (!key) return { error: 'no_secret' }; const d = load(); d.profiles = d.profiles || {}; const p2 = own(d.profiles, u.uid) ? d.profiles[u.uid] : (d.profiles[u.uid] = {});
    if (b.username != null) {
      const un = String(b.username).trim().replace(/^@/, '').toLowerCase();
      if (un === '') delete p2.username;
      else { if (!USERNAME_RE.test(un)) return { error: 'bad_username' }; if (Object.entries(d.profiles).some(([k, v]) => k !== u.uid && v.username === un)) return { error: 'username_taken' };
        if (un !== d.profiles[u.uid]?.username && (/bot$/.test(un) || Object.values(d.bots || {}).some((x) => x.username === un))) return { error: 'username_taken' };   // v368: bot names are for bots only
        p2.username = un; }
    }
    if (b.bio != null) p2.bio = clipText(b.bio, 140);
    if (b.dmFrom != null) p2.dmFrom = b.dmFrom === 'all' ? 'all' : 'groups';
    p2.name = nameOf(u); p2.email = emailOf(u); save(); return myProfile(u);
  }
  function setAvatar(u, buf) {
    if (!key) return { error: 'no_secret' }; if (!buf?.length) { const p0 = profOf(u.uid); if (p0?.avatar) { dropFile(p0.avatar); delete p0.avatar; p0.av = (p0.av || 1) + 1; save(); } return myProfile(u); }
    const type = sniffImage(buf); if (!type || type === 'image/gif') return { error: 'bad_image' }; if (buf.length > 600_000) return { error: 'image_too_large' };
    if (limited(u.uid, 'avatar', 6, 3600_000)) return { error: 'rate_limited' };
    const d = load(); d.profiles = d.profiles || {}; const p2 = own(d.profiles, u.uid) ? d.profiles[u.uid] : (d.profiles[u.uid] = { name: nameOf(u), email: emailOf(u) });
    const fid = `f${hex(8)}`; fs.mkdirSync(fdir, { recursive: true, mode: 0o700 });
    fs.writeFileSync(path.join(fdir, `${fid}.bin`), enc(Buffer.concat([Buffer.from(`${type}\n`), buf]), `avatar:${u.uid}:${fid}`), { mode: 0o600 });
    if (p2.avatar) dropFile(p2.avatar); p2.avatar = fid; p2.av = (p2.av || 1) + 1; save(); return myProfile(u);
  }
  function avatarFile(uid) { const p2 = profOf(uid); if (!p2?.avatar) return null; try { const buf = dec(fs.readFileSync(path.join(fdir, `${p2.avatar}.bin`)), `avatar:${uid}:${p2.avatar}`); const nl = buf.indexOf(10); return { type: buf.subarray(0, nl).toString(), data: buf.subarray(nl + 1) }; } catch { return null; } }
  function profile(u, uid) {   // a person's card: for people you share a chat with, or who have a public @username
    const p2 = profOf(uid); let name = p2?.name || null; let shared = false;
    for (const c of Object.values(load().channels)) if (active(c, uid) && active(c, u.uid) && c.type !== 'saved') { shared = true; name = name || c.members[uid].name; }
    if (!shared && !p2?.username) return { error: 'not_found' };
    return { uid, name: name || 'Member', ...pubProfile(uid), canDm: shared || p2?.dmFrom === 'all' || isOwner(u) };
  }
  function people(u, q) {
    const k = String(q || '').trim().replace(/^@/, '').toLowerCase(); if (k.length < 3) return { people: [] };
    if (limited(u.uid, 'people', 30)) return { error: 'rate_limited' };
    return { people: Object.entries(load().profiles || {}).filter(([uid, v]) => uid !== u.uid && v.username && v.username.startsWith(k)).slice(0, 10).map(([uid, v]) => ({ uid, name: v.name || 'Member', username: v.username, bio: v.bio || '', av: v.avatar ? v.av || 1 : 0, dm: v.dmFrom === 'all' })) };
  }
  function setPrefs(u, id, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const me = c.members[u.uid];
    if (b.archived != null) me.archived = Boolean(b.archived);
    if (b.pinned != null) { if (b.pinned && Object.values(load().channels).filter((x) => own(x.members, u.uid) && x.members[u.uid].pinnedAt).length >= 10) return { error: 'too_many_pins' }; me.pinnedAt = b.pinned ? now() : 0; }
    if (b.mute != null) { const mins = Number(b.mute); if (mins === -1) { me.notify = false; me.muteUntil = 0; } else if (mins > 0) { me.notify = true; me.muteUntil = now() + Math.min(mins, 525_600) * 60_000; } else { me.notify = true; me.muteUntil = 0; } }
    save(); return { channel: card(c, u.uid) };
  }
  function searchAll(u, q) {
    const k = String(q || '').trim().toLowerCase().slice(0, 80); if (k.length < 2) return { results: [], people: [] };
    if (limited(u.uid, 'searchall', 20)) return { error: 'rate_limited' };
    const out = [];
    for (const c of Object.values(load().channels)) { if (!peek(u, c) || c.type === 'secret') continue;
      for (const m of c.messages) if (!m.deleted && !m.sys && m.text && m.text.toLowerCase().includes(k) && !(m.hiddenFor || []).includes(u.uid)) out.push({ ch: c.id, chName: card(c, u.uid).name, chType: typeOf(c), message: msgView(m, u.uid) }); }
    out.sort((a, b2) => b2.message.at - a.message.at);
    const ppl = k.replace(/^@/, '').length >= 3 ? people(u, k).people || [] : [];
    return { results: out.slice(0, 40), people: ppl };
  }
  const URL_RE = /https?:\/\/[^\s<>"']{3,300}/i;
  function sharedMedia(u, id, kind) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (c.type === 'secret') return { items: [] };
    const pick = kind === 'file' ? (m) => m.kind === 'file' : kind === 'voice' ? (m) => m.kind === 'voice' : kind === 'link' ? (m) => URL_RE.test(m.text || '') : (m) => m.file && !m.sticker && (m.kind === 'image' || m.kind === 'video' || !m.kind);
    return { items: c.messages.filter((m) => !m.deleted && !m.sys && !(m.hiddenFor || []).includes(u.uid) && pick(m)).slice(-120).reverse().map((m) => ({ ...msgView(m, u.uid), link: kind === 'link' ? (URL_RE.exec(m.text) || [''])[0] : undefined })) };
  }
  function hideForMe(u, id, mid) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const m = findMsg(c, mid); if (!m) return { error: 'not_found' };
    m.hiddenFor = [...new Set([...(m.hiddenFor || []), u.uid])].slice(0, 600); save(); return { ok: true };
  }
  function readers(u, id, mid) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const m = findMsg(c, mid); if (!m) return { error: 'not_found' };
    if (m.uid !== u.uid) return { error: 'forbidden' }; if (Object.keys(c.members).length > 100 || c.type === 'channel') return { readers: [], hidden: true };
    return { readers: Object.entries(c.members).filter(([k, mm]) => k !== u.uid && (mm.lastRead || 0) >= m.seq).map(([k, mm]) => ({ uid: k, name: mm.name, av: avVer(k) })) };
  }
  /* scheduled messages: kept with the chat, sent by the server at their time (text, and polls); the sender can cancel them */
  function schedule(u, id, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (c.type === 'secret') return { error: 'bad_request' }; const at = Number(b.at);
    if (!Number.isFinite(at) || at < now() + 30_000 || at > now() + 30 * 86_400_000) return { error: 'bad_time' };
    if (!clipText(b.text, CHAT_LIMITS.maxText) && !b.poll) return { error: 'empty' };
    c.scheduled = c.scheduled || []; if (c.scheduled.filter((x) => x.uid === u.uid).length >= 20) return { error: 'too_many_scheduled' };
    const x = { id: `s${hex(5)}`, uid: u.uid, who: { uid: u.uid, email: emailOf(u), name: nameOf(u), emailVerified: true }, at, b: { text: clipText(b.text, CHAT_LIMITS.maxText), poll: b.poll || undefined, topic: b.topic || undefined, silent: Boolean(b.silent) } };
    c.scheduled.push(x); save(); return scheduledList(u, id);
  }
  function scheduledList(u, id) { const c = gate(u, id); if (!c) return { error: 'not_found' }; return { scheduled: (c.scheduled || []).filter((x) => x.uid === u.uid).sort((a, b2) => a.at - b2.at).map((x) => ({ id: x.id, at: x.at, text: x.b.text, poll: x.b.poll ? x.b.poll.q : null, silent: x.b.silent })) }; }
  function unschedule(u, id, sid) { const c = gate(u, id); if (!c) return { error: 'not_found' }; c.scheduled = (c.scheduled || []).filter((x) => !(x.id === sid && x.uid === u.uid)); save(); return scheduledList(u, id); }
  function runScheduled() {
    for (const c of Object.values(load().channels)) { if (!c.scheduled?.length) continue;
      const due = c.scheduled.filter((x) => x.at <= now()); if (!due.length) continue;
      c.scheduled = c.scheduled.filter((x) => x.at > now());
      for (const x of due) { if (own(c.members, x.uid)) post(x.who, c.id, x.b, { silent: x.b.silent }); }
      save();
    }
  }
  if (env.NODE_ENV !== 'test') { const t2 = setInterval(runScheduled, 15_000); t2.unref?.(); }
  /* ── v361: secret chats (end-to-end). Each device makes its own P-256 key pair; only the public halves come here.
        The two browsers derive the same AES key (ECDH + HKDF) and send ciphertext; this server stores and relays it blind. ── */
  const B64_RE = /^[A-Za-z0-9+/_-]+={0,2}$/;
  const PUB_RE = /^[A-Za-z0-9+/]{86}[A-Za-z0-9+/=]{2}$/;   // a raw P-256 public key: 65 bytes, base64
  function cleanEnc(e, media = false) {
    if (!e || typeof e !== 'object') return null; const iv = String(e.iv || ''); const ct = media ? '' : String(e.ct || '');
    if (!B64_RE.test(iv) || iv.length > 24) return null; if (!media && (!B64_RE.test(ct) || ct.length > 16_000 || ct.length < 8)) return null;
    const out = { iv }; if (!media) out.ct = ct; if (e.v === 2) out.v = 2;   // v2 = bound to chat, sender and kind (associated data)
    if (media) { out.kind = ['image', 'file', 'voice', 'video'].includes(e.kind) ? e.kind : 'file'; if (e.name) { const nm = String(e.name); if (!B64_RE.test(nm) || nm.length > 600) return null; out.name = nm; } if (e.nameIv) { const ni = String(e.nameIv); if (!B64_RE.test(ni) || ni.length > 24) return null; out.nameIv = ni; } }
    return out;
  }
  const validPub = (p2) => { const v = String(p2 || ''); if (!PUB_RE.test(v)) return false; const raw = Buffer.from(v, 'base64'); return raw.length === 65 && raw[0] === 4; };
  function openSecret(u, b = {}) {
    if (!key) return { error: 'no_secret' }; const to = String(b.uid || ''); if (!validPub(b.pub)) return { error: 'bad_key' };
    if (!to || to === u.uid || !/^[A-Za-z0-9_-]{1,128}$/.test(to) || to === '__proto__') return { error: 'bad_request' };
    const d = load(); let peer = null; for (const c of Object.values(d.channels)) if (own(c.members, to)) { peer = c.members[to]; break; }
    const pf = d.profiles && own(d.profiles, to) ? d.profiles[to] : null; if (!peer && pf) peer = { name: pf.name, email: pf.email }; if (!peer) return { error: 'not_found' };
    if (!isOwner(u) && !shareAny(u.uid, to) && !(pf?.dmFrom === 'all' && pf.username)) return { error: 'dm_closed' };
    // v368 security: a block in any one-to-one chat also stops a new secret chat from the blocked person
    if ((d.blocks && own(d.blocks, `${to}|${u.uid}`)) || Object.values(d.channels).some((x) => (x.type === 'dm' || x.type === 'secret') && own(x.members, u.uid) && own(x.members, to) && x.blocked && own(x.blocked, to))) return { error: 'blocked' };
    if (limited(u.uid, 'secret', 10, 3600_000)) return { error: 'rate_limited' };
    const id = `c${hex(6)}`; const c = { id, type: 'secret', name: '', logo: null, createdBy: u.uid, createdAt: now(), rev: 0, messages: [], keys: { [u.uid]: String(b.pub) },
      members: { [u.uid]: { role: 'member', name: nameOf(u), email: emailOf(u), addedAt: now(), addedBy: u.uid, lastRead: 0 }, [to]: { role: 'member', name: clip(peer.name, 40), email: peer.email, addedAt: now(), addedBy: u.uid, lastRead: 0 } } };
    d.channels[id] = c; sys(c, 'secret_start', nameOf(u)); save(); wake(id);
    notify?.(to, { title: nameOf(u), body: langOf(to) === 'ar' ? '🔒 بدّه يبلّش معك محادثة سرية.' : '🔒 wants to start a secret chat.', url: `/#/app/chat?c=${id}`, tag: `chat-${id}` });
    return { channel: card(c, u.uid) };
  }
  function acceptSecret(u, id, b = {}) {
    const c = gate(u, id); if (!c || c.type !== 'secret') return { error: 'not_found' }; if (!validPub(b.pub)) return { error: 'bad_key' };
    if (own(c.keys, u.uid)) return { error: 'already_set' };   // a key is set once: a new device means a new secret chat (no silent key swap)
    c.keys[u.uid] = String(b.pub); sys(c, 'secret_ready', nameOf(u)); bump(c); save(); wake(id); return { channel: card(c, u.uid) };
  }
  /* ── v362: chat folders, sessions (devices), bots ── */
  function folders(u) { return { folders: (load().folders?.[u.uid] || []) }; }
  function setFolders(u, b = {}) {
    const list = Array.isArray(b.folders) ? b.folders.slice(0, 10) : null; if (!list) return { error: 'bad_request' };
    const mine = new Set(Object.values(load().channels).filter((c) => peek(u, c)).map((c) => c.id));
    const clean = list.map((f) => ({ id: /^f[0-9a-z]{4,12}$/.test(String(f?.id)) ? String(f.id) : `f${hex(4)}`, name: clip(f?.name, 30), emoji: /^\p{Extended_Pictographic}[️‍\p{Extended_Pictographic}]{0,6}$/u.test(String(f?.emoji || '')) ? String(f.emoji) : '',
      chats: [...new Set((Array.isArray(f?.chats) ? f.chats : []).map(String))].filter((x) => mine.has(x)).slice(0, 200), unread: Boolean(f?.unread), types: (Array.isArray(f?.types) ? f.types : []).filter((t) => ['group', 'channel', 'dm', 'secret'].includes(t)) })).filter((f) => f.name.length >= 1);
    const d = load(); d.folders = d.folders || {}; d.folders[u.uid] = clean; save(); return folders(u);
  }
  /* devices: each browser reports itself; "sign out" stops the sign-ins of the chosen devices everywhere on the site */
  const sess = (uid, make = false) => { const d = load(); d.sessions = d.sessions || {}; if (!own(d.sessions, uid)) { if (!make) return null; d.sessions[uid] = { devices: {}, revoked: [] }; } return d.sessions[uid]; };
  function seeDevice(u, b = {}) {
    const id = String(b.id || ''); if (!/^d[0-9a-f]{16}$/.test(id)) return { error: 'bad_request' };
    const sx = sess(u.uid, true); const ua = clip(b.ua, 160);
    if (!own(sx.devices, id) && Object.keys(sx.devices).length >= 30) { const old = Object.entries(sx.devices).sort((a, b2) => a[1].at - b2[1].at)[0]; if (old) delete sx.devices[old[0]]; }
    const was = own(sx.devices, id) ? sx.devices[id] : null; sx.devices[id] = { ua, at: now(), first: was?.first || now(), auth: Number(u.authTime) || was?.auth || 0 };
    if (!was || now() - (was.at || 0) > 60_000) save(); return devices(u, id);
  }
  function devices(u, current = '') {
    const sx = sess(u.uid); return { devices: Object.entries(sx?.devices || {}).sort((a, b) => b[1].at - a[1].at).map(([id, v]) => ({ id, ua: v.ua, at: v.at, first: v.first, current: id === current })) };
  }
  function signOutDevices(u, b = {}) {
    const sx = sess(u.uid, true); const cur = String(b.current || ''); const mine = Number(u.authTime) || 0;
    const targets = b.all ? Object.keys(sx.devices).filter((k) => k !== cur) : [String(b.id || '')].filter((k) => own(sx.devices, k) && k !== cur);
    if (!targets.length && !b.all) return { error: 'not_found' };
    for (const k of targets) { const a = sx.devices[k].auth; if (a && a !== mine) sx.revoked.push(a); delete sx.devices[k]; }
    if (b.all) { sx.cutoff = now(); sx.keep = null; revokeAll?.(u.uid); }   // v368: every session, this one too (a stolen copy shares this one's sign-in time); Firebase also stops refreshing them
    sx.revoked = [...new Set(sx.revoked)].slice(-200); save(); return devices(u, cur);
  }
  /** True when this sign-in was ended from another device (checked on every signed-in request of the site). */
  function revoked(uid, authTime) {
    const a = Number(authTime) || 0; if (!a) return false; const sx = sess(uid); if (!sx) return false;
    if (sx.revoked?.includes(a)) return true; return Boolean(sx.cutoff && a * 1000 < sx.cutoff && a !== sx.keep);
  }
  /* bots: made by owners and approved moderators. A bot has a name, a @username ending in "bot", a secret token (only its hash
     is kept), an optional welcome line and /command replies — and an HTTP API (token in the Authorization header) to read
     the messages of the groups it was added to and to post. A bot never sees direct or secret chats. */
  const BOT_RE = /^[a-z][a-z0-9_]{2,28}bot$/;
  const tokHash = (t) => crypto.createHash('sha256').update(String(t)).digest('hex');
  const botUid = (id) => `bot_${id}`;
  function botView(bt, withToken = null) { return { id: bt.id, name: bt.name, username: bt.username, about: bt.about || '', welcome: bt.welcome || '', commands: bt.commands || [], at: bt.at, chats: Object.values(load().channels).filter((c) => own(c.members, botUid(bt.id))).map((c) => ({ id: c.id, name: c.name })), ...(withToken ? { token: withToken } : {}) }; }
  function myBots(u) { return { bots: Object.values(load().bots || {}).filter((bt) => bt.owner === u.uid).map((bt) => botView(bt)), canMake: canCreate(u) }; }
  function makeBot(u, b = {}) {
    if (!canCreate(u)) return { error: 'forbidden' }; const d = load(); d.bots = d.bots || {};
    if (Object.values(d.bots).filter((x) => x.owner === u.uid).length >= 10) return { error: 'too_many_bots' };
    const un = String(b.username || '').trim().replace(/^@/, '').toLowerCase(); if (!BOT_RE.test(un)) return { error: 'bad_bot_username' };
    if (Object.values(d.bots).some((x) => x.username === un) || Object.values(d.profiles || {}).some((p2) => p2.username === un)) return { error: 'username_taken' };
    const name = clip(b.name, 40); if (name.length < 2) return { error: 'bad_name' };
    const id = hex(6); const token = `${id}:${crypto.randomBytes(24).toString('base64url')}`;
    d.bots[id] = { id, owner: u.uid, name, username: un, about: clipText(b.about, 200), tok: tokHash(token), at: now(), welcome: '', commands: [] }; save();
    return { bot: botView(d.bots[id], token) };
  }
  const ownBot = (u, id) => { const d = load(); return d.bots && own(d.bots, String(id)) && (d.bots[id].owner === u.uid || isOwner(u)) ? d.bots[id] : null; };
  function editBot(u, id, b = {}) {
    const bt = ownBot(u, id); if (!bt) return { error: 'not_found' };
    if (b.name != null) { const n = clip(b.name, 40); if (n.length < 2) return { error: 'bad_name' }; bt.name = n; }
    if (b.about != null) bt.about = clipText(b.about, 200);
    if (b.welcome != null) bt.welcome = clipText(b.welcome, 1000);
    if (b.commands != null) bt.commands = (Array.isArray(b.commands) ? b.commands : []).map((x) => ({ cmd: String(x?.cmd || '').trim().replace(/^\//, '').toLowerCase(), reply: clipText(x?.reply, 2000) })).filter((x) => /^[a-z0-9_]{1,32}$/.test(x.cmd) && x.reply).slice(0, 30);
    let token = null; if (b.newToken) { token = `${bt.id}:${crypto.randomBytes(24).toString('base64url')}`; bt.tok = tokHash(token); }
    for (const c of Object.values(load().channels)) if (own(c.members, botUid(bt.id))) c.members[botUid(bt.id)].name = `${bt.name}`;
    save(); return { bot: botView(bt, token) };
  }
  function dropBot(u, id) { const bt = ownBot(u, id); if (!bt) return { error: 'not_found' }; for (const c of Object.values(load().channels)) if (own(c.members, botUid(bt.id))) { delete c.members[botUid(bt.id)]; bump(c); wake(c.id); } delete load().bots[bt.id]; save(); return myBots(u); }
  function addBot(u, id, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; if (!can(c, u, 'members') || isPrivType(c)) return { error: 'forbidden' };
    const un = String(b.username || '').trim().replace(/^@/, '').toLowerCase(); const bt = Object.values(load().bots || {}).find((x) => x.username === un); if (!bt) return { error: 'no_bot' };
    if (own(c.members, botUid(bt.id))) return { error: 'already_member' };
    c.members[botUid(bt.id)] = { role: b.admin && (c.createdBy === u.uid || isOwner(u)) ? 'admin' : 'member', name: bt.name, email: '', addedAt: now(), addedBy: u.uid, lastRead: c.rev || 0, bot: true };
    sys(c, 'added', nameOf(u), bt.name); logAct(c, u, 'add', `@${bt.username}`); save(); wake(id); return members(u, id);
  }
  const isPrivType = (c) => c.type === 'dm' || c.type === 'saved' || c.type === 'secret';
  function botByToken(token) { const t = String(token || ''); const id = t.split(':')[0]; const d = load(); if (!/^[0-9a-f]{12}$/.test(id) || !d.bots || !own(d.bots, id)) return null; const bt = d.bots[id]; return crypto.timingSafeEqual(Buffer.from(bt.tok), Buffer.from(tokHash(t))) ? bt : null; }
  const botUser = (bt) => ({ uid: botUid(bt.id), email: '', name: bt.name, bot: true });
  function botMe(token) { const bt = botByToken(token); if (!bt) return { error: 'unauthorized' }; return { id: bt.id, name: bt.name, username: bt.username, chats: botView(bt).chats }; }
  function botUpdates(token, since = 0) {
    const bt = botByToken(token); if (!bt) return { error: 'unauthorized' }; if (limited(botUid(bt.id), 'botpoll', 30)) return { error: 'rate_limited' };
    const out = []; let next = Number(since) || 0;
    const from = Number(since) || 0;
    for (const c of Object.values(load().channels)) { if (!own(c.members, botUid(bt.id)) || isPrivType(c)) continue; const joined = c.members[botUid(bt.id)].addedAt || 0;
      for (let i = c.messages.length - 1; i >= 0; i--) { const m = c.messages[i]; if (m.at <= from || m.at < joined) break;   // newest first, stop at what the bot has seen or before it joined
        if (!m.deleted && !m.sys && m.uid !== botUid(bt.id)) out.push({ chat: { id: c.id, name: c.name }, message: { id: m.id, from: { id: m.uid, name: m.name }, text: m.text || '', kind: m.kind || (m.file ? 'image' : 'text'), at: m.at, replyTo: m.replyTo?.id || null } }); } }
    out.sort((a, b2) => a.message.at - b2.message.at); const page = out.slice(0, 100); if (page.length) next = page[page.length - 1].message.at;
    return { updates: page, next: next || now() };
  }
  function botSend(token, b = {}) {
    const bt = botByToken(token); if (!bt) return { error: 'unauthorized' }; const c = ch(String(b.chat || '')); if (!c || !own(c.members, botUid(bt.id)) || isPrivType(c)) return { error: 'not_found' };
    if (limited(botUid(bt.id), 'botsend', 30)) return { error: 'rate_limited' };
    const r = post(botUser(bt), c.id, { text: b.text, replyTo: b.replyTo, silent: Boolean(b.silent) }, { bot: true }); return r.error ? r : { message: { id: r.message.id, at: r.message.at } };
  }
  /** Built-in replies: a /command a bot knows, or a welcome when someone joins. Runs on the server, no code needed. */
  function botAuto(c, m) {
    if (isPrivType(c) || m.bot) return;
    const bots = Object.keys(c.members).filter((k) => k.startsWith('bot_')).map((k) => load().bots?.[k.slice(4)]).filter(Boolean); if (!bots.length) return;
    const cmd = /^\/([a-z0-9_]{1,32})(?:@([a-z0-9_]+))?\b/i.exec(m.text || '');
    if (cmd) for (const bt of bots) { if (cmd[2] && cmd[2].toLowerCase() !== bt.username) continue; const hit = (bt.commands || []).find((x) => x.cmd === cmd[1].toLowerCase()); if (hit) { setTimeout(() => { if (ch(c.id)) post(botUser(bt), c.id, { text: hit.reply, replyTo: m.id }, { bot: true }); }, 0); break; } }
  }
  function botWelcome(c, name) { if (isPrivType(c)) return; for (const k of Object.keys(c.members)) if (k.startsWith('bot_')) { const bt = load().bots?.[k.slice(4)]; if (bt?.welcome) setTimeout(() => { if (ch(c.id)) post(botUser(bt), c.id, { text: bt.welcome.replaceAll('{name}', name) }, { bot: true }); }, 0); } }
  /* ── v363: big calls through LiveKit (an SFU), for groups past the 8-person browser mesh. Needs LIVEKIT_URL (wss://…),
        LIVEKIT_API_KEY and LIVEKIT_API_SECRET on the server; tokens are signed here (HS256, 2 hours, one room only). ── */
  const lk = () => { const url = String(env.LIVEKIT_URL || ''); const k = String(env.LIVEKIT_API_KEY || ''); const sec = String(env.LIVEKIT_API_SECRET || '');
    return /^wss:\/\/[^\s"<>]{3,200}$/.test(url) && k && sec.length >= 16 ? { url, key: k, secret: sec, meet: /^https:\/\/[^\s"<>]{3,200}$/.test(String(env.LIVEKIT_MEET_URL || '')) ? String(env.LIVEKIT_MEET_URL) : 'https://meet.livekit.io/custom' } : null; };
  const b64u = (o) => Buffer.from(typeof o === 'string' ? o : JSON.stringify(o)).toString('base64url');
  function lkToken(cfg, { identity, name, room, ttl = 900, publish = true }) {   // v368: 15-minute join window (LiveKit checks it only when joining)
    const t = Math.floor(now() / 1000);
    const body = `${b64u({ alg: 'HS256', typ: 'JWT' })}.${b64u({ iss: cfg.key, sub: identity, name, nbf: t - 10, exp: t + ttl, video: { room, roomJoin: true, canPublish: publish, canSubscribe: true, canPublishData: publish } })}`;
    return `${body}.${crypto.createHmac('sha256', cfg.secret).update(body).digest('base64url')}`;
  }
  const bigOn = () => Boolean(lk());
  function bigCall(u, id, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const cfg = lk(); if (!cfg) return { error: 'big_off' };
    if (c.type === 'saved' || c.type === 'secret') return { error: 'forbidden' };
    const act = String(b.action || 'join');
    if (act !== 'end' && c.type === 'dm' && c.blocked && Object.keys(c.blocked).length) return { error: 'blocked' };   // ending stays possible
    if (c.bigCall && now() - c.bigCall.at > 6 * 3600_000) c.bigCall = null;
    if (act === 'start') {
      if (!isAdmin(c, u) && c.type !== 'dm') return { error: 'forbidden' }; if (limited(u.uid, 'bigstart', 3, 600_000)) return { error: 'rate_limited' };
      if (!c.bigCall) { c.bigCall = { at: now(), by: nameOf(u), room: `gotriva-${id}-${hex(4)}` }; sys(c, 'call_start', nameOf(u)); save(); wake(id);
        for (const uid of Object.keys(c.members)) if (uid !== u.uid && !uid.startsWith('bot_')) notify?.(uid, { title: card(c, uid).name, body: langOf(uid) === 'ar' ? `${nameOf(u)} بلّش مكالمة كبيرة. انضم هلأ.` : `${nameOf(u)} started a big call. Join now.`, url: `/#/app/chat?c=${id}`, tag: `chat-${id}` }); }
    } else if (act === 'end') {
      if (!isAdmin(c, u) && c.type !== 'dm') return { error: 'forbidden' }; if (c.bigCall) { c.bigCall = null; sys(c, 'call_end', nameOf(u)); bump(c); save(); wake(id); } return { ok: true };
    }
    if (!c.bigCall) return { error: 'no_call' };
    const token = lkToken(cfg, { identity: u.uid, name: c.members[u.uid].name || nameOf(u), room: c.bigCall.room, publish: c.type !== 'channel' || isAdmin(c, u) });   // v368: broadcast-channel subscribers listen only
    return { url: `${cfg.meet}?liveKitUrl=${encodeURIComponent(cfg.url)}&token=${encodeURIComponent(token)}`, server: cfg.url, token, room: c.bigCall.room };
  }
  /* ── v364: comments under broadcast-channel posts (like Telegram's discussion), link previews ── */
  function comments(u, id, mid) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const m = findMsg(c, mid); if (!m || m.deleted || c.type !== 'channel') return { error: 'not_found' };
    const l = (c.comments && own(c.comments, mid) ? c.comments[mid] : []);
    return { post: msgView(m, u.uid), comments: l.filter((x) => !x.deleted).map((x) => ({ id: x.id, uid: x.uid, name: x.name, text: x.text, at: x.at, replyTo: x.replyTo || null, mine: x.uid === u.uid, admin: isAdminUid(c, x.uid), av: avVer(x.uid) })), canDelete: can(c, u, 'delete') };
  }
  function addComment(u, id, mid, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const m = findMsg(c, mid); if (!m || m.deleted || c.type !== 'channel') return { error: 'not_found' };
    const mu = c.muted?.[u.uid]; if (own(c.muted, u.uid) && (!mu.until || mu.until > now())) return { error: 'muted' };
    const text = clipText(b.text, 2000); if (!text) return { error: 'empty' };
    if (!isAdmin(c, u)) { if (c.filterLinks && LINK_RE.test(text)) return { error: 'links_off' }; const low = text.toLowerCase(); if ((c.words || []).some((w) => low.includes(w))) return { error: 'blocked_word' }; }
    if (limited(u.uid, 'comment', 15)) return { error: 'rate_limited' };
    c.comments = c.comments || {}; const l = own(c.comments, mid) ? c.comments[mid] : (c.comments[mid] = []); if (l.length >= 500) return { error: 'too_many_comments' };
    const r = b.replyTo ? l.find((x) => x.id === String(b.replyTo) && !x.deleted) : null;
    l.push({ id: `k${hex(6)}`, uid: u.uid, name: c.members[u.uid].name || nameOf(u), text, at: now(), ...(r ? { replyTo: { id: r.id, name: r.name, text: clip(r.text, 100) } } : {}) });
    m.comments = l.filter((x) => !x.deleted).length; m.rev2 = bump(c); save(); wake(id);
    if (r && r.uid !== u.uid && !limited(`${r.uid}:${mid}`, 'cnote', 1, 300_000)) notify?.(r.uid, { title: c.name, body: `${nameOf(u)}: ${clip(text, 90)}`, url: `/#/app/chat?c=${id}`, tag: `chat-${id}` });
    return comments(u, id, mid);
  }
  function delComment(u, id, mid, kid) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; const m = findMsg(c, mid); const l = c.comments?.[mid]; if (!m || !l || !own(c.comments, mid)) return { error: 'not_found' };
    const x = l.find((y) => y.id === kid && !y.deleted); if (!x) return { error: 'not_found' }; if (x.uid !== u.uid && !can(c, u, 'delete')) return { error: 'forbidden' };
    x.deleted = true; x.text = ''; m.comments = l.filter((y) => !y.deleted).length; m.rev2 = bump(c); save(); wake(id); return comments(u, id, mid);
  }
  /* link previews: fetched by the server with strict guards — http(s) only, ports 80/443, every address checked to be public
     (no localhost, private, link-local or metadata ranges — checked at connect time, so DNS tricks don't help), 3 redirects,
     5 s, 300 KB, HTML only; only title / description / site name come back (no images, no scripts). Cached for a day. */
  const previewCache = new Map();
  const privateIp = (ip) => {
    if (net.isIPv4(ip)) { const [a, b2] = ip.split('.').map(Number); return a === 0 || a === 10 || a === 127 || (a === 100 && b2 >= 64 && b2 <= 127) || (a === 169 && b2 === 254) || (a === 172 && b2 >= 16 && b2 <= 31) || (a === 192 && b2 === 168) || (a === 198 && (b2 === 18 || b2 === 19)) || a >= 224; }
    const x = ip.toLowerCase(); if (x.startsWith('::ffff:')) { const r = x.slice(7); if (net.isIPv4(r)) return privateIp(r);
      const h = r.split(':'); if (h.length === 2) { const n = (parseInt(h[0], 16) << 16 >>> 0) + parseInt(h[1], 16); return privateIp([n >>> 24, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.')); } return true; }   // v368: hex-mapped form
    return x.startsWith('::') || x === '::1' || x.startsWith('fc') || x.startsWith('fd') || x.startsWith('fe8') || x.startsWith('fe9') || x.startsWith('fea') || x.startsWith('feb') || /^fe[c-f]/.test(x) || x.startsWith('2002:') || /^2001:0?:/.test(x) || x.startsWith('100::') || x.startsWith('ff') || x.startsWith('64:ff9b');
  };
  const safeLookup = (host, opts, cb) => { const o = typeof opts === 'function' ? {} : opts; const done = typeof opts === 'function' ? opts : cb;
    (env.__testLookup || dns.lookup)(host, { all: true }, (err, list) => { if (err) return done(err); const all = Array.isArray(list) ? list : [{ address: list, family: net.isIPv6(list) ? 6 : 4 }];
      if (!all.length || all.some((x) => privateIp(x.address))) return done(Object.assign(new Error('blocked_address'), { code: 'EBLOCKED' }));
      return o.all ? done(null, all) : done(null, all[0].address, all[0].family); }); };
  const decodeEnt = (t) => String(t).replace(/&(#x?[0-9a-f]+|amp|lt|gt|quot|apos|nbsp);/gi, (m0, e) => { const k = e.toLowerCase(); if (k === 'amp') return '&'; if (k === 'lt') return '<'; if (k === 'gt') return '>'; if (k === 'quot') return '"'; if (k === 'apos') return "'"; if (k === 'nbsp') return ' '; const n = k.startsWith('#x') ? parseInt(k.slice(2), 16) : parseInt(k.slice(1), 10); return Number.isFinite(n) && n > 31 && n < 0x10ffff ? String.fromCodePoint(n) : ''; });
  function fetchPage(url, hops = 0) {
    return new Promise((resolve) => {
      let u2; try { u2 = new URL(url); } catch { return resolve(null); }
      if (!/^https?:$/.test(u2.protocol) || (u2.port && !['80', '443'].includes(u2.port)) || u2.username || u2.password) return resolve(null);
      const host = u2.hostname.replace(/^\[|\]$/g, '');   // v368 security: Node skips lookup() for IP literals, so check them here (also on every redirect hop)
      if (net.isIP(host) && privateIp(host)) return resolve(null);
      const mod = u2.protocol === 'https:' ? https : http;
      const req = mod.request(u2, { method: 'GET', lookup: safeLookup, timeout: 5000, headers: { 'User-Agent': 'GoTrivaLinkPreview/1.0', Accept: 'text/html', 'Accept-Language': 'en,ar;q=0.8' } }, (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && hops < 3) { res.resume(); return resolve(fetchPage(new URL(res.headers.location, u2).href, hops + 1)); }
        if (res.statusCode !== 200 || !/text\/html|application\/xhtml/i.test(String(res.headers['content-type'] || ''))) { res.resume(); return resolve(null); }
        let size = 0; const parts = [];
        res.on('data', (d) => { size += d.length; if (size > 300_000) { req.destroy(); } else parts.push(d); });
        res.on('end', () => resolve({ html: Buffer.concat(parts).toString('utf8'), url: u2.href })); res.on('close', () => resolve(parts.length ? { html: Buffer.concat(parts).toString('utf8'), url: u2.href } : null));
      });
      req.on('timeout', () => req.destroy()); req.on('error', () => resolve(null)); req.end();
    });
  }
  async function preview(u, url) {
    const raw = String(url || '').slice(0, 500); let u2; try { u2 = new URL(raw); } catch { return { error: 'bad_request' }; }
    if (!/^https?:$/.test(u2.protocol)) return { error: 'bad_request' };
    const k = u2.href; const hit = previewCache.get(k); if (hit && now() - hit.at < 86_400_000) return hit.v;
    if (limited(u.uid, 'preview', 30)) return { error: 'rate_limited' };
    const page = await fetchPage(k); let v = { url: k, host: u2.hostname, title: '', description: '', site: '' };
    if (page) { const h = page.html.slice(0, 300_000); const meta = (name) => { const re = new RegExp(`<meta[^>]+(?:property|name)=["']${name}["'][^>]*>`, 'i'); const tag = re.exec(h)?.[0]; return tag ? decodeEnt(/content=["']([^"']*)["']/i.exec(tag)?.[1] || '') : ''; };
      v = { url: k, host: u2.hostname, title: clip(meta('og:title') || meta('twitter:title') || decodeEnt(/<title[^>]*>([^<]{1,300})<\/title>/i.exec(h)?.[1] || ''), 160), description: clip(meta('og:description') || meta('description') || meta('twitter:description'), 300), site: clip(meta('og:site_name'), 60) }; }
    if (previewCache.size > 500) previewCache.delete(previewCache.keys().next().value); previewCache.set(k, { at: now(), v }); return v;
  }
  function pushChannel(c, uid, m) {
    const ar = langOf(uid) === 'ar'; const unread = c.messages.filter((x) => x.seq > (c.members[uid]?.lastRead || 0) && x.uid !== uid && !x.deleted && !x.sys).length;
    const what = m.text ? clip(m.text, 90) : m.poll ? `📊 ${clip(m.poll.q, 80)}` : m.kind === 'video' ? (ar ? 'فيديو' : 'Video') : m.kind === 'voice' ? (ar ? 'رسالة صوتية' : 'Voice message') : m.kind === 'file' ? `📎 ${m.fileName}` : (ar ? 'صورة' : 'Photo');
    if (c.type === 'secret') { notify?.(uid, { title: m.name, body: ar ? '🔒 رسالة سرية جديدة' : '🔒 New secret message', url: `/#/app/chat?c=${c.id}`, tag: `chat-${c.id}` }); return; }
    if (c.type === 'dm') { notify?.(uid, { title: m.name, body: what, url: `/#/app/chat?c=${c.id}`, tag: `chat-${c.id}` }); return; }
    if (m.mentions?.includes(uid)) { notify?.(uid, { title: c.name, body: `${ar ? `${m.name} ذكرك` : `${m.name} mentioned you`}: ${what}`, url: `/#/app/chat?c=${c.id}`, tag: `chat-${c.id}` }); return; }
    const body = unread > 1 ? `${ar ? `${unread} رسائل جديدة` : `${unread} new messages`} · ${m.name}: ${what}` : `${m.name}: ${what}`;
    notify?.(uid, { title: c.name, body, url: `/#/app/chat?c=${c.id}`, tag: `chat-${c.id}` });
  }
  function delMessage(u, id, mid) {
    const c = gate(u, id); if (!c) return { error: 'not_found' };
    const m = c.messages.find((x) => x.id === mid); if (!m || m.sys) return { error: 'not_found' };
    if (m.uid !== u.uid && !can(c, u, 'delete')) return { error: 'forbidden' };
    if (!m.deleted && m.uid !== u.uid) logAct(c, u, 'delete', m.name);
    if (!m.deleted) { m.deleted = true; m.text = ''; dropFile(m.file); dropFile(m.poster); m.file = null; m.poster = null; m.deletedRev = bump(c); m.rev2 = m.deletedRev; if (c.pinned === m.id) c.pinned = null; save(); wake(id); }
    return { ok: true, rev: c.rev };
  }
  function markRead(u, id, seq) {
    const c = gate(u, id); const me = c?.members?.[u.uid]; if (!me) return { error: 'not_found' };
    const s = Math.min(Number(seq) || 0, c.rev); if (s > (me.lastRead || 0)) { me.lastRead = s; save(); wake(id); }   // others see the read ticks
    me.seenAt = now(); return { ok: true };
  }
  function getFile(u, id, fid) {
    const c = gate(u, id); if (!c || !FILE_RE.test(String(fid))) return null; expire(c);
    const owner = c.logo === fid ? null : c.messages.find((m) => (m.file === fid || m.poster === fid) && !m.deleted); if (c.logo !== fid && !owner) return null;
    try { const buf = dec(fs.readFileSync(path.join(fdir, `${fid}.bin`)), `chat:${id}:${fid}`); const nl = buf.indexOf(10); return { type: buf.subarray(0, nl).toString(), data: buf.subarray(nl + 1), name: owner?.kind === 'file' ? owner.fileName : null }; } catch { return null; }
  }

  /* ── calls: an admin starts one, every member may join; WebRTC between browsers (this server only passes the set-up
        messages, kept in memory). Up to 8 people (each browser connects to each other one). ── */
  const calls = new Map();   // channel id → { id, by, byName, startedAt, rev, peers: {uid: {...}}, inbox: {uid: []}, chat: [] }
  const callCard = (id) => { const k = calls.get(id); return k ? { id: k.id, startedAt: k.startedAt, by: k.byName, n: Object.keys(k.peers).length } : null; };
  const callBump = (id, k) => { k.rev++; wake(`call:${id}`); };
  function sweepCall(id) {
    const k = calls.get(id); if (!k) return;
    for (const [uid, p] of Object.entries(k.peers)) if (now() - p.seen > 25_000) { delete k.peers[uid]; delete k.inbox[uid]; k.rev++; }
    if (!Object.keys(k.peers).length && now() - (k.emptySince || (k.emptySince = now())) > 90_000) endCall(id, null);
    else if (Object.keys(k.peers).length) k.emptySince = 0;
  }
  function endCall(id, by) {
    const k = calls.get(id); if (!k) return; calls.delete(id); k.rev++; wake(`call:${id}`);
    const c = ch(id); if (c) { sys(c, 'call_end', by ? nameOf(by) : '', null); save(); wake(id); }
  }
  function callView(id, uid) {
    const k = calls.get(id); if (!k) return { call: null };
    const signals = (k.inbox[uid] || []).splice(0);
    return { call: { id: k.id, by: k.byName, byUid: k.by, startedAt: k.startedAt, rev: k.rev, max: CHAT_LIMITS.callMax,
      peers: Object.entries(k.peers).map(([pid, p]) => ({ uid: pid, name: p.name, mic: p.mic, cam: p.cam, screen: p.screen, joinedAt: p.joinedAt })),
      chat: k.chat.slice(-100), joined: Boolean(k.peers[uid]) }, signals };
  }
  function callGet(u, id) { const c = gate(u, id); if (!c) return { error: 'not_found' }; sweepCall(id); const k = calls.get(id); if (k?.peers[u.uid]) k.peers[u.uid].seen = now(); return callView(id, u.uid); }
  function callAct(u, id, b = {}) {
    const c = gate(u, id); if (!c) return { error: 'not_found' }; sweepCall(id);
    let k = calls.get(id); const act = String(b.action || '');
    if (act === 'start') {
      if (!isAdmin(c, u) && c.type !== 'dm' && c.type !== 'secret') return { error: 'forbidden' }; if (c.type === 'saved') return { error: 'forbidden' }; if (k) return callView(id, u.uid);
      if ((c.type === 'dm' || c.type === 'secret') && c.blocked && Object.keys(c.blocked).length) return { error: 'blocked' };
      if (limited(u.uid, 'callstart', 3, 600_000)) return { error: 'rate_limited' };   // 3 call starts per 10 minutes
      k = { id: `k${hex(5)}`, by: u.uid, byName: nameOf(u), startedAt: now(), rev: 1, peers: {}, inbox: {}, chat: [] }; calls.set(id, k);
      sys(c, 'call_start', nameOf(u)); save(); wake(id);
      const ar = (x) => langOf(x) === 'ar';
      for (const uid of Object.keys(c.members)) if (uid !== u.uid) notify?.(uid, { title: c.name, body: ar(uid) ? `${nameOf(u)} بلّش مكالمة. انضم هلأ.` : `${nameOf(u)} started a call. Join now.`, url: `/#/app/chat?c=${id}&call=1`, tag: `chat-${id}` });
      b.action = 'join';
    }
    if (!k) return { error: 'no_call' };
    if (b.action === 'join') {
      if (!k.peers[u.uid] && Object.keys(k.peers).length >= CHAT_LIMITS.callMax) return { error: 'call_full' };
      k.peers[u.uid] = { name: c.members[u.uid].name || nameOf(u), mic: b.mic !== false, cam: Boolean(b.cam), screen: false, joinedAt: k.peers[u.uid]?.joinedAt || now(), seen: now() };
      k.inbox[u.uid] = k.inbox[u.uid] || []; callBump(id, k); return callView(id, u.uid);
    }
    if (!own(k.peers, u.uid) && act !== 'end') return { error: 'not_in_call' };
    if (act === 'leave') { delete k.peers[u.uid]; delete k.inbox[u.uid]; callBump(id, k); return { ok: true }; }
    if (act === 'end') { if (!isAdmin(c, u) && k.by !== u.uid) return { error: 'forbidden' }; endCall(id, u); return { ok: true }; }
    if (act === 'state') { const p = k.peers[u.uid]; for (const f of ['mic', 'cam', 'screen']) if (typeof b[f] === 'boolean') p[f] = b[f]; p.seen = now(); callBump(id, k); return { ok: true }; }
    if (act === 'signal') {
      const to = String(b.to || ''); if (!own(k.peers, to) || to === u.uid) return { error: 'not_in_call' };
      if (limited(u.uid, 'signal', 240)) return { error: 'rate_limited' };
      const data = b.data; const raw = JSON.stringify(data ?? null); if (raw.length > 24_000 || !data || !['offer', 'answer', 'ice'].includes(data.type)) return { error: 'bad_signal' };
      const box = k.inbox[to] || (k.inbox[to] = []); if (box.length > 100) box.splice(0, 50); box.push({ from: u.uid, data, at: now() });
      k.peers[u.uid].seen = now(); wake(`call:${id}`); return { ok: true };
    }
    if (act === 'say') {
      const text = clipText(b.text, 500); if (!text) return { error: 'empty' }; if (limited(u.uid, 'callmsg', 30)) return { error: 'rate_limited' };
      k.chat.push({ id: `q${hex(4)}`, uid: u.uid, name: k.peers[u.uid].name, text, at: now() }); if (k.chat.length > 300) k.chat.splice(0, 100); callBump(id, k); return { ok: true };
    }
    return { error: 'bad_request' };
  }
  /** Waits until the call changes or a set-up message arrives for this person (up to waitMs). */
  function callWait(u, id, rev, waitMs = 15_000, onCancel = () => {}) {
    return new Promise((resolve) => {
      const k = calls.get(id); if (!k || k.rev > rev || (k.inbox[u.uid] || []).length) return resolve(true);
      let done = false; const key2 = `call:${id}`; const fin = (v) => { if (done) return; done = true; clearTimeout(t); waiters.get(key2)?.delete(fn); resolve(v); };
      const fn = () => fin(true); const t = setTimeout(() => fin(false), waitMs);
      if (!waiters.has(key2)) waiters.set(key2, new Set()); waiters.get(key2).add(fn); onCancel(() => fin(false));
    });
  }

  /* ── approved moderators (site owners only) ── */
  function mods(u) { if (!isOwner(u)) return { error: 'forbidden' }; const d = load();
    return { mods: Object.entries(d.mods).map(([email, m]) => ({ email, at: m.at, channels: Object.values(d.channels).filter((c) => c.members[c.createdBy]?.email === email).length })).sort((a, b) => b.at - a.at),
      channels: Object.values(d.channels).filter((c) => c.type !== 'dm' && c.type !== 'saved' && c.type !== 'secret').map((c) => ({ id: c.id, name: c.name, members: Object.keys(c.members).length, messages: c.messages.length, createdAt: c.createdAt, by: c.members[c.createdBy]?.email || null })) }; }
  function addMod(u, b = {}) { if (!isOwner(u)) return { error: 'forbidden' }; const email = String(b.email || '').trim().toLowerCase(); if (!EMAIL_RE.test(email)) return { error: 'bad_email' };
    load().mods[email] = { at: now(), by: emailOf(u) }; save(); return mods(u); }
  function removeMod(u, email) { if (!isOwner(u)) return { error: 'forbidden' }; const e = String(email || '').toLowerCase(); if (own(load().mods, e)) delete load().mods[e]; save(); return mods(u); }

  function forgetUser(uid, email = '') { const d = load(); let any = false; const em = String(email || '').toLowerCase();
    for (const box of ['folders', 'sessions']) if (d[box] && own(d[box], uid)) { delete d[box][uid]; any = true; }
    if (d.blocks) for (const k of Object.keys(d.blocks)) if (k.split('|').includes(uid)) { delete d.blocks[k]; any = true; }
    for (const bt of Object.values(d.bots || {})) if (bt.owner === uid) { for (const c of Object.values(d.channels)) delete c.members[botUid(bt.id)]; delete d.bots[bt.id]; any = true; }
    if (d.profiles && own(d.profiles, uid)) { if (d.profiles[uid].avatar) dropFile(d.profiles[uid].avatar); delete d.profiles[uid]; any = true; }
    for (const c of Object.values(d.channels)) { if (c.scheduled?.length) c.scheduled = c.scheduled.filter((x) => x.uid !== uid); if (c.requests && own(c.requests, uid)) { delete c.requests[uid]; any = true; } }   // v368: join requests keep the e-mail
    if (Array.isArray(d.reports)) for (const r of d.reports) if (r.byUid === uid || (em && String(r.byEmail || '').toLowerCase() === em)) { r.by = 'deleted user'; r.byEmail = ''; delete r.byUid; any = true; }
    for (const box of ['stories', 'stickers']) if (d[box] && own(d[box], uid)) { for (const x of d[box][uid]) dropFile(x.fid); delete d[box][uid]; any = true; }
    for (const c of Object.values(d.channels)) { if ((c.type === 'dm' || c.type === 'saved' || c.type === 'secret') && own(c.members, uid)) { for (const m of c.messages) { dropFile(m.file); dropFile(m.poster); } delete d.channels[c.id]; any = true; continue; } if (c.banned && own(c.banned, uid)) { delete c.banned[uid]; any = true; } if (c.muted && own(c.muted, uid)) { delete c.muted[uid]; any = true; } if (!own(c.members, uid)) continue; any = true; if (c.createdBy === uid) { dropFile(c.logo); for (const m of c.messages) { dropFile(m.file); dropFile(m.poster); } delete d.channels[c.id]; continue; }
      delete c.members[uid]; for (const m of c.messages) if (m.reactions) for (const k of Object.keys(m.reactions)) { m.reactions[k] = m.reactions[k].filter((x) => x !== uid); if (!m.reactions[k].length) delete m.reactions[k]; }
      for (const m of c.messages) if (m.poll) { for (const o of m.poll.options) o.v = o.v.filter((x) => x !== uid); if (m.poll.names) delete m.poll.names[uid]; }
      for (const m of c.messages) if (m.uid === uid && !m.deleted) { m.deleted = true; m.text = ''; dropFile(m.file); dropFile(m.poster); m.file = null; m.poster = null; m.deletedRev = bump(c); } }
    if (any) save(); }

  return { lowDisk: () => lowDisk(), comments, addComment, delComment, preview, privateIp, bigCall, lkToken, folders, setFolders, seeDevice, devices, signOutDevices, revoked, myBots, makeBot, editBot, dropBot, addBot, botMe, botUpdates, botSend, openSecret, acceptSecret, myProfile, setProfile, setAvatar, avatarFile, profile, people, setPrefs, searchAll, sharedMedia, hideForMe, readers, schedule, scheduledList, unschedule, runScheduled, setTtl, topicAdd, topicDel, myStickers, stickerAdd, stickerFromMsg, stickerFile, stickerDel, storyAdd, stories, storyGet, storyDel, translateMsg, vote, openDm, openSaved, block, report, reports, clearReport, forward, makeInvite, dropInvite, invitePeek, joinInvite, answerRequest, activity, setTyping, editMessage, react, pin, search, moderate, setNotify, isMember, sweepFiles, upload, callGet, callAct, callWait, list, create, update, remove, members, addMember, setRole, removeMember, read, post, delMessage, markRead, getFile, waitFor, mods, addMod, removeMod, forgetUser, canSave: () => Boolean(key), flush: () => writer.flush() };
}
