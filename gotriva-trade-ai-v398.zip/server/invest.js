// v347 Investment section (server side): real prices, daily / hourly candles, company news and reported fundamentals for a
// watch-list of the world's biggest companies, plus the AI news-sentiment reading and the documented "ready trade".
// Providers (keys stay on the server, never in the page):
//   • Twelve Data (TWELVEDATA_API_KEY — already used by the site): quotes, candles, company press releases, and /statistics
//     when the plan allows it (Pro).
//   • Finnhub (FINNHUB_API_KEY, optional): faster quotes (15 s), company news from the press and basic financials on its
//     free tier (personal use; a commercial site needs Finnhub's paid plan).
// Every answer is cached and only fetched when someone has the page open, so a basic data plan is never exhausted.
// AI sentiment: the site's own AI (the owner's key) reads the latest headlines; it is cached per set of headlines.
import { WATCH, isWatched, readyTrade, stripHtml } from '../src/services/investEngine.js';

const r2 = (v) => (Number.isFinite(v) ? Math.round(v * 100) / 100 : null);
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : null; };

export function createInvest({ tdKey = () => '', tdBase = 'https://api.twelvedata.com', env = process.env, fetchImpl = globalThis.fetch, now = Date.now, ai = null, aiReady = () => Boolean(ai), log = console } = {}) {
  const fh = () => String(env.FINNHUB_API_KEY || '').trim();
  const cache = new Map(); const inflight = new Map(); let lastErr = null;   // v371: why the last price request failed (shown on the page)
  /** One cached value per key; concurrent callers share the same request; an error keeps the last good copy. */
  async function cached(key, ttl, fn) {
    const c = cache.get(key); const t = now();
    if (c && t - c.at < ttl) return c.v;
    if (inflight.has(key)) return inflight.get(key);
    const p = (async () => {
      try { const v = await fn(); if (v != null) cache.set(key, { at: now(), v }); return v ?? c?.v ?? null; }
      catch (e) { log.warn?.('[invest]', key, e?.message || e); if (key.startsWith('q:')) lastErr = { code: e?.code || 'error', at: now() }; return c?.v ?? null; }
      finally { inflight.delete(key); }
    })();
    inflight.set(key, p); return p;
  }
  async function td(path, params) {
    const key = tdKey(); if (!key) throw Object.assign(new Error('no_key'), { code: 'no_key' });
    const u = new URL(`${tdBase.replace(/\/$/, '')}/${path}`); u.search = new URLSearchParams({ ...params, apikey: key });
    const r = await fetchImpl(u, { signal: AbortSignal.timeout(12_000) }); const j = await r.json().catch(() => ({}));
    if (!r.ok || j.status === 'error') { const e = new Error(`td ${path} ${j.code || r.status}`); e.code = Number(j.code || r.status) === 403 ? 'no_permission' : Number(j.code || r.status) === 429 ? 'rate_limit' : 'error'; throw e; }
    return j;
  }
  async function fhGet(path, params) {
    const u = new URL(`https://finnhub.io/api/v1/${path}`); u.search = new URLSearchParams({ ...params, token: fh() });
    const r = await fetchImpl(u, { signal: AbortSignal.timeout(10_000) }); if (!r.ok) throw new Error(`fh ${path} ${r.status}`);
    return r.json();
  }
  // US regular session (09:30–16:00 New York, Mon–Fri) — only to choose how often prices are refreshed.
  function usOpen(t = now()) {
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', weekday: 'short', hour: 'numeric', minute: 'numeric', hour12: false }).formatToParts(new Date(t)).map((x) => [x.type, x.value]));
    if (['Sat', 'Sun'].includes(p.weekday)) return false;
    const m = (Number(p.hour) % 24) * 60 + Number(p.minute); return m >= 570 && m < 960;
  }

  /** Watch-list quotes → { items: [{ symbol, price, change, changePct, high, low, prevClose, at }], source, at, delayedNote } */
  async function quotes() {
    const open = usOpen();
    if (fh()) {
      return cached('q:fh', 15_000, async () => {
        const items = [];
        for (const w of WATCH) {
          try { const q = await fhGet('quote', { symbol: w.s }); if (num(q.c) > 0) items.push({ symbol: w.s, price: q.c, change: r2(q.d), changePct: r2(q.dp), high: q.h, low: q.l, open: q.o, prevClose: q.pc, at: q.t ? q.t * 1000 : now() }); } catch { /* one symbol failing never empties the list */ }
        }
        if (!items.length) throw Object.assign(new Error('finnhub returned no prices'), { code: 'no_data' });
        lastErr = null; return { items, source: 'finnhub', at: now(), marketOpen: open };
      }).then((v) => v || tdQuotes(open));   // v371: Finnhub down → Twelve Data
    }
    return tdQuotes(open);
  }
  async function tdQuotes(open) {
    const ttl = (Number(env.INVEST_QUOTE_TTL_MIN) || (open ? 5 : 60)) * 60_000;
    return cached('q:td', ttl, async () => {
      const j = await td('quote', { symbol: WATCH.map((w) => w.s).join(',') });
      const items = WATCH.map((w) => { const q = j[w.s] || (j.symbol === w.s ? j : null); if (!q || q.status === 'error' || !(num(q.close) > 0)) return null;
        return { symbol: w.s, price: num(q.close), change: r2(num(q.change)), changePct: r2(num(q.percent_change)), high: num(q.high), low: num(q.low), open: num(q.open), prevClose: num(q.previous_close), volume: num(q.volume), hi52: num(q.fifty_two_week?.high), lo52: num(q.fifty_two_week?.low), at: num(q.timestamp) ? num(q.timestamp) * 1000 : now(), marketOpen: Boolean(q.is_market_open) }; }).filter(Boolean);
      // v371: Twelve Data answers 200 with an error per symbol when the plan's per-minute credits are used up (the rest of the
      // site uses the same key), so an empty list is an error with its reason, logged, and the last good prices stay.
      if (!items.length) { const codes = WATCH.map((w) => Number(j[w.s]?.code || j.code)).filter(Boolean); throw Object.assign(new Error(`twelvedata returned no prices (${codes.join(',') || 'empty'})`), { code: codes.includes(429) ? 'rate_limit' : codes.includes(403) ? 'no_permission' : 'no_data' }); }
      lastErr = null; return { items, source: 'twelvedata', at: now(), marketOpen: open };
    });
  }

  /** Candles (oldest → newest) for the chart and the analysis. tf: '1day' | '1h' */
  async function candles(symbol, tf = '1day') {
    if (!isWatched(symbol)) return null;
    const ttl = tf === '1h' ? 20 * 60_000 : 6 * 3600_000;
    return cached(`c:${symbol}:${tf}`, ttl, async () => {
      const j = await td('time_series', { symbol, interval: tf === '1h' ? '1h' : '1day', outputsize: tf === '1h' ? '300' : '320', order: 'ASC' });
      const list = (j.values || []).map((v) => ({ time: Math.floor(Date.parse(String(v.datetime).length <= 10 ? `${v.datetime}T00:00:00Z` : `${String(v.datetime).replace(' ', 'T')}Z`) / 1000), open: num(v.open), high: num(v.high), low: num(v.low), close: num(v.close), volume: num(v.volume) }))
        .filter((c) => Number.isFinite(c.time) && c.close > 0);
      list.sort((a, b) => a.time - b.time);
      return list.length ? list : null;
    });
  }

  /** Latest company news → [{ title, summary, at, source, url }] (newest first). */
  async function news(symbol) {
    if (!isWatched(symbol)) return [];
    if (fh()) {
      return (await cached(`n:fh:${symbol}`, 15 * 60_000, async () => {
        const to = new Date(now()); const from = new Date(now() - 7 * 86400_000); const d = (x) => x.toISOString().slice(0, 10);
        const l = await fhGet('company-news', { symbol, from: d(from), to: d(to) });
        return (Array.isArray(l) ? l : []).slice(0, 12).map((x) => ({ title: stripHtml(x.headline, 200), summary: stripHtml(x.summary, 300), at: num(x.datetime) ? x.datetime * 1000 : null, source: stripHtml(x.source, 40), url: /^https:\/\//.test(x.url || '') ? x.url : null })).filter((x) => x.title);
      })) || [];
    }
    return (await cached(`n:td:${symbol}`, 30 * 60_000, async () => {
      const j = await td('press_releases', { symbol, outputsize: '8' });
      return (j.press_releases || []).map((x) => ({ title: stripHtml(x.title, 200), summary: stripHtml(x.body, 300), at: Date.parse(x.datetime) || null, source: 'Press release', url: null })).filter((x) => x.title);
    })) || [];
  }

  /** Reported fundamentals, normalised (fractions) → { pe, forwardPe, epsGrowth, revenueGrowth, netMargin, debtToEquity, marketCap, beta, source } | { unavailable } */
  async function fundamentalsOf(symbol) {
    if (!isWatched(symbol)) return null;
    if (fh()) {
      return cached(`f:fh:${symbol}`, 24 * 3600_000, async () => {
        const j = await fhGet('stock/metric', { symbol, metric: 'all' }); const m = j?.metric || {};
        const pct = (v) => (Number.isFinite(Number(v)) ? Number(v) / 100 : null);
        return { pe: num(m.peTTM ?? m.peBasicExclExtraTTM), forwardPe: null, epsGrowth: pct(m.epsGrowthTTMYoy), revenueGrowth: pct(m.revenueGrowthTTMYoy), netMargin: pct(m.netProfitMarginTTM), debtToEquity: num(m['totalDebt/totalEquityQuarterly']), marketCap: num(m.marketCapitalization) ? m.marketCapitalization * 1e6 : null, beta: num(m.beta), source: 'finnhub' };
      });
    }
    const v = await cached(`f:td:${symbol}`, 24 * 3600_000, async () => {
      try {
        const j = await td('statistics', { symbol }); const s = j.statistics || {}; const f = s.financials || {}; const inc = f.income_statement || {};
        return { pe: num(s.valuations_metrics?.trailing_pe), forwardPe: num(s.valuations_metrics?.forward_pe), epsGrowth: num(inc.quarterly_earnings_growth_yoy), revenueGrowth: num(inc.quarterly_revenue_growth), netMargin: num(f.profit_margin), debtToEquity: num(f.balance_sheet?.total_debt_to_equity_mrq) != null ? f.balance_sheet.total_debt_to_equity_mrq / 100 : null, marketCap: num(s.valuations_metrics?.market_capitalization), beta: num(s.stock_price_summary?.beta), source: 'twelvedata' };
      } catch (e) { if (e.code === 'no_permission') return { unavailable: 'plan' }; throw e; }
    });
    return v;
  }

  /** AI sentiment of the headlines → { score -1..1, label, n, items: [{ i, s, why }], summary, model } | null (no AI / no news). */
  async function sentiment(symbol, list, lang = 'ar') {
    if (!ai || !list?.length) return null;
    const heads = list.slice(0, 10);
    const key = `s:${symbol}:${lang}:${heads.map((h) => h.title).join('|').slice(0, 600)}`;
    return cached(key, 30 * 60_000, async () => {
      const system = 'You are a careful equity news analyst. Rate how each headline affects the stock in the coming weeks, from -1 (clearly negative) to 1 (clearly positive); 0 when neutral, promotional or unrelated. Do not invent facts. Answer with JSON only.';
      const prompt = `Company: ${symbol}\nHeadlines (newest first):\n${heads.map((h, i) => `${i + 1}. [${h.at ? new Date(h.at).toISOString().slice(0, 10) : '?'}] ${h.title}${h.summary ? ` — ${h.summary.slice(0, 200)}` : ''}`).join('\n')}\n\nReturn: {"items":[{"i":1,"s":0.4,"why":"<= 12 words in ${lang === 'ar' ? 'Arabic' : 'English'}"}],"summary":"<= 35 words in ${lang === 'ar' ? 'Levantine Arabic' : 'English'}"}`;
      const text = await ai({ system, prompt });
      if (!text) return null;
      let j; try { j = JSON.parse(String(text).replace(/^[^{]*/, '').replace(/[^}]*$/, '')); } catch { return null; }
      const items = (Array.isArray(j.items) ? j.items : []).map((x) => ({ i: Math.round(num(x.i)) - 1, s: Math.max(-1, Math.min(1, num(x.s) ?? 0)), why: String(x.why || '').slice(0, 140) })).filter((x) => x.i >= 0 && x.i < heads.length);
      if (!items.length) return null;
      // newer headlines weigh more
      let sw = 0; let st = 0; for (const x of items) { const w = 1 / (1 + x.i * 0.25); sw += w; st += x.s * w; }
      const score = r2(st / sw);
      return { score, label: score > 0.2 ? 'positive' : score < -0.2 ? 'negative' : 'neutral', n: items.length, items, summary: String(j.summary || '').slice(0, 400) };
    });
  }

  /** Everything for one company → analysis + the documented ready trade. */
  async function analysis(symbol, { lang = 'ar' } = {}) {
    if (!isWatched(symbol)) return { error: 'unknown_symbol' };
    const [q, day, nw, fd] = await Promise.all([quotes().catch(() => null), candles(symbol, '1day').catch(() => null), news(symbol).catch(() => []), fundamentalsOf(symbol).catch(() => null)]);
    const quote = q?.items?.find((x) => x.symbol === symbol) || null;
    const closed = (day || []).slice(0, usOpen() ? -1 : undefined);   // today's bar is still forming during the session
    const senti = await sentiment(symbol, nw, lang).catch(() => null);
    const fundOk = fd && !fd.unavailable ? fd : null;
    const trade = readyTrade({ price: quote?.price ?? closed.at(-1)?.close, candles: closed, fund: fundOk, sentiment: senti });
    return {
      symbol, quote, trade, news: nw.slice(0, 10), sentiment: senti, fundamentals: fd,
      sources: { prices: q?.source || null, candles: day ? 'twelvedata' : null, news: fh() ? 'finnhub' : 'twelvedata', fundamentals: fd?.source || null, ai: aiReady() },
      at: now(),
    };
  }
  const status = () => ({ twelvedata: Boolean(tdKey()), finnhub: Boolean(fh()), ai: aiReady(), marketOpen: usOpen(), lastError: lastErr?.code || null });
  return { quotes, candles, news, fundamentals: fundamentalsOf, sentiment, analysis, status, usOpen };
}
