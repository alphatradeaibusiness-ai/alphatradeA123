// Swing Pulse Pro (v346) — the website side of the independent swing channel.
//   • reads the worker's swing-signals.json (WORKER_DATA_DIR) — never another channel's file
//   • /api/swing/feed: signed-in members WITH ACCESS get the recommendations; each person's lot size and amount at risk are
//     computed HERE from their own linked MetaTrader 5 account (equity / balance + the broker's contract data) or from the
//     balance they entered (labelled as such) — one member's account is never visible to another
//   • plan rules: any paid platform plan (not channel-only, not free) when plans are enforced; the plan's existing monthly
//     recommendation allowance (TIERS[plan].signalsPerMonth) is counted for THIS channel on its own; owners are never limited.
//     Above the allowance the levels are withheld by the server, so a direct API call cannot bypass it.
//   • announcements: each new recommendation and each status change is delivered ONCE per member (bell + push + Telegram)
import fs from 'node:fs';
import path from 'node:path';
import { TIERS } from '../src/config/entitlements.js';
import { findInstrument } from '../src/config/instruments.js';
import { swingSummary, LIVE_STATUSES, SWING_BRAND, RISK_POLICY, MIN_CONFIDENCE } from '../src/services/swingEngine.js';
import { lotFor, brokerMatch } from '../src/services/swingLot.js';
import { SWING_MARKETS } from '../src/services/swingScanner.js';

const STATUS_AR = { new: 'توصية جديدة', active: 'تفعّلت', tp1: 'الهدف 1 ✅', tp2: 'الهدف 2 ✅', tp3: 'الهدف 3 ✅', sl: 'ضرب الوقف ❌', closed: 'تسكّرت', cancelled: 'انلغت' };
const STATUS_EN = { new: 'New recommendation', active: 'Activated', tp1: 'TP1 hit ✅', tp2: 'TP2 hit ✅', tp3: 'TP3 hit ✅', sl: 'Stop loss hit ❌', closed: 'Closed', cancelled: 'Cancelled' };
const monthStart = (ms) => { const d = new Date(ms); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1); };

export function alertText(s, ev, lang = 'ar', lot = null) {
  const ar = lang === 'ar'; const dir = s.direction === 'buy' ? (ar ? 'شراء' : 'BUY') : (ar ? 'بيع' : 'SELL');
  const type = s.entryType === 'limit' ? 'LIMIT' : 'MARKET';
  const head = `${(ar ? STATUS_AR : STATUS_EN)[ev] || ev} · ${s.name} ${dir} ${type} · ${s.tf === '1D' ? 'D1' : s.tf.toUpperCase()}`;
  const lines = [head, `${ar ? 'دخول' : 'Entry'} ${s.entry} · SL ${s.stop} · TP ${s.targets.join(' / ')}`, `${ar ? 'ثقة AI' : 'AI confidence'} ${s.confidence}% · ${ar ? 'مخاطرة AI' : 'AI risk'} ${s.riskPct}%${lot?.ok ? ` · ${lot.lots} lot` : ''}`];
  if (ev !== 'new' && s.realizedPips != null) lines.push(`${ar ? 'محقّق' : 'Realized'} ${s.realizedPips > 0 ? '+' : ''}${s.realizedPips} ${s.unit}`);
  lines.push(ar ? 'تحليل مش نصيحة مالية · متابعة توصية، مش تنفيذ مؤكّد' : 'Analysis, not financial advice · tracked recommendation, not a confirmed execution');
  return lines.join('\n');
}

export function createSwingService({ dataDir, workerDir, growth, ent, mt5, isOwnerEmail, channelAccess, now = Date.now, log = console }) {
  const file = () => path.join(workerDir(), 'swing-signals.json');
  const own = path.join(dataDir, 'swing.json');
  let cache = { key: '', data: null };
  let st = (() => { try { const j = JSON.parse(fs.readFileSync(own, 'utf8')); return { sent: j.sent || {}, prefs: j.prefs || {}, since: j.since || now() }; } catch { return { sent: {}, prefs: {}, since: now() }; } })();
  const save = () => { try { fs.mkdirSync(dataDir, { recursive: true }); const tmp = `${own}.tmp`; fs.writeFileSync(tmp, JSON.stringify(st), { mode: 0o600 }); fs.renameSync(tmp, own); } catch (e) { log.error?.('[swing] save failed:', e?.message); } };

  function read() {
    const f = file(); let stat; try { stat = fs.statSync(f); } catch { return null; }
    const key = `${stat.mtimeMs}|${stat.size}`;
    if (cache.key !== key) { try { const j = JSON.parse(fs.readFileSync(f, 'utf8')); cache = { key, data: j && Array.isArray(j.signals) ? j : { signals: [] } }; } catch { return cache.data; } }
    return cache.data;
  }

  /** Who may open the channel → { ok, owner, plan, quota } or { ok: false, code }. */
  function access(user) {
    const owner = Boolean(isOwnerEmail(user));
    if (owner) return { ok: true, owner, plan: 'owner', quota: Infinity };
    if (channelAccess?.channelOnly?.(user.uid)) return { ok: false, code: 'platform_plan_required' };
    if (!ent.enforce) return { ok: true, owner, plan: ent.planOf(user.uid) || null, quota: Infinity };
    const plan = ent.planOf(user.uid);
    if (plan === 'trial') return { ok: true, owner, plan, quota: TIERS.trial.signalsPerMonth };   // v391 the 7-day agents trial
    if (!plan || !(TIERS[plan]?.rank >= 1)) return { ok: false, code: 'plan_upgrade_required' };
    return { ok: true, owner, plan, quota: TIERS[plan].signalsPerMonth || 0 };
  }

  /** The member's account for sizing: a connected MT5 terminal first (verified by the terminal), else the balance they entered. */
  function accountOf(uid) {
    const links = mt5?.list?.(uid)?.links || [];
    const L = links.find((l) => l.connected && l.terminal && (l.terminal.equity > 0 || l.terminal.balance > 0));
    const p = st.prefs[uid] || {};
    const basis = p.basis === 'balance' ? 'balance' : 'equity';
    if (L) {
      const t = L.terminal; const amount = basis === 'balance' ? t.balance : (t.equity || t.balance);
      return { account: { amount, currency: t.currency || null, basis, source: 'mt5', at: t.at }, specs: t.specs || [], positions: t.positions || [] };
    }
    if (p.manual > 0 && p.currency) return { account: { amount: p.manual, currency: p.currency, basis: 'balance', source: 'manual' }, specs: [], positions: [] };
    return { account: null, specs: [], positions: [] };
  }

  /** The feed for one member. */
  function feed(user) {
    const a = access(user); if (!a.ok) return { status: 403, body: { code: a.code } };
    const d = read();
    if (!d) return { status: 200, body: { configured: false, at: now(), signals: [], markets: SWING_MARKETS.map((m) => ({ id: m.id, name: m.name, state: 'pending' })), summary: swingSummary([]), policy: policy(), access: { plan: a.plan, quota: a.quota === Infinity ? null : a.quota, used: 0 } } };
    const sigs = [...d.signals].sort((x, y) => y.createdAt - x.createdAt);
    // Monthly allowance: the first N recommendations created this month (oldest first) are open to this member.
    const m0 = monthStart(now());
    const thisMonth = sigs.filter((s) => s.createdAt >= m0).sort((x, y) => x.createdAt - y.createdAt);
    const allowed = new Set(a.quota === Infinity ? sigs.map((s) => s.id) : thisMonth.slice(0, a.quota).map((s) => s.id));
    if (a.quota !== Infinity) for (const s of sigs) if (s.createdAt < m0) allowed.add(s.id);   // last months' archive stays readable
    const { account, specs } = accountOf(user.uid);
    const rates = d.rates || {};
    const out = sigs.map((s) => {
      if (!allowed.has(s.id)) return { id: s.id, locked: true, symbol: s.symbol, name: s.name, tf: s.tf, direction: s.direction, status: s.status, createdAt: s.createdAt };
      const spec = specs.find((x) => brokerMatch(x.name, s.symbol)) || null;
      const lot = LIVE_STATUSES.includes(s.status) ? lotFor(s, account, spec, findInstrument(s.symbol), rates) : null;
      return { ...s, lot, brokerSymbol: spec?.name || null };
    });
    const markets = SWING_MARKETS.map((m) => { const ms = d.markets?.[m.id] || {}; return { id: m.id, name: m.name, symbol: m.symbol, cat: m.cat, state: ms.state || 'pending', reason: ms.reason || null, at: ms.at || null, price: ms.price ?? null, last: ms.last || {} }; });
    return { status: 200, body: {
      configured: true, at: now(), lastScan: d.lastScan || null, lastTrack: d.lastTrack || null, ratesAt: d.ratesAt || null,
      signals: out, markets, summary: swingSummary(d.signals), policy: policy(),
      account: account ? { amount: account.amount, currency: account.currency, basis: account.basis, source: account.source } : null,
      access: { plan: a.plan, quota: a.quota === Infinity ? null : a.quota, used: Math.min(thisMonth.length, a.quota === Infinity ? thisMonth.length : a.quota) },
      errors: (d.errors || []).length,
    } };
  }
  const policy = () => ({ minConfidence: MIN_CONFIDENCE, tiers: RISK_POLICY.tiers, safeMax: RISK_POLICY.SAFE_MAX, hardMax: RISK_POLICY.HARD_MAX, absLimit: RISK_POLICY.ABS_LIMIT });

  /** Member settings: balance basis, or a balance typed in by hand (used only without a connected MT5 account). */
  function setPrefs(uid, b = {}) {
    const p = (st.prefs[uid] ||= {});
    if (b.basis === 'equity' || b.basis === 'balance') p.basis = b.basis;
    if (b.manual === null || b.manual === 0) { delete p.manual; delete p.currency; }
    else if (b.manual != null) {
      const v = Number(b.manual); const c = String(b.currency || '').toUpperCase();
      if (!(v > 0 && v <= 1e9) || !/^[A-Z]{3,4}$/.test(c)) return { error: 'bad_input' };
      p.manual = Math.round(v * 100) / 100; p.currency = c;
    }
    save(); return { ok: true, prefs: { basis: p.basis || 'equity', manual: p.manual ?? null, currency: p.currency ?? null } };
  }
  const prefs = (uid) => { const p = st.prefs[uid] || {}; return { basis: p.basis || 'equity', manual: p.manual ?? null, currency: p.currency ?? null }; };
  const forget = (uid) => { if (st.prefs[uid]) { delete st.prefs[uid]; save(); } };

  /** Announce new recommendations and status changes once (called every few seconds). Returns the number of events. */
  let queue = Promise.resolve();
  function tick() {
    const d = read(); if (!d) return 0;
    const fresh = [];
    for (const s of d.signals) {
      if (s.createdAt < st.since - 60_000) { st.sent[s.id] ||= s.status; continue; }   // older than this server's first start: never re-announced
      const prev = st.sent[s.id];
      if (prev === s.status) continue;
      fresh.push({ s, ev: prev ? s.status : 'new' });
      if (!prev && s.status !== 'pending' && s.status !== 'active') fresh.push({ s, ev: s.status });
      st.sent[s.id] = s.status;
    }
    const ids = new Set(d.signals.map((s) => s.id)); for (const id of Object.keys(st.sent)) if (!ids.has(id)) delete st.sent[id];
    if (!fresh.length) return 0;
    save();
    queue = queue.then(async () => {
      const members = (growth.members?.() || []);
      for (const { s, ev } of fresh.slice(0, 20)) {
        for (let i = 0; i < members.length; i += 20) {
          await Promise.all(members.slice(i, i + 20).map(async (m) => {
            try {
              const a = access({ uid: m.uid, email: m.email }); if (!a.ok) return;
              if (a.quota !== Infinity) {   // above this member's monthly allowance: no alert (the card stays locked too)
                const m0 = monthStart(s.createdAt); const rank = d.signals.filter((x) => x.createdAt >= m0 && x.createdAt <= s.createdAt).length;
                if (rank > a.quota) return;
              }
              const lang = m.lang === 'en' ? 'en' : 'ar';
              const { account, specs } = accountOf(m.uid);
              const lot = ev === 'new' ? lotFor(s, account, specs.find((x) => brokerMatch(x.name, s.symbol)) || null, findInstrument(s.symbol), d.rates || {}) : null;
              await growth.deliver?.(m.uid, { kind: 'swing', symbol: s.symbol, tag: `${s.id}:${ev}`, title: SWING_BRAND, body: alertText(s, ev, lang, lot), url: '/#/app/swing', push: true, tg: true });
            } catch { /* one member never blocks the rest */ }
          }));
        }
      }
    }).catch((e) => log.error?.('[swing] announce:', String(e?.message || e).slice(0, 80)));
    return fresh.length;
  }
  return { feed, prefs, setPrefs, forget, tick, access, read };
}
