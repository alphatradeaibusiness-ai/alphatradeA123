// v393 One e-mail per money / security event, each with its own wording (Arabic first, then English). Used for every bank
// notification (deposits, withdrawals, transfers, cards, gifts, pots, requests, renewals, security…) and for payments of plans,
// channel add-ons and challenges (by card through Stripe, or from the bank balance). KYC e-mails live in mail.js.
// Only to a proven address (the sender checks). Amounts come from the ledger; nothing here is estimated.
import { CURRENCIES, fromMinor } from './bank/money.js';

const B = '/#/app/bank';
/** kind → [subject ar, body ar, subject en, body en, link] */
export const TEMPLATES = {
  // money in / out
  deposit_confirmed: ['وصل إيداعك', 'انضاف {amt} على محفظتك بالبنك الرقمي.', 'Your deposit arrived', '{amt} was added to your bank wallet.', B],
  deposit_rejected: ['ما انقبل طلب الإيداع', 'طلب الإيداع ما انقبل وما انخصم منك إشي. إذا عندك سؤال احكي معنا من «الدعم».', 'Deposit not accepted', 'Your deposit request was not accepted and nothing was charged. Contact support if you have questions.', B],
  withdrawal_requested: ['استلمنا طلب السحب', 'استلمنا طلب سحب {amt}. المبلغ محجوز من رصيدك لحد ما ينراجع وينبعت، وبيوصلك إيميل بكل خطوة.', 'Withdrawal request received', 'We received your {amt} withdrawal request. The amount is held from your balance until it is reviewed and sent; you will get an e-mail at each step.', B],
  withdrawal_approved: ['انوافق على السحب', 'انوافق على سحب {amt}، وبيوصلك إيميل لما ينبعت.', 'Withdrawal approved', 'Your {amt} withdrawal was approved. You will get another e-mail when it is sent.', B],
  withdrawal_rejected: ['انرفض طلب السحب ورجع المبلغ', 'طلب سحب {amt} انرفض، والمبلغ رجع لمحفظتك كامل.', 'Withdrawal rejected, money returned', 'Your {amt} withdrawal was rejected and the full amount is back in your wallet.', B],
  withdrawal_completed: ['انبعت السحب', 'انبعت {amt} للوجهة اللي اخترتها. حسب البنك أو الطريقة، ممكن ياخد وقت لحد ما يبيّن عندك.', 'Withdrawal sent', '{amt} was sent to your chosen destination. Depending on the bank or method it may take some time to show.', B],
  partner_commission: ['وصلتك عمولة شريك', 'انضافت عمولة {amt} من نادي شركاء GOTRIVA على محفظتك.', 'Partner commission received', 'A {amt} commission from the GOTRIVA Partner Club was added to your wallet.', B],
  transfer_sent: ['حوّلت مصاري', 'حوّلت {amt} لـ {name}. الإيصال بـ «الفواتير والإيصالات». إذا مش إنت، جمّد حسابك فورًا من «الأمان».', 'Money sent', 'You sent {amt} to {name}. The receipt is under «Invoices & receipts». If this was not you, freeze your account now from «Security».', B],
  transfer_received: ['وصلتك مصاري', 'وصلك {amt} من {name} على محفظتك.', 'Money received', 'You received {amt} from {name} in your wallet.', B],
  money_request: ['في حدا طالب منك مصاري', '{name} طالب منك {amt}. ادفع أو ارفض من «حوّل لعضو ← طلبات المصاري». الطلب بينتهي بعد 7 أيام.', 'Someone requested money', '{name} requested {amt} from you. Pay or decline under «Send to a member → Requests». It ends after 7 days.', B],
  request_paid: ['انْدفع طلبك', '{name} دفعلك {amt}.', 'Your request was paid', '{name} paid you {amt}.', B],
  pot_invite: ['انضفت على صندوق مشترك', '{name} ضافك على صندوق «{merchant}». حصتك {amt}.', 'You were added to a shared pot', '{name} added you to the pot «{merchant}». Your share is {amt}.', B],
  pot_reminder: ['تذكير بحصتك بالصندوق', 'حصتك {amt} بصندوق «{merchant}» لسا ما انْدفعت.', 'Reminder: your pot share', 'Your {amt} share in «{merchant}» is still unpaid.', B],
  pot_paid: ['دفعت حصتك بالصندوق', 'دفعت {amt} بصندوق «{merchant}». المبلغ محجوز لحد ما الكل يدفع.', 'Your pot share is paid', 'You paid {amt} into «{merchant}». It stays held until everyone has paid.', B],
  pot_done: ['كمل الصندوق', 'كمل صندوق «{merchant}» ونزل {amt} على محفظتك.', 'The pot is complete', 'The pot «{merchant}» is complete and {amt} is in your wallet.', B],
  pot_cancelled: ['انلغى الصندوق', 'انلغى صندوق «{merchant}»، وإذا كنت دافع حصتك رجعتلك كاملة.', 'The pot was cancelled', 'The pot «{merchant}» was cancelled; if you had paid, your share is back.', B],
  gift_bought: ['اشتريت بطاقة هدية', 'اشتريت بطاقة هدية بقيمة {amt}. الكود بـ «حوّل لعضو ← هدية». المبلغ محجوز لحد ما ينستعمل أو تلغيه.', 'You bought a gift card', 'You bought a {amt} gift card. The code is under «Send to a member → Gift». The money is held until used or cancelled.', B],
  gift_received: ['وصلتك هدية', 'استعملت بطاقة هدية من {name}، وانضاف {amt} على محفظتك.', 'You received a gift', 'You redeemed a gift card from {name}; {amt} was added to your wallet.', B],
  gift_redeemed: ['انستعملت بطاقة الهدية تبعتك', '{name} استعمل بطاقة الهدية ({amt}) اللي بعتها.', 'Your gift card was used', '{name} redeemed the {amt} gift card you sent.', B],
  renew_done: ['تجدد اشتراكك من رصيدك', 'تجدد اشتراكك وانخصم {amt} من رصيدك بالبنك. الفاتورة بـ «الفواتير والإيصالات».', 'Plan renewed from your balance', 'Your plan was renewed and {amt} was taken from your bank balance. The invoice is under «Invoices & receipts».', B],
  renew_failed: ['ما قدرنا نجدد اشتراكك', 'رصيدك ما كفّى لتجديد الاشتراك ({amt}). أودع أو ادفع بالبطاقة قبل ما يخلص.', 'We could not renew your plan', 'Your balance was short of the renewal ({amt}). Add money or pay by card before it ends.', '/#/app/pricing'],
  renew_reminder: ['اشتراكك بيتجدد بعد 3 أيام', 'اشتراكك بيتجدد من رصيدك بعد 3 أيام ({amt}) ورصيدك هلّق ما بيكفي. أودع قبل الموعد.', 'Your plan renews in 3 days', 'Your plan renews from your balance in 3 days ({amt}) and your balance is short right now. Add money before then.', B],
  vault_release_started: ['بلّش فتح الخزنة', 'بلّش فتح {amt} من الخزنة. إذا مش إنت، الغيه من البنك فورًا.', 'Vault release started', 'A {amt} vault release started. If this was not you, cancel it in the bank now.', B],
  vault_released: ['انفتح من الخزنة', 'انفتح {amt} من الخزنة ورجع لمحفظتك.', 'Released from the vault', '{amt} was released from the vault to your wallet.', B],
  converted: ['تحويل عملة', 'تم تحويل العملة ووصلك {amt}.', 'Currency converted', 'Your currency conversion is done: {amt} received.', B],
  intl_quoted: ['عرض تحويل دولي', 'جهّزنالك عرض سعر لتحويل دولي. صالح لوقت قصير.', 'International transfer quote', 'Your international transfer quote is ready. It is valid for a short time.', B],
  // cards
  card_purchase: ['شراء بالبطاقة', 'انخصم {amt} من بطاقتك عند {merchant}. إذا مش إنت، جمّد البطاقة فورًا.', 'Card purchase', '{amt} was charged on your card at {merchant}. If this was not you, freeze the card now.', B],
  card_declined: ['انرفضت عملية بالبطاقة', 'انرفضت عملية عند {merchant}. ما انخصم منك إشي.', 'Card payment declined', 'A payment at {merchant} was declined. Nothing was charged.', B],
  card_refund: ['استرجاع على البطاقة', 'رجعلك {amt} من {merchant}.', 'Card refund', '{amt} was refunded from {merchant}.', B],
  card_status: ['تحديث على بطاقتك', 'صار تغيير على حالة بطاقتك. شوفها بالبنك.', 'Card update', 'Your card status changed. Check it in the bank.', B],
  // planning & rewards
  budget_80: ['صرفت 80% من الميزانية', 'وصلت 80% من ميزانية {category} هالشهر.', 'Budget at 80%', 'You reached 80% of your {category} budget this month.', B],
  budget_100: ['خلصت الميزانية', 'خلصت ميزانية {category} هالشهر.', 'Budget used up', 'Your {category} budget for this month is used up.', B],
  subscription_due: ['اشتراك بيتجدد قريب', 'اشتراك {merchant} بيتجدد قريب ({amt}).', 'A subscription renews soon', 'Your {merchant} subscription renews soon ({amt}).', B],
  plan_skipped: ['خطة الاستثمار انتخطت', 'خطة الاستثمار التلقائي ما اشتغلت هالمرة (غالبًا الرصيد ما كفّى).', 'Investment plan skipped', 'Your automatic investment did not run this time (usually not enough balance).', B],
  save_skipped: ['قاعدة الادخار انتخطت', 'قاعدة ادخار ما اشتغلت هالمرة (سقف يومي أو رصيد أقل من الحد).', 'Saving rule skipped', 'A saving rule did not run this time (daily cap or balance floor).', B],
  points_expiring: ['نقاطك بتنتهي قريب', '{pts} نقطة بتنتهي قريب. استعملها قبل ما تروح.', 'Points expiring soon', '{pts} points expire soon. Use them before they go.', B],
  points_redeemed: ['استعملت نقاط', 'استعملت {pts} نقطة.', 'Points redeemed', 'You redeemed {pts} points.', B],
  ticket_reply: ['في رد على تذكرة الدعم', 'فريق الدعم رد على تذكرتك. افتح «الدعم» بالبنك.', 'Support replied', 'Support replied to your ticket. Open «Support» in the bank.', B],
  // security (always sent)
  passkey_added: ['انضاف مفتاح دخول (بصمة)', 'انضاف مفتاح دخول جديد لحسابك بالبنك. إذا مش إنت، احكي معنا فورًا.', 'Passkey added', 'A new passkey was added to your bank account. If this was not you, contact us now.', B],
  passkey_removed: ['انشال مفتاح دخول', 'انشال مفتاح دخول من حسابك بالبنك.', 'Passkey removed', 'A passkey was removed from your bank account.', B],
  beneficiary_added: ['انضافت وجهة سحب جديدة', 'انضافت وجهة سحب جديدة لحسابك. إذا مش إنت، جمّد الحساب فورًا.', 'New withdrawal destination', 'A new withdrawal destination was added. If this was not you, freeze the account now.', B],
  frozen: ['انجمّد حسابك بالبنك', 'انجمّد حسابك: ما في سحب ولا تحويل لحد ما تفكّه.', 'Bank account frozen', 'Your account is frozen: no withdrawals or transfers until you unfreeze it.', B],
  unfrozen: ['انفكّ تجميد حسابك', 'انفكّ تجميد حسابك بالبنك ورجع شغّال.', 'Bank account unfrozen', 'Your bank account is active again.', B],
  approval_needed: ['في طلب بحاجة موافقتك', 'في عملية بتستنى موافقتك كموقّع مشارك.', 'Your approval is needed', 'An action is waiting for your approval as a co-signer.', B],
  approval_result: ['نتيجة طلب الموافقة', 'نتيجة طلب الموافقة: {result}.', 'Approval result', 'Approval result: {result}.', B],
  policy_changed: ['تغيّرت سياسة الموافقات', 'تغيّرت إعدادات الموافقات على حسابك.', 'Approval policy changed', 'The approval settings on your account changed.', B],
  approver_added: ['انضاف موقّع مشارك', 'انضاف موقّع مشارك جديد لحسابك.', 'Co-signer added', 'A new co-signer was added to your account.', B],
  ob_linked: ['انربط حساب بنك خارجي', 'انربط حساب بنك خارجي بحسابك.', 'External bank linked', 'An external bank account was linked to yours.', B],
  security_changed: ['تغيير بإعدادات الأمان', 'صار تغيير بإعدادات الأمان. إذا مش إنت، احكي معنا فورًا.', 'Security settings changed', 'Your security settings changed. If this was not you, contact us now.', B],
  fraud_alert: ['تنبيه أمان', 'وقّفنا عملية مشبوهة على حسابك. افتح البنك وراجعها.', 'Security alert', 'We stopped a suspicious action on your account. Open the bank and review it.', B],
  // payments of GOTRIVA products
  paid_card: ['وصلنا دفعك، شكرًا', 'وصلنا دفع {amt} مقابل {merchant} بالبطاقة، وتفعّل على حسابك.', 'Payment received, thank you', 'We received your {amt} card payment for {merchant}; it is active on your account.', '/#/app/billing'],
  paid_wallet: ['دفعت من رصيدك', 'انخصم {amt} من رصيدك بالبنك مقابل {merchant}، وتفعّل على حسابك. الفاتورة بـ «الفواتير والإيصالات».', 'Paid from your balance', '{amt} was taken from your bank balance for {merchant}; it is active on your account. The invoice is under «Invoices & receipts».', '/#/app/billing'],
};

const money = (p) => { if (p.amount == null || !CURRENCIES[p.currency]) return ''; try { return `${fromMinor(Number(p.amount), p.currency)} ${p.currency}`; } catch { return ''; } };
/** Names and pot titles come from members: links and addresses are cut out so nobody can use our e-mails to phish. */
const clean = (v, n) => String(v ?? '—').replace(/(https?:\/\/|www\.)\S*/gi, '').replace(/\b[\w.-]+\.(com|net|org|io|co|me|ly|app|xyz|info|ru|cn)\b\S*/gi, '').replace(/[<>]/g, '').trim().slice(0, n) || '—';
const fill = (s, p) => s.replace(/\{amt\}/g, money(p) || '—').replace(/\{name\}/g, clean(p.name, 30)).replace(/\{merchant\}/g, clean(p.merchant, 60))
  .replace(/\{category\}/g, String(p.category || '—')).replace(/\{pts\}/g, String(p.pts ?? '')).replace(/\{result\}/g, String(p.result || '—')).replace(/\.\./g, '.');   // «Rami H.» at the end of a sentence

/** → { subject, text } or null when there is no template for this kind. */
export function renderEvent(kind, params = {}, { url = '' } = {}) {
  const t = TEMPLATES[kind]; if (!t) return null;
  const link = url ? `${url.replace(/\/$/, '')}${t[4] || ''}` : '';
  const subject = `${fill(t[0], params)} · ${fill(t[2], params)} · GOTRIVA`;
  const text = `${fill(t[1], params)}\n\n${fill(t[3], params)}${link ? `\n\n${link}` : ''}`;
  return { subject, text };
}
