// v374 market headlines from public RSS feeds (Forex Factory's news page blocks servers with HTTP 403).
// Several sources are read on the SERVER, merged, de-duplicated and cached, so every visitor costs at most one request per
// source every few minutes. A source that fails backs off; the last good list is kept (and written to disk) so a short outage
// or a restart never empties the page. Headlines only: title, link, source and time, exactly as the publisher gave them.
import fs from 'node:fs';
import path from 'node:path';

export const NEWS_SOURCES = [
  { id: 'investinglive', name: 'investingLive (ForexLive)', url: 'https://investinglive.com/feed/news' },
  { id: 'investinglive-cb', name: 'investingLive · Central banks', url: 'https://investinglive.com/feed/centralbank' },
  { id: 'fxstreet', name: 'FXStreet', url: 'https://www.fxstreet.com/rss/news' },
  { id: 'investing', name: 'Investing.com', url: 'https://www.investing.com/rss/news_1.rss' },
  { id: 'fxstreet-ar', name: 'FXStreet عربي', url: 'https://ar.fxstreet.com/rss/news' },
  { id: 'forexlive', name: 'ForexLive', url: 'https://www.forexlive.com/feed/news' },
];

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
const decode = (s) => String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
  .replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => (e[0] === '#' ? String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : Number(e.slice(1))) : ENT[e.toLowerCase()] ?? m));
const strip = (s) => decode(s).replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
const tag = (block, name) => { const m = block.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'i')); return m ? m[1] : ''; };
const safeUrl = (u) => { try { const x = new URL(decode(u).trim()); return x.protocol === 'https:' || x.protocol === 'http:' ? x.href : null; } catch { return null; } };

/** RSS 2.0 or Atom → [{ id, title, url, source, time }]. Tolerant: an item without a title or a valid link is skipped. */
export function parseFeed(xml, source = '') {
  const out = []; const text = String(xml || '');
  const blocks = text.match(/<item[\s>][\s\S]*?<\/item>/gi) || text.match(/<entry[\s>][\s\S]*?<\/entry>/gi) || [];
  for (const b of blocks) {
    const title = strip(tag(b, 'title')).slice(0, 300);
    let url = safeUrl(strip(tag(b, 'link')));
    if (!url) { const m = b.match(/<link[^>]*href=["']([^"']+)["']/i); url = m ? safeUrl(m[1]) : null; }
    if (!title || title.length < 8 || !url) continue;
    const when = strip(tag(b, 'pubDate') || tag(b, 'published') || tag(b, 'updated') || tag(b, 'dc:date'));
    const time = Date.parse(when);
    out.push({ id: `${source}:${url}`, title, url, source, time: Number.isFinite(time) ? time : null });
  }
  return out;
}

/** Merge lists: newest first, one copy of a story that several sources carry (same link or same normalised title). */
export function mergeNews(lists, max = 80) {
  const seen = new Set(); const all = lists.flat().filter(Boolean).sort((a, b) => (b.time || 0) - (a.time || 0)); const out = [];
  for (const x of all) { const k1 = x.url.replace(/[?#].*$/, ''); const k2 = x.title.toLowerCase().replace(/[^a-z0-9؀-ۿ]+/g, ' ').trim(); if (seen.has(k1) || seen.has(k2)) continue; seen.add(k1); seen.add(k2); out.push(x); if (out.length >= max) break; }
  return out;
}

export function createNewsFeed({ dataDir = '', sources = NEWS_SOURCES, fetchFn = globalThis.fetch, ttlMs = 3 * 60_000, now = Date.now, log = console } = {}) {
  const file = dataDir ? path.join(dataDir, 'news-cache.json') : '';
  let last = (() => { try { const j = JSON.parse(fs.readFileSync(file, 'utf8')); return Array.isArray(j.items) ? j : null; } catch { return null; } })();
  const state = new Map();   // id → { items, at, failUntil, fails, error }
  let busy = null;
  async function readOne(s) {
    const st = state.get(s.id) || { items: [], at: 0, fails: 0, failUntil: 0 }; state.set(s.id, st);
    if (now() < st.failUntil) return st.items;
    try {
      const r = await fetchFn(s.url, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; GotrivaTradeAI/1.0; +news)', Accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9, */*;q=0.5' }, signal: AbortSignal.timeout(10_000) });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const items = parseFeed(await r.text(), s.name);
      if (!items.length) throw new Error('no items');
      Object.assign(st, { items, at: now(), fails: 0, failUntil: 0, error: null });
    } catch (e) {
      st.fails += 1; st.failUntil = now() + Math.min(30 * 60_000, 60_000 * 2 ** (st.fails - 1)); st.error = String(e?.message || e).slice(0, 60);
      if (st.fails === 1 || st.fails % 10 === 0) log.warn?.(`[news] ${s.id} failed: ${st.error}`);
    }
    return st.items;
  }
  /** → { items, at, sources: [{ id, name, ok, n, error }] }. Refreshes at most every ttlMs; a failing refresh keeps the last list. */
  async function headlines({ force = false } = {}) {
    if (!force && last && now() - last.at < ttlMs) return { ...last, sources: report() };
    if (!busy) busy = (async () => {
      const lists = await Promise.all(sources.map(readOne));
      const items = mergeNews(lists);
      if (items.length) { last = { items, at: now() }; if (file) { try { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(`${file}.tmp`, JSON.stringify(last)); fs.renameSync(`${file}.tmp`, file); } catch { /* memory only */ } } }
    })().finally(() => { busy = null; });
    await busy;
    return { items: last?.items || [], at: last?.at || null, stale: Boolean(last && now() - last.at >= ttlMs), sources: report() };
  }
  const report = () => sources.map((s) => { const st = state.get(s.id); return { id: s.id, name: s.name, ok: Boolean(st && st.items.length && !st.error), n: st?.items.length || 0, error: st?.error || null }; });
  return { headlines, report };
}
