// Daily rotating backups of everything the server keeps: the bank database (consistent snapshot with VACUUM INTO),
// the encrypted config files and the encrypted per-user trade files. Files stay encrypted exactly as they are on disk.
//   BACKUP_DIR        where backups go (default SERVER_DATA_DIR/backups). Best on a separate disk / mounted bucket.
//   BACKUP_KEEP_DAYS  how many daily backups to keep (default 14, 1–90)
//   BACKUP_DISABLED=1 turn it off
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const DAY = 86_400_000;
const stamp = (ms) => new Date(ms).toISOString().slice(0, 10);

export function createBackups({ dataDir, env = process.env, snapshotBank = null, now = Date.now, log = console }) {
  const dir = path.resolve(env.BACKUP_DIR || path.join(dataDir, 'backups'));
  const keep = Math.max(1, Math.min(90, Number(env.BACKUP_KEEP_DAYS) || 14));
  const disabled = env.BACKUP_DISABLED === '1';
  let last = null; let lastError = null;

  const list = () => { try { return fs.readdirSync(dir).filter((n) => /^\d{4}-\d{2}-\d{2}$/.test(n)).sort(); } catch { return []; } };
  function copyTree(from, to) {
    if (!fs.existsSync(from)) return 0;
    let n = 0;
    for (const e of fs.readdirSync(from, { withFileTypes: true })) {
      const a = path.join(from, e.name);
      if (path.resolve(a) === dir || e.name === 'backups' || e.name === 'bank') continue;   // never back up the backups; bank.db goes via VACUUM
      if (e.isDirectory()) { n += copyTree(a, path.join(to, e.name)); continue; }
      if (!e.isFile() || !/\.(json|jsonl)$/.test(e.name)) continue;
      fs.mkdirSync(to, { recursive: true, mode: 0o700 }); fs.copyFileSync(a, path.join(to, e.name)); n++;
    }
    return n;
  }
  function prune() {
    const all = list(); const drop = all.slice(0, Math.max(0, all.length - keep));
    for (const d of drop) fs.rmSync(path.join(dir, d), { recursive: true, force: true });
    return drop.length;
  }
  /** Make today's backup if it does not exist yet (or always with force). */
  function run({ force = false } = {}) {
    if (disabled) return { skipped: 'disabled' };
    const day = stamp(now()); const out = path.join(dir, day);
    if (!force && fs.existsSync(path.join(out, 'DONE'))) return { skipped: 'exists', day };
    const tmp = `${out}.partial`;
    try {
      fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true, mode: 0o700 });
      let bank = false;
      if (snapshotBank) { snapshotBank(path.join(tmp, 'bank.db')); bank = true; }
      const files = copyTree(dataDir, path.join(tmp, 'data'));
      const info = { at: now(), bank, files };
      fs.writeFileSync(path.join(tmp, 'DONE'), JSON.stringify(info));
      fs.rmSync(out, { recursive: true, force: true }); fs.renameSync(tmp, out);
      const pruned = prune(); last = info.at; lastError = null;
      return { ok: true, day, ...info, pruned };
    } catch (e) {
      fs.rmSync(tmp, { recursive: true, force: true }); lastError = String(e?.message || e).slice(0, 120);
      log.error?.('[backup] failed:', lastError); return { ok: false, error: lastError };
    }
  }
  function start() {
    if (disabled) return () => {};
    const first = setTimeout(() => run(), 60_000); first.unref?.();
    const timer = setInterval(() => run(), DAY / 24); timer.unref?.();   // hourly check; makes at most one per day
    return () => { clearTimeout(first); clearInterval(timer); };
  }
  const status = () => {
    const all = list();
    if (!last && all.length) { try { last = JSON.parse(fs.readFileSync(path.join(dir, all.at(-1), 'DONE'), 'utf8')).at; } catch { /* */ } }
    return { enabled: !disabled, count: all.length, keep, last, error: lastError, stale: !disabled && (!last || now() - last > 2 * DAY) };
  };
  /** v367: the newest finished backup as a .tar.gz Buffer (for the owner to keep a copy off the server). Null if none. */
  function latestArchive({ maxBytes = 200 * 1024 * 1024 } = {}) {
    const day = list().at(-1); if (!day) return null; const root = path.join(dir, day);
    if (!fs.existsSync(path.join(root, 'DONE'))) return null;
    const parts = []; let size = 0;
    const walk = (abs, rel) => {
      for (const e of fs.readdirSync(abs, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
        const a = path.join(abs, e.name); const r = rel ? `${rel}/${e.name}` : e.name;
        if (e.isDirectory()) { walk(a, r); continue; }
        if (!e.isFile()) continue;
        const body = fs.readFileSync(a); size += body.length; if (size > maxBytes) throw new Error('backup_too_big');
        parts.push(tarHeader(`gotriva-backup-${day}/${r}`, body.length), body, Buffer.alloc((512 - (body.length % 512)) % 512));
      }
    };
    walk(root, '');
    parts.push(Buffer.alloc(1024));
    return { day, gz: zlib.gzipSync(Buffer.concat(parts), { level: 6 }) };
  }
  return { run, start, status, dir, latestArchive };
}

/** One ustar header block (names up to 100 bytes, or split into prefix/name up to 255). */
export function tarHeader(name, size, mtime = Math.floor(Date.now() / 1000)) {
  const h = Buffer.alloc(512); let n = Buffer.from(name); let pre = Buffer.alloc(0);
  if (n.length > 100) { const i = name.lastIndexOf('/', name.length - 2); pre = Buffer.from(name.slice(0, i)); n = Buffer.from(name.slice(i + 1)); if (n.length > 100 || pre.length > 155) throw new Error('name_too_long'); }
  n.copy(h, 0); h.write('0000600\0', 100); h.write('0000000\0', 108); h.write('0000000\0', 116);
  h.write(`${size.toString(8).padStart(11, '0')}\0`, 124); h.write(`${mtime.toString(8).padStart(11, '0')}\0`, 136);
  h.write('        ', 148); h.write('0', 156); h.write('ustar\0', 257); h.write('00', 263); pre.copy(h, 345);
  let sum = 0; for (const b of h) sum += b; h.write(`${sum.toString(8).padStart(6, '0')}\0 `, 148);
  return h;
}
