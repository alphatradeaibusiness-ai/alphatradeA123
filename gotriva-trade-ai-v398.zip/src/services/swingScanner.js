// Swing Pulse Pro (v346) — the market scanner. Runs ONLY on the 24/7 server worker (server/worker.js → swing-signals.json, read by
// /api/swing/feed). Own state file, own markets, own timers: nothing here reads or writes another channel.
//
// Every market × H1 / H4 / Daily is evaluated once per newly CLOSED candle with swingEngine.evaluateSwing. Open recommendations
// are followed every 15 s on real 1-minute candles + the live quote. Each market and each frame fails on its own (logged, the
// scan goes on). Nothing is published from demo, stale, closed-market or missing data, and the real state of every market is kept
// for the page ("live", "market closed", "no real data"…).
import { findInstrument } from '../config/instruments.js';
import { evaluateSwing, trackSwing, SWING_TFS, TF_SEC, LIVE_STATUSES, FINAL_STATUSES } from './swingEngine.js';

export const SWING_MARKETS = [
  { id: 'XAUUSD', name: 'XAUUSD', symbol: 'XAUUSD', cat: 'metal' }, { id: 'XAGUSD', name: 'XAGUSD', symbol: 'XAGUSD', cat: 'metal' },
  { id: 'EURUSD', name: 'EURUSD', symbol: 'EURUSD', cat: 'forex' }, { id: 'GBPUSD', name: 'GBPUSD', symbol: 'GBPUSD', cat: 'forex' },
  { id: 'USDJPY', name: 'USDJPY', symbol: 'USDJPY', cat: 'forex' }, { id: 'AUDUSD', name: 'AUDUSD', symbol: 'AUDUSD', cat: 'forex' },
  { id: 'USDCAD', name: 'USDCAD', symbol: 'USDCAD', cat: 'forex' }, { id: 'USDCHF', name: 'USDCHF', symbol: 'USDCHF', cat: 'forex' },
  { id: 'GBPJPY', name: 'GBPJPY', symbol: 'GBPJPY', cat: 'forex' }, { id: 'EURJPY', name: 'EURJPY', symbol: 'EURJPY', cat: 'forex' },
  { id: 'US100', name: 'NAS100', symbol: 'US100', cat: 'index' }, { id: 'US30', name: 'US30', symbol: 'US30', cat: 'index' },
  { id: 'SPX500', name: 'US500', symbol: 'SPX500', cat: 'index' }, { id: 'GER40', name: 'GER40', symbol: 'GER40', cat: 'index' },
  { id: 'BTCUSDT', name: 'BTCUSD', symbol: 'BTCUSDT', cat: 'crypto' }, { id: 'ETHUSDT', name: 'ETHUSD', symbol: 'ETHUSDT', cat: 'crypto' },
];
// Live prices kept for converting a quote currency to the account currency in the lot calculation (never invented).
export const RATE_SYMBOLS = ['EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'USDCAD', 'USDCHF', 'NZDUSD'];
export const KEEP_DAYS = 120;
export const MAX_SIGNALS = 600;
const SCAN_EVERY_MS = 60_000;
export const TRACK_EVERY_MS = 15_000;
const RETRY_MS = 5 * 60_000;

export async function defaultDeps() {
  const [mk, htf, news] = await Promise.all([import('./market/index.js'), import('./htfData.js'), import('./news.js')]);
  return {
    getHistory: mk.getHistory,
    quotes: async (syms) => { const t = await mk.getTickers(syms); const out = {}; for (const s of syms) { const q = t?.[s]; if (q && q.mode === 'live' && Number.isFinite(q.price)) out[s] = { price: q.price, at: Number.isFinite(q.at) ? q.at : Date.now() }; } return out; },
    prefetchHtf: htf.prefetchHtf, htfCandles: htf.htfCandles,
    calendar: async () => { try { const c = await news.getCalendar(); return Array.isArray(c?.events) ? { events: c.events, at: c.at ?? Date.now() } : null; } catch { return null; } },
  };
}

/** store: { load(), save(state) } · onEvents([{ signal, status }]) for new signals and status changes. */
export function createSwingScanner({ deps, store, onEvents = () => {}, log = console, markets = SWING_MARKETS, tfs = SWING_TFS, now = Date.now, maxRiskPct = 2 } = {}) {
  let st = (() => { const s = store?.load?.(); return s && Array.isArray(s.signals) ? { signals: s.signals, markets: s.markets || {}, rates: s.rates || {}, lastScan: s.lastScan || 0, lastTrack: s.lastTrack || 0, errors: s.errors || [] } : { signals: [], markets: {}, rates: {}, lastScan: 0, lastTrack: 0, errors: [] }; })();
  let D = deps || null; let timer = 0; let running = false; let busy = false; const candleAt = new Map();
  const save = () => { try { store?.save?.(st); } catch (e) { log.warn?.('[swing] save', e?.message); } };
  const err = (where, e) => { const m = String(e?.message || e).slice(0, 120); st.errors.unshift({ at: now(), where, msg: m }); st.errors = st.errors.slice(0, 30); log.warn?.(`[swing] ${where}: ${m}`); };
  const prune = () => {
    const keep = now() - KEEP_DAYS * 86_400_000;
    st.signals = st.signals.filter((s) => LIVE_STATUSES.includes(s.status) || (s.closedAt || s.createdAt) >= keep).sort((a, b) => b.createdAt - a.createdAt).slice(0, MAX_SIGNALS);
  };

  async function scanOnce() {
    D ||= await defaultDeps();
    const events = []; const t0 = now();
    let quotes = {}; try { quotes = await D.quotes([...new Set([...markets.map((m) => m.symbol), ...RATE_SYMBOLS])]); } catch (e) { err('quotes', e); }
    for (const [k, q] of Object.entries(quotes)) if (RATE_SYMBOLS.includes(k)) st.rates[k] = q.price;
    st.ratesAt = t0;
    let calendar = null; try { calendar = await D.calendar(); } catch { calendar = null; }
    for (const m of markets) {
      const inst = findInstrument(m.symbol);
      const ms = (st.markets[m.id] ||= { id: m.id, name: m.name, symbol: m.symbol, cat: m.cat, bars: {}, retry: {}, last: {} });
      if (!inst) { Object.assign(ms, { state: 'unavailable', reason: 'no_instrument', at: t0 }); continue; }
      for (const tf of tfs) {
        const sec = TF_SEC[tf]; const t = now();
        const lastClosed = Math.floor(t / 1000 / sec) * sec - sec;
        if (ms.bars[tf] === lastClosed && !(ms.retry[tf] && t >= ms.retry[tf])) continue;   // already evaluated on this candle
        try {
          const ds = await D.getHistory(m.symbol, tf, 400);
          if (tf !== '1D') { try { await D.prefetchHtf(m.symbol, sec); } catch { /* the engine then uses the chart's own structure */ } }
          const r = evaluateSwing({ market: m, inst, tf, ds, htf: D.htfCandles?.(m.symbol) || null, quote: quotes[m.symbol] || null, calendar, nowMs: now(), signals: st.signals, maxRiskPct });
          ms.bars[tf] = r.barTime ?? lastClosed;
          ms.retry[tf] = ['stale', 'closed', 'unavailable', 'insufficient'].includes(r.state) ? now() + RETRY_MS : 0;
          ms.last[tf] = { state: r.state, reason: r.reason, at: now(), confidence: r.analysis?.confidence?.score ?? null };
          const ok = r.state === 'ok' || r.state === 'no_trade';
          Object.assign(ms, { state: ok ? 'live' : r.state, reason: ok ? null : r.reason, at: now(), source: ds?.source || null, price: quotes[m.symbol]?.price ?? ms.price ?? null });
          if (r.signal) { st.signals.unshift(r.signal); events.push({ signal: r.signal, status: 'new' }); }
        } catch (e) { err(`${m.id} ${tf}`, e); ms.retry[tf] = now() + 60_000; }
        await new Promise((res) => setTimeout(res, 5));
      }
    }
    prune(); st.lastScan = now(); save();
    if (events.length) { try { onEvents(events); } catch (e) { err('onEvents', e); } }
    return events;
  }

  async function trackOnce() {
    D ||= await defaultDeps();
    const live = st.signals.filter((s) => LIVE_STATUSES.includes(s.status));
    const events = [];
    if (live.length) {
      let quotes = {}; try { quotes = await D.quotes([...new Set(live.map((s) => s.symbol))]); } catch (e) { err('track quotes', e); }
      const bySym = new Map(); for (const s of live) { if (!bySym.has(s.symbol)) bySym.set(s.symbol, []); bySym.get(s.symbol).push(s); }
      for (const [sym, list] of bySym) {
        try {
          const q = quotes[sym] || null;
          // Real 1-minute candles once a minute per market (they catch a wick between two checks); in between, the live quote is the
          // newest price — so the provider is never called more often than its limits allow.
          let candles = null;
          if (now() - (candleAt.get(sym) || 0) >= 60_000) {
            const ds = await D.getHistory(sym, '1m', 300);
            candleAt.set(sym, now());
            if (ds && ds.mode === 'live' && ds.candles?.length) candles = ds.candles;
          }
          if (!candles && q) { const t = Math.floor(q.at / 1000); candles = [{ time: t - (t % 60), open: q.price, high: q.price, low: q.price, close: q.price }]; }
          if (!candles) continue;   // never follow a recommendation on generated prices
          for (const s of list) for (const ev of trackSwing(s, candles, { nowMs: now(), price: q?.price ?? null, priceAt: q?.at ?? null })) events.push({ signal: s, status: ev.status });
        } catch (e) { err(`track ${sym}`, e); }
      }
    }
    st.lastTrack = now();
    if (events.length) prune();
    save();
    if (events.length) { try { onEvents(events); } catch (e) { err('onEvents', e); } }
    return events;
  }

  const loop = async () => {
    if (!running) return;
    if (!busy) {
      busy = true;
      try { await trackOnce(); if (now() - st.lastScan >= SCAN_EVERY_MS) await scanOnce(); } catch (e) { err('loop', e); } finally { busy = false; }
    }
    if (running) timer = setTimeout(loop, TRACK_EVERY_MS);
  };
  return { state: () => st, scanOnce, trackOnce, start() { if (running) return; running = true; loop(); }, stop() { running = false; clearTimeout(timer); } };
}

export { FINAL_STATUSES, LIVE_STATUSES };
