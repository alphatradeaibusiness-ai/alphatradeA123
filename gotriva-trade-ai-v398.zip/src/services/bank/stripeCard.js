// v369 Real card details for Stripe-issued cards: number, CVV and expiry are drawn by Stripe's own iframes (Issuing Elements),
// so they never pass through GOTRIVA's server or page script. Needs STRIPE_PUBLISHABLE_KEY on the server and js.stripe.com in the CSP.
let stripeP = null;
function loadStripe(pk) {
  if (stripeP) return stripeP;
  stripeP = new Promise((resolve, reject) => {
    if (window.Stripe) { resolve(window.Stripe(pk)); return; }
    const s = document.createElement('script'); s.src = 'https://js.stripe.com/v3/'; s.async = true;
    s.onload = () => (window.Stripe ? resolve(window.Stripe(pk)) : reject(new Error('stripe_js')));
    s.onerror = () => { stripeP = null; reject(Object.assign(new Error('stripe_js'), { code: 'stripe_js' })); };
    document.head.append(s);
  });
  return stripeP;
}
/** Mounts the three fields into `box` for `seconds`, then clears them. getKey(nonce) → { secret } from our server. */
export async function showStripeCard(box, { publishableKey, cardRef, seconds = 60 }, getKey) {
  if (!publishableKey || !cardRef) throw Object.assign(new Error('not_configured'), { code: 'not_configured' });
  const stripe = await loadStripe(publishableKey);
  const { nonce } = await stripe.createEphemeralKeyNonce({ issuingCard: cardRef });
  const { secret } = await getKey(nonce);
  const style = { base: { color: '#e9f5ee', fontSize: '16px', fontFamily: 'ui-monospace, Menlo, monospace', letterSpacing: '0.06em' } };
  box.innerHTML = '<div class="bsc-row"><div data-n></div></div><div class="bsc-row"><div data-e></div><div data-c></div></div>';
  const els = stripe.elements();
  const opts = { issuingCard: cardRef, nonce, ephemeralKeySecret: secret, style };
  els.create('issuingCardNumberDisplay', opts).mount(box.querySelector('[data-n]'));
  els.create('issuingCardExpiryDisplay', opts).mount(box.querySelector('[data-e]'));
  els.create('issuingCardCvcDisplay', opts).mount(box.querySelector('[data-c]'));
  setTimeout(() => { if (box.isConnected) box.innerHTML = ''; }, Math.min(120, seconds) * 1000);
}
