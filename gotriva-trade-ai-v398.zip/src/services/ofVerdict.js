// v380 Order Flow «what now»: one word for people — BUY, SELL, «don't buy now», «don't sell now» or WAIT — from the live order
// flow, optionally confirmed by SMC or by ICT (never both: they are separate schools). Pure: no DOM, no network.
// It is a probability read of what the tape and the book show now, not a forecast: the card says what it saw and what
// cancels it. Too little data → «collecting», never a guess.
import { BOOK, indicators } from './strategyBook.js';

const clamp = (x) => Math.max(-1, Math.min(1, x));
const sum = (a, f) => a.reduce((t, x) => t + f(x), 0);

/**
 * Order-flow bias from real data → { enough, score (−100…100), parts: [{ key, v (−1…1) }] }.
 * fp: footprint candles ({ delta, buy, sell, close }), book: { bids, asks } as [price, qty], poc: the session point of control.
 */
export function ofBias({ candles = [], book = null, price = null, poc = null } = {}) {
  if (candles.length < 10 || !book?.bids?.length || !book?.asks?.length || !(price > 0)) return { enough: false, score: 0, parts: [] };
  const last5 = candles.slice(-5); const vol5 = sum(last5, (c) => c.buy + c.sell) || 1;
  const d5 = clamp(sum(last5, (c) => c.delta) / vol5 * 2);                          // aggressive buying vs selling, last 5 candles
  const w = candles.slice(-20); const vol20 = sum(w, (c) => c.buy + c.sell) || 1;
  const cvd = clamp(sum(w, (c) => c.delta) / vol20 * 3);                              // cumulative delta over 20 candles
  const band = price * 0.0025; const near = (side) => sum(side.filter(([p]) => Math.abs(+p - price) <= band), ([, q]) => +q);
  const bq = near(book.bids), aq = near(book.asks); const imb = bq + aq > 0 ? clamp((bq - aq) / (bq + aq)) : 0;   // resting bids vs asks within ±0.25%
  const vsPoc = poc > 0 ? clamp(((price - poc) / price) * 400) : 0;                    // above / below the volume point of control
  const parts = [{ key: 'delta', v: d5 }, { key: 'cvd', v: cvd }, { key: 'book', v: imb }, { key: 'poc', v: vsPoc }];
  const score = Math.round(100 * (0.4 * d5 + 0.25 * cvd + 0.2 * imb + 0.15 * vsPoc));
  return { enough: true, score, parts };
}

/** SMC-only or ICT-only confirmation on closed candles: the side most of that school's rules pointed to in the last 12 bars. */
export function schoolConfirm(cs, school) {
  if (!['smc', 'ict'].includes(school) || !Array.isArray(cs) || cs.length < 220) return { dir: 0, n: 0, rules: [] };
  const I = indicators(cs); const last = I.n - 1; let up = 0, dn = 0; const rules = [];
  for (const s of BOOK.filter((x) => x.school === school)) {
    for (let i = last; i > last - 12; i--) { let d = 0; try { d = s.f(I, i) || 0; } catch { d = 0; } if (d) { if (d > 0) up++; else dn++; rules.push({ id: s.id, name: s.name, dir: d, ago: last - i }); break; } }
  }
  return { dir: up > dn ? 1 : dn > up ? -1 : 0, n: up + dn, up, dn, rules };
}

/**
 * The word → { action: 'buy'|'sell'|'no_buy'|'no_sell'|'wait'|'collecting', side, plan|null, reasons, cancel }.
 * mode: 'of' | 'smc' | 'ict'. A strong bias is |score| ≥ 35. With a school, the trade needs the school on the same side;
 * against it → «don't buy / don't sell now». atr sets the stop (1.2 ATR), targets at 1.5R and 3R.
 */
export function ofVerdict({ bias, mode = 'of', confirm = null, price, atr }) {
  if (!bias?.enough) return { action: 'collecting', side: 0, plan: null, reasons: [] };
  const side = bias.score >= 35 ? 1 : bias.score <= -35 ? -1 : 0;
  const reasons = bias.parts.filter((p) => Math.abs(p.v) >= 0.15).map((p) => ({ key: p.key, dir: Math.sign(p.v) }));
  if (!side) return { action: 'wait', side: 0, plan: null, reasons };
  if (mode !== 'of') {
    const c = confirm?.dir || 0;
    if (c === -side) return { action: side > 0 ? 'no_buy' : 'no_sell', side: 0, plan: null, reasons, against: mode };
    if (c !== side) return { action: 'wait', side: 0, plan: null, reasons, need: mode };
  }
  const risk = 1.2 * atr; if (!(risk > 0) || !(price > 0)) return { action: 'wait', side: 0, plan: null, reasons };
  const plan = { entry: price, stop: price - side * risk, tp1: price + side * 1.5 * risk, tp2: price + side * 3 * risk, risk };
  return { action: side > 0 ? 'buy' : 'sell', side, plan, reasons, cancel: side > 0 ? 'delta_flips_down' : 'delta_flips_up' };
}
