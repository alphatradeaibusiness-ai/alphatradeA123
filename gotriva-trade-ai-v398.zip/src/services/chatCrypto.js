// v361 Secret chats: end-to-end encryption in the browser (Web Crypto only, no library).
//  • every device keeps one ECDH P-256 key pair in IndexedDB; the private half is created non-extractable, so it never
//    leaves this browser (not even to our own server). Only the public half is sent.
//  • a secret chat binds the two public keys it was opened with. Both browsers derive the same AES-256-GCM key:
//    ECDH → HKDF-SHA-256 (salt = chat id). Every message / file gets its own random 96-bit IV.
//  • the server stores and relays ciphertext only. Losing this browser's storage means the old secret chats can't be read
//    any more (the same as Telegram's secret chats, which live on one device).
const DB = 'gotriva-e2e'; const STORE = 'keys';
const b64 = (buf) => { let s = ''; const a = new Uint8Array(buf); for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode(...a.subarray(i, i + 0x8000)); return btoa(s); };
const unb64 = (s) => Uint8Array.from(atob(s), (ch) => ch.charCodeAt(0));
const enc = new TextEncoder(); const dec = new TextDecoder();

function idb() {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(STORE);
    r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error);
  });
}
const idbGet = async (k) => { const db = await idb(); return new Promise((res, rej) => { const t = db.transaction(STORE).objectStore(STORE).get(k); t.onsuccess = () => res(t.result); t.onerror = () => rej(t.error); }); };
const idbPut = async (k, v) => { const db = await idb(); return new Promise((res, rej) => { const t = db.transaction(STORE, 'readwrite').objectStore(STORE).put(v, k); t.onsuccess = () => res(); t.onerror = () => rej(t.error); }); };

let devicePromise = null;
/** This browser's key pair (made once). Returns { priv, pub } where pub is the raw public key in base64. */
export function deviceKey() {
  if (!devicePromise) devicePromise = (async () => {
    if (!globalThis.crypto?.subtle || !globalThis.indexedDB) throw Object.assign(new Error('no_crypto'), { code: 'no_crypto' });
    let k = await idbGet('device').catch(() => null);
    if (!k?.priv || !k?.pub) {
      const pair = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
      k = { priv: pair.privateKey, pub: b64(await crypto.subtle.exportKey('raw', pair.publicKey)), at: Date.now() };
      await idbPut('device', k);
    }
    return k;
  })().catch((e) => { devicePromise = null; throw e; });
  return devicePromise;
}

const chatKeys = new Map();
/** The shared AES key of one secret chat (cached). */
export async function chatKey(chatId, peerPub) {
  const ck = `${chatId}:${peerPub}`; if (chatKeys.has(ck)) return chatKeys.get(ck);
  const p = (async () => {
    const me = await deviceKey();
    const peer = await crypto.subtle.importKey('raw', unb64(peerPub), { name: 'ECDH', namedCurve: 'P-256' }, false, []);
    const bits = await crypto.subtle.deriveBits({ name: 'ECDH', public: peer }, me.priv, 256);
    const hk = await crypto.subtle.importKey('raw', bits, 'HKDF', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: enc.encode(`gotriva-secret-v1:${chatId}`), info: enc.encode('messages') }, hk, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  })();
  chatKeys.set(ck, p); p.catch(() => chatKeys.delete(ck)); return p;
}

// v2 (security review): every ciphertext is bound to "chat id | sender uid | kind" as AES-GCM associated data, so the server
// can't relabel who sent a message, move a file onto another message, or change a voice note into an image.
const ad = (aad) => (aad ? { additionalData: enc.encode(aad) } : {});
export async function sealText(key, text, aad = '') { const iv = crypto.getRandomValues(new Uint8Array(12)); const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, ...ad(aad) }, key, enc.encode(text)); return { iv: b64(iv), ct: b64(ct), ...(aad ? { v: 2 } : {}) }; }
export async function openText(key, e, aad = '') { const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(e.iv), ...ad(e.v === 2 ? aad : '') }, key, unb64(e.ct)); return dec.decode(pt); }
export async function sealBlob(key, blob, aad = '') { const iv = crypto.getRandomValues(new Uint8Array(12)); const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, ...ad(aad) }, key, await blob.arrayBuffer()); return { iv: b64(iv), blob: new Blob([ct], { type: 'application/octet-stream' }), ...(aad ? { v: 2 } : {}) }; }
export async function openBlob(key, iv, buf, type = 'application/octet-stream', aad = '') { const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(iv), ...ad(aad) }, key, buf); return new Blob([pt], { type }); }

const EMOJI = ['🍎', '🐬', '🌵', '🚀', '🎈', '🦊', '🌙', '⚓', '🍀', '🎸', '🐝', '🔔', '🍩', '🧭', '🌈', '🐢', '🍉', '🦉', '⛵', '🎯', '🍄', '🐙', '🌻', '🧩', '🍒', '🦋', '🌊', '🔑', '🥝', '🐧', '🎲', '🌋'];
/** The chat's key picture: both people see the same 12 emoji and 16 hex groups only if nobody swapped a key in between. */
export async function fingerprint(pubA, pubB) {
  const [x, y] = [pubA, pubB].sort();
  const h = new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(`${x}|${y}`)));
  return { emoji: Array.from(h.subarray(0, 12), (v) => EMOJI[v % EMOJI.length]), hex: Array.from(h.subarray(0, 16), (v) => v.toString(16).padStart(2, '0')).join('').match(/.{4}/g) };
}
