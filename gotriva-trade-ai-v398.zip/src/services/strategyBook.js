// v371 «توصية AI» strategy book: 120+ classic, rule-based strategies (trend, mean reversion, breakout, price action,
import { TESTED } from './testedBook.js';
export { TESTED };
// oscillator combos, session, plus SMC-only and ICT-only rules that are never mixed with each other).
// Every strategy is a pure rule on CLOSED candles. Each one is replayed on the same candles the page loaded (no look-ahead,
// costs included) so the card can show its real record on this market and timeframe. When the main engine finds nothing,
// the page takes the best-scoring strategy that points somewhere right now, so a request always ends with a trade plan
// that names its strategy. A record on past candles is not a promise.
// Pure: no DOM, no network. EDH and Gotriva Elite are not touched.
import { registerBook } from '../config/aiSignalRules.js';

/* ── indicators (arrays aligned to the candles, NaN until warmed up) ── */
const NaNs = (n) => new Array(n).fill(NaN);
function emaA(v, p) { const o = NaNs(v.length); const k = 2 / (p + 1); let e = NaN, s = 0, c = 0;
  for (let i = 0; i < v.length; i++) { const x = v[i]; if (!Number.isFinite(x)) continue; if (c < p) { s += x; c++; if (c === p) { e = s / p; o[i] = e; } } else { e = x * k + e * (1 - k); o[i] = e; } } return o; }
function smaA(v, p) { const o = NaNs(v.length); let s = 0; for (let i = 0; i < v.length; i++) { s += v[i]; if (i >= p) s -= v[i - p]; if (i >= p - 1) o[i] = s / p; } return o; }
function stdA(v, p) { const m = smaA(v, p); const o = NaNs(v.length); for (let i = p - 1; i < v.length; i++) { let s = 0; for (let j = i - p + 1; j <= i; j++) s += (v[j] - m[i]) ** 2; o[i] = Math.sqrt(s / p); } return o; }
function wmaA(v, p) { const o = NaNs(v.length); const d = (p * (p + 1)) / 2; for (let i = p - 1; i < v.length; i++) { let s = 0; for (let j = 0; j < p; j++) s += v[i - j] * (p - j); o[i] = s / d; } return o; }
function rmaA(v, p) { const o = NaNs(v.length); let e = NaN, s = 0, c = 0; for (let i = 0; i < v.length; i++) { const x = v[i]; if (!Number.isFinite(x)) continue; if (c < p) { s += x; c++; if (c === p) { e = s / p; o[i] = e; } } else { e = (e * (p - 1) + x) / p; o[i] = e; } } return o; }
const maxA = (v, p, i) => { let m = -Infinity; for (let j = Math.max(0, i - p + 1); j <= i; j++) if (v[j] > m) m = v[j]; return m; };
const minA = (v, p, i) => { let m = Infinity; for (let j = Math.max(0, i - p + 1); j <= i; j++) if (v[j] < m) m = v[j]; return m; };

export function indicators(cs) {
  const n = cs.length; const o = cs.map((x) => x.open), h = cs.map((x) => x.high), l = cs.map((x) => x.low), c = cs.map((x) => x.close), v = cs.map((x) => Number(x.volume) || 0);
  const tr = cs.map((x, i) => (i ? Math.max(x.high - x.low, Math.abs(x.high - cs[i - 1].close), Math.abs(x.low - cs[i - 1].close)) : x.high - x.low));
  const memo = new Map(); const m = (k, f) => { if (!memo.has(k)) memo.set(k, f()); return memo.get(k); };
  const I = {
    n, o, h, l, c, v, t: cs.map((x) => x.time), hasVol: v.filter((x) => x > 0).length > n * 0.8,
    ema: (p) => m(`e${p}`, () => emaA(c, p)), sma: (p) => m(`s${p}`, () => smaA(c, p)), std: (p) => m(`sd${p}`, () => stdA(c, p)),
    atr: (p = 14) => m(`a${p}`, () => rmaA(tr, p)),
    rsi: (p) => m(`r${p}`, () => { const up = c.map((x, i) => (i ? Math.max(0, x - c[i - 1]) : 0)), dn = c.map((x, i) => (i ? Math.max(0, c[i - 1] - x) : 0));
      const U = rmaA(up.slice(1), p), D = rmaA(dn.slice(1), p); return [NaN, ...U.map((u, i) => (D[i] === 0 ? 100 : 100 - 100 / (1 + u / D[i])))]; }),
    macd: (f, s, g) => m(`m${f}.${s}.${g}`, () => { const a = emaA(c, f), b = emaA(c, s); const line = a.map((x, i) => x - b[i]); const sig = emaA(line, g); return { line, sig, hist: line.map((x, i) => x - sig[i]) }; }),
    bb: (p, k) => m(`b${p}.${k}`, () => { const mid = smaA(c, p), sd = stdA(c, p); return { mid, up: mid.map((x, i) => x + k * sd[i]), lo: mid.map((x, i) => x - k * sd[i]) }; }),
    kc: (p, k) => m(`k${p}.${k}`, () => { const mid = emaA(c, p), a = rmaA(tr, p); return { mid, up: mid.map((x, i) => x + k * a[i]), lo: mid.map((x, i) => x - k * a[i]) }; }),
    stoch: (p, sk, sd) => m(`st${p}.${sk}.${sd}`, () => { const raw = c.map((x, i) => { if (i < p - 1) return NaN; const hi = maxA(h, p, i), lo = minA(l, p, i); return hi === lo ? 50 : ((x - lo) / (hi - lo)) * 100; }); const k = smaA(raw.map((x) => (Number.isFinite(x) ? x : 0)), sk).map((x, i) => (i < p + sk - 2 ? NaN : x)); return { k, d: smaA(k.map((x) => (Number.isFinite(x) ? x : 0)), sd).map((x, i) => (i < p + sk + sd - 3 ? NaN : x)) }; }),
    cci: (p) => m(`c${p}`, () => { const tp = cs.map((x) => (x.high + x.low + x.close) / 3); const ma = smaA(tp, p); return tp.map((x, i) => { if (i < p - 1) return NaN; let md = 0; for (let j = i - p + 1; j <= i; j++) md += Math.abs(tp[j] - ma[i]); md /= p; return md ? (x - ma[i]) / (0.015 * md) : 0; }); }),
    wr: (p) => m(`w${p}`, () => c.map((x, i) => { if (i < p - 1) return NaN; const hi = maxA(h, p, i), lo = minA(l, p, i); return hi === lo ? -50 : ((hi - x) / (hi - lo)) * -100; })),
    adx: (p = 14) => m(`x${p}`, () => { const pdm = cs.map((x, i) => { if (!i) return 0; const u = x.high - cs[i - 1].high, d = cs[i - 1].low - x.low; return u > d && u > 0 ? u : 0; }); const ndm = cs.map((x, i) => { if (!i) return 0; const u = x.high - cs[i - 1].high, d = cs[i - 1].low - x.low; return d > u && d > 0 ? d : 0; });
      const A = rmaA(tr, p), P = rmaA(pdm, p), N = rmaA(ndm, p); const pdi = P.map((x, i) => (100 * x) / A[i]), ndi = N.map((x, i) => (100 * x) / A[i]); const dx = pdi.map((x, i) => (100 * Math.abs(x - ndi[i])) / (x + ndi[i] || 1)); return { adx: rmaA(dx, p), pdi, ndi }; }),
    don: (p) => m(`d${p}`, () => ({ hi: h.map((_, i) => (i < p ? NaN : maxA(h, p, i - 1))), lo: l.map((_, i) => (i < p ? NaN : minA(l, p, i - 1))) })),
    st: (p, k) => m(`su${p}.${k}`, () => { const a = rmaA(tr, p); const dir = NaNs(n); let up = NaN, dn = NaN, d = 1;
      for (let i = 0; i < n; i++) { if (!Number.isFinite(a[i])) continue; const mid = (h[i] + l[i]) / 2; const bu = mid - k * a[i], bd = mid + k * a[i];
        up = Number.isFinite(up) && c[i - 1] > up ? Math.max(bu, up) : bu; dn = Number.isFinite(dn) && c[i - 1] < dn ? Math.min(bd, dn) : bd;
        if (d === 1 && c[i] < up) d = -1; else if (d === -1 && c[i] > dn) d = 1; dir[i] = d; } return dir; }),
    psar: (st, mx) => m(`p${st}.${mx}`, () => { const dir = NaNs(n); if (n < 3) return dir; let up = c[1] > c[0], sar = up ? l[0] : h[0], ep = up ? h[1] : l[1], af = st;
      for (let i = 2; i < n; i++) { sar = sar + af * (ep - sar); if (up) { sar = Math.min(sar, l[i - 1], l[i - 2]); if (l[i] < sar) { up = false; sar = ep; ep = l[i]; af = st; } else if (h[i] > ep) { ep = h[i]; af = Math.min(mx, af + st); } }
        else { sar = Math.max(sar, h[i - 1], h[i - 2]); if (h[i] > sar) { up = true; sar = ep; ep = h[i]; af = st; } else if (l[i] < ep) { ep = l[i]; af = Math.min(mx, af + st); } } dir[i] = up ? 1 : -1; } return dir; }),
    ichi: () => m('ichi', () => { const mid = (p, i) => (i < p - 1 ? NaN : (maxA(h, p, i) + minA(l, p, i)) / 2); const ten = c.map((_, i) => mid(9, i)), kij = c.map((_, i) => mid(26, i));
      const sa = c.map((_, i) => (i < 26 ? NaN : (ten[i - 26] + kij[i - 26]) / 2)), sb = c.map((_, i) => (i < 26 ? NaN : mid(52, i - 26))); return { ten, kij, sa, sb }; }),
    hma: (p) => m(`h${p}`, () => { const a = wmaA(c, Math.floor(p / 2)), b = wmaA(c, p); const raw = a.map((x, i) => 2 * x - b[i]); const s = Math.floor(Math.sqrt(p)); const o2 = NaNs(n); for (let i = 0; i < n; i++) { if (i < p + s) continue; let t = 0; for (let j = 0; j < s; j++) t += raw[i - j] * (s - j); o2[i] = t / ((s * (s + 1)) / 2); } return o2; }),
    aroon: (p) => m(`ar${p}`, () => { const up = NaNs(n), dn = NaNs(n); for (let i = p; i < n; i++) { let hi = i, lo = i; for (let j = i - p; j <= i; j++) { if (h[j] >= h[hi]) hi = j; if (l[j] <= l[lo]) lo = j; } up[i] = ((p - (i - hi)) / p) * 100; dn[i] = ((p - (i - lo)) / p) * 100; } return { up, dn }; }),
    trix: (p) => m(`tx${p}`, () => { const e3 = emaA(emaA(emaA(c, p), p), p); return e3.map((x, i) => (i && Number.isFinite(e3[i - 1]) ? ((x - e3[i - 1]) / e3[i - 1]) * 10000 : NaN)); }),
    roc: (p) => m(`ro${p}`, () => c.map((x, i) => (i >= p ? ((x - c[i - p]) / c[i - p]) * 100 : NaN))),
    ha: () => m('ha', () => { const hc = cs.map((x) => (x.open + x.high + x.low + x.close) / 4); const ho = NaNs(n); ho[0] = (o[0] + c[0]) / 2; for (let i = 1; i < n; i++) ho[i] = (ho[i - 1] + hc[i - 1]) / 2; return hc.map((x, i) => (x >= ho[i] ? 1 : -1)); }),
    mfi: (p) => m(`mf${p}`, () => { const tp = cs.map((x) => (x.high + x.low + x.close) / 3); return tp.map((_, i) => { if (i < p) return NaN; let pos = 0, neg = 0; for (let j = i - p + 1; j <= i; j++) { const f = tp[j] * v[j]; if (tp[j] > tp[j - 1]) pos += f; else if (tp[j] < tp[j - 1]) neg += f; } return neg ? 100 - 100 / (1 + pos / neg) : 100; }); }),
    obvSlope: (p) => m(`ob${p}`, () => { const ob = [0]; for (let i = 1; i < n; i++) ob.push(ob[i - 1] + (c[i] > c[i - 1] ? v[i] : c[i] < c[i - 1] ? -v[i] : 0)); const e = emaA(ob, p); return ob.map((x, i) => x - e[i]); }),
    vwap: () => m('vw', () => { const o2 = NaNs(n); let day = null, pv = 0, vv = 0; for (let i = 0; i < n; i++) { const d = Math.floor(I.t[i] / 86400); if (d !== day) { day = d; pv = 0; vv = 0; } const tp = (h[i] + l[i] + c[i]) / 3; pv += tp * v[i]; vv += v[i]; o2[i] = vv ? pv / vv : NaN; } return o2; }),
    vortex: (p) => m(`vx${p}`, () => { const vp = NaNs(n), vm = NaNs(n); for (let i = p; i < n; i++) { let a = 0, b = 0, t = 0; for (let j = i - p + 1; j <= i; j++) { a += Math.abs(h[j] - l[j - 1]); b += Math.abs(l[j] - h[j - 1]); t += tr[j]; } vp[i] = a / t; vm[i] = b / t; } return { vp, vm }; }),
    linreg: (p) => m(`lr${p}`, () => c.map((_, i) => { if (i < p - 1) return NaN; let sx = 0, sy = 0, sxy = 0, sxx = 0; for (let j = 0; j < p; j++) { const y = c[i - p + 1 + j]; sx += j; sy += y; sxy += j * y; sxx += j * j; } return (p * sxy - sx * sy) / (p * sxx - sx * sx); })),
    swings: (k) => m(`sw${k}`, () => { const hi = [], lo = []; for (let i = k; i < n - k; i++) { let isH = true, isL = true; for (let j = 1; j <= k; j++) { if (h[i] <= h[i - j] || h[i] < h[i + j]) isH = false; if (l[i] >= l[i - j] || l[i] > l[i + j]) isL = false; } if (isH) hi.push(i); if (isL) lo.push(i); } return { hi, lo }; }),
  };
  return I;
}

/* ── rule helpers ── */
const sgn = (x) => (x > 0 ? 1 : x < 0 ? -1 : 0);
const ok = (...xs) => xs.every(Number.isFinite);
const crossUp = (a, b, i) => ok(a[i], b[i], a[i - 1], b[i - 1]) && a[i - 1] <= b[i - 1] && a[i] > b[i];
const crossDn = (a, b, i) => ok(a[i], b[i], a[i - 1], b[i - 1]) && a[i - 1] >= b[i - 1] && a[i] < b[i];
const lvlUp = (a, lv, i) => ok(a[i], a[i - 1]) && a[i - 1] <= lv && a[i] > lv;
const lvlDn = (a, lv, i) => ok(a[i], a[i - 1]) && a[i - 1] >= lv && a[i] < lv;
const body = (I, i) => I.c[i] - I.o[i];
const rng = (I, i) => I.h[i] - I.l[i];
/** last confirmed swing (k bars on each side) at or before bar i - k */
const lastSw = (arr, i, k) => { for (let j = arr.length - 1; j >= 0; j--) if (arr[j] <= i - k) return arr[j]; return -1; };
const prevSw = (arr, i, k) => { let seen = 0; for (let j = arr.length - 1; j >= 0; j--) if (arr[j] <= i - k) { if (seen) return arr[j]; seen = 1; } return -1; };

/* ── the book: [id, school, ar, en, rule(I, i) → -1 | 0 | 1] ── */
const B = [];
const add = (id, school, ar, en, f) => B.push({ id: `bk_${id}`, school, name: { ar, en }, f });

// trend: moving-average crosses (state while aligned)
for (const [a, b] of [[5, 13], [8, 21], [9, 21], [12, 26], [10, 30], [20, 50], [21, 55], [50, 200]]) add(`ema_${a}_${b}`, 'trend', `تقاطع EMA ${a}/${b}`, `EMA ${a}/${b} cross`, (I, i) => sgn(I.ema(a)[i] - I.ema(b)[i]));
for (const [a, b] of [[5, 20], [10, 30], [20, 50], [50, 200]]) add(`sma_${a}_${b}`, 'trend', `تقاطع SMA ${a}/${b}`, `SMA ${a}/${b} cross`, (I, i) => sgn(I.sma(a)[i] - I.sma(b)[i]));
for (const p of [20, 50, 100, 200]) add(`px_ema${p}`, 'trend', `السعر مقابل EMA ${p}`, `Price vs EMA ${p}`, (I, i) => sgn(I.c[i] - I.ema(p)[i]));
for (const [a, b, c] of [[8, 21, 55], [5, 13, 34], [20, 50, 100], [10, 20, 50]]) add(`ribbon_${a}_${b}_${c}`, 'trend', `شريط EMA ${a}/${b}/${c}`, `EMA ribbon ${a}/${b}/${c}`, (I, i) => { const x = I.ema(a)[i], y = I.ema(b)[i], z = I.ema(c)[i]; return x > y && y > z ? 1 : x < y && y < z ? -1 : 0; });
for (const [f, s, g] of [[12, 26, 9], [8, 17, 9], [5, 35, 5], [24, 52, 9]]) add(`macd_${f}_${s}_${g}`, 'trend', `MACD ${f}/${s}/${g} (خط الإشارة)`, `MACD ${f}/${s}/${g} signal`, (I, i) => sgn(I.macd(f, s, g).hist[i]));
for (const [f, s] of [[12, 26], [8, 17]]) add(`macd0_${f}_${s}`, 'trend', `MACD ${f}/${s} فوق/تحت الصفر`, `MACD ${f}/${s} zero line`, (I, i) => sgn(I.macd(f, s, 9).line[i]));
for (const t of [20, 25, 30]) add(`adx_${t}`, 'trend', `ADX فوق ${t} مع DI`, `ADX > ${t} with DI`, (I, i) => { const x = I.adx(14); return x.adx[i] > t ? sgn(x.pdi[i] - x.ndi[i]) : 0; });
for (const [p, k] of [[10, 3], [10, 2], [7, 3], [14, 2.5], [20, 4]]) add(`st_${p}_${k}`, 'trend', `سوبرترند ${p}/${k}`, `Supertrend ${p}/${k}`, (I, i) => I.st(p, k)[i] || 0);
for (const [s, mx] of [[0.02, 0.2], [0.01, 0.1]]) add(`psar_${s}`, 'trend', `بارابوليك SAR ${s}/${mx}`, `Parabolic SAR ${s}/${mx}`, (I, i) => I.psar(s, mx)[i] || 0);
add('ichi_cloud', 'trend', 'إيشيموكو: السعر والسحابة', 'Ichimoku: price vs cloud', (I, i) => { const x = I.ichi(); const top = Math.max(x.sa[i], x.sb[i]), bot = Math.min(x.sa[i], x.sb[i]); return !ok(top, bot) ? 0 : I.c[i] > top ? 1 : I.c[i] < bot ? -1 : 0; });
add('ichi_tk', 'trend', 'إيشيموكو: تقاطع Tenkan/Kijun', 'Ichimoku: Tenkan/Kijun', (I, i) => sgn(I.ichi().ten[i] - I.ichi().kij[i]));
add('ichi_full', 'trend', 'إيشيموكو كامل (سحابة + TK + Chikou)', 'Ichimoku full (cloud + TK + chikou)', (I, i) => { const x = I.ichi(); const top = Math.max(x.sa[i], x.sb[i]), bot = Math.min(x.sa[i], x.sb[i]); if (!ok(top, bot) || i < 26) return 0; const ch = sgn(I.c[i] - I.c[i - 26]); return I.c[i] > top && x.ten[i] > x.kij[i] && ch > 0 ? 1 : I.c[i] < bot && x.ten[i] < x.kij[i] && ch < 0 ? -1 : 0; });
for (const p of [9, 21, 55]) add(`hma_${p}`, 'trend', `ميل Hull MA ${p}`, `Hull MA ${p} slope`, (I, i) => sgn(I.hma(p)[i] - I.hma(p)[i - 1]));
for (const p of [10, 20, 55]) add(`don_${p}`, 'breakout', `اختراق دونشيان ${p}`, `Donchian ${p} breakout`, (I, i) => { const d = I.don(p); return I.c[i] > d.hi[i] ? 1 : I.c[i] < d.lo[i] ? -1 : 0; });
for (const [p, k] of [[20, 2], [20, 1.5]]) add(`kc_brk_${p}_${k}`, 'breakout', `اختراق كيلتنر ${p}/${k}`, `Keltner ${p}/${k} breakout`, (I, i) => { const x = I.kc(p, k); return I.c[i] > x.up[i] ? 1 : I.c[i] < x.lo[i] ? -1 : 0; });
for (const [p, k] of [[20, 2], [20, 2.5]]) add(`bb_brk_${p}_${k}`, 'breakout', `اختراق بولينجر ${p}/${k}`, `Bollinger ${p}/${k} breakout`, (I, i) => { const x = I.bb(p, k); return I.c[i] > x.up[i] ? 1 : I.c[i] < x.lo[i] ? -1 : 0; });
for (const p of [14, 25]) add(`aroon_${p}`, 'trend', `آرون ${p}`, `Aroon ${p}`, (I, i) => { const x = I.aroon(p); return x.up[i] > 70 && x.dn[i] < 30 ? 1 : x.dn[i] > 70 && x.up[i] < 30 ? -1 : 0; });
for (const p of [9, 15]) add(`trix_${p}`, 'trend', `TRIX ${p}`, `TRIX ${p}`, (I, i) => { const x = I.trix(p); const s = emaA(x, 9); return sgn(x[i] - s[i]); });
for (const p of [9, 14, 21]) add(`roc_${p}`, 'trend', `زخم ROC ${p}`, `ROC ${p} momentum`, (I, i) => sgn(I.roc(p)[i]));
add('ha_1', 'trend', 'هايكن آشي (لون الشمعة)', 'Heikin Ashi colour', (I, i) => I.ha()[i]);
add('ha_3', 'trend', 'هايكن آشي 3 شموع نفس اللون', 'Heikin Ashi 3 in a row', (I, i) => { const x = I.ha(); return x[i] === x[i - 1] && x[i] === x[i - 2] ? x[i] : 0; });
for (const p of [20, 50]) add(`lr_${p}`, 'trend', `ميل الانحدار الخطي ${p}`, `Linear regression ${p} slope`, (I, i) => sgn(I.linreg(p)[i]));
add('elder', 'trend', 'نظام إلدر Impulse', 'Elder impulse system', (I, i) => { const e = I.ema(13), hst = I.macd(12, 26, 9).hist; const a = sgn(e[i] - e[i - 1]), b = sgn(hst[i] - hst[i - 1]); return a === b ? a : 0; });
add('vortex', 'trend', 'مؤشر Vortex 14', 'Vortex 14', (I, i) => { const x = I.vortex(14); return sgn(x.vp[i] - x.vm[i]); });
add('cci_trend', 'trend', 'CCI اتجاه (±100)', 'CCI trend (±100)', (I, i) => { const x = I.cci(20)[i]; return x > 100 ? 1 : x < -100 ? -1 : 0; });
for (const [f, m, s] of [[20, 50, 200], [21, 55, 200]]) add(`pullback_${f}_${m}`, 'trend', `رجوع لـ EMA ${f} باتجاه ${m}/${s}`, `Pullback to EMA ${f} in a ${m}/${s} trend`, (I, i) => { const e = I.ema(f)[i], a = I.ema(m)[i], b = I.ema(s)[i]; if (!ok(e, a, b)) return 0; if (a > b && I.l[i] <= e && I.c[i] > e && body(I, i) > 0) return 1; if (a < b && I.h[i] >= e && I.c[i] < e && body(I, i) < 0) return -1; return 0; });
add('golden_adx', 'trend', 'تقاطع ذهبي/موت مع ADX > 20', 'Golden / death cross with ADX > 20', (I, i) => (I.adx(14).adx[i] > 20 ? sgn(I.sma(50)[i] - I.sma(200)[i]) : 0));
add('vol_mom', 'trend', 'زخم بحجم عالي فوق EMA 50', 'High-volume momentum with EMA 50', (I, i) => { if (!I.hasVol) return 0; const av = smaA(I.v, 20)[i]; if (!(I.v[i] > 1.5 * av)) return 0; const d = sgn(body(I, i)); return d === sgn(I.c[i] - I.ema(50)[i]) ? d : 0; });
add('obv', 'trend', 'OBV فوق/تحت متوسطه', 'OBV vs its average', (I, i) => (I.hasVol ? sgn(I.obvSlope(20)[i]) : 0));

// mean reversion
for (const [p, lo, hi] of [[14, 30, 70], [14, 25, 75], [14, 20, 80], [7, 20, 80], [7, 30, 70], [2, 10, 90], [2, 5, 95]]) add(`rsi_${p}_${lo}`, 'reversion', `ارتداد RSI ${p} (${lo}/${hi})`, `RSI ${p} reversal (${lo}/${hi})`, (I, i) => { const r = I.rsi(p); return lvlUp(r, lo, i) ? 1 : lvlDn(r, hi, i) ? -1 : 0; });
for (const lv of [5, 10]) add(`connors_${lv}`, 'reversion', `كونورز RSI 2 < ${lv} مع SMA 200`, `Connors RSI 2 < ${lv} with SMA 200`, (I, i) => { const r = I.rsi(2)[i], s = I.sma(200)[i]; if (!ok(r, s)) return 0; return I.c[i] > s && r < lv ? 1 : I.c[i] < s && r > 100 - lv ? -1 : 0; });
for (const [p, k] of [[20, 2], [20, 2.5], [10, 1.5]]) add(`bb_rev_${p}_${k}`, 'reversion', `رجوع جوّا بولينجر ${p}/${k}`, `Back inside Bollinger ${p}/${k}`, (I, i) => { const x = I.bb(p, k); return I.c[i - 1] < x.lo[i - 1] && I.c[i] > x.lo[i] ? 1 : I.c[i - 1] > x.up[i - 1] && I.c[i] < x.up[i] ? -1 : 0; });
for (const [lo, hi] of [[30, 70], [25, 75]]) add(`bb_rsi_${lo}`, 'combo', `بولينجر + RSI (${lo}/${hi})`, `Bollinger + RSI (${lo}/${hi})`, (I, i) => { const x = I.bb(20, 2), r = I.rsi(14)[i]; return I.l[i] <= x.lo[i] && r < lo && body(I, i) > 0 ? 1 : I.h[i] >= x.up[i] && r > hi && body(I, i) < 0 ? -1 : 0; });
for (const [p, s, d, lo] of [[14, 3, 3, 20], [5, 3, 3, 20], [21, 5, 5, 25]]) add(`stoch_${p}_${s}_${d}`, 'reversion', `ستوكاستك ${p}/${s}/${d}`, `Stochastic ${p}/${s}/${d}`, (I, i) => { const x = I.stoch(p, s, d); return crossUp(x.k, x.d, i) && x.k[i] < lo + 10 ? 1 : crossDn(x.k, x.d, i) && x.k[i] > 90 - lo ? -1 : 0; });
add('stochrsi', 'reversion', 'Stoch RSI 14', 'Stoch RSI 14', (I, i) => { const r = I.rsi(14); const raw = r.map((_, j) => { if (j < 28) return NaN; const hi = maxA(r, 14, j), lo = minA(r, 14, j); return hi === lo ? 50 : ((r[j] - lo) / (hi - lo)) * 100; }); const k = smaA(raw.map((x) => x || 0), 3), d = smaA(k, 3); return crossUp(k, d, i) && k[i] < 25 ? 1 : crossDn(k, d, i) && k[i] > 75 ? -1 : 0; });
for (const [p, lv] of [[20, 100], [14, 200]]) add(`cci_rev_${p}`, 'reversion', `ارتداد CCI ${p} (±${lv})`, `CCI ${p} reversal (±${lv})`, (I, i) => { const x = I.cci(p); return lvlUp(x, -lv, i) ? 1 : lvlDn(x, lv, i) ? -1 : 0; });
for (const p of [14, 28]) add(`wr_${p}`, 'reversion', `ويليامز %R ${p}`, `Williams %R ${p}`, (I, i) => { const x = I.wr(p); return lvlUp(x, -80, i) ? 1 : lvlDn(x, -20, i) ? -1 : 0; });
add('mfi', 'reversion', 'MFI 14 (20/80)', 'MFI 14 (20/80)', (I, i) => { if (!I.hasVol) return 0; const x = I.mfi(14); return lvlUp(x, 20, i) ? 1 : lvlDn(x, 80, i) ? -1 : 0; });
for (const [p, z] of [[20, 2], [50, 2], [20, 2.5]]) add(`z_${p}_${z}`, 'reversion', `Z-Score ${p} (±${z})`, `Z-score ${p} (±${z})`, (I, i) => { const zz = (j) => (I.c[j] - I.sma(p)[j]) / I.std(p)[j]; const a = zz(i - 1), b = zz(i); return !ok(a, b) ? 0 : a < -z && b > a ? 1 : a > z && b < a ? -1 : 0; });
add('kc_rev', 'reversion', 'رجوع من حد كيلتنر 20/2', 'Keltner 20/2 reversion', (I, i) => { const x = I.kc(20, 2); return I.l[i] < x.lo[i] && I.c[i] > x.lo[i] ? 1 : I.h[i] > x.up[i] && I.c[i] < x.up[i] ? -1 : 0; });
add('rsi_div', 'reversion', 'دايفرجنس RSI 14', 'RSI 14 divergence', (I, i) => divergence(I, i, I.rsi(14)));
add('macd_div', 'reversion', 'دايفرجنس MACD', 'MACD divergence', (I, i) => divergence(I, i, I.macd(12, 26, 9).hist));
add('vwap_rev', 'reversion', 'رجوع لـ VWAP من ±2σ', 'VWAP ±2σ reversion', (I, i) => { if (!I.hasVol) return 0; const w = I.vwap()[i], s = I.std(20)[i]; if (!ok(w, s)) return 0; return I.c[i - 1] < w - 2 * s && I.c[i] > I.c[i - 1] ? 1 : I.c[i - 1] > w + 2 * s && I.c[i] < I.c[i - 1] ? -1 : 0; });
add('vwap_trend', 'trend', 'السعر مقابل VWAP اليومي', 'Price vs daily VWAP', (I, i) => (I.hasVol ? sgn(I.c[i] - I.vwap()[i]) : 0));

// breakout / volatility
for (const k of [1.5, 2]) add(`squeeze_${k}`, 'breakout', `انضغاط بولينجر داخل كيلتنر (${k})`, `Bollinger-in-Keltner squeeze (${k})`, (I, i) => { const b = I.bb(20, 2), kc = I.kc(20, k); const was = b.up[i - 1] < kc.up[i - 1] && b.lo[i - 1] > kc.lo[i - 1]; return was ? (I.c[i] > b.up[i] ? 1 : I.c[i] < b.lo[i] ? -1 : 0) : 0; });
for (const nb of [4, 7]) add(`nr${nb}`, 'breakout', `اختراق NR${nb}`, `NR${nb} breakout`, (I, i) => { let narrow = true; for (let j = 2; j <= nb; j++) if (rng(I, i - j) < rng(I, i - 1)) { narrow = false; break; } return narrow ? (I.c[i] > I.h[i - 1] ? 1 : I.c[i] < I.l[i - 1] ? -1 : 0) : 0; });
add('inside_bar', 'breakout', 'اختراق الشمعة الداخلية', 'Inside bar breakout', (I, i) => (I.h[i - 1] < I.h[i - 2] && I.l[i - 1] > I.l[i - 2] ? (I.c[i] > I.h[i - 2] ? 1 : I.c[i] < I.l[i - 2] ? -1 : 0) : 0));
add('inside_bar_ema', 'combo', 'شمعة داخلية + EMA 50', 'Inside bar + EMA 50', (I, i) => { const s = (I.h[i - 1] < I.h[i - 2] && I.l[i - 1] > I.l[i - 2]) ? (I.c[i] > I.h[i - 2] ? 1 : I.c[i] < I.l[i - 2] ? -1 : 0) : 0; return s && s === sgn(I.c[i] - I.ema(50)[i]) ? s : 0; });
add('atr_expand', 'breakout', 'شمعة توسّع (أكبر من 1.8 ATR)', 'Range expansion (> 1.8 ATR)', (I, i) => (rng(I, i) > 1.8 * I.atr(14)[i - 1] && Math.abs(body(I, i)) > 0.6 * rng(I, i) ? sgn(body(I, i)) : 0));
add('range_brk', 'breakout', 'اختراق تجميع 20 شمعة', '20-bar consolidation breakout', (I, i) => { const hi = maxA(I.h, 20, i - 1), lo = minA(I.l, 20, i - 1); if (!(hi - lo < 4 * I.atr(14)[i - 1])) return 0; return I.c[i] > hi ? 1 : I.c[i] < lo ? -1 : 0; });
add('pdhl', 'breakout', 'اختراق قمة/قاع اليوم السابق', 'Previous day high / low break', (I, i) => { const d = Math.floor(I.t[i] / 86400); let hi = -Infinity, lo = Infinity, f = false; for (let j = i - 1; j >= 0; j--) { const dj = Math.floor(I.t[j] / 86400); if (dj === d) continue; if (dj < d - 1) break; f = true; hi = Math.max(hi, I.h[j]); lo = Math.min(lo, I.l[j]); } if (!f) return 0; return I.c[i] > hi && I.c[i - 1] <= hi ? 1 : I.c[i] < lo && I.c[i - 1] >= lo ? -1 : 0; });
add('orb', 'session', 'اختراق نطاق أول ساعة باليوم', 'First-hour range breakout (UTC day)', (I, i) => { const d = Math.floor(I.t[i] / 86400) * 86400; let hi = -Infinity, lo = Infinity, f = 0; for (let j = i; j >= 0 && I.t[j] >= d; j--) if (I.t[j] < d + 3600 && j < i) { hi = Math.max(hi, I.h[j]); lo = Math.min(lo, I.l[j]); f++; } if (!f || I.t[i] < d + 3600) return 0; return I.c[i] > hi && I.c[i - 1] <= hi ? 1 : I.c[i] < lo && I.c[i - 1] >= lo ? -1 : 0; });
add('london_mom', 'session', 'زخم افتتاح لندن (07–09 UTC)', 'London open momentum (07–09 UTC)', (I, i) => { const hr = new Date(I.t[i] * 1000).getUTCHours(); if (hr < 7 || hr > 9) return 0; return Math.abs(body(I, i)) > 1.2 * I.atr(14)[i - 1] ? sgn(body(I, i)) : 0; });
add('ny_mom', 'session', 'زخم افتتاح نيويورك (13–15 UTC)', 'New York open momentum (13–15 UTC)', (I, i) => { const hr = new Date(I.t[i] * 1000).getUTCHours(); if (hr < 13 || hr > 15) return 0; return Math.abs(body(I, i)) > 1.2 * I.atr(14)[i - 1] ? sgn(body(I, i)) : 0; });

// price action / candles
add('engulf', 'price_action', 'شمعة ابتلاعية', 'Engulfing candle', (I, i) => engulf(I, i));
add('engulf_ema', 'combo', 'ابتلاعية باتجاه EMA 50', 'Engulfing with EMA 50', (I, i) => { const s = engulf(I, i); return s && s === sgn(I.c[i] - I.ema(50)[i]) ? s : 0; });
add('pin', 'price_action', 'بين بار (ذيل رفض)', 'Pin bar', (I, i) => pin(I, i));
add('pin_trend', 'combo', 'بين بار باتجاه EMA 200', 'Pin bar with EMA 200', (I, i) => { const s = pin(I, i); return s && s === sgn(I.c[i] - I.ema(200)[i]) ? s : 0; });
add('three', 'price_action', 'ثلاث جنود / ثلاث غربان', 'Three soldiers / crows', (I, i) => { const a = sgn(body(I, i)), b = sgn(body(I, i - 1)), c = sgn(body(I, i - 2)); return a && a === b && b === c && Math.sign(I.c[i] - I.c[i - 1]) === a && Math.sign(I.c[i - 1] - I.c[i - 2]) === a && Math.abs(body(I, i)) > 0.5 * rng(I, i) ? a : 0; });
add('star', 'price_action', 'نجمة الصباح / المساء', 'Morning / evening star', (I, i) => { const big = (j) => Math.abs(body(I, j)) > 0.6 * rng(I, j); const small = Math.abs(body(I, i - 1)) < 0.3 * rng(I, i - 1); if (!small || !big(i) || !big(i - 2)) return 0; const d = sgn(body(I, i)); return d === -sgn(body(I, i - 2)) && (d > 0 ? I.c[i] > (I.o[i - 2] + I.c[i - 2]) / 2 : I.c[i] < (I.o[i - 2] + I.c[i - 2]) / 2) ? d : 0; });
add('tweezer', 'price_action', 'قاع/قمة ملقط', 'Tweezer bottom / top', (I, i) => { const a = I.atr(14)[i] * 0.1; if (Math.abs(I.l[i] - I.l[i - 1]) < a && body(I, i - 1) < 0 && body(I, i) > 0) return 1; if (Math.abs(I.h[i] - I.h[i - 1]) < a && body(I, i - 1) > 0 && body(I, i) < 0) return -1; return 0; });
add('outside', 'price_action', 'انعكاس الشمعة الخارجية', 'Outside bar reversal', (I, i) => (I.h[i] > I.h[i - 1] && I.l[i] < I.l[i - 1] ? (I.c[i] > I.h[i - 1] ? 1 : I.c[i] < I.l[i - 1] ? -1 : 0) : 0));
for (const k of [3, 5]) add(`hhhl_${k}`, 'price_action', `قمم وقيعان صاعدة/هابطة (${k})`, `Higher highs & lows (${k})`, (I, i) => { const s = I.swings(k); const h1 = lastSw(s.hi, i, k), h0 = prevSw(s.hi, i, k), l1 = lastSw(s.lo, i, k), l0 = prevSw(s.lo, i, k); if ([h1, h0, l1, l0].some((x) => x < 0)) return 0; return I.h[h1] > I.h[h0] && I.l[l1] > I.l[l0] ? 1 : I.h[h1] < I.h[h0] && I.l[l1] < I.l[l0] ? -1 : 0; });
add('retest', 'price_action', 'كسر وإعادة اختبار 20 شمعة', '20-bar break and retest', (I, i) => { for (let j = i - 1; j >= i - 6 && j > 21; j--) { const hi = maxA(I.h, 20, j - 1), lo = minA(I.l, 20, j - 1); if (I.c[j] > hi && I.l[i] <= hi && I.c[i] > hi) return 1; if (I.c[j] < lo && I.h[i] >= lo && I.c[i] < lo) return -1; } return 0; });
add('fib618', 'fib', 'رجوع فيبوناتشي 61.8% بالاتجاه', 'Fibonacci 61.8% trend pullback', (I, i) => { const s = I.swings(5); const hI = lastSw(s.hi, i, 5), lI = lastSw(s.lo, i, 5); if (hI < 0 || lI < 0) return 0; const hi = I.h[hI], lo = I.l[lI]; const up = lI < hI; const f = up ? hi - 0.618 * (hi - lo) : lo + 0.618 * (hi - lo); const tol = 0.15 * I.atr(14)[i]; if (up && I.l[i] <= f + tol && I.c[i] > f && I.ema(50)[i] < I.c[i]) return 1; if (!up && I.h[i] >= f - tol && I.c[i] < f && I.ema(50)[i] > I.c[i]) return -1; return 0; });
add('pivot_bounce', 'price_action', 'ارتداد من S1/R1 (بيفوت يومي)', 'Daily pivot S1 / R1 bounce', (I, i) => { const p = dayPivot(I, i); if (!p) return 0; if (I.l[i] <= p.s1 && I.c[i] > p.s1) return 1; if (I.h[i] >= p.r1 && I.c[i] < p.r1) return -1; return 0; });
add('pivot_brk', 'breakout', 'كسر البيفوت اليومي', 'Daily pivot break', (I, i) => { const p = dayPivot(I, i); if (!p) return 0; return I.c[i] > p.p && I.c[i - 1] <= p.p ? 1 : I.c[i] < p.p && I.c[i - 1] >= p.p ? -1 : 0; });

// combos: one trend filter + one trigger (classic pairings)
const FILTERS = [['ema200', 'EMA 200', 'EMA 200', (I, i) => sgn(I.c[i] - I.ema(200)[i])], ['st', 'سوبرترند 10/3', 'Supertrend 10/3', (I, i) => I.st(10, 3)[i] || 0], ['adx', 'ADX > 25', 'ADX > 25', (I, i) => { const x = I.adx(14); return x.adx[i] > 25 ? sgn(x.pdi[i] - x.ndi[i]) : 0; }], ['ichi', 'سحابة إيشيموكو', 'Ichimoku cloud', (I, i) => { const x = I.ichi(); const top = Math.max(x.sa[i], x.sb[i]), bot = Math.min(x.sa[i], x.sb[i]); return !ok(top, bot) ? 0 : I.c[i] > top ? 1 : I.c[i] < bot ? -1 : 0; }]];
const TRIGGERS = [['rsi50', 'RSI يقطع 50', 'RSI crosses 50', (I, i) => (lvlUp(I.rsi(14), 50, i) ? 1 : lvlDn(I.rsi(14), 50, i) ? -1 : 0)], ['stoch', 'تقاطع ستوكاستك', 'Stochastic cross', (I, i) => { const x = I.stoch(14, 3, 3); return crossUp(x.k, x.d, i) ? 1 : crossDn(x.k, x.d, i) ? -1 : 0; }],
  ['macd', 'تقاطع MACD', 'MACD cross', (I, i) => { const x = I.macd(12, 26, 9); return crossUp(x.line, x.sig, i) ? 1 : crossDn(x.line, x.sig, i) ? -1 : 0; }], ['bbmid', 'ارتداد عن وسط بولينجر', 'Bollinger middle bounce', (I, i) => { const m = I.bb(20, 2).mid; return I.l[i] <= m[i] && I.c[i] > m[i] && body(I, i) > 0 ? 1 : I.h[i] >= m[i] && I.c[i] < m[i] && body(I, i) < 0 ? -1 : 0; }],
  ['ema9', 'تقاطع السعر مع EMA 9', 'Price crosses EMA 9', (I, i) => (crossUp(I.c, I.ema(9), i) ? 1 : crossDn(I.c, I.ema(9), i) ? -1 : 0)]];
for (const [fid, far, fen, ff] of FILTERS) for (const [tid, tar, ten, tf] of TRIGGERS) add(`cmb_${fid}_${tid}`, 'combo', `${far} + ${tar}`, `${fen} + ${ten}`, (I, i) => { const t = tf(I, i); return t && t === ff(I, i) ? t : 0; });

// SMC only (structure, order block). Never mixed with ICT rules.
for (const k of [3, 5]) add(`smc_bos_${k}`, 'smc', `SMC: كسر هيكل BOS (${k})`, `SMC: break of structure (${k})`, (I, i) => { const s = I.swings(k); const h1 = lastSw(s.hi, i, k), l1 = lastSw(s.lo, i, k); if (h1 < 0 || l1 < 0) return 0; const tr = sgn(I.ema(50)[i] - I.ema(200)[i]); if (tr > 0 && I.c[i] > I.h[h1] && I.c[i - 1] <= I.h[h1]) return 1; if (tr < 0 && I.c[i] < I.l[l1] && I.c[i - 1] >= I.l[l1]) return -1; return 0; });
add('smc_choch', 'smc', 'SMC: تغيّر الطابع CHoCH', 'SMC: change of character', (I, i) => { const s = I.swings(3); const h1 = lastSw(s.hi, i, 3), l1 = lastSw(s.lo, i, 3); if (h1 < 0 || l1 < 0) return 0; const tr = sgn(I.ema(20)[i - 3] - I.ema(50)[i - 3]); if (tr < 0 && I.c[i] > I.h[h1] && I.c[i - 1] <= I.h[h1]) return 1; if (tr > 0 && I.c[i] < I.l[l1] && I.c[i - 1] >= I.l[l1]) return -1; return 0; });
add('smc_ob', 'smc', 'SMC: رجوع لأوردر بلوك', 'SMC: order block retest', (I, i) => { for (let j = i - 2; j > i - 30 && j > 2; j--) { const a = I.atr(14)[j]; if (!(Math.abs(body(I, j + 1)) > 1.5 * a)) continue; const d = sgn(body(I, j + 1)); if (sgn(body(I, j)) !== -d) continue; const top = Math.max(I.o[j], I.c[j]), bot = Math.min(I.o[j], I.c[j]); if (d > 0 && I.l[i] <= top && I.c[i] > top) return 1; if (d < 0 && I.h[i] >= bot && I.c[i] < bot) return -1; return 0; } return 0; });
add('smc_sweep', 'smc', 'SMC: سحب سيولة ورجوع', 'SMC: liquidity sweep and reclaim', (I, i) => { const s = I.swings(3); const h1 = lastSw(s.hi, i, 3), l1 = lastSw(s.lo, i, 3); if (l1 >= 0 && I.l[i] < I.l[l1] && I.c[i] > I.l[l1]) return 1; if (h1 >= 0 && I.h[i] > I.h[h1] && I.c[i] < I.h[h1]) return -1; return 0; });
// ICT only (time windows, fair value gaps, OTE). Never mixed with SMC rules.
add('ict_fvg', 'ict', 'ICT: رجوع لفجوة FVG', 'ICT: fair value gap return', (I, i) => { for (let j = i - 1; j > i - 15 && j > 1; j--) { if (I.l[j + 1] > I.h[j - 1] && I.l[i] <= I.l[j + 1] && I.c[i] > I.h[j - 1]) return 1; if (I.h[j + 1] < I.l[j - 1] && I.h[i] >= I.h[j + 1] && I.c[i] < I.l[j - 1]) return -1; } return 0; });
add('ict_silver', 'ict', 'ICT: سيلفر بوليت (10–11 نيويورك)', 'ICT: Silver Bullet (10–11 New York)', (I, i) => { const hr = (new Date(I.t[i] * 1000).getUTCHours() + 24 - 4) % 24; if (hr !== 10) return 0; if (i > 2 && I.l[i] > I.h[i - 2]) return 1; if (i > 2 && I.h[i] < I.l[i - 2]) return -1; return 0; });
add('ict_ote', 'ict', 'ICT: منطقة OTE (62–79%)', 'ICT: OTE zone (62–79%)', (I, i) => { const s = I.swings(5); const hI = lastSw(s.hi, i, 5), lI = lastSw(s.lo, i, 5); if (hI < 0 || lI < 0) return 0; const hi = I.h[hI], lo = I.l[lI]; const up = lI < hI; const a = up ? hi - 0.79 * (hi - lo) : lo + 0.62 * (hi - lo), b = up ? hi - 0.62 * (hi - lo) : lo + 0.79 * (hi - lo); if (up && I.l[i] <= b && I.l[i] >= a && body(I, i) > 0) return 1; if (!up && I.h[i] >= a && I.h[i] <= b && body(I, i) < 0) return -1; return 0; });
add('ict_judas', 'ict', 'ICT: Judas swing بعد افتتاح لندن', 'ICT: Judas swing after the London open', (I, i) => { const hr = new Date(I.t[i] * 1000).getUTCHours(); if (hr < 7 || hr > 10) return 0; const d = Math.floor(I.t[i] / 86400) * 86400; let hi = -Infinity, lo = Infinity; for (let j = i - 1; j >= 0 && I.t[j] >= d; j--) if (new Date(I.t[j] * 1000).getUTCHours() < 7) { hi = Math.max(hi, I.h[j]); lo = Math.min(lo, I.l[j]); } if (!Number.isFinite(hi)) return 0; if (I.l[i] < lo && I.c[i] > lo) return 1; if (I.h[i] > hi && I.c[i] < hi) return -1; return 0; });

function engulf(I, i) { const b0 = body(I, i), b1 = body(I, i - 1); if (b0 > 0 && b1 < 0 && I.c[i] >= I.o[i - 1] && I.o[i] <= I.c[i - 1]) return 1; if (b0 < 0 && b1 > 0 && I.c[i] <= I.o[i - 1] && I.o[i] >= I.c[i - 1]) return -1; return 0; }
function pin(I, i) { const r = rng(I, i); if (!(r > 0)) return 0; const up = Math.min(I.o[i], I.c[i]) - I.l[i], dn = I.h[i] - Math.max(I.o[i], I.c[i]); if (up > 0.6 * r && I.l[i] < minA(I.l, 10, i - 1)) return 1; if (dn > 0.6 * r && I.h[i] > maxA(I.h, 10, i - 1)) return -1; return 0; }
function divergence(I, i, osc) { const k = 3; const s = I.swings(k); const l1 = lastSw(s.lo, i, k), l0 = prevSw(s.lo, i, k), h1 = lastSw(s.hi, i, k), h0 = prevSw(s.hi, i, k);
  if (l1 > 0 && l0 > 0 && i - l1 === k && I.l[l1] < I.l[l0] && osc[l1] > osc[l0] && body(I, i) > 0) return 1;
  if (h1 > 0 && h0 > 0 && i - h1 === k && I.h[h1] > I.h[h0] && osc[h1] < osc[h0] && body(I, i) < 0) return -1; return 0; }
function dayPivot(I, i) { const d = Math.floor(I.t[i] / 86400); let hi = -Infinity, lo = Infinity, cl = NaN; for (let j = i - 1; j >= 0; j--) { const dj = Math.floor(I.t[j] / 86400); if (dj === d) continue; if (dj < d - 1) break; if (!Number.isFinite(cl)) cl = I.c[j]; hi = Math.max(hi, I.h[j]); lo = Math.min(lo, I.l[j]); } if (!Number.isFinite(cl)) return null; const p = (hi + lo + cl) / 3; return { p, r1: 2 * p - lo, s1: 2 * p - hi }; }

// v398 the library keeps ONLY rules that passed the backtest (testedBook.js) plus the SMC / ICT rules that the order-flow page uses
// as confirmations. Every other rule (losing, no trades, or below 56% wins) is removed and can never run anywhere.
const PASSED = new Set(TESTED.map((t) => t.id));
export const REMOVED = B.filter((x) => !PASSED.has(x.id) && x.school !== 'smc' && x.school !== 'ict').map((x) => x.id);
export const BOOK = B.filter((x) => PASSED.has(x.id) || x.school === 'smc' || x.school === 'ict');
export const BOOK_SIZE = BOOK.length;
const BY_ID = new Map(BOOK.map((s) => [s.id, s]));
export const bookStrategy = (id) => BY_ID.get(id) || null;
registerBook(bookStrategy);   // names on the card and the performance panel (aiSignalRules.strategyOf)
/** SMC and ICT stay separate: a combined rule may never take conditions from both schools. */
export const SCHOOLS_NEVER_MIXED = ['smc', 'ict'];

/* ── replay on the loaded candles ── */
export const STYLE_CFG = { scalp: { stopAtr: 1.2, tp: [1, 1.5, 2.5], hold: 24 }, swing: { stopAtr: 2, tp: [1, 2, 3], hold: 60 } };
/**
 * Replays one strategy: a trade opens at the close of a bar whose signal is new (it was not pointing the same way one bar before),
 * stop = stopAtr × ATR, target = the main target (TP2) in R. Stop first when both are touched in one bar. Costs taken in R.
 */
export function replay(I, s, { style = 'scalp', costPct = 0, from = 210 } = {}) {
  const cfg = STYLE_CFG[style] || STYLE_CFG.scalp; const A = I.atr(14); const tpR = cfg.tp[1];
  let n = 0, wins = 0, sumR = 0, gw = 0, gl = 0, prev = 0, busyTo = -1;
  for (let i = Math.max(from, 3); i < I.n - 1; i++) {
    let d = 0; try { d = s.f(I, i) || 0; } catch { d = 0; }
    const fresh = d !== 0 && d !== prev; prev = d;
    if (!fresh || i <= busyTo || !(A[i] > 0)) continue;
    const e = I.c[i], risk = cfg.stopAtr * A[i], st = e - d * risk, tg = e + d * tpR * risk; const cR = ((e * costPct) / 100) / risk;
    let r = null, j = i + 1;
    for (; j < I.n && j <= i + cfg.hold; j++) {
      const hitS = d > 0 ? I.l[j] <= st : I.h[j] >= st, hitT = d > 0 ? I.h[j] >= tg : I.l[j] <= tg;
      if (hitS) { r = -1; break; } if (hitT) { r = tpR; break; }
    }
    if (r == null) { if (j >= I.n) break; r = ((I.c[Math.min(j, I.n - 1)] - e) * d) / risk; }   // time exit; a trade still open at the end is not counted
    r -= cR; n++; sumR += r; if (r > 0) { wins++; gw += r; } else gl -= r; busyTo = j;
  }
  return { n, wins, winRate: n ? wins / n : null, avgR: n ? sumR / n : null, pf: gl > 0 ? gw / gl : gw > 0 ? Infinity : null };
}

/* ── v398: recommendations come ONLY from TESTED (testedBook.js): each entry = one rule on one timeframe with one order type,
 * with the stop (sa × ATR 14), target (tp × risk), trend filter and limit offset it was tested with. ── */
export const TF_OF = { 60: '1m', 300: '5m', 900: '15m', 3600: '1h', 14400: '4h', 86400: '1D' };
const SYM_OF = { crypto: 'BTCUSD', forex: 'EURUSD', metal: 'XAUUSD' };   // the market each class was tested on
export const CORE_IDS = [...new Set(TESTED.map((t) => t.id))];
export const CORE = CORE_IDS.map((id) => BY_ID.get(id)).filter(Boolean);
STYLE_CFG.trend = { stopAtr: 2.5, tp: [1, 4], hold: 150 };
/** −1 / 0 / 1: EMA 200 rising or falling and ADX ≥ 20. */
export function trendOf(I, i) {
  const e = I.ema(200); const x = I.adx(14); const adx = x.adx ? x.adx[i] : x[i];
  if (!(e[i] > 0 && e[i - 10] > 0 && adx >= 20)) return 0;
  return I.c[i] > e[i] && e[i] > e[i - 10] ? 1 : I.c[i] < e[i] && e[i] < e[i - 10] ? -1 : 0;
}

/**
 * v398 → { size, signals, pick, longs, shorts, why }. Only entries tested on this timeframe, this order type ('auto': both) and a
 * market of this class where the rule was positive. A rule counts only when its signal is NEW on the last closed candle and, if it
 * was tested with the trend filter, points with the trend. Buy and sell together → stay out. Pick = best untouched-test result.
 */
export function runBook(cs, { costPct = 0, tfSec = 0, asset = '', execution = 'auto' } = {}) {
  const tf = TF_OF[tfSec] || ''; const sym = SYM_OF[asset] || '';
  const pool = TESTED.filter((x) => x.tf === tf && (execution === 'market' || execution === 'limit' ? x.order === execution : true) && (!sym || x.mk.includes(sym)));
  const empty = (why) => ({ size: pool.length, signals: [], pick: null, longs: 0, shorts: 0, why });
  if (!Array.isArray(cs) || cs.length < 220) return empty('few_candles');
  if (asset && !sym) return empty('untested');
  if (!pool.length) return empty('none_tested');
  const I = indicators(cs); const i = I.n - 1; const t = trendOf(I, i); const out = [];
  for (const x of pool) {
    const s = BY_ID.get(x.id); if (!s) continue;
    let d = 0, d1 = 0; try { d = s.f(I, i) || 0; d1 = s.f(I, i - 1) || 0; } catch { d = 0; }
    if (!d || d === d1 || (x.trend && d !== t)) continue;
    out.push({ id: x.id, school: s.school, name: s.name, dir: d, order: x.order, cfg: x, score: x.avg * Math.sqrt(x.n) });
  }
  out.sort((a, b) => b.score - a.score);
  const longs = out.filter((x) => x.dir > 0).length, shorts = out.filter((x) => x.dir < 0).length;
  const res = (why, pick = null) => ({ size: pool.length, signals: out, pick, longs, shorts, why });
  if (!out.length) return res('no_signal');
  if (longs && shorts) return res('conflict');
  const p = out[0];
  return res('ok', { ...p, rec: { n: p.cfg.n, winRate: p.cfg.win, avgR: p.cfg.avg, maxRun: p.cfg.run } });
}

/** Market plan for a book signal: entry at the live price (or the last close), stop = stopAtr × ATR, targets in R. */
export function bookPlan(sig, cs, { price = null, costPct = 0 } = {}) {
  const I = indicators(cs); const a = I.atr(14)[I.n - 1]; if (!(a > 0)) return null;
  // v398 exactly as tested: stop = sa × ATR, one target = tp × risk. Market = the signal close (or the live price while it is still
  // within 0.25 × ATR or better); limit = lk × ATR better than the signal close, valid 5 candles.
  const c = sig.cfg || { sa: 2, tp: 1, order: 'market', lk: 0 };
  const close = I.c[I.n - 1]; const live = Number.isFinite(price) && price > 0 ? price : null; const sg = sig.dir;
  let order = c.order === 'limit' ? 'limit' : 'market';
  let entry = order === 'limit' ? close - sg * (c.lk || 0.5) * a : close;
  if (order === 'market' && live != null) { if (Math.abs(live - close) <= 0.25 * a || (sg > 0 ? live < close : live > close)) entry = live; else { order = 'limit'; entry = close; } }
  const risk = c.sa * a; const stop = entry - sg * risk; const targets = [entry + sg * c.tp * risk];
  const costR = ((entry * costPct) / 100) / risk; const rr = [Math.round(c.tp * 100) / 100];
  const wr = sig.rec.winRate; const q = Math.max(5, Math.min(95, Math.round(40 + (sig.rec.avgR || 0) * 60 + (wr - 0.5) * 40)));
  return { order, livePrice: live, direction: sg > 0 ? 'long' : 'short', entry, stop, targets, rr, rrNet: rr.map((x) => Math.round((x - costR) * 100) / 100), rrMain: Math.round((rr[0] - costR) * 100) / 100, costR: Math.round(costR * 1000) / 1000, risk, stopAtr: c.sa, sources: ['TP'], quality: q, execution: order };
}
