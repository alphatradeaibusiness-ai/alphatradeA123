// Swing Pulse Pro (v346) — personal lot size for one recommendation. Pure and tested; computed on the SERVER for each user.
//
//   amount at risk = account basis (equity or balance) × AI risk % / 100
//   loss per lot   = (|entry − stop| / tick size) × tick value          (tick value is in the ACCOUNT currency)
//   lots           = amount at risk / loss per lot, rounded DOWN to the broker's volume step, inside min / max
//
// Contract data, in order of trust:
//   1. the broker's own symbol specification reported by the linked MetaTrader 5 terminal (tick size, tick value, contract size,
//      volume min / step / max) — exact for that account;
//   2. a market CONVENTION where one exists (forex 100 000 units, gold 100 oz, silver 5 000 oz, Bitcoin / Ether 1 coin), with
//      the quote-currency → account-currency rate from live prices — labelled "standard contract, check your broker";
//   3. nothing: indices, energies and anything else differ by broker → "cannot be calculated reliably" (never guessed).
const STANDARD = {
  forex: { contract: 100000 },
  XAUUSD: { contract: 100 }, XAGUSD: { contract: 5000 },
  BTCUSDT: { contract: 1, quote: 'USD' }, ETHUSDT: { contract: 1, quote: 'USD' },
};
const STEP = { min: 0.01, step: 0.01, max: 100 };
const r2 = (v) => Math.round(v * 100) / 100;

/** Broker symbol name → the platform symbol it trades (suffixes / prefixes ignored: "XAUUSD.m", "GOLD", "BTCUSD"). */
export function brokerMatch(name, symbol) {
  const raw = String(name || '').trim(); const up = raw.toUpperCase();
  const s = String(symbol || '').toUpperCase();
  const alias = { XAUUSD: ['XAUUSD', 'GOLD'], XAGUSD: ['XAGUSD', 'SILVER'], BTCUSDT: ['BTCUSD', 'BTCUSDT'], ETHUSDT: ['ETHUSD', 'ETHUSDT'], US100: ['US100', 'NAS100', 'USTEC', 'NDX100'], US30: ['US30', 'DJ30', 'WS30'], SPX500: ['SPX500', 'US500'], GER40: ['GER40', 'DE40', 'DAX40'] }[s] || [s];
  // exact, or the broker's suffix (".m", "-ECN", "+", lower-case "m" / "pro") or a short prefix ("#", "m.") — never another symbol
  return alias.some((a) => up === a || (up.startsWith(a) && /^([._\-+#!].{0,6}|[a-z]{1,4})$/.test(raw.slice(a.length))) || (up.endsWith(a) && /^[#._a-z]{1,2}$/.test(raw.slice(0, raw.length - a.length))));
}

/** The quote currency → account currency rate from live prices, or null when it is not known. */
export function quoteToAccount(quote, account, rates = {}) {
  const q = quote === 'USDT' ? 'USD' : quote; const a = account === 'USDT' ? 'USD' : account;
  if (!q || !a) return null;
  if (q === a) return 1;
  const direct = rates[`${q}${a}`]; if (direct > 0) return direct;
  const inverse = rates[`${a}${q}`]; if (inverse > 0) return 1 / inverse;
  // through USD
  const qUsd = q === 'USD' ? 1 : rates[`${q}USD`] > 0 ? rates[`${q}USD`] : rates[`USD${q}`] > 0 ? 1 / rates[`USD${q}`] : null;
  const usdA = a === 'USD' ? 1 : rates[`USD${a}`] > 0 ? rates[`USD${a}`] : rates[`${a}USD`] > 0 ? 1 / rates[`${a}USD`] : null;
  return qUsd && usdA ? qUsd * usdA : null;
}

/**
 * @param sig      { symbol, asset, entry, stop, riskPct }
 * @param account  { amount, currency, basis: 'equity'|'balance', source: 'mt5'|'manual' } or null
 * @param spec     broker spec { tickSize, tickValue, contractSize, volMin, volStep, volMax } or null
 * @param inst     platform instrument { quote, type }
 * @param rates    { EURUSD: 1.08, USDJPY: 151.2, … } live mid prices
 * → { ok: true, lots, riskAmount, riskActualPct, lossPerLot, currency, specSource, belowMin, warnings }
 *   or { ok: false, reason }
 */
export function lotFor(sig, account, spec, inst, rates = {}) {
  if (!account || !(account.amount > 0)) return { ok: false, reason: 'no_account' };
  if (!(sig?.riskPct > 0)) return { ok: false, reason: 'no_risk' };
  const dist = Math.abs(sig.entry - sig.stop);
  if (!(dist > 0)) return { ok: false, reason: 'bad_levels' };
  const ccy = String(account.currency || '').toUpperCase();
  const riskAmount = (account.amount * sig.riskPct) / 100;
  let lossPerLot = null; let vol = STEP; let specSource = null; const warnings = [];
  if (spec && spec.tickSize > 0 && spec.tickValue > 0) {
    lossPerLot = (dist / spec.tickSize) * spec.tickValue; specSource = 'broker';
    vol = { min: spec.volMin > 0 ? spec.volMin : STEP.min, step: spec.volStep > 0 ? spec.volStep : STEP.step, max: spec.volMax > 0 ? spec.volMax : STEP.max };
  } else {
    const std = STANDARD[sig.symbol] || (inst?.type === 'forex' ? STANDARD.forex : null);
    if (!std) return { ok: false, reason: 'no_contract_spec' };
    const rate = quoteToAccount(std.quote || inst?.quote, ccy, rates);
    if (!rate) return { ok: false, reason: 'no_conversion_rate' };
    lossPerLot = dist * std.contract * rate; specSource = 'standard'; warnings.push('standard_contract');
  }
  if (!(lossPerLot > 0)) return { ok: false, reason: 'no_contract_spec' };
  const raw = riskAmount / lossPerLot;
  const steps = Math.floor(raw / vol.step + 1e-9);
  let lots = Number((steps * vol.step).toFixed(6));
  let belowMin = false;
  if (lots < vol.min) { belowMin = true; lots = 0; warnings.push('below_min_lot'); }
  if (lots > vol.max) { lots = vol.max; warnings.push('max_lot'); }
  const actual = lots * lossPerLot;
  return {
    ok: true, lots, riskAmount: r2(riskAmount), riskActual: r2(actual), riskActualPct: r2((actual / account.amount) * 100),
    minLotRiskPct: r2(((vol.min * lossPerLot) / account.amount) * 100), lossPerLot: r2(lossPerLot), currency: ccy || null,
    basis: account.basis || 'equity', accountSource: account.source || null, specSource, belowMin, warnings,
  };
}
