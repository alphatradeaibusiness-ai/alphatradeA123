// v349 Gotriva Order Flow strategy — entries, stops and targets from candle order flow (aggressive buy vs sell volume),
// plus an honest back-test on real exchange history. Each candle needs { time, open, high, low, close, volume, buy } where
// `buy` is the volume bought by aggressive buyers (Binance klines give it as "taker buy volume"); sell = volume − buy.
// Three setups, judged only on CLOSED candles:
//   A  absorption at an extreme — a sweep of the 20-bar low (high) on ≥2× volume with heavy selling (buying), but the candle
//      closes in its upper (lower) half: big passive orders absorbed the aggression → reversal
//   B  delta divergence — a new 20-bar high (low) made with negative (positive) delta, a bearish (bullish) close and falling
//      (rising) cumulative delta over the last 5 bars → reversal
//   C  delta breakout — a close beyond the 20-bar high (low) with ≥30% one-sided delta, ≥1.5× volume, in the EMA-50 trend
// Trade: entry at the next candle's open, stop beyond the signal candle's extreme ± 0.25 ATR, half off at 1.5R (stop to
// entry), the rest at 3R, or closed after 24 candles. A fee is charged on every trade. Nothing is fitted to the test data.
import { ema, atr } from '../indicators/index.js';

export const OF_RULES = { look: 20, volX: 2, absDelta: 0.25, brkDelta: 0.3, brkVolX: 1.5, atrStop: 0.25, tp1: 1.5, tp2: 3, maxBars: 24, minRiskAtr: 0.3, maxRiskAtr: 3 };
export const SETUP_NAMES = { A: { ar: 'امتصاص عند القمة/القاع', en: 'Absorption at an extreme' }, B: { ar: 'تباعد الدلتا', en: 'Delta divergence' }, C: { ar: 'اختراق بتأكيد الدلتا', en: 'Delta-confirmed breakout' } };

const deltaOf = (c) => c.buy - (c.volume - c.buy);

/** Precompute what every bar needs once (EMA 50, ATR 14, delta, CVD). */
export function prepare(cs) {
  const closes = cs.map((c) => c.close);
  const e50 = ema(closes, 50); const a14 = atr(cs, 14);
  let cvd = 0; const cv = cs.map((c) => (cvd += deltaOf(c)));
  return { cs, e50, a14, cv };
}

/** The signal on CLOSED bar i (or null). → { side, setup, i, stop, why } — the entry is the next bar's open. */
export function signalAt(P, i, R = OF_RULES) {
  const { cs, e50, a14, cv } = P; const c = cs[i]; const L = R.look;
  if (i < Math.max(L, 50) || !c || !(c.volume > 0) || a14[i] == null || e50[i] == null) return null;
  const prev = cs.slice(i - L, i);
  const hi = Math.max(...prev.map((x) => x.high)); const lo = Math.min(...prev.map((x) => x.low));
  const avgVol = prev.reduce((t, x) => t + x.volume, 0) / L;
  const d = deltaOf(c); const rng = c.high - c.low || 1e-12; const pos = (c.close - c.low) / rng; const a = a14[i];
  const out = (side, setup, why) => {
    const stop = side === 'buy' ? c.low - R.atrStop * a : c.high + R.atrStop * a;
    return { side, setup, i, time: c.time, stop, why, ref: c.close };
  };
  // A — absorption at an extreme
  if (c.volume >= R.volX * avgVol) {
    if (c.low < lo && d <= -R.absDelta * c.volume && pos >= 0.5) return out('buy', 'A', { volX: c.volume / avgVol, deltaPct: d / c.volume });
    if (c.high > hi && d >= R.absDelta * c.volume && pos <= 0.5) return out('sell', 'A', { volX: c.volume / avgVol, deltaPct: d / c.volume });
  }
  // B — delta divergence at a new extreme, confirmed by the close and the cumulative-delta slope
  const cvdSlope = cv[i] - cv[i - 5];
  if (c.high > hi && d < 0 && c.close < c.open && cvdSlope < 0) return out('sell', 'B', { deltaPct: d / c.volume });
  if (c.low < lo && d > 0 && c.close > c.open && cvdSlope > 0) return out('buy', 'B', { deltaPct: d / c.volume });
  // C — breakout with the delta behind it, in the trend
  if (c.volume >= R.brkVolX * avgVol) {
    if (c.close > hi && d >= R.brkDelta * c.volume && c.close > e50[i]) return out('buy', 'C', { volX: c.volume / avgVol, deltaPct: d / c.volume });
    if (c.close < lo && d <= -R.brkDelta * c.volume && c.close < e50[i]) return out('sell', 'C', { volX: c.volume / avgVol, deltaPct: d / c.volume });
  }
  return null;
}

/** The full plan for a signal, given the entry price → { entry, stop, tp1, tp2, risk } or null when the stop is unusable. */
export function planFor(sig, entry, a, R = OF_RULES) {
  const long = sig.side === 'buy'; const risk = long ? entry - sig.stop : sig.stop - entry;
  if (!(risk > 0) || risk < R.minRiskAtr * a || risk > R.maxRiskAtr * a) return null;
  return { entry, stop: sig.stop, tp1: long ? entry + R.tp1 * risk : entry - R.tp1 * risk, tp2: long ? entry + R.tp2 * risk : entry - R.tp2 * risk, risk };
}

/**
 * Walk a trade forward from bar `from` (the entry bar). Conservative: when a bar touches both the stop and a target, the stop
 * counts first. → { exitIdx, r (before fees), outcome: 'tp2'|'tp1_be'|'tp1_time'|'sl'|'time', tp1 }
 */
export function simulate(cs, from, side, plan, R = OF_RULES) {
  const long = side === 'buy'; let stop = plan.stop; let half = false; let banked = 0;
  for (let j = from; j < cs.length && j < from + R.maxBars; j++) {
    const b = cs[j];
    const hitStop = long ? b.low <= stop : b.high >= stop;
    if (hitStop) return half ? { exitIdx: j, r: banked, outcome: 'tp1_be', tp1: true } : { exitIdx: j, r: -1, outcome: 'sl', tp1: false };
    if (!half && (long ? b.high >= plan.tp1 : b.low <= plan.tp1)) { half = true; banked = 0.5 * R.tp1; stop = plan.entry; }
    if (half && (long ? b.high >= plan.tp2 : b.low <= plan.tp2)) return { exitIdx: j, r: banked + 0.5 * R.tp2, outcome: 'tp2', tp1: true };
  }
  const j = Math.min(cs.length - 1, from + R.maxBars - 1); const px = cs[j].close;
  const open = (long ? px - plan.entry : plan.entry - px) / plan.risk;
  return half ? { exitIdx: j, r: banked + 0.5 * open, outcome: 'tp1_time', tp1: true } : { exitIdx: j, r: open, outcome: 'time', tp1: false };
}

/**
 * Back-test on real candles. One trade at a time (a new signal waits for the open one to finish). feePct = round-trip fee in
 * percent of the price (0.04 = Binance taker both sides, roughly). → { trades, stats: { all, A, B, C }, from, to, bars }
 */
export function backtest(cs, { feePct = 0.04, rules = OF_RULES } = {}) {
  const P = prepare(cs); const trades = []; let busyTill = -1;
  for (let i = 0; i < cs.length - 2; i++) {
    if (i <= busyTill) continue;
    const sig = signalAt(P, i, rules); if (!sig) continue;
    const entry = cs[i + 1].open; const plan = planFor(sig, entry, P.a14[i], rules); if (!plan) continue;
    const res = simulate(cs, i + 1, sig.side, plan, rules);
    const fee = (entry * feePct / 100) / plan.risk;
    trades.push({ setup: sig.setup, side: sig.side, time: cs[i + 1].time, entry, stop: plan.stop, tp1: plan.tp1, tp2: plan.tp2, outcome: res.outcome, r: +(res.r - fee).toFixed(3), fee: +fee.toFixed(3), bars: res.exitIdx - i });
    busyTill = res.exitIdx;
  }
  const stat = (list) => {
    if (!list.length) return { n: 0 };
    const wins = list.filter((t) => t.r > 0); const gross = wins.reduce((a, t) => a + t.r, 0); const loss = -list.filter((t) => t.r <= 0).reduce((a, t) => a + t.r, 0);
    let eq = 0; let peak = 0; let dd = 0; const curve = [];
    for (const t of list) { eq += t.r; peak = Math.max(peak, eq); dd = Math.max(dd, peak - eq); curve.push(+eq.toFixed(3)); }
    return { n: list.length, winRate: +(wins.length / list.length * 100).toFixed(1), tp1Rate: +(list.filter((t) => t.outcome !== 'sl' && t.outcome !== 'time').length / list.length * 100).toFixed(1), totalR: +eq.toFixed(2), avgR: +(eq / list.length).toFixed(3), pf: loss ? +(gross / loss).toFixed(2) : null, maxDD: +dd.toFixed(2), curve };
  };
  return { trades, stats: { all: stat(trades), A: stat(trades.filter((t) => t.setup === 'A')), B: stat(trades.filter((t) => t.setup === 'B')), C: stat(trades.filter((t) => t.setup === 'C')) }, from: cs[0]?.time, to: cs.at(-1)?.time, bars: cs.length, feePct };
}
