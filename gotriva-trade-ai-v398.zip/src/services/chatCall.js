// v354 Private-channel calls: voice / video / screen share between members, browser to browser (WebRTC, encrypted DTLS-SRTP).
// Every browser connects to every other one (mesh, up to 8). The server only passes the set-up messages (offer / answer / ICE)
// and the participant list; audio and video never go through it.
// Rule that avoids two offers crossing: of any two people, the one whose id sorts first makes the offer.
// Each connection always carries one audio and one video slot, so turning the camera on, flipping it or sharing the screen
// only swaps the track (replaceTrack) — no new negotiation, no freeze.
import { apiRequest } from './ai/gateway.js';

const VIDEO = { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30, max: 30 } };

export function createCall({ channelId, me, onChange = () => {}, onError = () => {} }) {
  const base = `/api/chat/${channelId}/call`;
  const peers = new Map();   // uid → { pc, stream, pendingIce: [], name, state }
  const st = { joined: false, mic: true, cam: false, screen: false, facing: 'user', rev: 0, call: null, ice: [], local: new MediaStream(), alive: true };
  let micTrack = null, camTrack = null, screenTrack = null; let loopGen = 0;

  const post = (body) => apiRequest('POST', base, body, 20000);
  const videoTrack = () => (st.screen && screenTrack) || (st.cam && camTrack) || null;
  const emit = () => { try { onChange(snapshot()); } catch { /* the view handles its own errors */ } };
  function snapshot() {
    return { joined: st.joined, mic: st.mic, cam: st.cam, screen: st.screen, facing: st.facing, call: st.call, local: st.local,
      peers: [...peers.entries()].map(([uid, p]) => ({ uid, name: p.name, stream: p.stream, state: p.pc?.connectionState || 'new', info: st.call?.peers.find((x) => x.uid === uid) || null })) };
  }
  function rebuildLocal() { st.local = new MediaStream([micTrack, videoTrack()].filter(Boolean)); }

  async function getMic() { if (micTrack) return micTrack; const s = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); micTrack = s.getAudioTracks()[0]; micTrack.enabled = st.mic; return micTrack; }
  async function getCam(facing = st.facing) { const s = await navigator.mediaDevices.getUserMedia({ video: { ...VIDEO, facingMode: { ideal: facing } } }); return s.getVideoTracks()[0]; }

  function senders(pc) { const out = { audio: null, video: null }; for (const t of pc.getTransceivers()) { const k = t.receiver.track?.kind; if (k && !out[k]) out[k] = t; } return out; }
  async function pushTracks() { for (const p of peers.values()) { if (!p.pc) continue; const tr = senders(p.pc); try { await tr.audio?.sender.replaceTrack(micTrack); await tr.video?.sender.replaceTrack(videoTrack()); } catch { /* the connection is closing */ } } }

  function makePc(uid, name) {
    const pc = new RTCPeerConnection({ iceServers: st.ice });
    const p = { pc, stream: new MediaStream(), pendingIce: [], name };
    pc.onicecandidate = (e) => { if (e.candidate) post({ action: 'signal', to: uid, data: { type: 'ice', candidate: e.candidate.toJSON() } }).catch(() => {}); };
    pc.ontrack = (e) => { if (!p.stream.getTracks().includes(e.track)) p.stream.addTrack(e.track); e.track.onunmute = emit; e.track.onmute = emit; emit(); };
    pc.onconnectionstatechange = () => {
      emit();
      if (pc.connectionState === 'failed' && me < uid) { setTimeout(() => { if (peers.get(uid)?.pc === pc) { close(uid); offerTo(uid, name); } }, 1500); }
    };
    peers.set(uid, p); return p;
  }
  function close(uid) { const p = peers.get(uid); if (!p) return; try { p.pc.close(); } catch { /* */ } peers.delete(uid); emit(); }

  async function offerTo(uid, name) {
    const p = makePc(uid, name);
    p.pc.addTransceiver(micTrack || 'audio', { direction: 'sendrecv' });
    const v = p.pc.addTransceiver('video', { direction: 'sendrecv' }); await v.sender.replaceTrack(videoTrack());
    const offer = await p.pc.createOffer(); await p.pc.setLocalDescription(offer);
    await post({ action: 'signal', to: uid, data: { type: 'offer', sdp: p.pc.localDescription.sdp } });
  }
  async function onSignal({ from, data }) {
    const name = st.call?.peers.find((x) => x.uid === from)?.name || '';
    if (data.type === 'offer') {
      if (peers.has(from)) close(from);
      const p = makePc(from, name);
      await p.pc.setRemoteDescription({ type: 'offer', sdp: data.sdp });
      const tr = senders(p.pc);
      for (const t of p.pc.getTransceivers()) t.direction = 'sendrecv';
      await tr.audio?.sender.replaceTrack(micTrack); await tr.video?.sender.replaceTrack(videoTrack());
      const ans = await p.pc.createAnswer(); await p.pc.setLocalDescription(ans);
      for (const c of p.pendingIce.splice(0)) await p.pc.addIceCandidate(c).catch(() => {});
      await post({ action: 'signal', to: from, data: { type: 'answer', sdp: p.pc.localDescription.sdp } });
    } else if (data.type === 'answer') {
      const p = peers.get(from); if (!p || p.pc.signalingState !== 'have-local-offer') return;
      await p.pc.setRemoteDescription({ type: 'answer', sdp: data.sdp });
      for (const c of p.pendingIce.splice(0)) await p.pc.addIceCandidate(c).catch(() => {});
    } else if (data.type === 'ice') {
      const p = peers.get(from); if (!p) return;
      if (p.pc.remoteDescription) await p.pc.addIceCandidate(data.candidate).catch(() => {}); else p.pendingIce.push(data.candidate);
    }
  }
  function apply(r) {
    if (r.iceServers) st.ice = r.iceServers;
    st.call = r.call; if (!r.call) { if (st.joined) leaveLocal(); emit(); return; }
    st.rev = r.call.rev;
    if (st.joined) {
      const ids = new Set(r.call.peers.map((x) => x.uid));
      for (const uid of [...peers.keys()]) if (!ids.has(uid)) close(uid);
      for (const x of r.call.peers) { if (x.uid === me || peers.has(x.uid)) continue; if (me < x.uid) offerTo(x.uid, x.name).catch((e) => onError(e)); }
      for (const [uid, p] of peers) p.name = r.call.peers.find((x) => x.uid === uid)?.name || p.name;
    }
    return Promise.all((r.signals || []).map((s) => onSignal(s).catch(() => {}))).then(emit);
  }
  async function loop() {
    const mine = ++loopGen;
    while (st.alive && mine === loopGen) {
      try { const r = await apiRequest('GET', `${base}?rev=${st.rev}&wait=1`, undefined, 25000); if (mine !== loopGen) return; await apply(r); if (!r.call && !st.joined) { await sleep(4000); } }
      catch (e) { if (e?.code === 'not_found') { st.alive = false; emit(); return; } await sleep(e?.code === 'timeout' ? 200 : 2500); }
    }
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let beat = null;

  async function join({ start = false, cam = false } = {}) {
    try { await getMic(); } catch { st.mic = false; onError(new Error('mic_denied')); }
    if (cam) { try { camTrack = await getCam(); st.cam = true; } catch { st.cam = false; onError(new Error('cam_denied')); } }
    rebuildLocal();
    const r = await post({ action: start ? 'start' : 'join', mic: st.mic, cam: st.cam });
    st.joined = true; await apply(r); emit();
    clearInterval(beat); beat = setInterval(() => { if (st.joined) post({ action: 'state', mic: st.mic, cam: st.cam, screen: st.screen }).catch(() => {}); }, 10_000);
    loop();
  }
  function leaveLocal() {
    st.joined = false; clearInterval(beat);
    for (const uid of [...peers.keys()]) close(uid);
    for (const t of [micTrack, camTrack, screenTrack]) t?.stop(); micTrack = camTrack = screenTrack = null; st.cam = st.screen = false; rebuildLocal();
  }
  async function leave({ end = false } = {}) { const was = st.joined; leaveLocal(); emit(); if (was || end) await post({ action: end ? 'end' : 'leave' }).catch(() => {}); }
  const sendState = () => post({ action: 'state', mic: st.mic, cam: st.cam, screen: st.screen }).catch(() => {});

  async function toggleMic() { if (!micTrack) { try { await getMic(); st.mic = true; await pushTracks(); } catch { onError(new Error('mic_denied')); return; } } else { st.mic = !st.mic; micTrack.enabled = st.mic; } rebuildLocal(); emit(); sendState(); }
  async function toggleCam() {
    if (st.cam) { camTrack?.stop(); camTrack = null; st.cam = false; }
    else { try { camTrack = await getCam(); st.cam = true; } catch { onError(new Error('cam_denied')); return; } }
    rebuildLocal(); await pushTracks(); emit(); sendState();
  }
  async function flip() {
    if (!st.cam) return; st.facing = st.facing === 'user' ? 'environment' : 'user';
    try { const t = await getCam(st.facing); camTrack?.stop(); camTrack = t; rebuildLocal(); await pushTracks(); emit(); } catch { onError(new Error('cam_denied')); }
  }
  const canShare = () => Boolean(navigator.mediaDevices?.getDisplayMedia);
  async function toggleScreen() {
    if (st.screen) { screenTrack?.stop(); screenTrack = null; st.screen = false; }
    else {
      try { const s = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: { ideal: 15, max: 30 } }, audio: false }); screenTrack = s.getVideoTracks()[0]; st.screen = true;
        screenTrack.onended = () => { if (st.screen) toggleScreen(); };
      } catch { return; }
    }
    rebuildLocal(); await pushTracks(); emit(); sendState();
  }
  const say = (text) => post({ action: 'say', text });

  /** Watches the channel's call (banner) without joining. */
  function watch() { st.alive = true; loop(); }
  function destroy() { st.alive = false; loopGen++; if (st.joined) leave(); }
  return { join, leave, toggleMic, toggleCam, flip, toggleScreen, canShare, say, watch, destroy, snapshot };
}
