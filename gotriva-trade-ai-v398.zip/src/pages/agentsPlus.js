// v389 Gotriva Agents — trading aids under an agent's record:
//   • the open trade (only for members the channel itself shows levels to): progress between stop and target, a warning when
//     a high-impact news event is due for its currencies, the lot size for the member's own balance and risk (the tested
//     swingLot.lotFor: standard contracts only, never guessed for indices), «copy to MT5» (the existing confirmed bridge
//     order) and «I took it» (→ the journal once the agent closes the trade, result from the real close);
//   • «what if»: the agent's really-closed trades in the chosen range, each sized at the same % risk from its own stop.
// Display only: nothing here changes how any channel picks or manages trades.
import { esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { storage } from '../utils/storage.js';
import { findInstrument } from '../config/instruments.js';
import { lotFor } from '../services/swingLot.js';
import { getCalendar, currenciesOf } from '../services/news.js';
import { applySignal, wasApplied } from '../services/mt5Apply.js';
import { toast } from '../components/ui.js';
import { apiRequest } from '../services/ai/gateway.js';

const AR = () => getLang() === 'ar';
const L = (ar, en) => (AR() ? ar : en);
const num = (v, d = 2) => Number(v).toLocaleString('en-US', { maximumFractionDigits: d });
const acct = () => { const a = storage.get('ag-acct', null) || {}; return { amount: Number(a.amount) > 0 ? Number(a.amount) : 1000, risk: Number(a.risk) > 0 && Number(a.risk) <= 10 ? Number(a.risk) : 1 }; };
const TAKEN = 'ag-taken'; const taken = () => { const t = storage.get(TAKEN, {}); return t && typeof t === 'object' ? t : {}; };

export { currenciesOf };
/** High-impact events for these currencies from 5 minutes ago to `ahead` from now. */
export function newsSoon(events, sym, now = Date.now(), ahead = 60 * 60_000) {
  const cs = currenciesOf(sym);
  return (events || []).filter((e) => e.impact === 'High' && (cs.includes(e.country) || e.country === 'ALL') && e.time >= now - 5 * 60_000 && e.time <= now + ahead);
}
/** «What if»: compounding the same % risk over trades given as R multiples (oldest first). */
export function whatIf(trades, start, riskPct) {
  let eq = start, peak = start, dd = 0, wins = 0; const curve = [start];
  for (const t of trades) { eq = Math.max(0, eq * (1 + (riskPct / 100) * t.r)); curve.push(eq); peak = Math.max(peak, eq); dd = Math.max(dd, peak > 0 ? (peak - eq) / peak : 0); if (t.r > 0) wins++; }
  return { end: eq, n: trades.length, maxDD: dd * 100, winRate: trades.length ? (wins / trades.length) * 100 : null, curve };
}

function tradeHtml(t) {
  const long = t.dir === 'long'; const tgt = (t.targets || []).filter(Number.isFinite);
  const span = (t.slPips || 0) + (t.tpPips || 0); const now = Number.isFinite(t.pipsNow) ? t.pipsNow : 0;
  const pos = span > 0 ? Math.max(0, Math.min(100, ((now + t.slPips) / span) * 100)) : 50; const red = span > 0 ? (t.slPips / span) * 100 : 50;
  return `<section class="ag-panel agp-trade" data-trade="${esc(t.id)}">
    <div class="agp-top"><b dir="ltr">${esc(t.sym)}</b><span class="agp-side ${long ? 'is-buy' : 'is-sell'}">${esc(long ? L('شراء', 'Buy') : L('بيع', 'Sell'))}</span></div>
    <dl class="agp-lv" dir="ltr"><div><dt>ENTRY</dt><dd>${num(t.entry, 5)}</dd></div><div><dt>SL</dt><dd class="dn">${num(t.stop, 5)}</dd></div><div><dt>TP</dt><dd class="up">${tgt.length ? num(tgt.at(-1), 5) : '—'}</dd></div></dl>
    ${t.slPips && t.tpPips ? `<div class="agp-prog" dir="ltr" role="img" aria-label="${esc(L(`الصفقة هلّق ${now} بيبس`, `Trade now ${now} pips`))}" style="--red:${red.toFixed(1)}%"><i style="left:${pos.toFixed(1)}%"></i></div>
    <div class="agp-plab" dir="ltr"><span>SL −${num(t.slPips, 1)}</span><span>${esc(L('هلّق', 'now'))} ${now > 0 ? '+' : ''}${num(now, 1)}</span><span>TP +${num(t.tpPips, 1)}</span></div>` : ''}
    <div data-news></div><div class="agp-lot" data-lot></div>
    <div class="agp-btns"><button type="button" class="agp-b1" data-mt5>${esc(wasApplied(t.id) ? L('انبعتت لـ MT5 ✓', 'Sent to MT5 ✓') : L('انسخ لـ MT5', 'Copy to MT5'))}</button><button type="button" class="agp-b2" data-took aria-pressed="${Boolean(taken()[t.id])}">${esc(taken()[t.id] ? L('✓ مسجّلة إنك أخدتها', '✓ Marked as taken') : L('أخدت الصفقة', 'I took it'))}</button></div>
    <p class="agp-note">${esc(L('«أخدت الصفقة» بتنحفظ بسجل التداول لما الوكيل يسكّرها، بنتيجتها الحقيقية. تحليل، مش نصيحة مالية.', '«I took it» goes to your journal when the agent closes it, with the real result. Analysis, not financial advice.'))}</p></section>`;
}

function lotHtml(t) {
  const a = acct(); const r = lotFor({ symbol: t.sym, entry: t.entry, stop: t.stop, riskPct: a.risk }, { amount: a.amount, currency: 'USD' }, null, findInstrument(t.sym), {});
  const why = { no_contract_spec: L('حجم العقد لهالسوق بيختلف حسب البروكر، فما بنحسبه تخمين. شوف حجم العقد عند البروكر أو اربط MT5.', 'Contract size for this market differs by broker, so we do not guess. Check your broker or link MT5.'), no_conversion_rate: L('ما عنا سعر تحويل لعملة هالزوج هلّق.', 'No conversion rate for this pair right now.'), bad_levels: L('مستويات الصفقة ناقصة.', 'Trade levels are missing.') };
  return `<div class="agp-row"><label>${esc(L('رصيدك $', 'Balance $'))}<input data-acct="amount" inputmode="decimal" dir="ltr" value="${a.amount}"></label><label>${esc(L('مخاطرة %', 'Risk %'))}<input data-acct="risk" inputmode="decimal" dir="ltr" value="${a.risk}"></label></div>
    ${r.ok ? `<div class="agp-r"><span>${esc(L('حجم اللوت المقترح', 'Suggested lot'))}</span><b dir="ltr">${r.belowMin ? '—' : `${r.lots} lot`}</b></div>
      <div class="agp-r"><span>${esc(L('المبلغ بخطر', 'Amount at risk'))}</span><b dir="ltr">$${num(r.riskActual)} (${num(r.riskActualPct)}%)</b></div>
      <p class="agp-note">${esc(r.belowMin ? L(`أصغر لوت (0.01) بيخاطر ${num(r.minLotRiskPct)}% من رصيدك، أكتر من اللي اخترته.`, `The smallest lot (0.01) risks ${num(r.minLotRiskPct)}% of your balance, more than you chose.`) : L('محسوب على عقد قياسي. تأكد من مواصفات البروكر.', 'Based on a standard contract. Check your broker’s specs.'))}</p>`
      : `<p class="agp-note">${esc(why[r.reason] || L('ما بنقدر نحسبه هلّق.', 'Cannot be calculated right now.'))}</p>`}`;
}

function whatIfHtml(d, st) {
  const tr = [...(d?.whatif?.trades || [])].sort((a, b) => a.t - b.t); const w = whatIf(tr, st.start, st.risk);
  const W = 300, H = 110; const lo = Math.min(...w.curve), hi = Math.max(...w.curve), sp = hi - lo || 1;
  const pts = w.curve.map((v, i) => `${((i / Math.max(1, w.curve.length - 1)) * W).toFixed(1)} ${(H - 6 - ((v - lo) / sp) * (H - 12)).toFixed(1)}`);
  return `<section class="ag-panel agp-wi"><h2 class="ag-h2">${esc(L('لو مشيت ورا هالوكيل', 'If you had followed this agent'))}</h2>
    <p class="ag-muted">${esc(L('من الصفقات المسكّرة فعليًا بالفترة اللي فوق، كل صفقة بنفس نسبة المخاطرة من الستوب تبعها.', 'From the really-closed trades in the range above, each sized at the same % risk from its own stop.'))}</p>
    <div class="agp-row"><label>${esc(L('رصيد البداية $', 'Start $'))}<input data-wi="start" inputmode="decimal" dir="ltr" value="${st.start}"></label><label>${esc(L('مخاطرة كل صفقة %', 'Risk per trade %'))}<input data-wi="risk" inputmode="decimal" dir="ltr" value="${st.risk}"></label></div>
    ${w.n ? `<svg class="agp-curve" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true"><path d="M${pts.join(' L')} L${W} ${H} L0 ${H}Z" class="agp-fill"/><path d="M${pts.join(' L')}" class="agp-line"/></svg>
      <dl class="agp-stats"><div><dt>${esc(L('كان صار رصيدك', 'Would be'))}</dt><dd dir="ltr">$${num(w.end)}</dd></div><div><dt>${esc(L('صفقات', 'Trades'))}</dt><dd dir="ltr">${w.n}</dd></div><div><dt>${esc(L('أكبر تراجع', 'Max drawdown'))}</dt><dd dir="ltr">−${num(w.maxDD, 1)}%</dd></div><div><dt>${esc(L('نسبة الربح', 'Win rate'))}</dt><dd dir="ltr">${num(w.winRate, 0)}%</dd></div></dl>`
      : `<p class="ag-muted">${esc(L('ما في صفقات مسكّرة بستوب معروف بهالفترة لسا.', 'No closed trades with a known stop in this range yet.'))}</p>`}
    ${d?.whatif?.skipped ? `<p class="agp-note">${esc(L(`${d.whatif.skipped} صفقة قديمة ما انحسبت لأنه الستوب تبعها مش مسجّل.`, `${d.whatif.skipped} older trades not counted: their stop was not recorded.`))}</p>` : ''}
    <p class="agp-warn">${esc(L('نتيجة ماضية بدون رسوم وسبريد وانزلاق. مش وعد بأي ربح، والتداول فيه خطر خسارة.', 'Past result without fees, spread or slippage. Not a promise of profit; trading carries risk of loss.'))}</p></section>`;
}

/** Records «I took it» trades the agent has since closed into the journal (once each, real result). */
function syncTaken(d) {
  const t = taken(); const ids = Object.keys(t); if (!ids.length || !d?.recent) return;
  const journal = storage.get('journal', []) || []; let n = 0;
  for (const r of d.recent) {
    const x = t[r.id]; if (!x || !(r.rp > 0) || journal.some((j) => j.agentId === r.id)) continue;
    const R = r.pips / r.rp; const dir = r.dir === 'long' ? 1 : -1; const risk = Math.abs(x.entry - x.stop);
    journal.unshift({ id: `j_${r.id}`, agentId: r.id, tf: r.tf, openedAt: x.at, symbol: r.sym, direction: r.dir, entry: x.entry, exit: x.entry + dir * R * risk, stop: x.stop, qty: x.lot || 1, fees: 0, r: Math.round(R * 100) / 100, strategy: `agent:${d.id}`, notes: L(`من ${d.id} عبر Gotriva Agents`, `From ${d.id} via Gotriva Agents`), closedAt: r.closedAt, source: 'agent' });
    delete t[r.id]; n++;
  }
  if (n) { journal.sort((a, b) => b.closedAt - a.closedAt); storage.set('journal', journal); storage.set(TAKEN, t); toast(L(`انضافت ${n} صفقة لسجل التداول.`, `${n} trade(s) added to your journal.`), 'success'); }
}

/** Mounts the aids into `host` for agent detail `d`. */
export function mountAgentPlus(host, d, wiState) {
  if (!host || !d) return; syncTaken(d);
  const live = (d.live || []).filter((t) => Number.isFinite(t.entry) && Number.isFinite(t.stop));
  host.innerHTML = live.map(tradeHtml).join('') + whatIfHtml(d, wiState);
  for (const t of live) {
    const card = host.querySelector(`[data-trade="${CSS.escape(t.id)}"]`); const lotBox = card.querySelector('[data-lot]');
    const paintLot = () => { lotBox.innerHTML = lotHtml(t); lotBox.querySelectorAll('[data-acct]').forEach((i) => i.addEventListener('change', () => { const a = acct(); a[i.dataset.acct] = Number(String(i.value).replace(/[^0-9.]/g, '')); storage.set('ag-acct', a); paintLot(); })); };
    paintLot();
    getCalendar().then(({ events }) => { const soon = newsSoon(events, t.sym); if (!soon.length) return; const e = soon[0]; const m = Math.round((e.time - Date.now()) / 60000);
      const iso = (x) => `\u2068${x}\u2069`; card.querySelector('[data-news]').innerHTML = `<p class="agp-news" role="note"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l10 18H2zM12 10v5M12 18v.5"/></svg>${esc(m > 0 ? L(`خبر قوي بعد ${m} دقيقة: ${iso(`${e.title} (${e.country})`)}. السعر ممكن يتحرّك بقوة.`, `High-impact news in ${m} min: ${e.title} (${e.country}). Price may move sharply.`) : L(`خبر قوي هلّق: ${iso(`${e.title} (${e.country})`)}.`, `High-impact news now: ${e.title} (${e.country}).`))}</p>`; }).catch(() => {});
    card.querySelector('[data-mt5]').addEventListener('click', async (e) => {
      const b = e.currentTarget; if (wasApplied(t.id)) return; const a = acct();
      const r = lotFor({ symbol: t.sym, entry: t.entry, stop: t.stop, riskPct: a.risk }, { amount: a.amount, currency: 'USD' }, null, findInstrument(t.sym), {});
      b.disabled = true;
      try { await applySignal({ id: t.id, symbol: t.sym, direction: t.dir, stop: t.stop, targets: t.targets, status: 'active', strategy: d.id }, { lot: r.ok && !r.belowMin ? r.lots : null }); b.textContent = L('انبعتت لـ MT5 ✓', 'Sent to MT5 ✓'); toast(L('انبعتت للـ MT5 تبعك.', 'Sent to your MT5.'), 'success'); }
      catch (x) { b.disabled = false; toast({ no_link: L('اربط MT5 أول من صفحة MT5.', 'Link MT5 first from the MT5 page.'), terminal_offline: L('الـ MT5 تبعك مش متصل هلّق.', 'Your MT5 is offline.'), trading_disabled: L('التداول مسكّر بإعدادات الـ EA.', 'Trading is off in the EA settings.'), already_applied: L('انبعتت قبل.', 'Already sent.') }[x?.code] || L('ما زبط الإرسال.', 'Could not send.'), 'error'); }
    });
    card.querySelector('[data-took]').addEventListener('click', (e) => {
      const b = e.currentTarget; const all = taken(); const a = acct(); const r = lotFor({ symbol: t.sym, entry: t.entry, stop: t.stop, riskPct: a.risk }, { amount: a.amount, currency: 'USD' }, null, findInstrument(t.sym), {});
      if (all[t.id]) delete all[t.id]; else all[t.id] = { at: Date.now(), entry: t.entry, stop: t.stop, lot: r.ok && !r.belowMin ? r.lots : null };
      storage.set(TAKEN, all); b.setAttribute('aria-pressed', String(Boolean(all[t.id]))); b.textContent = all[t.id] ? L('✓ مسجّلة إنك أخدتها', '✓ Marked as taken') : L('أخدت الصفقة', 'I took it');
    });
  }
  host.querySelectorAll('[data-wi]').forEach((i) => i.addEventListener('change', () => { const v = Number(String(i.value).replace(/[^0-9.]/g, '')); if (v > 0) { wiState[i.dataset.wi] = i.dataset.wi === 'risk' ? Math.min(10, v) : v; mountAgentPlus(host, d, wiState); } }));
}

/* ───────── v391 hub: ranking, favourites, 7-day trial, weekly e-mail ───────── */
const FAV = 'ag-favs';
export const favs = () => { const f = storage.get(FAV, []); return Array.isArray(f) ? f : []; };
export function toggleFav(id) { const f = new Set(favs()); if (f.has(id)) f.delete(id); else f.add(id); storage.set(FAV, [...f]); return f.has(id); }
/** Agents ordered by their last-30-day pips (only those with closed trades), best first. */
export function rankAgents(agents) { return (agents || []).filter((a) => a.m30?.signals > 0).sort((a, b) => b.m30.totalPips - a.m30.totalPips); }

export function hubExtrasHtml(d, { N }) {
  if (!d) return '';
  const sgn = (v) => `${v > 0 ? '+' : v < 0 ? '−' : ''}${num(Math.abs(v), 1)}`;
  const rk = rankAgents(d.agents); const tr = d.trial;
  const trial = tr?.active ? `<section class="ag-panel agp-trial"><b>${esc(L('تجربتك المجانية شغّالة', 'Your free trial is on'))}</b><p class="ag-muted">${esc(L(`Swing Pulse Pro وقناة التوصيات مفتوحين إلك لحد ${new Date(tr.until).toLocaleDateString('ar', { day: 'numeric', month: 'long', numberingSystem: 'latn' })}.`, `Swing Pulse Pro and the recommendation channel are open until ${new Date(tr.until).toLocaleDateString('en', { day: 'numeric', month: 'long' })}.`))}</p></section>`
    : tr?.eligible ? `<section class="ag-panel agp-trial"><b>${esc(L('جرّب Swing Pulse Pro وقناة التوصيات 7 أيام', 'Try Swing Pulse Pro and the recommendation channel for 7 days'))}</b>
      <p class="ag-muted">${esc(L('مجانًا، بدون بطاقة، مرة وحدة لكل حساب. الإشارات والتنبيهات (لحد 10 توصيات)، وبعدها بتقرر.', 'Free, no card, once per account. Signals and alerts (up to 10 recommendations), then you decide.'))}</p>
      <button type="button" class="agp-b1 agp-wide" data-trial>${esc(L('ابدأ التجربة', 'Start the trial'))}</button></section>` : '';
  const rank = `<section class="ag-panel agp-rank"><h2 class="ag-h2">${esc(L('ترتيب الوكلاء · آخر 30 يوم', 'Agent ranking · last 30 days'))}</h2>
    ${rk.length ? `<ol>${rk.map((a, i) => `<li><span class="agp-n">${i + 1}</span><span class="agp-rn"><b>${esc(N(a.id))}</b><small>${esc(L(`${a.m30.signals} صفقة · ربح \u2068${a.m30.winRate ?? 0}%\u2069 · أكبر تراجع \u2068${num(a.m30.maxDD, 1)} pips\u2069`, `${a.m30.signals} trades · ${a.m30.winRate ?? 0}% wins · max drawdown ${num(a.m30.maxDD, 1)} pips`))}</small></span><b class="${a.m30.totalPips > 0 ? 'is-up' : a.m30.totalPips < 0 ? 'is-down' : ''}" dir="ltr">${sgn(a.m30.totalPips)}</b></li>`).join('')}</ol>`
      : `<p class="ag-muted">${esc(L('ما في صفقات مسكّرة بآخر 30 يوم لسا.', 'No closed trades in the last 30 days yet.'))}</p>`}
    <p class="agp-note">${esc(L('مرتّبين حسب البيبس من الصفقات المسكّرة فعليًا. نتيجة ماضية مش وعد.', 'Ranked by pips from really-closed trades. Past results, not a promise.'))}</p></section>`;
  const weekly = `<section class="ag-panel agp-weekly"><div><b>${esc(L('ملخص أسبوعي على الإيميل', 'Weekly e-mail summary'))}</b><small>${esc(L('كل أحد الصبح: نتيجة كل وكيل بآخر 7 أيام.', 'Every Sunday morning: each agent’s last 7 days.'))}</small></div>
    <button type="button" class="ag-switch" role="switch" aria-checked="${Boolean(d.weekly)}" aria-label="${esc(L('ملخص أسبوعي', 'Weekly summary'))}" data-weekly><span></span></button></section>`;
  return `<div class="agp agp-hub">${trial}${rank}${weekly}</div>`;
}
export function bindHubExtras(root, d, reload) {
  root.querySelector('[data-trial]')?.addEventListener('click', async (e) => {
    const b = e.currentTarget; b.disabled = true;
    try { await apiRequest('POST', '/api/agents/trial', {}, 15000); toast(L('بلّشت التجربة. Swing Pulse Pro وقناة التوصيات مفتوحين إلك 7 أيام.', 'Trial started: Swing Pulse Pro and the recommendation channel are open for 7 days.'), 'success', 7000); reload(); }
    catch (x) { b.disabled = false; toast(x?.code === 'trial_used' ? L('استعملت التجربة قبل.', 'You already used the trial.') : L('التجربة مش متاحة لحسابك (عندك اشتراك أو دفعت قبل).', 'The trial is not available for your account (you have or had a plan).'), 'error'); }
  });
  root.querySelector('[data-weekly]')?.addEventListener('click', async (e) => {
    const b = e.currentTarget; const on = b.getAttribute('aria-checked') !== 'true'; b.setAttribute('aria-checked', String(on));
    try { await apiRequest('PUT', '/api/agents/weekly', { on }, 10000); d.weekly = on; toast(on ? L('رح يوصلك ملخص كل أحد.', 'You will get a summary every Sunday.') : L('وقّفنا الملخص الأسبوعي.', 'Weekly summary off.'), 'success'); }
    catch { b.setAttribute('aria-checked', String(!on)); toast(L('ما زبط، جرّب كمان مرة.', 'Failed, try again.'), 'error'); }
  });
}

/* ───────── v391 agent page: drawdown and streaks, by session, by market (+ per-market alerts), share a closed trade ───────── */
export function detailExtrasHtml(d, id) {
  if (!d?.period) return '';
  const p = d.period; const SES = { TOKYO: L('طوكيو', 'Tokyo'), LONDON: L('لندن', 'London'), NY: L('نيويورك', 'New York'), SYDNEY: L('سيدني', 'Sydney') };
  const sgn = (v) => `${v > 0 ? '+' : v < 0 ? '−' : ''}${num(Math.abs(v), 1)}`; const tone = (v) => (v > 0 ? 'is-up' : v < 0 ? 'is-down' : '');
  const muted = new Set(d.symAlerts?.[id] || []); const off = Boolean(d.alerts?.[id]);
  const row = (k, label, x, sw) => `<li><span class="agp-rn"><b ${sw ? 'dir="ltr"' : ''}>${esc(label)}</b><small>${esc(L(`${x.signals} صفقة · ربح \u2068${x.winRate ?? 0}%\u2069`, `${x.signals} trades · ${x.winRate ?? 0}% wins`))}</small></span><b class="${tone(x.totalPips)}" dir="ltr">${sgn(x.totalPips)}</b>${sw && id !== 'elite' ? `<button type="button" class="ag-switch agp-sm" role="switch" aria-checked="${!muted.has(k) && !off}" ${off ? 'disabled' : ''} aria-label="${esc(L(`تنبيهات ${k}`, `${k} alerts`))}" data-symalert="${esc(k)}"><span></span></button>` : ''}</li>`;
  const ns = p.nowStreak || 0;
  return `<div class="agp agp-stats2">
    <section class="ag-panel"><h2 class="ag-h2">${esc(L('المخاطرة بالفترة', 'Risk in this range'))}</h2>
      <dl class="agp-stats"><div><dt>${esc(L('أكبر تراجع', 'Max drawdown'))}</dt><dd dir="ltr">${p.signals ? `−${num(p.maxDD || 0, 1)}` : '—'} <small>pips</small></dd></div><div><dt>${esc(L('أطول خسارات ورا بعض', 'Longest losing run'))}</dt><dd dir="ltr">${p.worstLossStreak ?? 0}</dd></div>
        <div><dt>${esc(L('أطول ربح ورا بعض', 'Longest winning run'))}</dt><dd dir="ltr">${p.bestStreak ?? 0}</dd></div><div><dt>${esc(L('هلّق', 'Right now'))}</dt><dd>${esc(ns > 0 ? L(`${ns} ربح ورا بعض`, `${ns} wins in a row`) : ns < 0 ? L(`${-ns} خسارة ورا بعض`, `${-ns} losses in a row`) : '—')}</dd></div></dl></section>
    <section class="ag-panel"><h2 class="ag-h2">${esc(L('حسب الجلسة', 'By session'))}</h2>${d.bySession?.length ? `<ul class="agp-list">${d.bySession.map((x) => row(x.k, SES[x.k] || x.k, x, false)).join('')}</ul>` : `<p class="ag-muted">${esc(L('ما في صفقات بهالفترة.', 'No trades in this range.'))}</p>`}
      <p class="agp-note">${esc(L('الجلسة حسب ساعة إغلاق الصفقة (UTC).', 'Session by the hour the trade closed (UTC).'))}</p></section>
    <section class="ag-panel"><h2 class="ag-h2">${esc(L('حسب السوق', 'By market'))}</h2>${d.bySymbol?.length ? `<ul class="agp-list">${d.bySymbol.map((x) => row(x.k, x.k, x, true)).join('')}</ul>` : `<p class="ag-muted">${esc(L('ما في صفقات بهالفترة.', 'No trades in this range.'))}</p>`}
      ${id !== 'elite' && d.bySymbol?.length ? `<p class="agp-note">${esc(off ? L('تنبيهات هالوكيل كلها مطفية من فوق.', 'All of this agent’s alerts are off (above).') : L('طفّي تنبيهات سوق معيّن وخلّي الباقي شغّال.', 'Turn off one market’s alerts and keep the rest.'))}</p>` : ''}</section></div>`;
}
export function bindDetailExtras(root, d, id) {
  root.querySelectorAll('[data-symalert]').forEach((b) => b.addEventListener('click', async () => {
    const on = b.getAttribute('aria-checked') !== 'true'; b.setAttribute('aria-checked', String(on));
    try { const r = await apiRequest('PUT', '/api/agents/alerts', { id, symbol: b.dataset.symalert, on }, 10000); d.symAlerts = r.symAlerts || d.symAlerts; }
    catch { b.setAttribute('aria-checked', String(!on)); toast(L('ما زبط، جرّب كمان مرة.', 'Failed, try again.'), 'error'); }
  }));
}

/** v391 a picture of one closed trade (real record) to share or save: brand, agent, market, side, result, date. */
export async function shareTrade(r, agentName) {
  const S = 1080; const c = document.createElement('canvas'); c.width = S; c.height = S; const x = c.getContext('2d'); const ar = AR();
  const g = x.createRadialGradient(200, 120, 40, 540, 540, 900); g.addColorStop(0, '#12382A'); g.addColorStop(1, '#06120D'); x.fillStyle = g; x.fillRect(0, 0, S, S);
  x.textAlign = 'center'; x.direction = ar ? 'rtl' : 'ltr';
  x.fillStyle = '#6EE7B7'; x.font = '700 38px system-ui, sans-serif'; x.fillText('GOTRIVA AGENTS', S / 2, 120);
  x.fillStyle = '#CFE7DA'; x.font = '600 42px system-ui, sans-serif'; x.fillText(agentName, S / 2, 200);
  x.fillStyle = '#FFFFFF'; x.font = '800 92px system-ui, sans-serif'; x.direction = 'ltr'; x.fillText(r.sym, S / 2, 360);
  x.direction = ar ? 'rtl' : 'ltr'; x.fillStyle = r.dir === 'long' ? '#34D27B' : '#FF5C6C'; x.font = '700 48px system-ui, sans-serif'; x.fillText(r.dir === 'long' ? L('شراء', 'Buy') : L('بيع', 'Sell'), S / 2, 440);
  x.direction = 'ltr'; x.fillStyle = r.pips > 0 ? '#34D27B' : r.pips < 0 ? '#FF5C6C' : '#FFFFFF'; x.font = '900 150px system-ui, sans-serif'; x.fillText(`${r.pips > 0 ? '+' : r.pips < 0 ? '−' : ''}${num(Math.abs(r.pips), 1)}`, S / 2, 640);
  x.fillStyle = '#9FB8AA'; x.font = '600 44px system-ui, sans-serif'; x.fillText('pips', S / 2, 705);
  x.direction = ar ? 'rtl' : 'ltr'; x.fillStyle = '#CFE7DA'; x.font = '500 38px system-ui, sans-serif';
  const OUTS = { tp: L('وصل الهدف', 'Target hit'), sl: L('ضرب الستوب', 'Stopped out'), be: L('سكّر على الدخول', 'Closed at entry'), time: L('سكّر بالوقت', 'Closed on time') };
  x.fillText(`${OUTS[r.out] || ''} · ${new Date(r.closedAt).toLocaleDateString(ar ? 'ar' : 'en', { day: 'numeric', month: 'short', year: 'numeric', numberingSystem: 'latn' })}`, S / 2, 800);
  x.fillStyle = '#7F978A'; x.font = '400 30px system-ui, sans-serif'; x.fillText(L('صفقة مسكّرة من سجل الوكيل. نتيجة ماضية، مش نصيحة مالية.', 'A closed trade from the agent’s record. Past result, not financial advice.'), S / 2, 980);
  const blob = await new Promise((res) => c.toBlob(res, 'image/png')); if (!blob) return;
  const file = new File([blob], `gotriva-${r.sym}-${new Date(r.closedAt).toISOString().slice(0, 10)}.png`, { type: 'image/png' });
  try { if (navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], title: 'GOTRIVA AGENTS' }); return; } } catch (e) { if (e?.name === 'AbortError') return; }
  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = file.name; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 30_000);
}
