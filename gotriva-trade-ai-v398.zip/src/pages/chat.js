// v353–v354 Private channels (القنوات الخاصة): channel list + conversation in real time (long polling), text, photos and
// videos (in-app camera, the phone's own camera app, or the gallery), a colour per channel chosen by its admins, calls with
// camera / screen share / an in-call chat each person can show or hide, and approved-moderator management for the owners.
// Security lives on the server (server/chatChannels.js); this page only shows what the server returns, always as text.
import { h, esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { apiRequest, apiBlobUrl, apiUpload, apiBuffer } from '../services/ai/gateway.js';
import { deviceKey, chatKey, sealText, openText, sealBlob, openBlob, fingerprint } from '../services/chatCrypto.js';
import { auth } from '../services/auth/index.js';
import { toast } from '../components/ui.js';
import { onUnmount } from './tools/common.js';
import { createCall } from '../services/chatCall.js';
import '../styles/chat.css';
import '../styles/chat357.css';

const LIST_POLL = 20_000;
export const CHANNEL_COLORS = ['#14b8a6', '#22d3ee', '#8b5cf6', '#0f0f14', '#e11d48', '#f59e0b', '#10b981', '#3b82f6', '#ec4899'];

/** Shrinks a picked image in the browser (also drops camera location data) → JPEG Blob or data URL. */
export function shrinkImage(file, max = 1600, quality = 0.85, square = false, asBlob = false) {
  return new Promise((resolve, reject) => {
    if (!/^image\/(png|jpe?g|webp|gif|heic|heif)$/i.test(file.type || 'image/jpeg')) return reject(new Error('bad_image'));
    if (file.size > 40 * 1024 * 1024) return reject(new Error('image_too_large'));
    const url = URL.createObjectURL(file); const img = new Image();
    img.onload = () => {
      let { width: w, height: hh } = img; let sx = 0, sy = 0, sw = w, sh = hh;
      if (square) { const s = Math.min(w, hh); sx = (w - s) / 2; sy = (hh - s) / 2; sw = sh = s; w = hh = Math.min(s, max); }
      else { const k = Math.min(1, max / Math.max(w, hh)); w = Math.round(w * k); hh = Math.round(hh * k); }
      const cv = document.createElement('canvas'); cv.width = w; cv.height = hh;
      const cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, w, hh); cx.drawImage(img, sx, sy, sw, sh, 0, 0, w, hh);
      URL.revokeObjectURL(url);
      if (asBlob) cv.toBlob((b) => (b ? resolve(b) : reject(new Error('bad_image'))), 'image/jpeg', quality); else resolve(cv.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('bad_image')); };
    img.src = url;
  });
}
/** A sticker: up to 512 px, transparency kept (WebP, PNG if WebP can't be made). */
export function stickerBlob(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file); const img = new Image();
    img.onload = () => { const k = Math.min(1, 512 / Math.max(img.width, img.height)); const cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k); cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height); URL.revokeObjectURL(url);
      cv.toBlob((b) => (b && b.type === 'image/webp' ? resolve(b) : cv.toBlob((b2) => (b2 ? resolve(b2) : reject(new Error('bad_image'))), 'image/png')), 'image/webp', 0.9); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('bad_image')); }; img.src = url;
  });
}
/** Readable text on a channel colour (dark text on light colours). */
export function inkOn(hex) { const m = /^#([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return '#fff'; const n = parseInt(m[1], 16); const [r, g, b] = [n >> 16, (n >> 8) & 255, n & 255].map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }); return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.42 ? '#101014' : '#ffffff'; }

export function renderChat() {
  const AR = getLang() === 'ar'; const L = (ar, en) => (AR ? ar : en);
  const st = { list: null, open: null, ch: null, msgs: [], rev: 0, more: false, panel: null, members: null, mods: null, pending: null, sending: false, alive: true, draft: '', upload: null, newLogo: null, newColor: CHANNEL_COLORS[0], call: null, callView: null, callChat: false, callSeen: 0,
    tab: 'all', reply: null, edit: null, pinned: null, typing: [], seenUpTo: 0, mutedUntil: 0, info: window.matchMedia('(min-width: 1280px)').matches, search: null, hidePin: '' };
  const me = () => st.list?.me || auth.current()?.uid || null;   // the server's id for this account
  const ERR = { forbidden: L('ما عندك صلاحية لهالإشي.', 'You are not allowed to do that.'), no_account: L('ما في حساب بهالإيميل. خلّيه يسجّل بالموقع أول، وبعدين ضيفه.', 'No account uses this e-mail. Ask them to sign up first, then add them.'),
    already_member: L('هو عضو أصلًا.', 'Already a member.'), bad_email: L('الإيميل مش صحيح.', 'That e-mail is not valid.'), bad_name: L('الاسم لازم يكون حرفين أو أكثر.', 'The name needs at least 2 characters.'),
    bad_image: L('الصورة لازم تكون JPG أو PNG أو WebP.', 'The image must be JPG, PNG or WebP.'), bad_media: L('الملف لازم يكون صورة أو فيديو (MP4، MOV، WebM).', 'The file must be a photo or a video (MP4, MOV, WebM).'),
    image_too_large: L('الصورة كبيرة كثير.', 'The image is too large.'), video_too_large: L('الفيديو أكبر من 50MB. صوّر أقصر أو بجودة أقل.', 'The video is over 50 MB. Record a shorter one or at lower quality.'), too_large: L('الملف كبير كثير.', 'The file is too large.'),
    rate_limited: L('بتبعت بسرعة كثير. استنى دقيقة.', 'Too fast. Wait a minute.'), channel_full: L('القناة وصلت 500 عضو.', 'The channel has 500 members.'), too_many_channels: L('وصلت حد 20 قناة.', 'You reached 20 channels.'),
    creator_cannot_leave: L('منشئ القناة ما بيقدر يطلع منها. احذفها إذا بدك.', 'The creator cannot leave; delete the channel instead.'), creator_stays_admin: L('منشئ القناة بيضل مشرف.', 'The creator stays an admin.'),
    email_unverified: L('أكّد إيميلك أول.', 'Confirm your e-mail first.'), no_secret: L('السيرفر ناقصه AI_KEY_SECRET، فالمحادثات مطفية.', 'The server lacks AI_KEY_SECRET, so chat is off.'), empty: L('اكتب رسالة أو اختار صورة أو فيديو.', 'Write a message or pick a photo or video.'),
    call_full: L('المكالمة فيها 8 أشخاص، وهاد الحد.', 'The call has 8 people, the maximum.'), no_call: L('المكالمة خلصت.', 'The call has ended.'), mic_denied: L('الميكروفون مش مسموح. اسمح فيه من إعدادات المتصفح.', 'Microphone blocked. Allow it in the browser settings.'),
    cam_denied: L('الكاميرا مش مسموحة. اسمح فيها من إعدادات المتصفح.', 'Camera blocked. Allow it in the browser settings.'), no_camera: L('هالجهاز أو المتصفح ما فيه كاميرا متاحة.', 'No camera available here.'), bad_color: L('اللون مش صحيح.', 'Invalid colour.'), blocked: L('هالشخص حظرك، ما بتقدر تبعتله.', 'This person blocked you.'), you_blocked: L('إنت حاظره. فك الحظر من المعلومات لتبعت.', 'You blocked them. Unblock from the info panel to write.'), slow_mode: L('الوضع البطيء شغّال: استنى شوي وابعت.', 'Slow mode is on: wait a moment.'), links_off: L('الروابط مسكّرة بهالمجموعة.', 'Links are off in this group.'), blocked_word: L('رسالتك فيها كلمة ممنوعة بهالمجموعة.', 'Your message has a word this group blocks.'), bad_poll: L('الاستطلاع بدّه سؤال وخيارين عالأقل.', 'A poll needs a question and two options.'), poll_closed: L('الاستطلاع تسكّر.', 'The poll is closed.'), voice_too_large: L('الرسالة الصوتية طويلة كتير.', 'The voice message is too long.'), file_too_large: L('الملف أكبر من 25MB.', 'The file is over 25 MB.'), banned: L('انحظرت من هالمجموعة.', 'You are banned from this group.'), too_many_invites: L('في كتير روابط. امسح القديمة.', 'Too many links. Remove old ones.'),
    big_off: L('المكالمات الكبيرة بدها LiveKit على السيرفر.', 'Big calls need LiveKit on the server.'),
    too_many_comments: L('في كتير تعليقات على هالمنشور.', 'This post has too many comments.'), bad_bot_username: L('اسم البوت لازم يخلص بـ bot، زي helperbot.', 'A bot username must end in "bot", like helperbot.'), no_bot: L('ما في بوت بهالاسم.', 'No bot with that username.'), too_many_bots: L('عندك 10 بوتات.', 'You have 10 bots.'),
    secret_device: L('هالمحادثة السرية مفتوحة على جهاز تاني.', 'This secret chat lives on another device.'), secret_pending: L('استنى لحد ما الطرف التاني يفتح المحادثة السرية.', 'Wait until the other side opens the secret chat.'), secret_no_forward: L('ما في تحويل من أو لمحادثة سرية.', 'Secret chats can\'t be forwarded.'), no_crypto: L('متصفحك ما بيدعم التشفير.', 'Your browser does not support encryption.'), bad_key: L('مفتاح التشفير مش صالح.', 'Invalid encryption key.'), already_set: L('المفتاح محطوط من قبل.', 'Key already set.'),
    dm_closed: L('هالشخص ما بيستقبل رسائل إلا من ناس بجروباته.', 'This person only takes messages from people in their groups.'), bad_username: L('اسم المستخدم: 5 لـ32 حرف إنجليزي وأرقام و_، ويبدأ بحرف.', 'Username: 5–32 letters, digits or _, starting with a letter.'), username_taken: L('هالاسم محجوز.', 'That username is taken.'), bad_time: L('اختار وقت بعد دقيقة عالأقل وخلال 30 يوم.', 'Pick a time at least a minute ahead, within 30 days.'), too_many_pins: L('بتقدر تثبّت 10 محادثات بس.', 'You can pin 10 chats.'), too_many_scheduled: L('عندك 20 رسالة مجدولة.', 'You have 20 scheduled messages.'),
    ai_off: L('الترجمة مش شغّالة هلأ.', 'Translation is not available right now.'), bad_topic: L('الموضوع انمسح.', 'That topic was removed.'), too_many_stickers: L('عندك 60 ستيكر. امسح كم واحد.', 'You have 60 stickers. Remove some.'), too_many_stories: L('عندك كتير حالات اليوم.', 'Too many stories today.'),
    admins_only: L('بهالقناة بس المشرفين بينشروا.', 'Only admins post in this channel.'), muted: L('المشرف كتمك مؤقتًا بهالمجموعة.', 'An admin muted you in this group for now.'), too_old: L('بتقدر تعدّل الرسالة خلال 48 ساعة بس.', 'Messages can be edited for 48 hours only.'),
    quota_reached: L('وصلت حد الرفع لليوم (600MB). كمّل بكرا.', 'You reached today\'s upload limit (600 MB). Continue tomorrow.') };
  const say = (e) => toast(ERR[e?.code || e?.message] || L('صار خطأ. جرّب كمان مرة.', 'Something went wrong. Try again.'), 'error');
  const fmtTime = (ms) => new Intl.DateTimeFormat(AR ? 'ar' : 'en-US', { hour: '2-digit', minute: '2-digit', numberingSystem: 'latn' }).format(ms);
  const fmtDay = (ms) => { const d = new Date(ms); const t = new Date(); const y = new Date(Date.now() - 86_400_000);
    if (d.toDateString() === t.toDateString()) return L('اليوم', 'Today'); if (d.toDateString() === y.toDateString()) return L('مبارح', 'Yesterday');
    return new Intl.DateTimeFormat(AR ? 'ar' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric', numberingSystem: 'latn' }).format(ms); };
  const ICON = {
    plus: '<path d="M12 5v14M5 12h14"/>', send: '<path d="M21.5 2.5L10.6 13.4M21.5 2.5l-6.9 19-4-8.1-8.1-4z"/>', img: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-8 9"/>',
    back: AR ? '<path d="M9 6l6 6-6 6"/>' : '<path d="M15 6l-6 6 6 6"/>', gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>', trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>', users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M21.5 20a6.5 6.5 0 0 0-4-6"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>', lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4Z"/><circle cx="12" cy="13" r="3.5"/>', phonecam: '<rect x="6" y="2.5" width="12" height="19" rx="2.5"/><circle cx="12" cy="10" r="3"/><path d="M10.5 18h3"/>',
    video: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3"/>', play: '<path d="M8 5.5v13l11-6.5z"/>', call: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"/>', micoff: '<path d="M3 3l18 18M9 9v2a3 3 0 0 0 5 2.2M15 9.3V6a3 3 0 0 0-5.8-1M5.5 11a6.5 6.5 0 0 0 10.4 5.2M18.5 11a6.4 6.4 0 0 1-.7 2.9M12 17.5V21"/>',
    camoff: '<path d="M3 3l18 18M16 16H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h1M10 6h4a2 2 0 0 1 2 2v3l5-3v9"/>', flip: '<path d="M20 11a8 8 0 0 0-14.3-4.9L4 8M4 4v4h4M4 13a8 8 0 0 0 14.3 4.9L20 16M20 20v-4h-4"/>',
    screen: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4M12 13V7M9 10l3-3 3 3"/>', chat: '<path d="M4 5h16v11H9l-5 4z"/>', leave: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2" transform="rotate(135 12 12)"/>',
    pin: '<path d="M9 3h6l-1 6 4 4H6l4-4zM12 13v8"/>', reply: AR ? '<path d="M14 9V5l7 7-7 7v-4c-5 0-8 1.5-11 5 1-5 4-10 11-11z"/>' : '<path d="M10 9V5l-7 7 7 7v-4c5 0 8 1.5 11 5-1-5-4-10-11-11z"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16zM13.5 6.5l4 4"/>', smile: '<circle cx="12" cy="12" r="9"/><path d="M8.5 14.5a4.5 4.5 0 0 0 7 0M9 9.5h.01M15 9.5h.01"/>', check: '<path d="M4 12.5l5 5L20 6.5"/>', check2: '<path d="M2 12.5l5 5L18 6.5M11.5 16l1.5 1.5L24 6.5"/>',
    crown: '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z"/>', more: '<circle cx="12" cy="5" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="12" cy="19" r="1.4"/>', bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4zM10 20.5a2 2 0 0 0 4 0"/>',
    belloff: '<path d="M3 3l18 18M8.5 5.3A6 6 0 0 1 18 11v4M6 11v5l-2 2h13M10 20.5a2 2 0 0 0 4 0"/>', ban: '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>', megaphone: '<path d="M3 10v4h3l7 4V6L6 10zM16 9a4 4 0 0 1 0 6M19 6.5a8 8 0 0 1 0 11"/>',
    doc: '<path d="M14 3H6v18h12V7zM14 3v4h4M9 13h6M9 17h6"/>', bookmark: '<path d="M6 3h12v18l-6-4.5L6 21z"/>',
    forward: AR ? '<path d="M10 9V5l-7 7 7 7v-4c5 0 8 1.5 11 5-1-5-4-10-11-11z"/>' : '<path d="M14 9V5l7 7-7 7v-4c-5 0-8 1.5-11 5 1-5 4-10 11-11z"/>', poll: '<path d="M5 20V10M12 20V4M19 20v-7"/>', link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>', dl: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>', pause: '<path d="M8 5v14M16 5v14"/>', copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    round: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/>', pen: '<path d="M4 20l4-1 11-11-3-3L5 16zM14 6l3 3"/>', rotate: '<path d="M4 12a8 8 0 1 0 2.3-5.6M4 4v4h4"/>', crop: '<path d="M6 2v16h16M2 6h16v16"/>', undo: '<path d="M9 14L4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3"/>',
    bot: '<rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9 17h6"/>', folder: '<path d="M3 6h7l2 2h9v11H3z"/>', device: '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>',
    archive: '<path d="M3 5h18v4H3zM5 9v10h14V9M10 13h4"/>', mute: '<path d="M11 5L6 9H3v6h3l5 4zM16 9l5 6M21 9l-5 6"/>', clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>', user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    timer: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2M9.5 2.5h5"/>', globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>', sticker: '<path d="M4 4h16v9l-7 7H4zM13 20v-5a2 2 0 0 1 2-2h5"/>', hash: '<path d="M9 3L7 21M17 3l-2 18M4 8.5h16M3 15.5h16"/>',
    down: '<path d="M6 9l6 6 6-6"/>', search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    palette: '<path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.5-.8 1.5-1.6 0-1.1-.9-1.6-.9-2.6 0-.9.7-1.8 2-1.8H17a4 4 0 0 0 4-4C21 6.6 17 3 12 3z"/><circle cx="7.5" cy="11" r="1.2"/><circle cx="10.5" cy="7.2" r="1.2"/><circle cx="15" cy="7.5" r="1.2"/>' };
  const ic = (n, cls = '') => `<svg class="ch-ic ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICON[n]}</svg>`;
  const colorOf = (c) => c?.color || CHANNEL_COLORS[0];
  // Arabic counting: 1 عضو واحد، 2 عضوان، 3–10 أعضاء، 11+ عضو
  const countAr = (n, one, two, few, many) => (n === 1 ? one : n === 2 ? two : n >= 3 && n <= 10 ? `${n} ${few}` : `${n} ${many}`);
  const membersTxt = (n) => L(countAr(n, 'عضو واحد', 'عضوان', 'أعضاء', 'عضو'), `${n} member${n === 1 ? '' : 's'}`);
  const CAT = { official: L('Go Triva الرسمي', 'Go Triva Official'), signals: L('إشارات التداول', 'Trading signals'), ai: L('استراتيجيات الذكاء الاصطناعي', 'AI strategies'), forex: L('فوركس وذهب', 'Forex & gold'), crypto: L('مجتمع الكريبتو', 'Crypto community'), general: L('دردشة عامة', 'General chat'), education: L('تعليم التداول', 'Trading education'), vip: 'VIP', support: L('الدعم', 'Support') };
  // the list tabs: everything, then the families that have channels (trading = signals, forex and crypto)
  const TABS = [['all', L('الكل', 'All'), null], ['dm', L('خاص', 'Private'), 'dm'], ['trading', L('تداول', 'Trading'), ['signals', 'forex', 'crypto', 'official']], ['ai', 'AI', ['ai']], ['learn', L('تعليم', 'Learn'), ['education']], ['vip', 'VIP', ['vip']], ['more', L('عام', 'General'), ['general', 'support']]];
  const PLAN_NAMES = [L('الكل (مجاني)', 'Everyone (free)'), L('شهري فما فوق', 'Monthly and up'), L('ربع سنوي فما فوق', 'Quarterly and up'), L('نصف سنوي فما فوق', 'Half-year and up'), L('سنوي فما فوق', 'Annual and up'), 'Prime +', 'Apex +', 'Max'];
  const verified = (c) => (c?.verified ? `<svg class="chp-verified" viewBox="0 0 24 24" role="img" aria-label="${esc(L('موثّقة', 'Verified'))}"><path d="M12 2l2.4 1.8 3-.3 1 2.8 2.7 1.4-.6 3 1.5 2.6-2.1 2.2-.2 3-2.9.8L15 22l-3-1-3 1-1.8-2.7-2.9-.8-.2-3L2 13.3l1.5-2.6-.6-3 2.7-1.4 1-2.8 3 .3z"/><path d="M8 12.2l2.7 2.6L16.2 9.3" fill="none" stroke="#04222a" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>` : '');
  const inCallTxt = (n) => L(countAr(n, 'شخص واحد بالمكالمة', 'شخصان بالمكالمة', 'أشخاص بالمكالمة', 'شخص بالمكالمة'), `${n} in call`);

  const el = h(`<section class="subpage chatp page-enter"><div class="chp-shell">
    <aside class="chp-side" data-side></aside>
    <p class="chp-offbar" data-offbar hidden>${ic('clock', 'is-xs')} ${esc(L('مش متصل. عم نعرض آخر نسخة، والرسائل بتنبعت لما يرجع النت.', 'Offline. Showing the last copy; messages go out when you are back.'))}</p>
    <main class="chp-main" data-main></main>
    <aside class="chp-info" data-info hidden></aside></div>
    <div class="chp-lightbox" data-lightbox hidden><button type="button" class="chp-icbtn chp-lb-x" data-close-lb aria-label="${esc(L('سكّر', 'Close'))}">${ic('x')}</button><img alt=""></div>
    <input type="file" accept="image/*,video/*" capture="environment" data-native hidden>
    <input type="file" accept="image/png,image/jpeg,image/webp,image/gif,image/heic,video/mp4,video/quicktime,video/webm" data-gallery hidden>
    <input type="file" data-docpick hidden>
    <input type="file" accept="image/png,image/jpeg,image/webp" data-avpick hidden>
    <input type="file" accept="image/png,image/jpeg,image/webp,image/gif" data-stkpick hidden>
    <input type="file" accept="image/png,image/jpeg,image/webp,video/mp4,video/quicktime,video/webm" data-storypick hidden></section>`);
  const side = el.querySelector('[data-side]'); const main = el.querySelector('[data-main]'); const info = el.querySelector('[data-info]'); const lb = el.querySelector('[data-lightbox]');
  const blobs = new Map();   // file id → blob URL (media only loads through the signed-in server route)
  let pollGen = 0;

  /* ── secret chats: decrypt what arrives, encrypt what leaves (the server only ever holds ciphertext) ── */
  const AAD = (chatId, uid, kind) => `${chatId}|${uid}|${kind}`;   // what each secret ciphertext is bound to
  const encFiles = new Map();   // file id → { key, iv, type } for files that must be decrypted after download
  const ENC_TYPES = { image: 'image/jpeg', voice: 'audio/webm', video: 'video/mp4', file: 'application/octet-stream' };
  async function secretKey(c = st.ch) {
    if (c?.type !== 'secret' || !c.secret?.ready) return null; const me2 = await deviceKey().catch(() => null); if (!me2) return null;
    const uid = st.list?.me; if (c.secret.keys[uid] !== me2.pub) return null; const peer = Object.entries(c.secret.keys).find(([k]) => k !== uid)?.[1]; if (!peer) return null;
    // v368 security: the other person's key is remembered on this device; if the server ever hands a different one, stop and warn
    const pinK = `gt-peerkey:${c.id}`; let pinned = null; try { pinned = localStorage.getItem(pinK); } catch { /* private mode */ }
    if (pinned && pinned !== peer) { st.secretState = 'keychanged'; st.keyWarned = st.keyWarned || {}; if (!st.keyWarned[c.id]) { st.keyWarned[c.id] = true; toast(L('⚠️ مفتاح الطرف الثاني تغيّر. ما رح نفك أو نبعت رسائل بهالمحادثة. ابدأ محادثة سرية جديدة وقارن البصمة.', '⚠️ The other person\'s key changed. This chat is paused: start a new secret chat and compare the fingerprint.'), 'error'); } return null; }
    if (!pinned) { try { localStorage.setItem(pinK, peer); } catch { /* */ } }
    return chatKey(c.id, peer);
  }
  async function secretInfo(c) {
    st.fp = null; st.secretState = null; if (c?.type !== 'secret') return;
    let me2; try { me2 = await deviceKey(); } catch { st.secretState = 'nocrypto'; return; }
    const uid = st.list?.me; const mine = c.secret?.keys?.[uid];
    st.secretState = !mine ? 'accept' : mine !== me2.pub ? 'device' : c.secret.ready ? 'ready' : 'pending';
    if (c.secret?.ready) { const peer = Object.entries(c.secret.keys).find(([k]) => k !== uid)?.[1]; let pin = null; try { pin = localStorage.getItem(`gt-peerkey:${c.id}`); } catch { /* */ } if (pin && peer && pin !== peer) { st.secretState = 'keychanged'; return; } }   // v368: keep the warning, no fingerprint for a swapped key
    if (c.secret?.ready) { const ks = Object.values(c.secret.keys); st.fp = await fingerprint(ks[0], ks[1]); }
  }
  async function decAll(list, c = st.ch) {
    if (c?.type !== 'secret' || !list?.length) return list; const k = await secretKey(c);
    for (const m of list) {
      if (m.enc) { if (!k) { m.text = ''; m.locked = true; continue; } try { m.text = await openText(k, m.enc, AAD(c.id, m.uid, 'text')); } catch { m.text = ''; m.locked = true; } }
      if (m.encMedia && m.file) { const em = m.encMedia; m.kind = em.kind; if (k) { encFiles.set(m.file, { key: k, iv: em.iv, type: em.kind === 'image' ? 'image/jpeg' : ENC_TYPES[em.kind], aad: em.v === 2 ? AAD(c.id, m.uid, em.kind) : '' }); if (em.name && em.nameIv) { try { m.fileName = await openText(k, { iv: em.nameIv, ct: em.name, v: em.v }, AAD(c.id, m.uid, 'name')); } catch { m.fileName = 'file'; } } } else m.locked = true; }
      if (m.replyTo?.enc) { const r0 = list.find((x) => x.id === m.replyTo.id) || st.msgs.find((x) => x.id === m.replyTo.id); m.replyTo = { ...m.replyTo, text: r0?.text || '🔒' }; }
    }
    return list;
  }
  function blob(chId, fid) {
    const got = blobs.get(fid); if (typeof got === 'string') return Promise.resolve(got); if (got) return got;
    const ef = encFiles.get(fid);
    const p = (ef ? apiBuffer(`/api/chat/${chId}/file/${fid}`).then(async (buf) => URL.createObjectURL(await openBlob(ef.key, ef.iv, buf, ef.type, ef.aad || '')))
      : apiBlobUrl(`/api/chat/${chId}/file/${fid}`)).then((u) => { blobs.set(fid, u); return u; }).catch(() => { blobs.delete(fid); return null; });
    blobs.set(fid, p); return p;
  }
  const logoHtml = (c, big = false) => (c?.logo ? `<img class="chp-logo${big ? ' is-big' : ''}" data-logo="${esc(c.id)}:${esc(c.logo)}" alt="" style="--ring:${esc(colorOf(c))}">` : `<span class="chp-logo chp-logo-ph${big ? ' is-big' : ''}" aria-hidden="true" style="--ring:${esc(colorOf(c))};background:${esc(colorOf(c))};color:${inkOn(colorOf(c))}">${esc((c?.name || '?').trim().charAt(0).toUpperCase())}</span>`);
  const lpCache = new Map();
  const lpGet = (u) => { if (!lpCache.has(u)) { if (lpCache.size > 300) lpCache.clear(); lpCache.set(u, apiRequest('GET', `/api/chat/preview?u=${encodeURIComponent(u)}`, undefined, 15000).catch(() => null)); } return lpCache.get(u); };
  const avUrls = new Map();
  const avUrl = (uid, v) => { const k = `${uid}:${v}`; if (!avUrls.has(k)) avUrls.set(k, apiBlobUrl(`/api/chat/avatar/${uid}?v=${v}`).catch(() => null)); return avUrls.get(k); };
  const hydrate = (root) => {
    root.querySelectorAll('img[data-logo], img[data-file]').forEach((im) => { const [cid, fid] = (im.dataset.logo || im.dataset.file).split(':'); blob(cid, fid).then((u) => { if (u) im.src = u; }); });
    root.querySelectorAll('[data-lp]').forEach((x) => { if (x.dataset.done) return; x.dataset.done = '1'; lpGet(x.dataset.lp).then((v) => { if (!v?.title || !x.isConnected) return; x.innerHTML = `<a href="${esc(v.url)}" target="_blank" rel="noopener noreferrer nofollow ugc"><small>${esc(v.site || v.host)}</small><b dir="auto">${esc(v.title)}</b>${v.description ? `<span dir="auto">${esc(v.description)}</span>` : ''}</a>`; x.hidden = false; }); });
    root.querySelectorAll('[data-av]').forEach((x) => { const [uid, v] = x.dataset.av.split(':'); if (!Number(v)) return; avUrl(uid, v).then((u) => { if (u && x.isConnected) { x.style.backgroundImage = `url("${u}")`; x.classList.add('has-img'); } }); });
  };
  const av = (uid) => st.av?.[uid] || 0;
  const avAttr = (uid, v = av(uid)) => (v ? ` data-av="${esc(uid)}:${v}"` : '');
  function applyColor() { const c = colorOf(st.ch); el.style.setProperty('--chc', c); el.style.setProperty('--chc-ink', inkOn(c)); }

  /* ── side: the channel list ── */
  function paintSide() {
    const l = st.list; const sig = `${l ? 1 : 0}${l?.owner ? 1 : 0}${l?.canCreate ? 1 : 0}:${st.myAv || 0}`;
    if (side.dataset.sig === sig && side.querySelector('[data-listbox]')) { paintList(); return; }   // keep the search box (and its focus) while the list refreshes
    side.dataset.sig = sig;
    side.innerHTML = `<header class="chp-side-head"><div class="chp-side-row"><h1>${esc(L('المجموعات', 'Groups'))}</h1>
        <div class="chp-side-actions">${l ? `<button type="button" class="chp-icbtn chp-me-btn" data-act="profile" aria-label="${esc(L('بروفايلي', 'My profile'))}" title="${esc(L('بروفايلي', 'My profile'))}"${avAttr(l.me, st.myAv || 0)}>${ic('user')}</button>` : ''}${l ? `<button type="button" class="chp-icbtn" data-act="saved" aria-label="${esc(L('الرسائل المحفوظة', 'Saved messages'))}" title="${esc(L('الرسائل المحفوظة', 'Saved messages'))}">${ic('bookmark')}</button>` : ''}${l?.owner ? `<button type="button" class="chp-icbtn" data-act="mods" aria-label="${esc(L('المشرفين المعتمدين', 'Approved moderators'))}" title="${esc(L('المشرفين المعتمدين', 'Approved moderators'))}">${ic('shield')}</button>` : ''}
        ${l?.canCreate ? `<button type="button" class="chp-plus" data-act="new" aria-label="${esc(L('مجموعة أو قناة جديدة', 'New group or channel'))}" title="${esc(L('مجموعة أو قناة جديدة', 'New group or channel'))}">${ic('plus')}</button>` : ''}</div></div>
        <label class="chp-search">${ic('search', 'is-sm')}<input type="search" data-q value="${esc(st.q || '')}" placeholder="${esc(L('دوّر بالمحادثات والرسائل والأشخاص', 'Search chats, messages and people'))}" aria-label="${esc(L('بحث', 'Search'))}"></label>
        <div class="chp-stories" data-stories></div>
        <div class="chp-tabs" role="tablist" data-tabs></div></header>
      <div class="chp-list" role="list" data-listbox></div>`;
    paintList();
  }
  const isPriv = (c) => c?.type === 'dm' || c?.type === 'saved' || c?.type === 'secret';
  const isOne = (c) => c?.type === 'dm' || c?.type === 'secret';
  const inTab = (c, t) => {
    if (t === 'unread') return c.unread > 0;
    if (t.startsWith('f:')) { const f = (st.folders || []).find((x) => `f:${x.id}` === t); if (!f) return false; const inF = f.chats.includes(c.id) || (f.types || []).includes(c.type); return inF && (!f.unread || c.unread > 0); }
    const d = TABS.find((x) => x[0] === t); if (!d?.[2]) return true; if (d[2] === 'dm') return isPriv(c); return !isPriv(c) && d[2].includes(c.category); };
  const nameOf = (c) => (c.type === 'saved' ? L('الرسائل المحفوظة', 'Saved messages') : c.name);
  const avatarOf = (c, big = false) => (c.type === 'saved' ? `<span class="chp-logo chp-logo-ph chp-saved-ava${big ? ' is-big' : ''}" aria-hidden="true">${ic('bookmark')}</span>`
    : isOne(c) ? `<span class="chp-logo chp-logo-ph chp-dm-ava${c.type === 'secret' ? ' is-secret' : ''}${big ? ' is-big' : ''}${c.peer?.online ? ' is-online' : ''}" aria-hidden="true"${avAttr(c.peer?.uid, c.peer?.av)} style="--h:${hueOf(c.peer?.uid)};background-color:var(--h)">${esc((c.name || '?').trim().charAt(0).toUpperCase())}</span>` : logoHtml(c, big));
  function paintStories() {
    const box = side.querySelector('[data-stories]'); if (!box || !st.list) return;
    const all = st.stories || []; const mine = all.find((x) => x.me);
    const ring = (x) => `<button type="button" class="chp-story${x.items.every((y) => y.seen) && !x.me ? ' is-seen' : ''}" data-story="${esc(x.uid)}"><span class="chp-story-ava" style="--h:${hueOf(x.uid)}">${esc((x.name || '?').charAt(0).toUpperCase())}</span><small dir="auto">${esc(x.me ? L('حالتي', 'My story') : x.name)}</small></button>`;
    const html = `<button type="button" class="chp-story is-add" data-act="storyadd" aria-label="${esc(L('ضيف حالة', 'Add a story'))}"><span class="chp-story-ava">${ic('plus')}</span><small>${esc(mine ? L('زيد', 'Add') : L('حالتي', 'My story'))}</small></button>${mine ? ring(mine) : ''}${all.filter((x) => !x.me).map(ring).join('')}`;
    if (box.dataset.html !== html) { box.innerHTML = html; box.dataset.html = html; }
  }
  async function loadStories() { try { st.stories = (await apiRequest('GET', '/api/chat/stories', undefined, 15000)).stories; paintStories(); } catch { /* quiet */ } }
  function paintList() {
    const l = st.list; const box = side.querySelector('[data-listbox]'); if (!box) return;
    const all = l?.channels || [];
    const tabs = [...TABS.slice(0, 1), ...(all.some((c) => c.unread) ? [['unread', L('غير مقروء', 'Unread'), 'unread']] : []), ...(st.folders || []).map((f) => [`f:${f.id}`, `${f.emoji ? `${f.emoji} ` : ''}${f.name}`, 'folder']), ...TABS.slice(1)].filter((t) => t[0] === 'all' || t[2] === 'folder' || all.some((c) => inTab(c, t[0])));
    if (!tabs.some((t) => t[0] === st.tab)) st.tab = 'all';
    const tb = side.querySelector('[data-tabs]');
    const tabHtml = all.length ? `${tabs.map((t) => { const n = all.filter((c) => inTab(c, t[0])).length; return `<button type="button" role="tab" class="chp-tab" data-tab="${esc(t[0])}" aria-selected="${st.tab === t[0]}">${esc(t[1])}<span>${n}</span></button>`; }).join('')}<button type="button" class="chp-tab chp-tab-add" data-act="folders" aria-label="${esc(L('المجلدات', 'Folders'))}" title="${esc(L('المجلدات', 'Folders'))}">${ic('folder', 'is-xs')}</button>` : '';
    if (tb && tb.dataset.html !== tabHtml) { tb.innerHTML = tabHtml; tb.dataset.html = tabHtml; }
    paintStories();
    const q = (st.q || '').trim().toLowerCase(); const arch = all.filter((c) => c.archived);
    const rows = all.filter((c) => inTab(c, st.tab) && Boolean(c.archived) === Boolean(st.showArch) && (!q || nameOf(c).toLowerCase().includes(q) || (c.description || '').toLowerCase().includes(q)));
    const kindTxt = (k) => (k === 'video' ? L('فيديو', 'Video') : k === 'voice' ? L('🎤 رسالة صوتية', '🎤 Voice message') : k === 'file' ? L('📎 ملف', '📎 File') : L('صورة', 'Photo'));
    const bd = (x) => `<bdi>${x}</bdi>`;
    const preview = (c) => (c.type === 'secret' && !c.last ? esc(c.secret?.ready ? L('محادثة سرية جاهزة', 'Secret chat ready') : L('محادثة سرية: بانتظار الطرف التاني', 'Secret chat: waiting for the other side')) : c.last?.enc ? esc(L('🔒 رسالة مشفّرة', '🔒 Encrypted message')) : c.call ? `<span class="chp-live">${ic('call', 'is-sm')} ${esc(L('مكالمة شغّالة', 'Call live'))}</span>` : c.last ? `${c.type === 'channel' || isPriv(c) ? '' : `${bd(esc(c.last.name))}: `}${bd(c.last.text ? esc(c.last.text) : esc(kindTxt(c.last.kind)))}` : esc(c.type === 'saved' ? L('احفظ هون رسائل وملاحظات إلك لحالك', 'Keep messages and notes for yourself') : c.description || L('ما في رسائل لسا', 'No messages yet')));
    const archRow = st.showArch ? `<button type="button" class="chp-arch-row" data-act="arch">${ic('back', 'is-sm')}<span>${esc(L('رجوع من الأرشيف', 'Back from the archive'))}</span></button>` : arch.length && !q ? `<button type="button" class="chp-arch-row" data-act="arch">${ic('archive', 'is-sm')}<span>${esc(L('المؤرشفة', 'Archived'))}</span><em>${arch.length}</em></button>` : '';
    box.innerHTML = `${archRow}${q ? searchResultsHtml() : ''}${q && all.length && !rows.length ? `<p class="chp-muted chp-pad">${esc(L('ما في مجموعة بهالاسم.', 'No group by that name.'))}</p>` : ''}${!l ? '<div class="chp-skel"></div><div class="chp-skel"></div><div class="chp-skel"></div>' : !all.length ? `<div class="chp-empty-side">${ic('users')}<b>${esc(L('ما في مجموعات لسا', 'No groups yet'))}</b><span>${esc(l.canCreate ? L('اعمل أول مجموعة أو قناة، واربطها باشتراك إذا بدك.', 'Create the first group or channel, and tie it to a plan if you like.') : L('لما مشرف يضيفك لمجموعة، أو اشتراكك يفتحلك وحدة، بتطلع هون.', 'Groups you are added to, or that your plan opens, show up here.'))}</span></div>`
        : rows.map((c) => `<button type="button" role="listitem" class="chp-item${c.id === st.open ? ' is-on' : ''}${c.unread ? ' is-unread' : ''}" data-open="${esc(c.id)}" style="--ring:${esc(colorOf(c))}">${avatarOf(c)}
          <span class="chp-item-txt"><span class="chp-item-top"><b dir="auto">${c.type === 'channel' ? `${ic('megaphone', 'is-xs')} ` : c.type === 'secret' ? `<span class="chp-lock">${ic('lock', 'is-xs')}</span>` : ''}${esc(nameOf(c))}</b>${verified(c)}</span><small>${draftOf(c.id) && c.id !== st.open ? `<span class="chp-draft">${esc(L('مسودة:', 'Draft:'))}</span> ${esc(draftOf(c.id).slice(0, 60))}` : preview(c)}</small></span>
          <span class="chp-item-meta">${c.last ? `<time>${esc(fmtTime(c.last.at))}</time>` : ''}${c.pinnedChat || c.muteUntil ? `<span class="chp-item-flags">${c.muteUntil ? ic('mute', 'is-xs') : ''}${c.pinnedChat ? ic('pin', 'is-xs') : ''}</span>` : ''}${c.mentions ? '<em class="chp-badge chp-at-badge" aria-label="@">@</em>' : ''}${c.requests ? `<em class="chp-badge is-quiet" title="${esc(L('طلبات انضمام', 'Join requests'))}">+${c.requests}</em>` : ''}${c.unread ? `<em class="chp-badge${c.notify === false ? ' is-quiet' : ''}" aria-label="${esc(L(`${c.unread} رسالة جديدة`, `${c.unread} new`))}">${c.unread > 99 ? '99+' : c.unread}</em>` : c.notify === false ? `<span class="chp-quiet" title="${esc(L('الإشعارات مسكّرة', 'Notifications off'))}">${ic('belloff', 'is-xs')}</span>` : ''}</span></button>`).join('')}`;
    hydrate(box);
  }

  /* ── main ── */
  const EMOJI = ['😀', '😂', '😍', '🤔', '😎', '🙏', '👍', '👏', '🔥', '🚀', '💯', '❤️', '💜', '📈', '📉', '💰', '🥇', '⚡', '✅', '❌', '👀', '🎯', '🤝', '👋'];
  const subTxt = (c) => (c.type === 'secret' && !st.typing.length ? `<span class="chp-on">${ic('lock', 'is-xs')} ${esc(L('مشفّرة بين الطرفين', 'End-to-end encrypted'))}</span>` : st.recording && st.typing.length ? `<span class="chp-typing"><i></i><i></i><i></i>${esc(L(`${st.typing[0]} عم يسجّل صوت…`, `${st.typing[0]} is recording audio…`))}</span>` : c.type === 'saved' ? esc(L('إلك لحالك', 'Only you')) : c.type === 'dm' && !st.typing.length ? (c.peer?.online ? `<span class="chp-on">${esc(L('متصل هلأ', 'online'))}</span>` : esc(c.peer?.seenAt ? L(`آخر ظهور ${fmtDay(c.peer.seenAt)} ${fmtTime(c.peer.seenAt)}`, `last seen ${fmtDay(c.peer.seenAt)} ${fmtTime(c.peer.seenAt)}`) : L('من زمان', 'a while ago'))) : st.typing.length ? `<span class="chp-typing"><i></i><i></i><i></i>${esc(st.typing.length === 1 ? L(`${st.typing[0]} عم يكتب…`, `${st.typing[0]} is typing…`) : L(`${st.typing.join('، ')} عم يكتبوا…`, `${st.typing.join(', ')} are typing…`))}</span>`
    : `${esc(membersTxt(c.members))}${c.online > 1 ? ` <span class="chp-dot-sep" aria-hidden="true"></span> ${esc(L(`متصل: ${c.online}`, `Online: ${c.online}`))}` : ''}`);
  function pinHtml() {
    const p = st.pinned; if (!p || st.hidePin === p.id) return '';
    const admin = st.ch?.role === 'admin';
    return `<div class="chp-pin"><button type="button" class="chp-pin-go" data-goto="${esc(p.id)}">${ic('pin')}<span><b>${esc(L('رسالة مثبّتة', 'Pinned message'))}</b><small dir="auto">${esc(p.text || (p.kind === 'video' ? L('فيديو', 'Video') : L('صورة', 'Photo')))}</small></span></button>
      <button type="button" class="chp-icbtn" data-act="${admin ? 'unpin' : 'hidepin'}" aria-label="${esc(admin ? L('شيل التثبيت', 'Unpin') : L('خبّي', 'Hide'))}">${ic('x')}</button></div>`;
  }
  function composeHtml() {
    const c = st.ch; const admin = c.role === 'admin';
    if (c.type === 'channel' && !admin) return `<div class="chp-readonly">${ic('megaphone', 'is-sm')}<span>${esc(L('قناة بث: بس المشرفين بينشروا هون.', 'Broadcast channel: only admins post here.'))}</span><button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-act="notify">${ic(c.notify === false ? 'bell' : 'belloff', 'is-sm')}<span>${esc(c.notify === false ? L('شغّل الإشعارات', 'Turn on alerts') : L('اكتم الإشعارات', 'Mute alerts'))}</span></button></div>`;
    if (c.type === 'secret' && st.secretState !== 'ready') return `<div class="chp-readonly chp-secret-bar">${ic('lock', 'is-sm')}<span>${esc(st.secretState === 'accept' ? L(`${c.name} بدّه يبلّش محادثة سرية. المفاتيح بتنعمل على هالجهاز بس.`, `${c.name} wants a secret chat. Keys are made on this device only.`) : st.secretState === 'device' ? L('هالمحادثة السرية مفتوحة على جهاز تاني، وما بتنقرأ هون.', 'This secret chat lives on another device and can\'t be read here.') : st.secretState === 'nocrypto' ? L('متصفحك ما بيدعم التشفير.', 'Your browser does not support encryption.') : st.secretState === 'keychanged' ? L('⚠️ مفتاح الطرف الثاني تغيّر، فوقّفنا هالمحادثة. ابدأ محادثة سرية جديدة وقارنوا البصمة.', '⚠️ The other person\'s key changed, so this chat is paused. Start a new secret chat and compare fingerprints.') : L(`بانتظار ما يفتحها ${c.name} على جهازه…`, `Waiting for ${c.name} to open it on their device…`))}</span>${st.secretState === 'accept' ? `<button type="button" class="chp-btn chp-btn-primary chp-btn-sm" data-act="secretaccept">${esc(L('اقبل وابدأ', 'Accept and start'))}</button>` : ''}</div>`;
    if (isOne(c) && (c.peer?.blockedMe || c.peer?.iBlocked)) return `<div class="chp-readonly">${ic('ban', 'is-sm')}<span>${esc(c.peer.iBlocked ? L('إنت حاظر هالشخص.', 'You blocked this person.') : L('ما بتقدر تبعت لهالشخص.', 'You can\'t message this person.'))}</span>${c.peer.iBlocked ? `<button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-act="unblock">${esc(L('فك الحظر', 'Unblock'))}</button>` : ''}</div>`;
    if (st.rec) return `<div class="chp-compose chp-rec-bar" data-recbar><button type="button" class="chp-icbtn chp-rec-cancel" data-act="reccancel" aria-label="${esc(L('الغي التسجيل', 'Cancel recording'))}">${ic('trash')}</button><span class="chp-rec-dot" aria-hidden="true"></span><time data-rectime>0:00</time><span class="chp-rec-hint">${esc(L('عم يسجّل…', 'Recording…'))}</span><button type="button" class="chp-send" data-act="recsend" aria-label="${esc(L('ابعت الرسالة الصوتية', 'Send voice message'))}">${ic('send')}</button></div>`;
    if (st.mutedUntil) return `<div class="chp-readonly">${ic('ban', 'is-sm')}<span>${esc(st.mutedUntil > 0 ? L(`المشرف كتمك لحد ${fmtTime(st.mutedUntil)}.`, `An admin muted you until ${fmtTime(st.mutedUntil)}.`) : L('المشرف كتمك بهالمجموعة.', 'An admin muted you in this group.'))}</span></div>`;
    const ctx = st.edit || st.reply;
    return `<form class="chp-compose${st.pending || st.draft ? '' : ' is-empty'}" data-compose>
        ${ctx ? `<div class="chp-ctx">${ic(st.edit ? 'edit' : 'reply', 'is-sm')}<span><b>${esc(st.edit ? L('تعديل الرسالة', 'Edit message') : L(`رد على ${ctx.name}`, `Reply to ${ctx.name}`))}</b><small dir="auto">${esc(ctx.text || (ctx.kind === 'video' ? L('فيديو', 'Video') : L('صورة', 'Photo')))}</small></span><button type="button" class="chp-icbtn" data-act="noctx" aria-label="${esc(L('إلغاء', 'Cancel'))}">${ic('x')}</button></div>` : ''}
        ${st.pending ? `<div class="chp-pending">${st.pending.kind === 'video' ? `<video src="${st.pending.url}" muted playsinline preload="metadata"></video><span class="chp-pending-tag">${ic('video', 'is-sm')} ${esc(L('فيديو', 'Video'))} · ${(st.pending.blob.size / 1e6).toFixed(1)} MB</span>` : `<img src="${st.pending.url}" alt="${esc(L('الصورة اللي رح تنبعت', 'Image to send'))}"><button type="button" class="chp-icbtn chp-edit-img" data-act="editimg" aria-label="${esc(L('عدّل الصورة', 'Edit the photo'))}">${ic('pen')}</button>`}<button type="button" class="chp-icbtn" data-act="unpick" aria-label="${esc(L('شيلها', 'Remove'))}">${ic('x')}</button>${st.upload != null ? `<span class="chp-progress" style="--p:${Math.round(st.upload * 100)}%"><i></i></span>` : ''}</div>` : ''}
        <div class="chp-compose-row">
          <div class="chp-emo-wrap"><button type="button" class="chp-icbtn" data-act="emo" aria-haspopup="true" aria-expanded="false" aria-label="${esc(L('إيموجي', 'Emoji'))}">${ic('smile')}</button>
            <div class="chp-emo" hidden><div class="chp-emo-tabs" role="tablist"><button type="button" role="tab" data-emotab="e" aria-selected="true">${esc(L('إيموجي', 'Emoji'))}</button><button type="button" role="tab" data-emotab="s" aria-selected="false"${c.type === 'secret' ? ' hidden' : ''}>${esc(L('ستيكرات', 'Stickers'))}</button></div>
              <div class="chp-emo-grid" data-emogrid>${EMOJI.map((e) => `<button type="button" data-ins="${e}" aria-label="${e}">${e}</button>`).join('')}</div><div class="chp-stk-grid" data-stkgrid hidden></div></div></div>
          <textarea data-text rows="1" maxlength="4000" placeholder="${esc(L('اكتب رسالة…', 'Type a message…'))}" aria-label="${esc(L('الرسالة', 'Message'))}"></textarea>
          ${st.edit ? '' : `<div class="chp-attach-wrap"><button type="button" class="chp-icbtn chp-attach" data-act="attach" aria-haspopup="menu" aria-expanded="false" aria-label="${esc(L('أرفق صورة أو فيديو', 'Attach a photo or video'))}"><svg class="ch-ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11.5l-8 8a5 5 0 0 1-7-7l8.5-8.5a3.3 3.3 0 0 1 4.7 4.7L9.7 17.2a1.7 1.7 0 0 1-2.4-2.4L15 7"/></svg></button>
            <div class="chp-menu" role="menu" hidden>
              <button type="button" role="menuitem" data-act="camera">${ic('camera')}<span><b>${esc(L('صوّر هلأ', 'Shoot now'))}</b><small>${esc(L('صورة أو فيديو بدون ما تطلع من الشات', 'Photo or video without leaving the chat'))}</small></span></button>
              <button type="button" role="menuitem" data-act="native">${ic('phonecam')}<span><b>${esc(L('تطبيق الكاميرا', 'Camera app'))}</b><small>${esc(L('بورتريه، سينمائي، وكل أوضاع هاتفك', 'Portrait, Cinematic, every mode of your phone'))}</small></span></button>
              <button type="button" role="menuitem" data-act="gallery">${ic('img')}<span><b>${esc(L('من المعرض', 'From gallery'))}</b><small>${esc(L('صور، وفيديو لحد 50MB', 'Photos, and videos up to 50 MB'))}</small></span></button>
              <button type="button" role="menuitem" data-act="roundrec">${ic('round')}<span><b>${esc(L('فيديو دائري', 'Round video'))}</b><small>${esc(L('رسالة فيديو قصيرة من الكاميرا الأمامية', 'A short video message from the front camera'))}</small></span></button>
              <button type="button" role="menuitem" data-act="docpick">${ic('doc')}<span><b>${esc(L('ملف', 'File'))}</b><small>${esc(L('PDF، Word، ZIP… لحد 25MB', 'PDF, Word, ZIP… up to 25 MB'))}</small></span></button>
              ${c.type === 'secret' ? '' : `<button type="button" role="menuitem" data-act="later">${ic('clock')}<span><b>${esc(L('ابعت لاحقًا أو بدون صوت', 'Send later or silently'))}</b><small>${esc(L('جدولة الرسالة أو بدون إشعار', 'Schedule it, or no notification sound'))}</small></span></button>`}
              ${c.type === 'saved' || c.type === 'secret' ? '' : `<button type="button" role="menuitem" data-act="poll">${ic('poll')}<span><b>${esc(L('استطلاع', 'Poll'))}</b><small>${esc(L('سؤال وخيارات للتصويت', 'A question with options to vote on'))}</small></span></button>`}</div></div>
          <button type="button" class="chp-icbtn chp-only-wide" data-act="gallery" aria-label="${esc(L('صورة من المعرض', 'Photo from gallery'))}">${ic('img')}</button>`}
          ${st.edit ? '' : `<button type="button" class="chp-mic" data-act="rec" aria-label="${esc(L('سجّل رسالة صوتية', 'Record a voice message'))}" title="${esc(L('سجّل رسالة صوتية', 'Record a voice message'))}">${ic('mic')}</button>`}
          <button type="submit" class="chp-send" aria-label="${esc(st.edit ? L('احفظ التعديل', 'Save edit') : L('ابعت', 'Send'))}" ${st.sending ? 'disabled' : ''}>${ic(st.edit ? 'check' : 'send')}</button></div>
        <div class="chp-mention" data-mention hidden></div>${st.schedN ? `<button type="button" class="chp-sched-pill" data-act="schedlist">${ic('clock', 'is-xs')}${esc(L(`${st.schedN} رسالة مجدولة`, `${st.schedN} scheduled`))}</button>` : ''}</form>`;
  }
  function paintMain() {
    el.classList.toggle('is-open', Boolean(st.open || st.panel === 'new' || st.panel === 'mods'));
    applyColor();
    if (st.panel === 'new') { paintInfo(); return paintNew(); }
    if (st.panel === 'mods') { paintInfo(); return paintMods(); }
    if (!st.open || !st.ch) { paintInfo(); main.innerHTML = `<div class="chp-empty"><span class="chp-empty-mark">${ic('chat')}</span><b>${esc(L('اختار مجموعة', 'Pick a group'))}</b><span>${esc(L('الرسائل والصور والفيديوهات محفوظة، وبتوصل لحظة ما تنبعت.', 'Messages, photos and videos are kept and arrive the moment they are sent.'))}</span></div>`; return; }
    const c = st.ch; const admin = c.role === 'admin'; const call = c.call;
    main.innerHTML = `<header class="chp-head"><button type="button" class="chp-icbtn chp-only-mobile" data-act="back" aria-label="${esc(L('رجوع للمجموعات', 'Back to groups'))}">${ic('back')}</button>
        <button type="button" class="chp-head-id" data-act="settings" aria-label="${esc(L('المعلومات', 'Info'))}">${avatarOf(c)}<span class="chp-head-txt"><span class="chp-head-name"><b dir="auto">${esc(nameOf(c))}</b>${verified(c)}${c.ttl ? `<span class="chp-ttl" title="${esc(L('رسائل بتختفي', 'Disappearing messages'))}">${ic('timer', 'is-xs')}${esc(TTL_NAMES[c.ttl] || '')}</span>` : ''}</span><small data-sub>${subTxt(c)}</small></span></button>
        <div class="chp-head-actions">${(admin && !isPriv(c) || isOne(c)) && !call ? `<button type="button" class="chp-icbtn" data-act="startcall" aria-label="${esc(L('ابدأ مكالمة للأعضاء', 'Start a call for the members'))}" title="${esc(L('ابدأ مكالمة للأعضاء', 'Start a call for the members'))}">${ic('video')}</button>` : ''}
        ${c.bigOn && !c.bigCall && (admin && !isPriv(c) || c.type === 'dm') ? `<button type="button" class="chp-icbtn" data-act="bigstart" aria-label="${esc(L('مكالمة كبيرة (أكثر من 8)', 'Big call (more than 8)'))}" title="${esc(L('مكالمة كبيرة (أكثر من 8)', 'Big call (more than 8)'))}">${ic('users')}</button>` : ''}
        <button type="button" class="chp-icbtn" data-act="search" aria-label="${esc(L('دوّر بالرسائل', 'Search messages'))}" aria-expanded="${Boolean(st.search)}">${ic('search')}</button>
        <button type="button" class="chp-icbtn" data-act="settings" aria-label="${esc(L('معلومات المجموعة', 'Group info'))}" aria-expanded="${st.info}">${ic('more')}</button></div></header>
      ${st.search ? `<form class="chp-msearch" data-msearch>${ic('search', 'is-sm')}<input name="q" type="search" minlength="2" maxlength="80" value="${esc(st.search.q || '')}" placeholder="${esc(L('دوّر بهالمجموعة…', 'Search this group…'))}" aria-label="${esc(L('دوّر بالرسائل', 'Search messages'))}"><button type="button" class="chp-icbtn" data-act="search" aria-label="${esc(L('سكّر البحث', 'Close search'))}">${ic('x')}</button></form>
        ${st.search.results ? `<ul class="chp-results">${st.search.results.length ? st.search.results.map((m) => `<li><button type="button" data-goto="${esc(m.id)}"><b>${esc(m.name)}</b><time>${esc(fmtDay(m.at))} ${esc(fmtTime(m.at))}</time><span dir="auto">${esc(m.text)}</span></button></li>`).join('') : `<li class="chp-muted chp-pad">${esc(L('ما في نتائج.', 'No results.'))}</li>`}</ul>` : ''}` : ''}
      ${c.topics?.length ? `<div class="chp-topics" role="tablist">${[{ id: null, name: L('عام', 'General'), emoji: '' }, ...c.topics].map((t) => `<button type="button" role="tab" class="chp-topic" data-topic="${esc(t.id || '')}" aria-selected="${(st.topic || null) === t.id}">${t.emoji ? `<span aria-hidden="true">${esc(t.emoji)}</span>` : ic('hash', 'is-xs')}${esc(t.name)}</button>`).join('')}</div>` : ''}
      ${c.bigCall ? `<div class="chp-callbar is-big"><span class="chp-callbar-dot" aria-hidden="true"></span><div class="chp-callbar-txt"><b>${esc(L('مكالمة كبيرة شغّالة', 'Big call in progress'))}</b><small>${esc(L(`بدأها ${c.bigCall.by} · بتنفتح بتبويب جديد`, `Started by ${c.bigCall.by} · opens in a new tab`))}</small></div>
        ${admin || c.type === 'dm' ? `<button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-act="bigend">${esc(L('أنهِ', 'End'))}</button>` : ''}<button type="button" class="chp-btn chp-btn-call" data-act="bigjoin">${ic('call')}<span>${esc(L('انضم', 'Join'))}</span></button></div>` : ''}
      <div data-selbox>${st.sel ? selBarHtml() : ''}</div>
      <div data-pinbox>${pinHtml()}</div>
      ${call ? `<div class="chp-callbar"><span class="chp-callbar-dot" aria-hidden="true"></span><div class="chp-callbar-txt"><b>${esc(L('مكالمة شغّالة', 'Call in progress'))}</b><small>${esc(L(`بدأها ${call.by}`, `Started by ${call.by}`))}</small></div><span class="chp-callbar-n" title="${esc(L('بالمكالمة هلأ', 'In the call now'))}">${ic('users', 'is-sm')}<b>${call.n}</b></span>
        <button type="button" class="chp-btn chp-btn-call" data-act="joincall">${ic('call')}<span>${esc(st.callView?.joined ? L('ارجع للمكالمة', 'Back to call') : L('انضم', 'Join'))}</span></button></div>` : ''}
      <div class="chp-body"><button type="button" class="chp-fab" data-act="tobottom" hidden aria-label="${esc(L('انزل لآخر رسالة', 'Jump to the latest message'))}">${ic('down')}<em data-fabn hidden></em></button><div class="chp-msgs" data-msgs aria-live="polite">${st.more ? `<button type="button" class="chp-older" data-act="older">${esc(L('عرض الرسائل الأقدم', 'Show older messages'))}</button>` : ''}${msgsHtml()}</div></div>
      ${composeHtml()}`;
    hydrate(main); scrollEnd(true); paintInfo();
    const ta = main.querySelector('[data-text]'); if (ta && st.draft) { ta.value = st.draft; grow(ta); }
  }
  /** Things that change often (typing, pinned, read ticks) without redrawing the conversation. */
  function paintLive() {
    const sub = main.querySelector('[data-sub]'); if (sub && st.ch) sub.innerHTML = subTxt(st.ch);
    const pb = main.querySelector('[data-pinbox]'); if (pb) { const hh = pinHtml(); if (pb.dataset.html !== hh) { pb.innerHTML = hh; pb.dataset.html = hh; } }
    main.querySelectorAll('.chp-msg.is-mine[data-seq]').forEach((x) => { const seen = Number(x.dataset.seq) <= st.seenUpTo; const t = x.querySelector('.chp-ticks'); if (t && t.classList.contains('is-seen') !== seen) { t.classList.toggle('is-seen', seen); t.innerHTML = ic(seen ? 'check2' : 'check', 'is-xs'); t.setAttribute('aria-label', seen ? L('انقرت', 'Read') : L('انبعتت', 'Sent')); } });
  }

  // each sender keeps one colour for name and avatar (stable from their id), like a real group chat
  const HUES = ['#f472b6', '#60a5fa', '#34d399', '#fbbf24', '#a78bfa', '#fb923c', '#22d3ee', '#f87171'];
  const hueOf = (id) => { let x = 0; for (const ch of String(id || '')) x = (x * 31 + ch.charCodeAt(0)) >>> 0; return HUES[x % HUES.length]; };
  const fmtDur = (s) => (s ? `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')}` : '');
  const sameGroup = (a, b) => a && b && !a.sys && !b.sys && a.uid === b.uid && Math.abs(b.at - a.at) < 5 * 60_000 && fmtDay(a.at) === fmtDay(b.at);
  // which way the text runs decides on which side the time sits (an English line in the Arabic page keeps it on the right)
  const txtDir = (t) => { const m = /[A-Za-z\u00C0-\u024F]|[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/.exec(t || ''); return !m ? '' : /[A-Za-z\u00C0-\u024F]/.test(m[0]) ? ' t-ltr' : ' t-rtl'; };
  const TTL_NAMES = { 86400: L('يوم', 'a day'), 604800: L('أسبوع', 'a week'), 2592000: L('شهر', 'a month') };
  const fmtSize = (n) => (!n ? '' : n < 1024 ? `${n} B` : n < 1048576 ? `${(n / 1024).toFixed(0)} KB` : `${(n / 1048576).toFixed(1)} MB`);
  // links stay text (never clickable HTML from others), @mentions are highlighted
  // links become real links (http and https only, opened in a new tab without access to this page); @mentions are highlighted
  const fmtText = (t) => esc(t).replace(/(^|\s)(@[^\s@]{1,40}(?: [^\s@]{1,40})?)/g, (x, a, b) => `${a}<span class="chp-at">${b}</span>`)
    .replace(/\bhttps?:\/\/[^\s<]{2,300}/g, (u) => { const clean = u.replace(/[.,!?)\]]+$/, ''); return `<a class="chp-link" href="${clean}" target="_blank" rel="noopener noreferrer nofollow ugc" dir="ltr">${clean}</a>${u.slice(clean.length)}`; });
  const firstUrl = (t) => /\bhttps?:\/\/[^\s<>"']{2,300}/.exec(t || '')?.[0]?.replace(/[.,!?)\]]+$/, '') || null;
  function voiceHtml(m) {
    let x = 0; for (const ch of m.id) x = (x * 33 + ch.charCodeAt(0)) >>> 0;
    const bars = Array.from({ length: 34 }, (_, i) => { x = (x * 1103515245 + 12345) >>> 0; return 22 + ((x >>> 8) % 70) * (0.55 + 0.45 * Math.sin((i / 34) * Math.PI)); });
    return `<div class="chp-voice" data-voice="${esc(m.file)}"><button type="button" class="chp-voice-play" data-vplay aria-label="${esc(L('شغّل', 'Play'))}">${ic('play')}</button>
      <span class="chp-voice-mid"><span class="chp-wave" dir="ltr" data-vseek role="slider" tabindex="0" aria-label="${esc(L('مكان التشغيل', 'Playback position'))}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">${bars.map((hh) => `<i style="height:${hh.toFixed(0)}%"></i>`).join('')}</span>
      <span class="chp-voice-meta"><time data-vtime>${esc(fmtDur(m.dur) || '0:00')}</time><button type="button" class="chp-speed" data-vspeed aria-label="${esc(L('السرعة', 'Speed'))}">1x</button></span></span></div>`;
  }
  function pollHtml(m) {
    const p = m.poll; const admin = st.ch?.role === 'admin'; const show = p.voted || p.closed;
    return `<div class="chp-poll${show ? ' is-shown' : ''}"><b class="chp-poll-q" dir="auto">${esc(p.q)}</b><small class="chp-poll-kind">${esc([p.anon ? L('بدون أسماء', 'Anonymous') : L('بالأسماء', 'Public'), p.multi ? L('أكثر من خيار', 'Multiple answers') : '', p.closed ? L('مسكّر', 'Closed') : ''].filter(Boolean).join(' · '))}</small>
      <div class="chp-poll-opts">${p.options.map((o, i) => { const pc = p.total ? Math.round((o.n / p.total) * 100) : 0; return `<button type="button" class="chp-poll-opt${o.mine ? ' is-mine' : ''}" data-vote="${esc(m.id)}" data-opt="${i}" ${p.closed ? 'disabled' : ''} aria-pressed="${o.mine}" style="--pc:${show ? pc : 0}%"><span class="chp-poll-box" aria-hidden="true">${o.mine ? ic('check', 'is-xs') : ''}</span><span class="chp-poll-t" dir="auto">${esc(o.t)}</span>${show ? `<span class="chp-poll-pc">${pc}%</span>` : ''}${show && !p.anon && o.who.length ? `<small class="chp-poll-who">${esc(o.who.filter(Boolean).join('، '))}${o.n > o.who.length ? ' …' : ''}</small>` : ''}</button>`; }).join('')}</div>
      <div class="chp-poll-foot"><small>${esc(L(`${p.total} صوت`, `${p.total} vote${p.total === 1 ? '' : 's'}`))}</small>${!p.closed && (m.uid === me() || admin) ? `<button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-pollclose="${esc(m.id)}">${esc(L('سكّر التصويت', 'Close poll'))}</button>` : ''}</div></div>`;
  }
  /** Everything one message offers, in Telegram's order; delete comes last, in red. */
  function menuItems(m) {
    const mine = m.uid === me(); const admin = st.ch?.role === 'admin'; const priv = isPriv(st.ch); const sec = st.ch?.type === 'secret';
    const canPin = (admin || priv) && !m.deleted; const canEdit = mine && !m.deleted && m.text && Date.now() - m.at < 48 * 3600_000 && !m.poll;
    const it = (attr, icon, label, extra = '') => ({ attr: `${attr}="${esc(m.id)}"${extra}`, icon, label });
    return [
      !(st.ch?.type === 'channel' && !admin) && it('data-reply', 'reply', L('رد', 'Reply')),
      m.text && it('data-copy', 'copy', L('نسخ النص', 'Copy text')),
      canEdit && it('data-edit', 'edit', L('تعديل', 'Edit')),
      canPin && it('data-pin', 'pin', st.pinned?.id === m.id ? L('شيل التثبيت', 'Unpin') : L('تثبيت', 'Pin')),
      !m.poll && !sec && it('data-fwd', 'forward', L('تحويل', 'Forward')),
      !m.poll && !sec && st.ch?.type !== 'saved' && it('data-save', 'bookmark', L('حفظ بالمحفوظات', 'Save to Saved')),
      m.text && !mine && !sec && it('data-tr', 'globe', L('ترجمة', 'Translate')),
      m.file && !sec && (m.kind === 'image' || (!m.kind && m.file)) && !m.sticker && it('data-mkstk', 'sticker', L('اعملها ستيكر', 'Make a sticker')),
      mine && !priv && st.ch?.type !== 'channel' && (st.ch?.members || 0) <= 100 && it('data-readers', 'eye', L('مين قرأ', 'Seen by')),
      it('data-selstart', 'check', L('تحديد', 'Select')),
      !mine && st.ch?.type !== 'saved' && !sec && it('data-report', 'flag', L('إبلاغ', 'Report')),
      { ...it('data-del', 'trash', L('حذف', 'Delete')), danger: true },
    ].filter(Boolean);
  }
  function openMsgMenu(mid, at = null) {
    const m = st.msgs.find((x) => x.id === mid); if (!m || m.deleted || m.pendingLocal) return; closeMsgMenu();
    const bub = main.querySelector(`.chp-msg[data-mid="${CSS.escape(mid)}"] .chp-bubble`); bub?.closest('.chp-msg')?.classList.add('is-menu');
    const reacts = (st.list?.reactions || ['👍', '❤️', '🔥', '😂', '😮', '🙏', '🚀', '📈']);
    const bg = h(`<div class="chp-mm-bg"><div class="chp-mm" role="menu" aria-label="${esc(L('خيارات الرسالة', 'Message options'))}">
      <div class="chp-mm-reacts">${reacts.map((e) => `<button type="button" role="menuitem" data-react="${esc(m.id)}" data-emoji="${e}" aria-label="${e}">${e}</button>`).join('')}</div>
      <div class="chp-mm-list">${menuItems(m).map((x) => `<button type="button" role="menuitem" class="chp-mm-item${x.danger ? ' is-danger' : ''}" ${x.attr}>${ic(x.icon, 'is-sm')}<span>${esc(x.label)}</span></button>`).join('')}</div></div></div>`);
    document.body.append(bg); bg.addEventListener('click', onClick); bg.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') closeMsgMenu(); }); const mm = bg.querySelector('.chp-mm');   // above the site's top bar too
    // place it next to the message (or the pointer), flipped and clamped so it always fits on screen
    const vw = window.innerWidth; const vh = window.visualViewport?.height || window.innerHeight; const r = at || bub?.getBoundingClientRect() || { left: vw / 2, right: vw / 2, top: vh / 2, bottom: vh / 2 };
    const w = mm.offsetWidth; const hh = mm.offsetHeight; const pad = 10;
    let x = at ? at.left : (document.dir === 'rtl' ? r.right - w : r.left); x = Math.max(pad, Math.min(vw - w - pad, x));
    let y = at ? at.top : r.bottom + 8; if (y + hh > vh - pad) y = Math.max(pad, (at ? at.top : r.top) - hh - 8); if (y < pad) y = pad;
    mm.style.left = `${x}px`; mm.style.top = `${y}px`;
    mm.querySelector('.chp-mm-item, button')?.focus({ preventScroll: true });
  }
  function closeMsgMenu() { document.querySelectorAll('.chp-mm-bg').forEach((x) => x.remove()); main.querySelectorAll('.chp-msg.is-menu').forEach((x) => x.classList.remove('is-menu')); }
  /* select mode: tick messages, then forward / copy / delete them together */
  function selBarHtml() {
    const n = st.sel?.size || 0; const all = [...(st.sel || [])].map((id) => st.msgs.find((m) => m.id === id)).filter(Boolean);
    const canAll = all.length && all.every((m) => m.uid === me() || st.ch?.perms?.delete || st.ch?.role === 'admin' || isOne(st.ch));
    return `<div class="chp-selbar"><button type="button" class="chp-icbtn" data-act="selcancel" aria-label="${esc(L('إلغاء التحديد', 'Cancel selection'))}">${ic('x')}</button><b>${esc(L(`${n} محدّدة`, `${n} selected`))}</b>
      <span class="chp-selbar-acts">${st.ch?.type !== 'secret' ? `<button type="button" class="chp-icbtn" data-act="selfwd" aria-label="${esc(L('حوّلهم', 'Forward them'))}" title="${esc(L('حوّلهم', 'Forward them'))}" ${n ? '' : 'disabled'}>${ic('forward')}</button>` : ''}
      <button type="button" class="chp-icbtn" data-act="selcopy" aria-label="${esc(L('انسخهم', 'Copy them'))}" title="${esc(L('انسخهم', 'Copy them'))}" ${n ? '' : 'disabled'}>${ic('copy')}</button>
      <button type="button" class="chp-icbtn chp-sel-del" data-act="seldel" data-all="${canAll ? 1 : 0}" aria-label="${esc(L('احذفهم', 'Delete them'))}" title="${esc(L('احذفهم', 'Delete them'))}" ${n ? '' : 'disabled'}>${ic('trash')}</button></span></div>`;
  }
  function paintSel() {
    const box = main.querySelector('[data-selbox]'); if (box) box.innerHTML = st.sel ? selBarHtml() : '';
    el.classList.toggle('is-selecting', Boolean(st.sel));
    main.querySelectorAll('.chp-msg[data-mid]').forEach((x) => x.classList.toggle('is-sel', Boolean(st.sel?.has(x.dataset.mid))));
  }
  const isAdminUid = (uid) => Boolean(st.ch?.admins?.some((a) => a.uid === uid));
  function msgHtml(m, i, arr = st.msgs) {
    const uid = me(); const admin = st.ch?.role === 'admin';
    if (m.sys) { const SYS = { created: L(`${m.a} عمل المجموعة`, `${m.a} created the group`), added: L(`${m.a} ضاف ${m.b}`, `${m.a} added ${m.b}`), removed: L(`${m.a} شال ${m.b}`, `${m.a} removed ${m.b}`), left: L(`${m.a} طلع من المجموعة`, `${m.a} left`),
      call_start: L(`${m.a} بلّش مكالمة`, `${m.a} started a call`), call_end: L('المكالمة خلصت', 'The call ended'), banned: L(`${m.a} حظر ${m.b}`, `${m.a} banned ${m.b}`), muted: L(`${m.a} كتم ${m.b}`, `${m.a} muted ${m.b}`), joined: L(`${m.a} انضم بالرابط`, `${m.a} joined via link`), secret_start: L(`🔒 ${m.a} بلّش محادثة سرية`, `🔒 ${m.a} started a secret chat`), secret_ready: L('🔒 المحادثة السرية جاهزة. الرسائل مشفّرة بين الطرفين.', '🔒 Secret chat ready. Messages are end-to-end encrypted.'), ttl: m.b === '0' ? L(`${m.a} وقّف اختفاء الرسائل`, `${m.a} turned off disappearing messages`) : L(`${m.a} خلّى الرسائل الجديدة تختفي بعد ${TTL_NAMES[m.b] || ''}`, `${m.a} set new messages to disappear after ${TTL_NAMES[m.b] || ''}`) };
      return `<div class="chp-sys" data-mid="${esc(m.id)}"><span>${m.sys.startsWith('call') ? ic('call', 'is-sm') : ''}${esc(SYS[m.sys] || '')}</span></div>`; }
    const mine = m.uid === uid; const first = !sameGroup(arr[i - 1], m) || Boolean(m.replyTo); const last = !sameGroup(m, arr[i + 1]);
    const visual = m.kind === 'image' || m.kind === 'video' || (!m.kind && m.file);
    const bare = (m.round && !m.deleted) || Boolean(visual && m.file && !m.text && !m.deleted && !m.replyTo && !m.fwd) || (m.sticker && !m.deleted);
    const priv = isPriv(st.ch); const meUid = me();   // a photo or video on its own: no bubble around it
    const ticks = m.pendingLocal ? `<span class="chp-ticks is-wait" aria-label="${esc(L('بانتظار النت', 'Waiting for connection'))}">${ic('clock', 'is-xs')}</span>` : mine && !m.deleted ? (() => { const seen = m.seq <= st.seenUpTo; return `<span class="chp-ticks${seen ? ' is-seen' : ''}" aria-label="${esc(seen ? L('انقرت', 'Read') : L('انبعتت', 'Sent'))}">${ic(seen ? 'check2' : 'check', 'is-xs')}</span>`; })() : '';
    const time = `${m.edited && !m.deleted ? `<span class="chp-edited">${esc(L('معدّلة', 'edited'))}</span>` : ''}<time>${esc(fmtTime(m.at))}</time>${ticks}`;
    const canPin = admin && !m.deleted; const canEdit = mine && !m.deleted && m.text && Date.now() - m.at < 48 * 3600_000;
    // desktop hover bar: react, reply, and "more" (the full labelled menu, also on right-click / tap)
    const acts = m.deleted || m.pendingLocal ? '' : `<span class="chp-acts" role="toolbar" aria-label="${esc(L('خيارات الرسالة', 'Message actions'))}">
        <button type="button" data-react-open="${esc(m.id)}" aria-label="${esc(L('تفاعل', 'React'))}" title="${esc(L('تفاعل', 'React'))}">${ic('smile', 'is-sm')}</button>
        ${st.ch?.type === 'channel' && !admin ? '' : `<button type="button" data-reply="${esc(m.id)}" aria-label="${esc(L('رد', 'Reply'))}" title="${esc(L('رد', 'Reply'))}">${ic('reply', 'is-sm')}</button>`}
        <button type="button" data-msgmenu="${esc(m.id)}" aria-label="${esc(L('خيارات أكثر', 'More options'))}" title="${esc(L('خيارات أكثر', 'More options'))}" aria-haspopup="menu">${ic('more', 'is-sm')}</button></span>`;
    void canPin; void canEdit;
    const media = m.deleted ? '' : m.poll ? pollHtml(m) : !m.file ? '' : m.kind === 'voice' ? voiceHtml(m) : m.kind === 'file' ? `<button type="button" class="chp-doc" data-doc="${esc(m.file)}" data-name="${esc(m.fileName || 'file')}"><span class="chp-doc-ic">${ic('doc')}</span><span class="chp-doc-txt"><b dir="auto">${esc(m.fileName || 'file')}</b><small dir="ltr">${esc(fmtSize(m.size))}</small></span><span class="chp-doc-dl" aria-hidden="true">${ic('dl', 'is-sm')}</span></button>` : m.kind === 'video'
      ? `<button type="button" class="chp-vid${m.poster ? ' has-poster' : ''}${m.round ? ' is-round' : ''}" data-play="${esc(m.file)}" aria-label="${esc(L('شغّل الفيديو', 'Play the video'))}">${m.poster ? `<img data-file="${esc(st.open)}:${esc(m.poster)}" alt="" loading="lazy">` : ''}<span class="chp-vid-play">${ic('play')}</span>${m.dur ? `<span class="chp-vid-dur">${esc(fmtDur(m.dur))}</span>` : `<span class="chp-vid-dur">${ic('video', 'is-sm')}</span>`}${bare ? `<span class="chp-overlay">${time}</span>` : ''}</button>`
      : `<button type="button" class="chp-imgbtn" data-zoom="${esc(m.file)}" aria-label="${esc(L('كبّر الصورة', 'Open the image'))}"><img data-file="${esc(st.open)}:${esc(m.file)}" alt="${esc(L('صورة من', 'Photo from'))} ${esc(m.name)}" loading="lazy">${bare ? `<span class="chp-overlay">${time}</span>` : ''}</button>`;
    const avatar = !mine && !priv ? (last ? `<span class="chp-ava" style="--h:${hueOf(m.uid)}" aria-hidden="true"${avAttr(m.uid)}>${esc((m.name || '?').trim().charAt(0).toUpperCase())}</span>` : '<span class="chp-ava is-gap" aria-hidden="true"></span>') : '';
    const crown = m.bot ? `<span class="chp-botbadge">${ic('bot', 'is-xs')}${esc(L('بوت', 'bot'))}</span>` : isAdminUid(m.uid) ? `<span class="chp-crown">${ic('crown', 'is-xs')}${esc(L('مشرف', 'Admin'))}</span>` : '';
    const quote = m.replyTo && !m.deleted ? `<button type="button" class="chp-quote" data-goto="${esc(m.replyTo.id)}" style="--h:${hueOf(m.replyTo.uid)}"><b>${esc(m.replyTo.name)}</b><span dir="auto">${esc(m.replyTo.text || (m.replyTo.kind === 'video' ? L('فيديو', 'Video') : L('صورة', 'Photo')))}</span></button>` : '';
    const reacts = (m.reactions || []).length && !m.deleted ? `<span class="chp-reacts">${m.reactions.map((r) => `<button type="button" class="chp-react${r.mine ? ' is-mine' : ''}" data-react="${esc(m.id)}" data-emoji="${esc(r.e)}" aria-pressed="${r.mine}" aria-label="${esc(`${r.e} ${r.n}`)}">${esc(r.e)}<b>${r.n}</b></button>`).join('')}</span>` : '';
    const fwdTag = m.fwd && !m.deleted ? `<span class="chp-fwd">${ic('forward', 'is-xs')}${esc(L(`محوّلة من ${m.fwd.name}`, `Forwarded from ${m.fwd.name}`))}</span>` : '';
    const head = !mine && first && !bare && !priv ? `<span class="chp-who"><b class="chp-name" style="--h:${hueOf(m.uid)}">${esc(m.name)}</b>${crown}</span>` : '';
    return `<div class="chp-msg${mine ? ' is-mine' : ''}${st.sel?.has(m.id) ? ' is-sel' : ''}${(m.mentions || []).includes(meUid) ? ' is-mentioned' : ''}${priv ? ' is-priv' : ''}${first ? ' is-first' : ''}${last ? ' is-last' : ''}" data-mid="${esc(m.id)}" data-seq="${m.seq}">${avatar}
      <div class="chp-bubble${bare ? ' is-bare' : ''}${m.sticker ? ' is-sticker' : ''}${m.file && (m.text || m.replyTo) ? ' has-media' : ''}${m.text && !m.deleted ? ` has-text${txtDir(m.text)}` : ''}${m.edited && !m.deleted ? ' is-edited' : ''}${reacts ? ' has-reacts' : ''}${st.ch?.type === 'channel' && !m.deleted ? ' has-cmt' : ''}" tabindex="-1">${head}${fwdTag}${quote}
        ${m.locked ? `<i class="chp-deleted">${ic('lock', 'is-sm')} ${esc(L('مشفّرة لجهاز تاني', 'Encrypted for another device'))}</i>` : m.deleted ? `<i class="chp-deleted">${ic('trash', 'is-sm')} ${esc(L('الرسالة انحذفت', 'Message deleted'))}</i>` : `${media}${m.text ? `<p dir="auto">${fmtText(m.text)}</p>` : ''}${m.text && st.ch?.type !== 'secret' && firstUrl(m.text) ? `<div class="chp-lp" data-lp="${esc(firstUrl(m.text))}" hidden></div>` : ''}${st.ch?.type === 'channel' && !m.deleted && !m.sys ? `<button type="button" class="chp-cmt-btn" data-comments="${esc(m.id)}">${ic('chat', 'is-xs')}<span>${esc(m.comments ? L(`${m.comments} تعليق`, `${m.comments} comment${m.comments === 1 ? '' : 's'}`) : L('اكتب تعليق', 'Leave a comment'))}</span></button>` : ''}${st.tr?.[m.id] ? `<div class="chp-tr" dir="auto"><small>${ic('globe', 'is-xs')} ${esc(L('ترجمة آلية (AI)', 'Machine translation (AI)'))}</small>${esc(st.tr[m.id])}</div>` : ''}`}
        ${reacts}${bare ? '' : `<span class="chp-meta">${time}</span>`}${acts}</div></div>`;
  }
  // with topics, the conversation shows one topic at a time (General = messages without a topic, and the group's own notices)
  const visibleMsgs = () => (st.ch?.topics?.length ? st.msgs.filter((m) => (m.topic || null) === (st.topic || null)) : st.msgs);
  function msgsHtml() {
    if (!st.msgs.length) return `<div class="chp-first"><span class="chp-first-mark" aria-hidden="true">${ic('chat')}</span><b>${esc(L('ما في رسائل لسا', 'No messages yet'))}</b><span>${esc(L('اكتب أول رسالة، أو ابعت صورة أو فيديو.', 'Write the first message, or send a photo or video.'))}</span></div>`;
    let day = ''; const arr = visibleMsgs();
    return arr.map((m, i) => { const d = fmtDay(m.at); const sep = d !== day ? `<div class="chp-day"><span>${esc(d)}</span></div>` : ''; day = d; return sep + msgHtml(m, i, arr); }).join('');
  }

  const swatches = (cur, attr) => `<div class="chp-swatches" role="radiogroup" aria-label="${esc(L('لون القناة', 'Channel colour'))}">${CHANNEL_COLORS.map((c) => `<button type="button" role="radio" aria-checked="${c === cur}" class="chp-sw" style="--sw:${c}" ${attr}="${c}" aria-label="${c}"></button>`).join('')}
    <label class="chp-sw chp-sw-custom" title="${esc(L('لون خاص', 'Custom colour'))}">${ic('palette', 'is-sm')}<input type="color" value="${esc(cur)}" ${attr}-custom aria-label="${esc(L('لون خاص', 'Custom colour'))}"></label></div>`;

  const avaRow = (list, max, total) => `<div class="chp-avas">${list.slice(0, max).map((x) => `<span class="chp-ava2${x.online ? ' is-online' : ''}" style="--h:${hueOf(x.uid)}" title="${esc(x.name)}"${avAttr(x.uid, x.av ?? av(x.uid))}>${esc((x.name || '?').trim().charAt(0).toUpperCase())}</span>`).join('')}${total > max ? `<span class="chp-ava2 is-more">+${total - max > 999 ? `${Math.floor((total - max) / 1000)}K` : total - max}</span>` : ''}</div>`;
  const lastSeen = (x) => (x.online ? L('متصل هلأ', 'online') : x.seenAt ? L(`آخر ظهور ${fmtDay(x.seenAt)} ${fmtTime(x.seenAt)}`, `last seen ${fmtDay(x.seenAt)} ${fmtTime(x.seenAt)}`) : L('ما فتحها لسا', 'not opened yet'));
  function privInfoHtml() {
    const c = st.ch; const dm = isOne(c);
    return `<div class="chp-panel-head"><b>${esc(c.type === 'secret' ? L('محادثة سرية', 'Secret chat') : dm ? L('معلومات', 'Info') : L('الرسائل المحفوظة', 'Saved messages'))}</b><button type="button" class="chp-icbtn" data-act="settings" aria-label="${esc(L('سكّر', 'Close'))}">${ic('x')}</button></div>
      <div class="chp-info-scroll"><section class="chp-hero">${avatarOf(c, true)}<h2><span dir="auto">${esc(nameOf(c))}</span></h2><p>${subTxt(c)}</p>
        ${dm ? `<button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-act="notify" aria-pressed="${c.notify !== false}">${ic(c.notify === false ? 'belloff' : 'bell', 'is-sm')}<span>${esc(c.notify === false ? L('الإشعارات مسكّرة', 'Notifications off') : L('الإشعارات شغّالة', 'Notifications on'))}</span></button>` : `<p class="chp-desc">${esc(L('احفظ هون أي رسالة من أي محادثة (من زر الحفظ على الرسالة)، أو اكتب ملاحظات وابعت ملفات إلك لحالك. ما حدا غيرك بيشوفها.', 'Save any message here (with the bookmark on a message), or write notes and keep files for yourself. Nobody else sees them.'))}</p>`}</section>
      ${prefsHtml(c)}${sharedHtml()}
      ${c.type === 'secret' ? `<section class="chp-card chp-fp"><h3 class="chp-h3">${ic('lock', 'is-sm')} ${esc(L('مفتاح التشفير', 'Encryption key'))}</h3>${st.fp ? `<div class="chp-fp-emoji" aria-label="${esc(L('صورة المفتاح', 'Key picture'))}">${st.fp.emoji.map((e) => `<span>${e}</span>`).join('')}</div><code class="chp-fp-hex" dir="ltr">${st.fp.hex.join(' ')}</code>` : `<p class="chp-muted">${esc(L('بيطلع لما المحادثة تجهز.', 'Shows once the chat is ready.'))}</p>`}
        <p class="chp-muted">${esc(L('قارن هالصورة مع صاحبك (وجهًا لوجه أو بمكالمة). إذا متطابقة، ما حدا بالنص بيقدر يقرأ رسايلكم، ولا حتى سيرفر الموقع.', 'Compare this picture with your friend (in person or on a call). If it matches, nobody in between can read your messages, not even this site\'s server.'))}</p></section>` : ''}
      ${c.type === 'dm' ? `<section class="chp-card"><button type="button" class="chp-btn chp-btn-ghost chp-btn-wide" data-secret="${esc(c.peer?.uid || '')}">${ic('lock', 'is-sm')}<span>${esc(L('ابدأ محادثة سرية', 'Start a secret chat'))}</span></button></section>` : ''}
      ${dm ? ttlHtml(c) : ''}
      ${dm ? `<section class="chp-card chp-priv-acts"><button type="button" class="chp-btn chp-btn-ghost" data-act="${c.peer?.iBlocked ? 'unblock' : 'block'}">${ic('ban', 'is-sm')}<span>${esc(c.peer?.iBlocked ? L('فك الحظر', 'Unblock') : L('احظر هالشخص', 'Block this person'))}</span></button>
        <button type="button" class="chp-btn chp-btn-ghost" data-act="reportchat">${ic('flag', 'is-sm')}<span>${esc(L('بلّغ عنه', 'Report'))}</span></button></section>` : ''}
      <div class="chp-danger-zone"><button type="button" class="chp-btn chp-btn-ghost" data-act="export">${ic('dl', 'is-sm')}<span>${esc(L('صدّر المحادثة', 'Export chat'))}</span></button><button type="button" class="chp-btn chp-btn-danger" data-act="delete">${ic('trash')}<span>${esc(dm ? L('احذف المحادثة للطرفين', 'Delete chat for both') : L('امسح كل المحفوظات', 'Clear all saved'))}</span></button><p class="chp-muted" data-confirm hidden></p></div></div>`;
  }
  const PERM_NAMES = { info: L('تعديل المعلومات', 'Edit info'), members: L('إضافة وشيل أعضاء', 'Add and remove members'), pin: L('تثبيت', 'Pin'), delete: L('حذف رسائل الغير', 'Delete others\' messages'), ban: L('كتم وحظر', 'Mute and ban'), invite: L('روابط وطلبات', 'Links and requests') };
  const prefsHtml = (c) => `<section class="chp-card chp-prefs"><div class="chp-pref-rows"><button type="button" class="chp-row-btn" data-pref="pinned" aria-pressed="${Boolean(c.pinnedChat)}">${ic('pin', 'is-sm')}<span>${esc(c.pinnedChat ? L('شيلها من فوق', 'Unpin chat') : L('ثبّتها فوق', 'Pin chat'))}</span></button>
      <button type="button" class="chp-row-btn" data-pref="archived" aria-pressed="${Boolean(c.archived)}">${ic('archive', 'is-sm')}<span>${esc(c.archived ? L('طلّعها من الأرشيف', 'Unarchive') : L('أرشفة', 'Archive'))}</span></button></div>
      <h3 class="chp-h3">${ic('mute', 'is-sm')} ${esc(L('كتم الإشعارات', 'Mute notifications'))}</h3><div class="chp-seg" role="radiogroup">${[[0, L('لا', 'Off')], [60, L('ساعة', '1 h')], [480, L('8 ساعات', '8 h')], [-1, L('دايمًا', 'Always')]].map(([v, t]) => `<button type="button" role="radio" data-mute="${v}" aria-checked="${v === -1 ? c.muteUntil === -1 : v === 0 ? !c.muteUntil : false}">${esc(t)}</button>`).join('')}</div>
      ${c.muteUntil > 0 ? `<p class="chp-muted">${esc(L(`مكتومة لحد ${fmtTime(c.muteUntil)}. المنشن بيوصلك برضه.`, `Muted until ${fmtTime(c.muteUntil)}. Mentions still reach you.`))}</p>` : ''}</section>`;
  const SHARED = [['media', L('صور', 'Media')], ['file', L('ملفات', 'Files')], ['voice', L('صوت', 'Voice')], ['link', L('روابط', 'Links')]];
  const sharedHtml = () => `<section class="chp-card"><h3 class="chp-h3">${esc(L('الوسائط المشتركة', 'Shared media'))}</h3><div class="chp-seg" role="tablist">${SHARED.map(([k, t]) => `<button type="button" role="tab" data-shared="${k}" aria-selected="${st.sharedKind === k}" aria-checked="${st.sharedKind === k}">${esc(t)}</button>`).join('')}</div><div class="chp-shared" data-sharedbox>${st.sharedKind ? sharedItems() : `<p class="chp-muted">${esc(L('اختار نوع لتشوف اللي انبعت بالمحادثة.', 'Pick a type to see what was shared here.'))}</p>`}</div></section>`;
  function sharedItems() {
    const it = st.shared; if (!it) return '<div class="chp-skel is-sm"></div>'; if (!it.length) return `<p class="chp-muted">${esc(L('ما في إشي لسا.', 'Nothing yet.'))}</p>`;
    if (st.sharedKind === 'media') return `<div class="chp-shared-grid">${it.map((m) => `<button type="button" class="chp-shared-cell" data-goto="${esc(m.id)}"><img data-file="${esc(st.open)}:${esc(m.kind === 'video' ? (m.poster || m.file) : m.file)}" alt="" loading="lazy">${m.kind === 'video' ? `<span class="chp-vid-dur">${ic('play', 'is-xs')}${esc(fmtDur(m.dur) || '')}</span>` : ''}</button>`).join('')}</div>`;
    if (st.sharedKind === 'link') return `<ul class="chp-shared-list">${it.map((m) => `<li><a href="${esc(m.link)}" target="_blank" rel="noopener noreferrer nofollow" dir="ltr">${esc(m.link)}</a><small>${esc(m.name)} · ${esc(fmtDay(m.at))}</small></li>`).join('')}</ul>`;
    return `<ul class="chp-shared-list">${it.map((m) => `<li><button type="button" class="chp-shared-row" data-goto="${esc(m.id)}">${ic(st.sharedKind === 'file' ? 'doc' : 'mic', 'is-sm')}<span><b dir="auto">${esc(m.fileName || L('رسالة صوتية', 'Voice message'))}</b><small>${esc(m.name)} · ${esc(fmtDay(m.at))}${m.size ? ` · ${esc(fmtSize(m.size))}` : m.dur ? ` · ${esc(fmtDur(m.dur))}` : ''}</small></span></button></li>`).join('')}</ul>`;
  }
  const ttlHtml = (c) => `<section class="chp-card"><h3 class="chp-h3">${ic('timer', 'is-sm')} ${esc(L('رسائل بتختفي', 'Disappearing messages'))}</h3><div class="chp-seg" role="radiogroup">${[[0, L('مطفي', 'Off')], [86400, L('يوم', '1 day')], [604800, L('أسبوع', '1 week')], [2592000, L('شهر', '1 month')]].map(([v, t]) => `<button type="button" role="radio" data-ttl="${v}" aria-checked="${(c.ttl || 0) === v}">${esc(t)}</button>`).join('')}</div><p class="chp-muted">${esc(L('بتنطبق على الرسائل الجديدة بس، وبتختفي عند الكل.', 'Applies to new messages, and they vanish for everyone.'))}</p></section>`;
  function adminToolsHtml(c) {
    const pr = c.perms || {}; const inv = st.invites || []; const reqs = st.requests || [];
    return `${pr.members ? `<section class="chp-card"><form class="chp-form chp-topic-add chp-bot-add" data-addbot><input name="username" dir="ltr" autocomplete="off" required placeholder="@helperbot" aria-label="${esc(L('اسم البوت', 'Bot username'))}"><label class="chp-check"><input type="checkbox" name="admin"> ${esc(L('مشرف', 'Admin'))}</label><button class="chp-btn chp-btn-ghost chp-btn-sm">${ic('bot', 'is-sm')}<span>${esc(L('ضيف بوت', 'Add bot'))}</span></button></form></section>` : ''}${pr.info ? ttlHtml(c) : ''}${pr.info ? `<section class="chp-card"><h3 class="chp-h3">${ic('hash', 'is-sm')} ${esc(L('المواضيع', 'Topics'))} <span>${(c.topics || []).length}</span></h3>
        <ul class="chp-invites">${(c.topics || []).map((t) => `<li><span class="chp-inv-txt"><b>${esc(t.emoji)} ${esc(t.name)}</b></span><button type="button" class="chp-icbtn" data-deltopic="${esc(t.id)}" aria-label="${esc(L(`امسح ${t.name}`, `Remove ${t.name}`))}">${ic('trash')}</button></li>`).join('')}</ul>
        <form class="chp-form chp-topic-add" data-topicadd><input name="emoji" maxlength="8" placeholder="🏖️" aria-label="${esc(L('إيموجي', 'Emoji'))}"><input name="name" maxlength="40" required placeholder="${esc(L('اسم الموضوع', 'Topic name'))}" aria-label="${esc(L('اسم الموضوع', 'Topic name'))}"><button class="chp-btn chp-btn-ghost chp-btn-sm">${esc(L('زيد', 'Add'))}</button></form>
        <p class="chp-muted">${esc(L('المواضيع بتقسم المجموعة الكبيرة لنقاشات مرتّبة. الرسائل بدون موضوع بتضل بـ«عام».', 'Topics split a big group into tidy threads. Messages without one stay in General.'))}</p></section>` : ''}${pr.invite ? `<section class="chp-card"><h3 class="chp-h3">${esc(L('روابط الدعوة', 'Invite links'))} <span>${inv.length}</span></h3>
        <ul class="chp-invites">${inv.map((v) => `<li><span class="chp-inv-txt"><b dir="ltr">…${esc(v.code.slice(-6))}</b><small>${esc([v.approve ? L('بموافقة', 'Needs approval') : L('دخول مباشر', 'Direct join'), v.expires ? L(`لحد ${fmtDay(v.expires)}`, `until ${fmtDay(v.expires)}`) : '', v.max ? `${v.uses}/${v.max}` : L(`${v.uses} دخلوا`, `${v.uses} joined`)].filter(Boolean).join(' · '))}</small></span>
          <button type="button" class="chp-icbtn" data-copyinv="${esc(v.code)}" aria-label="${esc(L('انسخ الرابط', 'Copy link'))}">${ic('copy')}</button><button type="button" class="chp-icbtn" data-dropinv="${esc(v.code)}" aria-label="${esc(L('الغي الرابط', 'Revoke link'))}">${ic('trash')}</button></li>`).join('')}</ul>
        <form class="chp-form" data-invite><div class="chp-2col"><label>${esc(L('المدة', 'Expires'))}<select name="hours"><option value="0">${esc(L('بدون نهاية', 'Never'))}</option><option value="24">${esc(L('يوم', '1 day'))}</option><option value="168">${esc(L('أسبوع', '1 week'))}</option><option value="720">${esc(L('شهر', '1 month'))}</option></select></label>
          <label>${esc(L('عدد المرات', 'Uses'))}<select name="max"><option value="0">${esc(L('بلا حد', 'Unlimited'))}</option><option value="1">1</option><option value="10">10</option><option value="100">100</option></select></label></div>
          <label class="chp-check"><input type="checkbox" name="approve"> ${esc(L('لازم أوافق على كل طلب', 'I approve each request'))}</label><button class="chp-btn chp-btn-ghost">${ic('link', 'is-sm')}<span>${esc(L('اعمل رابط', 'Create link'))}</span></button></form></section>` : ''}
      ${pr.invite && reqs.length ? `<section class="chp-card"><h3 class="chp-h3">${esc(L('طلبات الانضمام', 'Join requests'))} <span>${reqs.length}</span></h3><ul class="chp-members">${reqs.map((x) => `<li><span class="chp-avatar" style="--h:${hueOf(x.uid)}" aria-hidden="true">${esc((x.name || '?').charAt(0).toUpperCase())}</span><span class="chp-member-txt"><b>${esc(x.name)}</b><small dir="ltr">${esc(x.email || '')}</small></span>
        <span class="chp-member-act"><button type="button" class="chp-btn chp-btn-primary chp-btn-sm" data-req="${esc(x.uid)}" data-accept="1">${esc(L('اقبل', 'Accept'))}</button><button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-req="${esc(x.uid)}" data-accept="0">${esc(L('ارفض', 'Decline'))}</button></span></li>`).join('')}</ul></section>` : ''}
      <details class="chp-card chp-fold" data-logfold><summary>${ic('shield', 'is-sm')}<span>${esc(L('سجل المشرفين', 'Admin log'))}</span></summary><ul class="chp-log" data-log>${st.log ? (st.log.length ? st.log.map((x) => `<li><b>${esc(x.by)}</b> ${esc(LOG_NAMES[x.act] || x.act)}${x.target ? ` <i>${esc(x.target)}</i>` : ''}<time>${esc(fmtDay(x.at))} ${esc(fmtTime(x.at))}</time></li>`).join('') : `<li class="chp-muted">${esc(L('ما في إشي لسا.', 'Nothing yet.'))}</li>`) : '<li class="chp-skel is-sm"></li>'}</ul></details>`;
  }
  const LOG_NAMES = { settings: L('عدّل الإعدادات', 'changed settings'), add: L('ضاف', 'added'), remove: L('شال', 'removed'), promote: L('خلّى مشرف', 'made admin'), demote: L('رجّع عضو', 'made member'), perms: L('غيّر صلاحيات', 'changed permissions of'), delete: L('حذف رسالة لـ', 'deleted a message by'), pin: L('ثبّت رسالة', 'pinned a message'), unpin: L('شال التثبيت', 'unpinned'),
    ban: L('حظر', 'banned'), unban: L('فك حظر', 'unbanned'), mute: L('كتم', 'muted'), unmute: L('فك كتم', 'unmuted'), invite: L('عمل رابط دعوة', 'created an invite link'), invite_off: L('لغى رابط دعوة', 'revoked an invite link'), accept: L('قبل', 'accepted'), decline: L('رفض', 'declined') };
  function settingsHtml() {
    if (isPriv(st.ch)) return privInfoHtml();
    const c = st.ch; const admin = c.role === 'admin'; const mm = st.members; const owner = Boolean(st.list?.owner);
    const admins = (mm || c.admins || []).filter((x) => !mm || x.role === 'admin');
    const tags = [CAT[c.category] || CAT.general, c.type === 'channel' ? L('قناة بث', 'Broadcast') : L('مجموعة', 'Group'), c.access === 'plan' ? (c.minRank ? PLAN_NAMES[c.minRank] : L('مفتوحة للأعضاء', 'Open to members')) : L('بالدعوة', 'Invite only')];
    return `<div class="chp-panel-head"><b>${esc(c.type === 'channel' ? L('معلومات القناة', 'Channel info') : L('معلومات المجموعة', 'Group info'))}</b><button type="button" class="chp-icbtn" data-act="settings" aria-label="${esc(L('سكّر', 'Close'))}">${ic('x')}</button></div>
      <div class="chp-info-scroll">
      <section class="chp-hero">${logoHtml(c, true)}<h2><span dir="auto">${esc(c.name)}</span>${verified(c)}</h2><p>${esc(membersTxt(c.members))}${c.online ? ` <span class="chp-dot-sep" aria-hidden="true"></span> ${esc(L(`متصل: ${c.online}`, `Online: ${c.online}`))}` : ''}</p>
        ${c.description ? `<p class="chp-desc" dir="auto">${esc(c.description)}</p>` : admin ? `<p class="chp-muted">${esc(L('ما في وصف لسا. ضيف واحد من «تعديل التفاصيل» تحت.', 'No description yet. Add one in "Edit details" below.'))}</p>` : ''}
        <div class="chp-tags">${tags.map((t) => `<span class="chp-tag">${esc(t)}</span>`).join('')}</div></section>
      ${prefsHtml(c)}${sharedHtml()}
      ${c.rules ? `<details class="chp-card chp-rules"><summary>${esc(L('قواعد المجموعة', 'Group rules'))}</summary><p dir="auto">${esc(c.rules)}</p></details>` : ''}
      <section class="chp-card"><h3 class="chp-h3">${esc(L('المشرفين', 'Admins'))} <span>${admins.length}</span></h3>${avaRow(admins, 6, admins.length)}</section>
      <section class="chp-card"><h3 class="chp-h3">${esc(L('الأعضاء', 'Members'))} <span>${c.members}</span></h3>${mm ? avaRow(mm.filter((x) => x.role !== 'admin').sort((a, b) => Number(b.online) - Number(a.online)), 6, mm.filter((x) => x.role !== 'admin').length) : '<div class="chp-skel is-sm"></div>'}</section>
      ${admin ? `<details class="chp-card chp-fold"><summary>${ic('edit', 'is-sm')}<span>${esc(L('تعديل التفاصيل', 'Edit details'))}</span></summary>
          <div class="chp-logo-row">${logoHtml(c, true)}<div class="chp-logo-acts"><label class="chp-btn chp-btn-sm">${esc(L('غيّر الشعار', 'Change logo'))}<input type="file" accept="image/png,image/jpeg,image/webp" data-logo-pick hidden></label>${c.logo ? `<button type="button" class="chp-btn chp-btn-danger chp-btn-sm" data-act="nologo">${esc(L('شيل الشعار', 'Remove logo'))}</button>` : ''}</div></div>
          <form class="chp-form" data-meta>
            <label>${esc(L('الاسم', 'Name'))}<input name="name" maxlength="60" required value="${esc(c.name)}"></label>
            <label>${esc(L('الوصف', 'Description'))}<textarea name="description" maxlength="600" rows="3" dir="auto">${esc(c.description || '')}</textarea></label>
            <label>${esc(L('القواعد', 'Rules'))}<textarea name="rules" maxlength="1500" rows="3" dir="auto">${esc(c.rules || '')}</textarea></label>
            <div class="chp-2col"><label>${esc(L('النوع', 'Type'))}<select name="type"><option value="group"${c.type !== 'channel' ? ' selected' : ''}>${esc(L('مجموعة (الكل بيكتب)', 'Group (everyone writes)'))}</option><option value="channel"${c.type === 'channel' ? ' selected' : ''}>${esc(L('قناة بث (المشرفين بس)', 'Broadcast (admins only)'))}</option></select></label>
            <label>${esc(L('التصنيف', 'Category'))}<select name="category">${Object.entries(CAT).map(([k, v]) => `<option value="${k}"${c.category === k ? ' selected' : ''}>${esc(v)}</option>`).join('')}</select></label></div>
            <div class="chp-2col"><label>${esc(L('مين بيدخل', 'Who can join'))}<select name="access"><option value="members"${c.access !== 'plan' ? ' selected' : ''}>${esc(L('اللي بيضيفهم المشرف', 'People admins add'))}</option><option value="plan"${c.access === 'plan' ? ' selected' : ''}>${esc(L('حسب الاشتراك', 'By subscription'))}</option></select></label>
            <label>${esc(L('أقل اشتراك', 'Lowest plan'))}<select name="minRank">${PLAN_NAMES.map((n, i) => `<option value="${i}"${(c.minRank || 0) === i ? ' selected' : ''}>${esc(n)}</option>`).join('')}</select></label></div>
            <div class="chp-2col"><label>${esc(L('الوضع البطيء', 'Slow mode'))}<select name="slow">${[[0, L('مطفي', 'Off')], [10, L('10 ثواني', '10 s')], [30, L('30 ثانية', '30 s')], [60, L('دقيقة', '1 min')], [300, L('5 دقايق', '5 min')], [900, L('ربع ساعة', '15 min')]].map(([v, t]) => `<option value="${v}"${(c.slow || 0) === v ? ' selected' : ''}>${esc(t)}</option>`).join('')}</select></label>
            <label class="chp-check chp-check-low"><input type="checkbox" name="filterLinks"${c.filterLinks ? ' checked' : ''}> ${esc(L('امنع الروابط للأعضاء', 'Block links for members'))}</label></div>
            <label>${esc(L('كلمات ممنوعة (افصل بفاصلة)', 'Blocked words (comma separated)'))}<textarea name="words" rows="2" maxlength="3000" dir="auto" placeholder="${esc(L('مثلًا: نصب، ربح مضمون', 'e.g. scam, guaranteed profit'))}">${esc((c.words || []).join(', '))}</textarea></label>
            ${owner ? `<label class="chp-check"><input type="checkbox" name="verified"${c.verified ? ' checked' : ''}> ${esc(L('شارة رسمية (موثّقة)', 'Official badge (verified)'))}</label>` : ''}
            <p class="chp-muted">${esc(L('«حسب الاشتراك» بيستعمل اشتراكات الموقع نفسها: اللي اشتراكه بيوصل للمستوى بيدخل لحاله، ولما يخلص اشتراكه بيطلع لحاله.', '"By subscription" uses the site\'s own plans: members whose plan reaches the level get in automatically, and lose access when it expires.'))}</p>
            <button class="chp-btn chp-btn-primary">${esc(L('احفظ', 'Save'))}</button></form>
          <h3 class="chp-h3">${esc(L('اللون', 'Colour'))}</h3>${swatches(colorOf(c), 'data-color')}</details>
        <section class="chp-card"><form class="chp-form" data-add><label>${esc(L('ضيف عضو بإيميل حسابه', 'Add a member by their account e-mail'))}<input name="email" type="email" required autocomplete="off" placeholder="name@email.com" dir="ltr"></label>
          <label class="chp-check"><input type="checkbox" name="admin"> ${esc(L('مشرف', 'Admin'))}</label><button class="chp-btn chp-btn-primary">${esc(L('ضيف', 'Add'))}</button></form></section>${adminToolsHtml(c)}` : ''}
      <section class="chp-card"><h3 class="chp-h3">${esc(L('كل الأعضاء', 'All members'))} <span>${mm ? mm.length : '…'}</span></h3>
      <ul class="chp-members">${(mm || []).map((x) => `<li><span class="chp-avatar${x.online ? ' is-online' : ''}" style="--h:${hueOf(x.uid)}" aria-hidden="true"${avAttr(x.uid, x.av)}>${esc((x.name || '?').charAt(0).toUpperCase())}</span>
          <span class="chp-member-txt"><b>${esc(x.name)}${x.me ? ` <small>(${esc(L('إنت', 'you'))})</small>` : ''}</b><small>${x.username ? `<span dir="ltr">@${esc(x.username)}</span> · ` : ''}${x.email ? `<span dir="ltr">${esc(x.email)}</span> · ` : ''}${esc(lastSeen(x))}${x.muted ? ` · ${esc(L('مكتوم', 'muted'))}` : ''}</small></span>
          ${x.role === 'admin' ? `<em class="chp-role">${ic('crown', 'is-xs')}${esc(x.creator ? L('المنشئ', 'Owner') : L('مشرف', 'Admin'))}</em>` : ''}
          ${x.bot ? `<em class="chp-role chp-botrole">${ic('bot', 'is-xs')}${esc(L('بوت', 'Bot'))}</em>` : ''}
          ${!x.me && !x.bot ? `<button type="button" class="chp-icbtn chp-dm-btn" data-dm="${esc(x.uid)}" aria-label="${esc(L(`راسل ${x.name}`, `Message ${x.name}`))}" title="${esc(L('رسالة خاصة', 'Private message'))}">${ic('chat', 'is-sm')}</button>` : ''}
          ${c.creator && x.role === 'admin' && !x.me && x.perms ? `<details class="chp-perms"><summary>${esc(L('صلاحياته', 'Permissions'))}</summary><form data-perms="${esc(x.uid)}">${Object.entries(PERM_NAMES).map(([k, t]) => `<label class="chp-check"><input type="checkbox" name="${k}"${x.perms[k] ? ' checked' : ''}> ${esc(t)}</label>`).join('')}<button class="chp-btn chp-btn-primary chp-btn-sm">${esc(L('احفظ', 'Save'))}</button></form></details>` : ''}
          ${admin && !x.me ? `<span class="chp-member-act"><button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-role="${esc(x.uid)}" data-to="${x.role === 'admin' ? 'member' : 'admin'}">${esc(x.role === 'admin' ? L('خلّيه عضو', 'Make member') : L('خلّيه مشرف', 'Make admin'))}</button>
            ${x.role !== 'admin' ? `<button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-mod="${esc(x.uid)}" data-do="${x.muted ? 'unmute' : 'mute'}">${esc(x.muted ? L('فك الكتم', 'Unmute') : L('اكتمه يوم', 'Mute 1 day'))}</button>
            <button type="button" class="chp-btn chp-btn-danger chp-btn-sm" data-mod="${esc(x.uid)}" data-do="ban">${esc(L('احظر', 'Ban'))}</button>` : ''}
            <button type="button" class="chp-btn chp-btn-danger chp-btn-sm" data-kick="${esc(x.uid)}">${esc(L('شيله', 'Remove'))}</button></span>` : ''}</li>`).join('')}</ul></section>
      ${admin && st.banned?.length ? `<section class="chp-card"><h3 class="chp-h3">${esc(L('المحظورين', 'Banned'))} <span>${st.banned.length}</span></h3><ul class="chp-members">${st.banned.map((x) => `<li><span class="chp-avatar" aria-hidden="true">${esc((x.name || '?').charAt(0).toUpperCase())}</span><span class="chp-member-txt"><b>${esc(x.name)}</b></span><span class="chp-member-act"><button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-mod="${esc(x.uid)}" data-do="unban">${esc(L('فك الحظر', 'Unban'))}</button></span></li>`).join('')}</ul></section>` : ''}
      <div class="chp-danger-zone"><button type="button" class="chp-btn chp-btn-ghost" data-act="export">${ic('dl', 'is-sm')}<span>${esc(L('صدّر المحادثة', 'Export chat'))}</span></button>${!admin ? `<button type="button" class="chp-btn chp-btn-ghost" data-act="reportchat">${ic('flag', 'is-sm')}<span>${esc(L('بلّغ عن المجموعة', 'Report group'))}</span></button>` : ''}${c.creator || (admin && owner) ? `<button type="button" class="chp-btn chp-btn-danger" data-act="delete">${ic('trash')}<span>${esc(L('احذف المجموعة', 'Delete group'))}</span></button>` : !c.creator ? `<button type="button" class="chp-btn chp-btn-danger" data-act="leave">${esc(L('اطلع من المجموعة', 'Leave group'))}</button>` : ''}
        <p class="chp-muted" data-confirm hidden></p></div></div>`;
  }
  function paintInfo() {
    const show = Boolean(st.info && st.open && st.ch && !st.panel);
    info.hidden = !show; el.classList.toggle('has-info', show);
    if (!show) { info.innerHTML = ''; return; }
    const opens = [...info.querySelectorAll('details')].map((d) => d.open); const y = info.querySelector('.chp-info-scroll')?.scrollTop || 0;
    info.innerHTML = settingsHtml(); hydrate(info);
    info.querySelectorAll('details').forEach((d, i) => { if (opens[i]) d.open = true; });
    const sc = info.querySelector('.chp-info-scroll'); if (sc) sc.scrollTop = y;
    if (!st.members) loadMembers();
  }

  function paintNew() {
    main.innerHTML = `<header class="chp-head"><button type="button" class="chp-icbtn" data-act="cancel" aria-label="${esc(L('رجوع', 'Back'))}">${ic('back')}</button><div class="chp-head-txt"><b>${esc(L('مجموعة أو قناة جديدة', 'New group or channel'))}</b><small>${esc(L('خاصة بالدعوة، أو مربوطة باشتراكات الموقع', 'Invite only, or tied to the site\'s plans'))}</small></div></header>
      <form class="chp-form chp-new" data-create>
        <section class="chp-card chp-new-hero"><span class="chp-new-preview" data-new-preview style="--chc:${esc(st.newColor)}">${st.newLogo ? `<img src="${st.newLogo}" alt="">` : ic('img')}</span>
          <div><label class="chp-btn">${esc(L('ارفع شعار', 'Upload a logo'))}<input type="file" accept="image/png,image/jpeg,image/webp" data-new-logo-pick hidden></label><p class="chp-muted">${esc(L('مربّع، بيتصغّر لحاله.', 'Square; resized automatically.'))}</p></div></section>
        <section class="chp-card chp-form"><label>${esc(L('الاسم', 'Name'))}<input name="name" maxlength="60" required placeholder="${esc(L('مثلًا: فوركس وذهب', 'e.g. Forex & Gold'))}"></label>
          <label>${esc(L('الوصف', 'Description'))}<textarea name="description" maxlength="600" rows="2" dir="auto" placeholder="${esc(L('شو بيصير بهالمجموعة؟', 'What happens in this group?'))}"></textarea></label>
          <div class="chp-2col"><label>${esc(L('النوع', 'Type'))}<select name="type"><option value="group">${esc(L('مجموعة (الكل بيكتب)', 'Group (everyone writes)'))}</option><option value="channel">${esc(L('قناة بث (المشرفين بس)', 'Broadcast (admins only)'))}</option></select></label>
          <label>${esc(L('التصنيف', 'Category'))}<select name="category">${Object.entries(CAT).map(([k, v]) => `<option value="${k}"${k === 'general' ? ' selected' : ''}>${esc(v)}</option>`).join('')}</select></label></div>
          <div class="chp-2col"><label>${esc(L('مين بيدخل', 'Who can join'))}<select name="access"><option value="members">${esc(L('اللي بضيفهم أنا', 'People I add'))}</option><option value="plan">${esc(L('حسب الاشتراك', 'By subscription'))}</option></select></label>
          <label>${esc(L('أقل اشتراك', 'Lowest plan'))}<select name="minRank">${PLAN_NAMES.map((n, i) => `<option value="${i}">${esc(n)}</option>`).join('')}</select></label></div></section>
        <section class="chp-card"><h3 class="chp-h3">${esc(L('لون القناة', 'Channel colour'))}</h3>${swatches(st.newColor, 'data-newcolor')}</section>
        <button class="chp-btn chp-btn-primary chp-btn-wide">${esc(L('اعملها', 'Create'))}</button>
        <p class="chp-muted">${esc(L('بالدعوة: بتضيف الأعضاء بإيميلاتهم. حسب الاشتراك: كل مين اشتراكه بيوصل للمستوى بيدخل لحاله، وبيطلع لما يخلص.', 'Invite only: add members by e-mail. By subscription: everyone whose plan reaches the level gets in, and leaves when it expires.'))}</p></form>`;
    el.style.setProperty('--chc', st.newColor); el.style.setProperty('--chc-ink', inkOn(st.newColor));
  }

  function paintMods() {
    const d = st.mods;
    main.innerHTML = `<header class="chp-head"><button type="button" class="chp-icbtn" data-act="cancel" aria-label="${esc(L('رجوع', 'Back'))}">${ic('back')}</button><div class="chp-head-txt"><b>${esc(L('المشرفين المعتمدين', 'Approved moderators'))}</b><small>${esc(L('هدول بس بيقدروا يعملوا قنوات خاصة (غيرك كمالك)', 'Only they can create private channels (besides the owners)'))}</small></div></header>
      <div class="chp-scroll"><section class="chp-card"><form class="chp-form" data-mod-add><label>${esc(L('إيميل المشرف', 'Moderator e-mail'))}<input name="email" type="email" required autocomplete="off" dir="ltr" placeholder="name@email.com"></label><button class="chp-btn chp-btn-primary">${esc(L('اعتمده', 'Approve'))}</button></form></section>
      <section class="chp-card"><h3 class="chp-h3">${esc(L('المعتمدين', 'Approved'))} <span>${d ? d.mods.length : '…'}</span></h3><ul class="chp-members">${!d ? '' : !d.mods.length ? `<li class="chp-muted">${esc(L('ما في مشرفين معتمدين لسا.', 'No approved moderators yet.'))}</li>` : d.mods.map((x) => `<li><span class="chp-avatar" aria-hidden="true">${esc(x.email.charAt(0).toUpperCase())}</span><span class="chp-member-txt"><b dir="ltr">${esc(x.email)}</b><small>${esc(L(`${x.channels} قناة`, `${x.channels} channels`))}</small></span>
        <span class="chp-member-act"><button type="button" class="chp-btn chp-btn-danger chp-btn-sm" data-unmod="${esc(x.email)}">${esc(L('شيل الاعتماد', 'Withdraw'))}</button></span></li>`).join('')}</ul></section>
      <section class="chp-card"><h3 class="chp-h3">${esc(L('البلاغات', 'Reports'))} <span>${st.reports ? st.reports.length : '…'}</span></h3><ul class="chp-members">${(st.reports || []).map((r) => `<li><span class="chp-avatar" aria-hidden="true">${ic('flag', 'is-sm')}</span><span class="chp-member-txt"><b>${esc(r.by)} → ${esc(r.about || r.channel)}</b><small>${esc(r.channel)} · ${esc(fmtDay(r.at))}${r.text ? ` · «${esc(r.text)}»` : ''}${r.reason ? ` · ${esc(r.reason)}` : ''}</small><small dir="ltr">${esc(r.byEmail || '')}</small></span><span class="chp-member-act"><button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-clearrep="${esc(r.id)}">${esc(L('تمّ', 'Done'))}</button></span></li>`).join('') || `<li class="chp-muted">${esc(L('ما في بلاغات.', 'No reports.'))}</li>`}</ul></section>
      <section class="chp-card"><h3 class="chp-h3">${esc(L('كل القنوات', 'All channels'))} <span>${d ? d.channels.length : '…'}</span></h3>
      <p class="chp-muted">${esc(L('بتشوف الأسماء والأعداد بس، مش الرسائل. فيك تحذف أي قناة.', 'You see names and counts, not messages. You can delete any channel.'))}</p>
      <ul class="chp-members">${(d?.channels || []).map((c) => `<li><span class="chp-avatar" aria-hidden="true">${esc(c.name.charAt(0).toUpperCase())}</span><span class="chp-member-txt"><b>${esc(c.name)}</b><small>${esc(L(`${c.members} عضو · ${c.messages} رسالة`, `${c.members} members · ${c.messages} messages`))}${c.by ? ` · <span dir="ltr">${esc(c.by)}</span>` : ''}</small></span>
        <span class="chp-member-act"><button type="button" class="chp-btn chp-btn-danger chp-btn-sm" data-owner-del="${esc(c.id)}">${esc(L('احذف', 'Delete'))}</button></span></li>`).join('')}</ul></section></div>`;
  }

  /* ── data ── */
  const msgsEl = () => main.querySelector('[data-msgs]');
  function scrollEnd(force = false) { const box = msgsEl(); if (!box) return; const near = box.scrollHeight - box.scrollTop - box.clientHeight < 160; if (force || near) box.scrollTop = box.scrollHeight; }
  function repaintMsgs(stick) {
    const box = msgsEl(); if (!box) return paintMain();
    const near = box.scrollHeight - box.scrollTop - box.clientHeight < 160;
    box.innerHTML = `${st.more ? `<button type="button" class="chp-older" data-act="older">${esc(L('عرض الرسائل الأقدم', 'Show older messages'))}</button>` : ''}${msgsHtml()}`;
    hydrate(box); if (stick || near) box.scrollTop = box.scrollHeight;
  }
  /** New messages at the end are added without redrawing the others (a playing video keeps playing). */
  function appendMsgs() {
    const box = msgsEl(); if (!box) return paintMain();
    const near = box.scrollHeight - box.scrollTop - box.clientHeight < 160;
    const tmp = document.createElement('div'); tmp.innerHTML = msgsHtml(); const items = [...tmp.children];
    let last = -1; items.forEach((x, i) => { if (x.dataset.mid && box.querySelector(`[data-mid="${CSS.escape(x.dataset.mid)}"]`)) last = i; });
    if (last < 0) return repaintMsgs(true);
    box.querySelector('.chp-first')?.remove();
    const prevEl = box.querySelector(`[data-mid="${CSS.escape(items[last].dataset.mid)}"]`);
    if (prevEl && prevEl.classList.contains('chp-msg')) {
      if (!prevEl.querySelector('video')) prevEl.replaceWith(items[last]);
      else {   // a video is playing in it: keep the player, only move the avatar / tail to the group's new last message
        const fresh = items[last]; prevEl.className = fresh.className; const a = prevEl.querySelector('.chp-ava'); const b2 = fresh.querySelector('.chp-ava'); if (a && b2) a.replaceWith(b2);
      }
    }
    for (const x of items.slice(last + 1)) box.append(x);
    if (!near) { st.newBelow = (st.newBelow || 0) + items.slice(last + 1).filter((x) => x.classList.contains('chp-msg')).length; paintFab(); }
    hydrate(box); if (near) box.scrollTop = box.scrollHeight;
  }
  function paintFab() {
    const box = msgsEl(); const fab = main.querySelector('.chp-fab'); if (!box || !fab) return;
    const far = box.scrollHeight - box.scrollTop - box.clientHeight > 320; if (!far) st.newBelow = 0;
    fab.hidden = !far; const n = fab.querySelector('[data-fabn]'); n.hidden = !st.newBelow; n.textContent = st.newBelow > 99 ? '99+' : String(st.newBelow || '');
  }
  /** First frame + length of a video, made in the browser so the others see a real thumbnail before playing. */
  function videoPoster(url) {
    return new Promise((resolve) => {
      const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = url;
      const done = (r) => { clearTimeout(t); v.removeAttribute('src'); v.load(); resolve(r); }; const t = setTimeout(() => done(null), 8000);
      v.onloadeddata = () => { try { v.currentTime = Math.min(0.2, (v.duration || 1) / 3); } catch { done(null); } };
      v.onseeked = () => { const k = Math.min(1, 720 / Math.max(v.videoWidth, v.videoHeight || 1)); const cv = document.createElement('canvas'); cv.width = Math.round(v.videoWidth * k) || 320; cv.height = Math.round(v.videoHeight * k) || 180;
        try { cv.getContext('2d').drawImage(v, 0, 0, cv.width, cv.height); cv.toBlob((b) => done(b ? { blob: b, dur: Number.isFinite(v.duration) ? v.duration : null } : null), 'image/jpeg', 0.8); } catch { done(null); } };
      v.onerror = () => done(null);
    });
  }
  const keepDraft = () => { st.draft = main.querySelector('[data-text]')?.value ?? st.draft; };
  // a draft stays with each chat (on this device) until it is sent
  const draftOf = (id) => { try { return localStorage.getItem(`gt-draft:${id}`) || ''; } catch { return ''; } };
  const saveDraft = (id, v) => { try { if (v && v.trim()) localStorage.setItem(`gt-draft:${id}`, v.slice(0, 4000)); else localStorage.removeItem(`gt-draft:${id}`); } catch { /* private mode */ } };
  async function loadList() {
    try { st.list = await apiRequest('GET', '/api/chat', undefined, 15000); setOffline(false); cachePut('list', st.list); }
    catch (e) { if (OFFLINE_ERR(e)) setOffline(true); if (!st.list) { const cached = cacheGet('list'); if (cached) st.list = cached; else { st.list = { channels: [], canCreate: false }; say(e); } } }
    paintSide(); setBadge();
  }
  /* ── v365: works on a shaky connection (last copy of the list and of each chat, a queue for messages written offline),
        an unread count on the installed app's icon, sharing from other apps, and keyboard shortcuts ── */
  const OFFLINE_ERR = (e) => e?.code === 'server_unreachable' || e?.code === 'timeout' || !navigator.onLine;
  const CK = () => `gt-cache:${st.list?.me || auth.current()?.uid || 'x'}:`;
  const cacheGet = (k) => { try { return JSON.parse(localStorage.getItem(CK() + k) || 'null'); } catch { return null; } };
  function cachePut(k, v) { try { localStorage.setItem(CK() + k, JSON.stringify(v)); } catch { try { for (const x of Object.keys(localStorage)) if (x.startsWith('gt-cache:') && x.includes(':m:')) localStorage.removeItem(x); localStorage.setItem(CK() + k, JSON.stringify(v)); } catch { /* storage full */ } } }
  function cacheChat(id) { const c = st.list?.channels.find((x) => x.id === id) || st.ch; if (!c || c.type === 'secret' || !st.msgs.length) return; cachePut(`m:${id}`, { ch: st.ch, msgs: st.msgs.filter((m) => !m.pendingLocal).slice(-60).map((m) => ({ ...m, poll: m.poll || null })) }); }
  function setOffline(on) { if (st.offline === on) return; st.offline = on; el.classList.toggle('is-offline', on); const b = el.querySelector('[data-offbar]'); if (b) b.hidden = !on; if (!on) flushOutbox(); }
  function setBadge() { const n = (st.list?.channels || []).reduce((a, c) => a + (c.notify === false || c.muteUntil ? 0 : c.unread || 0), 0); try { if (n) navigator.setAppBadge?.(n).catch(() => {}); else navigator.clearAppBadge?.().catch(() => {}); } catch { /* not supported */ } }
  // messages written without a connection wait here (this device) and go out, in order, as soon as the server answers again
  const outboxKey = () => `${CK()}outbox`;
  const outbox = () => { try { return JSON.parse(localStorage.getItem(outboxKey()) || '[]'); } catch { return []; } };
  const saveOutbox = (l) => { try { localStorage.setItem(outboxKey(), JSON.stringify(l.slice(-50))); } catch { /* ignore */ } };
  function queueText(id, text, replyTo) {
    const tmp = { id: `local${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`, ch: id, text, replyTo: replyTo || undefined, at: Date.now() };
    saveOutbox([...outbox(), tmp]);
    if (st.open === id) { st.msgs.push({ id: tmp.id, seq: Number.MAX_SAFE_INTEGER, uid: me(), name: '', text, at: tmp.at, pendingLocal: true, reactions: [] }); repaintMsgs(true); }
    toast(L('ما في نت. الرسالة رح تنبعت لحالها لما يرجع.', 'Offline. The message will go out when you are back online.'), 'info');
  }
  let flushing = false;
  async function flushOutbox() {
    if (flushing) return; const l = outbox(); if (!l.length) return; flushing = true;
    try { for (const x of l) { try { await apiRequest('POST', `/api/chat/${x.ch}/messages`, { text: x.text, replyTo: x.replyTo }, 20000); saveOutbox(outbox().filter((y) => y.id !== x.id)); st.msgs = st.msgs.filter((m) => m.id !== x.id); } catch (e) { if (OFFLINE_ERR(e)) break; saveOutbox(outbox().filter((y) => y.id !== x.id)); st.msgs = st.msgs.filter((m) => m.id !== x.id); say(e); } } }
    finally { flushing = false; if (st.open) repaintMsgs(false); loadList(); }
  }
  window.addEventListener('online', () => { setOffline(false); flushOutbox(); });
  window.addEventListener('offline', () => setOffline(true));
  function merge(r) {
    const del = new Set(r.deleted || []);
    for (const m of st.msgs) if (del.has(m.id)) { m.deleted = true; m.text = ''; m.file = null; }
    const byId = new Map(st.msgs.map((m) => [m.id, m])); let changed = 0;
    for (const m of r.messages || []) { const o = byId.get(m.id); if (o && (o.text !== m.text || o.edited !== m.edited || JSON.stringify(o.reactions || []) !== JSON.stringify(m.reactions || []) || JSON.stringify(o.poll || null) !== JSON.stringify(m.poll || null) || (o.comments || 0) !== (m.comments || 0) || o.deleted !== m.deleted)) { Object.assign(o, m); changed++; } }
    const add = (r.messages || []).filter((m) => !byId.has(m.id));
    if (add.length) st.msgs = [...st.msgs, ...add].sort((a, b) => a.seq - b.seq);
    const before = st.ch; st.ch = r.channel; st.rev = r.rev; live(r);
    const headChanged = before && r.channel && ['role', 'name', 'logo', 'color', 'type', 'verified', 'description', 'rules', 'category', 'access', 'minRank', 'notify'].some((k) => before[k] !== r.channel[k]) || Boolean(before?.call) !== Boolean(r.channel?.call) || (before?.admins || []).map((a) => a.uid).join() !== (r.channel?.admins || []).map((a) => a.uid).join() || Boolean(before?.bigCall) !== Boolean(r.channel?.bigCall) || Boolean(before?.peer?.blockedMe) !== Boolean(r.channel?.peer?.blockedMe) || Boolean(before?.peer?.iBlocked) !== Boolean(r.channel?.peer?.iBlocked);
    return { added: add.length, deleted: del.size + changed, headChanged, mutedChanged: r.mutedChanged };
  }
  function live(r) {
    st.av = { ...(st.av || {}), ...(r.avs || {}) }; st.recording = Boolean(r.recording); st.schedN = r.scheduled || 0;
    const was = st.mutedUntil; st.pinned = r.pinned || null; st.typing = r.typing || []; st.seenUpTo = r.seenUpTo || 0; st.mutedUntil = r.mutedUntil || 0;
    r.mutedChanged = Boolean(was) !== Boolean(st.mutedUntil);
  }
  async function openChannel(id) {
    if (st.open && st.open !== id) { keepDraft(); saveDraft(st.open, st.draft); }
    st.shared = null; st.sharedKind = null; st.showArch = st.list?.channels.find((c) => c.id === id)?.archived ? st.showArch : false;
    st.open = id; st.ch = st.list?.channels.find((c) => c.id === id) || null; st.msgs = []; st.rev = 0; st.more = false; st.panel = null; st.members = null; st.banned = []; st.log = null; st.requests = []; st.invites = []; st.topic = null; st.tr = {}; st.sel = null; el.classList.remove('is-selecting'); if (st.rec) stopRec(false); mentionMap.clear(); st.reply = null; st.edit = null; st.search = null; st.pinned = null; st.typing = []; st.seenUpTo = 0; st.mutedUntil = 0; clearPending(); st.draft = draftOf(id);
    if (window.matchMedia('(max-width: 1279px)').matches) st.info = false;
    paintSide(); paintMain();
    try { const r = await apiRequest('GET', `/api/chat/${id}`, undefined, 15000); if (st.open !== id) return; await decAll(r.messages, r.channel); if (st.open !== id) return; await secretInfo(r.channel); if (st.open !== id) return; st.msgs = r.messages; st.more = r.more; st.ch = r.channel; st.rev = r.rev; live(r); setOffline(false);
      for (const x of outbox().filter((y) => y.ch === id)) st.msgs.push({ id: x.id, seq: Number.MAX_SAFE_INTEGER, uid: me(), name: '', text: x.text, at: x.at, pendingLocal: true, reactions: [] });
      paintMain(); markRead(); cacheChat(id); }
    catch (e) {
      if (OFFLINE_ERR(e)) { const cc = cacheGet(`m:${id}`); setOffline(true); if (cc && st.open === id) { st.msgs = cc.msgs; st.ch = cc.ch; st.more = false; st.rev = 0; for (const x of outbox().filter((y) => y.ch === id)) st.msgs.push({ id: x.id, seq: Number.MAX_SAFE_INTEGER, uid: me(), name: '', text: x.text, at: x.at, pendingLocal: true, reactions: [] }); paintMain(); } else say(e);
        setTimeout(() => { if (st.alive && st.open === id && st.offline) openChannel(id); }, 8000); return; }
      say(e); if (e?.code === 'not_found') { st.open = null; st.ch = null; paintMain(); loadList(); } return; }
    poll(id);
  }
  async function poll(id) {
    const mine = ++pollGen;
    while (st.alive && st.open === id && mine === pollGen) {
      try {
        const r = await apiRequest('GET', `/api/chat/${id}?since=${st.rev}&wait=1`, undefined, 35000);
        if (!st.alive || st.open !== id || mine !== pollGen) return;
        if (r.channel?.type === 'secret' && Boolean(r.channel.secret?.ready) !== Boolean(st.ch?.secret?.ready)) { await secretInfo(r.channel); st.ch = r.channel; keepDraft(); paintMain(); }
        await decAll(r.messages, r.channel || st.ch);
        const ch = merge(r);
        if (ch.headChanged || ch.mutedChanged) { keepDraft(); paintMain(); if (st.info) loadMembers(); }
        else if (ch.deleted) repaintMsgs(false);
        else if (ch.added) appendMsgs();
        paintLive(); setOffline(false);
        if (ch.added) { markRead(); loadList(); cacheChat(id); }
      } catch (e) {
        if (!st.alive || st.open !== id || mine !== pollGen) return;
        if (e?.code === 'not_found') { toast(L('ما عاد إلك وصول لهالقناة.', 'You no longer have access to this channel.'), 'error'); st.open = null; st.ch = null; paintMain(); loadList(); return; }
        if (OFFLINE_ERR(e) && e?.code !== 'timeout') setOffline(true);
        await new Promise((r) => setTimeout(r, e?.code === 'timeout' ? 300 : 4000));
      }
    }
  }
  const markRead = () => { if (st.open && st.msgs.length) apiRequest('POST', `/api/chat/${st.open}/read`, { seq: st.rev }, 10000).then(() => { const c = st.list?.channels.find((x) => x.id === st.open); if (c && c.unread) { c.unread = 0; paintSide(); } }).catch(() => {}); };
  async function loadMembers() { if (st.membersBusy) return; st.membersBusy = true; const id = st.open; try { const r = await apiRequest('GET', `/api/chat/${id}/members`, undefined, 15000); if (st.open !== id) return; st.members = r.members; for (const x of r.members) { st.av = st.av || {}; st.av[x.uid] = x.av || 0; } st.banned = r.banned || []; st.requests = r.requests || []; st.invites = r.invites || []; } catch (e) { st.members = st.members || []; say(e); } finally { st.membersBusy = false; } if (st.open === id) repaintPanel(); }
  function repaintPanel() { paintInfo(); }
  async function loadMods() { try { st.mods = await apiRequest('GET', '/api/chat/mods', undefined, 15000); st.reports = (await apiRequest('GET', '/api/chat/reports', undefined, 15000)).reports; } catch (e) { say(e); } if (st.panel === 'mods') paintMods(); }

  function clearPending() { if (st.pending?.url) URL.revokeObjectURL(st.pending.url); st.pending = null; st.upload = null; }
  async function setPending(file, kind) {
    try {
      if (kind === 'video' || /^video\//.test(file.type)) { if (file.size > 50_000_000) throw Object.assign(new Error('video_too_large'), { code: 'video_too_large' }); clearPending(); st.pending = { blob: file, kind: 'video', url: URL.createObjectURL(file) }; }
      else if (file.type === 'image/gif' && file.size < 8_000_000) { clearPending(); st.pending = { blob: file, kind: 'image', url: URL.createObjectURL(file) }; }   // a GIF keeps its animation
      else { const b = file.type === 'image/jpeg' && file.size < 1_500_000 && kind === 'image' ? file : await shrinkImage(file, 2048, 0.86, false, true); clearPending(); st.pending = { blob: b, kind: 'image', url: URL.createObjectURL(b) }; }
      keepDraft(); paintMain(); main.querySelector('[data-text]')?.focus();
    } catch (e) { say(e); }
  }
  async function send(form) {
    if (st.sending) return;
    const ta = form.querySelector('[data-text]'); const text = ta.value.trim(); const p = st.pending;
    if (!text && !p) return;
    if (st.edit) { const m = st.edit; st.sending = true; try { const sk = st.ch?.type === 'secret' ? await secretKey() : null; if (st.ch?.type === 'secret' && !sk) throw Object.assign(new Error('secret'), { code: 'secret_device' });   /* v368: never send plain text in a secret chat */ const r = await apiRequest('PATCH', `/api/chat/${st.open}/messages/${m.id}`, sk ? { enc: await sealText(sk, text, AAD(st.open, me(), 'text')) } : { text }, 15000); if (sk) r.message.text = text; Object.assign(st.msgs.find((x) => x.id === m.id) || {}, r.message); st.edit = null; st.draft = ''; paintMain(); } catch (e) { say(e); } finally { st.sending = false; } return; }
    st.sending = true; form.querySelector('.chp-send').disabled = true;
    try {
      let media;
      let poster, dur;
      if (p) {
        st.upload = 0; keepDraft(); paintMain();
        if (st.ch?.type === 'secret') { const sk = await secretKey(); if (!sk) throw Object.assign(new Error('secret'), { code: 'secret_device' }); const sealed = await sealBlob(sk, p.blob, AAD(st.open, me(), p.kind)); const up = await apiUpload(`/api/chat/${st.open}/media?as=file`, sealed.blob, (x) => { st.upload = x; const bar = main.querySelector('.chp-progress'); if (bar) bar.style.setProperty('--p', `${Math.round(x * 100)}%`); });
          const txt = (main.querySelector('[data-text]')?.value ?? text).trim(); const r2 = await apiRequest('POST', `/api/chat/${st.open}/messages`, { media: up.media, encMedia: { iv: sealed.iv, kind: p.kind, v: 2 }, round: p.round || undefined, enc: txt ? await sealText(sk, txt, AAD(st.open, me(), 'text')) : undefined, replyTo: st.reply?.id }, 30000);
          await decAll([r2.message]); st.draft = ''; saveDraft(st.open, ''); st.reply = null; clearPending(); if (!st.msgs.some((m) => m.id === r2.message.id)) st.msgs.push(r2.message); paintMain(); loadList(); return; }
        if (p.kind === 'video') { const pv = await videoPoster(p.url); if (pv) { dur = pv.dur || undefined; try { poster = (await apiUpload(`/api/chat/${st.open}/media`, pv.blob)).media; } catch { poster = undefined; } } }
        const up = await apiUpload(`/api/chat/${st.open}/media`, p.blob, (x) => { st.upload = x; const bar = main.querySelector('.chp-progress'); if (bar) bar.style.setProperty('--p', `${Math.round(x * 100)}%`); }); media = up.media;
      }
      if (st.ch?.type === 'secret' && !p) { const sk = await secretKey(); if (!sk) throw Object.assign(new Error('secret'), { code: 'secret_device' }); const t0 = (main.querySelector('[data-text]')?.value ?? text).trim();
        const r2 = await apiRequest('POST', `/api/chat/${st.open}/messages`, { enc: await sealText(sk, t0, AAD(st.open, me(), 'text')), replyTo: st.reply?.id }, 30000); r2.message.text = t0; await decAll([r2.message]);
        st.draft = ''; saveDraft(st.open, ''); st.reply = null; if (!st.msgs.some((m) => m.id === r2.message.id)) st.msgs.push(r2.message); paintMain(); loadList(); return; }
      if (!p && st.ch?.type !== 'secret' && (st.offline || !navigator.onLine)) { const t0 = (main.querySelector('[data-text]')?.value ?? text).trim(); queueText(st.open, t0, st.reply?.id); st.draft = ''; saveDraft(st.open, ''); st.reply = null; paintMain(); return; }
      const r = await apiRequest('POST', `/api/chat/${st.open}/messages`, { round: p?.round || undefined, text: (main.querySelector('[data-text]')?.value ?? text).trim(), media, poster, dur, topic: st.topic || undefined, replyTo: st.reply?.id, mentions: mentionsIn((main.querySelector('[data-text]')?.value ?? text)) }, 30000);
      st.draft = ''; saveDraft(st.open, ''); st.reply = null; clearPending();
      if (!st.msgs.some((m) => m.id === r.message.id)) st.msgs.push(r.message);
      paintMain(); loadList();
    } catch (e) { st.upload = null; if (!p && OFFLINE_ERR(e) && st.ch?.type !== 'secret') { const t0 = (main.querySelector('[data-text]')?.value ?? text).trim(); if (t0) { setOffline(true); queueText(st.open, t0, st.reply?.id); st.draft = ''; saveDraft(st.open, ''); st.reply = null; paintMain(); return; } } say(e); keepDraft(); paintMain(); }
    finally { st.sending = false; const b = main.querySelector('.chp-send'); if (b) b.disabled = false; main.querySelector('[data-text]')?.focus(); }
  }
  function grow(ta) { ta.style.height = 'auto'; ta.style.height = `${Math.min(ta.scrollHeight, 160)}px`; }
  /** Our own small player (no browser controls): tap to play / pause, a thin progress bar you can tap to seek, time, full screen. */
  async function playVideo(btn) {
    btn.classList.add('is-loading'); const u = await blob(st.open, btn.dataset.play);
    if (!u) { btn.classList.remove('is-loading'); say({ code: 'unknown' }); return; }
    const wrap = h(`<div class="chp-player is-playing" style="--ar:${btn.offsetWidth && btn.offsetHeight ? (btn.offsetWidth / btn.offsetHeight).toFixed(3) : '1.6'}"><video playsinline preload="auto"></video>
      <button type="button" class="chp-pl-toggle" aria-label="${esc(L('شغّل أو وقّف', 'Play or pause'))}"><span class="chp-vid-play">${ic('play')}</span></button>
      <div class="chp-pl-bar" dir="ltr"><span class="chp-pl-time">0:00</span><div class="chp-pl-track" role="slider" tabindex="0" aria-label="${esc(L('مكان التشغيل', 'Playback position'))}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><i></i></div>
        <button type="button" class="chp-pl-full" aria-label="${esc(L('ملء الشاشة', 'Full screen'))}"><svg class="ch-ic is-sm" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg></button></div></div>`);
    const v = wrap.querySelector('video'); v.src = u; const fill = wrap.querySelector('.chp-pl-track i'); const tm = wrap.querySelector('.chp-pl-time'); const tr = wrap.querySelector('.chp-pl-track');
    const sync = () => { const p = v.duration ? v.currentTime / v.duration : 0; fill.style.width = `${(p * 100).toFixed(1)}%`; tr.setAttribute('aria-valuenow', String(Math.round(p * 100))); tm.textContent = fmtDur(v.currentTime) || '0:00'; wrap.classList.toggle('is-playing', !v.paused); };
    v.addEventListener('timeupdate', sync); v.addEventListener('play', sync); v.addEventListener('pause', sync); v.addEventListener('ended', () => { v.currentTime = 0; sync(); });
    wrap.querySelector('.chp-pl-toggle').addEventListener('click', (e) => { e.stopPropagation(); if (v.paused) v.play().catch(() => {}); else v.pause(); });
    const seek = (x) => { const r = tr.getBoundingClientRect(); if (v.duration) v.currentTime = Math.min(1, Math.max(0, (x - r.left) / r.width)) * v.duration; sync(); };
    tr.addEventListener('click', (e) => { e.stopPropagation(); seek(e.clientX); });
    tr.addEventListener('keydown', (e) => { if (!v.duration) return; if (e.key === 'ArrowRight') v.currentTime = Math.min(v.duration, v.currentTime + 5); if (e.key === 'ArrowLeft') v.currentTime = Math.max(0, v.currentTime - 5); sync(); });
    wrap.querySelector('.chp-pl-full').addEventListener('click', (e) => { e.stopPropagation(); if (v.requestFullscreen) v.requestFullscreen().catch(() => {}); else if (v.webkitEnterFullscreen) v.webkitEnterFullscreen(); });
    const keepOverlay = btn.querySelector('.chp-overlay'); if (keepOverlay) wrap.append(keepOverlay.cloneNode(true));
    btn.replaceWith(wrap); v.play().catch(() => sync());
  }


  /* ── calls ── */
  let callOv = null;   // the call screen lives on <body> so nothing on the page can cover it
  function callUi() {
    let ov = callOv;
    const v = st.callView; if (!v || !v.joined) { if (ov) clearInterval(ov._timer); ov?.remove(); callOv = null; return; }
    if (!ov) { ov = h(`<div class="callx" data-call role="dialog" aria-label="${esc(L('المكالمة', 'Call'))}"><header class="callx-top"><span class="callx-live"><i></i>${esc(L('مكالمة', 'Call'))} <time data-calltime dir="ltr">0:00</time></span><b class="callx-name"></b><small class="callx-n"></small></header>
      <div class="callx-body"><div class="callx-grid" data-grid></div><aside class="callx-chat" data-callchat hidden><span class="callx-handle" aria-hidden="true"></span><div class="callx-chat-head"><b>${esc(L('شات المكالمة', 'Call chat'))}</b><button type="button" class="chp-icbtn" data-call-act="chat" aria-label="${esc(L('خبّي الشات', 'Hide chat'))}">${ic('x')}</button></div><ul data-callmsgs></ul>
        <form data-callsay class="callx-say"><input name="t" maxlength="500" autocomplete="off" placeholder="${esc(L('اكتب للمشاركين…', 'Message everyone…'))}" aria-label="${esc(L('رسالة للمكالمة', 'Call message'))}"><button class="chp-send" aria-label="${esc(L('ابعت', 'Send'))}">${ic('send')}</button></form></aside></div>
      <nav class="callx-bar" data-bar></nav></div>`); document.body.append(ov); callOv = ov; ov.addEventListener('click', onClick); ov.addEventListener('submit', onSubmit); ov.setAttribute('dir', document.documentElement.dir || 'rtl'); }
    ov.style.setProperty('--chc', colorOf(st.ch)); ov.querySelector('.callx-name').textContent = st.ch?.name || '';
    if (!ov._timer) { ov._timer = setInterval(() => { const t0 = st.callView?.call?.startedAt; const el2 = ov.querySelector('[data-calltime]'); if (!t0 || !el2) return; const sec = Math.max(0, Math.floor((Date.now() - t0) / 1000)); el2.textContent = sec >= 3600 ? `${Math.floor(sec / 3600)}:${String(Math.floor(sec / 60) % 60).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}` : `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`; }, 1000); }
    ov.querySelector('.callx-n').textContent = inCallTxt(v.peers.length + 1);
    const grid = ov.querySelector('[data-grid]'); const tiles = [{ uid: me(), name: L('إنت', 'You'), stream: v.local, mine: true, mic: v.mic, cam: v.cam || v.screen, screen: v.screen }, ...v.peers.map((p) => ({ uid: p.uid, name: p.name, stream: p.stream, mic: p.info?.mic !== false, cam: Boolean(p.info?.cam || p.info?.screen), screen: Boolean(p.info?.screen), state: p.state }))];
    grid.dataset.n = String(Math.min(tiles.length, 9));
    const keep = new Set(tiles.map((t) => t.uid));
    grid.querySelectorAll('[data-tile]').forEach((t) => { if (!keep.has(t.dataset.tile)) t.remove(); });
    for (const t of tiles) {
      let tile = grid.querySelector(`[data-tile="${CSS.escape(t.uid)}"]`);
      if (!tile) { tile = h(`<figure class="callx-tile" data-tile="${esc(t.uid)}"><video playsinline autoplay ${t.mine ? 'muted' : ''}></video><span class="callx-av" aria-hidden="true"></span><figcaption><span class="callx-mic"></span><b></b></figcaption></figure>`); grid.append(tile); }
      const vid = tile.querySelector('video'); if (vid.srcObject !== t.stream) { vid.srcObject = t.stream; vid.play?.().catch(() => {}); }
      tile.classList.toggle('is-cam', Boolean(t.cam)); tile.classList.toggle('is-me', Boolean(t.mine)); tile.classList.toggle('is-mirror', Boolean(t.mine && v.cam && !v.screen && v.facing === 'user')); tile.classList.toggle('is-wait', Boolean(t.state && !['connected', 'completed'].includes(t.state)));
      tile.querySelector('.callx-av').textContent = (t.name || '?').charAt(0).toUpperCase();
      tile.querySelector('b').textContent = t.screen ? `${t.name} · ${L('بيشارك الشاشة', 'sharing screen')}` : t.name;
      tile.querySelector('.callx-mic').innerHTML = t.mic ? '' : ic('micoff', 'is-sm');
    }
    const admin = st.ch?.role === 'admin'; const call = st.call;
    const btn = (act, icon, label, on = false, cls = '') => `<button type="button" class="callx-btn${on ? ' is-on' : ''} ${cls}" data-call-act="${act}" aria-pressed="${on}" aria-label="${esc(label)}"><span>${ic(icon)}</span><small>${esc(label)}</small></button>`;
    const unread = (v.call?.chat || []).filter((x) => x.at > st.callSeen && x.uid !== me()).length;
    const barHtml = btn('mic', v.mic ? 'mic' : 'micoff', v.mic ? L('الميك', 'Mic') : L('مسكّر', 'Muted'), !v.mic, v.mic ? '' : 'is-off')
      + btn('cam', v.cam ? 'video' : 'camoff', L('الكاميرا', 'Camera'), v.cam)
      + (v.cam ? btn('flip', 'flip', v.facing === 'user' ? L('سيلفي', 'Selfie') : L('أمامي', 'Back')) : '')
      + (call?.canShare() ? btn('screen', 'screen', L('شير الشاشة', 'Share'), v.screen) : '')
      + `<button type="button" class="callx-btn${st.callChat ? ' is-on' : ''}" data-call-act="chat" aria-pressed="${st.callChat}" aria-label="${esc(L('الشات', 'Chat'))}"><span>${ic('chat')}${unread && !st.callChat ? `<em>${unread}</em>` : ''}</span><small>${esc(st.callChat ? L('خبّي الشات', 'Hide chat') : L('الشات', 'Chat'))}</small></button>`
      + btn('leave', 'leave', L('اطلع', 'Leave'), false, 'is-danger')
      + (admin ? `<span class="callx-sep" aria-hidden="true"></span>${btn('end', 'x', L('أنهِ للكل', 'End for all'), false, 'is-danger-ghost')}` : '');
    const bar = ov.querySelector('[data-bar]'); if (bar.dataset.html !== barHtml) { bar.innerHTML = barHtml; bar.dataset.html = barHtml; }   // only redraw when something changed (keeps taps reliable)
    const chatBox = ov.querySelector('[data-callchat]'); chatBox.hidden = !st.callChat;
    if (st.callChat) { st.callSeen = Date.now(); const ul = ov.querySelector('[data-callmsgs]'); const near = ul.scrollHeight - ul.scrollTop - ul.clientHeight < 80;
      const chatHtml = (v.call?.chat || []).map((x) => `<li class="${x.uid === me() ? 'is-mine' : ''}">${x.uid === me() ? '' : `<b>${esc(x.name)}</b>`}<p dir="auto">${esc(x.text)}</p></li>`).join('') || `<li class="chp-muted">${esc(L('الشات بيختفي لما تخلص المكالمة.', 'This chat disappears when the call ends.'))}</li>`; if (ul.dataset.html !== chatHtml) { ul.innerHTML = chatHtml; ul.dataset.html = chatHtml; if (near) ul.scrollTop = ul.scrollHeight; } }
  }
  async function joinCall(start) {
    if (!st.call) st.call = createCall({ channelId: st.open, me: me(), onChange: (v) => { st.callView = v; callUi(); }, onError: (e) => say(e) });
    try { await st.call.join({ start, cam: true }); document.documentElement.classList.add('call-open'); } catch (e) { say(e); st.call.destroy(); st.call = null; }
  }
  async function leaveCall(end = false) { const c = st.call; st.call = null; st.callView = null; document.documentElement.classList.remove('call-open'); if (callOv) clearInterval(callOv._timer); callOv?.remove(); callOv = null; if (c) { await c.leave({ end }); c.destroy(); } paintMain(); }

  /** Scrolls to a message (loading older pages when needed) and flashes it. */
  async function gotoMsg(id) {
    for (let i = 0; i < 12 && !main.querySelector(`.chp-msg[data-mid="${CSS.escape(id)}"]`) && st.more; i++) {
      const first = st.msgs.find((m) => m.seq)?.seq || 0; try { const r = await apiRequest('GET', `/api/chat/${st.open}?before=${first}`, undefined, 15000); await decAll(r.messages); const have = new Set(st.msgs.map((m) => m.id)); st.msgs = [...r.messages.filter((m) => !have.has(m.id)), ...st.msgs]; st.more = r.more; repaintMsgs(false); } catch { break; }
    }
    const x = main.querySelector(`.chp-msg[data-mid="${CSS.escape(id)}"]`); if (!x) { toast(L('الرسالة مش موجودة أو انحذفت.', 'That message is gone.'), 'info'); return; }
    if (st.search && window.matchMedia('(max-width: 760px)').matches) { st.search = null; keepDraft(); paintMain(); return gotoMsg(id); }
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches; x.scrollIntoView({ block: 'center', behavior: reduce ? 'auto' : 'smooth' });
    x.classList.remove('is-flash'); void x.offsetWidth; x.classList.add('is-flash'); setTimeout(() => x.classList.remove('is-flash'), 1600);
  }
  let typedAt = 0;
  const typed = () => { if (!st.open || Date.now() - typedAt < 3000) return; typedAt = Date.now(); apiRequest('POST', `/api/chat/${st.open}/typing`, {}, 8000).catch(() => {}); };

  /* ── v358 helpers: sheets, forward, polls, voice, files, mentions, direct chats, invite links ── */
  function openSheet(html) { closeSheet(); const bg = h(`<div class="chp-sheet-bg"><div class="chp-sheet" role="dialog" aria-modal="true">${html}</div></div>`); el.append(bg); bg.querySelector('input, button:not([data-act=closesheet])')?.focus(); return bg; }
  function closeSheet() { el.querySelectorAll('.chp-sheet-bg').forEach((x) => x.remove()); }
  const sheetHead = (title) => `<div class="chp-sheet-head"><b>${esc(title)}</b><button type="button" class="chp-icbtn" data-act="closesheet" aria-label="${esc(L('سكّر', 'Close'))}">${ic('x')}</button></div>`;
  let fwdMid = null; let fwdMany = null;
  function openForward(mid) {
    fwdMid = mid; if (!st.sel) fwdMany = null; const rows = (st.list?.channels || []).filter((c) => c.type !== 'secret' && !(c.type === 'channel' && c.role !== 'admin') && !(c.type === 'dm' && (c.peer?.blockedMe || c.peer?.iBlocked)));
    openSheet(`${sheetHead(L('حوّل لـ…', 'Forward to…'))}<div class="chp-sheet-list">${rows.map((c) => `<button type="button" class="chp-item" data-fwdto="${esc(c.id)}" style="--ring:${esc(colorOf(c))}">${avatarOf(c)}<span class="chp-item-txt"><span class="chp-item-top"><b dir="auto">${esc(nameOf(c))}</b></span><small>${esc(c.type === 'dm' ? L('محادثة خاصة', 'Private chat') : c.type === 'saved' ? L('إلك لحالك', 'Only you') : membersTxt(c.members))}</small></span></button>`).join('')}</div>`);
  }
  async function doForward(to) {
    const btn = el.querySelector(`[data-fwdto="${CSS.escape(to)}"]`); if (btn) btn.disabled = true;
    try { const ids = fwdMany?.length ? [...fwdMany].sort((a, b) => (st.msgs.find((m) => m.id === a)?.seq || 0) - (st.msgs.find((m) => m.id === b)?.seq || 0)) : [fwdMid];
      for (const id of ids) await apiRequest('POST', `/api/chat/${st.open}/messages/${id}/forward`, { to }, 60000);
      closeSheet(); toast(ids.length > 1 ? L(`انحوّلوا (${ids.length}).`, `Forwarded (${ids.length}).`) : L('انحوّلت.', 'Forwarded.'), 'success'); if (fwdMany) { fwdMany = null; st.sel = null; paintSel(); } loadList(); } catch (e) { say(e); if (btn) btn.disabled = false; }
  }
  function openPollSheet() {
    openSheet(`${sheetHead(L('استطلاع جديد', 'New poll'))}<form class="chp-form" data-pollform><label>${esc(L('السؤال', 'Question'))}<input name="q" maxlength="200" required placeholder="${esc(L('شو رأيكم…؟', 'What do you think…?'))}"></label>
      <div class="chp-pollopts" data-pollopts><input name="opt" maxlength="100" required placeholder="${esc(L('خيار 1', 'Option 1'))}"><input name="opt" maxlength="100" required placeholder="${esc(L('خيار 2', 'Option 2'))}"></div>
      <button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-act="pollopt">${ic('plus', 'is-sm')}<span>${esc(L('زيد خيار', 'Add option'))}</span></button>
      <label class="chp-check"><input type="checkbox" name="anon"> ${esc(L('بدون أسماء', 'Anonymous'))}</label><label class="chp-check"><input type="checkbox" name="multi"> ${esc(L('مسموح أكثر من خيار', 'Allow several answers'))}</label>
      <button class="chp-btn chp-btn-primary chp-btn-wide">${esc(L('انشر الاستطلاع', 'Post poll'))}</button></form>`);
  }
  async function openJoin(code) {
    try {
      const v = await apiRequest('GET', `/api/chat/invite/${code}`, undefined, 15000);
      if (v.member && v.id) { await loadList(); return openChannel(v.id); }
      openSheet(`${sheetHead(L('دعوة', 'Invitation'))}<div class="chp-hero"><span class="chp-logo chp-logo-ph is-big" aria-hidden="true" style="background:${esc(v.color || '#14b8a6')}">${esc((v.name || '?').charAt(0).toUpperCase())}</span><h2><span dir="auto">${esc(v.name)}</span>${verified(v)}</h2><p>${esc(membersTxt(v.members))}</p>${v.description ? `<p class="chp-desc" dir="auto">${esc(v.description)}</p>` : ''}
        ${v.asked ? `<p class="chp-muted">${esc(L('طلبك مبعوت، استنى موافقة المشرف.', 'Your request is waiting for an admin.'))}</p>` : `<button type="button" class="chp-btn chp-btn-primary chp-btn-wide" data-join="${esc(code)}">${esc(v.approve ? L('اطلب الانضمام', 'Ask to join') : L('انضم', 'Join'))}</button>`}</div>`);
    } catch (e) { toast(e?.code === 'not_found' ? L('الرابط خلص أو انلغى.', 'This link expired or was revoked.') : (ERR[e?.code] || L('صار خطأ.', 'Something went wrong.')), 'error'); }
  }
  async function startDm(uid) {
    closeSheet(); try { const r = await apiRequest('POST', '/api/chat/dm', { uid }, 15000); await loadList(); await openChannel(r.channel.id); main.querySelector('[data-text]')?.focus(); } catch (e) { say(e); }
  }
  async function sendOther(blobOrFile, as, name = '', dur) {
    if (!st.open) return; const id = st.open;
    if (as === 'file' && blobOrFile.size > 25_000_000) return say({ code: 'file_too_large' });
    st.sending = true; toast(as === 'voice' ? L('عم تنبعت…', 'Sending…') : L('عم يرفع الملف…', 'Uploading the file…'), 'info');
    try {
      if (st.ch?.type === 'secret') { const sk = await secretKey(); if (!sk) throw Object.assign(new Error('secret'), { code: 'secret_device' });
        const sealed = await sealBlob(sk, blobOrFile, AAD(id, me(), as)); const nm = name ? await sealText(sk, name.slice(0, 120), AAD(id, me(), 'name')) : null;
        const up2 = await apiUpload(`/api/chat/${id}/media?as=file`, sealed.blob);
        const r2 = await apiRequest('POST', `/api/chat/${id}/messages`, { media: up2.media, dur, encMedia: { iv: sealed.iv, kind: as, v: 2, ...(nm ? { name: nm.ct, nameIv: nm.iv } : {}) }, replyTo: st.reply?.id }, 30000);
        await decAll([r2.message]); st.reply = null; if (st.open === id && !st.msgs.some((m) => m.id === r2.message.id)) st.msgs.push(r2.message); keepDraft(); paintMain(); loadList(); return; }
      const up = await apiUpload(`/api/chat/${id}/media?as=${as}${name ? `&name=${encodeURIComponent(name.slice(0, 120))}` : ''}`, blobOrFile);
      const r = await apiRequest('POST', `/api/chat/${id}/messages`, { media: up.media, dur, replyTo: st.reply?.id, topic: st.topic || undefined }, 30000);
      st.reply = null; if (st.open === id && !st.msgs.some((m) => m.id === r.message.id)) st.msgs.push(r.message); keepDraft(); paintMain(); loadList();
    } catch (e) { say(e); } finally { st.sending = false; }
  }
  /* voice recording: tap the mic, talk, then send or throw away (max 5 minutes) */
  async function startRec() {
    if (st.rec) return;
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') return toast(L('متصفحك ما بيدعم التسجيل.', 'Your browser cannot record.'), 'error');
    let stream; try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); } catch { return toast(L('اسمح للمايكروفون من إعدادات المتصفح.', 'Allow the microphone in your browser settings.'), 'error'); }
    const type = ['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/mp4', 'audio/webm'].find((x) => MediaRecorder.isTypeSupported?.(x)) || '';
    const mr = new MediaRecorder(stream, type ? { mimeType: type, audioBitsPerSecond: 48000 } : undefined); const chunks = [];
    mr.ondataavailable = (e) => { if (e.data?.size) chunks.push(e.data); };
    keepDraft(); st.rec = { mr, chunks, stream, t0: Date.now(), type: mr.mimeType || type || 'audio/webm' }; mr.start(250);
    const ping = () => apiRequest('POST', `/api/chat/${st.open}/typing?kind=voice`, {}, 8000).catch(() => {}); ping(); let last = Date.now();
    st.rec.timer = setInterval(() => { if (Date.now() - last > 4000) { last = Date.now(); ping(); } const s2 = (Date.now() - st.rec.t0) / 1000; const tt = main.querySelector('[data-rectime]'); if (tt) tt.textContent = fmtDur(s2) || '0:00'; if (s2 > 300) stopRec(true); }, 250);
    paintMain();
  }
  function stopRec(sendIt) {
    const r = st.rec; if (!r) return; st.rec = null; clearInterval(r.timer); const dur = (Date.now() - r.t0) / 1000;
    r.mr.onstop = () => { r.stream.getTracks().forEach((x) => x.stop()); if (sendIt && dur >= 0.8 && r.chunks.length) sendOther(new Blob(r.chunks, { type: r.type.split(';')[0] }), 'voice', '', Math.round(dur * 10) / 10); };
    try { r.mr.stop(); } catch { r.stream.getTracks().forEach((x) => x.stop()); }
    paintMain();
  }
  /* voice playback with a waveform you can tap to seek, and 1x / 1.5x / 2x */
  const voice = new Map();
  async function playVoice(box) {
    if (!box) return; const fid = box.dataset.voice; let a = voice.get(fid);
    for (const [k, x] of voice) if (k !== fid && !x.paused) x.pause();
    if (!a) {
      const u = await blob(st.open, fid); if (!u) return say({ code: 'unknown' });
      a = new Audio(u); voice.set(fid, a);
      const sync = () => { const b2 = main.querySelector(`.chp-voice[data-voice="${CSS.escape(fid)}"]`); if (!b2) return; const p2 = a.duration && Number.isFinite(a.duration) ? a.currentTime / a.duration : 0; b2.style.setProperty('--vp', `${(p2 * 100).toFixed(1)}%`); const bs = b2.querySelectorAll('.chp-wave i'); const on = Math.round(p2 * bs.length); bs.forEach((x, i) => x.classList.toggle('is-on', i < on)); b2.querySelector('[data-vtime]').textContent = fmtDur(a.currentTime) || '0:00'; b2.classList.toggle('is-playing', !a.paused); b2.querySelector('[data-vplay]').innerHTML = ic(a.paused ? 'play' : 'pause'); b2.querySelector('[data-vseek]').setAttribute('aria-valuenow', String(Math.round(p2 * 100))); };
      a.addEventListener('timeupdate', sync); a.addEventListener('play', sync); a.addEventListener('pause', sync); a.addEventListener('ended', () => { a.currentTime = 0; sync(); });
      const sp = box.querySelector('[data-vspeed]'); a.playbackRate = parseFloat(sp?.textContent) || 1;
    }
    if (a.paused) a.play().catch(() => {}); else a.pause();
  }
  function seekVoice(w, ev) { const box = w.closest('.chp-voice'); const a = voice.get(box?.dataset.voice); if (!a || !a.duration || !Number.isFinite(a.duration)) { playVoice(box); return; } const r = w.getBoundingClientRect(); a.currentTime = Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width)) * a.duration; }
  async function downloadDoc(btn) {
    btn.classList.add('is-loading'); const u = await blob(st.open, btn.dataset.doc); btn.classList.remove('is-loading');
    if (!u) return say({ code: 'unknown' }); const a = document.createElement('a'); a.href = u; a.download = btn.dataset.name || 'file'; document.body.append(a); a.click(); a.remove();
  }
  /* @mentions: typing @ lists the members; picked names are sent as ids so only real members get the notice */
  const mentionMap = new Map();
  function hideMention() { const m2 = main.querySelector('[data-mention]'); if (m2 && !m2.hidden) m2.hidden = true; }
  function mentionCheck(ta) {
    const box = main.querySelector('[data-mention]'); if (!box) return;
    const cm = /^\/([a-z0-9_]{0,32})$/i.exec(ta.value.slice(0, ta.selectionStart ?? ta.value.length)); const cmds = st.ch?.commands || [];
    if (cm && cmds.length) { const list2 = cmds.filter((x) => x.cmd.startsWith(cm[1].toLowerCase())).slice(0, 8); if (list2.length) { box.innerHTML = list2.map((x) => `<button type="button" data-cmd="${esc(x.cmd)}"><b dir="ltr">/${esc(x.cmd)}</b><small dir="ltr">@${esc(x.bot)}</small></button>`).join(''); box.hidden = false; return; } }
    if (isPriv(st.ch)) { box.hidden = true; return; }
    const before = ta.value.slice(0, ta.selectionStart ?? ta.value.length); const mt = /(^|\s)@([^\s@]{0,20})$/.exec(before);
    if (!mt) { box.hidden = true; return; }
    if (!st.members) { loadMembers(); return; }
    const q = mt[2].toLowerCase(); const list = st.members.filter((x) => !x.me && x.name.toLowerCase().includes(q)).slice(0, 6);
    if (!list.length) { box.hidden = true; return; }
    box.innerHTML = list.map((x) => `<button type="button" data-pick="${esc(x.uid)}" data-name="${esc(x.name)}"><span class="chp-avatar" style="--h:${hueOf(x.uid)}" aria-hidden="true">${esc(x.name.charAt(0).toUpperCase())}</span><b>${esc(x.name)}</b></button>`).join(''); box.hidden = false;
  }
  function pickMention(t) {
    const ta = main.querySelector('[data-text]'); if (!ta) return; const pos = ta.selectionStart ?? ta.value.length; const before = ta.value.slice(0, pos).replace(/@([^\s@]{0,20})$/, `@${t.dataset.name} `);
    ta.value = before + ta.value.slice(pos); ta.focus(); ta.selectionStart = ta.selectionEnd = before.length; mentionMap.set(t.dataset.name, t.dataset.pick); hideMention(); grow(ta); ta.form?.classList.remove('is-empty');
  }
  const mentionsIn = (text) => [...mentionMap.entries()].filter(([n]) => String(text).includes(`@${n}`)).map(([, uid]) => uid);

  /* global search: chats (filtered above), people by @username, and messages in every chat */
  let gsTimer = null; let gsSeq = 0;
  function globalSearch() {
    clearTimeout(gsTimer); const q = (st.q || '').trim(); if (q.length < 2) { st.gs = null; return; }
    gsTimer = setTimeout(async () => { const my = ++gsSeq; try { const r = await apiRequest('GET', `/api/chat/search?q=${encodeURIComponent(q)}`, undefined, 15000); if (my !== gsSeq) return; st.gs = r; paintList(); } catch { /* quiet */ } }, 350);
  }
  function searchResultsHtml() {
    const r = st.gs; if (!r) return '';
    const ppl = r.people?.length ? `<p class="chp-sec">${esc(L('أشخاص', 'People'))}</p>${r.people.map((x) => `<button type="button" class="chp-item" data-person="${esc(x.uid)}"><span class="chp-logo chp-logo-ph chp-dm-ava" aria-hidden="true"${avAttr(x.uid, x.av)} style="--h:${hueOf(x.uid)};background-color:var(--h)">${esc(x.name.charAt(0).toUpperCase())}</span><span class="chp-item-txt"><span class="chp-item-top"><b dir="auto">${esc(x.name)}</b></span><small dir="ltr">@${esc(x.username)}</small></span></button>`).join('')}` : '';
    const msgs = r.results?.length ? `<p class="chp-sec">${esc(L('رسائل', 'Messages'))}</p>${r.results.map((x) => `<button type="button" class="chp-item chp-res" data-openmsg="${esc(x.ch)}:${esc(x.message.id)}"><span class="chp-item-txt"><span class="chp-item-top"><b dir="auto">${esc(x.chType === 'saved' ? L('الرسائل المحفوظة', 'Saved messages') : x.chName)}</b></span><small dir="auto">${esc(x.message.name)}: ${esc(x.message.text.slice(0, 90))}</small></span><span class="chp-item-meta"><time>${esc(fmtDay(x.message.at))}</time></span></button>`).join('')}` : '';
    return ppl + msgs;
  }
  async function openPerson(uid) {
    try { const p2 = await apiRequest('GET', `/api/chat/profile/${uid}`, undefined, 15000);
      openSheet(`${sheetHead(L('البروفايل', 'Profile'))}<div class="chp-hero"><span class="chp-logo chp-logo-ph chp-dm-ava is-big" aria-hidden="true"${avAttr(uid, p2.av)} style="--h:${hueOf(uid)};background-color:var(--h)">${esc(p2.name.charAt(0).toUpperCase())}</span><h2><span dir="auto">${esc(p2.name)}</span></h2>${p2.username ? `<p dir="ltr">@${esc(p2.username)}</p>` : ''}${p2.bio ? `<p class="chp-desc" dir="auto">${esc(p2.bio)}</p>` : ''}
        ${p2.canDm ? `<button type="button" class="chp-btn chp-btn-primary chp-btn-wide" data-dm="${esc(uid)}">${ic('chat', 'is-sm')}<span>${esc(L('ابعتله رسالة', 'Send a message'))}</span></button><button type="button" class="chp-btn chp-btn-ghost chp-btn-wide" data-secret="${esc(uid)}">${ic('lock', 'is-sm')}<span>${esc(L('محادثة سرية', 'Secret chat'))}</span></button>` : `<p class="chp-muted">${esc(L('هالشخص ما بيستقبل رسائل من برّا جروباته.', 'This person only takes messages from their groups.'))}</p>`}</div>`); hydrate(el.querySelector('.chp-sheet'));
    } catch (e) { say(e); }
  }
  async function openProfile() {
    try { st.me = await apiRequest('GET', '/api/chat/me/profile', undefined, 15000); st.myAv = st.me.av; } catch (e) { return say(e); }
    const p2 = st.me;
    openSheet(`${sheetHead(L('بروفايلي', 'My profile'))}<div class="chp-hero"><span class="chp-logo chp-logo-ph chp-dm-ava is-big" aria-hidden="true"${avAttr(p2.uid, p2.av)} style="--h:${hueOf(p2.uid)};background-color:var(--h)">${esc(p2.name.charAt(0).toUpperCase())}</span><h2><span dir="auto">${esc(p2.name)}</span></h2>
      <div class="chp-pref-row"><button type="button" class="chp-btn chp-btn-ghost chp-btn-sm" data-act="avpick">${esc(L('غيّر الصورة', 'Change photo'))}</button>${p2.av ? `<button type="button" class="chp-btn chp-btn-danger chp-btn-sm" data-act="avdel">${esc(L('شيلها', 'Remove'))}</button>` : ''}</div></div>
      <form class="chp-form" data-profile><label>${esc(L('اسم المستخدم', 'Username'))}<input name="username" maxlength="33" dir="ltr" autocomplete="off" placeholder="${esc(L('@اسمك_بالإنجليزي', '@your_name'))}" value="${esc(p2.username ? `@${p2.username}` : '')}"></label>
        <label>${esc(L('نبذة', 'Bio'))}<textarea name="bio" maxlength="140" rows="2" dir="auto">${esc(p2.bio)}</textarea></label>
        <label>${esc(L('مين بيقدر يبعتلي رسالة خاصة', 'Who can message me'))}<select name="dmFrom"><option value="groups"${p2.dmFrom !== 'all' ? ' selected' : ''}>${esc(L('الناس اللي معي بجروب', 'People in my groups'))}</option><option value="all"${p2.dmFrom === 'all' ? ' selected' : ''}>${esc(L('أي حدا بيعرف اسم المستخدم تبعي', 'Anyone who knows my username'))}</option></select></label>
        <p class="chp-muted">${esc(L('الناس بيلاقوك باسم المستخدم من البحث. اسمك وإيميلك ما بينعرضوا للغرباء.', 'People find you by username in search. Your e-mail is never shown to strangers.'))}</p>
        <button class="chp-btn chp-btn-primary chp-btn-wide">${esc(L('احفظ', 'Save'))}</button></form>
      <h3 class="chp-h3 chp-wall-h">${esc(L('خلفية المحادثة', 'Chat background'))}</h3><div class="chp-walls" role="radiogroup">${WALLS.map(([k, t]) => `<button type="button" role="radio" class="chp-wall-sw wall-${k}" data-wall="${k}" aria-checked="${wallNow() === k}" aria-label="${esc(t)}" title="${esc(t)}"></button>`).join('')}</div>
      <div class="chp-sheet-links"><button type="button" class="chp-btn chp-btn-ghost chp-btn-wide" data-act="devices">${ic('device', 'is-sm')}<span>${esc(L('الأجهزة المفتوحة على حسابي', 'Devices signed in to my account'))}</span></button>
        <button type="button" class="chp-btn chp-btn-ghost chp-btn-wide" data-act="lockset">${ic('lock', 'is-sm')}<span>${esc(lockCfg() ? L('قفل الدردشة: شغّال', 'Chat lock: on') : L('قفل الدردشة برقم سري', 'Lock the chat with a PIN'))}</span></button>
        ${st.list?.canCreate ? `<button type="button" class="chp-btn chp-btn-ghost chp-btn-wide" data-act="bots">${ic('bot', 'is-sm')}<span>${esc(L('البوتات تبعتي', 'My bots'))}</span></button>` : ''}</div>`); hydrate(el.querySelector('.chp-sheet'));
  }
  function openLater() {
    const d = new Date(Date.now() + 3600_000); d.setSeconds(0, 0); const local = new Date(d.getTime() - d.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
    openSheet(`${sheetHead(L('ابعت لاحقًا', 'Send later'))}<form class="chp-form" data-later><label>${esc(L('الرسالة', 'Message'))}<textarea name="text" rows="3" maxlength="4000" required dir="auto">${esc(st.draft || '')}</textarea></label>
      <label>${esc(L('الوقت (فاضي = هلأ)', 'Time (empty = now)'))}<input name="when" type="datetime-local" value="${local}"></label>
      <label class="chp-check"><input type="checkbox" name="silent"> ${esc(L('بدون صوت إشعار', 'No notification sound'))}</label>
      <button class="chp-btn chp-btn-primary chp-btn-wide">${esc(L('تمام', 'Done'))}</button></form>`);
  }
  async function openSchedList() {
    try { st.sched = (await apiRequest('GET', `/api/chat/${st.open}/scheduled`, undefined, 15000)).scheduled; } catch (e) { return say(e); }
    openSheet(`${sheetHead(L('الرسائل المجدولة', 'Scheduled messages'))}<ul class="chp-shared-list">${st.sched.length ? st.sched.map((x) => `<li class="chp-sched-row"><span><b>${esc(fmtDay(x.at))} ${esc(fmtTime(x.at))}${x.silent ? ` · ${esc(L('بدون صوت', 'silent'))}` : ''}</b><small dir="auto">${esc(x.text || x.poll || '')}</small></span><button type="button" class="chp-icbtn" data-unsched="${esc(x.id)}" aria-label="${esc(L('الغيها', 'Cancel it'))}">${ic('trash')}</button></li>`).join('') : `<li class="chp-muted">${esc(L('ما في رسائل مجدولة.', 'No scheduled messages.'))}</li>`}</ul>`);
  }
  /* round video messages: a circle preview from the front camera, up to 60 s, sent when you stop */
  async function recordRound() {
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') return toast(L('متصفحك ما بيدعم التسجيل.', 'Your browser cannot record.'), 'error');
    let stream; try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 480 }, height: { ideal: 480 } }, audio: true }); } catch { return toast(L('اسمح للكاميرا والمايك من إعدادات المتصفح.', 'Allow the camera and microphone in your browser settings.'), 'error'); }
    const ov = h(`<div class="chp-round-ov" role="dialog" aria-modal="true" aria-label="${esc(L('فيديو دائري', 'Round video'))}"><div class="chp-round-cam"><video autoplay muted playsinline></video><svg class="chp-round-ring" viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="48"/></svg></div><time data-rt>0:00</time>
      <div class="chp-round-acts"><button type="button" class="chp-icbtn" data-rc="cancel" aria-label="${esc(L('الغي', 'Cancel'))}">${ic('trash')}</button><button type="button" class="chp-round-go" data-rc="go" aria-label="${esc(L('سجّل', 'Record'))}"><i></i></button><button type="button" class="chp-icbtn" data-rc="send" aria-label="${esc(L('ابعت', 'Send'))}" disabled>${ic('send')}</button></div></div>`);
    document.body.append(ov); const v = ov.querySelector('video'); v.srcObject = stream;
    const type = ['video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm'].find((x) => MediaRecorder.isTypeSupported?.(x)) || '';
    let mr = null; const chunks = []; let t0 = 0; let tick = null;
    const done = () => { clearInterval(tick); stream.getTracks().forEach((x) => x.stop()); ov.remove(); };
    const stop = (sendIt) => { if (!mr || mr.state === 'inactive') { done(); return; } mr.onstop = () => { done(); if (sendIt && chunks.length) { const b = new Blob(chunks, { type: (mr.mimeType || type || 'video/webm').split(';')[0] }); clearPending(); st.pending = { blob: b, kind: 'video', url: URL.createObjectURL(b), round: true }; keepDraft(); const f = main.querySelector('[data-compose]'); if (f) send(f); } }; mr.stop(); };
    ov.addEventListener('click', (ev) => { const b = ev.target.closest('[data-rc]'); if (!b) return;
      if (b.dataset.rc === 'cancel') stop(false);
      else if (b.dataset.rc === 'send') stop(true);
      else if (!mr) { mr = new MediaRecorder(stream, type ? { mimeType: type, videoBitsPerSecond: 900_000 } : undefined); mr.ondataavailable = (e) => { if (e.data?.size) chunks.push(e.data); }; mr.start(250); t0 = Date.now(); ov.classList.add('is-rec'); ov.querySelector('[data-rc=send]').disabled = false;
        tick = setInterval(() => { const s2 = (Date.now() - t0) / 1000; ov.querySelector('[data-rt]').textContent = fmtDur(s2) || '0:00'; ov.style.setProperty('--rp', String(Math.min(1, s2 / 60))); if (s2 >= 60) stop(true); }, 200); }
      else stop(true); });
    ov.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') stop(false); });
    ov.querySelector('[data-rc=go]').focus();
  }
  /* photo editor before sending: rotate, square crop, draw with a pen, undo */
  async function openEditor() {
    const p0 = st.pending; if (!p0 || p0.kind !== 'image') return;
    const img = await new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = p0.url; }).catch(() => null); if (!img) return;
    let base = document.createElement('canvas'); { const k = Math.min(1, 1600 / Math.max(img.width, img.height)); base.width = Math.round(img.width * k); base.height = Math.round(img.height * k); base.getContext('2d').drawImage(img, 0, 0, base.width, base.height); }
    const strokes = []; let color = '#22d3ee'; let pen = false; let cur = null;
    const ov = h(`<div class="chp-editor" role="dialog" aria-modal="true" aria-label="${esc(L('تعديل الصورة', 'Edit photo'))}"><div class="chp-ed-stage"><canvas></canvas></div>
      <div class="chp-ed-tools"><button type="button" class="chp-icbtn" data-ed="rotate" aria-label="${esc(L('دوّر', 'Rotate'))}">${ic('rotate')}</button><button type="button" class="chp-icbtn" data-ed="crop" aria-label="${esc(L('قصّ مربّع', 'Square crop'))}">${ic('crop')}</button>
        <button type="button" class="chp-icbtn" data-ed="pen" aria-pressed="false" aria-label="${esc(L('قلم', 'Pen'))}">${ic('pen')}</button>${['#22d3ee', '#f43f5e', '#facc15', '#ffffff'].map((c2) => `<button type="button" class="chp-ed-color" data-color2="${c2}" style="--c:${c2}" aria-label="${c2}"></button>`).join('')}
        <button type="button" class="chp-icbtn" data-ed="undo" aria-label="${esc(L('تراجع', 'Undo'))}">${ic('undo')}</button></div>
      <div class="chp-ed-foot"><button type="button" class="chp-btn chp-btn-ghost" data-ed="cancel">${esc(L('إلغاء', 'Cancel'))}</button><button type="button" class="chp-btn chp-btn-primary" data-ed="done">${esc(L('تمام', 'Done'))}</button></div></div>`);
    document.body.append(ov); const cv = ov.querySelector('canvas'); const cx = cv.getContext('2d');
    const draw = () => { cv.width = base.width; cv.height = base.height; cx.drawImage(base, 0, 0); for (const s2 of strokes) { cx.strokeStyle = s2.c; cx.lineWidth = s2.w; cx.lineCap = 'round'; cx.lineJoin = 'round'; cx.beginPath(); s2.p.forEach(([x, y], i) => (i ? cx.lineTo(x, y) : cx.moveTo(x, y))); cx.stroke(); } };
    const xform = (fn) => { const out = fn(); base = out; strokes.length = 0; draw(); };
    draw();
    const pt = (ev) => { const r = cv.getBoundingClientRect(); return [((ev.clientX - r.left) / r.width) * cv.width, ((ev.clientY - r.top) / r.height) * cv.height]; };
    cv.addEventListener('pointerdown', (ev) => { if (!pen) return; cv.setPointerCapture(ev.pointerId); cur = { c: color, w: Math.max(4, cv.width / 160), p: [pt(ev)] }; strokes.push(cur); draw(); });
    cv.addEventListener('pointermove', (ev) => { if (!cur) return; cur.p.push(pt(ev)); draw(); });
    const up = () => { cur = null; }; cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    ov.addEventListener('click', (ev) => {
      const c2 = ev.target.closest('[data-color2]'); if (c2) { color = c2.dataset.color2; pen = true; ov.querySelector('[data-ed=pen]').setAttribute('aria-pressed', 'true'); ov.classList.add('is-pen'); return; }
      const b = ev.target.closest('[data-ed]'); if (!b) return; const a = b.dataset.ed;
      if (a === 'pen') { pen = !pen; b.setAttribute('aria-pressed', String(pen)); ov.classList.toggle('is-pen', pen); }
      else if (a === 'undo') { strokes.pop(); draw(); }
      else if (a === 'rotate') xform(() => { draw(); const o = document.createElement('canvas'); o.width = cv.height; o.height = cv.width; const ox = o.getContext('2d'); ox.translate(o.width, 0); ox.rotate(Math.PI / 2); ox.drawImage(cv, 0, 0); return o; });
      else if (a === 'crop') xform(() => { draw(); const sz = Math.min(cv.width, cv.height); const o = document.createElement('canvas'); o.width = o.height = sz; o.getContext('2d').drawImage(cv, (cv.width - sz) / 2, (cv.height - sz) / 2, sz, sz, 0, 0, sz, sz); return o; });
      else if (a === 'cancel') ov.remove();
      else if (a === 'done') { draw(); cv.toBlob((bl) => { ov.remove(); if (!bl) return; clearPending(); st.pending = { blob: bl, kind: 'image', url: URL.createObjectURL(bl) }; keepDraft(); paintMain(); }, 'image/jpeg', 0.88); }
    });
    ov.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') ov.remove(); });
    ov.querySelector('[data-ed=done]').focus();
  }
  /* something shared from another app: pick the chat, then it waits in the composer for you to send */
  const shareTake = () => new Promise((resolve) => { try { const r = indexedDB.open('gotriva-share', 1); r.onupgradeneeded = () => r.result.createObjectStore('s');
    r.onsuccess = () => { const t = r.result.transaction('s', 'readwrite'); const os = t.objectStore('s'); const g = os.get('last'); g.onsuccess = () => { os.delete('last'); resolve(g.result || null); }; g.onerror = () => resolve(null); }; r.onerror = () => resolve(null); } catch { resolve(null); } });
  let shared = null;
  async function openShare() {
    shared = await shareTake(); if (!shared || Date.now() - shared.at > 10 * 60_000) { shared = null; return; }
    if (!st.list?.channels?.length) await loadList();
    const rows = (st.list?.channels || []).filter((c) => !(c.type === 'channel' && c.role !== 'admin'));
    const what = shared.files?.length ? L(`${shared.files.length} ملف`, `${shared.files.length} file(s)`) : (shared.text || shared.url || '').slice(0, 80);
    openSheet(`${sheetHead(L('شارك بـ…', 'Share to…'))}<p class="chp-muted" dir="auto">${esc(what)}</p><div class="chp-sheet-list">${rows.map((c) => `<button type="button" class="chp-item" data-shareto="${esc(c.id)}" style="--ring:${esc(colorOf(c))}">${avatarOf(c)}<span class="chp-item-txt"><span class="chp-item-top"><b dir="auto">${esc(nameOf(c))}</b></span></span></button>`).join('')}</div>`);
    hydrate(el.querySelector('.chp-sheet'));
  }
  async function shareTo(id) {
    const sh = shared; shared = null; closeSheet(); if (!sh) return; await openChannel(id);
    const txt = [sh.title, sh.text, sh.url].filter(Boolean).join('\n').trim(); if (txt) { st.draft = txt; }
    const f = sh.files?.[0];
    if (f) { if (/^(image|video)\//.test(f.type)) await setPending(f, /^video\//.test(f.type) ? 'video' : 'image'); else confirmSharedFile(f); }
    else { keepDraft(); paintMain(); }
    const ta = main.querySelector('[data-text]'); if (ta && txt) { ta.value = txt; grow(ta); ta.form?.classList.remove('is-empty'); ta.focus(); }
    if (sh.files?.length > 1) toast(L('انبعت أول ملف. ابعت الباقي واحد واحد.', 'The first file is ready; send the others one by one.'), 'info');
  }
  /* v368 security: a shared file is never sent by itself (another site could push one through the share target) — show its name and size, the person presses Send */
  function confirmSharedFile(f) {
    const kb = f.size >= 1_048_576 ? `${(f.size / 1_048_576).toFixed(1)} MB` : `${Math.max(1, Math.round(f.size / 1024))} KB`;
    openSheet(`${sheetHead(L('تبعت هالملف؟', 'Send this file?'))}<p class="chp-muted" dir="auto"><b>${esc(f.name || 'file')}</b> · ${esc(kb)}</p>
      <p class="chp-muted">${esc(L('ابعته بس إذا إنت اللي شاركته هلأ.', 'Only send it if you shared it yourself just now.'))}</p>
      <div class="chp-sheet-acts"><button type="button" class="chp-btn chp-btn-ghost chp-btn-wide" data-sh-cancel>${esc(L('إلغاء', 'Cancel'))}</button><button type="button" class="chp-btn chp-btn-wide" data-sh-send>${esc(L('ابعت', 'Send'))}</button></div>`);
    const box = el.querySelector('.chp-sheet');
    box.querySelector('[data-sh-send]').onclick = () => { closeSheet(); sendOther(f, 'file', f.name || 'file'); };
    box.querySelector('[data-sh-cancel]').onclick = () => closeSheet();
  }
  /* keyboard (desktop, like Telegram): Ctrl/⌘+K search · ↑ in an empty box edits your last message · Alt+↑/↓ previous / next chat */
  function onKeys(ev) {
    if (!el.isConnected || el.querySelector('.chp-lockscreen')) return;
    if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'k') { ev.preventDefault(); const q = side.querySelector('[data-q]'); if (q) { el.classList.remove('is-open'); q.focus(); q.select(); } return; }
    if (ev.altKey && (ev.key === 'ArrowUp' || ev.key === 'ArrowDown')) { const ids = [...side.querySelectorAll('[data-open]')].map((x) => x.dataset.open); if (!ids.length) return; ev.preventDefault(); const i = ids.indexOf(st.open); const n = ids[Math.max(0, Math.min(ids.length - 1, i < 0 ? 0 : i + (ev.key === 'ArrowUp' ? -1 : 1)))]; if (n && n !== st.open) openChannel(n); return; }
    const ta = ev.target.closest?.('[data-text]');
    if (ta && ev.key === 'ArrowUp' && !ta.value && !st.edit && !ev.shiftKey) { const m = [...st.msgs].reverse().find((x) => x.uid === me() && x.text && !x.deleted && !x.pendingLocal && Date.now() - x.at < 48 * 3600_000); if (m) { ev.preventDefault(); st.edit = m; st.reply = null; st.draft = m.text; paintMain(); main.querySelector('[data-text]')?.focus(); } return; }
    if (ta && ev.key === 'Escape' && (st.edit || st.reply)) { ev.preventDefault(); if (st.edit) st.draft = ''; st.edit = null; st.reply = null; paintMain(); main.querySelector('[data-text]')?.focus(); }
  }
  document.addEventListener('keydown', onKeys);
  el.addEventListener('contextmenu', (ev) => { const bub = ev.target.closest?.('.chp-bubble'); if (!bub || ev.target.closest('a, video') || st.sel) return; const mid = bub.closest('.chp-msg')?.dataset.mid; if (!mid || mid.startsWith('local')) return; ev.preventDefault(); openMsgMenu(mid, { left: ev.clientX, top: ev.clientY }); });
  /* chat backgrounds (this device) */
  const WALLS = [['doodle', L('رسومات', 'Doodles')], ['plain', L('سادة', 'Plain')], ['teal', L('تركوازي', 'Teal')], ['night', L('ليلي', 'Night')], ['sunset', L('غروب', 'Sunset')], ['dots', L('نقاط', 'Dots')]];
  const wallNow = () => { try { return localStorage.getItem('gt-wall') || 'doodle'; } catch { return 'doodle'; } };
  const applyWall = () => { for (const [k] of WALLS) el.classList.toggle(`wall-${k}`, wallNow() === k); };
  /* comments under channel posts */
  async function openComments(mid) {
    st.cmtMid = mid; try { st.cmts = await apiRequest('GET', `/api/chat/${st.open}/messages/${mid}/comments`, undefined, 15000); } catch (e) { return say(e); }
    openSheet(`${sheetHead(L('التعليقات', 'Comments'))}<div class="chp-cmt-post" dir="auto">${fmtText(st.cmts.post.text || '')}</div><ul class="chp-cmts" data-cmts></ul>
      <form class="chp-cmt-form" data-cmtform><input name="t" maxlength="2000" autocomplete="off" dir="auto" placeholder="${esc(L('اكتب تعليق…', 'Write a comment…'))}" aria-label="${esc(L('تعليق', 'Comment'))}"><button class="chp-send" aria-label="${esc(L('ابعت', 'Send'))}">${ic('send')}</button></form>`);
    paintComments();
  }
  function paintComments() {
    const box = el.querySelector('[data-cmts]'); if (!box || !st.cmts) return;
    box.innerHTML = st.cmts.comments.length ? st.cmts.comments.map((x) => `<li><span class="chp-avatar" style="--h:${hueOf(x.uid)}" aria-hidden="true"${avAttr(x.uid, x.av)}>${esc((x.name || '?').charAt(0).toUpperCase())}</span><div><b>${esc(x.name)}${x.admin ? ` <span class="chp-crown">${ic('crown', 'is-xs')}</span>` : ''}</b>${x.replyTo ? `<small class="chp-cmt-re">↩ ${esc(x.replyTo.name)}: ${esc(x.replyTo.text)}</small>` : ''}<p dir="auto">${fmtText(x.text)}</p><time>${esc(fmtDay(x.at))} ${esc(fmtTime(x.at))}</time></div>${x.mine || st.cmts.canDelete ? `<button type="button" class="chp-icbtn" data-delcmt="${esc(x.id)}" aria-label="${esc(L('امسح التعليق', 'Delete comment'))}">${ic('trash', 'is-sm')}</button>` : ''}</li>`).join('') : `<li class="chp-muted">${esc(L('كون أول واحد بيعلّق.', 'Be the first to comment.'))}</li>`;
    hydrate(box); box.scrollTop = box.scrollHeight;
  }
  /* export: the whole conversation as one HTML file you can open in any browser (decrypted here for secret chats) */
  async function exportChat(btn) {
    btn.disabled = true; const label = btn.querySelector('span'); if (label) label.textContent = L('عم يجهّز…', 'Preparing…');
    try {
      for (let i = 0; i < 80 && st.more; i++) { const first = st.msgs.find((m) => m.seq)?.seq || 0; const r = await apiRequest('GET', `/api/chat/${st.open}?before=${first}`, undefined, 15000); await decAll(r.messages); const have = new Set(st.msgs.map((m) => m.id)); st.msgs = [...r.messages.filter((m) => !have.has(m.id)), ...st.msgs]; st.more = r.more; }
      const name = nameOf(st.ch); const rows = st.msgs.filter((m) => !m.deleted).map((m) => m.sys ? `<p class="s">${esc(fmtDay(m.at))} ${esc(fmtTime(m.at))} · ${esc(m.sys)}</p>` : `<div class="m"><b>${esc(m.name)}</b> <time>${esc(fmtDay(m.at))} ${esc(fmtTime(m.at))}</time><p dir="auto">${esc(m.text || '')}${m.file ? ` <i>[${esc(m.kind === 'file' ? (m.fileName || 'file') : m.kind || 'image')}]</i>` : ''}${m.poll ? ` <i>[${esc(m.poll.q)}]</i>` : ''}</p></div>`).join('\n');
      const html = `<!doctype html><meta charset="utf-8"><title>${esc(name)}</title><style>body{font:15px/1.5 system-ui,sans-serif;max-width:760px;margin:24px auto;padding:0 16px;background:#0b1620;color:#e7f3f6}.m{padding:8px 12px;margin:6px 0;border-radius:10px;background:#142531}.m b{color:#22d3ee}time{color:#7f98a2;font-size:12px}.s{color:#7f98a2;font-size:12px;text-align:center}p{margin:4px 0;white-space:pre-wrap}</style><h1>${esc(name)}</h1><p class="s">${esc(L(`تصدير ${new Date().toLocaleString()}`, `Exported ${new Date().toLocaleString()}`))}</p>\n${rows}`;
      const u = URL.createObjectURL(new Blob([html], { type: 'text/html' })); const a = document.createElement('a'); a.href = u; a.download = `${name.replace(/[^\p{L}\p{N} _-]/gu, '').trim() || 'chat'}.html`; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 5000);
      repaintMsgs(false); toast(L('المحادثة انصدّرت.', 'Chat exported.'), 'success');
    } catch (e) { say(e); } finally { if (btn.isConnected) { btn.disabled = false; if (label) label.textContent = L('صدّر المحادثة', 'Export chat'); } }
  }
  /* folders */
  async function loadFolders() { try { st.folders = (await apiRequest('GET', '/api/chat/me/folders', undefined, 15000)).folders; paintList(); } catch { /* quiet */ } }
  function openFolders() {
    openSheet(`${sheetHead(L('المجلدات', 'Folders'))}<ul class="chp-shared-list">${(st.folders || []).map((f) => `<li class="chp-sched-row"><span><b>${esc(f.emoji)} ${esc(f.name)}</b><small>${esc(L(`${f.chats.length} محادثة`, `${f.chats.length} chats`))}${f.unread ? ` · ${esc(L('غير المقروء بس', 'unread only'))}` : ''}</small></span><span class="chp-row-acts"><button type="button" class="chp-icbtn" data-act="folderedit" data-fid="${esc(f.id)}" aria-label="${esc(L('عدّل', 'Edit'))}">${ic('edit')}</button><button type="button" class="chp-icbtn" data-delfolder="${esc(f.id)}" aria-label="${esc(L('امسح', 'Delete'))}">${ic('trash')}</button></span></li>`).join('') || `<li class="chp-muted">${esc(L('رتّب محادثاتك بمجلدات زي «شغل» و«عيلة»، وبتطلع كتبويبات فوق القائمة.', 'Sort chats into folders like "Work" and "Family"; they show as tabs above the list.'))}</li>`}</ul>
      ${(st.folders || []).length < 10 ? `<button type="button" class="chp-btn chp-btn-primary chp-btn-wide" data-act="folderedit">${ic('plus', 'is-sm')}<span>${esc(L('مجلد جديد', 'New folder'))}</span></button>` : ''}`);
  }
  function openFolderEdit(fid) {
    const f = (st.folders || []).find((x) => x.id === fid) || { name: '', emoji: '', chats: [], types: [], unread: false };
    const TYPES = [['group', L('كل الجروبات', 'All groups')], ['channel', L('كل القنوات', 'All channels')], ['dm', L('كل الخاص', 'All private')], ['secret', L('كل السرية', 'All secret')]];
    openSheet(`${sheetHead(fid ? L('تعديل المجلد', 'Edit folder') : L('مجلد جديد', 'New folder'))}<form class="chp-form" data-folderform="${esc(fid || '')}"><div class="chp-topic-add"><input name="femoji" maxlength="8" placeholder="💼" value="${esc(f.emoji)}" aria-label="${esc(L('إيموجي', 'Emoji'))}"><input name="fname" maxlength="30" required placeholder="${esc(L('اسم المجلد', 'Folder name'))}" value="${esc(f.name)}" aria-label="${esc(L('اسم المجلد', 'Folder name'))}"></div>
      <fieldset class="chp-fs"><legend>${esc(L('بيضم تلقائيًا', 'Include automatically'))}</legend>${TYPES.map(([k, t]) => `<label class="chp-check"><input type="checkbox" name="ft" value="${k}"${f.types?.includes(k) ? ' checked' : ''}> ${esc(t)}</label>`).join('')}</fieldset>
      <fieldset class="chp-fs"><legend>${esc(L('محادثات بعينها', 'Specific chats'))}</legend><div class="chp-fs-list">${(st.list?.channels || []).map((c) => `<label class="chp-check"><input type="checkbox" name="fc" value="${esc(c.id)}"${f.chats.includes(c.id) ? ' checked' : ''}> ${esc(nameOf(c))}</label>`).join('')}</div></fieldset>
      <label class="chp-check"><input type="checkbox" name="funread"${f.unread ? ' checked' : ''}> ${esc(L('اعرض اللي فيها رسائل جديدة بس', 'Show only chats with new messages'))}</label>
      <button class="chp-btn chp-btn-primary chp-btn-wide">${esc(L('احفظ', 'Save'))}</button></form>`);
  }
  /* devices */
  const deviceId = () => { try { let d = localStorage.getItem('gt-device'); if (!/^d[0-9a-f]{16}$/.test(d || '')) { d = `d${[...crypto.getRandomValues(new Uint8Array(8))].map((x) => x.toString(16).padStart(2, '0')).join('')}`; localStorage.setItem('gt-device', d); } return d; } catch { return ''; } };
  const uaName = (ua) => { const os = /iPhone|iPad/.test(ua) ? 'iPhone/iPad' : /Android/.test(ua) ? 'Android' : /Mac OS/.test(ua) ? 'Mac' : /Windows/.test(ua) ? 'Windows' : /Linux/.test(ua) ? 'Linux' : L('جهاز', 'Device'); const br = /Edg\//.test(ua) ? 'Edge' : /CriOS|Chrome\//.test(ua) ? 'Chrome' : /Firefox|FxiOS/.test(ua) ? 'Firefox' : /Safari/.test(ua) ? 'Safari' : ''; return `${os}${br ? ` · ${br}` : ''}`; };
  async function openDevices(have = false) {
    if (!have) { try { st.devs = (await apiRequest('POST', '/api/chat/me/devices', { id: deviceId(), ua: navigator.userAgent }, 15000)).devices; } catch (e) { return say(e); } }
    openSheet(`${sheetHead(L('الأجهزة', 'Devices'))}<ul class="chp-shared-list">${(st.devs || []).map((d) => `<li class="chp-sched-row"><span><b>${ic('device', 'is-xs')} ${esc(uaName(d.ua))}${d.current ? ` · ${esc(L('هالجهاز', 'this device'))}` : ''}</b><small>${esc(L(`آخر نشاط ${fmtDay(d.at)} ${fmtTime(d.at)}`, `Last active ${fmtDay(d.at)} ${fmtTime(d.at)}`))}</small></span>${d.current ? '' : `<button type="button" class="chp-btn chp-btn-danger chp-btn-sm" data-devout="${esc(d.id)}">${esc(L('اطلع منه', 'Sign out'))}</button>`}</li>`).join('')}</ul>
      ${true ? `<button type="button" class="chp-btn chp-btn-danger chp-btn-wide" data-devout="all">${esc(L('اطلع من كل الأجهزة (وهاد كمان)', 'Sign out everywhere (this one too)'))}</button>` : ''}
      <p class="chp-muted">${esc(L('الجهاز اللي بتطلع منه بيوقف دخوله عالموقع كله، وبيرجع بس إذا سجّل دخول من جديد بكلمة السر.', 'A signed-out device loses access to the whole site until it signs in again.'))}</p>`);
  }
  /* chat lock: a PIN kept as a PBKDF2 hash on this device (a local lock for shared phones; your account sign-in still applies) */
  let lockFails = 0;
  const lockCfg = () => { try { return JSON.parse(localStorage.getItem('gt-lock') || 'null'); } catch { return null; } };
  const pinHash = async (pin, salt) => { const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']); const b = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: new TextEncoder().encode(salt), iterations: 150_000 }, k, 256); return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join(''); };
  async function setPin(pin, mins) { const salt = [...crypto.getRandomValues(new Uint8Array(12))].map((x) => x.toString(16).padStart(2, '0')).join(''); try { localStorage.setItem('gt-lock', JSON.stringify({ salt, hash: await pinHash(pin, salt), mins: [0, 1, 5, 60].includes(mins) ? mins : 5 })); sessionStorage.setItem('gt-unlocked', String(Date.now())); } catch { /* storage off */ } }
  async function checkPin(pin) { const c2 = lockCfg(); if (!c2) return true; return (await pinHash(String(pin || ''), c2.salt)) === c2.hash; }
  function openLockSet() {
    const c2 = lockCfg();
    openSheet(`${sheetHead(L('قفل الدردشة', 'Chat lock'))}${c2 ? `<div class="chp-form"><label>${esc(L('الرقم الحالي لتشيل القفل', 'Current PIN to remove the lock'))}<input data-lockpin type="password" inputmode="numeric" autocomplete="off" maxlength="8"></label><button type="button" class="chp-btn chp-btn-danger chp-btn-wide" data-act="lockoff">${esc(L('شيل القفل', 'Remove lock'))}</button></div>` : `<form class="chp-form" data-lockform>
      <label>${esc(L('رقم سري (4 لـ8 أرقام)', 'PIN (4–8 digits)'))}<input name="pin" type="password" inputmode="numeric" autocomplete="new-password" maxlength="8" required></label><label>${esc(L('أعده', 'Repeat it'))}<input name="pin2" type="password" inputmode="numeric" autocomplete="new-password" maxlength="8" required></label>
      <label>${esc(L('اقفل بعد ما أغيب', 'Lock after I am away for'))}<select name="mins"><option value="0">${esc(L('فورًا', 'Immediately'))}</option><option value="1">${esc(L('دقيقة', '1 minute'))}</option><option value="5" selected>${esc(L('5 دقايق', '5 minutes'))}</option><option value="60">${esc(L('ساعة', '1 hour'))}</option></select></label>
      <p class="chp-muted">${esc(L('القفل على هالجهاز بس. إذا نسيت الرقم، اطلع من حسابك وارجع ادخل، فبينشال.', 'The lock is on this device only. Forgot it? Sign out and back in to clear it.'))}</p><button class="chp-btn chp-btn-primary chp-btn-wide">${esc(L('شغّل القفل', 'Turn on lock'))}</button></form>`}`);
  }
  let lockOv = null; let hiddenAt = 0;
  function lockNow() {
    if (lockOv || !lockCfg()) return;
    lockOv = h(`<div class="chp-lockscreen" role="dialog" aria-modal="true" aria-label="${esc(L('الدردشة مقفولة', 'Chat locked'))}"><span class="chp-lock-ic">${ic('lock')}</span><b>${esc(L('الدردشة مقفولة', 'Chat locked'))}</b>
      <form data-lockgate class="chp-form"><input name="pin" type="password" inputmode="numeric" autocomplete="off" maxlength="8" aria-label="${esc(L('الرقم السري', 'PIN'))}" placeholder="••••"><button class="chp-btn chp-btn-primary chp-btn-wide">${esc(L('افتح', 'Unlock'))}</button><p class="chp-muted" data-lockmsg aria-live="polite"></p></form><p class="chp-muted">${esc(L('نسيت الرقم؟ اطلع من حسابك من القائمة وارجع ادخل، فبينشال القفل.', 'Forgot it? Sign out from the menu and back in to clear the lock.'))}</p></div>`);
    el.append(lockOv); setTimeout(() => lockOv?.querySelector('input')?.focus(), 50);
  }
  function unlock() { lockFails = 0; lockOv?.remove(); lockOv = null; try { sessionStorage.setItem('gt-unlocked', String(Date.now())); } catch { /* ignore */ } }
  const onVis = () => { const c2 = lockCfg(); if (!c2) return; if (document.visibilityState === 'hidden') hiddenAt = Date.now(); else if (hiddenAt && Date.now() - hiddenAt >= c2.mins * 60_000) lockNow(); };
  document.addEventListener('visibilitychange', onVis);
  { const c2 = lockCfg(); let u2 = 0; try { u2 = Number(sessionStorage.getItem('gt-unlocked')) || 0; } catch { /* ignore */ } if (c2 && (!u2 || Date.now() - u2 > Math.max(1, c2.mins) * 60_000)) setTimeout(lockNow, 0); }
  /* bots */
  async function openBots() {
    try { const r = await apiRequest('GET', '/api/chat/bots', undefined, 15000); st.bots = r.bots; } catch (e) { return say(e); }
    openSheet(`${sheetHead(L('البوتات تبعتي', 'My bots'))}<ul class="chp-shared-list">${st.bots.map((b2) => `<li class="chp-sched-row"><span><b>${ic('bot', 'is-xs')} ${esc(b2.name)} <small dir="ltr">@${esc(b2.username)}</small></b><small>${esc(L(`بـ ${b2.chats.length} جروب · ${b2.commands.length} أمر`, `In ${b2.chats.length} groups · ${b2.commands.length} commands`))}</small></span><span class="chp-row-acts"><button type="button" class="chp-icbtn" data-botedit="${esc(b2.id)}" aria-label="${esc(L('عدّل', 'Edit'))}">${ic('edit')}</button><button type="button" class="chp-btn chp-btn-danger chp-btn-sm" data-botdel="${esc(b2.id)}">${esc(L('امسح', 'Delete'))}</button></span></li>`).join('') || `<li class="chp-muted">${esc(L('البوت بيرحّب بالأعضاء الجداد، وبيرد على أوامر زي /rules، وبيقدر المبرمج يربطه بأي نظام عبر الـAPI.', 'A bot welcomes new members, answers commands like /rules, and a developer can connect it to anything through the API.'))}</li>`}</ul>
      <form class="chp-form" data-botnew><h3 class="chp-h3">${esc(L('بوت جديد', 'New bot'))}</h3><label>${esc(L('الاسم', 'Name'))}<input name="bname" maxlength="40" required placeholder="${esc(L('مساعد الجروب', 'Group helper'))}"></label><label>${esc(L('اسم المستخدم (بيخلص بـ bot)', 'Username (ends in "bot")'))}<input name="busername" dir="ltr" maxlength="33" required placeholder="helperbot"></label><label>${esc(L('نبذة', 'About'))}<input name="babout" maxlength="200"></label><button class="chp-btn chp-btn-primary chp-btn-wide">${esc(L('اعمل البوت', 'Create bot'))}</button></form>`);
  }
  function openBotEdit(id) {
    const b2 = (st.bots || []).find((x) => x.id === id); if (!b2) return;
    openSheet(`${sheetHead(`@${b2.username}`)}<form class="chp-form" data-botform="${esc(b2.id)}"><label>${esc(L('الاسم', 'Name'))}<input name="bname" maxlength="40" value="${esc(b2.name)}"></label><label>${esc(L('نبذة', 'About'))}<input name="babout" maxlength="200" value="${esc(b2.about)}"></label>
      <label>${esc(L('رسالة ترحيب للعضو الجديد ({name} = اسمه)', 'Welcome for new members ({name} = their name)'))}<textarea name="welcome" rows="2" maxlength="1000" dir="auto">${esc(b2.welcome)}</textarea></label>
      <label>${esc(L('الأوامر: كل سطر /أمر = الرد', 'Commands: one per line, /command = reply'))}<textarea name="cmds" rows="5" dir="ltr" placeholder="/rules = Be kind and no spam&#10;/help = Ask the admins">${esc(b2.commands.map((x) => `/${x.cmd} = ${x.reply.replace(/\n/g, '\\n')}`).join('\n'))}</textarea></label>
      <button class="chp-btn chp-btn-primary chp-btn-wide">${esc(L('احفظ', 'Save'))}</button></form>
      <div class="chp-sheet-links"><button type="button" class="chp-btn chp-btn-ghost chp-btn-wide" data-bottoken="${esc(b2.id)}">${esc(L('مفتاح API جديد (القديم بيوقف)', 'New API token (the old one stops)'))}</button></div>`);
  }
  function showToken(b2) {
    const api = `${location.origin}/api/bot`;
    openSheet(`${sheetHead(`@${b2.username}`)}<p class="chp-muted">${esc(L('هاد مفتاح البوت. انسخه هلأ واحفظه بمكان آمن: ما رح يطلع مرة تانية. أي حدا معه المفتاح بيتحكّم بالبوت.', 'This is the bot token. Copy it now and keep it safe: it will not be shown again. Anyone with it controls the bot.'))}</p>
      <code class="chp-token" dir="ltr">${esc(b2.token)}</code><button type="button" class="chp-btn chp-btn-primary chp-btn-wide" data-copytxt="${esc(b2.token)}">${ic('copy', 'is-sm')}<span>${esc(L('انسخ المفتاح', 'Copy token'))}</span></button>
      <details class="chp-card chp-fold"><summary>${esc(L('للمبرمجين: الـAPI', 'For developers: the API'))}</summary><pre class="chp-api" dir="ltr">Authorization: Bot &lt;token&gt;
GET  ${esc(api)}/me
GET  ${esc(api)}/updates?since=&lt;ms&gt;
POST ${esc(api)}/send  {"chat":"&lt;id&gt;","text":"hi"}</pre></details>`);
  }
  /* stickers */
  const stkUrls = new Map();
  const stkUrl = (fid) => { if (!stkUrls.has(fid)) stkUrls.set(fid, apiBlobUrl(`/api/chat/stickers/${fid}`).catch(() => null)); return stkUrls.get(fid); };
  async function paintStickers(box) {
    if (!st.stickers) { box.innerHTML = '<div class="chp-skel is-sm"></div>'; try { st.stickers = (await apiRequest('GET', '/api/chat/stickers', undefined, 15000)).stickers; } catch (e) { st.stickers = []; say(e); } }
    box.innerHTML = `<button type="button" class="chp-stk is-add" data-act="stkadd" aria-label="${esc(L('ستيكر من صورة', 'Sticker from a photo'))}">${ic('plus')}<small>${esc(L('من صورة', 'From photo'))}</small></button>${st.stickers.map((f) => `<span class="chp-stk-cell"><button type="button" class="chp-stk" data-stk="${esc(f)}" aria-label="${esc(L('ابعت الستيكر', 'Send sticker'))}"><img data-stkimg="${esc(f)}" alt=""></button><button type="button" class="chp-stk-x" data-stkdel="${esc(f)}" aria-label="${esc(L('امسح الستيكر', 'Remove sticker'))}">${ic('x', 'is-xs')}</button></span>`).join('')}
      ${st.stickers.length ? '' : `<p class="chp-muted">${esc(L('اعمل ستيكر من أي صورة: من هون، أو من زر الستيكر على أي صورة بالشات.', 'Make a sticker from any photo: here, or from the sticker button on any photo in a chat.'))}</p>`}`;
    box.querySelectorAll('[data-stkimg]').forEach(async (img) => { const u = await stkUrl(img.dataset.stkimg); if (u) img.src = u; });
  }
  /* stories */
  let storyFile = null;
  function storyDraft(file) {
    if (!/^(image|video)\//.test(file.type)) return say({ code: 'bad_media' }); if (file.size > 30_000_000) return say({ code: 'video_too_large' });
    storyFile = file; const url = URL.createObjectURL(file);
    openSheet(`${sheetHead(L('حالة جديدة', 'New story'))}<div class="chp-story-prev">${/^video/.test(file.type) ? `<video src="${url}" muted playsinline autoplay loop></video>` : `<img src="${url}" alt="">`}</div>
      <label class="chp-form"><span>${esc(L('تعليق (اختياري)', 'Caption (optional)'))}</span><input data-storycap maxlength="200" dir="auto"></label>
      <p class="chp-muted">${esc(L('بتضل 24 ساعة، وبيشوفها الناس اللي معك بمجموعة أو محادثة.', 'Stays 24 hours; seen by people who share a group or chat with you.'))}</p>
      <button type="button" class="chp-btn chp-btn-primary chp-btn-wide" data-act="storypost">${esc(L('انشر', 'Post'))}</button>`);
  }
  async function postStory() {
    if (!storyFile) return; const btn = el.querySelector('[data-act=storypost]'); if (btn) btn.disabled = true;
    try { const f = storyFile; const b = /^image\//.test(f.type) && f.type !== 'image/gif' ? await shrinkImage(f, 1600, 0.86, false, true) : f; const cap = el.querySelector('[data-storycap]')?.value || '';
      st.stories = (await apiUpload(`/api/chat/stories?caption=${encodeURIComponent(cap.slice(0, 200))}`, b)).stories; storyFile = null; closeSheet(); paintStories(); toast(L('الحالة انتشرت.', 'Story posted.'), 'success'); }
    catch (e) { say(e); if (btn?.isConnected) btn.disabled = false; }
  }
  let storyView = null;
  async function openStory(uid) {
    if ((st.stories || []).find((x) => x.uid === uid)?.me) await loadStories();
    const who = (st.stories || []).find((x) => x.uid === uid); if (!who) return;
    const start = Math.max(0, who.items.findIndex((x) => !x.seen)); closeStory();
    const ov = h(`<div class="chp-sv" role="dialog" aria-modal="true" aria-label="${esc(who.name)}"><div class="chp-sv-bars">${who.items.map(() => '<i><b></b></i>').join('')}</div>
      <div class="chp-sv-top"><span class="chp-story-ava" style="--h:${hueOf(uid)}">${esc(who.name.charAt(0).toUpperCase())}</span><span class="chp-sv-who"><b dir="auto">${esc(who.me ? L('حالتي', 'My story') : who.name)}</b><small data-svtime></small></span>
        ${who.me ? `<button type="button" class="chp-icbtn" data-svdel aria-label="${esc(L('امسح هالحالة', 'Delete this story'))}">${ic('trash')}</button>` : ''}<button type="button" class="chp-icbtn" data-svclose aria-label="${esc(L('سكّر', 'Close'))}">${ic('x')}</button></div>
      <div class="chp-sv-media" data-svmedia></div><p class="chp-sv-cap" data-svcap dir="auto"></p>${who.me ? '<p class="chp-sv-views" data-svviews></p>' : ''}
      <button type="button" class="chp-sv-nav is-prev" data-svprev aria-label="${esc(L('اللي قبل', 'Previous'))}"></button><button type="button" class="chp-sv-nav is-next" data-svnext aria-label="${esc(L('اللي بعد', 'Next'))}"></button></div>`);
    document.body.append(ov); storyView = { ov, who, i: start, timer: null };
    ov.addEventListener('click', async (ev) => {
      const b = ev.target.closest('button'); if (!b) return;
      if (b.matches('[data-svclose]')) closeStory(); else if (b.matches('[data-svnext]')) storyGo(1); else if (b.matches('[data-svprev]')) storyGo(-1);
      else if (b.matches('[data-svdel]')) { try { st.stories = (await apiRequest('DELETE', `/api/chat/stories/${storyView.who.items[storyView.i].fid}`, undefined, 15000)).stories; closeStory(); paintStories(); } catch (e) { say(e); } }
    });
    ov.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') closeStory(); if (ev.key === 'ArrowRight') storyGo(AR ? -1 : 1); if (ev.key === 'ArrowLeft') storyGo(AR ? 1 : -1); });
    ov.querySelector('[data-svclose]').focus(); showStory();
  }
  async function showStory() {
    const v = storyView; if (!v) return; const it = v.who.items[v.i]; clearTimeout(v.timer);
    v.ov.querySelectorAll('.chp-sv-bars i').forEach((x, k) => { x.className = k < v.i ? 'is-done' : k === v.i ? 'is-now' : ''; });
    v.ov.querySelector('[data-svtime]').textContent = `${fmtDay(it.at)} ${fmtTime(it.at)}`; v.ov.querySelector('[data-svcap]').textContent = it.caption || '';
    const vw = v.ov.querySelector('[data-svviews]'); if (vw) vw.textContent = it.views?.length ? L(`شافها ${it.views.length}: ${it.views.slice(0, 8).join('، ')}`, `Seen by ${it.views.length}: ${it.views.slice(0, 8).join(', ')}`) : L('ما حدا شافها لسا', 'No views yet');
    const box = v.ov.querySelector('[data-svmedia]'); box.innerHTML = '<div class="chp-skel"></div>';
    let u = null; try { u = await apiBlobUrl(`/api/chat/stories/${v.who.uid}/${it.fid}`); } catch { u = null; }
    if (storyView !== v || v.who.items[v.i] !== it) return;
    if (!u) { box.innerHTML = `<p class="chp-muted">${esc(L('الحالة خلصت.', 'This story ended.'))}</p>`; return; }
    it.seen = true; v.urls = v.urls || []; v.urls.push(u);
    if (it.kind === 'video') { box.innerHTML = '<video playsinline autoplay></video>'; const vid = box.querySelector('video'); vid.src = u; vid.onended = () => storyGo(1); vid.play().catch(() => { vid.muted = true; vid.play().catch(() => {}); }); v.ov.style.setProperty('--sv-ms', '15000ms'); }
    else { box.innerHTML = '<img alt="">'; box.querySelector('img').src = u; v.ov.style.setProperty('--sv-ms', '6000ms'); v.timer = setTimeout(() => storyGo(1), 6000); }
  }
  function storyGo(d) { const v = storyView; if (!v) return; const n = v.i + d; if (n < 0) return; if (n >= v.who.items.length) { closeStory(); paintStories(); return; } v.i = n; showStory(); }
  function closeStory() { const v = storyView; if (!v) return; clearTimeout(v.timer); for (const u of v.urls || []) URL.revokeObjectURL(u); v.ov.remove(); storyView = null; paintStories(); }

  /* ── events ── */
  const closeMenu = () => { const mnu = main.querySelector('.chp-menu'); if (mnu && !mnu.hidden) { mnu.hidden = true; main.querySelector('[data-act=attach]')?.setAttribute('aria-expanded', 'false'); } };
  async function onClick(ev) {
    if (!ev.target.closest('.chp-attach-wrap')) closeMenu();
    if (!ev.target.closest('.chp-emo-wrap')) { const e2 = main.querySelector('.chp-emo'); if (e2 && !e2.hidden) e2.hidden = true; }
    if (!ev.target.closest('.chp-rpick, [data-react-open]')) main.querySelectorAll('.chp-rpick').forEach((x) => x.remove());
    if (ev.target.closest('.chp-mention') === null) hideMention();
    const seek = ev.target.closest('[data-vseek]'); if (seek) { seekVoice(seek, ev); return; }
    if (ev.target.matches('.chp-sheet-bg')) { closeSheet(); return; }
    if (ev.target.matches('.chp-mm-bg')) { closeMsgMenu(); return; }
    const bub = ev.target.closest('.chp-bubble'); const t = ev.target.closest('button, [data-open]');
    if (bub && !t && st.sel) { const mid = bub.closest('.chp-msg')?.dataset.mid; if (mid && !mid.startsWith('local')) { if (st.sel.has(mid)) st.sel.delete(mid); else st.sel.add(mid); paintSel(); } return; }
    if (bub && !t && window.matchMedia('(pointer: coarse)').matches) { const mid = bub.closest('.chp-msg')?.dataset.mid; if (mid) openMsgMenu(mid); return; }
    if (bub && !t) { const msg = bub.closest('.chp-msg'); main.querySelectorAll('.chp-msg.is-picked').forEach((x) => { if (x !== msg) x.classList.remove('is-picked'); }); msg?.classList.toggle('is-picked'); return; }   // touch: tap a message to show its actions
    if (!t) return;
    if (t.dataset.open) return openChannel(t.dataset.open);
    if (t.dataset.tab) { st.tab = t.dataset.tab; paintList(); return; }
    if (t.closest('.chp-mm') && !t.dataset.msgmenu) setTimeout(closeMsgMenu, 0);   // any menu choice closes the menu (after its own handler runs)
    if (t.dataset.msgmenu) return openMsgMenu(t.dataset.msgmenu);
    if (t.dataset.copy) { const m = st.msgs.find((x) => x.id === t.dataset.copy); closeMsgMenu(); try { await navigator.clipboard.writeText(m?.text || ''); toast(L('النص انسخ.', 'Text copied.'), 'success'); } catch { toast(L('ما قدرت أنسخ هون.', 'Could not copy here.'), 'error'); } return; }
    if (t.dataset.selstart) { closeMsgMenu(); st.sel = new Set([t.dataset.selstart]); paintSel(); return; }
    if (t.matches('[data-vplay]')) return playVoice(t.closest('.chp-voice'));
    if (t.dataset.pref) { const on = t.getAttribute('aria-pressed') !== 'true'; try { const r = await apiRequest('POST', `/api/chat/${st.open}/prefs`, { [t.dataset.pref]: on }, 15000); st.ch = { ...st.ch, ...r.channel }; if (t.dataset.pref === 'archived' && on) toast(L('انأرشفت. بتلاقيها تحت «المؤرشفة».', 'Archived. Find it under "Archived".'), 'success'); await loadList(); repaintPanel(); } catch (e) { say(e); } return; }
    if (t.dataset.mute != null) { try { const r = await apiRequest('POST', `/api/chat/${st.open}/prefs`, { mute: Number(t.dataset.mute) }, 15000); st.ch = { ...st.ch, ...r.channel }; await loadList(); repaintPanel(); } catch (e) { say(e); } return; }
    if (t.dataset.shared) { st.sharedKind = t.dataset.shared; st.shared = null; repaintPanel(); try { st.shared = (await apiRequest('GET', `/api/chat/${st.open}/shared?kind=${st.sharedKind}`, undefined, 15000)).items; } catch (e) { st.shared = []; say(e); } const bx = info.querySelector('[data-sharedbox]'); if (bx) { bx.innerHTML = sharedItems(); hydrate(bx); } return; }
    if (t.dataset.readers) { try { const r = await apiRequest('GET', `/api/chat/${st.open}/messages/${t.dataset.readers}/readers`, undefined, 15000); openSheet(`${sheetHead(L('مين قرأ', 'Seen by'))}<ul class="chp-members">${r.readers.length ? r.readers.map((x) => `<li><span class="chp-avatar" style="--h:${hueOf(x.uid)}" aria-hidden="true"${avAttr(x.uid, x.av)}>${esc((x.name || '?').charAt(0).toUpperCase())}</span><span class="chp-member-txt"><b>${esc(x.name)}</b></span></li>`).join('') : `<li class="chp-muted">${esc(L('ما حدا قرأها لسا.', 'Nobody has read it yet.'))}</li>`}</ul>`); hydrate(el.querySelector('.chp-sheet')); } catch (e) { say(e); } return; }
    if (t.dataset.openmsg) { const [cid, mid] = t.dataset.openmsg.split(':'); st.q = ''; const qi = side.querySelector('[data-q]'); if (qi) qi.value = ''; await openChannel(cid); if (mid) gotoMsg(mid); return; }
    if (t.dataset.person) return openPerson(t.dataset.person);
    if (t.dataset.shareto) return shareTo(t.dataset.shareto);
    if (t.dataset.devout === 'all') {   // v368: a copied session looks the same as this one, so "everywhere" really means every device, this one included
      try { await apiRequest('POST', '/api/chat/me/devices/signout', { all: true, current: deviceId() }, 15000); toast(L('طلعت من كل الأجهزة. ادخل من جديد.', 'Signed out everywhere. Sign in again.'), 'success'); setTimeout(() => { auth.signOut(); location.hash = '#/login'; }, 800); } catch (e) { say(e); } return; }
    if (t.dataset.devout) { try { st.devs = (await apiRequest('POST', '/api/chat/me/devices/signout', t.dataset.devout === 'all' ? { all: true, current: deviceId() } : { id: t.dataset.devout, current: deviceId() }, 15000)).devices; openDevices(true); toast(L('طلع من الجهاز. لازم يسجّل دخول من جديد.', 'Signed out there. It has to sign in again.'), 'success'); } catch (e) { say(e); } return; }
    if (t.dataset.delfolder) { const fl = (st.folders || []).filter((f) => f.id !== t.dataset.delfolder); try { st.folders = (await apiRequest('PUT', '/api/chat/me/folders', { folders: fl }, 15000)).folders; if (st.tab === `f:${t.dataset.delfolder}`) st.tab = 'all'; paintList(); openFolders(); } catch (e) { say(e); } return; }
    if (t.dataset.botedit) return openBotEdit(t.dataset.botedit);
    if (t.dataset.botdel) { if (t.dataset.armed !== '1') { t.dataset.armed = '1'; t.textContent = L('أكيد؟', 'Sure?'); return; } try { st.bots = (await apiRequest('DELETE', `/api/chat/bots/${t.dataset.botdel}`, undefined, 15000)).bots; openBots(); } catch (e) { say(e); } return; }
    if (t.dataset.bottoken) { try { const r = await apiRequest('PATCH', `/api/chat/bots/${t.dataset.bottoken}`, { newToken: true }, 15000); showToken(r.bot); } catch (e) { say(e); } return; }
    if (t.dataset.copytxt) { try { await navigator.clipboard.writeText(t.dataset.copytxt); toast(L('انسخ.', 'Copied.'), 'success'); } catch { /* select instead */ } return; }
    if (t.dataset.secret) { closeSheet(); try { const k = await deviceKey(); const r = await apiRequest('POST', '/api/chat/secret', { uid: t.dataset.secret, pub: k.pub }, 15000); await loadList(); await openChannel(r.channel.id); } catch (e) { say(e); } return; }
    if (t.dataset.unsched) { try { st.sched = (await apiRequest('DELETE', `/api/chat/${st.open}/scheduled/${t.dataset.unsched}`, undefined, 15000)).scheduled; st.schedN = st.sched.length; openSchedList(); keepDraft(); paintMain(); } catch (e) { say(e); } return; }
    if (t.dataset.topic != null && t.matches('.chp-topic')) { st.topic = t.dataset.topic || null; keepDraft(); paintMain(); return; }
    if (t.dataset.ttl != null) { try { const r = await apiRequest('POST', `/api/chat/${st.open}/ttl`, { ttl: Number(t.dataset.ttl) }, 15000); st.ch = { ...st.ch, ...r.channel }; keepDraft(); paintMain(); } catch (e) { say(e); } return; }
    if (t.dataset.deltopic) { try { const r = await apiRequest('DELETE', `/api/chat/${st.open}/topics/${t.dataset.deltopic}`, undefined, 15000); st.ch = { ...st.ch, ...r.channel }; if (st.topic === t.dataset.deltopic) st.topic = null; keepDraft(); paintMain(); } catch (e) { say(e); } return; }
    if (t.dataset.tr) { t.disabled = true; try { const r = await apiRequest('POST', `/api/chat/${st.open}/messages/${t.dataset.tr}/translate`, { lang: AR ? 'ar' : 'en' }, 40000); st.tr = st.tr || {}; st.tr[t.dataset.tr] = r.text; repaintMsgs(false); } catch (e) { say(e); } finally { if (t.isConnected) t.disabled = false; } return; }
    if (t.dataset.mkstk) { try { st.stickers = (await apiRequest('POST', `/api/chat/${st.open}/messages/${t.dataset.mkstk}/sticker`, {}, 30000)).stickers; toast(L('صارت ستيكر عندك.', 'Added to your stickers.'), 'success'); } catch (e) { say(e); } return; }
    if (t.dataset.emotab) { const pop = t.closest('.chp-emo'); pop.querySelectorAll('[data-emotab]').forEach((x) => x.setAttribute('aria-selected', String(x === t))); pop.querySelector('[data-emogrid]').hidden = t.dataset.emotab !== 'e'; const sg = pop.querySelector('[data-stkgrid]'); sg.hidden = t.dataset.emotab !== 's'; if (!sg.hidden) paintStickers(sg); return; }
    if (t.dataset.stk) { main.querySelector('.chp-emo').hidden = true; try { const r = await apiRequest('POST', `/api/chat/${st.open}/messages`, { sticker: t.dataset.stk, topic: st.topic || undefined, replyTo: st.reply?.id }, 30000); st.reply = null; if (!st.msgs.some((m) => m.id === r.message.id)) st.msgs.push(r.message); keepDraft(); paintMain(); loadList(); } catch (e) { say(e); } return; }
    if (t.dataset.stkdel) { try { st.stickers = (await apiRequest('DELETE', `/api/chat/stickers/${t.dataset.stkdel}`, undefined, 15000)).stickers; const sg = main.querySelector('[data-stkgrid]'); if (sg) paintStickers(sg); } catch (e) { say(e); } return; }
    if (t.dataset.story) return openStory(t.dataset.story);
    if (t.matches('[data-vspeed]')) { const sp = { '1x': 1.5, '1.5x': 2, '2x': 1 }[t.textContent] || 1; t.textContent = `${sp}x`; const a = voice.get(t.closest('.chp-voice')?.dataset.voice); if (a) a.playbackRate = sp; return; }
    if (t.dataset.doc) return downloadDoc(t);
    if (t.dataset.vote) { try { const r = await apiRequest('POST', `/api/chat/${st.open}/messages/${t.dataset.vote}/vote`, { option: Number(t.dataset.opt) }, 15000); const m = st.msgs.find((x) => x.id === t.dataset.vote); if (m) { Object.assign(m, r.message); repaintMsgs(false); } } catch (e) { say(e); } return; }
    if (t.dataset.pollclose) { try { const r = await apiRequest('POST', `/api/chat/${st.open}/messages/${t.dataset.pollclose}/vote`, { close: true }, 15000); const m = st.msgs.find((x) => x.id === t.dataset.pollclose); if (m) { Object.assign(m, r.message); repaintMsgs(false); } } catch (e) { say(e); } return; }
    if (t.dataset.fwd) return openForward(t.dataset.fwd);
    if (t.dataset.fwdto) return doForward(t.dataset.fwdto);
    if (t.dataset.save) { try { const sv = (await apiRequest('POST', '/api/chat/saved', {}, 15000)).channel; await apiRequest('POST', `/api/chat/${st.open}/messages/${t.dataset.save}/forward`, { to: sv.id }, 60000); toast(L('انحفظت بالمحفوظات.', 'Saved.'), 'success'); loadList(); } catch (e) { say(e); } return; }
    if (t.dataset.report) { if (t.dataset.armed !== '1') { t.dataset.armed = '1'; toast(L('اضغط كمان مرة لتبلّغ عن الرسالة.', 'Tap again to report the message.'), 'info'); return; } try { await apiRequest('POST', `/api/chat/${st.open}/report`, { mid: t.dataset.report }, 15000); toast(L('وصل البلاغ لإدارة الموقع. شكرًا.', 'Report sent to the site team. Thanks.'), 'success'); } catch (e) { say(e); } return; }
    if (t.dataset.dm) return startDm(t.dataset.dm);
    if (t.dataset.pick != null && t.closest('[data-mention]')) return pickMention(t);
    if (t.dataset.cmd && t.closest('[data-mention]')) { const ta = main.querySelector('[data-text]'); if (ta) { ta.value = `/${t.dataset.cmd}`; hideMention(); ta.form?.classList.remove('is-empty'); send(ta.form); } return; }
    if (t.dataset.comments) return openComments(t.dataset.comments);
    if (t.dataset.delcmt) { try { st.cmts = await apiRequest('DELETE', `/api/chat/${st.open}/messages/${st.cmtMid}/comments/${t.dataset.delcmt}`, undefined, 15000); paintComments(); } catch (e) { say(e); } return; }
    if (t.dataset.wall) { try { localStorage.setItem('gt-wall', t.dataset.wall); } catch { /* ignore */ } applyWall(); el.querySelectorAll('[data-wall]').forEach((x) => x.setAttribute('aria-checked', String(x === t))); return; }
    if (t.dataset.copyinv) { const url = `${location.origin}/#/app/chat?join=${t.dataset.copyinv}`; try { await navigator.clipboard.writeText(url); toast(L('الرابط انسخ.', 'Link copied.'), 'success'); } catch { window.prompt?.(L('انسخ الرابط', 'Copy the link'), url); } return; }
    if (t.dataset.dropinv) { try { const r = await apiRequest('DELETE', `/api/chat/${st.open}/invites/${t.dataset.dropinv}`, undefined, 15000); st.invites = r.invites || []; repaintPanel(); } catch (e) { say(e); } return; }
    if (t.dataset.req) { try { const r = await apiRequest('POST', `/api/chat/${st.open}/requests/${t.dataset.req}`, { accept: t.dataset.accept === '1' }, 15000); st.members = r.members; st.requests = r.requests || []; st.invites = r.invites || []; repaintPanel(); loadList(); } catch (e) { say(e); } return; }
    if (t.dataset.clearrep) { try { st.reports = (await apiRequest('DELETE', `/api/chat/reports/${t.dataset.clearrep}`, undefined, 15000)).reports; paintMods(); } catch (e) { say(e); } return; }
    if (t.dataset.join) { try { const r = await apiRequest('POST', `/api/chat/invite/${t.dataset.join}`, {}, 15000); closeSheet(); if (r.asked) toast(L('انبعت طلبك. لما المشرف يوافق بتطلعلك المجموعة.', 'Request sent. The group shows up once an admin accepts.'), 'success'); else { await loadList(); await openChannel(r.id); } } catch (e) { say(e); } return; }
    if (t.dataset.goto) return gotoMsg(t.dataset.goto);
    if (t.dataset.ins) { const ta = main.querySelector('[data-text]'); if (ta) { const a = ta.selectionStart ?? ta.value.length; ta.value = ta.value.slice(0, a) + t.dataset.ins + ta.value.slice(ta.selectionEnd ?? a); ta.focus(); ta.selectionStart = ta.selectionEnd = a + t.dataset.ins.length; ta.form?.classList.remove('is-empty'); grow(ta); } return; }
    if (t.dataset.reply || t.dataset.edit) { const m = st.msgs.find((x) => x.id === (t.dataset.reply || t.dataset.edit)); if (!m) return; keepDraft(); if (t.dataset.edit) { st.edit = m; st.reply = null; st.draft = m.text; clearPending(); } else { st.reply = m; if (st.edit) { st.edit = null; st.draft = ''; } } paintMain(); main.querySelector('[data-text]')?.focus(); return; }
    if (t.dataset.pin) { try { await apiRequest('POST', `/api/chat/${st.open}/pin`, { id: st.pinned?.id === t.dataset.pin ? null : t.dataset.pin }, 15000); st.pinned = st.pinned?.id === t.dataset.pin ? null : st.msgs.find((x) => x.id === t.dataset.pin) || null; st.hidePin = ''; paintLive(); repaintMsgs(false); } catch (e) { say(e); } return; }
    if (t.dataset.reactOpen) { const bub = t.closest('.chp-bubble'); main.querySelectorAll('.chp-rpick').forEach((x) => x.remove()); const pick = h(`<div class="chp-rpick" role="menu">${(st.list?.reactions || ['👍', '❤️', '🔥', '😂', '😮', '🙏', '🚀', '📈']).map((e) => `<button type="button" role="menuitem" data-react="${esc(t.dataset.reactOpen)}" data-emoji="${e}" aria-label="${e}">${e}</button>`).join('')}</div>`); bub.append(pick); pick.querySelector('button')?.focus(); return; }
    if (t.dataset.react) { main.querySelectorAll('.chp-rpick').forEach((x) => x.remove()); try { const r = await apiRequest('POST', `/api/chat/${st.open}/messages/${t.dataset.react}/react`, { emoji: t.dataset.emoji }, 15000); const m = st.msgs.find((x) => x.id === t.dataset.react); if (m) { Object.assign(m, r.message); repaintMsgs(false); } } catch (e) { say(e); } return; }
    if (t.dataset.mod) { const act = t.dataset.do; if (act === 'ban' && t.dataset.armed !== '1') { t.dataset.armed = '1'; t.textContent = L('أكيد؟', 'Sure?'); return; }
      try { await apiRequest('POST', `/api/chat/${st.open}/moderate/${t.dataset.mod}`, { action: act, minutes: act === 'mute' ? 1440 : undefined }, 15000); toast({ ban: L('انحظر وطلع من المجموعة.', 'Banned and removed.'), unban: L('انفك الحظر. ضيفه من جديد إذا بدك.', 'Unbanned. Add them again if you like.'), mute: L('انكتم ليوم.', 'Muted for a day.'), unmute: L('انفك الكتم.', 'Unmuted.') }[act] || '', 'success'); st.members = null; loadMembers(); } catch (e) { say(e); } return; }
    if (t.dataset.zoom) { const im = lb.querySelector('img'); im.removeAttribute('src'); blob(st.open, t.dataset.zoom).then((u) => { if (u) im.src = u; }); im.alt = t.querySelector('img')?.alt || ''; lb.hidden = false; lb.querySelector('button').focus(); return; }
    if (t.dataset.play) return playVideo(t);
    if (t.hasAttribute('data-close-lb')) { lb.hidden = true; return; }
    if (t.dataset.callAct) {
      const a = t.dataset.callAct; const c = st.call; if (!c) return;
      if (a === 'mic') c.toggleMic(); else if (a === 'cam') c.toggleCam(); else if (a === 'flip') c.flip(); else if (a === 'screen') c.toggleScreen();
      else if (a === 'chat') { st.callChat = !st.callChat; callUi(); if (st.callChat) el.querySelector('[data-callsay] input')?.focus(); }
      else if (a === 'leave') leaveCall(false);
      else if (a === 'end') { if (t.dataset.armed !== '1') { t.dataset.armed = '1'; t.querySelector('small').textContent = L('أكيد؟', 'Sure?'); return; } leaveCall(true); }
      return;
    }
    if (t.dataset.color) { try { const r = await apiRequest('PATCH', `/api/chat/${st.open}`, { color: t.dataset.color }, 15000); st.ch = { ...st.ch, ...r.channel }; applyColor(); repaintPanel(); loadList(); } catch (e) { say(e); } return; }
    if (t.dataset.newcolor) { st.newColor = t.dataset.newcolor; keepNewName(); paintNew(); restoreNewName(); return; }
    if (t.dataset.del && !t.dataset.how) { const m = st.msgs.find((x) => x.id === t.dataset.del); if (!m) return; const all = m.uid === me() || st.ch?.perms?.delete || st.ch?.role === 'admin';
      openSheet(`${sheetHead(L('حذف الرسالة', 'Delete message'))}<div class="chp-sheet-acts"><button type="button" class="chp-btn chp-btn-ghost chp-btn-wide" data-del="${esc(m.id)}" data-how="me">${esc(L('احذف عندي بس', 'Delete for me'))}</button>${all && !isPriv(st.ch) || (all && isOne(st.ch)) ? `<button type="button" class="chp-btn chp-btn-danger chp-btn-wide" data-del="${esc(m.id)}" data-how="all">${esc(L('احذف عند الكل', 'Delete for everyone'))}</button>` : ''}</div>`); return; }
    if (t.dataset.how === 'me') { try { await apiRequest('POST', `/api/chat/${st.open}/messages/${t.dataset.del}/hide`, {}, 15000); closeSheet(); st.msgs = st.msgs.filter((x) => x.id !== t.dataset.del); repaintMsgs(false); } catch (e) { say(e); } return; }
    if (t.dataset.how === 'all') { closeSheet(); t.dataset.armed = '1'; }
    if (t.dataset.del) { if (t.dataset.armed !== '1') { t.dataset.armed = '1'; t.classList.add('is-armed'); t.setAttribute('aria-label', L('اضغط كمان مرة للحذف', 'Tap again to delete')); setTimeout(() => { t.dataset.armed = ''; t.classList.remove('is-armed'); }, 3000); return; }
      try { await apiRequest('DELETE', `/api/chat/${st.open}/messages/${t.dataset.del}`, undefined, 15000); const m = st.msgs.find((x) => x.id === t.dataset.del); if (m) { m.deleted = true; m.text = ''; m.file = null; } repaintMsgs(false); } catch (e) { say(e); } return; }
    if (t.dataset.role) { try { const r = await apiRequest('PATCH', `/api/chat/${st.open}/members/${t.dataset.role}`, { role: t.dataset.to }, 15000); st.members = r.members; repaintPanel(); } catch (e) { say(e); } return; }
    if (t.dataset.kick) { if (t.dataset.armed !== '1') { t.dataset.armed = '1'; t.textContent = L('أكيد؟', 'Sure?'); return; } try { const r = await apiRequest('DELETE', `/api/chat/${st.open}/members/${t.dataset.kick}`, undefined, 15000); st.members = r.members; repaintPanel(); } catch (e) { say(e); } return; }
    if (t.dataset.unmod) { try { st.mods = await apiRequest('DELETE', `/api/chat/mods/${encodeURIComponent(t.dataset.unmod)}`, undefined, 15000); paintMods(); } catch (e) { say(e); } return; }
    if (t.dataset.ownerDel) { if (t.dataset.armed !== '1') { t.dataset.armed = '1'; t.textContent = L('أكيد؟ بتنحذف لكل الأعضاء', 'Sure? Gone for everyone'); return; } try { await apiRequest('DELETE', `/api/chat/${t.dataset.ownerDel}`, undefined, 15000); if (st.open === t.dataset.ownerDel) { st.open = null; st.ch = null; } loadMods(); loadList(); } catch (e) { say(e); } return; }
    const act = t.dataset.act; if (!act) return;
    if (act === 'new') { st.panel = 'new'; st.open = null; st.ch = null; pollGen++; st.newLogo = null; st.newColor = CHANNEL_COLORS[0]; paintSide(); paintMain(); main.querySelector('input[name=name]')?.focus(); }
    else if (act === 'mods') { st.panel = 'mods'; st.open = null; st.ch = null; pollGen++; paintSide(); paintMain(); loadMods(); }
    else if (act === 'cancel' || act === 'back') { st.panel = null; st.open = null; st.ch = null; pollGen++; paintSide(); paintMain(); }
    else if (act === 'settings') { st.info = !st.info; if (st.info) { st.members = null; } paintInfo(); main.querySelector('[data-act=settings][aria-expanded]')?.setAttribute('aria-expanded', String(st.info)); if (st.info) info.querySelector('.chp-panel-head button')?.focus(); }
    else if (act === 'saved') { try { const r = await apiRequest('POST', '/api/chat/saved', {}, 15000); await loadList(); await openChannel(r.channel.id); } catch (e) { say(e); } }
    else if (act === 'block' || act === 'unblock') { try { const r = await apiRequest('POST', `/api/chat/${st.open}/block`, { on: act === 'block' }, 15000); st.ch = { ...st.ch, ...r.channel }; keepDraft(); paintMain(); toast(act === 'block' ? L('انحظر. ما بيقدر يبعتلك.', 'Blocked. They can\'t message you.') : L('انفك الحظر.', 'Unblocked.'), 'success'); } catch (e) { say(e); } }
    else if (act === 'reportchat') { if (t.dataset.armed !== '1') { t.dataset.armed = '1'; t.querySelector('span').textContent = L('أكيد؟ اضغط كمان مرة', 'Sure? Tap again'); return; } try { await apiRequest('POST', `/api/chat/${st.open}/report`, { about: nameOf(st.ch) }, 15000); toast(L('وصل البلاغ لإدارة الموقع.', 'Report sent to the site team.'), 'success'); } catch (e) { say(e); } }
    else if (act === 'secretaccept') { try { const k = await deviceKey(); const r = await apiRequest('POST', `/api/chat/${st.open}/secret/accept`, { pub: k.pub }, 15000); st.ch = { ...st.ch, ...r.channel }; await secretInfo(st.ch); keepDraft(); paintMain(); loadList(); } catch (e) { say(e); } }
    else if (act === 'roundrec') { closeMenu(); recordRound(); }
    else if (act === 'editimg') openEditor();
    else if (act === 'bigstart' || act === 'bigjoin') {
      const w = window.open('', '_blank'); try { if (w) w.opener = null; } catch { /* ignore */ }
      try { const r = await apiRequest('POST', `/api/chat/${st.open}/bigcall`, { action: act === 'bigstart' ? 'start' : 'join' }, 15000); if (w) w.location.href = r.url; else location.assign(r.url); if (act === 'bigstart') { st.ch = { ...st.ch, bigCall: { at: Date.now(), by: L('إنت', 'you') } }; keepDraft(); paintMain(); } }
      catch (e) { w?.close(); say(e); } }
    else if (act === 'bigend') { try { await apiRequest('POST', `/api/chat/${st.open}/bigcall`, { action: 'end' }, 15000); st.ch = { ...st.ch, bigCall: null }; keepDraft(); paintMain(); } catch (e) { say(e); } }
    else if (act === 'export') exportChat(t);
    else if (act === 'selcancel') { st.sel = null; paintSel(); }
    else if (act === 'selcopy') { const txt = st.msgs.filter((m) => st.sel?.has(m.id) && m.text).map((m) => `${m.name || ''}: ${m.text}`).join('\n'); try { await navigator.clipboard.writeText(txt); toast(L('انسخوا.', 'Copied.'), 'success'); } catch { /* ignore */ } st.sel = null; paintSel(); }
    else if (act === 'selfwd') { fwdMany = [...st.sel].filter((id) => !st.msgs.find((m) => m.id === id)?.poll); openForward(fwdMany[0]); }
    else if (act === 'seldel') { const ids = [...st.sel]; const all = t.dataset.all === '1';
      openSheet(`${sheetHead(L(`حذف ${ids.length} رسائل`, `Delete ${ids.length} messages`))}<div class="chp-sheet-acts"><button type="button" class="chp-btn chp-btn-ghost chp-btn-wide" data-act="seldelgo" data-how="me">${esc(L('احذفهم عندي بس', 'Delete for me'))}</button>${all ? `<button type="button" class="chp-btn chp-btn-danger chp-btn-wide" data-act="seldelgo" data-how="all">${esc(L('احذفهم عند الكل', 'Delete for everyone'))}</button>` : ''}</div>`); }
    else if (act === 'seldelgo') { const ids = [...(st.sel || [])]; const how = t.dataset.how; closeSheet();
      for (const id of ids) { try { if (how === 'all') { await apiRequest('DELETE', `/api/chat/${st.open}/messages/${id}`, undefined, 15000); const m = st.msgs.find((x) => x.id === id); if (m) { m.deleted = true; m.text = ''; m.file = null; } } else { await apiRequest('POST', `/api/chat/${st.open}/messages/${id}/hide`, {}, 15000); st.msgs = st.msgs.filter((x) => x.id !== id); } } catch (e) { say(e); break; } }
      st.sel = null; repaintMsgs(false); paintSel(); }
    else if (act === 'folders') openFolders();
    else if (act === 'folderedit') openFolderEdit(t.dataset.fid || null);
    else if (act === 'devices') openDevices();
    else if (act === 'lockset') openLockSet();
    else if (act === 'lockoff') { const pin = el.querySelector('[data-lockpin]')?.value || ''; if (await checkPin(pin)) { try { localStorage.removeItem('gt-lock'); } catch { /* ignore */ } closeSheet(); toast(L('القفل انشال.', 'Lock removed.'), 'success'); } else toast(L('الرقم غلط.', 'Wrong PIN.'), 'error'); }
    else if (act === 'bots') openBots();
    else if (act === 'arch') { st.showArch = !st.showArch; paintList(); }
    else if (act === 'profile') openProfile();
    else if (act === 'avpick') el.querySelector('[data-avpick]').click();
    else if (act === 'avdel') { try { const r = await apiRequest('DELETE', '/api/chat/me/avatar', undefined, 15000); st.myAv = r.av; st.me = r; openProfile(); paintSide(); } catch (e) { say(e); } }
    else if (act === 'later') { closeMenu(); keepDraft(); openLater(); }
    else if (act === 'schedlist') openSchedList();
    else if (act === 'stkadd') el.querySelector('[data-stkpick]').click();
    else if (act === 'storyadd') el.querySelector('[data-storypick]').click();
    else if (act === 'storypost') return postStory();
    else if (act === 'docpick') { closeMenu(); el.querySelector('[data-docpick]').click(); }
    else if (act === 'poll') { closeMenu(); openPollSheet(); }
    else if (act === 'pollopt') { const box = el.querySelector('[data-pollopts]'); if (box && box.children.length < 10) { box.append(h(`<input name="opt" maxlength="100" placeholder="${esc(L('خيار', 'Option'))} ${box.children.length + 1}">`)); box.lastElementChild.focus(); } }
    else if (act === 'closesheet') closeSheet();
    else if (act === 'rec') startRec();
    else if (act === 'reccancel') stopRec(false);
    else if (act === 'recsend') stopRec(true);
    else if (act === 'unpin') { try { await apiRequest('POST', `/api/chat/${st.open}/pin`, { id: null }, 15000); st.pinned = null; paintLive(); } catch (e) { say(e); } }
    else if (act === 'hidepin') { st.hidePin = st.pinned?.id || ''; paintLive(); }
    else if (act === 'noctx') { if (st.edit) st.draft = ''; else keepDraft(); st.reply = null; st.edit = null; paintMain(); main.querySelector('[data-text]')?.focus(); }
    else if (act === 'emo') { const e2 = main.querySelector('.chp-emo'); e2.hidden = !e2.hidden; t.setAttribute('aria-expanded', String(!e2.hidden)); }
    else if (act === 'search') { keepDraft(); st.search = st.search ? null : { q: '', results: null }; paintMain(); main.querySelector('[data-msearch] input')?.focus(); }
    else if (act === 'notify') { const on = st.ch.notify === false; try { await apiRequest('POST', `/api/chat/${st.open}/notify`, { on }, 15000); st.ch = { ...st.ch, notify: on }; const c = st.list?.channels.find((x) => x.id === st.open); if (c) c.notify = on; keepDraft(); paintMain(); paintList(); toast(on ? L('رح توصلك إشعارات هالمجموعة.', 'You will get this group\'s notifications.') : L('ما رح توصلك إشعارات منها.', 'No more notifications from it.'), 'success'); } catch (e) { say(e); } }
    else if (act === 'attach') { main.querySelectorAll('.chp-msg.is-picked').forEach((x) => x.classList.remove('is-picked')); const mnu = main.querySelector('.chp-menu'); mnu.hidden = !mnu.hidden; t.setAttribute('aria-expanded', String(!mnu.hidden)); if (!mnu.hidden) mnu.querySelector('button')?.focus(); }
    else if (act === 'camera') { closeMenu(); const { openCamera } = await import('../components/chatCamera.js'); const r = await openCamera(); if (r?.error) say({ code: r.error }); else if (r?.blob) setPending(r.blob, r.kind); }
    else if (act === 'native') { closeMenu(); el.querySelector('[data-native]').click(); }
    else if (act === 'gallery') { closeMenu(); el.querySelector('[data-gallery]').click(); }
    else if (act === 'tobottom') { const box = msgsEl(); if (box) box.scrollTo({ top: box.scrollHeight, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }); st.newBelow = 0; paintFab(); }
    else if (act === 'startcall') joinCall(true);
    else if (act === 'joincall') { if (st.callView?.joined) callUi(); else joinCall(false); }
    else if (act === 'older') { const first = st.msgs.find((m) => m.seq)?.seq || 0; try { const r = await apiRequest('GET', `/api/chat/${st.open}?before=${first}`, undefined, 15000); await decAll(r.messages); const box = msgsEl(); const h0 = box.scrollHeight; const have = new Set(st.msgs.map((m) => m.id)); st.msgs = [...r.messages.filter((m) => !have.has(m.id)), ...st.msgs]; st.more = r.more; repaintMsgs(false); box.scrollTop = box.scrollHeight - h0; } catch (e) { say(e); } }
    else if (act === 'unpick') { clearPending(); keepDraft(); paintMain(); }
    else if (act === 'nologo') { try { await apiRequest('PATCH', `/api/chat/${st.open}`, { logo: null }, 20000); st.ch.logo = null; st.info = true; paintMain(); loadList(); } catch (e) { say(e); } }
    else if (act === 'delete' || act === 'leave') {
      const box = main.querySelector('[data-confirm]');
      if (t.dataset.armed !== '1') { t.dataset.armed = '1'; box.hidden = false; box.textContent = act === 'delete' ? L('اضغط كمان مرة: القناة ورسائلها وصورها بتنحذف لكل الأعضاء، وما بترجع.', 'Tap again: the channel, its messages and photos are deleted for everyone, for good.') : L('اضغط كمان مرة لتطلع. ما بترجع إلا إذا مشرف ضافك.', 'Tap again to leave. Only an admin can add you back.'); return; }
      try { if (act === 'delete') await apiRequest('DELETE', `/api/chat/${st.open}`, undefined, 15000); else await apiRequest('DELETE', `/api/chat/${st.open}/members/${me()}`, undefined, 15000); st.open = null; st.ch = null; st.panel = null; pollGen++; paintMain(); loadList(); } catch (e) { say(e); }
    }
  }
  el.addEventListener('click', onClick);
  let newName = '';
  // the new-group form is redrawn when a logo or colour is picked: every field the person filled in is kept
  const keepNewName = () => { const f = main.querySelector('[data-create]'); if (f) newName = Object.fromEntries([...f.elements].filter((x) => x.name).map((x) => [x.name, x.value])); };
  const restoreNewName = () => { const f = main.querySelector('[data-create]'); if (!f || !newName || typeof newName !== 'object') return; for (const x of f.elements) if (x.name && newName[x.name] != null) x.value = newName[x.name]; };
  async function onSubmit(ev) {
    ev.preventDefault(); const f = ev.target;
    if (f.matches('[data-compose]')) return send(f);
    if (f.matches('[data-msearch]')) { const q = f.q.value.trim(); if (q.length < 2) return; try { const r = await apiRequest('GET', `/api/chat/${st.open}/search?q=${encodeURIComponent(q)}`, undefined, 15000); st.search = { q, results: r.results }; keepDraft(); paintMain(); main.querySelector('[data-msearch] input')?.focus(); } catch (e) { say(e); } return; }
    if (f.matches('[data-meta]')) { const b = f.querySelector('button:not([type=button])'); if (b) b.disabled = true; try { const r = await apiRequest('PATCH', `/api/chat/${st.open}`, { name: f.name.value, description: f.description.value, rules: f.rules.value, type: f.type.value, category: f.category.value, access: f.access.value, minRank: Number(f.minRank.value), slow: Number(f.slow.value), filterLinks: f.filterLinks.checked, words: f.words.value, ...(f.verified ? { verified: f.verified.checked } : {}) }, 20000); st.ch = { ...st.ch, ...r.channel }; toast(L('انحفظ.', 'Saved.'), 'success'); keepDraft(); paintMain(); loadList(); } catch (e) { say(e); } finally { if (b?.isConnected) b.disabled = false; } return; }
    if (f.matches('[data-cmtform]')) { const v = f.t.value.trim(); if (!v) return; try { st.cmts = await apiRequest('POST', `/api/chat/${st.open}/messages/${st.cmtMid}/comments`, { text: v }, 15000); f.t.value = ''; paintComments(); const m = st.msgs.find((x) => x.id === st.cmtMid); if (m) { m.comments = st.cmts.comments.length; repaintMsgs(false); } } catch (e) { say(e); } return; }
    if (f.matches('[data-folderform]')) { const fid = f.dataset.folderform; const item = { id: fid || undefined, name: f.fname.value.trim(), emoji: f.femoji.value.trim(), chats: [...f.querySelectorAll('input[name=fc]:checked')].map((x) => x.value), types: [...f.querySelectorAll('input[name=ft]:checked')].map((x) => x.value), unread: f.funread.checked };
      const list = fid ? (st.folders || []).map((x) => (x.id === fid ? { ...x, ...item, id: fid } : x)) : [...(st.folders || []), item];
      try { st.folders = (await apiRequest('PUT', '/api/chat/me/folders', { folders: list }, 15000)).folders; closeSheet(); if (!fid) st.tab = `f:${st.folders.at(-1)?.id}`; paintList(); } catch (e) { say(e); } return; }
    if (f.matches('[data-lockform]')) { const a = f.pin.value.trim(); if (!/^\d{4,8}$/.test(a) || a !== f.pin2.value.trim()) return toast(L('الرقم لازم 4 لـ8 أرقام ومتطابق مرتين.', 'Use 4–8 digits, the same twice.'), 'error'); await setPin(a, Number(f.mins.value)); closeSheet(); toast(L('الدردشة صارت مقفولة برقمك.', 'Chat lock is on.'), 'success'); return; }
    if (f.matches('[data-lockgate]')) {
      // wrong tries are remembered across reloads; after 5 the wait doubles each time (30 s, 1 min, 2 min … up to 1 hour)
      const fl = (() => { try { return JSON.parse(localStorage.getItem('gt-lock-fails') || '{"n":0,"until":0}'); } catch { return { n: 0, until: 0 }; } })();
      const m2 = f.querySelector('[data-lockmsg]');
      if (fl.until > Date.now()) { if (m2) m2.textContent = L(`استنى ${Math.ceil((fl.until - Date.now()) / 1000)} ثانية.`, `Wait ${Math.ceil((fl.until - Date.now()) / 1000)} seconds.`); return; }
      const ok2 = await checkPin(f.pin.value.trim());
      if (ok2) { try { localStorage.removeItem('gt-lock-fails'); } catch { /* ignore */ } unlock(); return; }
      fl.n += 1; if (fl.n >= 5) fl.until = Date.now() + Math.min(3600_000, 30_000 * 2 ** (fl.n - 5)); try { localStorage.setItem('gt-lock-fails', JSON.stringify(fl)); } catch { /* ignore */ }
      f.pin.value = ''; if (m2) m2.textContent = fl.n >= 5 ? L(`غلط كتير. استنى ${Math.ceil((fl.until - Date.now()) / 1000)} ثانية.`, `Too many tries. Wait ${Math.ceil((fl.until - Date.now()) / 1000)} seconds.`) : L('الرقم غلط.', 'Wrong PIN.'); return; }
    if (f.matches('[data-botnew]')) { try { const r = await apiRequest('POST', '/api/chat/bots', { name: f.bname.value, username: f.busername.value, about: f.babout.value }, 15000); showToken(r.bot); } catch (e) { say(e); } return; }
    if (f.matches('[data-botform]')) { const cmds = f.cmds.value.split('\n').map((l2) => { const m2 = /^\s*\/?([a-zA-Z0-9_]{1,32})\s*[=:-]\s*(.+)$/.exec(l2); return m2 ? { cmd: m2[1], reply: m2[2].replace(/\\n/g, '\n') } : null; }).filter(Boolean);
      try { await apiRequest('PATCH', `/api/chat/bots/${f.dataset.botform}`, { name: f.bname.value, about: f.babout.value, welcome: f.welcome.value, commands: cmds }, 15000); toast(L('البوت انحفظ.', 'Bot saved.'), 'success'); openBots(); } catch (e) { say(e); } return; }
    if (f.matches('[data-addbot]')) { try { const r = await apiRequest('POST', `/api/chat/${st.open}/bots`, { username: f.username.value, admin: f.admin.checked }, 15000); st.members = r.members; repaintPanel(); toast(L('البوت انضاف.', 'Bot added.'), 'success'); } catch (e) { say(e); } return; }
    if (f.matches('[data-profile]')) { try { const r = await apiRequest('PUT', '/api/chat/me/profile', { username: f.username.value, bio: f.bio.value, dmFrom: f.dmFrom.value }, 15000); st.me = r; closeSheet(); toast(L('البروفايل انحفظ.', 'Profile saved.'), 'success'); } catch (e) { say(e); } return; }
    if (f.matches('[data-later]')) { const text = f.text.value.trim(); if (!text) return; const silent = f.silent.checked;
      try { if (f.when.value) { const at = new Date(f.when.value).getTime(); const r = await apiRequest('POST', `/api/chat/${st.open}/scheduled`, { text, at, silent, topic: st.topic || undefined }, 15000); st.schedN = r.scheduled.length; toast(L(`انجدولت لـ ${fmtDay(at)} ${fmtTime(at)}.`, `Scheduled for ${fmtDay(at)} ${fmtTime(at)}.`), 'success'); }
        else { const r = await apiRequest('POST', `/api/chat/${st.open}/messages`, { text, silent: true, topic: st.topic || undefined }, 15000); if (!st.msgs.some((m) => m.id === r.message.id)) st.msgs.push(r.message); }
        closeSheet(); st.draft = ''; saveDraft(st.open, ''); paintMain(); loadList(); } catch (e) { say(e); } return; }
    if (f.matches('[data-topicadd]')) { try { const r = await apiRequest('POST', `/api/chat/${st.open}/topics`, { name: f.name.value, emoji: f.emoji.value.trim() }, 15000); st.ch = { ...st.ch, ...r.channel }; keepDraft(); paintMain(); } catch (e) { say(e); } return; }
    if (f.matches('[data-invite]')) { try { const r = await apiRequest('POST', `/api/chat/${st.open}/invites`, { hours: Number(f.hours.value), max: Number(f.max.value), approve: f.approve.checked }, 15000); st.invites = r.invites || []; repaintPanel(); const url = `${location.origin}/#/app/chat?join=${r.code}`; try { await navigator.clipboard.writeText(url); toast(L('الرابط جاهز وانسخ.', 'Link ready and copied.'), 'success'); } catch { toast(L('الرابط جاهز. انسخه من القائمة.', 'Link ready. Copy it from the list.'), 'success'); } } catch (e) { say(e); } return; }
    if (f.matches('[data-perms]')) { const perms = Object.fromEntries(Object.keys(PERM_NAMES).map((k) => [k, f[k].checked])); try { const r = await apiRequest('PATCH', `/api/chat/${st.open}/members/${f.dataset.perms}`, { role: 'admin', perms }, 15000); st.members = r.members; repaintPanel(); toast(L('الصلاحيات انحفظت.', 'Permissions saved.'), 'success'); } catch (e) { say(e); } return; }
    if (f.matches('[data-pollform]')) { const options = [...f.querySelectorAll('input[name=opt]')].map((x) => x.value.trim()).filter(Boolean); try { const r = await apiRequest('POST', `/api/chat/${st.open}/messages`, { poll: { q: f.q.value, options, anon: f.anon.checked, multi: f.multi.checked }, topic: st.topic || undefined }, 15000); closeSheet(); if (!st.msgs.some((m) => m.id === r.message.id)) st.msgs.push(r.message); appendMsgs(); scrollEnd(true); loadList(); } catch (e) { say(e); } return; }
    if (f.matches('[data-callsay]')) { const v = f.t.value.trim(); if (!v || !st.call) return; f.t.value = ''; try { await st.call.say(v); } catch (e) { say(e); } return; }
    const btn = f.querySelector('button:not([type=button])'); if (btn) btn.disabled = true;
    try {
      if (f.matches('[data-create]')) { const r = await apiRequest('POST', '/api/chat', { name: f.name.value, logo: st.newLogo || undefined, color: st.newColor, type: f.type.value, category: f.category.value, description: f.description.value, access: f.access.value, minRank: Number(f.minRank.value) }, 30000); st.panel = null; newName = ''; await loadList(); toast(r.channel.access === 'plan' ? L('جاهزة، والمشتركين بيشوفوها هلأ.', 'Ready; subscribers see it now.') : L('جاهزة. ضيف أعضاءها من المعلومات.', 'Ready. Add its members from the info panel.'), 'success'); await openChannel(r.channel.id); st.info = true; paintMain(); }
      else if (f.matches('[data-rename]')) { const r = await apiRequest('PATCH', `/api/chat/${st.open}`, { name: f.name.value }, 20000); st.ch = { ...st.ch, ...r.channel }; toast(L('انحفظ.', 'Saved.'), 'success'); paintMain(); st.panel = 'settings'; loadMembers(); loadList(); }
      else if (f.matches('[data-add]')) { const r = await apiRequest('POST', `/api/chat/${st.open}/members`, { email: f.email.value.trim(), role: f.admin.checked ? 'admin' : 'member' }, 20000); st.members = r.members; f.reset(); repaintPanel(); toast(L('انضاف، ووصله إشعار.', 'Added; they were notified.'), 'success'); }
      else if (f.matches('[data-mod-add]')) { st.mods = await apiRequest('POST', '/api/chat/mods', { email: f.email.value.trim() }, 15000); paintMods(); }
    } catch (e) { say(e); }
    finally { if (btn?.isConnected) btn.disabled = false; }
  }
  el.addEventListener('submit', onSubmit);
  el.addEventListener('toggle', async (ev) => {   // the admin log loads when it is opened
    const d = ev.target; if (!d.matches?.('[data-logfold]') || !d.open) return;
    try { st.log = (await apiRequest('GET', `/api/chat/${st.open}/log`, undefined, 15000)).log; const box = info.querySelector('[data-log]'); if (box) box.innerHTML = st.log.length ? st.log.map((x) => `<li><b>${esc(x.by)}</b> ${esc(LOG_NAMES[x.act] || x.act)}${x.target ? ` <i>${esc(x.target)}</i>` : ''}<time>${esc(fmtDay(x.at))} ${esc(fmtTime(x.at))}</time></li>`).join('') : `<li class="chp-muted">${esc(L('ما في إشي لسا.', 'Nothing yet.'))}</li>`; } catch (e) { say(e); }
  }, true);
  el.addEventListener('change', async (ev) => {
    const inp = ev.target;
    if (inp.matches('input[type=color][data-color-custom]')) { try { const r = await apiRequest('PATCH', `/api/chat/${st.open}`, { color: inp.value }, 15000); st.ch = { ...st.ch, ...r.channel }; applyColor(); repaintPanel(); loadList(); } catch (e) { say(e); } return; }
    if (inp.matches('input[type=color][data-newcolor-custom]')) { st.newColor = inp.value; keepNewName(); paintNew(); restoreNewName(); return; }
    const file = inp.files?.[0]; if (!file) return;
    if (inp.matches('[data-native], [data-gallery]')) setPending(file, /^video\//.test(file.type) ? 'video' : 'image');
    else if (inp.matches('[data-docpick]')) sendOther(file, 'file', file.name);
    else if (inp.matches('[data-avpick]')) { try { const b = await shrinkImage(file, 512, 0.88, true, true); const r = await apiUpload('/api/chat/me/avatar', b); st.me = r; st.myAv = r.av; openProfile(); paintSide(); toast(L('الصورة تغيّرت.', 'Photo changed.'), 'success'); } catch (e) { say(e); } }
    else if (inp.matches('[data-stkpick]')) { try { const b = file.type === 'image/gif' && file.size < 1_400_000 ? file : await stickerBlob(file); const r = await apiUpload('/api/chat/stickers', b); st.stickers = r.stickers; const sg = main.querySelector('[data-stkgrid]'); if (sg) paintStickers(sg); toast(L('الستيكر انضاف.', 'Sticker added.'), 'success'); } catch (e) { say(e); } }
    else if (inp.matches('[data-storypick]')) storyDraft(file);
    else if (inp.matches('[data-new-logo-pick]')) { try { st.newLogo = await shrinkImage(file, 256, 0.88, true); keepNewName(); paintNew(); restoreNewName(); } catch (e) { say(e); } }
    else if (inp.matches('[data-logo-pick]')) { try { const logo = await shrinkImage(file, 256, 0.88, true); const r = await apiRequest('PATCH', `/api/chat/${st.open}`, { logo }, 30000); st.ch = { ...st.ch, ...r.channel }; st.info = true; paintMain(); loadList(); toast(L('الشعار تغيّر.', 'Logo changed.'), 'success'); } catch (e) { say(e); } }
    inp.value = '';
  });
  el.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape') { if (!lb.hidden) { lb.hidden = true; return; } if (document.querySelector('.chp-mm-bg')) { closeMsgMenu(); return; } if (st.sel) { st.sel = null; paintSel(); return; } if (el.querySelector('.chp-sheet-bg')) { closeSheet(); return; } hideMention(); closeMenu(); }
    const ta = ev.target.closest?.('[data-text]'); if (!ta) return;
    // Enter sends on a keyboard (Shift+Enter = new line); a phone keyboard keeps Enter for new lines. IME composition is respected.
    if (ev.key !== 'Enter' || ev.shiftKey || ev.ctrlKey || ev.metaKey || ev.altKey || !window.matchMedia('(pointer: fine)').matches) return;
    ev.preventDefault(); if (ev.isComposing || ev.keyCode === 229 || ev.repeat) return; send(ta.form);
  });
  el.addEventListener('input', (ev) => { if (ev.target.matches?.('[data-text]')) { grow(ev.target); if (ev.target.value.trim() && !st.edit) typed(); mentionCheck(ev.target); if (!st.edit && st.open) saveDraft(st.open, ev.target.value); ev.target.form?.classList.toggle('is-empty', !ev.target.value.trim() && !st.pending); } if (ev.target.matches?.('[data-q]')) { st.q = ev.target.value; paintList(); globalSearch(); } });
  el.addEventListener('scroll', (ev) => { if (ev.target.matches?.('[data-msgs]')) paintFab(); }, true);
  el.addEventListener('paste', (ev) => { if (!ev.target.closest?.('[data-compose]')) return; const f = [...(ev.clipboardData?.files || [])].find((x) => /^(image|video)\//.test(x.type)); if (f) { ev.preventDefault(); setPending(f, /^video\//.test(f.type) ? 'video' : 'image'); } });
  lb.addEventListener('click', (ev) => { if (ev.target === lb) lb.hidden = true; });

  // a notification link (#/app/chat?c=<id>&call=1) opens that channel, and joins its call when asked
  const fromHash = () => { const q = new URLSearchParams((location.hash.split('?')[1] || '')); const j = q.get('join'); if (j && /^[A-Za-z0-9_-]{10,24}$/.test(j)) return { join: j }; if (q.get('share') === '1') return { share: true }; const c = q.get('c'); if (!c || !/^c[0-9a-f]{12}$/.test(c)) return null; return { c, call: q.get('call') === '1' }; };
  async function followHash() { const t = fromHash(); if (!t) return; if (t.share) { try { history.replaceState(null, '', '#/app/chat'); } catch { /* ignore */ } return openShare(); } if (t.join) { try { history.replaceState(null, '', '#/app/chat'); } catch { /* ignore */ } return openJoin(t.join); } if (st.open !== t.c) await openChannel(t.c); if (t.call && st.ch?.call && !st.callView?.joined) main.querySelector('[data-act=joincall]')?.focus(); try { history.replaceState(null, '', '#/app/chat'); } catch { /* ignore */ } }
  const onHash = () => { if (location.hash.startsWith('#/app/chat')) followHash(); };
  window.addEventListener('hashchange', onHash);

  const listTimer = setInterval(() => { if (st.alive && document.visibilityState === 'visible') { loadList(); loadStories(); } }, LIST_POLL);
  onUnmount(el, () => { closeStory(); closeMsgMenu(); document.removeEventListener('visibilitychange', onVis); document.removeEventListener('keydown', onKeys); for (const p2 of stkUrls.values()) p2.then((u) => u && URL.revokeObjectURL(u)); document.documentElement.classList.remove('route-chat'); window.removeEventListener('resize', fit); window.visualViewport?.removeEventListener('resize', fit); st.alive = false; pollGen++; clearInterval(listTimer); window.removeEventListener('hashchange', onHash); if (st.call) leaveCall(false); clearPending(); for (const u of blobs.values()) if (typeof u === 'string') URL.revokeObjectURL(u); });
  // the chat fills exactly what is left of the screen (and shrinks above the phone keyboard)
  const shell = el.querySelector('.chp-shell');
  const fit = () => { if (!el.isConnected) return; const vh = window.visualViewport?.height || window.innerHeight; const top = shell.getBoundingClientRect().top; el.style.setProperty('--chp-h', `${Math.max(420, Math.round(vh - Math.max(0, top) - (window.innerWidth <= 760 ? 0 : 24)))}px`); };
  window.addEventListener('resize', fit); window.visualViewport?.addEventListener('resize', fit); requestAnimationFrame(() => requestAnimationFrame(fit)); setTimeout(fit, 400);
  // things above the chat (price tickers, banners) can appear after it; keep the chat's height matching what is left
  let lastTop = -1; const fitTimer = setInterval(() => { if (!el.isConnected) { clearInterval(fitTimer); return; } const tp = Math.round(shell.getBoundingClientRect().top); if (tp !== lastTop) { lastTop = tp; fit(); } }, 700);
  document.documentElement.classList.add('route-chat');   // phones: the chat takes the whole screen under the top bar
  applyWall(); paintSide(); paintMain(); loadList().then(followHash); loadStories(); loadFolders(); apiRequest('POST', '/api/chat/me/devices', { id: deviceId(), ua: navigator.userAgent }, 15000).catch(() => {}); apiRequest('GET', '/api/chat/me/profile', undefined, 15000).then((r) => { st.me = r; if (r.av) { st.myAv = r.av; paintSide(); } }).catch(() => {});
  return el;
}
