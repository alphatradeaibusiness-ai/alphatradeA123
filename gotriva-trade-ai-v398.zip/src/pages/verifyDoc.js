// v385 Public page: check that a GOTRIVA invoice / receipt is real, by its verification code. Shows only number, amount, date.
import { tx } from '../i18n/tx.js';
import { esc } from '../utils/dom.js';
import { AI_BASE } from '../services/ai/gateway.js';

const L = (ar, en) => tx({ ar, en });
export function renderVerify() {
  const el = document.createElement('main'); el.className = 'vd'; el.dir = document.documentElement.lang === 'en' ? 'ltr' : 'rtl';
  el.innerHTML = `<form class="card cs-card bl" novalidate><div class="cs"><h2 class="cs-title">${esc(L('تحقّق من فاتورة أو إيصال', 'Verify an invoice or receipt'))}</h2>
    <p class="cs-sub">${esc(L('اكتب رمز التحقق المطبوع على المستند.', 'Enter the verification code printed on the document.'))}</p>
    <label class="bl-f"><span class="bl-in"><input name="c" dir="ltr" placeholder="XXXX-XXXX-XXXX" maxlength="20" autocomplete="off" autocapitalize="characters" required></span></label>
    <button class="cs-go" type="submit">${esc(L('تحقّق', 'Verify'))}</button><div class="vd-out" aria-live="polite"></div>
    <p class="cs-note"><a href="#/login">GOTRIVA TRADE AI</a></p></div></form>`;
  const f = el.querySelector('form'); const out = el.querySelector('.vd-out');
  f.addEventListener('submit', async (e) => {
    e.preventDefault(); out.textContent = '…';
    try {
      const r = await (await fetch(`${AI_BASE.replace(/\/api\/ai$/, '/api/bank')}/verify/${encodeURIComponent(f.c.value.trim())}`)).json();
      out.innerHTML = r.valid ? `<p class="vd-ok">✓ ${esc(L('مستند أصلي', 'Genuine document'))}<br><b dir="ltr">${esc(r.number)}</b> · <bdi dir="ltr">${esc((r.amount / 100).toFixed(2))} ${esc(r.currency)}</bdi> · ${esc(new Date(r.at).toLocaleDateString('en-GB'))}</p>` : `<p class="vd-no">✗ ${esc(L('ما لقينا مستند بهالرمز.', 'No document with this code.'))}</p>`;
    } catch { out.textContent = L('ما قدرنا نتحقق هلّق. جرّب كمان شوي.', 'Could not check right now. Try again shortly.'); }
  });
  return el;
}
