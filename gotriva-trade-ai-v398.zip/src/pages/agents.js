// v351 Gotriva Agents: every signal channel on one page (Elite, Swing Pulse Pro, Nova Pulse, the recommendation channel).
// Hub = one card per agent (live state, all-time and 30-day pips, alerts on/off). Agent page = record, open trade,
// performance chart with range / result / symbol filters, latest closed trades. All numbers come from /api/agents
// (the server's ledger of really-closed trades); nothing here is estimated or invented.
import { h, esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { apiRequest } from '../services/ai/gateway.js';
import { whileMounted } from './tools/common.js';
import '../styles/agents.css';
import { mountAgentPlus, hubExtrasHtml, bindHubExtras, detailExtrasHtml, bindDetailExtras, shareTrade, favs, toggleFav } from './agentsPlus.js';

const POLL_MS = 20_000;
export const AGENT_INFO = {
  elite: { name: ['وكيل النخبة', 'Elite Agent'], desc: ['إشارات النخبة: ذهب، مؤشرات وفوركس بأقوى الإعدادات.', 'Gotriva Elite Signals: gold, indices and forex, strongest setups only.'], route: '#/app/elite', orb: 'gold', channel: ['إشارات النخبة', 'Gotriva Elite Signals'] },
  swing: { name: ['وكيل سوينغ بالس', 'Swing Pulse Agent'], desc: ['صفقات سوينغ من قناة سوينغ بالس برو.', 'Swing trades from the Swing Pulse Pro channel.'], route: '#/app/swing', orb: 'violet', channel: ['سوينغ بالس برو', 'Swing Pulse Pro'] },
  nova: { name: ['وكيل نوفا بالس', 'Nova Pulse Agent'], desc: ['صفقات سريعة على فريم الدقيقة من قناة نوفا بالس.', 'Fast 1-minute trades from the Nova Pulse channel.'], route: '#/app/nova', orb: 'blue', channel: ['نوفا بالس', 'Nova Pulse'] },
  signals: { name: ['وكيل التوصيات', 'Signals Agent'], desc: ['توصيات قناة التوصيات على مدار الساعة.', 'Trade signals from the recommendation channel, around the clock.'], route: '#/app/signals', orb: 'green', channel: ['قناة التوصيات', 'the signals channel'] },
};
const IDS = Object.keys(AGENT_INFO);

export function renderAgents() {
  const AR = getLang() === 'ar'; const L = (ar, en) => (AR ? ar : en); const N = (id) => AGENT_INFO[id].name[AR ? 0 : 1];
  const nf = new Intl.NumberFormat('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  const pips = (v) => (v == null ? '—' : `${v > 0 ? '+' : v < 0 ? '−' : ''}${nf.format(Math.abs(v))}`);
  const tone = (v) => (v > 0 ? 'is-up' : v < 0 ? 'is-down' : '');
  const when = (ms) => (ms ? new Intl.DateTimeFormat(AR ? 'ar' : 'en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', numberingSystem: 'latn' }).format(ms) : '');
  const since = (ms) => (ms ? new Intl.DateTimeFormat(AR ? 'ar' : 'en-US', { year: 'numeric', month: 'short', day: 'numeric', numberingSystem: 'latn' }).format(ms) : '');
  const OUT = { tp: [L('وصل الهدف', 'Closed win'), 'is-up'], sl: [L('ضرب الستوب', 'Stopped out'), 'is-down'], be: [L('سكّر على الدخول', 'Closed at entry'), ''], time: [L('سكّر بالوقت', 'Closed on time'), ''] };
  const SESSION = { TOKYO: L('طوكيو', 'TOKYO'), LONDON: L('لندن', 'LONDON'), NY: L('نيويورك', 'NY'), SYDNEY: L('سيدني', 'SYDNEY') };
  const chev = `<svg class="ag-chev" viewBox="0 0 24 24" aria-hidden="true"><path d="${AR ? 'M15 6l-6 6 6 6' : 'M9 6l6 6-6 6'}"/></svg>`;
  const arrow = (long) => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${long ? 'M7 17L17 7M9 7h8v8' : 'M7 7l10 10M17 9v8H9'}"/></svg>`;

  const el = h('<section class="subpage agents page-enter"><div data-view></div></section>');
  const view = el.querySelector('[data-view]');
  const st = { open: null, range: '30', side: 'all', sym: 'all', hub: null, detail: null, alerts: {}, err: null, wi: { start: 1000, risk: 1 } };
  let gen = 0;

  const toggle = (id) => `<button type="button" class="ag-switch" role="switch" aria-checked="${!st.alerts[id]}" aria-label="${esc(L(`تنبيهات ${N(id)}`, `${N(id)} alerts`))}" data-alert="${id}"><span></span></button>`;
  const errBox = () => (st.err === 'email_unverified' ? `<p class="ag-err" role="alert">${esc(L('أكّد إيميلك أول عشان تشوف الوكلاء. بعتنالك رمز على إيميلك.', 'Confirm your e-mail first to see the agents. We sent a code to your e-mail.'))} <button type="button" class="ag-verify" data-verify>${esc(L('أدخل الرمز', 'Enter the code'))}</button></p>` : '') || ((st.err ? `<p class="ag-err" role="alert">${esc(st.err === 'email_unverified' ? L('أكّد إيميلك أول عشان تشوف الوكلاء. بعتنالك رمز على إيميلك.', 'Confirm your e-mail first to see the agents. We sent a code to your e-mail.') : L('ما قدرنا نجيب الأرقام هلأ. بنجرّب كمان شوي.', 'Could not load the numbers right now. Retrying shortly.'))}</p>` : ''));

  function paintHub() {
    const d = st.hub;
    view.innerHTML = `<header class="ag-head"><h1>Gotriva Agents</h1>
        <p>${esc(L('كل وكيل بيراقب أسواقه لحاله، وبينزّل الصفقة هون أول ما تطلع.', 'Each agent watches its own markets and posts signals here the moment they happen.'))}</p></header>
      ${errBox()}${hubExtrasHtml(d, { N })}
      <div class="ag-grid">${[...IDS].sort((x, y) => Number(favs().includes(y)) - Number(favs().includes(x))).map((id) => { const a = d?.agents?.find((x) => x.id === id) || {}; const loading = !d; const fav = favs().includes(id);
        return `<article class="ag-card${fav ? ' is-fav' : ''}"><button type="button" class="ag-fav" data-fav="${id}" aria-pressed="${fav}" aria-label="${esc(fav ? L(`شيل ${N(id)} من المفضّلة`, `Remove ${N(id)} from favourites`) : L(`حط ${N(id)} بالمفضّلة`, `Add ${N(id)} to favourites`))}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/></svg></button>
          <button type="button" class="ag-card-top" data-open="${id}">
            <span class="ag-orb ag-orb-${AGENT_INFO[id].orb}" aria-hidden="true"></span>
            <span class="ag-card-txt"><b>${esc(N(id))}</b><small>${esc(AGENT_INFO[id].desc[AR ? 0 : 1])}</small>
              ${loading ? '<em class="ag-state">…</em>' : !a.running ? `<em class="ag-state">${esc(L('القناة مش شغّالة على هالسيرفر', 'Channel not running on this server'))}</em>` : a.live ? `<em class="ag-state is-live"><i></i>${esc(L('في إشارة شغّالة هلأ', 'Signal live now'))}</em>` : `<em class="ag-state">${esc(L('بيستنى الإشارة الجاية', 'Waiting for the next signal'))}</em>`}</span>
            ${chev}</button>
          <div class="ag-nums">
            <div><span>${esc(L('من البداية', 'All time'))}</span><strong class="${tone(a.allPips)}" dir="ltr">${loading ? '…' : pips(a.allPips)}<small>pips</small></strong></div>
            <div><span>${esc(L('آخر 30 يوم', 'Last 30 days'))}</span><strong class="${tone(a.m30Pips)}" dir="ltr">${loading ? '…' : pips(a.m30Pips)}<small>pips</small></strong></div>
          </div>
          <div class="ag-alerts"><span>${esc(st.alerts[id] ? L('التنبيهات مطفية', 'Alerts off') : L('التنبيهات شغّالة', 'Alerts on'))}</span>${toggle(id)}</div>
        </article>`; }).join('')}</div>
      <p class="ag-foot">${esc(L('البيبس من الصفقات اللي انفتحت وتسكّرت فعلًا: الهدف، الستوب، أو الإغلاق بالوقت. الليمت اللي ما تفعّل ما بينحسب. نتائج الماضي ما بتضمن المستقبل.', 'Pips come from trades that really opened and closed: target, stop or time exit. A limit that never filled does not count. Past results do not guarantee the future.'))}</p>`;
  }

  function chart(eq) {
    if (!eq || eq.length < 2) return `<div class="ag-chart-empty">${esc(L('ما في صفقات مسكّرة بهالفترة لسا.', 'No closed trades in this period yet.'))}</div>`;
    const W = 600, Hh = 200, P = 8; const ys = [0, ...eq.map((p) => p[1])]; const lo = Math.min(...ys), hi = Math.max(...ys); const span = hi - lo || 1;
    const x = (i) => P + (i * (W - 2 * P)) / (eq.length - 1); const y = (v) => Hh - P - ((v - lo) * (Hh - 2 * P)) / span;
    const line = eq.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(p[1]).toFixed(1)}`).join(' ');
    const last = eq.at(-1);
    return `<svg class="ag-chart" viewBox="0 0 ${W} ${Hh}" preserveAspectRatio="none" role="img" aria-label="${esc(L('تراكم البيبس مع الوقت', 'Cumulative pips over time'))}">
      <defs><linearGradient id="agFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f5a524" stop-opacity=".35"/><stop offset="1" stop-color="#f5a524" stop-opacity="0"/></linearGradient></defs>
      <line x1="0" x2="${W}" y1="${y(0).toFixed(1)}" y2="${y(0).toFixed(1)}" class="ag-zero"/>
      <path d="${line} L${x(eq.length - 1).toFixed(1)} ${Hh} L${x(0).toFixed(1)} ${Hh} Z" fill="url(#agFill)"/>
      <path d="${line}" class="ag-line"/><circle cx="${x(eq.length - 1).toFixed(1)}" cy="${y(last[1]).toFixed(1)}" r="5" class="ag-dot"/></svg>`;
  }

  function paintDetail() {
    const id = st.open; const d = st.detail; const o = d?.overall || {}; const p = d?.period || {};
    const stat = (k, v, c = '') => `<div><span>${esc(k)}</span><b class="${c}" dir="ltr">${d ? esc(v) : '…'}</b></div>`;
    const pill = (group, val, label) => `<button type="button" class="ag-pill-btn${st[group] === val ? ' is-on' : ''}" aria-pressed="${st[group] === val}" data-${group}="${esc(val)}">${esc(label)}</button>`;
    const RANGE_TXT = { today: L('اليوم', 'Today'), '7': L('آخر 7 أيام', 'Last 7 days'), '30': L('آخر 30 يوم', 'Last 30 days'), '90': L('آخر 90 يوم', 'Last 90 days'), all: L('من البداية', 'All time') };
    view.innerHTML = `<header class="ag-dhead">
        <button type="button" class="ag-back" data-back aria-label="${esc(L('رجوع لكل الوكلاء', 'Back to all agents'))}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="${AR ? 'M9 6l6 6-6 6' : 'M15 6l-6 6 6 6'}"/></svg></button>
        <span class="ag-orb ag-orb-lg ag-orb-${AGENT_INFO[id].orb}" aria-hidden="true"></span>
        <div><h1>${esc(N(id))}</h1><p>${esc(AGENT_INFO[id].desc[AR ? 0 : 1])}</p></div>
        <div class="ag-dhead-alerts">${toggle(id)}</div></header>
      ${errBox()}
      <div class="ag-strip">${stat(L('نسبة الربح', 'Win rate'), o.winRate == null ? '—' : `${o.winRate}%`)}${stat(L('الإشارات', 'Signals'), String(o.signals ?? 0))}${stat(L('ربح / خسارة', 'Wins / losses'), `${o.wins ?? 0} / ${o.losses ?? 0}`)}${stat(L('مجموع البيبس', 'Total pips'), pips(o.totalPips), tone(o.totalPips))}${stat(L('معدّل البيبس', 'Average pips'), pips(o.avgPips), tone(o.avgPips))}${stat(L('أطول سلسلة ربح', 'Best streak'), String(o.bestStreak ?? 0))}</div>
      ${d?.since ? `<p class="ag-muted ag-since">${esc(L(`الأرقام من ${since(d.since)}، أول ما بلّش السجل.`, `Numbers since ${since(d.since)}, when the record started.`))}</p>` : ''}
      <a class="ag-go" href="${AGENT_INFO[id].route}"><span class="ag-go-txt"><b>${esc(L(`الذهاب إلى ${AGENT_INFO[id].channel[0]}`, `Go to ${AGENT_INFO[id].channel[1]}`))}</b>
          <small>${esc(d?.live?.length ? L('في إشارة شغّالة هلأ، الصفقات وتفاصيلها هناك.', 'A signal is live now. The trades and their details are there.') : L('الصفقات وتفاصيلها كلها بصفحة القناة.', 'All trades and their details are on the channel page.'))}</small></span>
        ${d?.live?.length ? '<i class="ag-go-live" aria-hidden="true"></i>' : ''}<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${AR ? 'M15 6l-6 6 6 6' : 'M9 6l6 6-6 6'}"/></svg></a>
      <div class="agp" data-agplus></div>
      <div class="ag-cols">
        <section class="ag-panel ag-perf"><div class="ag-perf-top"><h2 class="ag-h2">${esc(L('الأداء', 'Performance'))}</h2>
            <div class="ag-seg" role="group" aria-label="${esc(L('المدة', 'Range'))}">${pill('range', 'today', L('اليوم', 'Today'))}${pill('range', '7', '7D')}${pill('range', '30', '30D')}${pill('range', '90', '90D')}${pill('range', 'all', L('الكل', 'All'))}</div></div>
          <div class="ag-filters"><div class="ag-seg">${pill('side', 'all', L('الكل', 'All'))}${pill('side', 'wins', L('الرابحة', 'Wins'))}${pill('side', 'losses', L('الخاسرة', 'Losses'))}</div>
            <div class="ag-seg">${pill('sym', 'all', L('كل الأسواق', 'All symbols'))}${(d?.symbols || []).slice(0, 8).map((s) => pill('sym', s, s)).join('')}</div></div>
          <div class="ag-big ${tone(p.totalPips)}" dir="ltr">${d ? pips(p.totalPips) : '…'}<small>pips</small></div>
          <p class="ag-muted">${esc(RANGE_TXT[st.range])}${L('، ', ', ')}${esc(L(`${p.signals ?? 0} إشارة`, `${p.signals ?? 0} signals`))}</p>
          ${d ? chart(p.equity) : '<div class="ag-chart-empty">…</div>'}</section>
        <section class="ag-panel ag-recent"><h2 class="ag-h2">${esc(L('آخر الإشارات', 'Recent signals'))}</h2>
          ${d?.recent?.length ? `<ul>${d.recent.map((r) => { const long = r.dir === 'long'; const out = OUT[r.out] || ['', ''];
            return `<li><span class="ag-dir ${long ? 'is-up' : 'is-down'}">${arrow(long)}</span>
              <span class="ag-rec-txt"><b><span dir="ltr">${esc(r.sym)}</span> ${esc(long ? L('شراء', 'Buy') : L('بيع', 'Sell'))}</b><small>${esc(when(r.closedAt))}${L('، ', ', ')}${esc(SESSION[r.session] || '')}</small></span>
              <span class="ag-rec-res"><b class="${tone(r.pips)}" dir="ltr">${pips(r.pips)}</b><em class="ag-pill ${out[1]}">${esc(out[0])}</em></span><button type="button" class="ag-share" data-share="${esc(r.id)}" aria-label="${esc(L('شارك صورة الصفقة', 'Share the trade picture'))}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12M7 8l5-5 5 5M5 14v5h14v-5"/></svg></button></li>`; }).join('')}</ul>`
            : `<p class="ag-muted">${esc(d ? L('لسا ما في إشارات مسكّرة لهالوكيل.', 'No closed signals for this agent yet.') : '…')}</p>`}</section>
      </div>
      <div data-agx></div>
      <p class="ag-foot">${esc(L('كل رقم من صفقات القناة المسكّرة فعلًا. بعد الهدف الأول الستوب بيصير على الدخول، وكل هدف بيسكّر تلت الصفقة. الرسوم والانزلاق مش محسوبين. نتائج الماضي ما بتضمن المستقبل.', 'Every number comes from the channel\'s really-closed trades. After TP1 the stop moves to entry and each target closes a third. Fees and slippage are not included. Past results do not guarantee the future.'))}</p>`;
  }

  const paint = () => {
    if (st.open) { paintDetail(); if (st.detail) { mountAgentPlus(view.querySelector('[data-agplus]'), { ...st.detail, id: st.open }, st.wi); const x = view.querySelector('[data-agx]'); if (x) { x.innerHTML = detailExtrasHtml(st.detail, st.open); bindDetailExtras(x, st.detail, st.open); } } }
    else { paintHub(); if (st.hub) bindHubExtras(view, st.hub, load); }
  };
  async function load() {
    const mine = ++gen;
    try {
      const d = st.open ? await apiRequest('GET', `/api/agents/${st.open}?range=${st.range}&side=${st.side}&sym=${encodeURIComponent(st.sym)}`, undefined, 15000) : await apiRequest('GET', '/api/agents', undefined, 15000);
      if (mine !== gen) return;
      st.err = null; st.alerts = d.alerts || st.alerts; if (st.open) st.detail = d; else st.hub = d;
    } catch (e) { if (mine !== gen) return; st.err = e?.code || 'error'; }
    paint();
  }

  view.addEventListener('click', async (ev) => {
    const b = ev.target.closest('button'); if (!b) return;
    if (b.dataset.open) { st.open = b.dataset.open; st.detail = null; st.range = '30'; st.side = 'all'; st.sym = 'all'; paint(); window.scrollTo({ top: 0 }); load(); return; }
    if (b.hasAttribute('data-verify')) { window.dispatchEvent(new CustomEvent('gt:verify-needed')); return; }
    if (b.dataset.fav) { toggleFav(b.dataset.fav); paint(); return; }   // v391 favourites first
    if (b.dataset.share) { const r = st.detail?.recent?.find((x) => x.id === b.dataset.share); if (r) { b.disabled = true; try { await shareTrade(r, N(st.open)); } finally { b.disabled = false; } } return; }
    if (b.hasAttribute('data-back')) { st.open = null; st.detail = null; paint(); window.scrollTo({ top: 0 }); load(); return; }
    for (const g of ['range', 'side', 'sym']) if (b.dataset[g] != null) { st[g] = b.dataset[g]; paint(); load(); return; }
    if (b.dataset.alert) {
      const id = b.dataset.alert; const on = Boolean(st.alerts[id]);   // muted now → turning on
      st.alerts = { ...st.alerts, [id]: !on }; paint();
      try { const r = await apiRequest('PUT', '/api/agents/alerts', { id, on }, 10000); st.alerts = r.alerts || st.alerts; }
      catch { st.alerts = { ...st.alerts, [id]: on }; }
      paint();
    }
  });

  try { const back = sessionStorage.getItem('ata:agent-open'); sessionStorage.removeItem('ata:agent-open'); if (AGENT_INFO[back]) st.open = back; } catch { /* ignore */ }
  paint(); load();
  whileMounted(el, load, POLL_MS);
  return el;
}
