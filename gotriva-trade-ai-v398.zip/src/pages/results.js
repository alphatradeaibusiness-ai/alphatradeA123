// v367 public results page (#/results and #/app/results): every closed trade of the four Gotriva Agents channels, straight
// from the server's ledger. No sign-in needed. Closed trades only: no open trades, no entry/stop levels, nothing that could
// be traded on. The numbers are pips as recorded when each trade closed; past results do not promise future ones.
import { esc } from '../utils/dom.js';
import { getLang, getLocale } from '../i18n/index.js';
import { icons } from '../components/icons.js';
import '../styles/results.css';

const L = (ar, en) => (getLang() === 'ar' ? ar : en);
const NAMES = {
  elite: ['وكيل النخبة', 'Elite Agent'], swing: ['وكيل سوينغ بالس', 'Swing Pulse Agent'],
  nova: ['وكيل نوفا بالس', 'Nova Pulse Agent'], signals: ['وكيل التوصيات', 'Signals Agent'],
};
const OUT = { tp: ['هدف', 'Target'], sl: ['وقف', 'Stop'], be: ['تعادل/جزئي', 'Partial/BE'], time: ['انتهى الوقت', 'Timed out'] };
const iso = (v) => `⁦${v}⁩`;   // keeps the minus sign in place inside Arabic text
const pipsTxt = (p) => (p == null ? '—' : iso(`${p > 0 ? '+' : ''}${p}`));
const dateTxt = (ms) => { try { return new Date(ms).toLocaleDateString(getLocale(), { day: 'numeric', month: 'short', year: 'numeric' }); } catch { return ''; } };

function spark(eq) {
  if (!eq || eq.length < 2) return '';
  const W = 300, H = 64, ys = eq.map((p) => p[1]); const lo = Math.min(0, ...ys), hi = Math.max(0, ...ys); const span = hi - lo || 1;
  const x = (i) => (i / (eq.length - 1)) * W; const y = (v) => H - 4 - ((v - lo) / span) * (H - 8);
  const d = eq.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p[1]).toFixed(1)}`).join('');
  const up = ys.at(-1) >= 0;
  return `<svg class="rs-spark ${up ? 'is-up' : 'is-down'}" dir="ltr" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="${esc(L('مجموع النقاط مع الوقت', 'Running total of pips'))}">
    <line x1="0" x2="${W}" y1="${y(0).toFixed(1)}" y2="${y(0).toFixed(1)}" class="rs-zero"/><path d="${d}"/></svg>`;
}

function card(a) {
  const o = a.overall || {}; const m = a.m30 || {}; const nm = NAMES[a.id] || [a.id, a.id];
  const stat = (v, label) => `<div><b>${v}</b><span>${esc(label)}</span></div>`;
  return `<article class="card rs-card">
    <header class="rs-head"><h2>${esc(L(...nm))}</h2>${a.since ? `<small>${esc(L('من', 'since'))} ${esc(dateTxt(a.since))}</small>` : ''}</header>
    ${o.signals ? `<div class="rs-stats">
      ${stat(esc(String(o.signals)), L('صفقة مسكّرة', 'closed trades'))}
      ${stat(o.winRate == null ? '—' : `${esc(String(o.winRate))}%`, L('نسبة الربح', 'win rate'))}
      ${stat(pipsTxt(o.totalPips), L('مجموع النقاط', 'total pips'))}
      ${stat(pipsTxt(m.totalPips), L('آخر 30 يوم', 'last 30 days'))}
    </div>
    ${spark(a.equity)}
    <ul class="rs-last" aria-label="${esc(L('آخر الصفقات المسكّرة', 'Latest closed trades'))}">${(a.last || []).map((r) => `<li title="${esc(dateTxt(r.closedAt))}"><span class="rs-sym" dir="ltr">${esc(r.sym || '')}</span><span class="rs-dir">${esc(r.dir === 'long' ? L('شراء', 'Buy') : L('بيع', 'Sell'))}</span>
      <span class="rs-out">${esc(L(...(OUT[r.out] || [r.out || '', r.out || ''])))}</span><span class="rs-pips ${r.pips > 0 ? 'is-up' : r.pips < 0 ? 'is-down' : ''}">${pipsTxt(r.pips)}</span></li>`).join('')}</ul>`
    : `<p class="muted rs-empty">${esc(L('لسا ما في صفقات مسكّرة بهالقناة. أول ما تسكّر صفقة بتظهر هون.', 'No closed trades on this channel yet. They show here as soon as one closes.'))}</p>`}
  </article>`;
}

export function renderResults({ standalone = false } = {}) {
  const el = document.createElement('section');
  el.className = `page rs-page${standalone ? ' rs-standalone' : ''}`;
  el.innerHTML = `<header class="rs-top">
      ${standalone ? `<a class="btn btn-ghost btn-sm" href="#/login">${esc(L('تسجيل الدخول', 'Sign in'))}</a>` : ''}
      <h1>${icons.bars || ''}<span>${esc(L('نتائج الإشارات', 'Signal results'))}</span></h1>
      <p class="rs-lead">${esc(L('كل صفقة مسكّرة من قنوات Gotriva Agents، بالنقاط، مثل ما انسجّلت لحظة الإغلاق. ما بنحذف الخسارات وما بنعرض صفقات مفتوحة.', 'Every closed trade from the Gotriva Agents channels, in pips, as recorded when it closed. Losses are never removed and open trades are not shown.'))}</p>
    </header>
    <div class="rs-grid" aria-live="polite"><p class="muted">${esc(L('عم نجيب الأرقام…', 'Loading the numbers…'))}</p></div>
    <p class="rs-note">${esc(L('الأداء الماضي ما بيضمن نتائج قادمة. الأرقام بالنقاط بدون عمولات وسبريد. مش نصيحة مالية.', 'Past performance does not guarantee future results. Pips before fees and spread. Not financial advice.'))}
      <a href="${standalone ? '#/legal/risk' : '#/app/legal/risk'}">${esc(L('تحذير المخاطر', 'Risk warning'))}</a></p>`;
  const grid = el.querySelector('.rs-grid');
  const load = async () => {
    try {
      const r = await fetch('/api/public/results', { headers: { Accept: 'application/json' } });
      if (!r.ok) throw new Error(String(r.status));
      const d = await r.json();
      grid.innerHTML = (d.agents || []).map(card).join('') || `<p class="muted">${esc(L('ما في بيانات لسا.', 'No data yet.'))}</p>`;
      const upd = document.createElement('p'); upd.className = 'rs-upd muted';
      upd.textContent = `${L('آخر تحديث', 'Updated')}: ${new Date(d.at || Date.now()).toLocaleString(getLocale())}`; grid.after(upd);
    } catch {
      grid.innerHTML = `<p class="muted">${esc(L('ما قدرنا نجيب النتائج هلأ. جرّب كمان شوي.', 'Could not load the results right now. Try again in a moment.'))}</p>
        <button type="button" class="btn btn-ghost btn-sm" data-retry>${esc(L('جرّب مرة ثانية', 'Try again'))}</button>`;
      grid.querySelector('[data-retry]').onclick = () => { grid.innerHTML = ''; load(); };
    }
  };
  load();
  return el;
}
