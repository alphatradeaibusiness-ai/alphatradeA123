// v369 bank stats cards: the owner's StatsCard design (title, value, % change, icon in a gradient tile, lifts on hover),
// rebuilt without React so it fits the site's vanilla-JS pages. Real numbers only, from GET /api/bank/dashboard:
// net worth, money in and money out this calendar month, each compared with last month. No data → no card.
import { icons } from '../../../components/icons.js';
import { esc } from './ui.js';
import { getLang } from '../../../i18n/index.js';

const L = (ar, en) => (getLang() === 'ar' ? ar : en);
const usd = (v) => `$${Number(v).toLocaleString('en-US', { maximumFractionDigits: 2, minimumFractionDigits: 2 })}`;
const ARROW_UP = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17 17 7M8 7h9v9"/></svg>';
const ARROW_DOWN = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 7l10 10M17 8v9H8"/></svg>';

/** % change from `prev` to `cur`; null when there is nothing honest to compare with. */
export function pctChange(cur, prev) {
  if (!(prev > 0) || cur == null) return null;
  return Math.round(((cur - prev) / prev) * 1000) / 10;
}

function statCard({ title, value, change, icon, tone, goodWhenUp = true }) {
  const dir = change == null ? '' : change > 0 ? 'up' : change < 0 ? 'down' : 'flat';
  const good = change == null || change === 0 ? '' : (change > 0) === goodWhenUp ? 'is-good' : 'is-bad';
  const ch = change == null ? `<p class="bst-change">${esc(L('ما في شهر سابق للمقارنة', 'No previous month to compare'))}</p>`
    : `<p class="bst-change ${good}">${dir === 'down' ? ARROW_DOWN : ARROW_UP}<span dir="ltr">${change > 0 ? '+' : ''}${change}%</span><small>${esc(L('عن الشهر الماضي', 'vs last month'))}</small></p>`;
  return `<article class="bst-card"><div class="bst-row"><div class="bst-text">
      <p class="bst-title">${esc(title)}</p><h3 class="bst-value mono" dir="ltr">${esc(value)}</h3>${ch}</div>
      <span class="bst-icon bst-${tone}" aria-hidden="true">${icon || ''}</span></div></article>`;
}

/** The row of cards, or '' when the dashboard has no usable numbers. */
export function statsRow(dash) {
  if (!dash || !Array.isArray(dash.cashflow) || !dash.cashflow.length || dash.netWorthUsd == null) return '';   // no exchange rates → no honest dollar figures, so no cards
  const cur = dash.cashflow.at(-1); const prev = dash.cashflow.at(-2) || null;
  const cards = [];
  if (dash.netWorthUsd != null) cards.push(statCard({ title: L('صافي الثروة', 'Net worth'), value: usd(dash.netWorthUsd), change: null, icon: icons.wallet, tone: 'violet' }).replace(/<p class="bst-change">[^<]*<\/p>/, `<p class="bst-change">${esc(dash.complete ? L('كل محافظك بالدولار', 'All your wallets in USD') : L('جزئي: في أسعار ناقصة', 'Partial: some prices missing'))}</p>`));
  cards.push(statCard({ title: L('دخل هالشهر', 'Money in this month'), value: usd(cur.inUsd), change: pctChange(cur.inUsd, prev?.inUsd), icon: icons.piggy, tone: 'emerald', goodWhenUp: true }));
  cards.push(statCard({ title: L('مصاريف هالشهر', 'Spent this month'), value: usd(cur.outUsd), change: pctChange(cur.outUsd, prev?.outUsd), icon: icons.card, tone: 'sky', goodWhenUp: false }));
  return `<section class="bst-grid" aria-label="${esc(L('ملخص الشهر', 'This month at a glance'))}">${cards.join('')}</section>`;
}
