// v382 The bank's own sign-in screen: username + the temporary password from the approval e-mail, then the person's own
// password (strength checklist, confirm). Owners and accounts approved before v382 never see it (the server says so).
import { bankApi, bankSession } from '../../../services/bank/api.js';
import { tx } from '../../../i18n/tx.js';
import { icons } from '../../../components/icons.js';
import { esc } from './ui.js';
import { signFor, passkeysSupported } from '../../../services/bank/passkey.js';

const L = (ar, en) => tx({ ar, en });
const LOCK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>';
const EYE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
const RULES = [[(s) => s.length >= 10, ['10 أحرف أو أكثر', '10 characters or more']], [(s) => /[a-z]/.test(s) && /[A-Z]/.test(s), ['حرف كبير وحرف صغير', 'An upper- and a lower-case letter']], [(s) => /\d/.test(s), ['رقم', 'A number']], [(s) => /[^\w\s]/.test(s), ['رمز متل ! أو # (أقوى)', 'A symbol like ! or # (stronger)']]];
const ERR = (e) => ({
  bad_login: e.left > 0 ? L(`اسم المستخدم أو كلمة السر غلط. باقي ${e.left} محاولات.`, `Wrong username or password. ${e.left} tries left.`) : L('اسم المستخدم أو كلمة السر غلط.', 'Wrong username or password.'),
  login_locked: L(`محاولات كثيرة. جرّب بعد ${Math.ceil((e.retryInS || 900) / 60)} دقيقة.`, `Too many tries. Try again in ${Math.ceil((e.retryInS || 900) / 60)} minutes.`),
  temp_expired: L('كلمة السر المؤقتة انتهت (24 ساعة). احكي معنا من الدعم وبنبعتلك وحدة جديدة.', 'The temporary password expired (24 h). Contact support for a new one.'),
  weak_password: L('كلمة السر ضعيفة. شوف الشروط تحت.', 'The password is too weak. See the rules below.'),
  bank_login_required: L('انتهت الجلسة. ادخل من جديد.', 'Session ended. Sign in again.'),
}[e?.code] || L('صار خطأ. جرّب كمان مرة.', 'Something went wrong. Try again.'));

const pwField = (name, label, auto) => `<label class="bl-f">${esc(label)}<span class="bl-in"><input name="${name}" type="password" dir="ltr" autocomplete="${auto}" required maxlength="128"><button type="button" class="bl-eye" data-eye aria-label="${esc(L('إظهار كلمة السر', 'Show password'))}">${EYE}</button></span></label>`;
function bindEyes(f) { f.querySelectorAll('[data-eye]').forEach((b) => b.addEventListener('click', () => { const i = b.previousElementSibling; i.type = i.type === 'password' ? 'text' : 'password'; })); }

/** Draws the sign-in in `body` when the bank asks for it → true (onIn runs once in); false when nothing is needed. */
export async function bankLoginGate(body, onIn) {
  let s; try { s = await bankApi.loginState(); } catch { return false; }
  if (!s?.required || s.inside) return false;
  bankSession.clear(); signIn(body, s, onIn); return true;
}

function signIn(body, s, onIn) {
  body.innerHTML = `<form class="card cs-card bl" novalidate><div class="cs"><div class="cs-badge" aria-hidden="true">${LOCK}</div>
    <h2 class="cs-title">${esc(L('ادخل على حسابك بالبنك', 'Sign in to your bank account'))}</h2>
    <p class="cs-sub">${esc(s.mustChange ? L('اسم المستخدم وكلمة السر المؤقتة وصلوك على الإيميل لما انفتح حسابك.', 'Your username and temporary password came by e-mail when your account opened.') : L('اسم المستخدم وكلمة سرك للبنك.', 'Your bank username and password.'))}</p>
    ${s.passkeys && !s.mustChange && passkeysSupported() ? `<button type="button" class="cs-go" data-bio>${esc(L('ادخل بالبصمة / Face ID', 'Sign in with fingerprint / Face ID'))}</button><p class="cs-sub bl-or">${esc(L('أو باسم المستخدم وكلمة السر', 'or with your username and password'))}</p>` : ''}
    <label class="bl-f">${esc(L('اسم المستخدم', 'Username'))}<span class="bl-in"><input name="u" dir="ltr" autocomplete="username" required maxlength="20" value="${esc(s.username || '')}" autocapitalize="characters"></span></label>
    ${pwField('p', s.mustChange ? L('كلمة السر المؤقتة', 'Temporary password') : L('كلمة السر', 'Password'), 'current-password')}
    <p class="cs-err" role="alert" hidden></p>
    <button class="cs-go" type="submit">${esc(L('دخول', 'Sign in'))}</button>
    <p class="cs-note">${icons.shield}<span>${esc(s.mustChange ? L('المؤقتة بتشتغل مرة وحدة خلال 24 ساعة. بعدها بتحط كلمة سرك.', 'The temporary one works once within 24 h; then you set your own.') : L('نسيت كلمة السر؟ احكي معنا من الدعم وبنبعتلك كلمة مؤقتة على إيميلك.', 'Forgot it? Contact support and we e-mail you a temporary one.'))}</span></p></div></form>`;
  const f = body.querySelector('form'); const err = f.querySelector('.cs-err'); bindEyes(f);
  if (!f.querySelector('[data-bio]')) setTimeout(() => f.p.focus({ preventScroll: true }), 300);
  f.querySelector('[data-bio]')?.addEventListener('click', async (e) => {   // v383 fingerprint / Face ID (a passkey) opens the bank
    const b = e.currentTarget; b.disabled = true; err.hidden = true;
    try { const r = await bankApi.loginPasskey(await signFor('bank_login', {})); bankSession.set(r.token); done(body, L('أهلا فيك', 'Welcome back'), onIn); }
    catch (x) { if (x?.code !== 'passkey_cancelled') { err.textContent = ERR(x); err.hidden = false; } b.disabled = false; }
  });
  f.addEventListener('submit', async (e) => {
    e.preventDefault(); const btn = f.querySelector('[type=submit]'); btn.disabled = true; err.hidden = true;
    try {
      const r = await bankApi.login(f.u.value.trim(), f.p.value);
      if (r.change) setOwn(body, r.change, onIn); else { bankSession.set(r.token); done(body, L('أهلا فيك', 'Welcome back'), onIn); }
    } catch (x) { err.textContent = ERR(x); err.hidden = false; btn.disabled = false; f.p.select(); }
  });
}

function setOwn(body, ticket, onIn) {
  body.innerHTML = `<form class="card cs-card bl" novalidate><div class="cs"><div class="cs-badge" aria-hidden="true">${icons.shield}</div>
    <h2 class="cs-title">${esc(L('حط كلمة سر جديدة', 'Set a new password'))}</h2>
    <p class="cs-sub">${esc(L('هاي كلمة سرك إنت للبنك. ما حدا غيرك بيعرفها، ولا إحنا.', 'This is your own bank password. Nobody else knows it, not even us.'))}</p>
    ${pwField('a', L('كلمة السر الجديدة', 'New password'), 'new-password')}
    <div class="bl-meter" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
    <ul class="bl-rules">${RULES.map(([, t]) => `<li>${esc(L(...t))}</li>`).join('')}</ul>
    ${pwField('b', L('أكّد كلمة السر', 'Confirm the password'), 'new-password')}
    <p class="cs-err" role="alert" hidden></p>
    <button class="cs-go" type="submit" disabled>${esc(L('احفظ وافتح البنك', 'Save and open the bank'))}</button>
    <p class="cs-note">${icons.mail}<span>${esc(L('بيوصلك إيميل تأكيد إنه كلمة السر تغيّرت.', 'You get an e-mail confirming the change.'))}</span></p></div></form>`;
  const f = body.querySelector('form'); const err = f.querySelector('.cs-err'); const go = f.querySelector('[type=submit]'); bindEyes(f);
  const lis = [...f.querySelectorAll('.bl-rules li')]; const bars = [...f.querySelectorAll('.bl-meter i')];
  const check = () => {
    const v = f.a.value; const ok = RULES.map(([t]) => t(v)); lis.forEach((li, i) => li.classList.toggle('ok', ok[i]));
    const n = ok.filter(Boolean).length; bars.forEach((b, i) => b.classList.toggle('g', i < n));
    go.disabled = !(ok[0] && ok[1] && ok[2] && v === f.b.value);
  };
  f.a.addEventListener('input', check); f.b.addEventListener('input', check); setTimeout(() => f.a.focus({ preventScroll: true }), 300);
  f.addEventListener('submit', async (e) => {
    e.preventDefault(); if (go.disabled) return; go.disabled = true; err.hidden = true;
    try { const r = await bankApi.setPassword(ticket, f.a.value); bankSession.set(r.token); done(body, L('تم حفظ كلمة سرك', 'Password saved'), onIn); }
    catch (x) { if (x?.code === 'bank_login_required') return signIn(body, { required: true, mustChange: true }, onIn); err.textContent = ERR(x); err.hidden = false; go.disabled = false; }
  });
}

function done(body, title, onIn) {
  body.innerHTML = `<div class="card cs-card bl"><div class="cs is-done"><div class="cs-badge">${icons.check}</div><h2 class="cs-title">${esc(title)}</h2><p class="cs-sub">${esc(L('عم نفتح البنك…', 'Opening the bank…'))}</p></div></div>`;
  setTimeout(onIn, 900);
}
