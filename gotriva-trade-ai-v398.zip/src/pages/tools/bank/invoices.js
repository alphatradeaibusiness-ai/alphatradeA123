// v385 «Invoices & receipts»: every money movement has a receipt, every fee paid to GOTRIVA an invoice. One tap opens the
// document drawn on an A4 canvas (logo, Arabic layout, verification code); the person saves it to the phone as an image
// (share sheet → Save image) or as a PDF (the same picture inside a one-page A4 PDF). What they see is exactly what they save.
import { bankApi } from '../../../services/bank/api.js';
import { tx } from '../../../i18n/tx.js';
import { icons } from '../../../components/icons.js';
import { esc, fmtMinor } from './ui.js';

const L = (ar, en) => tx({ ar, en });
const W = 794, H = 1123, S = 2;   // A4 at 96 dpi, drawn at 2x
const C = { dark: '#0B3D2E', mid: '#0F5C43', green: '#10B981', mint: '#6EE7B7', pale: '#F2F8F5', line: '#E4EEE9', ink: '#10231A', mute: '#5B7468', amber: '#B45309' };
const LOGO = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="a" x1="14" y1="52" x2="50" y2="12" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#059669"/><stop offset=".55" stop-color="#34D399"/><stop offset="1" stop-color="#D1FAE5"/></linearGradient><radialGradient id="f" cx="32" cy="24" r="40" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#0F3D2E"/><stop offset="1" stop-color="#04120C"/></radialGradient></defs><rect x="3" y="3" width="58" height="58" rx="15" fill="url(#f)" stroke="url(#a)" stroke-width="2"/><path d="M45.5 21.5A15.5 15.5 0 1 0 47.5 37H33.5" fill="none" stroke="url(#a)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/><path d="M37.5 30.5 48 20M40.5 19.5H48.5V27.5" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="48.5" cy="19.5" r="3.2" fill="#D1FAE5"/></svg>');
const MARK = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path d="M45.5 21.5A15.5 15.5 0 1 0 47.5 37H33.5" fill="none" stroke="#0B3D2E" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>');
const WHAT = {
  deposit: ['إيداع للمحفظة', 'Wallet top-up'], withdrawal: ['سحب من المحفظة', 'Withdrawal'], partner_commission: ['عمولة نادي الشركاء', 'Partner club commission'],
  sandbox_credit: ['رصيد تجريبي (مش مصاري حقيقية)', 'Test credit (not real money)'], fx_out: ['تحويل عملة (من)', 'Currency exchange (out)'], fx_in: ['تحويل عملة (إلى)', 'Currency exchange (in)'],
  invest_buy: ['شراء ضمن خطة استثمار', 'Investment plan purchase'], invest_sell: ['بيع استثمار', 'Investment sale'], cashback: ['كاش باك', 'Cashback'],
  card_purchase: ['شراء بالبطاقة', 'Card purchase'], card_refund: ['استرجاع على البطاقة', 'Card refund'], card_fee: ['رسوم إصدار بطاقة', 'Card issuing fee'], deposit_reversal: ['استرجاع إيداع', 'Deposit reversal'],
  transfer_out: ['تحويل لعضو', 'Transfer to a member'], transfer_in: ['تحويل من عضو', 'Transfer from a member'], purchase: ['اشتراك GOTRIVA TRADE AI', 'GOTRIVA TRADE AI subscription'], purchase_refund: ['استرجاع اشتراك', 'Subscription refund'],
};
const how = (d) => d.provider === 'paypal' ? 'PayPal' : d.provider === 'stripe' ? L('بطاقة / Apple Pay (Stripe)', 'Card / Apple Pay (Stripe)') : d.type === 'withdrawal' ? L('تحويل للوجهة', 'Payout') : d.type === 'deposit' ? L('حوالة', 'Transfer') : L('رصيد البنك', 'Bank balance');
const day = (t) => new Date(t).toLocaleDateString('en-GB');
const money = (v, c) => `${c === 'USD' ? '$' : ''}${fmtMinor(v, c)}${c === 'USD' ? '' : ` ${c}`}`;

function loadImg(src) { return new Promise((ok) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => ok(null); i.src = src; }); }

/** Draws one document → canvas (A4, 2x). */
export async function drawDoc(d, info) {
  const cv = document.createElement('canvas'); cv.width = W * S; cv.height = H * S; const g = cv.getContext('2d'); g.scale(S, S);
  try { await document.fonts?.ready; } catch { /* system font */ }
  const font = getComputedStyle(document.body).fontFamily || 'system-ui, sans-serif'; const ar = document.documentElement.lang !== 'en';
  const put = (s, x, y, { size = 14, weight = 400, color = C.ink, align = 'right', dir = 'rtl', fontF = font } = {}) => { g.font = `${weight} ${size}px ${fontF}`; g.fillStyle = color; g.textAlign = align; g.direction = dir; g.fillText(String(s), x, y); };
  const RR = (x, y, w, h, r, fill, stroke) => { g.beginPath(); g.roundRect(x, y, w, h, r); if (fill) { g.fillStyle = fill; g.fill(); } if (stroke) { g.strokeStyle = stroke; g.stroke(); } };
  const R = W - 48, Lx = 48; const inv = d.kind === 'invoice';
  g.fillStyle = '#FFFFFF'; g.fillRect(0, 0, W, H);
  const band = g.createLinearGradient(0, 0, W, 0); band.addColorStop(0, C.dark); band.addColorStop(.6, C.green); band.addColorStop(1, C.mint); g.fillStyle = band; g.fillRect(0, 0, W, 10);
  const [logo, mark] = await Promise.all([loadImg(LOGO), loadImg(MARK)]);
  if (mark) { g.globalAlpha = .05; g.drawImage(mark, -50, H - 480, 380, 380); g.globalAlpha = 1; } if (logo) g.drawImage(logo, R - 58, 34, 58, 58);
  put('TRADE AI', R - 72, 66, { size: 22, weight: 800, color: C.green, dir: 'ltr', fontF: 'system-ui, sans-serif' }); g.font = '800 22px system-ui, sans-serif';
  put('GOTRIVA', R - 72 - g.measureText('TRADE AI ').width, 66, { size: 22, weight: 800, color: C.dark, dir: 'ltr', fontF: 'system-ui, sans-serif' });
  put(`${info.company.name} · ${L('البنك الرقمي', 'Digital bank')}`, R - 72, 88, { size: 12.5, color: C.mute });
  put(inv ? 'INVOICE' : 'RECEIPT', Lx, 70, { size: 30, weight: 800, color: C.dark, align: 'left', dir: 'ltr', fontF: 'system-ui, sans-serif' });
  put(inv ? L('فاتورة', 'Invoice') : L('إيصال', 'Receipt'), Lx, 96, { size: 18, weight: 700, color: C.green, align: 'left' });
  const st = d.status === 'completed' ? (inv ? L('✓ مدفوعة', '✓ Paid') : L('✓ مكتملة', '✓ Completed')) : d.status; g.font = `800 13px ${font}`; const pw = g.measureText(st).width + 28;
  RR(Lx, 108, pw, 26, 13, '#D1FAE5'); put(st, Lx + pw / 2, 126, { size: 13, weight: 800, color: '#065F46', align: 'center' });
  // meta row
  RR(Lx, 150, R - Lx, 62, 14, C.pale); const cols = [[L('رقم المستند', 'Number'), d.number], [L('التاريخ', 'Date'), day(d.at)], [L('رقم العملية', 'Transaction'), d.txn.slice(0, 16)], [L('العملة', 'Currency'), d.currency]];
  const cw = (R - Lx) / 4; cols.forEach(([k, v], i) => { const x = R - i * cw - 16; put(k, x, 174, { size: 11.5, color: C.mute }); put(v, x, 198, { size: 14, weight: 700, dir: 'ltr', align: 'right' }); if (i) { g.fillStyle = '#DDEBE4'; g.fillRect(R - i * cw, 158, 1, 46); } });
  // parties
  const co = info.company; const to = info.to; const fill = L('[يعبّى من الإعدادات]', '[set in settings]');
  put(L('من', 'From'), R, 250, { size: 12, weight: 700, color: C.green }); put(co.name, R, 276, { size: 15.5, weight: 800 }); put(co.nameEn, R, 298, { size: 14, dir: 'ltr' });
  put(`${L('إيميل الدعم:', 'Support:')} ${co.email || fill}`, R, 320, { size: 13.5, color: co.email ? C.ink : C.amber });
  put(`${L('رقم السجل:', 'Reg. no.:')} ${co.reg || fill}`, R, 342, { size: 13.5, color: co.reg ? C.ink : C.amber });
  const mx = W / 2 - 10; put(L('إلى', 'To'), mx, 250, { size: 12, weight: 700, color: C.green }); put(to.name || '—', mx, 276, { size: 15.5, weight: 800 });
  if (to.username) put(`${L('اسم المستخدم:', 'Username:')} ${to.username}`, mx, 298, { size: 14 }); put(to.email || '', mx, to.username ? 320 : 298, { size: 14, dir: 'ltr' });
  // table
  let y = 378; RR(Lx, y, R - Lx, 40, 10, C.dark);
  const cx = [R - 16, R - 340, R - 520, Lx + 16];
  [[L('البيان', 'Description'), 'right'], [L('الطريقة', 'Method'), 'right'], [L('الكمية', 'Qty'), 'right'], [L('المبلغ', 'Amount'), 'left']].forEach(([h, a], i) => put(h, cx[i], y + 26, { size: 13, weight: 700, color: '#FFFFFF', align: a }));
  y += 40; const net = d.type === 'withdrawal' ? d.amount - d.fee : d.amount;
  const rows = [[`${L(...(WHAT[d.type] || [d.type, d.type]))}${d.product ? ` · ${d.product}` : ''}`, how(d), '1', money(net, d.currency)]]; if (d.fee) rows.push([L('رسوم السحب', 'Withdrawal fee'), L('رسوم ثابتة', 'Flat fee'), '1', money(d.fee, d.currency)]);
  for (const r of rows) { put(r[0], cx[0], y + 34, { size: 14.5, weight: 700 }); put(r[1], cx[1], y + 34, { size: 14 }); put(r[2], cx[2], y + 34, { size: 14 }); put(r[3], cx[3], y + 34, { size: 14.5, weight: 800, align: 'left', dir: 'ltr' }); y += 58; g.fillStyle = C.line; g.fillRect(Lx, y, R - Lx, 1); }
  // totals + payment box
  y += 26; const tw = 300; const tot = [[L('المجموع الفرعي', 'Subtotal'), money(d.amount, d.currency)], [L('الضريبة', 'Tax'), money(0, d.currency)]];
  tot.forEach(([k, v], i) => { put(k, Lx + tw, y + 22 + i * 40, { size: 14 }); put(v, Lx + 4, y + 22 + i * 40, { size: 14, weight: 700, align: 'left', dir: 'ltr' }); g.fillStyle = C.line; g.fillRect(Lx, y + 34 + i * 40, tw, 1); });
  const gy = y + 92; const gr = g.createLinearGradient(Lx, gy, Lx + tw, gy + 50); gr.addColorStop(0, C.dark); gr.addColorStop(1, C.mid); RR(Lx, gy, tw, 50, 12, gr);
  put(L('الإجمالي', 'Total'), Lx + tw - 16, gy + 32, { size: 17, weight: 800, color: '#FFFFFF' }); put(money(d.amount, d.currency), Lx + 16, gy + 32, { size: 17, weight: 800, color: '#FFFFFF', align: 'left', dir: 'ltr' });
  g.setLineDash([5, 4]); RR(Lx + tw + 24, y, R - Lx - tw - 24, 142, 14, null, '#A7D7C2'); g.setLineDash([]);
  const px = R - 16; put(L('تفاصيل الدفع', 'Payment details'), px, y + 28, { size: 13.5, weight: 800, color: C.dark });
  put(`${L('الحالة:', 'Status:')} ${st} · ${new Date(d.at).toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' })}`, px, y + 54, { size: 13 });
  if (d.ref) put(`${L('المرجع:', 'Ref:')} ${String(d.ref).slice(0, 34)}`, px, y + 78, { size: 13 });
  put(L('صادر إلكترونيًا وما بيحتاج توقيع.', 'Issued electronically; no signature needed.'), px, y + (d.ref ? 102 : 78), { size: 13, color: C.mute });
  // verification
  y = gy + 84; RR(Lx, y, R - Lx, 88, 14, C.pale);
  g.save(); g.translate(R - 52, y + 44); g.rotate(-.21); g.beginPath(); g.arc(0, 0, 32, 0, Math.PI * 2); g.strokeStyle = C.green; g.lineWidth = 2; g.stroke(); g.restore();
  g.save(); g.translate(R - 52, y + 44); g.rotate(-.21); put('GOTRIVA', 0, -2, { size: 10, weight: 800, color: C.green, align: 'center', dir: 'ltr', fontF: 'system-ui, sans-serif' }); put('VERIFIED', 0, 11, { size: 10, weight: 800, color: C.green, align: 'center', dir: 'ltr', fontF: 'system-ui, sans-serif' }); g.restore();
  put(L('تحقّق من المستند', 'Verify this document'), R - 100, y + 28, { size: 14, weight: 800 });
  put(`${L('رمز التحقق:', 'Code:')} ${d.verify}`, R - 100, y + 52, { size: 14, weight: 700 });
  put(`${location.host}/#/verify`, R - 100, y + 74, { size: 12.5, color: C.mute, dir: 'ltr' });
  if (d.test || info.mode === 'sandbox') { g.save(); g.translate(W / 2, 560); g.rotate(-.35); put(L('تجريبي — مش مصاري حقيقية', 'TEST — not real money'), 0, 0, { size: 46, weight: 800, color: 'rgba(180,83,9,.14)', align: 'center' }); g.restore(); }
  // footer
  g.fillStyle = '#FAFCFB'; g.fillRect(0, H - 52, W, 52); g.fillStyle = C.line; g.fillRect(0, H - 52, W, 1);
  put(L('شكرًا لثقتك بـ GOTRIVA TRADE AI', 'Thank you for choosing GOTRIVA TRADE AI'), R, H - 21, { size: 11.5, color: C.mute }); put(`${d.number} · 1 / 1`, Lx, H - 21, { size: 11.5, color: C.mute, align: 'left', dir: 'ltr' });
  void ar; return cv;
}

/** A one-page A4 PDF holding the drawn page as a JPEG (renders Arabic exactly as on screen). */
async function toPdf(cv) {
  const b64 = cv.toDataURL('image/jpeg', 0.92).split(',')[1]; const img = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  const enc = new TextEncoder(); const parts = []; const off = []; let len = 0; const add = (x) => { const b = typeof x === 'string' ? enc.encode(x) : x; parts.push(b); len += b.length; };
  const obj = (n, body, stream) => { off[n] = len; add(`${n} 0 obj\n${body}\n`); if (stream) { add('stream\n'); add(stream); add('\nendstream\n'); } add('endobj\n'); };
  const draw = enc.encode('q 595.28 0 0 841.89 0 0 cm /Im0 Do Q');
  add('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>'); obj(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  obj(3, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>');
  obj(4, `<< /Type /XObject /Subtype /Image /Width ${cv.width} /Height ${cv.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.length} >>`, img);
  obj(5, `<< /Length ${draw.length} >>`, draw);
  const x = len; add(`xref\n0 6\n0000000000 65535 f \n${[1, 2, 3, 4, 5].map((n) => `${String(off[n]).padStart(10, '0')} 00000 n \n`).join('')}trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${x}\n%%EOF`);
  return new Blob(parts, { type: 'application/pdf' });
}

/** Save to the phone: the share sheet when the device has one (→ Save image / Save to Files), else a download. */
async function save(blob, name) {
  const file = new File([blob], name, { type: blob.type });
  try { if (navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], title: name }); return true; } } catch (e) { if (e?.name === 'AbortError') return false; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); return true;
}

function viewer(d, info) {
  const el = document.createElement('div'); el.className = 'iv'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', d.number);
  el.innerHTML = `<div class="iv-top"><b>${esc(d.number)}</b><button type="button" class="iv-x" aria-label="${esc(L('سكّر', 'Close'))}">${icons.close}</button></div>
    <div class="iv-paper"><span class="spinner"></span></div>
    <div class="iv-acts"><button type="button" class="pm-go" data-img disabled>${icons.download}<span>${esc(L('احفظ صورة', 'Save image'))}</span></button><button type="button" class="pm-go is-soft" data-pdf disabled>${icons.download}<span>PDF</span></button></div>`;
  const close = () => { el.remove(); document.removeEventListener('keydown', key); window.removeEventListener('hashchange', close); }; const key = (e) => { if (e.key === 'Escape') close(); };
  el.querySelector('.iv-x').addEventListener('click', close); document.addEventListener('keydown', key); window.addEventListener('hashchange', close); document.body.append(el);
  drawDoc(d, info).then((cv) => {
    const img = new Image(); img.alt = d.number; img.src = cv.toDataURL('image/png'); el.querySelector('.iv-paper').replaceChildren(img);
    const bi = el.querySelector('[data-img]'); const bp = el.querySelector('[data-pdf]'); bi.disabled = false; bp.disabled = false;
    bi.addEventListener('click', () => cv.toBlob((b) => b && save(b, `${d.number}.png`), 'image/png'));
    bp.addEventListener('click', async () => { bp.disabled = true; try { await save(await toPdf(cv), `${d.number}.pdf`); } finally { bp.disabled = false; } });
  });
}

export async function docsTab(p) {
  p.innerHTML = '<article class="card gt-pay"><span class="spinner"></span></article>';
  let r; try { r = await bankApi.documents(); } catch (e) { p.innerHTML = `<article class="card gt-pay"><p class="muted">${esc(L('ما قدرنا نجيب المستندات.', 'Could not load your documents.'))}</p></article>`; return; }
  let tab = 'all';
  const paint = () => {
    const items = r.items.filter((d) => tab === 'all' || d.kind === tab);
    p.innerHTML = `<article class="card gt-pay"><div class="pm"><h2>${esc(L('فواتيري وإيصالاتي', 'My invoices & receipts'))}</h2><p class="pm-sub">${esc(L('كل عملية إلها إيصال، والرسوم إلها فاتورة. كبسة وحدة بتفتحها، وبتحفظها صورة أو PDF.', 'Every movement has a receipt and every fee an invoice. One tap opens it; save it as an image or PDF.'))}</p>
      <div class="dk-tabs" role="tablist">${[['all', 'الكل', 'All'], ['invoice', 'فواتير', 'Invoices'], ['receipt', 'إيصالات', 'Receipts']].map(([k, a, e]) => `<button type="button" role="tab" aria-selected="${k === tab}" data-t="${k}">${esc(L(a, e))}</button>`).join('')}</div>
      <div class="iv-list">${items.length ? items.map((d, i) => { const out = ['withdrawal', 'fx_out', 'invest_buy', 'card_purchase', 'card_fee', 'deposit_reversal', 'transfer_out', 'purchase'].includes(d.type);
        return `<button type="button" class="iv-row" data-i="${r.items.indexOf(d)}"><span class="iv-ic ${d.kind}">${d.kind === 'invoice' ? 'INV' : out ? '↑' : '↓'}</span><span class="iv-tx"><b>${esc(L(...(WHAT[d.type] || [d.type, d.type])))}</b><small><bdi dir="ltr">${esc(d.number)}</bdi> · ${esc(day(d.at))}</small></span><span class="iv-amt ${out ? 'out' : 'in'}" dir="ltr">${out ? '−' : '+'}${esc(money(d.amount, d.currency))}</span></button>`; void i; }).join('')
        : `<p class="muted dk-empty">${esc(L('لسا ما في عمليات. أول إيداع أو سحب بيطلعلك إيصاله هون.', 'No movements yet. Your first deposit or withdrawal shows its receipt here.'))}</p>`}</div></div></article>`;
    p.querySelectorAll('[data-t]').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.t; paint(); }));
    p.querySelectorAll('[data-i]').forEach((b) => b.addEventListener('click', () => viewer(r.items[Number(b.dataset.i)], r)));
  };
  paint();
}
