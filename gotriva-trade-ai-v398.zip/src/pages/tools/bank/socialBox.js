// v390 One card under «Send to a member»: money requests, shared pots, my receive code (QR) and «renew my plan from the balance».
import { bankApi } from '../../../services/bank/api.js';
import { tx } from '../../../i18n/tx.js';
import { qrSvg } from '../../../utils/qr.js';
import { esc } from './ui.js';

const L = (ar, en) => tx({ ar, en });
const iso = (x) => `⁨${x}⁩`;
const usd = (c) => `$${(c / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const who = (p) => p?.name || p?.username || '—';
const day = (t) => new Date(t).toLocaleDateString(L('ar', 'en'), { day: 'numeric', month: 'short' });
const TABS = [['req', L('طلبات المصاري', 'Requests')], ['pot', L('صندوق مشترك', 'Shared pot')], ['gift', L('هدية', 'Gift')], ['code', L('كودي', 'My code')], ['auto', L('تجديد تلقائي', 'Auto-renew')]];
const STATUS = { pending: L('بالانتظار', 'Waiting'), paid: L('انْدفع', 'Paid'), declined: L('انرفض', 'Declined'), cancelled: L('انلغى', 'Cancelled'), expired: L('انتهى', 'Expired') };

let tab = 'req';   // kept across re-renders of the page (a balance update redraws it)
export function socialBox(host, { act, secure, onDone }) {
  const paint = async () => {
    host.innerHTML = `<div class="pm sx"><div class="sx-tabs" role="tablist">${TABS.map(([k, t]) => `<button type="button" role="tab" aria-selected="${k === tab}" data-t="${k}">${esc(t)}</button>`).join('')}</div><div data-body><p class="pm-sub">…</p></div></div>`;
    host.querySelectorAll('[data-t]').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.t; paint(); }));
    const body = host.querySelector('[data-body]');
    try { await ({ req: reqTab, pot: potTab, gift: giftTab, code: codeTab, auto: autoTab })[tab](body); } catch { body.innerHTML = `<p class="pm-warn">${esc(L('ما قدرنا نحمّل هالقسم. جرّب كمان شوي.', 'Could not load this part. Try again shortly.'))}</p>`; }
  };
  const done = () => { paint(); onDone?.(); };

  async function reqTab(b) {
    const q = await bankApi.requests();
    b.innerHTML = `${q.incoming.length ? `<h3 class="sx-h">${esc(L('طالبين منك', 'Asked from you'))}</h3><ul class="sx-list">${q.incoming.map((r) => `<li><div><b><bdi>${esc(who(r.other))}</bdi></b><small>${esc(r.note || '')}${r.note ? ' · ' : ''}${esc(day(r.at))}</small></div><b dir="ltr">${usd(r.amount)}</b>
        <div class="sx-act"><button type="button" class="pm-go" data-pay="${esc(r.id)}" data-u="${esc(r.other.username)}" data-a="${(r.amount / 100).toFixed(2)}">${esc(L('ادفع', 'Pay'))}</button><button type="button" class="pm-go is-soft" data-decline="${esc(r.id)}">${esc(L('ارفض', 'Decline'))}</button></div></li>`).join('')}</ul>` : ''}
      <form class="sx-form" data-rq novalidate><h3 class="sx-h">${esc(L('اطلب مصاري', 'Request money'))}</h3>
        <label class="pm-f">${esc(L('من (اسم المستخدم بالبنك)', 'From (bank username)'))}<span class="bl-in"><input name="to" dir="ltr" placeholder="GT-12345" maxlength="20" autocapitalize="characters" required></span></label>
        <div class="sx-two"><label class="pm-f">${esc(L('المبلغ $', 'Amount $'))}<span class="bl-in"><input name="amount" inputmode="decimal" dir="ltr" placeholder="45" required></span></label><label class="pm-f">${esc(L('السبب', 'What for'))}<span class="bl-in"><input name="note" maxlength="60"></span></label></div>
        <button type="submit" class="pm-go">${esc(L('ابعت الطلب', 'Send request'))}</button><p class="pm-lnote">${esc(L('بيوصله إشعار فيه زر «ادفع»، والدفع بيصير بتحويل عادي ضمن حدوده. الطلب بينتهي بعد 7 أيام.', 'They get a notice with a «Pay» button; paying is a normal transfer inside their limits. Requests end after 7 days.'))}</p></form>
      ${q.outgoing.length ? `<h3 class="sx-h">${esc(L('طلباتك', 'Your requests'))}</h3><ul class="sx-list">${q.outgoing.map((r) => `<li><div><b><bdi>${esc(who(r.other))}</bdi></b><small>${esc(STATUS[r.status] || r.status)} · ${esc(day(r.at))}</small></div><b dir="ltr">${usd(r.amount)}</b>${r.status === 'pending' ? `<div class="sx-act"><button type="button" class="pm-go is-soft" data-cancel="${esc(r.id)}">${esc(L('إلغاء', 'Cancel'))}</button></div>` : ''}</li>`).join('')}</ul>` : ''}`;
    b.querySelectorAll('[data-pay]').forEach((x) => x.addEventListener('click', async () => { const p = { to: x.dataset.u, amount: x.dataset.a }; if (await act(x, () => secure('p2p', p, (passkey) => bankApi.payRequest(x.dataset.pay, { passkey })), L('انْدفع الطلب', 'Request paid'))) done(); }));
    b.querySelectorAll('[data-decline]').forEach((x) => x.addEventListener('click', async () => { if (await act(x, () => bankApi.closeRequest(x.dataset.decline, 'decline'))) paint(); }));
    b.querySelectorAll('[data-cancel]').forEach((x) => x.addEventListener('click', async () => { if (await act(x, () => bankApi.closeRequest(x.dataset.cancel, 'cancel'))) paint(); }));
    const f = b.querySelector('[data-rq]');
    f.addEventListener('submit', async (e) => { e.preventDefault(); const v = { to: f.to.value.trim().toUpperCase(), amount: f.amount.value.trim(), note: f.note.value.trim() || undefined }; if (await act(f.querySelector('button'), () => bankApi.requestMoney(v), L('انبعت الطلب', 'Request sent'))) paint(); });
  }

  async function potTab(b) {
    const r = await bankApi.pots();
    const pot = (p) => { const pct = Math.round((p.collected / p.target) * 100); const me = p.members.find((m) => m.me); const mine = p.creator.me;
      return `<li class="sx-pot"><div class="sx-pot-h"><b>${esc(p.name)}</b><small dir="ltr">${usd(p.share)} × ${p.members.length}</small></div>
        <div class="sx-bar" role="img" aria-label="${esc(`${pct}%`)}"><i style="width:${pct}%"></i></div><small class="sx-sum">${esc(L(`انجمع ${iso(usd(p.collected))} من ${iso(usd(p.target))}`, `${usd(p.collected)} of ${usd(p.target)} collected`))}${p.status !== 'open' ? ` · ${esc(p.status === 'done' ? L('كمل ونزل للمنظّم', 'Complete, paid to the organiser') : L('انلغى ورجعت الحصص', 'Cancelled, shares returned'))}` : ''}</small>
        <ul class="sx-mem">${p.members.map((m) => `<li><i aria-hidden="true">${esc(who(m).charAt(0))}</i><bdi>${esc(who(m))}${m.me ? esc(L(' (إنت)', ' (you)')) : ''}</bdi><span class="${m.paid ? 'is-ok' : ''}">${esc(m.paid ? L('دفع ✓', 'Paid ✓') : L('بانتظار', 'Waiting'))}</span></li>`).join('')}</ul>
        ${p.status === 'open' ? `<div class="sx-act">${me && !me.paid ? `<button type="button" class="pm-go" data-ppay="${esc(p.id)}" data-u="${esc(p.creator.username)}" data-a="${(p.share / 100).toFixed(2)}">${esc(L(`ادفع حصتي ${iso(usd(p.share))}`, `Pay my share ${usd(p.share)}`))}</button>` : ''}${mine ? `<button type="button" class="pm-go is-soft" data-prem="${esc(p.id)}">${esc(L('ذكّر الباقيين', 'Remind the rest'))}</button><button type="button" class="pm-go is-soft" data-pcan="${esc(p.id)}">${esc(L('إلغاء الصندوق', 'Cancel pot'))}</button>` : ''}</div>` : ''}</li>`; };
    b.innerHTML = `${r.items.length ? `<ul class="sx-list">${r.items.map(pot).join('')}</ul>` : ''}
      <form class="sx-form" data-pf novalidate><h3 class="sx-h">${esc(L('صندوق جديد', 'New pot'))}</h3>
        <div class="sx-two"><label class="pm-f">${esc(L('على شو؟', 'What for?'))}<span class="bl-in"><input name="name" maxlength="40" placeholder="${esc(L('اشتراك الإشارات السنوي', 'Yearly signals plan'))}" required></span></label><label class="pm-f">${esc(L('حصة كل واحد $', 'Share each $'))}<span class="bl-in"><input name="share" inputmode="decimal" dir="ltr" placeholder="90" required></span></label></div>
        <label class="pm-f">${esc(L('مين معك؟ (أسماء المستخدمين، افصل بفاصلة)', 'Who else? (usernames, comma separated)'))}<span class="bl-in"><input name="members" dir="ltr" placeholder="GT-12345, GT-67890" autocapitalize="characters" required></span></label>
        <button type="submit" class="pm-go">${esc(L('افتح الصندوق', 'Open the pot'))}</button>
        <p class="pm-lnote">${esc(L('الحصص بتضل محجوزة بالصندوق. لما الكل يدفع، المبلغ كامل بينزل على محفظتك وبتقدر تدفع فيه الاشتراك. إذا لغيته قبل، كل واحد بترجعله حصته.', 'Shares stay held in the pot. When everyone paid, the full amount lands in your wallet so you can pay the plan with it. Cancel before that and each share goes back.'))}</p></form>`;
    b.querySelectorAll('[data-ppay]').forEach((x) => x.addEventListener('click', async () => { const p = { to: x.dataset.u, amount: x.dataset.a }; if (await act(x, () => secure('p2p', p, (passkey) => bankApi.payPot(x.dataset.ppay, { passkey })), L('انْدفعت حصتك', 'Your share is paid'))) done(); }));
    b.querySelectorAll('[data-prem]').forEach((x) => x.addEventListener('click', async () => { await act(x, () => bankApi.potAction(x.dataset.prem, 'remind'), L('وصلهم تذكير', 'Reminder sent')); }));
    b.querySelectorAll('[data-pcan]').forEach((x) => x.addEventListener('click', async () => { if (x.dataset.sure !== '1') { x.dataset.sure = '1'; x.textContent = L('متأكد؟ اكبس كمان مرة', 'Sure? Tap again'); return; } if (await act(x, () => bankApi.potAction(x.dataset.pcan, 'cancel'), L('انلغى الصندوق ورجعت الحصص', 'Pot cancelled, shares returned'))) done(); }));
    const f = b.querySelector('[data-pf]');
    f.addEventListener('submit', async (e) => { e.preventDefault(); const members = f.members.value.split(/[\s,،]+/).map((x) => x.trim().toUpperCase()).filter(Boolean);
      if (await act(f.querySelector('button'), () => bankApi.createPot({ name: f.name.value.trim(), share: f.share.value.trim(), members }), L('انفتح الصندوق ووصلهم إشعار', 'Pot opened; they were notified'))) paint(); });
  }

  async function giftTab(b) {   // v391 gift cards
    const r = await bankApi.gifts(); const ST = { active: L('ما انستعملت', 'Unused'), redeemed: L('انستعملت', 'Redeemed'), cancelled: L('انلغت', 'Cancelled') };
    b.innerHTML = `<form class="sx-form" data-gr novalidate><h3 class="sx-h">${esc(L('عندك كود هدية؟', 'Have a gift code?'))}</h3>
        <label class="pm-f">${esc(L('الكود', 'Code'))}<span class="bl-in"><input name="code" dir="ltr" placeholder="GFT-XXXX-XXXX-XXXX" autocapitalize="characters" autocomplete="off" required></span></label>
        <button type="submit" class="pm-go is-soft">${esc(L('استعمل الهدية', 'Redeem'))}</button></form>
      <form class="sx-form" data-gb novalidate><h3 class="sx-h">${esc(L('ابعت بطاقة هدية', 'Send a gift card'))}</h3>
        <div class="sx-two"><label class="pm-f">${esc(L('المبلغ $ (10–600)', 'Amount $ (10–600)'))}<span class="bl-in"><input name="amount" inputmode="decimal" dir="ltr" placeholder="50" required></span></label><label class="pm-f">${esc(L('رسالة', 'Message'))}<span class="bl-in"><input name="note" maxlength="60" placeholder="${esc(L('كل عام وإنت بخير', 'Happy birthday'))}"></span></label></div>
        <button type="submit" class="pm-go">${esc(L('اشتري البطاقة من رصيدي', 'Buy it from my balance'))}</button>
        <p class="pm-lnote">${esc(L('بيطلعلك كود تبعته لأي عضو عنده حساب. المبلغ بيضل محجوز لحد ما ينستعمل، وإذا ما انستعمل بتقدر تلغيه وبترجعلك مصاريك.', 'You get a code to send to any member with an account. The money stays held until it is used; cancel an unused one to get it back.'))}</p></form>
      <div data-gnew></div>
      ${r.items.length ? `<h3 class="sx-h">${esc(L('بطاقاتك', 'Your gift cards'))}</h3><ul class="sx-list">${r.items.map((g) => `<li><div><b dir="ltr">${usd(g.amount)}</b><small>${esc(ST[g.status] || g.status)} · ${esc(day(g.at))}${g.note ? ` · ${esc(g.note)}` : ''}</small>${g.code ? `<small dir="ltr" class="sx-gcode">${esc(g.code)}</small>` : ''}</div><span></span>
        ${g.status === 'active' ? `<div class="sx-act"><button type="button" class="pm-go is-soft" data-gcopy="${esc(g.code || '')}">${esc(L('انسخ الكود', 'Copy code'))}</button><button type="button" class="pm-go is-soft" data-gcan="${esc(g.id)}">${esc(L('إلغاء ورجّع المصاري', 'Cancel and refund'))}</button></div>` : ''}</li>`).join('')}</ul>` : ''}`;
    const fr = b.querySelector('[data-gr]');
    fr.addEventListener('submit', async (e) => { e.preventDefault(); const x = await act(fr.querySelector('button'), () => bankApi.redeemGift(fr.code.value.trim())); if (x) { toast2(L(`وصلك ${iso(usd(x.amount))} هدية من ${iso(x.from || '—')}`, `${usd(x.amount)} gift from ${x.from || '—'} received`)); done(); } });
    const fb = b.querySelector('[data-gb]');
    fb.addEventListener('submit', async (e) => { e.preventDefault(); const v = { amount: fb.amount.value.trim(), note: fb.note.value.trim() || undefined };
      const x = await act(fb.querySelector('button'), () => secure('p2p', { to: 'GIFT', amount: v.amount }, (passkey) => bankApi.createGift({ ...v, passkey }))); if (!x) return;
      b.querySelector('[data-gnew]').innerHTML = `<div class="sx-gift"><small>GOTRIVA · ${esc(L('بطاقة هدية', 'Gift card'))}</small><b dir="ltr">${usd(x.amount)}</b><code dir="ltr">${esc(x.code)}</code>${x.note ? `<span>${esc(x.note)}</span>` : ''}</div>
        <div class="sx-act"><button type="button" class="pm-go" data-gc>${esc(L('انسخ الكود', 'Copy code'))}</button>${navigator.share ? `<button type="button" class="pm-go is-soft" data-gs>${esc(L('شارك', 'Share'))}</button>` : ''}</div>`;
      const msg = L(`هدية إلك على GOTRIVA بقيمة ${usd(x.amount)}. الكود: ${x.code}`, `A GOTRIVA gift of ${usd(x.amount)}. Code: ${x.code}`);
      b.querySelector('[data-gc]').addEventListener('click', (ev) => navigator.clipboard?.writeText(x.code).then(() => { ev.target.textContent = L('انتسخ ✓', 'Copied ✓'); }).catch(() => {}));
      b.querySelector('[data-gs]')?.addEventListener('click', () => navigator.share({ text: msg }).catch(() => {})); });
    b.querySelectorAll('[data-gcopy]').forEach((x) => x.addEventListener('click', () => navigator.clipboard?.writeText(x.dataset.gcopy).then(() => { x.textContent = L('انتسخ ✓', 'Copied ✓'); }).catch(() => {})));
    b.querySelectorAll('[data-gcan]').forEach((x) => x.addEventListener('click', async () => { if (x.dataset.sure !== '1') { x.dataset.sure = '1'; x.textContent = L('متأكد؟ اكبس كمان مرة', 'Sure? Tap again'); return; } if (await act(x, () => bankApi.cancelGift(x.dataset.gcan), L('انلغت ورجعت المصاري', 'Cancelled and refunded'))) done(); }));
  }
  const toast2 = (m) => { import('../../../components/ui.js').then((u) => u.toast(m, 'success', 6000)).catch(() => {}); };

  async function codeTab(b) {
    const { username } = await bankApi.p2pMe();
    b.innerHTML = username ? `<div class="sx-code"><div class="sx-qr">${qrSvg(username, { label: username })}</div><b dir="ltr">${esc(username)}</b>
      <p class="pm-lnote">${esc(L('خلّي صاحبك يمسحه من «حوّل لعضو» (زر الكاميرا)، أو ابعتله اسم المستخدم.', 'Let a friend scan it from «Send to a member» (camera button), or send them your username.'))}</p>
      <div class="sx-act"><button type="button" class="pm-go" data-copy>${esc(L('انسخ', 'Copy'))}</button>${navigator.share ? `<button type="button" class="pm-go is-soft" data-share>${esc(L('شارك', 'Share'))}</button>` : ''}</div></div>`
      : `<p class="pm-sub">${esc(L('الكود بيطلع بعد ما ينفتح حسابك بالبنك.', 'Your code appears once your bank account is open.'))}</p>`;
    b.querySelector('[data-copy]')?.addEventListener('click', async (e) => { try { await navigator.clipboard.writeText(username); e.target.textContent = L('انتسخ ✓', 'Copied ✓'); } catch { /* the username is shown above */ } });
    b.querySelector('[data-share]')?.addEventListener('click', () => navigator.share({ text: L(`حوّلي على GOTRIVA: ${username}`, `Send to me on GOTRIVA: ${username}`) }).catch(() => {}));
  }

  async function autoTab(b) {
    const a = await bankApi.autoRenew();
    const pl = a.plan;
    b.innerHTML = `<div class="sx-auto"><div class="sx-arow"><div><b>${esc(L('جدّد اشتراكي من الرصيد', 'Renew my plan from my balance'))}</b><small>${esc(pl ? L(`بيتجدد ${iso(day(pl.until))} · ${iso(usd(pl.cents))}`, `Renews ${day(pl.until)} · ${usd(pl.cents)}`) : L('ما عندك اشتراك شهري شغّال هلّق.', 'You have no active plan right now.'))}</small></div>
      <button type="button" class="sx-sw" role="switch" aria-checked="${Boolean(a.on)}" data-ar aria-label="${esc(L('تجديد تلقائي', 'Auto-renew'))}"><i></i></button></div>
      ${a.on && pl && a.short > 0 ? `<p class="pm-warn">${esc(L(`رصيدك ${iso(usd(a.balance))} وما بيكفي للتجديد (${iso(usd(pl.cents))}). أودع ${iso(usd(a.short))} قبل ${iso(day(pl.until))}.`, `Your balance ${usd(a.balance)} is short of the renewal (${usd(pl.cents)}). Add ${usd(a.short)} before ${day(pl.until)}.`))}</p>` : ''}
      <p class="pm-lnote">${esc(L('بآخر 24 ساعة من اشتراكك بنشتري نفس الباقة من رصيدك وبتكمل من آخر يوم. قبل 3 أيام، إذا الرصيد ما بيكفي، بيوصلك تذكير. بتقدر تطفيها بأي وقت.', 'In your plan’s last 24 hours we buy the same plan from your balance; it continues from the end date. Three days before, if the balance is short, you get a reminder. Turn it off any time.'))}</p>
      <p class="pm-lnote">${esc(L('الادخار التلقائي (التقريب، الجدول، «احمي أرباحي») بتلاقيه بقسم «الميزانية والادخار».', 'Automatic saving (round-up, schedule, «protect profits») is under «Budget & saving».'))}</p></div>`;
    b.querySelector('[data-ar]').addEventListener('click', async (e) => { const on = e.currentTarget.getAttribute('aria-checked') !== 'true'; if (await act(e.currentTarget, () => bankApi.setAutoRenew(on), on ? L('انفتح التجديد التلقائي', 'Auto-renew on') : L('انطفى التجديد التلقائي', 'Auto-renew off'))) paint(); });
  }

  paint();
}
