// v383 One way in and one way out: deposit and withdraw with the same methods — Apple Pay / Google Pay, Visa / Mastercard,
// PayPal, bank transfer (and crypto out) — with today's limit on top. Card and wallet payments run on Stripe's page, PayPal on
// PayPal's; we never see a card number. Every withdrawal waits for the bank team; above the daily limit it needs a reason.
import { bankApi } from '../../../services/bank/api.js';
import { tx } from '../../../i18n/tx.js';
import { icons } from '../../../components/icons.js';
import { esc, fmtMinor, CURRENCIES } from './ui.js';

const L = (ar, en) => tx({ ar, en });
const APL = '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" aria-hidden="true"><path d="M16.4 12.6c0-2.4 2-3.5 2-3.6-1.1-1.6-2.8-1.8-3.4-1.8-1.4-.2-2.8.8-3.5.8-.7 0-1.8-.8-3-.8-1.5 0-3 .9-3.8 2.3-1.6 2.8-.4 7 1.2 9.2.8 1.1 1.7 2.3 2.9 2.3 1.2-.1 1.6-.8 3-.8s1.8.8 3 .7c1.2 0 2-1.1 2.8-2.2.9-1.3 1.2-2.5 1.3-2.6-.1 0-2.5-.9-2.5-3.5zM14.1 5.6c.6-.8 1.1-1.8 1-2.9-.9 0-2 .6-2.7 1.4-.6.7-1.1 1.8-1 2.8 1 .1 2.1-.5 2.7-1.3z"/></svg>';
const BADGE = { wallet: `<span class="pm-ic pm-ap">${APL}Pay</span>`, card: '<span class="pm-ic pm-vi">VISA</span>', paypal: '<span class="pm-ic pm-pp">PayPal</span>', bank: '<span class="pm-ic pm-bk">IBAN</span>', crypto: '<span class="pm-ic pm-cr">USDT</span>' };
const usd = (c) => `$${(c / 100).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
const limitBar = (left, total, label, note) => `<div class="pm-lim"><div class="pm-row"><span>${esc(label)}</span><b dir="ltr">${usd(left)} / ${usd(total)}</b></div><div class="pm-bar"><i style="width:${total ? Math.round((left / total) * 100) : 0}%"></i></div>${note ? `<p class="pm-lnote">${esc(note)}</p>` : ''}</div>`;
const methodList = (ms, on) => `<div class="pm-list" role="radiogroup">${ms.map(([k, t, sub]) => `<button type="button" role="radio" aria-checked="${k === on}" class="pm-m" data-m="${k}">${BADGE[k]}<span><b>${esc(t)}</b><small>${esc(sub)}</small></span><i class="pm-rd" aria-hidden="true"></i></button>`).join('')}</div>`;
const pick = (box, on) => box.querySelectorAll('[data-m]').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.m === on)));

/** Deposit card. `bankForm` is the existing bank-transfer form, shown when that method is picked. */
export async function depositBox(host, { act, rails, paypal, bankForm }) {
  const lim = await bankApi.limits().catch(() => null); const t = lim?.topup;
  const ms = [...(rails.topup ? [['wallet', 'Apple Pay / Google Pay', L('بيطلع تلقائي على الآيفون والأندرويد', 'Shows up on iPhone and Android')], ['card', L('بطاقة فيزا / ماستركارد', 'Visa / Mastercard'), L('دفع آمن عبر Stripe', 'Secure payment on Stripe')]] : []),
    ...(paypal ? [['paypal', 'PayPal', L('بتنتقل لـ PayPal وبترجع', 'You go to PayPal and come back')]] : []), ['bank', L('حوالة بنكية', 'Bank transfer'), L('بيأكّدها فريق البنك', 'Confirmed by the bank team')]];
  let on = ms[0][0];
  host.innerHTML = `<div class="pm"><h2>${esc(L('إيداع', 'Deposit'))}</h2><p class="pm-sub">${esc(L('اختار طريقة الدفع. المبلغ بيوصل لمحفظة الدولار.', 'Pick how to pay. The amount lands in your USD wallet.'))}</p>
    ${t ? limitBar(t.left, t.day, L('متاح اليوم', 'Available today'), L(`أقل مبلغ ${usd(t.min)} · أكتر مبلغ ${usd(t.day)} باليوم`, `Min ${usd(t.min)} · up to ${usd(t.day)} a day`)) : ''}
    ${methodList(ms, on)}<form class="pm-pay" data-pay novalidate><label class="pm-amt"><span>$</span><input name="amount" inputmode="decimal" dir="ltr" placeholder="100" aria-label="${esc(L('المبلغ', 'Amount'))}" required></label>
    <div class="pm-chips" dir="ltr">${[50, 100, 250, 500, 1000].map((v) => `<button type="button" data-v="${v}">$${v.toLocaleString('en-US')}</button>`).join('')}</div>
    <button class="pm-go" type="submit" data-go></button><p class="pm-note">${icons.lock || icons.shield}<span>${esc(L('ما بنشوف رقم بطاقتك. الدفع بيصير عند Stripe أو PayPal مباشرة.', 'We never see your card number. You pay on Stripe or PayPal directly.'))}</span></p></form></div>`;
  const f = host.querySelector('[data-pay]'); const go = f.querySelector('[data-go]');
  const show = () => {
    pick(host, on); f.hidden = on === 'bank'; if (bankForm) bankForm.hidden = on !== 'bank';
    go.className = `pm-go${on === 'wallet' ? ' is-ap' : on === 'paypal' ? ' is-pp' : ''}`;
    go.innerHTML = on === 'wallet' ? `${APL}<span>${esc(L('ادفع بـ Apple Pay / Google Pay', 'Pay with Apple Pay / Google Pay'))}</span>` : on === 'paypal' ? `<span>${esc(L('ادفع بـ PayPal', 'Pay with PayPal'))}</span>` : `<span>${esc(L('ادفع بالبطاقة', 'Pay by card'))}</span>`;
  };
  host.querySelectorAll('[data-m]').forEach((b) => b.addEventListener('click', () => { on = b.dataset.m; show(); }));
  f.querySelectorAll('[data-v]').forEach((b) => b.addEventListener('click', () => { f.amount.value = b.dataset.v; }));
  f.addEventListener('submit', async (e) => {
    e.preventDefault(); const amount = f.amount.value.trim(); if (!amount) { f.amount.focus(); return; }
    if (on === 'paypal') { const r = await act(go, () => bankApi.paypalOrder(amount)); if (r?.approveUrl && /^https:\/\/([\w-]+\.)*paypal\.com\//.test(r.approveUrl)) { try { sessionStorage.setItem('gt:pp-order', r.orderId); } catch { /* */ } location.href = r.approveUrl; } return; }
    const r = await act(go, () => bankApi.topup(amount)); if (r?.url && /^https:\/\/checkout\.stripe\.com\//.test(r.url)) location.href = r.url;
  });
  show();
}

/** Back from PayPal: capture the order this tab started. → a message for the toast, or '' when nothing to do. */
export async function paypalReturn() {
  const h = location.hash; if (!/[?&]paypal=(return|cancel)/.test(h)) return null;
  let id = ''; try { id = sessionStorage.getItem('gt:pp-order') || ''; sessionStorage.removeItem('gt:pp-order'); } catch { /* */ }
  history.replaceState(null, '', h.replace(/[?&]paypal=[^&]*(&token=[^&]*)?(&PayerID=[^&]*)?/, ''));
  if (/paypal=cancel/.test(h) || !id) return { ok: false, text: L('ما تمّ الدفع بـ PayPal.', 'The PayPal payment was not completed.') };
  try { const r = await bankApi.paypalCapture(id); return { ok: true, text: L(`وصل ${usd(r.amount)} لمحفظتك من PayPal.`, `${usd(r.amount)} from PayPal is in your wallet.`) }; }
  catch (e) { return { ok: false, code: e?.code }; }
}

/** Withdraw card: method → destination (saved or new) → amount → reason when above today's limit. */
export async function withdrawBox(host, { act, secure, bens, payout, onDone, T }) {
  const lim = await bankApi.limits().catch(() => null);
  const ms = [['card', L('بطاقة فيزا / ماستركارد', 'Visa / Mastercard'), L('لبطاقتك البنكية (Debit) · عن طريق Stripe', 'To your debit card · via Stripe')], ['wallet', 'Apple Pay / Google Pay', L('للبطاقة اللي بمحفظة موبايلك', 'To the card in your phone wallet')],
    ['paypal', 'PayPal', L('لحسابك بـ PayPal بالإيميل', 'To your PayPal e-mail')], ['bank', L('حوالة بنكية', 'Bank transfer'), L('لحسابك بأي بنك (IBAN)', 'To any bank account (IBAN)')], ['crypto', L('كريبتو', 'Crypto'), L('USDT · BTC لعنوان محفظتك', 'USDT · BTC to your wallet address')]];
  const kindOf = { card: 'stripe', wallet: 'stripe', paypal: 'paypal', bank: 'bank', crypto: 'crypto' };
  let on = 'card';
  const w = lim?.withdraw?.USD; const half = lim?.newAccount;
  host.innerHTML = `<div class="pm"><h2>${esc(L('سحب', 'Withdraw'))}</h2>
    ${w ? limitBar(w.left, w.limit, L('باقي إلك اليوم (دولار)', 'Left today (USD)'), half ? L(`حسابك جديد: نص الحد لحد ${new Date(lim.newAccountUntil).toLocaleDateString('ar')}، بعدها أكتر`, `New account: half the limit until ${new Date(lim.newAccountUntil).toLocaleDateString('en')}`) : L(`أقل سحب ${usd(lim.minWithdraw.USD)} · فوق الحد بدها سبب وموافقة`, `Min ${usd(lim.minWithdraw.USD)} · above the limit needs a reason and approval`)) : ''}
    <p class="pm-sub">${esc(L('لوين بدك تسحب؟', 'Where to?'))}</p>${methodList(ms, on)}<div data-dest></div>
    <form class="pm-pay" data-wdf novalidate><label class="pm-amt"><span data-cur>$</span><input name="amount" inputmode="decimal" dir="ltr" placeholder="100" aria-label="${esc(L('المبلغ', 'Amount'))}" required></label>
      <div class="pm-warn" data-over hidden></div><textarea class="pm-ta" name="reason" maxlength="500" hidden placeholder="${esc(L('ليش بدك تسحب هالمبلغ ولوين رايح؟', 'Why do you need this amount and where is it going?'))}" aria-label="${esc(L('سبب السحب', 'Reason'))}"></textarea>
      <button class="pm-go" type="submit" data-go>${esc(L('ابعت طلب السحب للمراجعة', 'Send the withdrawal for review'))}</button>
      <p class="pm-note">${icons.shield}<span>${esc(L('كل طلب سحب بيراجعه فريق البنك قبل ما ينبعت. رسوم $1.', 'The bank team reviews every withdrawal before it is sent. $1 fee.'))}</span></p></form></div>`;
  const dest = host.querySelector('[data-dest]'); const f = host.querySelector('[data-wdf]'); const over = f.querySelector('[data-over]');
  const mine = () => bens.filter((b) => b.kind === kindOf[on]);
  const paint = () => {
    pick(host, on); const list = mine();
    const pickHtml = list.length ? `<label class="pm-f">${esc(L('الوجهة', 'Destination'))}<select class="select" name="ben">${list.map((b) => `<option value="${esc(b.id)}" data-cur="${b.currency}">${esc(b.label)} · ${esc(b.currency)} …${esc(b.last4)}${b.usableAfter > Date.now() ? ` (${esc(L('جاهزة بعد 24 ساعة', 'ready in 24 h'))})` : ''}</option>`).join('')}</select></label>` : '';
    let add = '';
    if (on === 'card' || on === 'wallet') add = payout?.payoutsEnabled ? '' : `<div class="pm-add"><p>${esc(L('اربط بطاقتك البنكية عند Stripe مرة وحدة (Stripe بيتحقق منها، وإحنا ما بنشوف رقمها).', 'Link your debit card at Stripe once (Stripe checks it; we never see the number).'))}</p><form data-pa class="pm-inline"><input name="country" maxlength="2" dir="ltr" placeholder="JO" aria-label="${esc(L('بلدك', 'Your country'))}" required><button class="pm-go is-soft" type="submit">${esc(payout?.linked ? L('كمّل الربط', 'Finish linking') : L('اربط بطاقتي', 'Link my card'))}</button></form></div>`;
    else add = `<details class="pm-add"${list.length ? '' : ' open'}><summary>${esc(L('أضف وجهة جديدة', 'Add a new destination'))}</summary><form data-nb class="pm-grid">
      <input name="label" maxlength="40" placeholder="${esc(L('اسم للوجهة', 'A name for it'))}" required>
      ${on === 'paypal' ? `<select class="select" name="currency"><option>USD</option><option>EUR</option></select><input name="email" type="email" dir="ltr" placeholder="paypal@email.com" required><input name="holder" maxlength="70" placeholder="${esc(L('الاسم على الحساب', 'Account holder'))}" required>`
        : on === 'bank' ? `<select class="select" name="currency"><option>USD</option><option>EUR</option></select><input name="iban" dir="ltr" maxlength="40" placeholder="IBAN" required><input name="holder" maxlength="70" placeholder="${esc(L('الاسم على الحساب', 'Account holder'))}" required>`
        : `<select class="select" name="currency"><option>USDT</option><option>BTC</option></select><select class="select" name="network">${CURRENCIES.USDT.networks.map((n) => `<option>${esc(n)}</option>`).join('')}</select><input name="address" dir="ltr" maxlength="100" placeholder="${esc(L('عنوان المحفظة', 'Wallet address'))}" required>`}
      <button class="pm-go is-soft" type="submit">${esc(L('احفظ الوجهة', 'Save'))}</button><p class="pm-note">${esc(T('coolingNote'))}</p></form></details>`;
    dest.innerHTML = pickHtml + add; f.hidden = !list.length;
    const cur = dest.querySelector('select[name=ben]')?.selectedOptions[0]?.dataset.cur || 'USD'; f.querySelector('[data-cur]').textContent = cur === 'USD' ? '$' : cur;
    dest.querySelector('select[name=ben]')?.addEventListener('change', (e) => { const c = e.target.selectedOptions[0]?.dataset.cur || 'USD'; f.querySelector('[data-cur]').textContent = c === 'USD' ? '$' : c; check(); });
    dest.querySelector('[data-pa]')?.addEventListener('submit', async (e) => { e.preventDefault(); const r = await act(e.target.querySelector('button'), () => bankApi.startPayoutAccount(String(e.target.country.value || '').trim().toUpperCase())); if (r?.url && /^https:\/\/connect\.stripe\.com\//.test(r.url)) location.href = r.url; });
    const nb = dest.querySelector('[data-nb]');
    if (on === 'crypto') nb?.currency.addEventListener('change', () => { nb.network.innerHTML = CURRENCIES[nb.currency.value].networks.map((n) => `<option>${esc(n)}</option>`).join(''); });
    nb?.addEventListener('submit', async (e) => {
      e.preventDefault(); const v = Object.fromEntries(new FormData(e.target)); if (on === 'paypal') v.method = 'paypal';
      if (await act(e.target.querySelector('button'), () => secure('beneficiary_add', v, (passkey) => bankApi.addBeneficiary({ ...v, passkey })), T('benSaved'))) onDone();
    });
    check();
  };
  const check = () => {
    const opt = dest.querySelector('select[name=ben]')?.selectedOptions[0]; const cur = opt?.dataset.cur || 'USD'; const l = lim?.withdraw?.[cur];
    const n = Number(String(f.amount.value).replace(/,/g, '')); const minor = Number.isFinite(n) ? Math.round(n * 10 ** (CURRENCIES[cur]?.decimals ?? 2)) : 0;
    const isOver = Boolean(l && minor > l.left);
    over.hidden = !isOver; f.reason.hidden = !isOver; f.reason.required = isOver;
    if (isOver) over.textContent = L(`المبلغ أكتر من الباقي من حدّك اليومي (${fmtMinor(l.left, cur)} ${cur}). بتقدر تبعت الطلب، بس اكتب ليش بدك تسحبه، وصاحب البنك بيراجعه قبل ما ينبعت.`, `This is above what is left of your daily limit (${fmtMinor(l.left, cur)} ${cur}). You can still send it with a reason; the bank owner reviews it first.`);
  };
  host.querySelectorAll('[data-m]').forEach((b) => b.addEventListener('click', () => { on = b.dataset.m; paint(); }));
  f.amount.addEventListener('input', check);
  f.addEventListener('submit', async (e) => {
    e.preventDefault(); const opt = dest.querySelector('select[name=ben]')?.selectedOptions[0]; if (!opt || !f.amount.value.trim()) return;
    if (!f.reason.hidden && f.reason.value.trim().length < 10) { f.reason.focus(); over.textContent = L('اكتب السبب (10 أحرف على الأقل).', 'Write the reason (10+ characters).'); return; }
    const b = { beneficiaryId: opt.value, currency: opt.dataset.cur, amount: f.amount.value.trim(), ...(f.reason.hidden ? {} : { reason: f.reason.value.trim() }) };
    if (await act(f.querySelector('[data-go]'), () => secure('withdraw', b, (passkey) => bankApi.withdraw({ ...b, passkey })), T('wdRequested'))) onDone();
  });
  paint();
}
