// v382 Owner desk → account applications: pending / approved / rejected, one card per person with their details and
// document photos (opening the photos is audited on the server), approve with a confirm step (the person then gets their
// bank username + temporary password by e-mail), reject with a reason they receive, and a new temporary password on request.
import { bankApi } from '../../../services/bank/api.js';
import { tx } from '../../../i18n/tx.js';
import { icons } from '../../../components/icons.js';
import { esc } from './ui.js';

const L = (ar, en) => tx({ ar, en });
const getLangSafe = () => (document.documentElement.lang === 'en' ? 'en-GB' : 'ar');
const CHK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>';
const X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>';
const REASONS = [['الصورة مش واضحة', 'The photo is not clear'], ['الوثيقة منتهية', 'The document has expired'], ['الاسم مش مطابق للوثيقة', 'The name does not match the document'], ['السيلفي ناقص أو مش واضح', 'The selfie is missing or unclear']];
const DOC = { front: ['الوثيقة (وجه)', 'Document (front)'], back: ['الوثيقة (ظهر)', 'Document (back)'], selfie: ['سيلفي', 'Selfie'], address: ['إثبات عنوان', 'Proof of address'] };
const ID = { passport: ['جواز سفر', 'Passport'], national_id: ['هوية', 'ID card'], driving_license: ['رخصة سواقة', 'Driving licence'] };
const ago = (t) => { const m = Math.max(1, Math.round((Date.now() - t) / 60000)); return m < 60 ? L(`قبل ${m} دقيقة`, `${m} min ago`) : m < 1440 ? L(`قبل ${Math.round(m / 60)} ساعة`, `${Math.round(m / 60)} h ago`) : L(`قبل ${Math.round(m / 1440)} يوم`, `${Math.round(m / 1440)} d ago`); };
const age = (dob) => { const d = new Date(dob); return Number.isNaN(+d) ? '' : Math.floor((Date.now() - d) / 31557600000); };

export async function kycDesk(el, { act, toast }) {
  let tab = 'pending'; let open = null;
  async function load() {
    let r; try { r = await bankApi.admin.kycList(tab); } catch (e) { el.innerHTML = `<div class="dk"><p class="muted">${esc(L('ما قدرنا نجيب الطلبات.', 'Could not load the applications.'))}</p></div>`; return; }
    const c = r.counts || {}; if (tab === 'pending' && open == null && r.items[0]) open = r.items[0].uid;
    el.innerHTML = `<div class="dk"><div class="dk-head"><h2>${icons.user}<span>${esc(L('طلبات فتح الحسابات', 'Account applications'))}</span>${c.pending ? `<span class="dk-count">${c.pending}</span>` : ''}</h2></div>
      <div class="dk-tabs" role="tablist">${[['pending', 'مستنية', 'Pending'], ['approved', 'مقبولة', 'Approved'], ['rejected', 'مرفوضة', 'Rejected']].map(([k, a, e]) => `<button type="button" role="tab" aria-selected="${k === tab}" data-tab="${k}">${esc(L(a, e))} (${c[k] || 0})</button>`).join('')}</div>
      ${tab === 'pending' && r.items.length > 1 ? `<div class="dk-bulk"><label class="dk-all"><input type="checkbox" data-all> ${esc(L('اختار الكل', 'Select all'))}</label><button type="button" class="ap-yes" data-bulk disabled>${CHK}${esc(L('وافق على المختارين', 'Approve selected'))}</button></div>` : ''}
      ${r.items.length ? r.items.map(item).join('') : `<p class="muted dk-empty">${esc(tab === 'pending' ? L('ما في طلبات مستنية هلّق.', 'No pending applications.') : L('ما في شي هون لسا.', 'Nothing here yet.'))}</p>`}</div>`;
    el.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.tab; open = null; load(); }));
    el.querySelectorAll('.ap').forEach(bind);
    // v391 bulk approve: tick several applications (after checking them), confirm once, each one is approved on its own and the result counted
    const bulk = el.querySelector('[data-bulk]');
    if (bulk) {
      const picks = () => [...el.querySelectorAll('[data-pick]:checked')].map((x) => x.closest('.ap').dataset.uid);
      const sync = () => { const n = picks().length; bulk.disabled = !n; bulk.dataset.sure = ''; bulk.lastChild.textContent = n ? L(`وافق على المختارين (${n})`, `Approve selected (${n})`) : L('وافق على المختارين', 'Approve selected'); };
      el.querySelectorAll('[data-pick]').forEach((x) => x.addEventListener('change', sync));
      el.querySelector('[data-all]').addEventListener('change', (e) => { el.querySelectorAll('[data-pick]').forEach((x) => { x.checked = e.target.checked; }); sync(); });
      bulk.addEventListener('click', async () => {
        const ids = picks(); if (!ids.length) return;
        if (bulk.dataset.sure !== '1') { bulk.dataset.sure = '1'; bulk.lastChild.textContent = L(`متأكد؟ رح ينفتح ${ids.length} حساب. اكبس كمان مرة`, `Sure? ${ids.length} accounts will open. Tap again`); return; }
        bulk.disabled = true; let ok = 0, bad = 0;
        for (const uid of ids) { try { await bankApi.admin.kycReview(uid, 'approve', {}); ok++; } catch { bad++; } }
        toast(bad ? L(`انوافق على ${ok}، و${bad} ما زبطوا. افتحهم واحد واحد.`, `${ok} approved, ${bad} failed. Open those one by one.`) : L(`انوافق على ${ok} ووصلتهم معلومات الدخول.`, `${ok} approved; sign-in details sent.`), bad ? 'error' : 'success', 7000);
        open = null; load();
      });
    }
    if (open) el.querySelector(`.ap[data-uid="${CSS.escape(open)}"]`)?.querySelector('[data-open]')?.click();
  }
  function item(k) {
    const when = tab === 'pending' ? k.submitted_at : k.reviewed_at; const a = age(k.dob);
    const st = { pending: ['', 'بانتظار المراجعة', 'Waiting for review'], approved: ['ok', 'مقبول', 'Approved'], rejected: ['no', 'مرفوض', 'Rejected'] }[k.status];
    return `<div class="ap${tab === 'pending' && Date.now() - k.submitted_at < 86400000 ? ' new' : ''}" data-uid="${esc(k.uid)}">${tab === 'pending' ? `<label class="ap-pick"><input type="checkbox" data-pick aria-label="${esc(L(`اختار ${k.name || ''}`, `Select ${k.name || ''}`))}"></label>` : ''}
      <div class="ap-top"><div class="ap-av" data-av>${esc((k.name || '?').trim().charAt(0).toUpperCase())}</div><div class="ap-who"><b>${esc(k.name || '—')}</b><small>${esc(ago(when || Date.now()))}${k.email ? ` · <bdi>${esc(k.email)}</bdi>` : ''}</small></div><span class="ap-st ${st[0]}">${esc(L(st[1], st[2]))}</span></div>
      <dl class="ap-facts"><div><dt>${esc(L('رقم التلفون', 'Phone'))}</dt><dd dir="ltr">${esc(k.phone || '—')}</dd></div><div><dt>${esc(L('الجنسية / الإقامة', 'Nationality / residence'))}</dt><dd>${esc([k.nationality, k.city || k.country].filter(Boolean).join(' · ') || '—')}</dd></div>
        <div><dt>${esc(L('الوثيقة', 'Document'))}</dt><dd>${esc(ID[k.idType] ? L(...ID[k.idType]) : k.idType || '—')} · <bdi dir="ltr">${esc(k.idNumber || '')}</bdi></dd></div><div><dt>${esc(L('تاريخ الميلاد', 'Date of birth'))}</dt><dd><bdi dir="ltr">${esc(k.dob || '—')}</bdi>${a ? ` <span class="${a < 21 ? 'ap-age' : ''}">(${a}${a < 21 ? L(' · انتبه للعمر، قارنه مع الوثيقة', ' · check the age against the document') : ''})</span>` : ''}</dd></div></dl>
      ${tab === 'pending' && Date.now() - k.submitted_at > 86400000 ? `<div class="ap-confirm is-warn">${esc(L('⏰ مستني أكتر من يوم. بيوصلك تذكير كل يوم لحد ما ترد.', '⏰ Waiting over a day. You get a daily reminder until you answer.'))}</div>` : ''}
      ${tab !== 'pending' && k.reviewed_at ? `<p class="ap-why ${tab === 'approved' ? 'ok' : ''}">${esc(tab === 'approved' ? L('وافق عليه:', 'Approved by:') : L('رفضه:', 'Rejected by:'))} <bdi dir="ltr">${esc(k.reviewer || '—')}</bdi> · <bdi dir="ltr">${esc(new Date(k.reviewed_at).toLocaleString(getLangSafe()))}</bdi></p>` : ''}
      ${tab === 'rejected' && k.reason ? `<p class="ap-why">${esc(L('السبب:', 'Reason:'))} ${esc(k.reason)}</p>` : ''}
      ${tab === 'approved' ? `<p class="ap-why ok">${esc(k.login?.required ? (k.login.mustChange ? L(`اسم المستخدم ${k.login.username} · لسا ما حط كلمة سره`, `Username ${k.login.username} · has not set a password yet`) : L(`اسم المستخدم ${k.login.username} · عنده كلمة سر`, `Username ${k.login.username} · password set`)) : L('انفتح قبل نظام كلمات السر', 'Opened before bank passwords'))}</p>` : ''}
      <div class="ap-body" hidden></div>
      <div class="ap-act">${tab === 'pending' ? `<button type="button" class="ap-yes" data-do="approve">${CHK}${esc(L('موافقة', 'Approve'))}</button><button type="button" class="ap-no" data-do="reject">${X}${esc(L('رفض', 'Reject'))}</button>`
        : tab === 'approved' && k.login?.required ? `<button type="button" class="ap-soft" data-do="reset">${esc(L('ابعت كلمة سر مؤقتة جديدة', 'Send a new temporary password'))}</button>` : ''}</div>
      <button type="button" class="ap-more" data-open>${esc(L('افتح الصور', 'Open the photos'))}</button></div>`;
  }
  function bind(card) {
    const uid = card.dataset.uid; const body = card.querySelector('.ap-body'); const acts = card.querySelector('.ap-act');
    card.querySelector('[data-open]').addEventListener('click', async (e) => {
      const b = e.currentTarget; if (!body.hidden && body.dataset.docs) { body.hidden = true; b.textContent = L('افتح الصور', 'Open the photos'); return; }
      b.disabled = true; let docs = { items: [] }; try { docs = await bankApi.admin.kycDocs(uid); } catch { /* shown as «no photos» */ } b.disabled = false;
      body.dataset.docs = '1'; body.hidden = false; b.textContent = L('سكّر الصور', 'Hide the photos');
      body.innerHTML = docs.items.length ? `<div class="ap-docs">${docs.items.map((x) => `<button type="button" class="ap-doc" data-big="${esc(x.url)}"><img src="${esc(x.url)}" alt="${esc(L(...(DOC[x.kind] || [x.kind, x.kind])))}"><span>${esc(L(...(DOC[x.kind] || [x.kind, x.kind])))}</span></button>`).join('')}</div>` : `<p class="muted">${esc(L('ما في صور بهالطلب.', 'No photos in this application.'))}</p>`;
      const self = docs.items.find((x) => x.kind === 'selfie'); if (self) card.querySelector('[data-av]').innerHTML = `<img src="${esc(self.url)}" alt="">`;
      body.querySelectorAll('[data-big]').forEach((d) => d.addEventListener('click', () => lightbox(d.dataset.big)));
    });
    acts.addEventListener('click', (e) => {
      const b = e.target.closest('[data-do]'); if (!b) return; const name = card.querySelector('.ap-who b').textContent;
      if (b.dataset.do === 'approve') confirmBox(card, `<b>${esc(L('متأكد بدك توافق؟', 'Approve this application?'))}</b><br>${esc(L(`رح ينفتح حساب ${name} بالبنك، وبيوصله إيميل فيه اسم المستخدم وكلمة سر مؤقتة بتنتهي بعد 24 ساعة، ولازم يغيّرها أول ما يفوت.`, `${name}'s bank account opens and they get an e-mail with a username and a temporary password valid for 24 hours, to change at first sign-in.`))}`,
        L('أكّد الموافقة', 'Confirm approval'), 'ap-yes', async (btn) => {
          const r = await act(btn, () => bankApi.admin.kycReview(uid, 'approve', {})); if (!r) return;
          toast(r.credentialsSent ? L('تم. انفتح الحساب وانبعتله اسم المستخدم وكلمة السر المؤقتة.', 'Done. The account is open and the sign-in details were e-mailed.') : L('تم. انفتح الحساب (خدمة الإيميل مش شغّالة، فما في كلمة سر للبنك).', 'Done. The account is open (no e-mail service, so no bank password).'), 'success'); open = null; load();
        });
      if (b.dataset.do === 'reject') confirmBox(card, `<b class="bad">${esc(L('سبب الرفض (بيوصله بالإيميل)', 'Reason (e-mailed to them)'))}</b><div class="ap-chips">${REASONS.map((x) => `<button type="button" data-r="${esc(L(...x))}">${esc(L(...x))}</button>`).join('')}</div><textarea maxlength="200" aria-label="${esc(L('سبب الرفض', 'Reason'))}"></textarea>`,
        L('أكّد الرفض', 'Confirm rejection'), 'ap-no is-solid', async (btn, box) => {
          const why = box.querySelector('textarea').value.trim(); if (why.length < 3) { toast(L('اكتب سبب الرفض، بيوصل للشخص بالإيميل.', 'Write the reason; it is e-mailed to the person.'), 'error'); return; }
          if (await act(btn, () => bankApi.admin.kycReview(uid, 'reject', { reason: why }), L('تم الرفض وانبعت السبب.', 'Rejected; the reason was sent.'))) { open = null; load(); }
        }, (box) => box.querySelectorAll('[data-r]').forEach((c) => c.addEventListener('click', () => { box.querySelector('textarea').value = c.dataset.r; })));
      if (b.dataset.do === 'reset') confirmBox(card, `<b>${esc(L('نبعت كلمة سر مؤقتة جديدة؟', 'Send a new temporary password?'))}</b><br>${esc(L('القديمة بتوقف، وبيوصله إيميل بكلمة مؤقتة جديدة لـ 24 ساعة.', 'The old one stops working and a new 24-hour one is e-mailed.'))}`,
        L('ابعت', 'Send'), 'ap-yes', async (btn) => { if (await act(btn, () => bankApi.admin.kycReset(uid), L('انبعتت كلمة سر مؤقتة جديدة.', 'A new temporary password was sent.'))) load(); });
    });
  }
  function confirmBox(card, html, label, cls, onOk, setup) {
    const acts = card.querySelector('.ap-act'); const keep = acts.innerHTML; const box = document.createElement('div'); box.className = 'ap-confirm'; box.innerHTML = html;
    acts.before(box); setup?.(box);
    acts.innerHTML = `<button type="button" class="${cls}" data-ok>${label === L('أكّد الرفض', 'Confirm rejection') ? X : CHK}${esc(label)}</button><button type="button" class="ap-soft" data-cancel>${esc(L('إلغاء', 'Cancel'))}</button>`;
    const reset = () => { box.remove(); acts.innerHTML = keep; };
    acts.querySelector('[data-cancel]').addEventListener('click', (e) => { e.stopPropagation(); reset(); });
    acts.querySelector('[data-ok]').addEventListener('click', (e) => { e.stopPropagation(); onOk(e.currentTarget, box); });
    box.querySelector('textarea')?.focus();
  }
  function lightbox(url) {
    const d = document.createElement('div'); d.className = 'ap-lb'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-modal', 'true');
    d.innerHTML = `<img src="${esc(url)}" alt=""><button type="button" aria-label="${esc(L('سكّر', 'Close'))}">${X}</button>`;
    const close = () => { d.remove(); document.removeEventListener('keydown', key); }; const key = (e) => { if (e.key === 'Escape') close(); };
    d.addEventListener('click', close); document.addEventListener('keydown', key); document.body.append(d);
  }
  await load();
}
