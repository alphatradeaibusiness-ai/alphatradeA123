// v379 opening a bank account: before the bank itself, a person fills in who they are, their phone and address, and sends a
// photo of their passport / ID (both sides for an ID card or licence) and a selfie. The team reviews it in the owner desk;
// the bank opens when it is approved. The same form is the bank's «Identity» tab. Photos are shrunk in the browser first.
import { icons } from '../../../components/icons.js';
import { getLang } from '../../../i18n/index.js';
import { bankApi } from '../../../services/bank/api.js';
import { auth } from '../../../services/auth/index.js';
import { codeStep } from '../../../components/codeStep.js';
import { T, esc, opts, field, input, fd } from './ui.js';
import '../../../styles/bankOverview.css';

const L = (ar, en) => (getLang() === 'ar' ? ar : en);

/** A photo → JPEG data URL, longest side ≤ 1600 px (a phone photo of 4–8 MB becomes ~300 KB). */
export async function shrinkPhoto(file, max = 1600) {
  if (!file || !/^image\//.test(file.type)) throw Object.assign(new Error('x'), { code: 'bad_doc_front' });
  const img = await createImageBitmap(file); const k = Math.min(1, max / Math.max(img.width, img.height));
  const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
  c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); img.close?.();
  return c.toDataURL('image/jpeg', 0.85);
}

const photo = (name, label, hint, capture = 'environment') => `<label class="kyc-photo" data-photo="${name}"><input type="file" accept="image/*" capture="${capture}" name="${name}" hidden/>
  <span class="kyc-ph-ic">${icons.camera || icons.plus}</span><b>${esc(label)}</b><small>${esc(hint)}</small><img alt="" hidden/></label>`;

/** The application form (tier 1 with photos, or tier 2 extras when `tier2` is allowed). */
export function kycFormHtml({ tier2 = false } = {}) {
  const addr = `${field(T('country'), input('a_country', { max: 2, ph: 'JO', req: true }))}${field(T('city'), input('a_city', { max: 60, req: true }))}${field(T('region'), input('a_region', { max: 60 }))}${field(T('postal'), input('a_postal', { max: 12, req: true }))}${field(T('line1'), input('a_line1', { max: 80, req: true }), true)}`;
  return `<form class="bank-form kyc-form" data-kyc>
    ${tier2 ? field(T('targetTier'), `<select class="select" name="tier"><option value="1">${esc(T('tier1'))}</option><option value="2">${esc(T('tier2'))}</option></select>`) : '<input type="hidden" name="tier" value="1"/>'}
    <h3 class="bank-h">${esc(L('1. معلوماتك', '1. About you'))}</h3>
    ${field(T('fullName'), input('fullName', { max: 80, req: true, ph: L('متل ما هو بالجواز', 'As on the passport') }))}${field(T('dob'), input('dob', { type: 'date', req: true }))}${field(T('nationality'), input('nationality', { max: 2, ph: 'JO', req: true }))}
    ${field(L('رقم الموبايل', 'Mobile number'), input('phone', { type: 'tel', ph: '+962791234567', max: 16, req: true, dir: 'ltr', mode: 'tel' }))}
    <h3 class="bank-h">${esc(L('2. عنوانك', '2. Your address'))}</h3>${addr}
    <h3 class="bank-h">${esc(L('3. الوثيقة', '3. Your document'))}</h3>
    ${field(T('idType'), `<select class="select" name="idType">${opts(['passport', 'national_id', 'driver_license'], 'passport', (x) => T(`idt.${x}`))}</select>`)}${field(T('idNumber'), input('idNumber', { max: 30, req: true, dir: 'ltr' }))}${field(T('idExpiry'), input('idExpiry', { type: 'date', req: true }))}
    <div class="kyc-photos tf-wide">${photo('front', L('صورة الوثيقة', 'Document photo'), L('الصفحة اللي فيها صورتك، واضحة وكاملة', 'The page with your photo, clear and whole'))}
      <span data-backwrap hidden>${photo('back', L('الوجه الخلفي', 'Back side'), L('للهوية أو الرخصة', 'For an ID card or licence'))}</span>
      ${photo('selfie', L('سيلفي', 'Selfie'), L('وجهك واضح، بدون نظارة شمسية', 'Your face, clear, no sunglasses'), 'user')}</div>
    <span data-t2 hidden class="bank-sub"><h3 class="bank-h">${esc(T('tier2Extra'))}</h3>${field(T('sourceOfFunds'), `<select class="select" name="sourceOfFunds">${opts(['salary', 'business', 'savings', 'investments', 'other'], 'salary', (x) => T(`sof.${x}`))}</select>`)}${field(T('proofRef'), input('proofOfAddressRef', { max: 80 }))}</span>
    <label class="bank-check tf-wide"><input type="checkbox" required/> ${esc(L('أأكد إنه المعلومات صحيحة وإنه الوثيقة إلي، وبوافق إنها تنحفظ مشفّرة للمراجعة.', 'I confirm the details are true and the document is mine, and I agree it is kept encrypted for review.'))}</label>
    <button class="btn btn-primary tf-wide" type="submit">${icons.check}<span>${esc(T('submitKyc'))}</span></button></form>`;
}

/** Wires the form: photo previews, the back side for ID cards, shrinking, and the submit. */
export function bindKycForm(f, act, onDone) {
  const docs = {};
  const sync = () => { const t2 = f.tier.value === '2'; f.querySelector('[data-t2]').hidden = !t2; f.querySelector('[data-backwrap]').hidden = f.idType.value === 'passport'; };
  f.idType.addEventListener('change', sync); f.tier.addEventListener?.('change', sync); sync();
  f.querySelectorAll('[data-photo] input').forEach((inp) => inp.addEventListener('change', async () => {
    const box = inp.closest('[data-photo]'); const file = inp.files?.[0]; if (!file) return;
    try { docs[inp.name] = await shrinkPhoto(file); const im = box.querySelector('img'); im.src = docs[inp.name]; im.hidden = false; box.classList.add('is-set'); }
    catch { delete docs[inp.name]; box.classList.remove('is-set'); }
  }));
  f.addEventListener('submit', async (e) => {
    e.preventDefault(); const v = fd(f); const t2 = v.tier === '2';
    const payload = { tier: Number(v.tier), fullName: v.fullName, dob: v.dob, nationality: String(v.nationality || '').toUpperCase(), phone: String(v.phone || '').replace(/[\s-]/g, ''),
      address: { country: String(v.a_country || '').toUpperCase(), region: v.a_region || '-', city: v.a_city, postal: v.a_postal, line1: v.a_line1 },
      idType: v.idType, idNumber: v.idNumber, idExpiry: v.idExpiry,
      ...(t2 ? { sourceOfFunds: v.sourceOfFunds, proofOfAddressRef: v.proofOfAddressRef } : { docs: { front: docs.front, back: v.idType === 'passport' ? undefined : docs.back, selfie: docs.selfie } }) };
    const btn = f.querySelector('[type=submit]'); const okMsg = L('انبعت طلبك للمراجعة، وبيوصلك إيميل.', 'Sent for review. You will get an e-mail.');
    // v381 last step: a code to the person's e-mail, in the same card. No e-mail service on the server → straight to review.
    let first; btn.disabled = true;
    try { first = await bankApi.kycCode(getLang()); } catch (x) { first = x?.code === 'too_soon' ? { retryInS: 60 } : { err: x }; } finally { btn.disabled = false; }
    if (first.skip) { if (await act(btn, () => bankApi.submitKyc(payload), okMsg)) onDone?.(); return; }
    if (first.err) { await act(btn, () => Promise.reject(first.err)); return; }
    const host = document.createElement('div'); host.className = 'card cs-card cs-host'; const back = () => { host.remove(); f.hidden = false; f.scrollIntoView({ block: 'center' }); };
    f.hidden = true; f.after(host); host.scrollIntoView({ block: 'start' }); window.scrollBy?.(0, -80);
    const photos = ['front', 'back', 'selfie'].filter((k) => payload.docs?.[k]).length;
    codeStep(host, {
      email: auth.current()?.email || '', title: L('آخر خطوة: أكّد إيميلك', 'Last step: confirm your e-mail'),
      sub: L('طلبك جاهز. بعتنالك رمز من 6 أرقام على إيميلك، ولما تكتبه بينبعت الطلب للمراجعة.', 'Your application is ready. We sent a 6-digit code to your e-mail; enter it to send the application for review.'),
      goLabel: L('تأكيد وإرسال الطلب', 'Confirm and send'), doneTitle: L('انبعت طلبك للمراجعة', 'Sent for review'), doneSub: L('بيوصلك إيميل أول ما ننتهي.', 'You will get an e-mail when we finish.'),
      backLabel: L('رجوع للطلب', 'Back to the form'), onBack: back, firstWait: first.retryInS || 60,
      extraHtml: `<div class="cs-sum">${icons.card || icons.user}<span><b>${esc(L('بطلبك:', 'Your application:'))}</b> ${esc(payload.fullName || '')} · <bdi dir="ltr">${esc(payload.phone || '')}</bdi> · ${esc(T(`idt.${payload.idType}`))}${photos ? ` · ${esc(L(`${photos} صور`, `${photos} photos`))}` : ''}. ${esc(L('كله مشفّر.', 'All encrypted.'))}</span></div>`,
      send: () => bankApi.kycCode(getLang()),
      check: async (emailCode) => {
        try { await bankApi.submitKyc({ ...payload, emailCode }); }
        catch (x) { if (['wrong_code', 'expired', 'too_many_tries', 'email_code_required'].includes(x?.code)) throw x; back(); await act(btn, () => Promise.reject(x)); throw Object.assign(new Error('form'), { code: 'form' }); }
      },
      onDone: async () => { await act(null, async () => true, okMsg); onDone?.(); },
    });
  });
}

/** The screen before the bank: apply → under review → (approved) the bank opens; rejected → the reason and apply again. */
export function onboardingGate(body, B, onApproved) {
  const k = B.st.wallet.kyc || { status: 'none', tier: 0 };
  const head = `<header class="kyc-head"><span class="bov-logo" aria-hidden="true">G</span><div><h2>${esc(L('افتح حسابك بالبنك الرقمي', 'Open your digital bank account'))}</h2>
    <p>${esc(L('قبل ما يفتح البنك، لازم نتأكد من هويتك. بتاخد 3 دقايق: معلوماتك، عنوانك، صورة جواز السفر أو الهوية، وسيلفي.', 'Before the bank opens we verify who you are. It takes 3 minutes: your details, your address, a photo of your passport or ID, and a selfie.'))}</p></div></header>`;
  const steps = `<ol class="kyc-steps"><li class="is-on">${esc(L('الطلب', 'Apply'))}</li><li class="${k.status === 'pending' ? 'is-on' : ''}">${esc(L('المراجعة', 'Review'))}</li><li>${esc(L('الحساب مفتوح', 'Account open'))}</li></ol>`;
  if (k.status === 'pending') {
    body.innerHTML = `<div class="bov kyc-gate">${head}${steps}<div class="kyc-wait">${icons.shield}<div><b>${esc(L('طلبك عند فريقنا للمراجعة', 'Your application is with our team'))}</b>
      <p>${esc(L('بيوصلك إيميل وإشعار أول ما ننتهي. عادة خلال يوم عمل.', 'You will get an e-mail and a notification as soon as we finish, usually within one working day.'))}</p>
      <button type="button" class="bov-btn" data-recheck>${icons.refresh}<span>${esc(L('شيّك على الحالة', 'Check status'))}</span></button></div></div></div>`;
    body.querySelector('[data-recheck]').addEventListener('click', onApproved);
    return;
  }
  body.innerHTML = `<div class="bov kyc-gate">${head}${steps}
    ${k.status === 'rejected' ? `<div class="bov-banner is-bad">${icons.alert || icons.info}<span>${esc(L(`الطلب السابق ما انقبل: ${k.reason || '—'}. صلّح وابعت من جديد.`, `Your last application was not approved: ${k.reason || '—'}. Fix it and send again.`))}</span></div>` : ''}
    <div class="bov-legacy">${kycFormHtml()}</div>
    <p class="bov-note">${esc(L('المعلومات والصور بتنحفظ مشفّرة على سيرفرنا وبيشوفها بس فريق المراجعة، وكل مرة حدا بيفتحها بتنسجل. ما بنشاركها مع حدا.', 'Details and photos are kept encrypted on our server, seen only by the review team, and every view is logged. We do not share them.'))}</p></div>`;
  bindKycForm(body.querySelector('[data-kyc]'), B.act, onApproved);
}
