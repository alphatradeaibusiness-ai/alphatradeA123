// v369 bank "Overview" tab — the owner's reference dashboard (greeting, card stack you can throw aside or flip, balance with
// range chips and a line chart, money in & out bars with a sliding pill), rebuilt for GOTRIVA in vanilla JS.
// Every number comes from the bank API: wallet, 12-month dashboard, virtual cards, budgets. Nothing is made up:
// a piece without data shows an empty state instead.
import { icons } from '../../../components/icons.js';
import { auth } from '../../../services/auth/index.js';
import { bankApi } from '../../../services/bank/api.js';
import { showStripeCard } from '../../../services/bank/stripeCard.js';
import { getLang, getLocale } from '../../../i18n/index.js';
import { esc, fmtMinor } from './ui.js';
import { pctChange } from './stats.js';
import '../../../styles/bankOverview.css';

const L = (ar, en) => (getLang() === 'ar' ? ar : en);
const usd = (v, d = 2) => `$${Number(v || 0).toLocaleString('en-US', { maximumFractionDigits: d, minimumFractionDigits: d })}`;
const usdK = (v) => (Math.abs(v) >= 1000 ? `$${(v / 1000).toFixed(v >= 10000 ? 0 : 1)}k` : `$${Math.round(v)}`);
const iso = (s) => `⁦${s}⁩`;
const reduced = () => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; } };

/* ── the sliding pill (same idea as the reference's slidePill: the leading edge moves first, the trailing edge catches up) ── */
function tween(from, to, ms, onUpdate) {
  if (reduced()) { onUpdate(to); return; }
  const t0 = performance.now(); const ease = (x) => 1 - Math.pow(1 - x, 3);
  const step = (t) => { const k = Math.min(1, (t - t0) / ms); onUpdate(from + (to - from) * ease(k)); if (k < 1) requestAnimationFrame(step); };
  requestAnimationFrame(step);
}
export function slidePill(pill, target) {
  const box = pill.parentElement;
  const to = { l: target.offsetLeft, t: target.offsetTop, r: box.offsetWidth - (target.offsetLeft + target.offsetWidth), b: box.offsetHeight - (target.offsetTop + target.offsetHeight) };
  const st = pill.__st || (pill.__st = { ...to });
  const paint = () => { pill.style.clipPath = `inset(${st.t}px ${st.r}px ${st.b}px ${st.l}px round 10px)`; };
  const horizontal = Math.abs(to.l - st.l) > Math.abs(to.t - st.t);
  const fwd = horizontal ? to.l > st.l : to.t > st.t;
  const [lead, trail] = horizontal ? (fwd ? ['r', 'l'] : ['l', 'r']) : (fwd ? ['b', 't'] : ['t', 'b']);
  for (const k of ['l', 'r', 't', 'b']) if (k !== lead && k !== trail) st[k] = to[k];
  tween(st[lead], to[lead], 360, (v) => { st[lead] = v; paint(); });
  tween(st[trail], to[trail], 550, (v) => { st[trail] = v; paint(); });
  paint();
}

/* ── card art ── */
const CHIP = '<svg viewBox="0 0 40 30" class="bov-chip" aria-hidden="true"><rect x="1" y="1" width="38" height="28" rx="6"/><path d="M1 10h12M1 20h12M27 10h12M27 20h12M13 1v28M27 1v28M13 15h14"/></svg>';
const WAVES = '<svg viewBox="0 0 24 24" class="bov-nfc" aria-hidden="true"><path d="M8 8.5a5 5 0 0 1 0 7M11.5 6a9 9 0 0 1 0 12M15 3.5a13 13 0 0 1 0 17"/></svg>';
const MARK = '<svg viewBox="0 0 40 28" class="bov-mark" aria-hidden="true"><path d="M8 26 18 2h6L14 26zM20 26 30 2h6L26 26z"/></svg>';
function cardFace(c, i) {
  const frozen = c.status === 'frozen';
  return `<div class="bov-card${frozen ? ' is-frozen' : ''}" data-ci="${i}" tabindex="0" role="button" aria-label="${esc(L('بطاقة', 'Card'))} ${esc(c.last4 || '')}">
    <div class="bov-card-in">
      <div class="bov-face bov-front">
        <div class="bov-row"><span class="bov-brandf" dir="ltr">GOTRIVA <i>TRADE AI</i></span>${WAVES}</div>
        <div class="bov-row bov-row2">${CHIP}<span class="bov-label">${esc(c.label || L('يومي', 'Everyday'))}</span></div>
        <div class="bov-num" dir="ltr">•••• &nbsp;•••• &nbsp;•••• &nbsp;<b>${esc(c.last4 || '••••')}</b></div>
        <div class="bov-row bov-meta"><div><small>${esc(L('حامل البطاقة', 'Holder'))}</small><span dir="auto">${esc(c.holder || '—')}</span></div><div><small>${esc(L('الانتهاء', 'Exp'))}</small><span dir="ltr">${esc(c.exp || '—')}</span></div>${MARK}</div>
        ${frozen ? `<span class="bov-frozen">${icons.lock}${esc(L('مجمّدة', 'Frozen'))}</span>` : ''}
      </div>
      <div class="bov-face bov-back">
        <div class="bov-stripe"></div>
        <div class="bov-sign"><span></span><b dir="ltr">CVV •••</b></div>
        <div class="bov-brand">GOTRIVA TRADE AI</div>
        <small class="bov-back-note">${esc(L('الأرقام الكاملة بتبيّن بس من تبويب البطاقات، بعد التحقق.', 'Full details only show in the Cards tab, after verification.'))}</small>
      </div>
    </div>
  </div>`;
}

/* ── charts ── */
function lineChart(points) {   // points: [{ label, v }] running balance at each month end
  if (points.length < 2) return `<p class="bov-empty">${esc(L('لسا ما في حركة كافية لرسم الخط.', 'Not enough history to draw the line yet.'))}</p>`;
  const W = 640, H = 170, P = 10; const vs = points.map((p) => p.v); const lo = Math.min(...vs), hi = Math.max(...vs); const span = hi - lo || 1;
  const x = (i) => P + (i / (points.length - 1)) * (W - 2 * P); const y = (v) => H - 22 - ((v - lo) / span) * (H - 44);
  const d = points.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.v).toFixed(1)}`).join('');
  const last = points.length - 1;
  return `<svg class="bov-line" viewBox="0 0 ${W} ${H}" dir="ltr" role="img" aria-label="${esc(L('الرصيد آخر 12 شهر', 'Balance over 12 months'))}">
    <defs><linearGradient id="bovFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="var(--bov-acc)" stop-opacity=".28"/><stop offset="1" stop-color="var(--bov-acc)" stop-opacity="0"/></linearGradient></defs>
    <path d="${d}L${x(last)},${H - 22}L${x(0)},${H - 22}Z" fill="url(#bovFill)"/>
    <path d="${d}" class="bov-line-path"/>
    <line x1="${x(last)}" x2="${x(last)}" y1="14" y2="${H - 22}" class="bov-today"/><text x="${x(last) - 8}" y="11" text-anchor="end" direction="ltr" class="bov-tag">${esc(L('اليوم', 'Today'))}</text>
    <circle cx="${x(last)}" cy="${y(points[last].v)}" r="4.5" class="bov-dot"/>
    ${points.map((p, i) => (i % 2 === last % 2 ? `<text x="${x(i)}" y="${H - 4}" text-anchor="${i === last ? 'end' : i === 0 ? 'start' : 'middle'}" class="bov-ax">${esc(p.label)}</text>` : '')).join('')}
  </svg>`;
}
function barChart(rows) {
  if (!rows.length) return '';
  const W = 640, H = 170, P = 26; const max = Math.max(1, ...rows.map((r) => Math.max(r.inUsd, r.outUsd)));
  const bw = (W - P - 6) / rows.length; const y = (v) => H - 20 - (v / max) * (H - 34);
  const ticks = [max, max / 2].map((v) => `<text x="0" y="${y(v) + 3}" class="bov-ax">${esc(usdK(v))}</text><line x1="${P}" x2="${W}" y1="${y(v)}" y2="${y(v)}" class="bov-grid"/>`).join('');
  return `<svg class="bov-bars" viewBox="0 0 ${W} ${H}" dir="ltr" role="img" aria-label="${esc(L('الدخل والمصاريف', 'Money in and out'))}">${ticks}
    ${rows.map((r, i) => { const x0 = P + i * bw + bw * 0.18; const w = bw * 0.3;
      return `<rect x="${x0}" y="${y(r.inUsd)}" width="${w}" height="${Math.max(1, H - 20 - y(r.inUsd))}" rx="3" class="bov-in"><title>${esc(r.month)} · ${esc(L('دخل', 'In'))} ${esc(usd(r.inUsd))}</title></rect>
        <rect x="${x0 + w + 2}" y="${y(r.outUsd)}" width="${w}" height="${Math.max(1, H - 20 - y(r.outUsd))}" rx="3" class="bov-out"><title>${esc(r.month)} · ${esc(L('مصاريف', 'Out'))} ${esc(usd(r.outUsd))}</title></rect>
        ${rows.length > 6 && (rows.length - 1 - i) % 2 ? '' : `<text x="${x0 + w}" y="${H - 5}" text-anchor="middle" class="bov-ax">${esc(monthShort(r.month))}</text>`}`; }).join('')}</svg>`;
}
const monthShort = (ym) => { try { return new Date(`${ym}-01T00:00:00Z`).toLocaleDateString(getLocale(), { month: 'short', timeZone: 'UTC' }); } catch { return ym.slice(5); } };

/* ── the bank app inside the wallet tab: sidebar + top bar + Overview / Cards / Insights ── */
/* v370 the whole bank lives in this green shell. Each side item opens one section; every old tab's content renders inside
   the section (under the dashboard for Overview / Cards / Insights). [id, icon, [ar, en], old tab it shows]. */
const NAV = [
  ['overview', 'grid', ['نظرة عامة', 'Overview'], 'wallet'], ['cards', 'card', ['البطاقات', 'Cards'], 'cards'],
  ['deposit', 'download', ['إيداع', 'Add money'], 'deposit'], ['payments', 'swap', ['الدفعات والسحب', 'Payments'], 'withdraw'], ['documents', 'journal', ['الفواتير والإيصالات', 'Invoices & receipts'], 'documents'],
  ['insights', 'bars', ['التحليلات', 'Insights'], 'insights'], ['budgets', 'piggy', ['الميزانيات', 'Budgets'], 'money'],
  ['invest', 'trend', ['الاستثمار', 'Invest'], 'invest'], ['rewards', 'gift', ['المكافآت', 'Rewards'], 'rewards'],
  0, ['security', 'shield', ['الأمان والعيلة', 'Security & household'], 'security'], ['identity', 'user', ['الهوية', 'Identity'], 'identity'],
  ['help', 'info', ['المساعدة', 'Help'], 'support'], ['admin', 'crown', ['مكتب المالك', 'Owner desk'], 'admin'],
];
const SUB = {
  deposit: ['عبّي محفظتك بالبطاقة أو بتحويل بنكي أو كريبتو', 'Top up by card, bank transfer or crypto'],
  payments: ['اسحب لحسابك البنكي ببلدك، المستفيدين، والتحويل الدولي', 'Withdraw to your own bank, beneficiaries and international transfers'],
  documents: ['كل عملية إلها إيصال، والرسوم إلها فاتورة', 'A receipt for every movement, an invoice for every fee'],
  budgets: ['الميزانيات، الاشتراكات، وقواعد الادخار', 'Budgets, subscriptions and saving rules'],
  invest: ['الخطط، البيع، وتقرير الضريبة', 'Plans, selling and the tax report'],
  rewards: ['الكاش باك والمكافآت', 'Cashback and rewards'],
  security: ['مفاتيح الدخول، التجميد، الموقّعين المشاركين والإشعارات', 'Passkeys, freeze, co-signers and notifications'],
  identity: ['تحقق الهوية (KYC) وحدود حسابك', 'Identity check (KYC) and your limits'],
  help: ['تذاكر الدعم', 'Support tickets'], admin: ['طلبات السحب والإيداع والامتثال', 'Withdrawals, deposits and compliance'],
  notifications: ['إشعارات البنك', 'Bank notifications'],
};
const NAV_OF = Object.fromEntries(NAV.filter(Boolean).map((n) => [n[3], n[0]]));
const csvCell = (v) => { const s = String(v ?? ''); const safe = /^[=+\-@\t\r]/.test(s) && !/^-?\d/.test(s) ? `'${s}` : s; return `"${safe.replace(/"/g, '""')}"`; };   // no spreadsheet formulas

/** Draws the shell into `root` and takes over B.go. `paintLegacy()` renders the old tab `B.st.tab` into `[data-pane]`. */
export function mountBank(root, B, paintLegacy, extra = {}) {
  const { st } = B;
  const user = auth.current() || {}; const name = String(user.name || '').trim(); const first = name.split(/\s+/)[0] || '';
  const initials = (name.split(/\s+/).map((w) => w[0]).join('').slice(0, 2) || (user.email || '?')[0]).toUpperCase();
  const nav0 = NAV.filter((n) => n && (n[0] !== 'admin' || st.owner));
  st.bovView = st.bovView && (st.bovView === 'notifications' || nav0.some((n) => n[0] === st.bovView)) ? st.bovView : 'overview';
  root.innerHTML = `<div class="bov bov-app">
    <aside class="bov-side">
      <div class="bov-brandrow"><span class="bov-logo" aria-hidden="true">G</span><div><b>GOTRIVA</b><small>${esc(L('البنك الرقمي', 'Digital bank'))}</small></div></div>
      <nav class="bov-nav" aria-label="${esc(L('أقسام البنك', 'Bank sections'))}"><span class="bov-navpill" aria-hidden="true"></span>
        ${NAV.filter((n) => n === 0 || nav0.includes(n)).map((n) => (n === 0 ? '<hr>' : `<button type="button" data-nav="${n[0]}">${icons[n[1]] || ''}<span>${esc(L(...n[2]))}</span><em hidden data-badge="${n[0]}"></em></button>`)).join('')}
      </nav>
      <div data-safe></div>
      <div class="bov-me"><span class="bov-av">${esc(initials)}</span><div><b dir="auto">${esc(name || L('حسابي', 'My account'))}</b><small dir="ltr">${esc(user.email || '')}</small></div></div>
    </aside>
    <div class="bov-main">
      <div class="bov-top">
        <label class="bov-search">${icons.search}<input type="search" data-search placeholder="${esc(L('دوّر بالدفعات والصفحات…', 'Search payments, pages…'))}" autocomplete="off"><kbd>/</kbd><div class="bov-sres" data-sres hidden></div></label>
        <button type="button" class="bov-ib is-acc" data-go="deposit" title="${esc(L('أضف مصاري', 'Add money'))}" aria-label="${esc(L('أضف مصاري', 'Add money'))}">${icons.plus}</button>
        <button type="button" class="bov-ib" data-go="withdraw" title="${esc(L('حوّل', 'Send'))}" aria-label="${esc(L('حوّل', 'Send'))}">${icons.send}</button>
        <span class="bov-sep"></span>
        ${extra.mic ? `<button type="button" class="bov-ib" data-mic title="${esc(extra.micTitle || '')}" aria-label="${esc(extra.micTitle || '')}">${icons.mic}</button>` : ''}
        <button type="button" class="bov-ib" data-theme title="${esc(L('الثيم', 'Theme'))}" aria-label="${esc(L('الثيم', 'Theme'))}">${icons.sun}</button>
        <button type="button" class="bov-ib" data-go="notifications" title="${esc(L('الإشعارات', 'Notifications'))}" aria-label="${esc(L('الإشعارات', 'Notifications'))}">${icons.bell}<b class="bov-unread" data-unread hidden></b></button>
        <button type="button" class="bov-av is-btn" data-go="identity" title="${esc(L('هويتي', 'Identity'))}">${esc(initials)}</button>
      </div>
      ${extra.banner || ''}
      <p class="bov-voice" data-voice hidden aria-live="polite"></p>
      <div data-view></div>
    </div>
  </div>`;
  const nav = root.querySelector('.bov-nav'); const pill = nav.querySelector('.bov-navpill'); const view = root.querySelector('[data-view]');
  let seq = 0;
  const show = async (v, opts = {}) => {
    const my = ++seq; const n = NAV.find((x) => x && x[0] === v);
    st.bovView = v; st.tab = n ? n[3] : v;
    nav.querySelectorAll('[data-nav]').forEach((b) => { const on = b.dataset.nav === v; b.classList.toggle('is-on', on); if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
    const on = nav.querySelector(`[data-nav="${v}"]`); if (on) { slidePill(pill, on); if (opts.user) on.scrollIntoView?.({ block: 'nearest', inline: 'nearest', behavior: reduced() ? 'auto' : 'smooth' }); } else pill.style.clipPath = 'inset(0 0 100% 0)';
    const green = ['overview', 'cards', 'insights'].includes(v);
    view.innerHTML = `${green ? '<div data-green><div class="bov-loading"><span class="spinner"></span></div></div>' : `<header class="bov-head"><div><h2 class="bov-hello">${esc(n ? L(...n[2]) : L('الإشعارات', 'Notifications'))}</h2>${SUB[v] ? `<p class="bov-sub">${esc(L(...SUB[v]))}</p>` : ''}</div></header>`}
      <div class="bov-legacy" data-pane></div>`;
    paintLegacy();
    if (!green) return;
    const cx = await loadCx(B, first, user);
    if (my !== seq || !B.alive() || !view.isConnected) return;
    paintSafe(cx);
    const g = view.querySelector('[data-green]'); if (!g) return;
    (v === 'cards' ? cardsView : v === 'insights' ? insightsView : overviewView)(g, B, cx, (x) => show(x));
  };
  /** Old tabs call B.go(tab). Going to the section already open just scrolls to its old-tab part. */
  B.go = (tab, opts = {}) => {
    const v = NAV_OF[tab] || (tab === 'notifications' ? 'notifications' : tab === 'pockets' ? 'overview' : null); if (!v) return;
    if (v === st.bovView && !opts.force) { view.querySelector(tab === 'pockets' ? '[data-pockets]' : '[data-pane]')?.scrollIntoView({ behavior: reduced() ? 'auto' : 'smooth', block: 'start' }); return; }
    show(v, opts).then(() => { if (tab === 'pockets') view.querySelector('[data-pockets]')?.scrollIntoView({ block: 'start' }); });
  };
  B.bankView = (v) => show(v);
  const paintSafe = (cx) => {
    const box = root.querySelector('[data-safe]'); const bud = cx.bud; if (!box) return;
    const left = (bud?.items || []).reduce((a, b) => a + Math.max(0, b.amount - b.spent), 0);
    const daysLeft = (() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate() - d.getDate() + 1; })();
    const hot = (bud?.items || []).filter((b) => b.pct >= 80).length;
    box.innerHTML = bud?.items?.length ? `<div class="bov-safe"><small>${esc(L('آمن تصرفه اليوم', 'Safe to spend today'))}</small><b dir="ltr" data-amt>${esc(usd(left / 100 / daysLeft))}</b><span>${esc(L(`${usd(left / 100, 0)} باقي بميزانياتك · ${daysLeft} يوم`, `${usd(left / 100, 0)} left in budgets · ${daysLeft} days`))}</span></div>`
      : `<button type="button" class="bov-safe is-empty" data-gosafe><small>${esc(L('آمن تصرفه اليوم', 'Safe to spend today'))}</small><span>${esc(L('حط ميزانية للشهر ونحسبلك كل يوم', 'Set a monthly budget and we work it out daily'))}</span></button>`;
    box.querySelector('[data-gosafe]')?.addEventListener('click', () => B.go('money', { user: true }));
    const setB = (id, n, soft) => { const e = root.querySelector(`[data-badge="${id}"]`); if (!e) return; e.hidden = !n; e.textContent = String(n); e.classList.toggle('is-soft', Boolean(soft)); };
    setB('budgets', hot, false); setB('cards', cx.cards.length, true);
  };
  nav.addEventListener('click', (e) => { const b = e.target.closest('[data-nav]'); if (!b) return; show(b.dataset.nav, { user: true }); });
  root.querySelectorAll('.bov-top [data-go]').forEach((b) => b.addEventListener('click', () => B.go(b.dataset.go, { user: true })));
  root.querySelector('[data-theme]').addEventListener('click', () => document.querySelector('[data-theme-toggle]')?.click());
  bindSearch(root, B, show);
  requestAnimationFrame(() => { const on = nav.querySelector('.is-on'); if (on) { pill.__st = null; slidePill(pill, on); } });
  show(st.bovView);
}
async function loadCx(B, first, user) {
  const [dash, vc, bud] = await Promise.all([bankApi.dashboard(12).catch(() => null), bankApi.vcards().catch(() => ({ items: [] })), bankApi.budgets().catch(() => null)]);
  return { dash, cards: (vc.items || []).filter((c) => c.status !== 'closed'), bud, flow: dash?.cashflow || [], rates: Boolean(dash && dash.netWorthUsd != null), first, user };
}

/* search: pages by name, and your real payments (merchant / type) */
function bindSearch(p, B, show) {
  const inp = p.querySelector('[data-search]'); const box = p.querySelector('[data-sres]'); let hist = null; let timer = 0;
  const close = () => { box.hidden = true; box.innerHTML = ''; };
  inp.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(async () => {
    const q = inp.value.trim().toLowerCase(); if (q.length < 2) return close();
    const pages = NAV.filter((n) => n && L(...n[2]).toLowerCase().includes(q));
    if (!hist) { try { hist = (await bankApi.history({ limit: 100 })).items || []; } catch { hist = []; } }
    const pays = hist.filter((x) => `${x.meta?.merchant || ''} ${x.type}`.toLowerCase().includes(q)).slice(0, 6);
    box.innerHTML = `${pages.map((n) => `<button type="button" data-sp="${n[0]}">${icons[n[1]] || ''}<span>${esc(L(...n[2]))}</span></button>`).join('')}
      ${pays.map((x) => `<div class="bov-sr"><span>${esc(String(x.meta?.merchant || x.type).replace(/_/g, ' '))}</span><b dir="ltr">${x.effect > 0 ? '+' : x.effect < 0 ? '−' : ''}${esc(fmtMinor(Math.abs(x.effect || x.amount), x.currency))} ${esc(x.currency)}</b></div>`).join('')}
      ${!pages.length && !pays.length ? `<p>${esc(L('ما لقينا إشي', 'Nothing found'))}</p>` : ''}`;
    box.hidden = false;
  }, 180); });
  box.addEventListener('click', (e) => { const b = e.target.closest('[data-sp]'); if (!b) return; close(); inp.value = ''; p.querySelector(`[data-nav="${b.dataset.sp}"]`)?.click(); });
  inp.addEventListener('keydown', (e) => { if (e.key === 'Escape') { close(); inp.blur(); } });
  inp.addEventListener('blur', () => setTimeout(close, 200));
}

/* ── Overview ── */
function overviewView(v, B, cx, show) {
  const { dash, cards, flow, rates, first, bud } = cx; const st = B.st;
  const hr = new Date().getHours(); const greet = hr < 12 ? L('صباح الخير', 'Good morning') : hr < 18 ? L('مساء الخير', 'Good afternoon') : L('مساء النور', 'Good evening');
  const today = new Date().toLocaleDateString(getLocale(), { weekday: 'long', month: 'long', day: 'numeric' });
  const usdW = (st.wallet?.wallets || []).find((w) => w.currency === 'USD');
  const pts = rates ? flow.filter((r) => r.balanceUsd != null).map((r) => ({ label: monthShort(r.month), v: r.balanceUsd })) : [];
  const m1 = flow.at(-1); const sum = (n, k) => flow.slice(-n).reduce((a, r) => a + r[k], 0);
  const chg = pts.length > 1 ? pctChange(pts.at(-1).v, pts.at(-2).v) : null;
  const sub = [usdW ? L(`متاح بمحفظة الدولار: ⁦$${fmtMinor(usdW.available, 'USD')}⁩`, `Available in your USD wallet: $${fmtMinor(usdW.available, 'USD')}`) : '', cards.length ? L(`${cards.length} بطاقة`, `${cards.length} card${cards.length > 1 ? 's' : ''}`) : ''].filter(Boolean).join(' · ');
  v.innerHTML = `
    <header class="bov-head">
      <div><p class="bov-date">${esc(today)}</p><h2 class="bov-hello">${esc(greet)}${first ? `${getLang() === 'ar' ? '، ' : ', '}${esc(first)}` : ''}</h2>${sub ? `<p class="bov-sub">${esc(sub)}</p>` : ''}</div>
      <div class="bov-acts"><button type="button" class="bov-btn" data-statement>${icons.download}<span>${esc(L('كشف الحساب', 'Statement'))}</span></button><button type="button" class="bov-btn is-primary" data-go="withdraw">${icons.send}<span>${esc(L('حوّل مصاري', 'Send money'))}</span></button></div>
    </header>
    <div class="bov-grid">
      <section class="bov-panel bov-cards">
        <div class="bov-ph"><div><h3>${esc(L('البطاقات', 'Cards'))}</h3><p>${esc(L('اسحب البطاقة الفوقانية عالجنب، أو اضغط عليها لتقلبها', 'Throw the top card aside, or tap it to turn it over'))}</p></div><button type="button" class="bov-link" data-view="cards">${esc(L('كل البطاقات', 'All cards'))}</button></div>
        ${stackHtml(cards, first)}
        <div data-recent></div>
      </section>
      <section class="bov-panel bov-bal">
        <div class="bov-ph"><div><h3>${esc(L('صافي الثروة', 'Net worth'))}</h3><p>${esc(dash?.complete === false ? L('جزئي: في أسعار ناقصة', 'Partial: some prices missing') : L('محافظك واستثماراتك بالدولار', 'Your wallets and investments in USD'))}</p></div><button type="button" class="bov-eye" data-hide aria-label="${esc(L('خبّي الأرقام', 'Hide amounts'))}">${icons.eyeOff}</button></div>
        ${rates ? `<div class="bov-balrow"><div><div class="bov-big" dir="ltr" data-amt>${esc(usd(dash.netWorthUsd))}</div>${chg != null ? `<span class="bov-chg ${chg >= 0 ? 'is-up' : 'is-down'}" dir="ltr">${chg >= 0 ? '↑' : '↓'} ${Math.abs(chg)}%</span><small class="bov-muted">${esc(L('رصيد المحافظ عن آخر الشهر الماضي', 'wallets vs last month end'))}</small>` : ''}</div>
            <div class="bov-chips">${[[L('هالشهر', 'This month'), m1?.outUsd], [L('3 شهور', '3 months'), sum(3, 'outUsd')], [L('6 شهور', '6 months'), sum(6, 'outUsd')], [L('السنة', 'This year'), sum(12, 'outUsd')]].map(([k, val]) => `<div class="bov-chipbox"><small>${esc(k)}</small><b dir="ltr" data-amt>${esc(usd(val || 0, 0))}</b></div>`).join('')}<small class="bov-chips-note">${esc(L('مصاريف', 'spent'))}</small></div></div>
          ${lineChart(pts)}
          <div class="bov-legend"><span><i class="is-line"></i>${esc(L('رصيد محافظك نهاية كل شهر (بأسعار صرف اليوم)', 'Your wallets at each month end (at today\'s rates)'))}</span><span><i class="is-dot"></i>${esc(L('اليوم', 'Today'))}</span></div>`
          : `<p class="bov-empty">${esc(L('أسعار الصرف مش متوفرة هلأ، فما بنعرض مجموع بالدولار. أرصدتك تحت بالمحفظة.', 'Exchange rates are not available right now, so no USD total is shown. Your balances are below.'))}</p>`}
      </section>
      <section class="bov-panel bov-flow">${flowPanel(cx, 'ov')}</section>
    </div>
    <p class="bov-note">${esc(L('كل الأرقام من حسابك بالبنك الرقمي.', 'Every number comes from your digital-bank account.'))}${st.info?.mode === 'sandbox' ? ` ${esc(L('وضع تجريبي: أموال تجربة.', 'Test mode: test funds.'))}` : ''}</p>`;
  bindFlow(v, cx, 'ov');
  v.querySelector('[data-hide]').addEventListener('click', (e) => { const on = v.closest('.bov').classList.toggle('is-hidden'); e.currentTarget.innerHTML = on ? icons.eye : icons.eyeOff; });
  v.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => B.go(b.dataset.go)));
  v.querySelectorAll('[data-view]').forEach((b) => b.addEventListener('click', () => show(b.dataset.view)));
  bindStatement(v);
  bankApi.history({ limit: 4 }).then((h) => { const box = v.querySelector('[data-recent]'); if (!box || !h?.items?.length) return;
    box.innerHTML = `<div class="bov-recent"><small>${esc(L('آخر الحركات', 'Latest activity'))}</small><ul>${h.items.map(rowHtml).join('')}</ul></div>`; }).catch(() => {});
  bindStack(v, B, cx, () => show('overview'));
}
const rowHtml = (x) => `<li><span>${esc(String(x.meta?.merchant || x.type || '').replace(/_/g, ' '))}</span><time>${esc(new Date(x.created_at).toLocaleDateString(getLocale(), { month: 'short', day: 'numeric' }))}</time><b dir="ltr" data-amt class="${x.effect > 0 ? 'is-up' : ''}">${x.effect > 0 ? '+' : x.effect < 0 ? '−' : ''}${esc(fmtMinor(Math.abs(x.effect || x.amount), x.currency))} ${esc(x.currency)}</b></li>`;

function bindStatement(v) {
  v.querySelector('[data-statement]')?.addEventListener('click', async (e) => {
    const btn = e.currentTarget; if (btn.disabled) return; btn.disabled = true;
    try {
      const rows = []; let before = null;
      for (let i = 0; i < 20; i++) { const h = await bankApi.history({ limit: 100, before }); rows.push(...(h.items || [])); if (!h.next || !h.items?.length) break; before = h.next; }
      const lines = [['date', 'type', 'description', 'amount', 'currency', 'status', 'id'].join(','), ...rows.map((x) => [new Date(x.created_at).toISOString(), x.type, x.meta?.merchant || '', `${x.effect < 0 ? '-' : ''}${fmtMinor(Math.abs(x.effect || x.amount), x.currency).replace(/,/g, '')}`, x.currency, x.status, x.id].map(csvCell).join(','))];
      const url = URL.createObjectURL(new Blob(['﻿' + lines.join('\n')], { type: 'text/csv;charset=utf-8' }));
      const a = document.createElement('a'); a.href = url; a.download = `gotriva-statement-${new Date().toISOString().slice(0, 10)}.csv`; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 30_000);
    } catch { btn.querySelector('span').textContent = L('ما زبط، جرّب كمان مرة', 'Failed, try again'); } finally { btn.disabled = false; }
  });
}

/* money in & out panel (shared by Overview and Insights) */
function flowPanel(cx, id) {
  return `<div class="bov-ph"><div><h3>${esc(L('الدخل والمصاريف', 'Money in & out'))}</h3><p data-range-sub="${id}">${esc(L('آخر 12 شهر', 'The last twelve months'))}</p></div>
      <div class="bov-seg" data-seg="${id}" role="tablist"><span class="bov-pill" aria-hidden="true"></span>${[[3, L('3 شهور', 'Quarter')], [6, L('6 شهور', '6 months')], [12, L('سنة', 'Year')]].map(([n, t]) => `<button type="button" role="tab" data-range="${n}" aria-selected="${n === 12}" class="${n === 12 ? 'is-on' : ''}">${esc(t)}</button>`).join('')}</div></div>
    <div class="bov-flowsum" data-flowsum="${id}"></div><div data-bars="${id}"></div>`;
}
function bindFlow(v, cx, id) {
  const { flow, rates } = cx; const seg = v.querySelector(`[data-seg="${id}"]`); if (!seg) return; const pill = seg.querySelector('.bov-pill');
  const showRange = (n) => {
    const rows = flow.slice(-n); const tin = rows.reduce((a, r) => a + r.inUsd, 0); const tout = rows.reduce((a, r) => a + r.outUsd, 0);
    v.querySelector(`[data-range-sub="${id}"]`).textContent = n === 12 ? L('آخر 12 شهر', 'The last twelve months') : n === 6 ? L('آخر 6 شهور', 'The last six months') : L('آخر 3 شهور', 'The last three months');
    v.querySelector(`[data-flowsum="${id}"]`).innerHTML = rates && rows.length ? `<span><i class="is-in"></i>${esc(L('دخل', 'In'))} <b dir="ltr">${esc(usd(tin, 0))}</b></span><span><i class="is-out"></i>${esc(L('مصاريف', 'Out'))} <b dir="ltr">${esc(usd(tout, 0))}</b></span><span>${esc(L('ضل معك', 'Kept'))} <b dir="ltr" class="${tin - tout >= 0 ? 'is-up' : 'is-down'}">${esc(iso(usd(tin - tout, 0)))}</b></span>` : '';
    v.querySelector(`[data-bars="${id}"]`).innerHTML = rates && rows.length ? barChart(rows) : `<p class="bov-empty">${esc(L('ما في أرقام بالدولار هلأ.', 'No USD figures right now.'))}</p>`;
  };
  seg.addEventListener('click', (e) => { const b = e.target.closest('[data-range]'); if (!b) return; seg.querySelectorAll('[data-range]').forEach((x) => { x.classList.toggle('is-on', x === b); x.setAttribute('aria-selected', String(x === b)); }); slidePill(pill, b); showRange(Number(b.dataset.range)); });
  requestAnimationFrame(() => { const on = seg.querySelector('.is-on'); if (on) { pill.__st = null; slidePill(pill, on); } });
  showRange(12);
}

/* card stack (Overview and Cards) */
function stackHtml(cards, first) {
  return cards.length ? `<div class="bov-stack" data-stack>${cards.map(cardFace).join('')}</div>
    <div class="bov-ctrl"><button type="button" class="bov-round" data-prev aria-label="${esc(L('السابقة', 'Previous'))}">‹</button><span class="bov-dots">${cards.map((_, i) => `<i class="${i ? '' : 'is-on'}"></i>`).join('')}</span><button type="button" class="bov-round" data-next aria-label="${esc(L('التالية', 'Next'))}">›</button>
      <span class="bov-sp"></span><button type="button" class="bov-chipbtn" data-flip>${icons.swap || ''}<span>${esc(L('اقلب', 'Flip'))}</span></button><button type="button" class="bov-chipbtn" data-freeze>${icons.lock}<span data-fz>${esc(L('جمّد', 'Freeze'))}</span></button></div>`
    : `<div class="bov-nocard">${cardFace({ label: L('بطاقتك الجاية', 'Your next card'), last4: '••••', holder: first || '—', exp: '—', status: 'active' }, 0).replace('bov-card"', 'bov-card is-ghost"')}<button type="button" class="bov-btn is-primary" data-newcard>${icons.plus}<span>${esc(L('اطلب بطاقة', 'Get a card'))}</span></button></div>`;
}
function bindStack(v, B, cx, rerender, onTop = null) {
  v.querySelector('[data-newcard]')?.addEventListener('click', () => B.go('cards'));
  const stack = v.querySelector('[data-stack]'); if (!stack) return; const { cards } = cx;
  let order = cards.map((_, i) => i);
  const layout = () => {
    stack.querySelectorAll('.bov-card').forEach((el) => { const pos = order.indexOf(Number(el.dataset.ci)); el.style.setProperty('--pos', pos); el.style.zIndex = String(10 - pos); el.classList.toggle('is-top', pos === 0); el.style.transform = ''; });
    v.querySelectorAll('.bov-dots i').forEach((d, i) => d.classList.toggle('is-on', i === order[0]));
    const top = cards[order[0]]; const fz = v.querySelector('[data-fz]'); if (fz) fz.textContent = top.status === 'frozen' ? L('فك التجميد', 'Unfreeze') : L('جمّد', 'Freeze');
    onTop?.(top);
  };
  const rotate = (dir = 1) => { order = dir > 0 ? [...order.slice(1), order[0]] : [order.at(-1), ...order.slice(0, -1)]; stack.querySelectorAll('.bov-card.is-flipped').forEach((x) => x.classList.remove('is-flipped')); layout(); };
  const topEl = () => stack.querySelector(`.bov-card[data-ci="${order[0]}"]`);
  let drag = null;
  stack.addEventListener('pointerdown', (e) => { const el = e.target.closest('.bov-card.is-top'); if (!el) return; drag = { el, x: e.clientX, y: e.clientY, dx: 0, moved: false }; el.setPointerCapture(e.pointerId); el.classList.add('is-drag'); });
  stack.addEventListener('pointermove', (e) => { if (!drag) return; drag.dx = e.clientX - drag.x; const dy = e.clientY - drag.y; if (Math.abs(drag.dx) > 6) drag.moved = true; drag.el.style.transform = `translate(${drag.dx}px, ${dy * 0.2}px) rotate(${drag.dx / 18}deg)`; });
  const end = () => { if (!drag) return; const { el, dx, moved } = drag; drag = null; el.classList.remove('is-drag');
    if (Math.abs(dx) > 90 && cards.length > 1) { el.style.transform = `translate(${dx > 0 ? 520 : -520}px, 30px) rotate(${dx > 0 ? 24 : -24}deg)`; el.style.opacity = '0'; setTimeout(() => { el.style.opacity = ''; rotate(1); }, reduced() ? 0 : 260); }
    else if (!moved) el.classList.toggle('is-flipped'); else el.style.transform = ''; };
  stack.addEventListener('pointerup', end); stack.addEventListener('pointercancel', end);
  stack.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); topEl()?.classList.toggle('is-flipped'); } });
  v.querySelector('[data-next]').addEventListener('click', () => rotate(getLang() === 'ar' ? -1 : 1));
  v.querySelector('[data-prev]').addEventListener('click', () => rotate(getLang() === 'ar' ? 1 : -1));
  v.querySelector('[data-flip]').addEventListener('click', () => topEl()?.classList.toggle('is-flipped'));
  v.querySelector('[data-freeze]').addEventListener('click', async (e) => { const c = cards[order[0]]; const a = c.status === 'frozen' ? 'unfreeze' : 'freeze';
    if (await B.act(e.currentTarget, () => bankApi.vcardAction(c.id, a))) { c.status = a === 'freeze' ? 'frozen' : 'active'; rerender(); } });
  layout();
}

/* ── Cards: the stack + the selected card's real settings ── */
function cardsView(v, B, cx, show) {
  const { cards } = cx; const spentAll = cards.reduce((a, c) => a + (c.spent?.month || 0), 0);
  const month = new Date().toLocaleDateString(getLocale(), { month: 'long' });
  v.innerHTML = `<header class="bov-head"><div><h2 class="bov-hello">${esc(L('البطاقات', 'Cards'))}</h2><p class="bov-sub">${esc(cards.length ? L(`${cards.length} بطاقة · صرفت عليهن ${usd(spentAll / 100)} بشهر ${month}`, `${cards.length} card${cards.length > 1 ? 's' : ''} · ${usd(spentAll / 100)} spent on them in ${month}`) : L('لسا ما عندك بطاقات', 'No cards yet'))}</p></div>
      <div class="bov-acts"><button type="button" class="bov-btn is-primary" data-go="cards">${icons.plus}<span>${esc(L('بطاقة افتراضية', 'Virtual card'))}</span></button></div></header>
    <div class="bov-grid2"><section class="bov-panel bov-cards">${stackHtml(cards, cx.first)}</section><section class="bov-panel" data-cset></section></div>`;
  v.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => B.go(b.dataset.go)));
  const set = v.querySelector('[data-cset]');
  const paint = (c) => {
    if (!c) { set.innerHTML = `<p class="bov-empty">${esc(L('اطلب بطاقة افتراضية وبتطلع إعداداتها هون.', 'Request a virtual card and its settings show here.'))}</p>`; return; }
    const lim = c.limits || {}; const ctl = c.controls || { online: true, abroad: true, contactless: true };
    const leftM = Math.max(0, (lim.month || 0) - (c.spent?.month || 0));
    const sw = (k, on, t, d) => `<div class="bov-setrow"><div><b>${esc(t)}</b><small>${esc(d)}</small></div><button type="button" class="bov-switch${on ? ' is-on' : ''}" role="switch" aria-checked="${on}" data-sw="${k}" aria-label="${esc(t)}"><i></i></button></div>`;
    const minM = Math.ceil((lim.day || 0) / 100); const maxM = 25000;
    set.innerHTML = `<div class="bov-ph"><div><h3 dir="auto">${esc(c.label || L('بطاقة', 'Card'))}</h3><p dir="auto">${esc([c.holder, c.kind === 'single' ? L('لمرة وحدة', 'single-use') : L('افتراضية', 'virtual'), `•••• ${c.last4 || ''}`].filter(Boolean).join(' · '))}</p></div><span class="bov-live ${c.status === 'active' ? 'is-on' : ''}">${esc(c.status === 'active' ? L('فعّالة', 'Live') : L('مجمّدة', 'Frozen'))}</span></div>
      <div class="bov-2box"><div class="bov-chipbox"><small>${esc(L(`صرفت بشهر ${month}`, `Spent in ${month}`))}</small><b dir="ltr" data-amt>${esc(usd((c.spent?.month || 0) / 100))}</b></div><div class="bov-chipbox"><small>${esc(L('باقي هالشهر', 'Left this month'))}</small><b dir="ltr" data-amt>${esc(usd(leftM / 100))}</b></div></div>
      ${sw('freeze', c.status === 'frozen', L('جمّد البطاقة', 'Freeze card'), L('بيوقف أي دفعة جديدة.', 'Stops new payments.'))}
      ${sw('online', ctl.online, L('الدفع أونلاين', 'Online payments'), L('المواقع والتطبيقات', 'Shops on the web and in apps'))}
      ${sw('abroad', ctl.abroad, L('الدفع برّا البلد', 'Payments abroad'), L('دفعات من برّا بلدك', 'Outside your country'))}
      ${sw('contactless', ctl.contactless, L('الدفع بالتلامس', 'Contactless'), L('قرّب البطاقة أو الموبايل وادفع', 'Tap to pay'))}
      <div class="bov-setrow is-col"><div class="bov-row"><b>${esc(L('الحد الشهري', 'Monthly limit'))}</b><b dir="ltr" data-limv>${esc(usd(lim.month / 100, 0))}</b></div>
        <input type="range" class="bov-range" data-lim min="${minM}" max="${maxM}" step="50" value="${Math.round((lim.month || 0) / 100)}" aria-label="${esc(L('الحد الشهري', 'Monthly limit'))}"><small class="bov-muted" data-limmsg>${esc(L(`بين ${usd(minM, 0)} (حدّك اليومي) و ${usd(maxM, 0)}`, `Between ${usd(minM, 0)} (your daily limit) and ${usd(maxM, 0)}`))}</small></div>
      <button type="button" class="bov-hold" data-hold>${icons.lock}<span>${esc(L('اضغط مطوّل لتشوف تفاصيل البطاقة', 'Hold to see card details'))}</span><i></i></button><div data-reveal-out></div>`;
    const save = async (btn, payload, okMsg) => { const r = await B.act(btn, () => B.secure('card_limits', { id: c.id, ...payload }, (passkey) => bankApi.updateVcard(c.id, { ...payload, passkey })), okMsg); if (r) Object.assign(c, r); return r; };
    set.querySelectorAll('[data-sw]').forEach((b) => b.addEventListener('click', async () => {
      const k = b.dataset.sw; const on = !b.classList.contains('is-on');
      if (k === 'freeze') { if (await B.act(b, () => bankApi.vcardAction(c.id, on ? 'freeze' : 'unfreeze'))) { c.status = on ? 'frozen' : 'active'; cardsView(v, B, cx, show); } return; }
      const r = await save(b, { [{ online: 'allowOnline', abroad: 'allowAbroad', contactless: 'allowContactless' }[k]]: on }); if (r) paint(c);
    }));
    const rng = set.querySelector('[data-lim]'); let t2 = 0;
    rng.addEventListener('input', () => { set.querySelector('[data-limv]').textContent = usd(Number(rng.value), 0); });
    rng.addEventListener('change', () => { clearTimeout(t2); t2 = setTimeout(async () => { const r = await save(rng, { limitMonth: String(rng.value) }, L('انحفظ الحد الشهري', 'Monthly limit saved')); if (r) paint(c); }, 150); });
    // hold to reveal: after 0.7 s of pressing, the bank's own step-up check runs and the details show for a few seconds
    const hold = set.querySelector('[data-hold]'); let ht = 0;
    const startH = () => { hold.classList.add('is-holding'); ht = setTimeout(async () => { hold.classList.remove('is-holding');
      if (c.issuer === 'stripe') { const out = set.querySelector('[data-reveal-out]'); out.innerHTML = '<div class="bsc"></div>'; await B.act(hold, () => B.secure('card_reveal', { id: c.id }, (passkey) => showStripeCard(out.querySelector('.bsc'), { publishableKey: B.st.info.features?.rails?.publishableKey, cardRef: c.issuerRef }, (nonce) => bankApi.vcardEphemeral(c.id, { nonce, passkey })))); return; }   // v369 real card
      const r = await B.act(hold, () => B.secure('card_reveal', { id: c.id }, (passkey) => bankApi.revealVcard(c.id, { passkey }))); const out = set.querySelector('[data-reveal-out]');
      if (r && out) { out.innerHTML = r.pan ? `<div class="bov-reveal" dir="ltr"><b>${esc(String(r.pan).replace(/(\d{4})(?=\d)/g, '$1 '))}</b><span>${esc(r.exp || '')}</span><span>CVV ${esc(r.cvv || '')}</span></div>` : `<p class="bov-muted">${esc(r.sandbox ? L('بطاقة تجريبية: ما في تفاصيل حقيقية.', 'Test card: no real details.') : L('التفاصيل عند مُصدر البطاقة.', 'Details are with the card issuer.'))}</p>`;
        setTimeout(() => { if (out.isConnected) out.innerHTML = ''; }, Math.min(60, Number(r.showSeconds) || 30) * 1000); } }, 700); };
    const stopH = () => { clearTimeout(ht); hold.classList.remove('is-holding'); };
    hold.addEventListener('pointerdown', startH); ['pointerup', 'pointerleave', 'pointercancel'].forEach((ev) => hold.addEventListener(ev, stopH));
    hold.addEventListener('keydown', (e) => { if ((e.key === 'Enter' || e.key === ' ') && !e.repeat) { e.preventDefault(); startH(); } }); hold.addEventListener('keyup', stopH);
  };
  bindStack(v, B, cx, () => cardsView(v, B, cx, show), paint);
  if (!cards.length) paint(null);
}

/* ── Insights: In & out / Spending / Merchants + balance over time ── */
function insightsView(v, B, cx) {
  const { flow, rates, dash } = cx; const has = rates && flow.length;
  const months = flow.filter((r) => r.inUsd || r.outUsd); const nM = months.length || 1;
  const avgIn = months.reduce((a, r) => a + r.inUsd, 0) / nM; const avgOut = months.reduce((a, r) => a + r.outUsd, 0) / nM;
  const keptPct = avgIn > 0 ? Math.round(((avgIn - avgOut) / avgIn) * 100) : null;
  const best = months.slice().sort((a, b) => (b.inUsd - b.outUsd) - (a.inUsd - a.outUsd))[0];
  const spark = (k) => { const vs = flow.map((r) => r[k]); const mx = Math.max(1, ...vs); return `<svg class="bov-spark" viewBox="0 0 100 30" dir="ltr" aria-hidden="true"><path d="${vs.map((x, i) => `${i ? 'L' : 'M'}${(i / Math.max(1, vs.length - 1)) * 100},${28 - (x / mx) * 24}`).join('')}"/></svg>`; };
  v.innerHTML = `<header class="bov-head"><div><h2 class="bov-hello">${esc(L('التحليلات', 'Insights'))}</h2><p class="bov-sub">${esc(L('قديش بيدخلك، قديش بتصرف، ووين بتروح المصاري', 'What you earn, keep and spend, and where it goes'))}</p></div></header>
    <div class="bov-tabs" role="tablist"><button type="button" class="is-on" data-it="io">${esc(L('الدخل والمصاريف', 'In & out'))}</button><button type="button" data-it="sp">${esc(L('المصاريف', 'Spending'))}</button><button type="button" data-it="mr">${esc(L('التجار', 'Merchants'))}</button></div>
    <div data-itv></div>`;
  const box = v.querySelector('[data-itv]');
  const io = () => {
    box.innerHTML = has ? `<div class="bov-kpis">
        <div class="bov-kpi"><small>${icons.download}${esc(L('متوسط الدخل بالشهر', 'Average in a month'))}</small><b dir="ltr" data-amt>${esc(usd(avgIn, 0))}</b><span>${esc(L(`على ${nM} شهر`, `over ${nM} months`))}</span>${spark('inUsd')}</div>
        <div class="bov-kpi"><small>${icons.send}${esc(L('متوسط المصاريف بالشهر', 'Average out a month'))}</small><b dir="ltr" data-amt>${esc(usd(avgOut, 0))}</b><span>${esc(L('دفعات وبطاقات وتحويلات', 'Payments, cards and transfers'))}</span>${spark('outUsd')}</div>
        <div class="bov-kpi is-warm"><small>${icons.piggy}${esc(L('اللي بيضل معك كل شهر', 'Kept each month'))}</small><b dir="ltr">${keptPct == null ? '—' : `${keptPct}%`}</b><span dir="auto">${esc(L(`${usd(avgIn - avgOut, 0)} بالمتوسط`, `${usd(avgIn - avgOut, 0)} on average`))}</span></div>
        <div class="bov-kpi"><small>${icons.trophy}${esc(L('أحسن شهر', 'Best month'))}</small><b>${esc(best ? monthShort(best.month) : '—')}</b><span dir="auto">${esc(best ? L(`ضل معك ${usd(best.inUsd - best.outUsd, 0)}`, `${usd(best.inUsd - best.outUsd, 0)} kept`) : '')}</span></div></div>
      <div class="bov-grid2"><section class="bov-panel bov-flow">${flowPanel(cx, 'in')}</section>
        <section class="bov-panel"><div class="bov-ph"><div><h3>${esc(L('الرصيد مع الوقت', 'Balance over time'))}</h3><p>${esc(L('رصيد محافظك نهاية كل يوم (بأسعار صرف اليوم)', 'Your wallets at the end of each day (at today\'s rates)'))}</p></div>
          <div class="bov-seg" data-seg="bd"><span class="bov-pill" aria-hidden="true"></span>${[[30, L('30 يوم', '30 days')], [90, L('90 يوم', '90 days')], [365, L('سنة', 'Year')]].map(([n, t]) => `<button type="button" data-days="${n}" class="${n === 90 ? 'is-on' : ''}">${esc(t)}</button>`).join('')}</div></div><div data-bd></div></section></div>`
      : `<p class="bov-empty">${esc(L('أسعار الصرف مش متوفرة هلأ، فما بنقدر نعرض التحليلات بالدولار.', 'Exchange rates are not available right now, so insights in USD cannot be shown.'))}</p>`;
    if (!has) return;
    bindFlow(box, cx, 'in');
    const seg = box.querySelector('[data-seg="bd"]'); const pill = seg.querySelector('.bov-pill'); const out = box.querySelector('[data-bd]');
    const load = async (n) => { out.innerHTML = '<div class="bov-loading"><span class="spinner"></span></div>'; let r = null; try { r = await bankApi.balanceDaily(n); } catch { r = null; }
      if (!out.isConnected) return; const pts = r?.points || [];
      out.innerHTML = pts.length > 1 ? dailyChart(pts) : `<p class="bov-empty">${esc(L('ما في بيانات كافية.', 'Not enough data.'))}</p>`; };
    seg.addEventListener('click', (e) => { const b = e.target.closest('[data-days]'); if (!b) return; seg.querySelectorAll('[data-days]').forEach((x) => x.classList.toggle('is-on', x === b)); slidePill(pill, b); load(Number(b.dataset.days)); });
    requestAnimationFrame(() => { const on = seg.querySelector('.is-on'); pill.__st = null; slidePill(pill, on); });
    load(90);
  };
  const sp = () => {
    const rows = (dash?.spendByCategory || []).filter((r) => r.amount > 0); const mx = Math.max(1, ...rows.map((r) => r.amount));
    box.innerHTML = `<section class="bov-panel"><div class="bov-ph"><div><h3>${esc(L('المصاريف حسب النوع', 'Spending by category'))}</h3><p>${esc(L('هالشهر، بالدولار', 'This month, in USD'))}</p></div></div>
      ${rows.length ? `<ul class="bov-hbars">${rows.map((r) => `<li><span>${esc(catLabel(r.category))}</span><i style="--w:${Math.max(3, (r.amount / mx) * 100)}%"></i><b dir="ltr" data-amt>${esc(usd(r.amount / 100))}</b></li>`).join('')}</ul>` : `<p class="bov-empty">${esc(L('ما في مصاريف مصنّفة هالشهر.', 'No categorised spending this month.'))}</p>`}</section>`;
  };
  const mr = async () => {
    box.innerHTML = '<div class="bov-loading"><span class="spinner"></span></div>'; let r = null; try { r = await bankApi.merchants(); } catch { r = null; }
    if (!box.isConnected) return; const items = r?.items || [];
    box.innerHTML = `<section class="bov-panel"><div class="bov-ph"><div><h3>${esc(L('وين صرفت بالبطاقات', 'Where your cards were used'))}</h3><p>${esc(L('آخر 90 يوم، بالدولار', 'Last 90 days, in USD'))}</p></div></div>
      ${items.length ? `<div class="bov-recent"><ul>${items.map((x) => `<li><span dir="auto">${esc(x.merchant)}</span><time>${esc(L(`${x.n} مرة`, `${x.n}×`))}</time><b dir="ltr" data-amt>${esc(usd(x.amount / 100))}</b></li>`).join('')}</ul></div>` : `<p class="bov-empty">${esc(L('لسا ما في دفعات بالبطاقة.', 'No card payments yet.'))}</p>`}</section>`;
  };
  v.querySelector('.bov-tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-it]'); if (!b) return; v.querySelectorAll('[data-it]').forEach((x) => x.classList.toggle('is-on', x === b)); ({ io, sp, mr })[b.dataset.it](); });
  io();
}
const catLabel = (c) => { const ar = { groceries: 'بقالة', dining: 'مطاعم', transport: 'مواصلات', shopping: 'تسوّق', bills: 'فواتير', subscriptions: 'اشتراكات', entertainment: 'ترفيه', travel: 'سفر', health: 'صحة', education: 'تعليم', other: 'غيره' }; return getLang() === 'ar' ? ar[c] || c : c; };
function dailyChart(pts) {
  const W = 640, H = 200, P = 44; const vs = pts.map((p) => p.usd); const lo = Math.min(...vs), hi = Math.max(...vs); const span = hi - lo || 1;
  const x = (i) => P + (i / (pts.length - 1)) * (W - P - 6); const y = (v) => H - 24 - ((v - lo) / span) * (H - 44);
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.usd).toFixed(1)}`).join('');
  const ticks = [hi, (hi + lo) / 2, lo].map((v) => `<text x="0" y="${y(v) + 3}" class="bov-ax">${esc(usdK(v))}</text><line x1="${P}" x2="${W}" y1="${y(v)}" y2="${y(v)}" class="bov-grid"/>`).join('');
  const step = Math.max(1, Math.floor(pts.length / 5));
  const lab = pts.map((p, i) => (i % step === 0 || i === pts.length - 1 ? `<text x="${x(i)}" y="${H - 6}" text-anchor="${i === pts.length - 1 ? 'end' : i === 0 ? 'start' : 'middle'}" class="bov-ax">${esc(new Date(p.at).toLocaleDateString(getLocale(), { month: 'short', day: 'numeric' }))}</text>` : '')).join('');
  return `<svg class="bov-line" viewBox="0 0 ${W} ${H}" dir="ltr" role="img" aria-label="${esc(L('الرصيد مع الوقت', 'Balance over time'))}">${ticks}<path d="${d}" class="bov-line-path"/>${lab}</svg>`;
}
