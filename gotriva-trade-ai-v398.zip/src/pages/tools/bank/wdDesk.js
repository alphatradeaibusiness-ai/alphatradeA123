// v383 Owner desk → withdrawals: one card per request (who, amount, balance, today's use, flags, the reason when above the
// limit), approve / reject with a confirm step, then send (Stripe) or mark it paid with the transfer reference.
import { bankApi } from '../../../services/bank/api.js';
import { tx } from '../../../i18n/tx.js';
import { icons } from '../../../components/icons.js';
import { esc, fmtMinor, Tx } from './ui.js';

const L = (ar, en) => tx({ ar, en });
const CHK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>';
const X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>';
const ago = (t) => { const m = Math.max(1, Math.round((Date.now() - t) / 60000)); return m < 60 ? L(`قبل ${m} دقيقة`, `${m} min ago`) : m < 1440 ? L(`قبل ${Math.round(m / 60)} ساعة`, `${Math.round(m / 60)} h ago`) : L(`قبل ${Math.round(m / 1440)} يوم`, `${Math.round(m / 1440)} d ago`); };
const money = (v, c) => `<bdi dir="ltr">${fmtMinor(v, c)} ${esc(c)}</bdi>`;

export function wdDesk(el, { items, act, toast, stripe, reload }) {
  el.innerHTML = `<div class="dk"><div class="dk-head"><h2>${icons.send}<span>${esc(L('طلبات السحب', 'Withdrawal requests'))}</span>${items.length ? `<span class="dk-count">${items.length}</span>` : ''}</h2></div>
    ${items.length ? items.map((w) => `<div class="ap${w.status === 'requested' && Date.now() - w.created_at < 3600_000 ? ' new' : ''}" data-wd="${esc(w.id)}">
      <div class="ap-top"><div class="ap-av">${esc((w.name || '?').trim().charAt(0).toUpperCase())}</div><div class="ap-who"><b>${esc(w.name || '—')}</b><small>${esc(ago(w.created_at))}${w.username ? ` · <bdi dir="ltr">${esc(w.username)}</bdi>` : ''}</small></div>
        <span class="ap-st ${w.flags.includes('over_limit') ? 'no' : w.status === 'approved' ? 'ok' : ''}">${esc(w.flags.includes('over_limit') ? L('فوق الحد', 'Above limit') : w.status === 'approved' ? L('موافق، بانتظار الإرسال', 'Approved, to send') : L('بانتظار المراجعة', 'Waiting for review'))}</span></div>
      <dl class="ap-facts"><div><dt>${esc(L('المبلغ', 'Amount'))}</dt><dd>${money(w.amount, w.currency)} <small class="muted">+ ${money(w.fee, w.currency)}</small></dd></div>
        <div><dt>${esc(L('رصيده', 'Balance'))}</dt><dd>${w.available == null ? '—' : money(w.available, w.currency)}</dd></div>
        <div><dt>${esc(L('سحب اليوم', 'Out today'))}</dt><dd>${w.today ? `${money(w.today.used, w.currency)} / ${money(w.today.limit, w.currency)}` : '—'}</dd></div>
        <div><dt>${esc(L('لوين', 'To'))}</dt><dd data-to><button type="button" class="ap-more" data-do="dest">${esc(L('اعرض الوجهة', 'Show destination'))}</button></dd></div></dl>
      ${w.reason ? `<div class="ap-confirm is-warn"><b>${esc(L('سببه:', 'Reason:'))}</b> ${esc(w.reason)}</div>` : ''}
      ${w.flags.filter((f) => f !== 'over_limit').length ? `<div class="ap-chips">${w.flags.filter((f) => f !== 'over_limit').map((f) => `<span>${esc(Tx(`flag.${f}`, f))}</span>`).join('')}</div>` : ''}
      <div class="ap-act">${w.status === 'requested' ? `<button type="button" class="ap-yes" data-do="approve">${CHK}${esc(L('موافقة', 'Approve'))}</button><button type="button" class="ap-no" data-do="reject">${X}${esc(L('رفض', 'Reject'))}</button>`
        : `${stripe ? `<button type="button" class="ap-yes" data-do="stripe">${esc(L('ابعت عن طريق Stripe', 'Send via Stripe'))}</button>` : ''}<button type="button" class="ap-soft" data-do="paid">${esc(L('بعتها بإيدي، علّمها تم', 'Sent by hand, mark paid'))}</button>`}</div></div>`).join('')
      : `<p class="muted dk-empty">${esc(L('ما في طلبات سحب هلّق.', 'No withdrawal requests.'))}</p>`}</div>`;
  el.querySelectorAll('[data-wd]').forEach((card) => card.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-do]'); if (!b || b.closest('.ap-confirm')) return; const id = card.dataset.wd; const w = items.find((x) => x.id === id);
    if (b.dataset.do === 'dest') {
      const d = await act(b, () => bankApi.admin.destination(id)); if (!d) return; const x = d.details || {};
      card.querySelector('[data-to]').innerHTML = esc(x.paypal ? `PayPal · ${x.paypal}` : x.iban ? `IBAN ${x.iban} · ${x.holder || ''}` : x.address ? `${x.network} · ${x.address}` : x.stripe || x.account ? 'Stripe' : L('حساب Stripe المربوط', 'Linked Stripe account'));
      return;
    }
    const acts = card.querySelector('.ap-act'); const keep = acts.innerHTML; const box = document.createElement('div'); box.className = 'ap-confirm';
    const run = async (btn, fn, ok) => { if (await act(btn, fn, ok)) reload(); };
    const ask = (html, label, cls, onOk) => {
      box.innerHTML = html; acts.before(box); box.querySelector('input,textarea')?.focus();
      acts.innerHTML = `<button type="button" class="${cls}" data-ok>${esc(label)}</button><button type="button" class="ap-soft" data-cancel>${esc(L('إلغاء', 'Cancel'))}</button>`;
      acts.querySelector('[data-cancel]').onclick = (ev) => { ev.stopPropagation(); box.remove(); acts.innerHTML = keep; };
      acts.querySelector('[data-ok]').onclick = (ev) => { ev.stopPropagation(); onOk(ev.currentTarget); };
    };
    const amt = `${fmtMinor(w.amount, w.currency)} ${w.currency}`;
    if (b.dataset.do === 'approve') ask(`<b>${esc(L(`توافق على سحب ${amt} لـ ${w.name || '—'}؟`, `Approve ${amt} for ${w.name || '—'}?`))}</b><br>${esc(L('بعد الموافقة بتبعت المصاري وبتعلّمها تم.', 'After approving you send the money and mark it paid.'))}`, L('أكّد الموافقة', 'Confirm'), 'ap-yes', (btn) => run(btn, () => bankApi.admin.withdrawal(id, 'approve', {}), L('تمت الموافقة.', 'Approved.')));
    if (b.dataset.do === 'reject') ask(`<b class="bad">${esc(L('سبب الرفض (بيوصله)', 'Reason (sent to them)'))}</b><textarea maxlength="200"></textarea>`, L('أكّد الرفض', 'Confirm rejection'), 'ap-no is-solid', (btn) => {
      const why = box.querySelector('textarea').value.trim(); if (why.length < 3) { toast(L('اكتب سبب الرفض.', 'Write the reason.'), 'error'); return; }
      run(btn, () => bankApi.admin.withdrawal(id, 'reject', { note: why }), L('تم الرفض ورجعت المصاري لرصيده.', 'Rejected; the money is back in their balance.'));
    });
    if (b.dataset.do === 'stripe') ask(`<b>${esc(L(`Stripe رح يحوّل ${amt} لبطاقة أو حساب ${w.name || '—'}. متأكد؟`, `Stripe will send ${amt} to ${w.name || '—'}. Sure?`))}</b>`, L('ابعت هلّق', 'Send now'), 'ap-yes', (btn) => run(btn, () => bankApi.admin.withdrawal(id, 'stripe', {}), L('انبعتت عن طريق Stripe.', 'Sent via Stripe.')));
    if (b.dataset.do === 'paid') ask(`<b>${esc(L('رقم الحوالة أو رقم العملية بـ PayPal', 'Transfer or PayPal transaction reference'))}</b><input maxlength="80" dir="ltr">`, L('علّمها تم', 'Mark paid'), 'ap-yes', (btn) => {
      const ref = box.querySelector('input').value.trim(); if (ref.length < 4) { toast(L('اكتب رقم العملية.', 'Enter the reference.'), 'error'); return; }
      run(btn, () => bankApi.admin.withdrawal(id, 'complete', { extRef: ref }), L('تم. انعلّم السحب إنه وصل.', 'Done. Marked as paid.'));
    });
  }));
}
