// v384 Send money to another member by their bank username (GT-xxxxx): instant and free, inside the daily limit.
import { bankApi } from '../../../services/bank/api.js';
import { tx } from '../../../i18n/tx.js';
import { icons } from '../../../components/icons.js';
import { esc } from './ui.js';

const L = (ar, en) => tx({ ar, en });
const iso = (x) => `\u2068${x}\u2069`;
const QR_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h2v2h-2zM18 14h2v2h-2zM14 18h2v2h-2zM18 18h2v2h-2z"/></svg>';
const scanOk = () => typeof window !== 'undefined' && 'BarcodeDetector' in window && Boolean(navigator.mediaDevices?.getUserMedia);
/** v390 camera scan of a member's code (browsers with BarcodeDetector; elsewhere the button is not shown). */
async function scanQr(onCode) {
  const ov = document.createElement('div'); ov.className = 'pp-scanov'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-label', L('امسح الكود', 'Scan the code'));
  ov.innerHTML = `<video playsinline muted></video><p>${esc(L('وجّه الكاميرا على كود صاحبك.', 'Point the camera at your friend\u2019s code.'))}</p><button type="button" class="pm-go is-soft">${esc(L('إلغاء', 'Cancel'))}</button>`;
  document.body.append(ov); let stream = null; let on = true;
  const close = () => { on = false; stream?.getTracks().forEach((t) => t.stop()); ov.remove(); };
  ov.querySelector('button').addEventListener('click', close);
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }); const v = ov.querySelector('video'); v.srcObject = stream; await v.play();
    const det = new window.BarcodeDetector({ formats: ['qr_code'] });
    const loop = async () => { if (!on) return; try { const c = await det.detect(v); const m = c.map((x) => /GT-\w{5,8}/i.exec(x.rawValue || '')).find(Boolean); if (m) { close(); onCode(m[0].toUpperCase()); return; } } catch { /* next frame */ } setTimeout(loop, 250); };
    loop();
  } catch { ov.querySelector('p').textContent = L('ما قدرنا نفتح الكاميرا. اكتب اسم المستخدم بإيدك.', 'Could not open the camera. Type the username instead.'); }
}   // keeps «Rami H.» and «$150.00» in one piece inside Arabic
export async function p2pBox(host, { act, secure, wallet, onDone }) {
  const lim = await bankApi.limits().catch(() => null); const max = lim?.p2p?.max || 60000; const left = Math.min(max, lim?.withdraw?.USD?.left ?? max);
  const bal = wallet?.wallets?.find((w) => w.currency === 'USD')?.available ?? 0; const usd = (c) => `$${(c / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  host.innerHTML = `<form class="pm" data-p2pf novalidate><h2>${esc(L('حوّل لعضو', 'Send to a member'))}</h2><p class="pm-sub">${esc(L('فوري ومجاني لأي عضو عنده حساب بالبنك.', 'Instant and free to any member with a bank account.'))}</p>
    <div class="pp-people" data-people hidden></div>
    <label class="pm-f">${esc(L('اسم المستخدم بالبنك', 'Bank username'))}<span class="bl-in pp-to"><input name="to" dir="ltr" placeholder="GT-12345" maxlength="20" autocapitalize="characters" autocomplete="off" required>${scanOk() ? `<button type="button" class="pp-scan" data-scan aria-label="${esc(L('امسح كود QR', 'Scan a QR code'))}">${QR_ICON}</button>` : ''}</span></label>
    <div data-who></div><label class="pm-amt"><span>$</span><input name="amount" inputmode="decimal" dir="ltr" placeholder="20" aria-label="${esc(L('المبلغ', 'Amount'))}" required></label>
    <p class="pm-warn" data-over hidden></p><div class="pm-chips" dir="ltr">${[20, 50, 100, 250, 600].map((v) => `<button type="button" data-v="${v}">$${v}</button>`).join('')}</div>
    <label class="pm-f">${esc(L('ملاحظة (اختياري)', 'Note (optional)'))}<span class="bl-in"><input name="note" maxlength="60"></span></label>
    <div class="pm-lim"><div class="pm-row"><span>${esc(L('رصيدك بعد التحويل', 'Your balance after'))}</span><b dir="ltr" data-after>${usd(bal)}</b></div><p class="pm-lnote">${esc(L(`أعلى مبلغ للتحويل الواحد ${iso(usd(max))} · من ضمن حدّك اليومي`, `Up to ${usd(max)} per transfer · inside your daily limit`))}</p></div>
    <button class="pm-go" type="submit" data-go disabled>${esc(L('حوّل', 'Send'))}</button></form>`;
  const f = host.querySelector('[data-p2pf]'); const who = f.querySelector('[data-who]'); const go = f.querySelector('[data-go]'); let name = ''; let tm = 0; let seq = 0;
  const paint = () => {
    const n = Math.round(Number(String(f.amount.value).replace(/,/g, '')) * 100) || 0; f.querySelector('[data-after]').textContent = usd(Math.max(0, bal - n));
    const ov = f.querySelector('[data-over]'); const msg = n > max ? L(`أعلى مبلغ للتحويل الواحد ${iso(usd(max))}. قسّمه على أكتر من تحويل.`, `A single transfer is up to ${usd(max)}. Split it into more transfers.`) : n > left ? L(`باقي إلك اليوم ${iso(usd(left))} من حدّك اليومي.`, `${usd(left)} left of your daily limit.`) : n > bal ? L('رصيدك ما بيكفي.', 'Not enough balance.') : '';
    ov.hidden = !msg; ov.textContent = msg;
    go.disabled = !name || n < 100 || n > bal || n > left; go.textContent = name && n ? L(`حوّل ${iso(usd(n))} لـ ${iso(name)}`, `Send ${usd(n)} to ${name}`) : L('حوّل', 'Send');
  };
  f.to.addEventListener('input', () => {
    clearTimeout(tm); name = ''; who.innerHTML = ''; paint(); const u = f.to.value.trim().toUpperCase(); if (!/^GT-\w{5,8}$/.test(u)) return;
    const my = ++seq; tm = setTimeout(async () => {
      const r = await bankApi.p2pLookup(u).catch(() => null); if (my !== seq) return;
      if (r?.found) { name = r.name; who.innerHTML = `<div class="ap pm-who"><div class="ap-top"><div class="ap-av">${esc(name.charAt(0))}</div><div class="ap-who"><b><bdi>${esc(name)}</bdi></b><small dir="ltr">${esc(u)} · ${esc(L('حساب موثّق ✓', 'verified ✓'))}</small></div></div></div>`; }
      else who.innerHTML = `<p class="pm-warn">${esc(L('ما لقينا عضو بهالاسم. تأكد من اسم المستخدم.', 'No member with this username. Check it and try again.'))}</p>`;
      paint();
    }, 350);
  });
  f.amount.addEventListener('input', paint);
  const fill = (u) => { f.to.value = u; f.to.dispatchEvent(new Event('input')); f.amount.focus(); };
  bankApi.people().then((r) => {   // v390 the people you sent to before: one tap fills the username
    const box = f.querySelector('[data-people]'); const items = (r?.items || []).filter((x) => x.username); if (!items.length) return;
    box.innerHTML = `<span class="pp-lbl">${esc(L('حوّلت لهم قبل', 'Sent before'))}</span><div class="pp-row">${items.map((x) => `<button type="button" class="pp-p" data-u="${esc(x.username)}"><i aria-hidden="true">${esc((x.name || x.username).charAt(0))}</i><span><bdi>${esc(x.name || x.username)}</bdi></span></button>`).join('')}</div>`;
    box.hidden = false; box.querySelectorAll('[data-u]').forEach((b) => b.addEventListener('click', () => fill(b.dataset.u)));
  }).catch(() => {});
  f.querySelector('[data-scan]')?.addEventListener('click', () => scanQr((u) => fill(u)));
  f.querySelectorAll('[data-v]').forEach((b) => b.addEventListener('click', () => { f.amount.value = b.dataset.v; paint(); }));
  f.addEventListener('submit', async (e) => {
    e.preventDefault(); if (go.disabled) return; const b = { to: f.to.value.trim().toUpperCase(), amount: f.amount.value.trim(), note: f.note.value.trim() || undefined };
    const r = await act(go, () => secure('p2p', b, (passkey) => bankApi.p2p({ ...b, passkey }))); if (!r) return;
    host.innerHTML = `<div class="cs is-done"><div class="cs-badge">${icons.check}</div><h2 class="cs-title">${esc(L(`وصلوا لـ ${iso(name)}`, `Sent to ${name}`))}</h2><p class="cs-sub" dir="ltr">${esc(usd(r.amount))}</p>
      <div class="pm-lim"><div class="pm-row"><span>${esc(L('الرسوم', 'Fee'))}</span><b>${esc(L('مجاني', 'Free'))}</b></div>${b.note ? `<div class="pm-row"><span>${esc(L('ملاحظتك', 'Your note'))}</span><b>${esc(b.note)}</b></div>` : ''}<p class="pm-lnote">${esc(L('إيصال التحويل بـ «الفواتير والإيصالات».', 'The receipt is in «Invoices & receipts».'))}</p></div>
      <div style="height:12px"></div><button type="button" class="pm-go is-soft" data-again>${esc(L('حوّل كمان', 'Send again'))}</button></div>`;
    host.querySelector('[data-again]').addEventListener('click', onDone);
  });
}
