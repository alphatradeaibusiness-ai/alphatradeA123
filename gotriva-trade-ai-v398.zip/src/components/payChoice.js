// v384 Paying a plan: from the bank wallet (instant, no card) or by card / Apple Pay on Stripe. Shown only when the person has
// an open bank account; otherwise checkout goes straight to Stripe as before.
import { payLock } from './payLock.js';
import { bankApi } from '../services/bank/api.js';
import { tx } from '../i18n/tx.js';
import { esc } from '../utils/dom.js';

const L = (ar, en) => tx({ ar, en });
/** → 'card' (go to Stripe), 'done' (paid from the wallet), or null (closed). */
export async function payChoice(plan, { title = null, sub = null, doneMsg = null } = {}) {   // v391 also challenges (title / sub given)
  let w = null; let locked = false;
  try { w = await bankApi.wallet(); } catch (e) { if (e?.code !== 'bank_login_required') return 'card'; locked = true; }
  if (!locked && !(w?.kyc?.tier >= 1)) return 'card';
  const bal = w?.wallets?.find((x) => x.currency === 'USD')?.available ?? 0; const cents = Math.round(plan.price * 100); const usd = (c) => `$${(c / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
  const enough = !locked && bal >= cents;
  return new Promise((done) => {
    const el = document.createElement('div'); el.className = 'iv pc'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true');
    el.innerHTML = `<div class="card gt-pay pc-card"><div class="pm"><h2>${esc(title || L('ادفع الاشتراك', 'Pay for your plan'))}</h2><p class="pm-sub">${sub ? esc(sub) : `GOTRIVA TRADE AI · ${esc(plan.months === 12 ? L('سنة', '12 months') : plan.months > 1 ? L(`${plan.months} شهور`, `${plan.months} months`) : L('شهر', '1 month'))} · <bdi dir="ltr">${usd(cents)}</bdi>`}</p>
      <div class="pm-list"><button type="button" class="pm-m" data-v="bank" aria-checked="${enough}" ${enough ? '' : 'disabled'}><span class="pm-ic pm-bk">G</span><span><b>${esc(L('من رصيد البنك', 'From my bank balance'))}</b><small>${locked ? esc(L('ادخل على البنك أول باسم المستخدم وكلمة السر', 'Sign in to the bank first')) : `${esc(L('رصيدك', 'Balance'))} <bdi dir="ltr">${usd(bal)}</bdi> · ${esc(enough ? L('بيتفعّل فورًا', 'instant') : L('ما بيكفي', 'not enough'))}`}</small></span><i class="pm-rd"></i></button>
      <button type="button" class="pm-m" data-v="card" aria-checked="${!enough}"><span class="pm-ic pm-vi">VISA</span><span><b>${esc(L('بطاقة / Apple Pay', 'Card / Apple Pay'))}</b><small>${esc(L('عن طريق Stripe', 'via Stripe'))}</small></span><i class="pm-rd"></i></button></div>
      ${enough ? `<div class="pm-lim"><div class="pm-row"><span>${esc(L('رصيدك بعد الدفع', 'Balance after'))}</span><b dir="ltr">${usd(bal - cents)}</b></div></div>` : ''}
      <button type="button" class="pm-go" data-go>${esc(enough ? L(`ادفع ${usd(cents)} من رصيدي`, `Pay ${usd(cents)} from my balance`) : L('كمّل بالبطاقة', 'Continue with card'))}</button>
      ${locked ? `<a class="pm-go is-soft" href="#/app/bank">${esc(L('افتح البنك', 'Open the bank'))}</a>` : ''}<button type="button" class="pm-go is-soft" data-x>${esc(L('إلغاء', 'Cancel'))}</button></div></div>`;
    let pick = enough ? 'bank' : 'card'; const go = el.querySelector('[data-go]');
    const close = (v) => { el.remove(); done(v); };
    el.querySelectorAll('[data-v]').forEach((b) => b.addEventListener('click', () => { pick = b.dataset.v; el.querySelectorAll('[data-v]').forEach((x) => x.setAttribute('aria-checked', String(x === b))); go.textContent = pick === 'bank' ? L(`ادفع ${usd(cents)} من رصيدي`, `Pay ${usd(cents)} from my balance`) : L('كمّل بالبطاقة', 'Continue with card'); }));
    el.querySelector('[data-x]').addEventListener('click', () => close(null)); el.querySelector('a')?.addEventListener('click', () => close(null));
    go.addEventListener('click', async () => {
      if (pick === 'card') return close('card');
      let failed = null; await payLock(go, async () => { try { await bankApi.payPlan(plan.id); } catch (e) { failed = e; } });   // v394 one tap only
      if (!failed) { close('done'); return; } { const e = failed; go.disabled = false; go.textContent = L('ما زبط الدفع. جرّب كمان مرة أو بالبطاقة.', 'Payment failed. Try again or use a card.'); void e; }
    });
    document.body.append(el);
  });
}
