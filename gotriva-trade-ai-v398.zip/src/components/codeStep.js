// v381 The e-mail code step: the card the person is filling turns into six glowing boxes for the code sent to their e-mail.
// One real <input> sits over the boxes (paste, iOS/Android one-time-code autofill, keyboard); the boxes only draw its value.
// Used after sign-up (login page and the confirm gate) and as the last step of the bank application.
import { esc } from '../utils/dom.js';
import { tx } from '../i18n/tx.js';
import { icons } from './icons.js';
import { apiRequest } from '../services/ai/gateway.js';
import { getLang } from '../i18n/index.js';

const L = (ar, en) => tx({ ar, en });
const ERR = {
  wrong_code: ['الرمز غلط.', 'Wrong code.'],
  expired: ['الرمز انتهى. اطلب رمز جديد.', 'The code expired. Ask for a new one.'],
  too_many_tries: ['محاولات كثيرة. اطلب رمز جديد.', 'Too many tries. Ask for a new one.'],
  too_soon: ['استنى شوي قبل ما تطلب رمز جديد.', 'Wait a little before asking again.'],
  too_many: ['طلبت رموز كثير. جرّب بعد ساعة.', 'Too many codes asked. Try again in an hour.'],
  email_code_required: ['اكتب الرمز اللي وصلك على الإيميل.', 'Enter the code from your e-mail.'],
  mail_not_configured: ['خدمة البريد مش جاهزة هلّق.', 'E-mail service is not ready right now.'],
};
export const codeError = (c) => L(...(ERR[c] || ['صار خطأ. جرّب كمان مرة.', 'Something went wrong. Try again.']));
const STAR = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0c.6 6.2 5.8 11.4 12 12-6.2.6-11.4 5.8-12 12-.6-6.2-5.8-11.4-12-12C6.2 11.4 11.4 6.2 12 0z"/></svg>';
const COPY = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/></svg>';
const SPARKS = [[-2, -12], [6, 62], [30, -18], [62, 64], [78, -14], [100, 52], [95, -6], [22, 64]].map(([x, y], i) => `<i class="cs-spark${i % 2 ? ' s' : ''}" style="left:${x}%;top:${y}px"></i>`).join('')
  + `<span class="cs-star" style="left:-6%;top:22px">${STAR}</span><span class="cs-star" style="left:103%;top:8px;width:10px">${STAR}</span><span class="cs-star" style="left:46%;top:-26px;width:11px">${STAR}</span>`;

/**
 * Draws the step into `host` (its old content is the caller's to keep). send() → { retryInS } or throws { code, retryInS };
 * check(code) resolves when accepted or throws { code }. onDone runs after the success animation. Returns { destroy }.
 */
export function codeStep(host, { email = '', title, sub, goLabel, doneTitle, doneSub = '', extraHtml = '', backLabel = '', firstWait = 0, send, check, onBack, onDone }) {
  host.innerHTML = `<div class="cs" role="group" aria-label="${esc(title)}">
    <div class="cs-badge" aria-hidden="true">${icons.mail}</div><h2 class="cs-title">${esc(title)}</h2><p class="cs-sub">${esc(sub)}</p>
    <div class="cs-mail" dir="ltr"><b>${esc(email)}</b><button type="button" data-copy>${COPY}<span>${esc(L('نسخ', 'Copy'))}</span></button></div>
    <div class="cs-boxes" dir="ltr">${'<div class="cs-box"></div>'.repeat(6)}${SPARKS}
      <input class="cs-input" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]*" aria-label="${esc(L('رمز التأكيد من 6 أرقام', '6-digit confirmation code'))}"></div>
    <p class="cs-err" role="alert" hidden></p>
    <div class="cs-meta"><button type="button" class="cs-link" data-resend></button>${onBack ? `<button type="button" class="cs-link" data-back>${esc(backLabel || L('رجوع', 'Back'))}</button>` : ''}</div>
    ${extraHtml}
    <button type="button" class="cs-go" data-go disabled>${esc(goLabel)}</button>
    <p class="cs-note">${icons.shield}<span>${esc(L('الرمز صالح 15 دقيقة. شيّك على البريد غير المرغوب كمان.', 'The code is valid for 15 minutes. Check your spam folder too.'))}</span></p></div>`;
  const $ = (s) => host.querySelector(s); const inp = $('.cs-input'); const boxes = [...host.querySelectorAll('.cs-box')]; const err = $('.cs-err');
  const resend = $('[data-resend]'); const go = $('[data-go]'); let tick = 0; let busy = false;
  const paint = () => { const v = inp.value; boxes.forEach((b, i) => { b.textContent = v[i] || ''; b.classList.toggle('f', i < v.length); b.classList.toggle('on', i === v.length && document.activeElement === inp); }); go.disabled = v.length !== 6 || busy; };
  const showErr = (t) => { err.textContent = t || ''; err.hidden = !t; if (t) { const bx = $('.cs-boxes'); bx.classList.remove('shake'); void bx.offsetWidth; bx.classList.add('shake'); } };
  const cool = (sec) => {
    clearInterval(tick); let left = Math.max(0, sec | 0);
    const draw = () => { resend.disabled = left > 0; resend.textContent = left > 0 ? `${L('ابعت رمز جديد بعد', 'New code in')} ${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}` : L('ابعت رمز جديد', 'Send a new code'); };
    draw(); tick = setInterval(() => { left--; draw(); if (left <= 0) clearInterval(tick); }, 1000);
  };
  const doSend = async () => { showErr(''); try { const r = await send(); cool(r?.retryInS ?? 60); } catch (e) { showErr(codeError(e?.code)); cool(e?.retryInS || (e?.code === 'too_soon' ? 60 : 0)); } };
  const submit = async () => {
    if (inp.value.length !== 6 || busy) return; busy = true; paint(); showErr('');
    try {
      await check(inp.value); clearInterval(tick);
      boxes.forEach((b) => b.classList.add('ok')); host.querySelector('.cs').classList.add('is-done');
      $('.cs-badge').innerHTML = icons.check; $('.cs-title').textContent = doneTitle || L('تم التأكيد', 'Confirmed'); $('.cs-sub').textContent = doneSub;
      setTimeout(() => onDone?.(), 1100);
    } catch (e) { busy = false; showErr(codeError(e?.code)); inp.select(); paint(); }
  };
  inp.addEventListener('input', () => { inp.value = inp.value.replace(/\D/g, '').slice(0, 6); showErr(''); paint(); if (inp.value.length === 6) submit(); });
  inp.addEventListener('focus', paint); inp.addEventListener('blur', paint);
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
  go.addEventListener('click', submit); resend.addEventListener('click', doSend);
  $('[data-back]')?.addEventListener('click', () => { clearInterval(tick); onBack(); });
  $('[data-copy]').addEventListener('click', async (e) => {
    const b = e.currentTarget; try { await navigator.clipboard.writeText(email); } catch { /* the address stays selectable */ }
    b.classList.add('ok'); b.innerHTML = `${icons.check}<span>${esc(L('تم النسخ', 'Copied'))}</span>`;
  });
  if (firstWait > 0) cool(firstWait); else doSend(); paint(); setTimeout(() => inp.focus({ preventScroll: true }), 350);
  return { destroy: () => clearInterval(tick) };
}

/** The new-account e-mail code inside `host`. Resolves false when nothing is needed (old account, owner, no mail service,
 *  server unreachable: a code that cannot arrive never locks anybody out); otherwise draws the step and calls onDone when confirmed. */
export async function accountCodeStep(host, { email, onDone, onOut }) {
  let s; try { s = await apiRequest('GET', '/api/me/verify', undefined, 15000); } catch { return false; }
  if (!s?.required) return false;
  host.classList.add('cs-card');
  codeStep(host, {
    email, title: L('أكّد إيميلك', 'Confirm your e-mail'), sub: L('بعتنالك رمز من 6 أرقام على:', 'We sent a 6-digit code to:'),
    goLabel: L('تأكيد وافتح حسابي', 'Confirm and open my account'), doneTitle: L('تم تأكيد إيميلك', 'E-mail confirmed'), doneSub: L('حسابك جاهز.', 'Your account is ready.'),
    backLabel: L('تسجيل خروج', 'Sign out'), onBack: onOut, firstWait: s.pending && s.retryInS > 0 ? s.retryInS : 0,
    send: async () => { const r = await apiRequest('POST', '/api/me/verify/send', { lang: getLang() }, 20000); return { retryInS: r?.retryInS ?? 60 }; },
    check: (code) => apiRequest('POST', '/api/me/verify/check', { code }, 15000), onDone,
  });
  return true;
}
