// v394 Money buttons: one tap only. The button turns into a spinner («Processing…») and stays locked for at least 5 seconds
// (longer if the server is still working), so a second tap can never send a second payment. The server also merges
// identical money requests that arrive within a few seconds (server/bank/http.js `once`).
import { tx } from '../i18n/tx.js';

const busy = new WeakSet();
export const isMoneyButton = (b) => Boolean(b?.matches?.('[data-money], .pm-go:not(.is-soft):not([data-x]), .plan-cta, .ch-start, [data-buy]'));

/** Runs fn once for this button; returns fn's result, or undefined when the button is already busy. */
export async function payLock(btn, fn, { minMs = 5000 } = {}) {
  if (!btn) return fn();
  if (busy.has(btn) || btn.disabled) return undefined;
  busy.add(btn); const t0 = Date.now(); const html = btn.innerHTML; const w = btn.offsetWidth;
  btn.disabled = true; btn.setAttribute('aria-busy', 'true'); btn.classList.add('is-paying'); if (w) btn.style.minWidth = `${w}px`;
  btn.innerHTML = `<span class="pl-spin" aria-hidden="true"></span><span>${tx({ ar: 'جاري التنفيذ…', en: 'Processing…' })}</span>`;
  try { return await fn(); }
  finally {
    const left = minMs - (Date.now() - t0); if (left > 0) await new Promise((r) => setTimeout(r, left));
    if (btn.isConnected) { btn.innerHTML = html; btn.disabled = false; btn.removeAttribute('aria-busy'); btn.classList.remove('is-paying'); btn.style.minWidth = ''; }
    busy.delete(btn);
  }
}
