// v354 In-app camera for private channels: photo or video, front (selfie) or back camera, 30 / 60 / 120 fps when the phone's
// camera offers them (the list shows only what this camera really supports), review before sending.
// What a web page cannot reach: the phone camera app's own modes (Portrait, Cinematic, Night, slow-motion…). For those the
// attach menu has «Phone camera», which opens the phone's own camera app and sends whatever it records.
import { h, esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';

const MAX_SEC = 120;
const TYPES = ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
const ic = (d) => `<svg viewBox="0 0 24 24" aria-hidden="true">${d}</svg>`;
const I = { x: '<path d="M6 6l12 12M18 6L6 18"/>', flip: '<path d="M20 11a8 8 0 0 0-14.3-4.9L4 8M4 4v4h4M4 13a8 8 0 0 0 14.3 4.9L20 16M20 20v-4h-4"/>', send: '<path d="M4 12l16-8-6 16-2.5-6.5z"/>', retry: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5"/>' };

/** Opens the camera full screen. Resolves with { blob, kind: 'image'|'video' } or null when closed. */
export function openCamera() {
  const AR = getLang() === 'ar'; const L = (a, e) => (AR ? a : e);
  if (!navigator.mediaDevices?.getUserMedia) return Promise.resolve({ error: 'no_camera' });
  return new Promise((resolve) => {
    const el = h(`<div class="cam" role="dialog" aria-modal="true" aria-label="${esc(L('الكاميرا', 'Camera'))}">
      <video class="cam-view" playsinline muted autoplay></video>
      <div class="cam-review" hidden></div>
      <div class="cam-top"><button type="button" class="cam-ib" data-x aria-label="${esc(L('سكّر الكاميرا', 'Close the camera'))}">${ic(I.x)}</button>
        <span class="cam-rec" hidden><i></i><b data-time>0:00</b></span>
        <div class="cam-fps" dir="ltr" role="group" aria-label="${esc(L('سرعة الفريمات', 'Frame rate'))}"></div></div>
      <div class="cam-bottom">
        <div class="cam-modes" role="tablist"><button type="button" role="tab" data-mode="photo" aria-selected="true">${esc(L('صورة', 'Photo'))}</button><button type="button" role="tab" data-mode="video" aria-selected="false">${esc(L('فيديو', 'Video'))}</button></div>
        <div class="cam-row"><span class="cam-spacer"></span><button type="button" class="cam-shutter" data-shoot aria-label="${esc(L('صوّر', 'Capture'))}"><span></span></button>
          <button type="button" class="cam-ib" data-flip aria-label="${esc(L('اقلب الكاميرا: سيلفي أو أمامي', 'Flip camera: selfie or back'))}">${ic(I.flip)}</button></div>
        <div class="cam-row cam-after" hidden><button type="button" class="cam-pill" data-retake>${ic(I.retry)}<span>${esc(L('عيد', 'Retake'))}</span></button>
          <button type="button" class="cam-pill cam-pill-main" data-send>${ic(I.send)}<span>${esc(L('ابعت', 'Send'))}</span></button></div>
        <p class="cam-note" data-note></p></div></div>`);
    document.body.append(el); document.documentElement.classList.add('cam-open');
    const view = el.querySelector('.cam-view'); const review = el.querySelector('.cam-review'); const fpsBox = el.querySelector('.cam-fps'); const note = el.querySelector('[data-note]');
    const st = { mode: 'photo', facing: 'environment', fps: 30, stream: null, rec: null, chunks: [], t0: 0, timer: null, result: null, fpsList: [30] };

    async function start() {
      stop();
      const video = { facingMode: { ideal: st.facing }, width: { ideal: 1920 }, height: { ideal: 1080 }, frameRate: { ideal: st.fps } };
      try { st.stream = await navigator.mediaDevices.getUserMedia({ video, audio: st.mode === 'video' }); }
      catch (e) { if (st.mode === 'video') { try { st.stream = await navigator.mediaDevices.getUserMedia({ video }); note.textContent = L('الميكروفون مش مسموح، الفيديو بينسجّل بدون صوت.', 'Microphone blocked; video records without sound.'); } catch { fail(e); return; } } else { fail(e); return; } }
      view.srcObject = st.stream; view.classList.toggle('is-mirror', st.facing === 'user');
      const tr = st.stream.getVideoTracks()[0]; const cap = tr.getCapabilities?.() || {}; const max = cap.frameRate?.max || tr.getSettings?.().frameRate || 30;
      st.fpsList = [30, 60, 120].filter((f) => f <= Math.round(max) + 1); if (!st.fpsList.length) st.fpsList = [Math.round(max)];
      if (!st.fpsList.includes(st.fps)) st.fps = st.fpsList.at(-1) >= 60 && st.fps > 30 ? 60 : 30;
      paintFps();
    }
    function fail(e) { note.textContent = e?.name === 'NotAllowedError' ? L('الكاميرا مش مسموحة. اسمح فيها من إعدادات المتصفح.', 'Camera blocked. Allow it in the browser settings.') : L('ما قدرنا نفتح الكاميرا.', 'Could not open the camera.'); }
    function paintFps() {
      const actual = Math.round(st.stream?.getVideoTracks()[0]?.getSettings?.().frameRate || st.fps);
      fpsBox.innerHTML = st.fpsList.length > 1 ? st.fpsList.map((f) => `<button type="button" data-fps="${f}" aria-pressed="${f === st.fps}">${f}</button>`).join('') + `<small>fps</small>` : `<small>${actual} fps</small>`;
    }
    function stop() { st.stream?.getTracks().forEach((t) => t.stop()); st.stream = null; }
    function done(v) { clearInterval(st.timer); stop(); if (st.result?.url) URL.revokeObjectURL(st.result.url); el.remove(); document.documentElement.classList.remove('cam-open'); document.removeEventListener('keydown', onKey); resolve(v); }
    const onKey = (e) => { if (e.key === 'Escape') done(null); };
    document.addEventListener('keydown', onKey);

    function shoot() {
      if (!st.stream) return;
      if (st.mode === 'photo') {
        const w = view.videoWidth, hh = view.videoHeight; if (!w) return;
        const cv = document.createElement('canvas'); cv.width = w; cv.height = hh; const cx = cv.getContext('2d');
        cx.drawImage(view, 0, 0, w, hh); cv.toBlob((b) => { if (b) showResult(b, 'image'); }, 'image/jpeg', 0.92);
        return;
      }
      if (st.rec) { st.rec.stop(); return; }
      const type = TYPES.find((t) => window.MediaRecorder?.isTypeSupported?.(t)); if (!window.MediaRecorder) { note.textContent = L('هالمتصفح ما بيقدر يسجّل فيديو. استعمل «كاميرا الهاتف».', 'This browser cannot record video. Use «Phone camera».'); return; }
      st.chunks = []; st.rec = new MediaRecorder(st.stream, { ...(type ? { mimeType: type } : {}), videoBitsPerSecond: st.fps >= 60 ? 4_000_000 : 2_500_000, audioBitsPerSecond: 96_000 });
      st.rec.ondataavailable = (e) => { if (e.data?.size) st.chunks.push(e.data); };
      st.rec.onstop = () => { clearInterval(st.timer); el.classList.remove('is-recording'); el.querySelector('.cam-rec').hidden = true; const b = new Blob(st.chunks, { type: (st.rec.mimeType || type || 'video/webm').split(';')[0] }); st.rec = null; if (b.size) showResult(b, 'video'); };
      st.rec.start(1000); st.t0 = Date.now(); el.classList.add('is-recording'); el.querySelector('.cam-rec').hidden = false;
      st.timer = setInterval(() => { const s = Math.floor((Date.now() - st.t0) / 1000); el.querySelector('[data-time]').textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; if (s >= MAX_SEC) st.rec?.stop(); }, 250);
    }
    function showResult(blob, kind) {
      if (st.result) return;   // the photo is taken once
      const url = URL.createObjectURL(blob); st.result = { blob, kind, url };
      review.innerHTML = kind === 'image' ? `<img src="${url}" alt="">` : `<video src="${url}" controls playsinline></video>`;
      review.hidden = false; view.hidden = true; stop();
      el.querySelector('.cam-row:not(.cam-after)').hidden = true; el.querySelector('.cam-modes').hidden = true; el.querySelector('.cam-after').hidden = false; fpsBox.hidden = true;
      note.textContent = blob.size > 50_000_000 ? L('الفيديو أكبر من 50MB. صوّر أقصر.', 'The video is over 50 MB. Record a shorter one.') : '';
    }
    function retake() { if (st.result?.url) URL.revokeObjectURL(st.result.url); st.result = null; review.hidden = true; review.innerHTML = ''; view.hidden = false; el.querySelector('.cam-row:not(.cam-after)').hidden = false; el.querySelector('.cam-modes').hidden = false; el.querySelector('.cam-after').hidden = true; fpsBox.hidden = false; note.textContent = ''; start(); }

    el.addEventListener('click', (e) => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.hasAttribute('data-x')) return done(null);
      if (b.hasAttribute('data-shoot')) return shoot();
      if (b.hasAttribute('data-flip')) { if (st.rec) return; st.facing = st.facing === 'user' ? 'environment' : 'user'; return start(); }
      if (b.dataset.mode) { if (st.rec || st.mode === b.dataset.mode) return; st.mode = b.dataset.mode; el.classList.toggle('is-video', st.mode === 'video'); el.querySelectorAll('[data-mode]').forEach((x) => x.setAttribute('aria-selected', String(x.dataset.mode === st.mode))); return start(); }
      if (b.dataset.fps) { if (st.rec) return; st.fps = Number(b.dataset.fps); const tr = st.stream?.getVideoTracks()[0]; tr?.applyConstraints({ frameRate: { ideal: st.fps } }).then(paintFps, () => start()); paintFps(); return; }
      if (b.hasAttribute('data-retake')) return retake();
      if (b.hasAttribute('data-send')) { if (!st.result || st.result.blob.size > 50_000_000) return; const { blob, kind } = st.result; st.result = null; return done({ blob, kind }); }
    });
    start();
  });
}
