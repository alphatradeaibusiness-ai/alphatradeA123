# باك تست كامل — v398 (56% فوز وأكثر)

**البيانات:** شموع حقيقية محفوظة: BTCUSD (1m, 5m, 15m, 1h)، EURUSD (15m, 1h, 4h, 1D)، XAUUSD (15m, 1h, 4h). التكاليف محسوبة.

**الطريقة:** كل استراتيجية من الـ154 لحالها، على كل فريم، ماركت وليميت. جربنا الستوب 1 لـ4 × ATR، والهدف 0.5 لـ2 × المخاطرة، مع فلتر الاتجاه وبدونه، والليميت 0.25 أو 0.5 × ATR.
- الإعدادات انختارت على أول 60% من البيانات بس.
- بقيت الاستراتيجية بس إذا نجحت على 60–80% **وكمان** على 80–100%، كل جزء لحاله: فوز 56% أو أكثر، ربح بعد التكاليف، ما في أكثر من 6 خسارات ورا بعض.
- الأرقام بالجدول هي آخر 40% كاملة.

## النتيجة
- **270 إعداد** ناجح من **126 استراتيجية**.
- **انحذفت 28 استراتيجية** من المكتبة لأنها ما نجحت بولا فريم: bk_ema_8_21, bk_ema_9_21, bk_ema_10_30, bk_sma_50_200, bk_px_ema100, bk_ribbon_10_20_50, bk_st_10_3, bk_st_7_3, bk_st_20_4, bk_psar_0.01, bk_roc_14, bk_lr_50, bk_vol_mom, bk_obv, bk_rsi_14_20, bk_connors_5, bk_bb_rsi_25, bk_stochrsi, bk_mfi, bk_rsi_div, bk_vwap_rev, bk_vwap_trend, bk_range_brk, bk_london_mom, bk_pin_trend, bk_star, bk_cmb_adx_rsi50, bk_cmb_ichi_rsi50.
- قواعد SMC وICT بقيت لأن صفحة الأوردر فلو بتستعملها كتأكيد.

| الفريم | ماركت | ليميت |
|---|---|---|
| 1m | 0 | 0 |
| 5m | 2 | 1 |
| 15m | 0 | 9 |
| 1h | 2 | 68 |
| 4h | 28 | 102 |
| 1D | 8 | 50 |

- **1 دقيقة:** ولا وحدة نجحت، لا ماركت ولا ليميت.
- **15 دقيقة ماركت:** ولا وحدة نجحت. 15 دقيقة ليميت فيها 9.

## محاكاة الصفحة نفسها (آخر 40%)
الصفحة بتختار أحسن إشارة من المختبرة، وإذا في شراء وبيع بنفس الوقت ما بتدخل.

```
BTCUSD_15m.json  trades   0 avgR - win - total R 0.0 {"none_tested":1999}
BTCUSD_1h.json   trades  48 avgR 0.14 win 77% total R 6.5 {"no_signal":1757,"ok":48}
BTCUSD_1m.json   trades   0 avgR - win - total R 0.0 {"none_tested":1199}
BTCUSD_5m.json   trades  37 avgR 0.18 win 76% total R 6.7 {"no_signal":647,"ok":37,"conflict":1}
EURUSD_15m.json  trades   0 avgR - win - total R 0.0 {"none_tested":1999}
EURUSD_1D.json   trades  45 avgR 0.12 win 64% total R 5.3 {"no_signal":103,"ok":46,"conflict":1}
EURUSD_1h.json   trades  12 avgR 0.15 win 75% total R 1.8 {"no_signal":1860,"ok":13}
EURUSD_4h.json   trades  62 avgR 0.07 win 58% total R 4.1 {"ok":63,"no_signal":67,"conflict":1}
XAUUSD_15m.json  trades   0 avgR - win - total R 0.0 {"none_tested":1999}
XAUUSD_1h.json   trades  25 avgR 0.16 win 76% total R 3.9 {"no_signal":1766,"ok":26}
XAUUSD_4h.json   trades  73 avgR 0.11 win 62% total R 7.7 {"no_signal":95,"ok":74}
market ALL trades 302 avgR 0.119 win 67% total R 36.0

BTCUSD_15m.json  trades 273 avgR 0.04 win 82% total R 11.3 {"ok":379,"conflict":41,"no_signal":409}
BTCUSD_1h.json   trades 277 avgR 0.15 win 83% total R 41.9 {"conflict":290,"ok":394,"no_signal":8}
BTCUSD_1m.json   trades   0 avgR - win - total R 0.0 {"none_tested":1199}
BTCUSD_5m.json   trades  20 avgR 0.10 win 70% total R 1.9 {"no_signal":949,"ok":23}
EURUSD_15m.json  trades 211 avgR 0.08 win 80% total R 16.2 {"no_signal":436,"ok":318,"conflict":30}
EURUSD_1D.json   trades 120 avgR 0.36 win 88% total R 43.3 {"ok":176,"conflict":66,"no_signal":10}
EURUSD_1h.json   trades 290 avgR 0.18 win 86% total R 51.8 {"ok":420,"conflict":291,"no_signal":18}
EURUSD_4h.json   trades 262 avgR 0.16 win 80% total R 42.5 {"ok":379,"conflict":463,"no_signal":8}
XAUUSD_15m.json  trades 191 avgR 0.14 win 82% total R 26.3 {"ok":279,"no_signal":798,"conflict":43}
XAUUSD_1h.json   trades 269 avgR 0.04 win 72% total R 10.8 {"conflict":189,"ok":438,"no_signal":56}
XAUUSD_4h.json   trades 243 avgR 0.19 win 80% total R 45.9 {"conflict":445,"ok":385,"no_signal":17}
limit ALL trades 2156 avgR 0.135 win 81% total R 292.0
```

## لازم تعرفه
- الفوز العالي سببه إن الهدف قريب (غالبًا 0.5 لـ0.75 من المخاطرة). يعني الربح بالصفقة صغير، والخسارة لما تصير 1R كاملة. الربح بييجي من إن الفوز أكثر بكثير.
- الليميت محسوب إنه انفتح لما السعر لمس السعر. بالحقيقة ممكن يلمس وما ينفتح، فالنتيجة الحقيقية ممكن تكون أقل شوي.
- الفوركس انختبر على EURUSD بس، والذهب على XAUUSD، والكريبتو على BTC. المؤشرات (US30, US100) والطاقة ما إلها بيانات، فما بتطلعلها توصيات.
- حجم اللوت بيتحسب من رأس المال ونسبة المخاطرة اللي العميل بيحطها ومسافة الستوب تبع كل استراتيجية.
- نتيجة الماضي مش وعد. التحليل مش نصيحة مالية.

## الجدول الكامل
| فريم | أمر | الاستراتيجية | ستوب ×ATR | هدف ×R | اتجاه | ليميت ×ATR | فوز | R/صفقة | صفقات | أسواق |
|---|---|---|---|---|---|---|---|---|---|---|
| 5m | ماركت | bk_sma_20_50 | 2.5 | 1 | لا | - | 59% | 0.03 | 22 | BTCUSD |
| 5m | ليميت | bk_adx_30 | 3 | 0.75 | لا | 0.25 | 70% | 0.10 | 20 | BTCUSD |
| 5m | ماركت | bk_macd_div | 3 | 0.5 | لا | - | 83% | 0.12 | 24 | BTCUSD |
| 15m | ليميت | bk_rsi_2_10 | 1 | 0.5 | لا | 0.5 | 80% | 0.04 | 413 | BTCUSD EURUSD XAUUSD |
| 15m | ليميت | bk_rsi_2_5 | 1 | 0.5 | لا | 0.5 | 82% | 0.07 | 247 | BTCUSD EURUSD XAUUSD |
| 15m | ليميت | bk_bb_rev_20_2 | 1.5 | 0.5 | نعم | 0.5 | 76% | 0.08 | 37 | BTCUSD XAUUSD |
| 15m | ليميت | bk_stoch_14_3_3 | 1 | 0.5 | لا | 0.5 | 79% | 0.04 | 316 | BTCUSD EURUSD XAUUSD |
| 15m | ليميت | bk_stoch_5_3_3 | 1 | 0.5 | لا | 0.5 | 81% | 0.07 | 294 | EURUSD XAUUSD |
| 15m | ليميت | bk_nr4 | 2.5 | 0.5 | نعم | 0.5 | 73% | 0.03 | 139 | BTCUSD EURUSD XAUUSD |
| 15m | ليميت | bk_nr7 | 1 | 0.5 | لا | 0.5 | 78% | 0.03 | 268 | BTCUSD XAUUSD |
| 15m | ليميت | bk_engulf_ema | 1.5 | 0.5 | نعم | 0.5 | 77% | 0.06 | 111 | BTCUSD EURUSD XAUUSD |
| 15m | ليميت | bk_ict_fvg | 1 | 0.5 | لا | 0.5 | 80% | 0.05 | 551 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_ema_20_50 | 1 | 0.5 | لا | 0.5 | 79% | 0.10 | 77 | BTCUSD XAUUSD |
| 1h | ليميت | bk_ema_21_55 | 1 | 0.5 | لا | 0.5 | 80% | 0.12 | 64 | BTCUSD EURUSD XAUUSD |
| 1h | ماركت | bk_ema_50_200 | 2 | 0.75 | لا | - | 77% | 0.31 | 22 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_sma_10_30 | 1 | 0.5 | لا | 0.5 | 76% | 0.07 | 164 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_px_ema20 | 1 | 0.5 | لا | 0.5 | 76% | 0.04 | 307 | BTCUSD EURUSD |
| 1h | ليميت | bk_px_ema50 | 1.5 | 0.5 | لا | 0.5 | 77% | 0.10 | 180 | BTCUSD EURUSD |
| 1h | ليميت | bk_px_ema200 | 1 | 0.5 | لا | 0.5 | 77% | 0.08 | 117 | BTCUSD XAUUSD |
| 1h | ليميت | bk_ribbon_20_50_100 | 1 | 0.5 | لا | 0.5 | 86% | 0.21 | 58 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_macd_5_35_5 | 1 | 0.5 | لا | 0.5 | 78% | 0.09 | 386 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_adx_20 | 1 | 0.5 | لا | 0.5 | 81% | 0.13 | 176 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_adx_30 | 1.5 | 0.5 | لا | 0.5 | 80% | 0.14 | 106 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_ichi_cloud | 1 | 0.5 | لا | 0.5 | 77% | 0.07 | 197 | BTCUSD EURUSD |
| 1h | ليميت | bk_ichi_tk | 1 | 0.5 | لا | 0.5 | 84% | 0.17 | 171 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_ichi_full | 1 | 0.5 | لا | 0.5 | 81% | 0.14 | 182 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_hma_9 | 1 | 0.5 | لا | 0.5 | 80% | 0.11 | 532 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_hma_21 | 1 | 0.5 | لا | 0.5 | 79% | 0.09 | 373 | BTCUSD EURUSD |
| 1h | ليميت | bk_hma_55 | 1 | 0.5 | لا | 0.5 | 76% | 0.05 | 176 | BTCUSD XAUUSD |
| 1h | ليميت | bk_don_10 | 1 | 0.5 | لا | 0.5 | 75% | 0.03 | 341 | BTCUSD EURUSD |
| 1h | ليميت | bk_kc_brk_20_2 | 1 | 0.5 | نعم | 0.5 | 75% | 0.05 | 96 | BTCUSD EURUSD |
| 1h | ليميت | bk_aroon_14 | 1 | 0.5 | لا | 0.5 | 82% | 0.16 | 264 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_aroon_25 | 1 | 0.5 | لا | 0.5 | 80% | 0.12 | 173 | BTCUSD EURUSD |
| 1h | ليميت | bk_trix_9 | 1 | 0.5 | لا | 0.5 | 76% | 0.05 | 259 | BTCUSD XAUUSD |
| 1h | ليميت | bk_roc_9 | 1 | 0.5 | لا | 0.5 | 76% | 0.05 | 378 | BTCUSD EURUSD |
| 1h | ليميت | bk_roc_21 | 1 | 0.5 | لا | 0.5 | 75% | 0.04 | 272 | BTCUSD EURUSD |
| 1h | ليميت | bk_ha_1 | 1 | 0.5 | لا | 0.5 | 81% | 0.13 | 540 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_ha_3 | 1 | 0.5 | لا | 0.5 | 80% | 0.12 | 500 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_lr_20 | 1 | 0.5 | لا | 0.5 | 77% | 0.07 | 194 | BTCUSD EURUSD |
| 1h | ليميت | bk_elder | 1 | 0.5 | لا | 0.5 | 79% | 0.10 | 566 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_vortex | 1 | 0.5 | لا | 0.5 | 75% | 0.04 | 287 | BTCUSD EURUSD |
| 1h | ليميت | bk_cci_trend | 1 | 0.5 | لا | 0.5 | 78% | 0.08 | 388 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_pullback_20_50 | 1 | 0.5 | لا | 0.5 | 77% | 0.06 | 309 | BTCUSD EURUSD |
| 1h | ليميت | bk_pullback_21_55 | 1 | 0.5 | لا | 0.5 | 77% | 0.07 | 305 | BTCUSD EURUSD |
| 1h | ليميت | bk_bb_rev_10_1.5 | 1 | 0.5 | لا | 0.5 | 77% | 0.06 | 453 | BTCUSD EURUSD |
| 1h | ليميت | bk_bb_rsi_30 | 1 | 0.5 | لا | 0.5 | 87% | 0.23 | 46 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_stoch_14_3_3 | 1 | 0.5 | لا | 0.5 | 83% | 0.17 | 316 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_stoch_5_3_3 | 1 | 0.5 | لا | 0.5 | 82% | 0.14 | 303 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_stoch_21_5_5 | 1 | 0.5 | لا | 0.5 | 76% | 0.06 | 238 | EURUSD XAUUSD |
| 1h | ليميت | bk_cci_rev_20 | 1 | 0.5 | لا | 0.5 | 78% | 0.09 | 348 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_wr_14 | 1 | 0.5 | لا | 0.5 | 78% | 0.08 | 403 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_kc_rev | 2.5 | 0.5 | نعم | 0.5 | 71% | 0.02 | 51 | BTCUSD XAUUSD |
| 1h | ليميت | bk_nr4 | 1 | 0.5 | لا | 0.5 | 84% | 0.17 | 396 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_nr7 | 1 | 0.5 | لا | 0.5 | 84% | 0.18 | 245 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_inside_bar | 1 | 0.5 | لا | 0.5 | 78% | 0.08 | 139 | BTCUSD XAUUSD |
| 1h | ليميت | bk_inside_bar_ema | 1 | 0.5 | لا | 0.5 | 78% | 0.09 | 96 | BTCUSD XAUUSD |
| 1h | ليميت | bk_orb | 1 | 0.5 | لا | 0.5 | 80% | 0.10 | 366 | BTCUSD EURUSD |
| 1h | ماركت | bk_ny_mom | 1.5 | 0.5 | لا | - | 73% | 0.04 | 69 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_engulf | 1 | 0.5 | لا | 0.5 | 82% | 0.15 | 393 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_engulf_ema | 1 | 0.5 | لا | 0.5 | 84% | 0.17 | 287 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_three | 1 | 0.5 | لا | 0.5 | 79% | 0.11 | 236 | BTCUSD XAUUSD |
| 1h | ليميت | bk_tweezer | 1 | 0.5 | لا | 0.5 | 82% | 0.15 | 381 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_hhhl_3 | 1 | 0.5 | لا | 0.5 | 79% | 0.11 | 178 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_hhhl_5 | 1 | 0.5 | لا | 0.5 | 80% | 0.13 | 111 | BTCUSD EURUSD |
| 1h | ليميت | bk_retest | 1 | 0.5 | نعم | 0.5 | 83% | 0.17 | 107 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_pivot_brk | 1.5 | 0.5 | لا | 0.5 | 73% | 0.04 | 195 | BTCUSD EURUSD |
| 1h | ليميت | bk_cmb_ema200_rsi50 | 1 | 0.5 | لا | 0.5 | 78% | 0.09 | 205 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_cmb_ema200_stoch | 1 | 0.5 | لا | 0.5 | 81% | 0.13 | 419 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_cmb_ema200_bbmid | 1 | 0.5 | لا | 0.5 | 77% | 0.07 | 319 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_cmb_ema200_ema9 | 1 | 0.5 | لا | 0.5 | 81% | 0.11 | 352 | BTCUSD EURUSD |
| 1h | ليميت | bk_cmb_st_rsi50 | 1 | 0.5 | لا | 0.5 | 75% | 0.03 | 191 | BTCUSD EURUSD |
| 1h | ليميت | bk_cmb_st_stoch | 1 | 0.5 | لا | 0.5 | 81% | 0.13 | 399 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_cmb_st_ema9 | 1 | 0.5 | لا | 0.5 | 82% | 0.14 | 322 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_cmb_adx_stoch | 1 | 0.5 | نعم | 0.5 | 78% | 0.08 | 170 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_cmb_adx_ema9 | 1 | 0.5 | نعم | 0.5 | 82% | 0.13 | 130 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_cmb_ichi_stoch | 1 | 0.5 | لا | 0.5 | 80% | 0.12 | 360 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_cmb_ichi_ema9 | 1 | 0.5 | لا | 0.5 | 80% | 0.12 | 288 | BTCUSD EURUSD |
| 1h | ليميت | bk_smc_choch | 1 | 0.5 | لا | 0.5 | 77% | 0.05 | 160 | BTCUSD EURUSD |
| 1h | ليميت | bk_smc_ob | 1 | 0.5 | لا | 0.5 | 78% | 0.08 | 104 | BTCUSD EURUSD |
| 1h | ليميت | bk_ict_fvg | 1 | 0.5 | لا | 0.5 | 83% | 0.16 | 494 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_ict_silver | 1 | 0.5 | لا | 0.5 | 81% | 0.13 | 32 | BTCUSD EURUSD XAUUSD |
| 1h | ليميت | bk_ict_ote | 1 | 0.5 | لا | 0.5 | 81% | 0.13 | 121 | BTCUSD EURUSD XAUUSD |
| 4h | ليميت | bk_ema_5_13 | 1 | 0.5 | لا | 0.5 | 77% | 0.11 | 184 | EURUSD XAUUSD |
| 4h | ليميت | bk_ema_12_26 | 1 | 0.5 | لا | 0.5 | 88% | 0.29 | 83 | EURUSD XAUUSD |
| 4h | ليميت | bk_ema_21_55 | 1 | 0.75 | لا | 0.5 | 88% | 0.51 | 43 | EURUSD XAUUSD |
| 4h | ليميت | bk_sma_5_20 | 1 | 0.5 | لا | 0.5 | 71% | 0.02 | 150 | EURUSD XAUUSD |
| 4h | ليميت | bk_sma_20_50 | 1 | 0.5 | لا | 0.5 | 80% | 0.17 | 51 | EURUSD XAUUSD |
| 4h | ليميت | bk_px_ema20 | 1 | 0.5 | لا | 0.5 | 79% | 0.14 | 234 | EURUSD XAUUSD |
| 4h | ليميت | bk_px_ema50 | 1 | 0.5 | لا | 0.5 | 78% | 0.14 | 152 | EURUSD XAUUSD |
| 4h | ليميت | bk_px_ema200 | 1 | 0.5 | لا | 0.5 | 85% | 0.24 | 60 | EURUSD XAUUSD |
| 4h | ليميت | bk_ribbon_8_21_55 | 1 | 0.75 | لا | 0.5 | 77% | 0.31 | 82 | EURUSD XAUUSD |
| 4h | ليميت | bk_ribbon_5_13_34 | 1 | 0.5 | لا | 0.5 | 83% | 0.20 | 137 | EURUSD XAUUSD |
| 4h | ليميت | bk_macd_12_26_9 | 1 | 0.5 | لا | 0.5 | 76% | 0.11 | 181 | EURUSD XAUUSD |
| 4h | ليميت | bk_macd_8_17_9 | 1 | 0.5 | لا | 0.5 | 80% | 0.16 | 219 | EURUSD XAUUSD |
| 4h | ليميت | bk_macd_5_35_5 | 1 | 0.5 | لا | 0.5 | 85% | 0.24 | 271 | EURUSD XAUUSD |
| 4h | ليميت | bk_macd_24_52_9 | 1 | 0.5 | لا | 0.5 | 79% | 0.15 | 137 | EURUSD XAUUSD |
| 4h | ليميت | bk_macd0_12_26 | 1 | 0.5 | لا | 0.5 | 88% | 0.29 | 83 | EURUSD XAUUSD |
| 4h | ليميت | bk_adx_20 | 1 | 0.5 | لا | 0.5 | 73% | 0.07 | 142 | EURUSD XAUUSD |
| 4h | ماركت | bk_adx_25 | 2.5 | 0.75 | نعم | - | 64% | 0.11 | 72 | EURUSD XAUUSD |
| 4h | ماركت | bk_adx_30 | 4 | 0.75 | نعم | - | 67% | 0.16 | 48 | EURUSD XAUUSD |
| 4h | ليميت | bk_st_10_2 | 1 | 0.5 | لا | 0.5 | 83% | 0.21 | 153 | EURUSD XAUUSD |
| 4h | ماركت | bk_psar_0.02 | 4 | 0.75 | نعم | - | 60% | 0.07 | 68 | XAUUSD |
| 4h | ليميت | bk_psar_0.02 | 1 | 0.5 | لا | 0.5 | 76% | 0.10 | 207 | EURUSD XAUUSD |
| 4h | ليميت | bk_ichi_cloud | 1 | 0.5 | لا | 0.5 | 83% | 0.22 | 114 | EURUSD XAUUSD |
| 4h | ماركت | bk_ichi_tk | 4 | 1 | نعم | - | 65% | 0.25 | 40 | XAUUSD |
| 4h | ليميت | bk_ichi_tk | 1 | 0.5 | لا | 0.5 | 79% | 0.15 | 118 | EURUSD XAUUSD |
| 4h | ماركت | bk_ichi_full | 4 | 1 | لا | - | 66% | 0.31 | 68 | EURUSD XAUUSD |
| 4h | ليميت | bk_ichi_full | 1 | 0.5 | لا | 0.5 | 79% | 0.16 | 126 | EURUSD XAUUSD |
| 4h | ماركت | bk_hma_9 | 2.5 | 0.75 | نعم | - | 63% | 0.09 | 151 | EURUSD XAUUSD |
| 4h | ليميت | bk_hma_9 | 1 | 0.5 | لا | 0.5 | 80% | 0.17 | 378 | EURUSD XAUUSD |
| 4h | ليميت | bk_hma_21 | 1 | 0.5 | لا | 0.5 | 80% | 0.16 | 275 | EURUSD XAUUSD |
| 4h | ماركت | bk_don_10 | 3 | 0.75 | نعم | - | 63% | 0.10 | 101 | EURUSD XAUUSD |
| 4h | ليميت | bk_don_10 | 1 | 0.5 | لا | 0.5 | 78% | 0.13 | 274 | EURUSD XAUUSD |
| 4h | ليميت | bk_don_20 | 1 | 0.5 | لا | 0.5 | 81% | 0.18 | 186 | EURUSD XAUUSD |
| 4h | ليميت | bk_don_55 | 1 | 0.5 | لا | 0.5 | 78% | 0.14 | 97 | EURUSD XAUUSD |
| 4h | ماركت | bk_kc_brk_20_2 | 2.5 | 0.75 | نعم | - | 63% | 0.08 | 75 | EURUSD XAUUSD |
| 4h | ليميت | bk_kc_brk_20_1.5 | 1 | 0.5 | لا | 0.5 | 81% | 0.18 | 197 | EURUSD XAUUSD |
| 4h | ليميت | bk_bb_brk_20_2 | 1 | 0.75 | لا | 0.5 | 67% | 0.14 | 175 | EURUSD XAUUSD |
| 4h | ليميت | bk_bb_brk_20_2.5 | 1 | 0.75 | لا | 0.5 | 69% | 0.18 | 111 | EURUSD XAUUSD |
| 4h | ماركت | bk_aroon_14 | 3 | 0.75 | نعم | - | 71% | 0.23 | 94 | EURUSD XAUUSD |
| 4h | ليميت | bk_aroon_14 | 1 | 0.5 | لا | 0.5 | 80% | 0.17 | 198 | EURUSD XAUUSD |
| 4h | ماركت | bk_trix_9 | 3 | 0.75 | نعم | - | 71% | 0.23 | 68 | EURUSD XAUUSD |
| 4h | ليميت | bk_trix_9 | 1 | 0.5 | لا | 0.5 | 74% | 0.08 | 171 | EURUSD XAUUSD |
| 4h | ليميت | bk_trix_15 | 1 | 0.5 | لا | 0.5 | 78% | 0.13 | 126 | EURUSD XAUUSD |
| 4h | ماركت | bk_roc_9 | 4 | 0.75 | نعم | - | 64% | 0.12 | 86 | EURUSD XAUUSD |
| 4h | ليميت | bk_roc_9 | 1 | 0.5 | لا | 0.5 | 76% | 0.10 | 287 | EURUSD XAUUSD |
| 4h | ليميت | bk_roc_21 | 1 | 0.5 | لا | 0.5 | 77% | 0.12 | 172 | EURUSD XAUUSD |
| 4h | ماركت | bk_ha_1 | 2.5 | 0.75 | نعم | - | 59% | 0.02 | 164 | EURUSD XAUUSD |
| 4h | ليميت | bk_ha_1 | 1 | 0.5 | لا | 0.5 | 76% | 0.11 | 398 | EURUSD XAUUSD |
| 4h | ليميت | bk_ha_3 | 1 | 0.5 | لا | 0.5 | 83% | 0.21 | 334 | EURUSD XAUUSD |
| 4h | ليميت | bk_lr_20 | 1 | 0.5 | لا | 0.5 | 73% | 0.06 | 133 | XAUUSD |
| 4h | ليميت | bk_elder | 1 | 0.5 | لا | 0.5 | 79% | 0.14 | 414 | EURUSD XAUUSD |
| 4h | ليميت | bk_vortex | 1 | 0.5 | لا | 0.5 | 80% | 0.17 | 214 | EURUSD XAUUSD |
| 4h | ماركت | bk_cci_trend | 3 | 0.75 | نعم | - | 64% | 0.13 | 73 | XAUUSD |
| 4h | ليميت | bk_cci_trend | 1 | 0.5 | لا | 0.5 | 78% | 0.14 | 247 | EURUSD XAUUSD |
| 4h | ماركت | bk_pullback_20_50 | 2.5 | 0.75 | نعم | - | 63% | 0.08 | 104 | EURUSD XAUUSD |
| 4h | ليميت | bk_pullback_20_50 | 1 | 0.5 | لا | 0.5 | 81% | 0.18 | 187 | EURUSD XAUUSD |
| 4h | ماركت | bk_pullback_21_55 | 2.5 | 0.75 | نعم | - | 62% | 0.07 | 100 | EURUSD XAUUSD |
| 4h | ليميت | bk_pullback_21_55 | 1 | 0.5 | لا | 0.5 | 81% | 0.18 | 188 | EURUSD XAUUSD |
| 4h | ليميت | bk_golden_adx | 1 | 0.5 | لا | 0.5 | 80% | 0.16 | 44 | EURUSD XAUUSD |
| 4h | ليميت | bk_rsi_14_30 | 1 | 0.5 | لا | 0.5 | 80% | 0.17 | 110 | EURUSD XAUUSD |
| 4h | ليميت | bk_rsi_14_25 | 1 | 0.5 | لا | 0.5 | 81% | 0.19 | 53 | EURUSD XAUUSD |
| 4h | ليميت | bk_rsi_7_20 | 1 | 0.5 | لا | 0.5 | 79% | 0.15 | 104 | EURUSD XAUUSD |
| 4h | ليميت | bk_rsi_7_30 | 1 | 0.5 | لا | 0.5 | 81% | 0.19 | 209 | EURUSD XAUUSD |
| 4h | ليميت | bk_rsi_2_10 | 1 | 0.5 | لا | 0.5 | 81% | 0.18 | 292 | EURUSD XAUUSD |
| 4h | ليميت | bk_rsi_2_5 | 1 | 0.5 | لا | 0.5 | 79% | 0.15 | 191 | EURUSD XAUUSD |
| 4h | ليميت | bk_connors_10 | 1 | 0.5 | لا | 0.5 | 77% | 0.12 | 126 | EURUSD XAUUSD |
| 4h | ماركت | bk_bb_rev_20_2.5 | 3 | 0.5 | نعم | - | 73% | 0.09 | 26 | XAUUSD |
| 4h | ليميت | bk_bb_rev_20_2.5 | 1 | 0.5 | لا | 0.5 | 75% | 0.09 | 127 | EURUSD XAUUSD |
| 4h | ماركت | bk_bb_rev_10_1.5 | 4 | 0.75 | نعم | - | 62% | 0.10 | 77 | EURUSD XAUUSD |
| 4h | ليميت | bk_bb_rev_10_1.5 | 1 | 0.5 | لا | 0.5 | 82% | 0.20 | 309 | EURUSD XAUUSD |
| 4h | ليميت | bk_bb_rsi_30 | 2 | 0.5 | لا | 0.5 | 77% | 0.14 | 30 | EURUSD |
| 4h | ماركت | bk_stoch_14_3_3 | 4 | 1 | نعم | - | 58% | 0.18 | 48 | EURUSD XAUUSD |
| 4h | ليميت | bk_stoch_14_3_3 | 1 | 0.5 | لا | 0.5 | 81% | 0.18 | 208 | EURUSD XAUUSD |
| 4h | ليميت | bk_stoch_5_3_3 | 1 | 0.5 | لا | 0.5 | 79% | 0.16 | 179 | EURUSD XAUUSD |
| 4h | ليميت | bk_stoch_21_5_5 | 1 | 0.5 | لا | 0.5 | 78% | 0.13 | 175 | EURUSD XAUUSD |
| 4h | ليميت | bk_cci_rev_20 | 1 | 0.5 | لا | 0.5 | 86% | 0.26 | 209 | EURUSD XAUUSD |
| 4h | ماركت | bk_cci_rev_14 | 3 | 1 | نعم | - | 63% | 0.26 | 46 | EURUSD XAUUSD |
| 4h | ليميت | bk_cci_rev_14 | 3 | 1.5 | نعم | 0.25 | 58% | 0.39 | 38 | EURUSD XAUUSD |
| 4h | ليميت | bk_wr_14 | 1 | 0.5 | لا | 0.5 | 80% | 0.17 | 285 | EURUSD XAUUSD |
| 4h | ليميت | bk_wr_28 | 1 | 0.5 | لا | 0.5 | 82% | 0.20 | 217 | EURUSD XAUUSD |
| 4h | ليميت | bk_z_50_2 | 1 | 0.5 | لا | 0.5 | 80% | 0.17 | 131 | EURUSD XAUUSD |
| 4h | ليميت | bk_z_20_2.5 | 1 | 0.5 | لا | 0.5 | 76% | 0.11 | 131 | EURUSD XAUUSD |
| 4h | ليميت | bk_kc_rev | 1 | 0.5 | لا | 0.5 | 80% | 0.16 | 201 | EURUSD XAUUSD |
| 4h | ليميت | bk_squeeze_1.5 | 1 | 0.75 | لا | 0.5 | 76% | 0.28 | 74 | EURUSD XAUUSD |
| 4h | ليميت | bk_squeeze_2 | 1 | 0.75 | لا | 0.5 | 66% | 0.11 | 125 | EURUSD XAUUSD |
| 4h | ليميت | bk_nr4 | 1 | 0.5 | لا | 0.5 | 79% | 0.15 | 245 | EURUSD XAUUSD |
| 4h | ماركت | bk_nr7 | 3 | 0.75 | نعم | - | 64% | 0.11 | 67 | EURUSD XAUUSD |
| 4h | ليميت | bk_nr7 | 1 | 0.5 | لا | 0.5 | 77% | 0.11 | 154 | EURUSD XAUUSD |
| 4h | ليميت | bk_atr_expand | 1 | 0.5 | لا | 0.5 | 78% | 0.13 | 161 | EURUSD XAUUSD |
| 4h | ليميت | bk_pdhl | 1 | 0.5 | لا | 0.5 | 79% | 0.15 | 296 | EURUSD XAUUSD |
| 4h | ليميت | bk_ny_mom | 1 | 0.5 | لا | 0.5 | 88% | 0.28 | 48 | EURUSD XAUUSD |
| 4h | ليميت | bk_engulf | 1 | 0.5 | لا | 0.5 | 82% | 0.19 | 236 | EURUSD XAUUSD |
| 4h | ليميت | bk_engulf_ema | 1 | 0.5 | لا | 0.5 | 84% | 0.23 | 171 | EURUSD XAUUSD |
| 4h | ماركت | bk_pin | 3 | 0.75 | نعم | - | 62% | 0.07 | 37 | EURUSD XAUUSD |
| 4h | ماركت | bk_three | 2.5 | 0.75 | نعم | - | 60% | 0.04 | 95 | EURUSD |
| 4h | ليميت | bk_three | 1 | 0.5 | لا | 0.5 | 84% | 0.22 | 182 | EURUSD XAUUSD |
| 4h | ماركت | bk_tweezer | 4 | 1 | نعم | - | 61% | 0.23 | 74 | EURUSD XAUUSD |
| 4h | ليميت | bk_tweezer | 1 | 0.5 | لا | 0.5 | 80% | 0.16 | 266 | EURUSD XAUUSD |
| 4h | ليميت | bk_outside | 1 | 0.5 | لا | 0.5 | 75% | 0.09 | 193 | EURUSD XAUUSD |
| 4h | ليميت | bk_retest | 1 | 0.5 | لا | 0.5 | 82% | 0.20 | 131 | EURUSD XAUUSD |
| 4h | ليميت | bk_fib618 | 1 | 0.5 | لا | 0.5 | 84% | 0.22 | 91 | EURUSD XAUUSD |
| 4h | ليميت | bk_pivot_bounce | 1 | 0.5 | لا | 0.5 | 79% | 0.15 | 251 | EURUSD XAUUSD |
| 4h | ليميت | bk_pivot_brk | 1 | 0.5 | لا | 0.5 | 80% | 0.17 | 307 | EURUSD XAUUSD |
| 4h | ماركت | bk_cmb_ema200_stoch | 2.5 | 0.75 | لا | - | 58% | 0.01 | 190 | EURUSD |
| 4h | ليميت | bk_cmb_ema200_stoch | 1 | 0.5 | لا | 0.5 | 81% | 0.18 | 281 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_ema200_macd | 1 | 0.5 | لا | 0.5 | 77% | 0.12 | 96 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_ema200_bbmid | 1 | 0.5 | لا | 0.5 | 77% | 0.13 | 181 | EURUSD XAUUSD |
| 4h | ماركت | bk_cmb_ema200_ema9 | 2.5 | 0.75 | لا | - | 63% | 0.10 | 169 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_ema200_ema9 | 1 | 0.5 | لا | 0.5 | 74% | 0.08 | 214 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_st_stoch | 1 | 0.5 | لا | 0.5 | 77% | 0.12 | 267 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_st_macd | 1 | 0.75 | نعم | 0.5 | 68% | 0.15 | 37 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_st_bbmid | 1 | 0.5 | لا | 0.5 | 78% | 0.13 | 205 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_st_ema9 | 1 | 0.5 | لا | 0.5 | 74% | 0.07 | 193 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_adx_stoch | 1 | 0.5 | لا | 0.5 | 80% | 0.17 | 148 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_adx_macd | 1.5 | 0.5 | لا | 0.5 | 78% | 0.14 | 45 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_adx_bbmid | 1.5 | 0.5 | لا | 0.5 | 74% | 0.09 | 84 | XAUUSD |
| 4h | ليميت | bk_cmb_ichi_stoch | 1 | 0.5 | لا | 0.5 | 79% | 0.15 | 255 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_ichi_macd | 1 | 0.5 | لا | 0.5 | 83% | 0.21 | 88 | EURUSD XAUUSD |
| 4h | ماركت | bk_cmb_ichi_bbmid | 2.5 | 0.75 | نعم | - | 60% | 0.04 | 88 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_ichi_bbmid | 1 | 0.5 | لا | 0.5 | 80% | 0.16 | 173 | EURUSD XAUUSD |
| 4h | ليميت | bk_cmb_ichi_ema9 | 1 | 0.5 | لا | 0.5 | 76% | 0.11 | 189 | EURUSD XAUUSD |
| 4h | ليميت | bk_smc_bos_3 | 1 | 0.5 | لا | 0.5 | 74% | 0.07 | 120 | EURUSD XAUUSD |
| 4h | ليميت | bk_smc_bos_5 | 1 | 0.5 | لا | 0.5 | 76% | 0.10 | 99 | EURUSD XAUUSD |
| 4h | ليميت | bk_smc_choch | 1 | 0.5 | لا | 0.5 | 82% | 0.18 | 108 | EURUSD XAUUSD |
| 4h | ماركت | bk_smc_ob | 2.5 | 0.75 | لا | - | 61% | 0.06 | 59 | XAUUSD |
| 4h | ليميت | bk_smc_ob | 1 | 0.5 | لا | 0.5 | 82% | 0.21 | 68 | EURUSD XAUUSD |
| 4h | ماركت | bk_smc_sweep | 3 | 0.75 | لا | - | 60% | 0.04 | 137 | EURUSD |
| 4h | ليميت | bk_smc_sweep | 1 | 0.5 | لا | 0.5 | 80% | 0.16 | 200 | EURUSD XAUUSD |
| 4h | ليميت | bk_ict_fvg | 1 | 0.5 | لا | 0.5 | 81% | 0.18 | 373 | EURUSD XAUUSD |
| 4h | ليميت | bk_ict_ote | 1 | 0.5 | لا | 0.5 | 82% | 0.20 | 79 | EURUSD XAUUSD |
| 4h | ليميت | bk_ict_judas | 1 | 0.5 | لا | 0.5 | 78% | 0.14 | 176 | EURUSD XAUUSD |
| 1D | ليميت | bk_ema_5_13 | 1 | 0.5 | لا | 0.5 | 82% | 0.21 | 44 | EURUSD |
| 1D | ليميت | bk_sma_5_20 | 1.5 | 0.5 | لا | 0.5 | 82% | 0.22 | 39 | EURUSD |
| 1D | ليميت | bk_px_ema20 | 1 | 0.5 | لا | 0.5 | 88% | 0.31 | 51 | EURUSD |
| 1D | ماركت | bk_px_ema50 | 1 | 1 | لا | - | 65% | 0.29 | 26 | EURUSD |
| 1D | ليميت | bk_macd_8_17_9 | 1 | 0.5 | لا | 0.5 | 92% | 0.36 | 49 | EURUSD |
| 1D | ليميت | bk_macd0_8_17 | 1 | 0.5 | لا | 0.5 | 88% | 0.30 | 24 | EURUSD |
| 1D | ليميت | bk_adx_20 | 1 | 0.5 | لا | 0.5 | 95% | 0.41 | 20 | EURUSD |
| 1D | ليميت | bk_st_14_2.5 | 1 | 0.75 | لا | 0.5 | 68% | 0.18 | 22 | EURUSD |
| 1D | ليميت | bk_ichi_cloud | 1 | 0.5 | لا | 0.5 | 91% | 0.35 | 23 | EURUSD |
| 1D | ماركت | bk_ichi_tk | 2 | 0.75 | لا | - | 75% | 0.30 | 24 | EURUSD |
| 1D | ليميت | bk_ichi_tk | 1 | 0.5 | لا | 0.5 | 93% | 0.38 | 28 | EURUSD |
| 1D | ليميت | bk_ichi_full | 1 | 0.75 | لا | 0.5 | 76% | 0.31 | 29 | EURUSD |
| 1D | ليميت | bk_hma_9 | 1 | 0.5 | لا | 0.5 | 95% | 0.41 | 80 | EURUSD |
| 1D | ليميت | bk_hma_21 | 1 | 0.5 | لا | 0.5 | 91% | 0.35 | 55 | EURUSD |
| 1D | ليميت | bk_don_10 | 1 | 0.5 | لا | 0.5 | 87% | 0.29 | 54 | EURUSD |
| 1D | ليميت | bk_don_20 | 1 | 0.5 | لا | 0.5 | 94% | 0.40 | 34 | EURUSD |
| 1D | ليميت | bk_kc_brk_20_2 | 1 | 0.5 | لا | 0.5 | 91% | 0.35 | 22 | EURUSD |
| 1D | ليميت | bk_kc_brk_20_1.5 | 1 | 0.5 | لا | 0.5 | 94% | 0.39 | 33 | EURUSD |
| 1D | ليميت | bk_bb_brk_20_2 | 1 | 0.5 | لا | 0.5 | 94% | 0.39 | 31 | EURUSD |
| 1D | ماركت | bk_aroon_25 | 4 | 0.5 | لا | - | 81% | 0.21 | 21 | EURUSD |
| 1D | ماركت | bk_trix_9 | 2 | 0.75 | لا | - | 63% | 0.09 | 43 | EURUSD |
| 1D | ليميت | bk_trix_9 | 1 | 0.75 | لا | 0.5 | 73% | 0.26 | 37 | EURUSD |
| 1D | ليميت | bk_roc_21 | 1 | 0.5 | لا | 0.5 | 92% | 0.37 | 25 | EURUSD |
| 1D | ليميت | bk_ha_1 | 1 | 0.5 | لا | 0.5 | 96% | 0.42 | 71 | EURUSD |
| 1D | ماركت | bk_ha_3 | 4 | 0.75 | لا | - | 65% | 0.16 | 23 | EURUSD |
| 1D | ليميت | bk_ha_3 | 1 | 0.5 | لا | 0.5 | 88% | 0.30 | 80 | EURUSD |
| 1D | ليميت | bk_elder | 1 | 0.5 | لا | 0.5 | 91% | 0.34 | 75 | EURUSD |
| 1D | ليميت | bk_cci_trend | 1 | 0.5 | لا | 0.5 | 88% | 0.31 | 43 | EURUSD |
| 1D | ماركت | bk_rsi_14_30 | 1.5 | 0.5 | لا | - | 73% | 0.08 | 22 | EURUSD |
| 1D | ليميت | bk_rsi_2_10 | 1 | 1 | نعم | 0.5 | 65% | 0.28 | 17 | EURUSD |
| 1D | ليميت | bk_rsi_2_5 | 1 | 0.5 | لا | 0.5 | 89% | 0.32 | 45 | EURUSD |
| 1D | ليميت | bk_bb_rev_10_1.5 | 1 | 1 | نعم | 0.5 | 70% | 0.38 | 20 | EURUSD |
| 1D | ليميت | bk_stoch_14_3_3 | 1.5 | 0.5 | لا | 0.5 | 71% | 0.05 | 48 | EURUSD |
| 1D | ليميت | bk_stoch_5_3_3 | 1 | 0.5 | لا | 0.5 | 88% | 0.30 | 48 | EURUSD |
| 1D | ليميت | bk_stoch_21_5_5 | 1 | 0.5 | لا | 0.5 | 86% | 0.28 | 36 | EURUSD |
| 1D | ليميت | bk_cci_rev_20 | 1 | 0.5 | لا | 0.5 | 89% | 0.32 | 45 | EURUSD |
| 1D | ليميت | bk_cci_rev_14 | 1 | 0.5 | لا | 0.25 | 82% | 0.21 | 22 | EURUSD |
| 1D | ليميت | bk_z_20_2 | 1 | 0.5 | لا | 0.5 | 93% | 0.37 | 40 | EURUSD |
| 1D | ليميت | bk_z_50_2 | 1 | 0.75 | لا | 0.5 | 72% | 0.25 | 29 | EURUSD |
| 1D | ماركت | bk_squeeze_2 | 2.5 | 0.75 | لا | - | 67% | 0.16 | 24 | EURUSD |
| 1D | ليميت | bk_squeeze_2 | 1 | 0.5 | لا | 0.5 | 91% | 0.34 | 21 | EURUSD |
| 1D | ليميت | bk_nr4 | 1 | 0.5 | لا | 0.5 | 89% | 0.32 | 63 | EURUSD |
| 1D | ليميت | bk_nr7 | 1 | 0.5 | لا | 0.5 | 90% | 0.34 | 50 | EURUSD |
| 1D | ليميت | bk_pdhl | 1 | 0.75 | لا | 0.5 | 78% | 0.35 | 81 | EURUSD |
| 1D | ليميت | bk_three | 1 | 0.5 | لا | 0.25 | 80% | 0.18 | 54 | EURUSD |
| 1D | ليميت | bk_cmb_ema200_stoch | 1 | 0.75 | نعم | 0.5 | 73% | 0.27 | 30 | EURUSD |
| 1D | ليميت | bk_cmb_ema200_bbmid | 1 | 0.5 | لا | 0.5 | 90% | 0.33 | 48 | EURUSD |
| 1D | ليميت | bk_cmb_ema200_ema9 | 1 | 0.5 | لا | 0.5 | 84% | 0.24 | 50 | EURUSD |
| 1D | ليميت | bk_cmb_st_stoch | 1 | 0.75 | لا | 0.5 | 72% | 0.24 | 53 | EURUSD |
| 1D | ليميت | bk_cmb_st_bbmid | 1 | 0.5 | لا | 0.5 | 90% | 0.33 | 40 | EURUSD |
| 1D | ليميت | bk_cmb_st_ema9 | 1 | 0.5 | لا | 0.5 | 81% | 0.21 | 43 | EURUSD |
| 1D | ليميت | bk_cmb_adx_stoch | 1 | 0.75 | لا | 0.5 | 75% | 0.30 | 20 | EURUSD |
| 1D | ليميت | bk_cmb_ichi_stoch | 1 | 0.75 | لا | 0.5 | 80% | 0.39 | 46 | EURUSD |
| 1D | ليميت | bk_cmb_ichi_bbmid | 1 | 0.5 | لا | 0.5 | 90% | 0.33 | 40 | EURUSD |
| 1D | ليميت | bk_cmb_ichi_ema9 | 1 | 0.5 | لا | 0.5 | 83% | 0.23 | 41 | EURUSD |
| 1D | ماركت | bk_smc_choch | 1 | 0.75 | لا | - | 64% | 0.10 | 25 | EURUSD |
| 1D | ليميت | bk_ict_fvg | 1 | 0.5 | لا | 0.25 | 77% | 0.13 | 111 | EURUSD |
| 1D | ليميت | bk_ict_ote | 1 | 0.5 | لا | 0.5 | 88% | 0.30 | 24 | EURUSD |
