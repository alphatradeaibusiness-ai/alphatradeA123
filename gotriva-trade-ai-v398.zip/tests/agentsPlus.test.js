import { test } from 'node:test';
import assert from 'node:assert/strict';
import { currenciesOf, newsSoon, whatIf } from '../src/pages/agentsPlus.js';

test('v389 currencies behind a symbol', () => {
  assert.deepEqual(currenciesOf('EURUSD'), ['EUR', 'USD']);
  assert.ok(currenciesOf('XAUUSD').includes('USD'));
});
test('v389 news warning: only high impact, matching currency, within the hour', () => {
  const now = 1_000_000_000_000; const ev = (m, c, i = 'High') => ({ title: 'x', country: c, impact: i, time: now + m * 60_000 });
  const r = newsSoon([ev(30, 'USD'), ev(30, 'JPY'), ev(30, 'EUR', 'Medium'), ev(90, 'USD'), ev(-20, 'USD')], 'EURUSD', now);
  assert.equal(r.length, 1); assert.equal(r[0].country, 'USD');
});
test('v389 what-if compounds the same % risk per R', () => {
  const w = whatIf([{ r: 2 }, { r: -1 }], 1000, 1);
  assert.equal(Math.round(w.end * 100) / 100, 1009.8); assert.equal(w.n, 2); assert.equal(w.winRate, 50);
  assert.ok(Math.abs(w.maxDD - 1) < 1e-9);
  assert.equal(whatIf([], 1000, 1).winRate, null);
});
