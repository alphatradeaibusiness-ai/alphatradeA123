// v379 account opening: tier 1 needs a document photo (both sides for an ID card) and a selfie; photos are sealed at rest,
// only the owner can open them, and every view is audited.
import test from 'node:test';
import assert from 'node:assert/strict';
import { openDb } from '../server/bank/db.js';
import { createVault } from '../server/bank/vault.js';
import { createBank } from '../server/bank/service.js';
import { TEST_DOCS, TEST_PHONE } from './kycDocs.fixture.js';

const ADDR = { country: 'DE', region: 'BE', city: 'Berlin', postal: '10115', line1: 'Invalidenstrasse 1' };
const base = { tier: 1, fullName: 'Ada Lovelace', dob: '1990-05-05', nationality: 'DE', address: ADDR, idType: 'passport', idNumber: 'X12345678', idExpiry: '2031-01-01', phone: TEST_PHONE, docs: TEST_DOCS };
const code = (fn) => { try { fn(); } catch (e) { return e.code; } return 'NO_ERROR'; };
const setup = () => { const db = openDb(':memory:'); return { db, bank: createBank({ db, vault: createVault({ secret: 'z'.repeat(40) }), mode: 'sandbox', now: () => Date.UTC(2026, 10, 1) }) }; };

test('tier 1 needs the document photo, the back of an ID card, a selfie and a phone number', () => {
  const { bank } = setup();
  assert.equal(code(() => bank.submitKyc('u1', { ...base, docs: { selfie: TEST_DOCS.selfie } })), 'bad_doc_front');
  assert.equal(code(() => bank.submitKyc('u1', { ...base, docs: { front: TEST_DOCS.front } })), 'bad_doc_selfie');
  assert.equal(code(() => bank.submitKyc('u1', { ...base, idType: 'national_id' })), 'bad_doc_back');
  assert.equal(code(() => bank.submitKyc('u1', { ...base, phone: '0791234567' })), 'bad_phone');
  const fake = `data:image/jpeg;base64,${Buffer.alloc(4000, 1).toString('base64')}`;   // not a JPEG
  assert.equal(code(() => bank.submitKyc('u1', { ...base, docs: { ...TEST_DOCS, front: fake } })), 'bad_doc_front');
  assert.equal(bank.submitKyc('u1', base, { email: 'ada@example.com' }).status, 'pending');
});

test('photos are sealed at rest; only the owner opens them (audited); the contact e-mail is kept for the decision mail', () => {
  const { bank, db } = setup();
  bank.submitKyc('u1', base, { email: 'ada@example.com' });
  const raw = db.prepare('SELECT data FROM kyc_docs WHERE uid = ?').all('u1').map((r) => r.data).join('');
  assert.ok(!raw.includes(TEST_DOCS.front.split(',')[1].slice(0, 40)), 'stored encrypted');
  assert.equal(code(() => bank.kycDocs({ uid: 'u1' }, 'u1')), 'self_action_not_allowed');
  const d = bank.kycDocs({ uid: 'owner' }, 'u1');
  assert.deepEqual(d.items.map((x) => x.kind).sort(), ['front', 'selfie']); assert.equal(d.items.find((x) => x.kind === 'front').url, TEST_DOCS.front);
  assert.ok(bank.audit.recent(20).some((r) => r.action === 'kyc.view_docs'));
  assert.equal(bank.kycContact('u1').email, 'ada@example.com');
});
