import test from 'node:test';
import assert from 'node:assert/strict';
import { ofBias, ofVerdict, schoolConfirm } from '../src/services/ofVerdict.js';

const cands = (delta, n = 20) => Array.from({ length: n }, () => ({ buy: 100 + delta / 2, sell: 100 - delta / 2, delta, close: 100 }));
const book = (bid, ask) => ({ bids: [[99.9, bid], [99.5, 1]], asks: [[100.1, ask], [100.5, 1]] });

test('too little data says «collecting», never a guess', () => {
  assert.equal(ofVerdict({ bias: ofBias({ candles: cands(50, 5), book: book(5, 1), price: 100 }), price: 100, atr: 1 }).action, 'collecting');
  assert.equal(ofVerdict({ bias: ofBias({ candles: cands(50), book: null, price: 100 }), price: 100, atr: 1 }).action, 'collecting');
});

test('strong buying + bids → BUY with stop below and targets above; selling → SELL the other way; balanced → WAIT', () => {
  const b = ofVerdict({ bias: ofBias({ candles: cands(80), book: book(9, 1), price: 100, poc: 99 }), price: 100, atr: 1 });
  assert.equal(b.action, 'buy'); assert.ok(b.plan.stop < 100 && b.plan.tp1 > 100 && b.plan.tp2 > b.plan.tp1);
  const s = ofVerdict({ bias: ofBias({ candles: cands(-80), book: book(1, 9), price: 100, poc: 101 }), price: 100, atr: 1 });
  assert.equal(s.action, 'sell'); assert.ok(s.plan.stop > 100 && s.plan.tp1 < 100 && s.plan.tp2 < s.plan.tp1);
  assert.equal(ofVerdict({ bias: ofBias({ candles: cands(0), book: book(1, 1), price: 100, poc: 100 }), price: 100, atr: 1 }).action, 'wait');
});

test('with SMC / ICT: agree → trade, against → «don\'t buy now», no signal → wait for it', () => {
  const bias = ofBias({ candles: cands(80), book: book(9, 1), price: 100, poc: 99 });
  assert.equal(ofVerdict({ bias, mode: 'smc', confirm: { dir: 1 }, price: 100, atr: 1 }).action, 'buy');
  assert.equal(ofVerdict({ bias, mode: 'smc', confirm: { dir: -1 }, price: 100, atr: 1 }).action, 'no_buy');
  const w = ofVerdict({ bias, mode: 'ict', confirm: { dir: 0 }, price: 100, atr: 1 }); assert.equal(w.action, 'wait'); assert.equal(w.need, 'ict');
});

test('the school confirmation only uses that school\'s rules (SMC and ICT never mixed)', () => {
  let p = 100; const cs = Array.from({ length: 300 }, (_, i) => { const o = p; p *= 1 + Math.sin(i / 7) * 0.004; return { time: 1700000000 + i * 300, open: o, high: Math.max(o, p) * 1.001, low: Math.min(o, p) * 0.999, close: p, volume: 10 }; });
  for (const sc of ['smc', 'ict']) { const r = schoolConfirm(cs, sc); assert.ok(r.rules.every((x) => x.id.startsWith(`bk_${sc}_`)), sc); }
  assert.equal(schoolConfirm(cs, 'other').n, 0);
});
