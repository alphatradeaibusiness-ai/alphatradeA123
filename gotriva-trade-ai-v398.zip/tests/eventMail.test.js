// v393 every bank / payment event has its own e-mail; the bank hands each event to the mail hook once.
import test from 'node:test';
import assert from 'node:assert/strict';
import { KIND_GROUP } from '../server/bank/features/notify.js';
import { TEMPLATES, renderEvent } from '../server/eventMail.js';
import { openDb } from '../server/bank/db.js';
import { createVault } from '../server/bank/vault.js';
import { createBank } from '../server/bank/service.js';
import { TEST_DOCS, TEST_PHONE } from './kycDocs.fixture.js';

test('v393 a template for every e-mailed bank event, each with its own subject', () => {
  const kinds = Object.entries(KIND_GROUP).filter(([k, g]) => g !== 'trading' && !['kyc_approved', 'kyc_rejected', 'points_earned'].includes(k)).map(([k]) => k);
  const missing = kinds.filter((k) => !TEMPLATES[k]); assert.deepEqual(missing, []);
  const subjects = Object.values(TEMPLATES).map((t) => t[0]); assert.equal(new Set(subjects).size, subjects.length, 'no two events share a subject');
  const m = renderEvent('transfer_received', { amount: 4500, currency: 'USD', name: 'Rami H.' }, { url: 'https://x.test/' });
  assert.match(m.subject, /وصلتك مصاري/); assert.match(m.text, /45\.00 USD/); assert.match(m.text, /Rami H\./); assert.match(m.text, /https:\/\/x\.test\/#\/app\/bank/);
  assert.doesNotMatch(renderEvent('card_purchase', { amount: 1999, currency: 'USD', merchant: 'Shop' }).text, /\{/);
});

test('v393 bank events reach the mail hook: transfer (both sides), withdrawal request', () => {
  let t = Date.UTC(2026, 9, 27, 12); const db = openDb(':memory:');
  const bank = createBank({ db, vault: createVault({ secret: 'z'.repeat(40) }), mode: 'sandbox', now: () => t, priceFn: async () => ({ price: 1, ts: t }) });
  const ADDR = { country: 'DE', region: 'BE', city: 'Berlin', postal: '10115', line1: 'Invalidenstrasse 1' };
  for (const [u, n] of [['m1', 'Rami Haddad'], ['m2', 'Sami Khalil']]) { bank.submitKyc(u, { tier: 1, fullName: n, dob: '1990-05-05', nationality: 'DE', address: ADDR, idType: 'passport', phone: TEST_PHONE, docs: TEST_DOCS, idNumber: 'C' + Buffer.from(u + n).toString('hex').slice(0, 14), idExpiry: '2031-01-01', sourceOfFunds: 'salary', proofOfAddressRef: 'vend-123' }); bank.reviewKyc({ uid: 'owner' }, u, 'approve'); }
  const got = []; bank.notifications.setMailHook((uid, kind, p) => got.push([uid, kind, p.amount, p.name]));
  bank.sandboxFund('m1', { currency: 'USD', amount: '100', idem: 'fund-mail-0001' });
  bank.p2p('m1', 'm2', { amount: '25', idem: 'p2p-mail-0001' });
  bank.p2p('m1', 'm2', { amount: '25', idem: 'p2p-mail-0001' });   // replay: no second e-mail
  assert.deepEqual(got.filter((g) => g[1].startsWith('transfer')), [['m2', 'transfer_received', 2500, 'Rami H.'], ['m1', 'transfer_sent', 2500, 'Sami K.']]);
  assert.ok(!got.some((g) => g[1] === 'kyc_approved'), 'KYC has its own e-mails');
});
