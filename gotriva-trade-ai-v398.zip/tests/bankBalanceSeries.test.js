// v369 overview: month-end balances come from the real ledger (wallet + held + pockets + vault), valued at today's rates.
import test from 'node:test';
import assert from 'node:assert/strict';
import { openDb } from '../server/bank/db.js';
import { createVault } from '../server/bank/vault.js';
import { createBank } from '../server/bank/service.js';

test('dashboard(12): balanceUsd per month end matches the ledger', async () => {
  let t = Date.UTC(2026, 8, 15, 12); const db = openDb(':memory:');
  const bank = createBank({ db, vault: createVault({ secret: 'z'.repeat(40) }), mode: 'sandbox', now: () => t,
    priceFn: async () => ({ price: 50000, ts: t }), rateFn: async () => ({ usdPer: { USD: 1, EUR: 1.1, USDT: 1, BTC: 50000 }, ts: t, sources: {} }) });
  let n = 0; const fund = (cur, amount) => bank.sandboxFund('u1', { currency: cur, amount, idem: `k-${++n}-abcdef` });
  fund('USD', '100');                 // September: $100
  t = Date.UTC(2026, 9, 10, 12); fund('EUR', '50');    // October: +€50 = $55
  t = Date.UTC(2026, 10, 20, 12); fund('USD', '10');   // November (now): +$10
  const d = await bank.insights.dashboard('u1', { months: 12 });
  assert.equal(d.cashflow.length, 12);
  const by = Object.fromEntries(d.cashflow.map((r) => [r.month, r.balanceUsd]));
  assert.equal(by['2026-08'], 0); assert.equal(by['2026-09'], 100); assert.equal(by['2026-10'], 155); assert.equal(by['2026-11'], 165);
  assert.equal(Math.round(d.netWorthUsd * 100) / 100, 165, 'the last point equals today\'s total');
  const d6 = await bank.insights.dashboard('u1'); assert.equal(d6.cashflow.length, 6, 'the old Insights tab still gets 6 months');
});

test('daily balances, merchants and card controls are real', async () => {
  let t = Date.UTC(2026, 10, 1, 12); const db = openDb(':memory:');
  const bank = createBank({ db, vault: createVault({ secret: 'z'.repeat(40) }), mode: 'sandbox', now: () => t,
    priceFn: async () => ({ price: 50000, ts: t }), rateFn: async () => ({ usdPer: { USD: 1, EUR: 1.1, USDT: 1, BTC: 50000 }, ts: t, sources: {} }) });
  let n = 0; bank.sandboxFund('u2', { currency: 'USD', amount: '40', idem: `q-${++n}-abcdef` });
  t += 5 * 86_400_000; bank.sandboxFund('u2', { currency: 'USD', amount: '60', idem: `q-${++n}-abcdef` });
  const d = await bank.insights.balanceDaily('u2', 30);
  assert.equal(d.points.length, 31); assert.equal(d.points.at(-1).usd, 100); assert.equal(d.points.at(-5).usd, 40); assert.equal(d.points.at(-7).usd, 0); assert.equal(d.points[0].usd, 0);
  assert.deepEqual(bank.insights.merchants('u2').items, []);
});
