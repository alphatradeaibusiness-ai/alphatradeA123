import test from 'node:test';
import assert from 'node:assert/strict';
import { runBook, bookPlan, BOOK, BOOK_SIZE, indicators, replay, CORE, CORE_IDS, trendOf, TESTED, REMOVED, TF_OF } from '../src/services/strategyBook.js';
import { strategyOf } from '../src/config/aiSignalRules.js';

function candles(n, drift, seed = 11) {
  let s = seed; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const out = []; let p = 100;
  for (let i = 0; i < n; i++) { const o = p; p *= 1 + (r() - 0.5) * 0.01 + drift; out.push({ time: 1700000000 + i * 300, open: o, high: Math.max(o, p) * (1 + r() * 0.003), low: Math.min(o, p) * (1 - r() * 0.003), close: p, volume: 50 + r() * 100 }); }
  return out;
}

test('the book has more than 100 strategies with unique ids and names', () => {
  assert.ok(BOOK_SIZE >= 100, `${BOOK_SIZE}`);   // v398: 126 left after removing the 28 that failed
  assert.equal(new Set(BOOK.map((s) => s.id)).size, BOOK_SIZE);
  for (const s of BOOK) { assert.ok(s.name.ar && s.name.en, s.id); assert.ok(strategyOf(s.id)?.status === 'book', s.id); }
});

test('SMC and ICT rules are never mixed', () => {
  for (const s of BOOK) {
    const smc = /SMC/.test(s.name.en), ict = /ICT/.test(s.name.en);
    assert.ok(!(smc && ict), s.id);
    if (smc) assert.equal(s.school, 'smc'); if (ict) assert.equal(s.school, 'ict');
  }
});

test('v398 only tested entries: right timeframe, order type and market; 56%+ wins; removed rules never run', () => {
  for (const t of TESTED) {
    assert.ok(t.win >= 0.56 && t.avg > 0 && t.n >= 10, `${t.id} ${t.tf}`); assert.ok(['market', 'limit'].includes(t.order));
    assert.ok(t.sa > 0 && t.tp > 0 && Object.values(TF_OF).includes(t.tf)); assert.ok(t.mk.length > 0);
    assert.ok(BOOK.some((s) => s.id === t.id), `${t.id} exists`);
  }
  for (const id of REMOVED) assert.ok(!BOOK.some((s) => s.id === id), id);
  for (const drift of [0.0008, -0.0008, 0]) {
    const cs = candles(600, drift, 3 + Math.round(drift * 1e4));
    const I = indicators(cs); for (const s of BOOK) for (let i = 210; i < cs.length; i++) s.f(I, i);   // no rule throws
    for (const [tfSec, tf] of Object.entries(TF_OF)) for (const o of ['market', 'limit']) for (const asset of ['forex', 'metal', 'crypto']) {
      const r = runBook(cs, { costPct: 0.05, tfSec: +tfSec, asset, execution: o });
      const sym = { forex: 'EURUSD', metal: 'XAUUSD', crypto: 'BTCUSD' }[asset];
      const pool = TESTED.filter((x) => x.tf === tf && x.order === o && x.mk.includes(sym));
      assert.equal(r.size, pool.length);
      if (!pool.length) assert.equal(r.why, 'none_tested');
      if (r.pick) { assert.equal(r.pick.order, o); assert.equal(r.pick.cfg.tf, tf); assert.ok(r.pick.cfg.mk.includes(sym)); assert.ok(r.pick.rec.winRate >= 0.56);
        if (r.pick.cfg.trend) assert.equal(r.pick.dir, trendOf(I, I.n - 1)); assert.ok(!(r.longs && r.shorts)); }
    }
  }
  assert.equal(runBook(candles(100, 0)).pick, null);
  assert.equal(CORE.length, CORE_IDS.length, 'every tested id exists in the library');
  assert.equal(runBook(candles(600, 0.0008, 11), { tfSec: 3600, asset: 'index' }).why, 'untested');
});

test('v398 plan: the tested stop (sa × ATR) and target (tp × risk); market near the signal, limit lk × ATR better; right sides', () => {
  const cs = candles(400, 0.0005); const close = cs.at(-1).close; const a = indicators(cs).atr(14).at(-1);
  for (const dir of [1, -1]) {
    const mk = { dir, rec: { n: 40, winRate: 0.7, avgR: 0.1 }, cfg: { sa: 1.5, tp: 0.75, order: 'market', lk: 0 } };
    const near = bookPlan(mk, cs, { price: close, costPct: 0.05 }); assert.equal(near.order, 'market'); assert.equal(near.entry, close);
    assert.ok(Math.abs(Math.abs(near.stop - near.entry) - 1.5 * a) < 1e-9); assert.ok(Math.abs(Math.abs(near.targets[0] - near.entry) - 0.75 * 1.5 * a) < 1e-9);
    const far = bookPlan(mk, cs, { price: close + dir * a, costPct: 0.05 }); assert.equal(far.order, 'limit'); assert.equal(far.entry, close);
    const lim = bookPlan({ ...mk, cfg: { sa: 1, tp: 0.5, order: 'limit', lk: 0.25 } }, cs, { price: close, costPct: 0.05 });
    assert.equal(lim.order, 'limit'); assert.ok(Math.abs(lim.entry - (close - dir * 0.25 * a)) < 1e-9); assert.ok(Math.abs(Math.abs(lim.stop - lim.entry) - a) < 1e-9);
    for (const pl of [near, far, lim]) {
      if (dir > 0) { assert.ok(pl.stop < pl.entry); pl.targets.forEach((t) => assert.ok(t > pl.entry)); }
      else { assert.ok(pl.stop > pl.entry); pl.targets.forEach((t) => assert.ok(t < pl.entry)); }
      assert.equal(pl.execution, pl.order); assert.ok(Number.isFinite(pl.rrMain));
    }
  }
});

test('replay counts costs and never looks ahead', () => {
  const cs = candles(500, 0.0003); const I = indicators(cs);
  const s = BOOK.find((x) => x.id === 'bk_ema_50_200');
  const a = replay(I, s, { costPct: 0 }), b = replay(I, s, { costPct: 0.2 });
  assert.ok(a.n > 0 && a.n === b.n); assert.ok(b.avgR < a.avgR);
  // changing a future candle does not change a signal computed at an earlier bar
  const I2 = indicators(cs.map((c, i) => (i === 450 ? { ...c, close: c.close * 1.2, high: c.high * 1.2 } : c)));
  for (let i = 220; i < 449; i++) assert.equal(s.f(I, i), s.f(I2, i));
});

test('the owner engine report renders when the main trade comes from the book (it used to throw and freeze the page)', async () => {
  const { engineHtml } = await import('../src/components/aiEngineReport.js');
  const { runAllStrategies } = await import('../src/services/multiStrategy.js');
  const cs = candles(600, 0.0002).map((c, i, a) => ({ ...c, time: Math.floor(Date.now() / 1000) - (a.length - i) * 300 }));
  const m = runAllStrategies({ symbol: 'XAUUSD', inst: { type: 'metal', provider: 'yahoo' }, tf: '5m', tfSec: 300, candles: cs, mode: 'live', reading: null, calendar: null }, { ai: true });
  m.pick = { id: 'bk_ema_50_200', plan: { direction: 'short', entry: 1, stop: 2, targets: [0.5, 0.4, 0.3], rrMain: 1.5 } }; m.final = 'sell';
  const h = engineHtml(m, 'ar');
  assert.ok(h.includes('EMA 50/200'));
});
