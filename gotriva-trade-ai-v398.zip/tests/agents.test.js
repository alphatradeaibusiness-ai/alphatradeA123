import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { closedRow, liveOf, statsOf, equityOf, pipPrice, sessionOf, createAgents } from '../server/agents.js';

const H = 3600_000;

test('pip price follows the site convention', () => {
  assert.equal(pipPrice('XAUUSD'), 0.1);
  assert.equal(pipPrice('US100'), 1);
  assert.equal(pipPrice('EURUSD'), 0.0001);
  assert.equal(pipPrice('USDJPY'), 0.01);
});

test('elite: full stop, stop at entry after TP1, all three targets, timed out', () => {
  const base = { symbol: 'XAUUSD', direction: 'long', entry: 2000, initialStop: 1990, stop: 1990, targets: [2010, 2020, 2030], filledAt: 1, closedAt: 2 };
  assert.equal(closedRow('elite', { ...base, id: 'a', status: 'sl', hits: 0 }).pips, -100);
  const be = closedRow('elite', { ...base, id: 'b', status: 'sl', hits: 1, stop: 2000 });
  assert.equal(be.pips, 33.3); assert.equal(be.out, 'be');   // a third banked at TP1, the rest closed at the entry
  assert.equal(closedRow('elite', { ...base, id: 'c', status: 'tp3', hits: 3 }).pips, 200);
  assert.equal(closedRow('elite', { ...base, id: 'd', status: 'expired', hits: 0, price: 2005 }).pips, 50);
  assert.equal(closedRow('elite', { ...base, id: 'e', status: 'expired', filledAt: null }), null, 'a limit that never filled is not a trade');
  assert.equal(closedRow('elite', { ...base, id: 'f', status: 'cancelled' }), null);
  assert.equal(closedRow('elite', { ...base, id: 'g', status: 'tp1', hits: 1 }), null, 'still open');
});

test('short trades, nova R results and swing realised pips', () => {
  assert.equal(closedRow('elite', { id: 's', symbol: 'US100', direction: 'short', entry: 100, initialStop: 110, targets: [90, 80, 70], status: 'tp3', hits: 3, filledAt: 1, closedAt: 2 }).pips, 20);
  assert.equal(closedRow('nova', { id: 'n', symbol: 'XAUUSD', direction: 'long', entry: 2000, stop: 1999, status: 'tp', result: 1, closedAt: 5 }).pips, 10);
  assert.equal(closedRow('nova', { id: 'n2', symbol: 'XAUUSD', direction: 'long', entry: 2000, stop: 1999, status: 'sl', result: -1, closedAt: 5 }).pips, -10);
  assert.equal(closedRow('swing', { id: 'w', symbol: 'EURUSD', direction: 'long', status: 'sl', filledAt: 1, closedAt: 2, realizedPips: -42.5 }).pips, -42.5);
  assert.equal(closedRow('swing', { id: 'w2', symbol: 'EURUSD', status: 'cancelled', closedAt: 2 }), null);
});

test('recommendation channel: be after TP1 keeps the banked third, expired is not counted', () => {
  const s = { id: 'r', symbol: 'XAUUSD', direction: 'long', entry: 2000, stop: 1990, targets: [2010, 2020, 2030], closedAt: 3 };
  assert.equal(closedRow('signals', { ...s, status: 'be', hits: 2 }).pips, 100);
  assert.equal(closedRow('signals', { ...s, status: 'sl', hits: 0 }).pips, -100);
  assert.equal(closedRow('signals', { ...s, status: 'expired', hits: 0 }), null);
});

test('stats: win rate, average, best streak; equity is a running total', () => {
  const rows = [10, 20, -5, 30, 40, 50, 0].map((p, i) => ({ pips: p, closedAt: i }));
  const s = statsOf(rows);
  assert.deepEqual([s.signals, s.wins, s.losses, s.totalPips, s.bestStreak], [7, 5, 1, 145, 3]);
  assert.equal(s.winRate, 71.4); assert.equal(s.avgPips, 20.7);
  assert.deepEqual(equityOf(rows).map((x) => x[1]), [10, 30, 25, 55, 95, 145, 145]);
  assert.equal(equityOf(Array.from({ length: 500 }, (_, i) => ({ pips: 1, closedAt: i })), 50).length, 50);
  assert.equal(statsOf([]).winRate, null);
});

test('live trade levels only when allowed', () => {
  const list = [{ id: 'x', symbol: 'XAUUSD', direction: 'long', status: 'tp1', entry: 2000, stop: 2000, targets: [1, 2, 3], price: 2004, filledAt: 1, createdAt: 1, hits: 1 }];
  assert.equal(liveOf('elite', list)[0].entry, undefined);
  const l = liveOf('elite', list, { levels: true })[0];
  assert.equal(l.entry, 2000); assert.equal(l.pipsNow, 40);
  assert.equal(liveOf('elite', [{ ...list[0], status: 'active' }]).length, 0, 'a pending limit is not a live trade');
});

test('session of a close time', () => {
  assert.equal(sessionOf(Date.UTC(2026, 10, 13, 3)), 'TOKYO');
  assert.equal(sessionOf(Date.UTC(2026, 10, 13, 9)), 'LONDON');
  assert.equal(sessionOf(Date.UTC(2026, 10, 13, 15)), 'NY');
});

test('ledger keeps closed trades after the channel prunes them, once each, and filters by range', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'agents-'));
  let t = Date.UTC(2026, 10, 16, 12);
  let elite = [
    { id: 'old', symbol: 'XAUUSD', direction: 'long', entry: 2000, initialStop: 1990, stop: 1990, targets: [2010, 2020, 2030], status: 'tp3', hits: 3, filledAt: t - 40 * 24 * H, createdAt: t - 40 * 24 * H, closedAt: t - 40 * 24 * H },
    { id: 'new', symbol: 'XAUUSD', direction: 'long', entry: 2000, initialStop: 1990, stop: 1990, targets: [2010, 2020, 2030], status: 'sl', hits: 0, filledAt: t - 2 * H, createdAt: t - 3 * H, closedAt: t - H },
    { id: 'open', symbol: 'XAUUSD', direction: 'short', entry: 2000, stop: 2010, targets: [1990, 1980, 1970], status: 'entry_hit', hits: 0, filledAt: t, createdAt: t, price: 1995 },
  ];
  const a = createAgents({ dataDir: dir, sources: { elite: () => elite, swing: () => null, nova: () => null, signals: () => null }, now: () => t });
  assert.equal(a.tick(), 2); assert.equal(a.tick(), 0, 'each closed trade is copied once');
  elite = elite.filter((s) => s.id === 'open');   // the channel drops its old history
  const hub = a.hub().agents.find((x) => x.id === 'elite');
  assert.deepEqual([hub.allPips, hub.m30Pips, hub.live, hub.running], [100, -100, true, true]);
  assert.equal(a.hub().agents.find((x) => x.id === 'swing').running, false);
  const d = a.detail('elite', { range: '30', levels: true });
  assert.equal(d.overall.signals, 2); assert.equal(d.period.signals, 1); assert.equal(d.live[0].pipsNow, 50);
  assert.equal(a.detail('elite', { range: 'all', side: 'wins' }).period.totalPips, 200);
  assert.equal(a.detail('nope'), null);
  await new Promise((r) => setTimeout(r, 2200));
  const b = createAgents({ dataDir: dir, sources: { elite: () => [] }, now: () => t });
  assert.equal(b.detail('elite', { range: 'all' }).overall.signals, 2, 'the ledger survives a restart');
  fs.rmSync(dir, { recursive: true, force: true });
});
