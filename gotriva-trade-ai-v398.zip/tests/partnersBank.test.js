// v369 Gotriva Partner Club → digital bank: approved payouts go into the partner's USD wallet from company money, never twice.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createPartners } from '../server/partners.js';
import { RANKS, PRICE_TIERS } from '../src/config/partnerRanks.js';
import { openDb } from '../server/bank/db.js';
import { createVault } from '../server/bank/vault.js';
import { createBank } from '../server/bank/service.js';

const CAT = { p650: { id: 'p650', kind: 'plan', cents: 65000 } };
const MATRIX = () => { const m = {}; RANKS.forEach((r) => { m[r.id] = {}; for (const t of PRICE_TIERS) m[r.id][t] = { newPct: 10, newFixedCents: 0, renPct: 4, renFixedCents: 0 }; }); return m; };
const U = (uid) => ({ uid, email: `${uid}@mail.test`, name: uid });
let n = 0; const pay = (uid) => ({ paymentId: `cs_b${++n}`, pi: `pi_b${n}`, uid, product: 'p650', listCents: 65000, collectedCents: 65000 });

function setup({ bankOn = true } = {}) {
  let t = Date.UTC(2026, 10, 9, 12);
  const db = openDb(':memory:');
  const bank = createBank({ db, vault: createVault({ secret: 'z'.repeat(40) }), mode: 'live', now: () => t,
    priceFn: async () => ({ price: 50000, ts: t }), rateFn: async () => ({ usdPer: { USD: 1, EUR: 1.1, USDT: 1, BTC: 50000 }, ts: t, sources: {} }) });
  const bankPay = Object.assign((uid, o) => bank.creditPartnerCommission(uid, o), { available: () => bankOn });
  const p = createPartners({ dir: fs.mkdtempSync(path.join(os.tmpdir(), 'pcb-')), secret: 's'.repeat(40), now: () => t, deliver: async () => null, catalogue: CAT, bankPay });
  p.setConfig({ enabled: true, matrix: MATRIX(), finance: { holdDays: 3 }, payout: { minPayoutCents: 1000 } });
  return { p, bank, db, adv: (ms) => { t += ms; } };
}
const usdWallet = (bank, uid) => bank.wallet(uid).find((w) => w.currency === 'USD').available;

test('owner approval pays the bank wallet once; the payout is marked paid with the bank transaction', () => {
  const { p, bank, adv } = setup();
  const part = p.join(U('pa')).partner; for (const c of ['a', 'b']) { p.attach(U(c), part.code); p.onPayment(pay(c)); }
  adv(4 * 86_400_000); p.tick();
  assert.equal(p.me(U('pa')).bankAvailable, true);
  const po = p.requestPayout(U('pa'), { method: 'gotriva_bank' }).payout; assert.equal(po.cents, 13000); assert.equal(po.status, 'requested');
  assert.equal(usdWallet(bank, 'pa'), 0, 'nothing moves before the owner approves');
  const r = p.adminAct({ action: 'payout_approve', id: po.id }); assert.equal(r.paid, true);
  assert.equal(usdWallet(bank, 'pa'), 13000, '$130.00 in the partner\'s wallet');
  const view = p.me(U('pa')); assert.equal(view.earnings.paid, 13000); assert.equal(view.earnings.available, 0); assert.match(view.payouts[0].reference, /^bank:/);
  assert.equal(p.adminAct({ action: 'payout_bank', id: po.id }).error, 'bad_state', 'a paid payout cannot be paid again');
  assert.equal(bank.creditPartnerCommission('pa', { cents: 13000, payoutId: po.id }).replay, true, 'the bank refuses a second credit for the same payout');
  assert.equal(usdWallet(bank, 'pa'), 13000);
  assert.equal(p.adminAct({ action: 'payout_paid', id: po.id, reference: 'X123' }).error, 'bad_state');
  assert.deepEqual(bank.ledger.verify(), { ok: true, problems: [] });
  const h = bank.history('pa', {}); assert.equal(h.items[0].type, 'partner_commission'); assert.equal(h.items[0].meta.source, 'gotriva_partner_club');
});

test('auto-pay (owner switch) pays approved balances of bank-wallet partners after the holding period; off by default', () => {
  const { p, bank, adv } = setup();
  assert.equal(p.adminView().config.payout.autoBank, false);
  const part = p.join(U('pb')).partner; p.attach(U('c1'), part.code); p.onPayment(pay('c1'));
  p.requestPayout(U('pb'), { method: 'gotriva_bank' });   // below minimum now (still pending) → remembers the method? no: below_minimum
  p._db().partners.pb.payoutMethod = { method: 'gotriva_bank', account: 'GOTRIVA bank · USD wallet' };
  adv(4 * 86_400_000); p.tick(); assert.equal(usdWallet(bank, 'pb'), 0, 'auto-pay is off');
  p.setConfig({ payout: { autoBank: true } }); p.tick();
  assert.equal(usdWallet(bank, 'pb'), 6500); p.tick(); assert.equal(usdWallet(bank, 'pb'), 6500, 'never twice');
  assert.equal(p.adminView().payouts[0].approvedBy, 'auto');
});

test('bank off → the bank method is refused; a failed credit keeps the payout open for a retry', () => {
  const off = setup({ bankOn: false }); const part = off.p.join(U('pc')).partner; off.p.attach(U('c2'), part.code); off.p.onPayment(off.p && pay('c2')); off.adv(4 * 86_400_000); off.p.tick();
  assert.equal(off.p.requestPayout(U('pc'), { method: 'gotriva_bank' }).error, 'bank_off');
  const { p, adv } = setup(); const pp = p.join(U('pd')).partner; p.attach(U('c3'), pp.code); p.onPayment(pay('c3')); adv(4 * 86_400_000); p.tick();
  const po = p.requestPayout(U('pd'), { method: 'gotriva_bank' }).payout;
  p._db().payouts[0].partner = '';   // simulate a broken record → the bank refuses
  const r = p.adminAct({ action: 'payout_approve', id: po.id }); assert.equal(r.approved, true); assert.ok(r.bankError);
  assert.equal(p._db().payouts[0].status, 'approved', 'still open, nothing marked paid');
});
