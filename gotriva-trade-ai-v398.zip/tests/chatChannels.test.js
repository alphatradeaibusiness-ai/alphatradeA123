import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto2 from 'node:crypto';
import { createChatChannels, sniffImage } from '../server/chatChannels.js';

const SECRET = 'x'.repeat(40);
const PNG = `data:image/png;base64,${Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3]).toString('base64')}`;
const FAKE = `data:image/png;base64,${Buffer.from('<svg onload=alert(1)>').toString('base64')}`;
const boss = { uid: 'uboss1', email: 'boss@site.test', name: 'Boss' };
const mod = { uid: 'umod01', email: 'mod@site.test', name: 'Mod' };
const ali = { uid: 'uali01', email: 'ali@site.test', name: 'Ali' };
const eve = { uid: 'ueve01', email: 'eve@site.test', name: 'Eve' };
const people = [boss, mod, ali, eve];

function setup() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-'));
  const sent = [];
  const c = createChatChannels({ dir, secret: SECRET, env: { NODE_ENV: 'test' }, isOwnerEmail: (u) => u?.email === 'boss@site.test',
    findMember: (e) => people.find((p) => p.email === e) || null, notify: (uid, n) => sent.push([uid, n]) });
  return { c, dir, sent };
}

test('image bytes decide the type, not the label', () => {
  assert.equal(sniffImage(Buffer.from([0xff, 0xd8, 0xff, 0xe0])), 'image/jpeg');
  assert.equal(sniffImage(Buffer.from('<svg/>')), null);
});

test('only owners and approved moderators create channels', () => {
  const { c } = setup();
  assert.equal(c.create(mod, { name: 'VIP' }).error, 'forbidden');
  assert.equal(c.addMod(mod, { email: 'mod@site.test' }).error, 'forbidden', 'a moderator cannot approve anyone');
  c.addMod(boss, { email: 'MOD@site.test' });
  assert.equal(c.list(mod).canCreate, true);
  assert.ok(c.create(mod, { name: 'VIP gold', logo: PNG }).channel.logo);
  c.removeMod(boss, 'mod@site.test');
  assert.equal(c.create(mod, { name: 'Again' }).error, 'forbidden');
});

test('members are chosen by the admin; outsiders see nothing', () => {
  const { c, sent } = setup();
  const id = c.create(boss, { name: 'Room' }).channel.id;
  assert.equal(c.read(eve, id).error, 'not_found');
  assert.equal(c.post(eve, id, { text: 'hi' }).error, 'not_found');
  assert.equal(c.addMember(boss, id, { email: 'nobody@x.io' }).error, 'no_account');
  c.addMember(boss, id, { email: 'ali@site.test' });
  assert.ok(sent.some(([uid]) => uid === ali.uid), 'the new member is told');
  assert.equal(c.addMember(ali, id, { email: 'eve@site.test' }).error, 'forbidden', 'a plain member cannot add people');
  assert.equal(c.members(ali, id).members.find((m) => m.uid === boss.uid).email, null, 'members do not see e-mails');
  assert.equal(c.list(ali).channels.length, 1);
  assert.equal(c.removeMember(boss, id, ali.uid).members.length, 1);
  assert.equal(c.read(ali, id).error, 'not_found', 'removed members lose access at once');
  assert.equal(c.removeMember(boss, id, boss.uid).error, 'creator_cannot_leave');
});

test('text and images, history, delete rules, unread', () => {
  const { c } = setup();
  const id = c.create(boss, { name: 'Room' }).channel.id; c.addMember(boss, id, { email: 'ali@site.test' });
  assert.equal(c.post(ali, id, { text: '   ' }).error, 'empty');
  assert.equal(c.post(ali, id, { image: FAKE }).error, 'bad_image', 'a script dressed as a PNG is refused');
  const m1 = c.post(ali, id, { text: 'hello <b>' }).message;
  assert.equal(m1.text, 'hello <b>', 'stored as plain text (the page shows it as text)');
  const m2 = c.post(ali, id, { text: 'chart', image: PNG }).message;
  assert.ok(m2.file);
  const f = c.getFile(ali, id, m2.file); assert.equal(f.type, 'image/png');
  assert.equal(c.getFile(eve, id, m2.file), null, 'outsiders cannot load the image');
  assert.equal(c.list(boss).channels[0].unread, 2);
  c.markRead(boss, id, m2.seq); assert.equal(c.list(boss).channels[0].unread, 0);
  const since = c.read(boss, id).rev;
  assert.equal(c.delMessage(ali, id, m1.id).ok, true);
  const again = c.read(boss, id, { since });
  assert.deepEqual(again.deleted, [m1.id], 'the delete reaches the others');
  const m3 = c.post(boss, id, { text: 'admin says' }).message;
  assert.equal(c.delMessage(ali, id, m3.id).error, 'forbidden', 'members delete only their own');
  assert.equal(c.delMessage(boss, id, m2.id).ok, true, 'admins delete any');
  assert.equal(c.getFile(ali, id, m2.file), null, 'a deleted image is gone');
});

test('history survives a restart (encrypted on disk) and pages backwards', () => {
  const { c, dir } = setup();
  const id = c.create(boss, { name: 'Room' }).channel.id;
  for (let i = 0; i < 25; i++) c.post(boss, id, { text: `m${i}` });
  c.flush();
  assert.ok(!fs.readFileSync(path.join(dir, 'chat-channels.json')).includes('m24'), 'no clear text on disk');
  const c2 = createChatChannels({ dir, secret: SECRET, env: { NODE_ENV: 'test' }, isOwnerEmail: () => false });
  const r = c2.read(boss, id); assert.equal(r.messages.at(-1).text, 'm24');
  const older = c2.read(boss, id, { before: r.messages[5].seq });
  assert.equal(older.messages.at(-1).seq, r.messages[4].seq);
});

test('rate limit and long polling', async () => {
  const { c } = setup();
  const id = c.create(boss, { name: 'Room' }).channel.id; c.addMember(boss, id, { email: 'ali@site.test' });
  let lim = null; for (let i = 0; i < 31; i++) lim = c.post(ali, id, { text: `x${i}` });
  assert.equal(lim.error, 'rate_limited');
  const rev = c.read(boss, id).rev;
  const t0 = Date.now(); const p = c.waitFor(id, rev, 5000);
  setTimeout(() => c.post(boss, id, { text: 'now' }), 50);
  assert.equal(await p, true); assert.ok(Date.now() - t0 < 2000, 'woke at once');
  assert.equal(await c.waitFor(id, c.read(boss, id).rev, 60), false, 'times out quietly');
});

test('deleting an account removes its channels and messages', () => {
  const { c } = setup();
  const id = c.create(boss, { name: 'Room' }).channel.id; c.addMember(boss, id, { email: 'ali@site.test' });
  const m = c.post(ali, id, { text: 'bye' }).message;
  c.forgetUser(ali.uid);
  assert.ok(c.read(boss, id).messages.find((x) => x.id === m.id).deleted);
  c.forgetUser(boss.uid); assert.equal(c.read(boss, id).error, 'not_found');
});

test('v354: channel colour, raw photo / video uploads checked by their bytes', () => {
  const { c } = setup();
  const id = c.create(boss, { name: 'Room', color: '#E11D48' }).channel.id;
  assert.equal(c.list(boss).channels[0].color, '#e11d48');
  assert.equal(c.update(boss, id, { color: 'red;background:url(x)' }).error, 'bad_color');
  c.addMember(boss, id, { email: 'ali@site.test' });
  assert.equal(c.update(ali, id, { color: '#000000' }).error, 'forbidden', 'only admins change the colour');
  const mp4 = Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypisom'), Buffer.alloc(40)]);
  const up = c.upload(ali, id, mp4); assert.equal(up.kind, 'video');
  assert.equal(c.upload(ali, id, Buffer.from('#!/bin/sh rm -rf /')).error, 'bad_media');
  assert.equal(c.upload(eve, id, mp4).error, 'not_found', 'outsiders cannot upload');
  assert.equal(c.post(boss, id, { media: up.media }).error, 'bad_media', 'nobody can send someone else\'s upload');
  const m = c.post(ali, id, { text: 'clip', media: up.media }).message; assert.equal(m.kind, 'video');
  assert.equal(c.post(ali, id, { media: up.media }).error, 'bad_media', 'an upload is used once');
  assert.equal(c.getFile(boss, id, m.file).type, 'video/mp4');
  const webm = c.upload(ali, id, Buffer.from([0x1a, 0x45, 0xdf, 0xa3, 1, 2, 3, 4, 5])); assert.equal(webm.kind, 'video');
});

test('v354: one notice per channel, named after it, in the reader\'s language', () => {
  const sent = []; const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-'));
  const c = createChatChannels({ dir, secret: SECRET, env: { NODE_ENV: 'test' }, isOwnerEmail: (u) => u?.email === 'boss@site.test', findMember: (e) => people.find((p) => p.email === e) || null, notify: (uid, n) => sent.push([uid, n]), langOf: (uid) => (uid === ali.uid ? 'ar' : 'en') });
  const id = c.create(boss, { name: 'Gold VIP' }).channel.id; c.addMember(boss, id, { email: 'ali@site.test' }); sent.length = 0;
  c.post(boss, id, { text: 'hello' });
  const [uid, n] = sent[0]; assert.equal(uid, ali.uid); assert.equal(n.title, 'Gold VIP'); assert.equal(n.tag, `chat-${id}`); assert.ok(n.url.includes(id)); assert.equal(n.body, 'Boss: hello');
  c.post(boss, id, { text: 'again' }); assert.equal(sent.length, 1, 'no second buzz within a minute');
});

test('v354: calls — an admin starts, members join, set-up messages reach only their target', async () => {
  const { c, sent } = setup();
  const id = c.create(boss, { name: 'Room' }).channel.id; c.addMember(boss, id, { email: 'ali@site.test' }); c.addMember(boss, id, { email: 'mod@site.test' });
  assert.equal(c.callAct(ali, id, { action: 'start' }).error, 'forbidden', 'members cannot start a call');
  sent.length = 0;
  const s = c.callAct(boss, id, { action: 'start' }); assert.equal(s.call.joined, true);
  assert.ok(sent.some(([uid, n]) => uid === ali.uid && n.url.includes('call=1')), 'members are invited');
  assert.equal(c.list(ali).channels[0].call.n, 1, 'the channel shows the live call');
  assert.equal(c.callAct(eve, id, { action: 'join' }).error, 'not_found', 'outsiders cannot join');
  c.callAct(ali, id, { action: 'join', cam: true });
  const rev = c.callGet(boss, id).call.rev;
  const w = c.callWait(boss, id, rev, 3000);
  c.callAct(ali, id, { action: 'signal', to: boss.uid, data: { type: 'offer', sdp: 'v=0' } });
  assert.equal(await w, true);
  const got = c.callGet(boss, id); assert.equal(got.signals.length, 1); assert.equal(got.signals[0].from, ali.uid);
  assert.equal(c.callGet(mod, id).signals.length, 0, 'not delivered to the others');
  assert.equal(c.callAct(ali, id, { action: 'signal', to: boss.uid, data: { type: 'evil' } }).error, 'bad_signal');
  c.callAct(ali, id, { action: 'say', text: 'can you hear me?' }); assert.equal(c.callGet(boss, id).call.chat.at(-1).text, 'can you hear me?');
  assert.equal(c.callAct(ali, id, { action: 'end' }).error, 'forbidden');
  c.callAct(boss, id, { action: 'end' }); assert.equal(c.callGet(ali, id).call, null);
  assert.equal(c.read(ali, id).messages.at(-1).sys, 'call_end');
});

test('v356: a video carries its own poster frame and length; posters follow the same rules', () => {
  const { c } = setup();
  const id = c.create(boss, { name: 'Room' }).channel.id; c.addMember(boss, id, { email: 'ali@site.test' });
  const mp4 = Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypisom'), Buffer.alloc(40)]);
  const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3]);
  const v = c.upload(ali, id, mp4); const p = c.upload(ali, id, png); const other = c.upload(boss, id, png);
  assert.equal(c.post(ali, id, { media: v.media, poster: other.media, dur: 12.34 }).message.poster, null, 'someone else\'s image is not a poster');
  const v2 = c.upload(ali, id, mp4);
  const m = c.post(ali, id, { media: v2.media, poster: p.media, dur: 12.34 }).message;
  assert.equal(m.poster, p.media); assert.equal(m.dur, 12.3);
  assert.equal(c.getFile(boss, id, m.poster).type, 'image/png');
  c.delMessage(ali, id, m.id); assert.equal(c.getFile(boss, id, p.media), null, 'deleting the video deletes its poster');
});

test('v356 security: __proto__ ids cannot touch Object.prototype; signals are rate-limited; unproven moderators cannot create', () => {
  const { c } = setup();
  const id = c.create(boss, { name: 'Room' }).channel.id; c.addMember(boss, id, { email: 'ali@site.test' });
  assert.equal(c.setRole(boss, id, '__proto__', { role: 'admin' }).error, 'not_found');
  assert.equal(({}).role, undefined, 'Object.prototype untouched');
  assert.equal(c.removeMember(boss, id, '__proto__').error, 'not_found');
  assert.equal(c.removeMember(boss, id, 'toString').error, 'not_found');
  c.callAct(boss, id, { action: 'start' }); c.callAct(ali, id, { action: 'join' });
  assert.equal(c.callAct(ali, id, { action: 'signal', to: '__proto__', data: { type: 'ice' } }).error, 'not_in_call');
  let last; for (let i = 0; i < 241; i++) last = c.callAct(ali, id, { action: 'signal', to: boss.uid, data: { type: 'ice', candidate: {} } });
  assert.equal(last.error, 'rate_limited');
  assert.ok(c.callGet(boss, id).signals.length <= 101, 'queue capped');
  assert.equal(c.isMember(ali, id), true); assert.equal(c.isMember(eve, id), false); assert.equal(c.isMember(ali, 'c__proto__xx'), false);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-'));
  const c2 = createChatChannels({ dir, secret: SECRET, env: { NODE_ENV: 'test' }, isOwnerEmail: (u) => u?.email === 'boss@site.test', isProven: (u) => u.uid !== mod.uid });
  c2.addMod(boss, { email: 'mod@site.test' });
  assert.equal(c2.create(mod, { name: 'X' }).error, 'forbidden', 'an approved e-mail that is not confirmed cannot create');
});

test('v356 security: upload backlog and daily quota per person; call starts are limited', () => {
  const { c } = setup();
  const id = c.create(boss, { name: 'Room' }).channel.id;
  const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3]);
  let r; for (let i = 0; i < 7; i++) r = c.upload(boss, id, png);
  assert.equal(r.error, 'rate_limited', 'at most 6 unsent uploads');
  for (let i = 0; i < 3; i++) { c.callAct(boss, id, { action: 'start' }); c.callAct(boss, id, { action: 'end' }); }
  assert.equal(c.callAct(boss, id, { action: 'start' }).error, 'rate_limited');
});

/* ── v357: Telegram-style features ── */
function setup2(rank = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-'));
  const c = createChatChannels({ dir, secret: SECRET, env: { NODE_ENV: 'test' }, isOwnerEmail: (u) => u?.email === 'boss@site.test',
    findMember: (e) => people.find((p) => p.email === e) || null, planRank: (uid) => rank[uid] ?? 0 });
  return { c, rank };
}

test('v357 reply, edit, reactions, pin, search and read ticks', () => {
  const { c } = setup2();
  const id = c.create(boss, { name: 'Gold room', category: 'forex', description: 'XAU talk' }).channel.id;
  c.addMember(boss, id, { email: 'ali@site.test' });
  const a = c.post(boss, id, { text: 'gold above 2400' }).message;
  const r = c.post(ali, id, { text: 'agreed', replyTo: a.id }).message;
  assert.equal(r.replyTo.id, a.id); assert.equal(r.replyTo.text, 'gold above 2400');
  assert.equal(c.editMessage(boss, id, r.id, { text: 'x' }).error, 'forbidden', 'only the writer edits');
  assert.ok(c.editMessage(ali, id, r.id, { text: 'agreed 100%' }).message.edited);
  assert.equal(c.react(ali, id, a.id, { emoji: '<script>' }).error, 'bad_reaction');
  c.react(ali, id, a.id, { emoji: '🔥' }); c.react(ali, id, a.id, { emoji: '👍' });   // one reaction per person
  const v = c.react(boss, id, a.id, { emoji: '👍' }).message;
  assert.deepEqual(v.reactions, [{ e: '👍', n: 2, mine: true }]);
  assert.equal(c.pin(ali, id, { id: a.id }).error, 'forbidden');
  c.pin(boss, id, { id: a.id });
  const view = c.read(ali, id);
  assert.equal(view.pinned.id, a.id); assert.equal(view.channel.category, 'forex'); assert.equal(view.channel.description, 'XAU talk');
  assert.equal(c.search(ali, id, 'gold').results.length, 1);
  c.markRead(ali, id, view.rev); assert.ok(c.read(boss, id).seenUpTo >= r.seq);
  c.setTyping(ali, id); assert.deepEqual(c.read(boss, id).typing, ['Ali']);
});

test('v357 broadcast channels, ban and mute', () => {
  const { c } = setup2();
  const id = c.create(boss, { name: 'Official', type: 'channel' }).channel.id;
  c.addMember(boss, id, { email: 'ali@site.test' });
  assert.equal(c.post(ali, id, { text: 'hi' }).error, 'admins_only');
  c.update(boss, id, { type: 'group' });
  c.moderate(boss, id, ali.uid, { action: 'mute', minutes: 10 });
  assert.equal(c.post(ali, id, { text: 'hi' }).error, 'muted');
  c.moderate(boss, id, ali.uid, { action: 'unmute' }); assert.ok(c.post(ali, id, { text: 'hi' }).message);
  assert.equal(c.moderate(ali, id, boss.uid, { action: 'ban' }).error, 'forbidden');
  c.moderate(boss, id, ali.uid, { action: 'ban' });
  assert.equal(c.read(ali, id).error, 'not_found'); assert.equal(c.isMember(ali, id), false);
  c.addMember(boss, id, { email: 'ali@site.test' }); assert.ok(c.read(ali, id).channel, 'adding someone back lifts the ban');
});

test('v357 subscription channels follow the current plan and drop an expired one', () => {
  const { c, rank } = setup2({ [ali.uid]: 3, [eve.uid]: 0 });
  const id = c.create(boss, { name: 'VIP room', access: 'plan', minRank: 3, category: 'vip' }).channel.id;
  assert.equal(c.list(ali).channels.some((x) => x.id === id), true);
  assert.equal(c.list(eve).channels.some((x) => x.id === id), false, 'a lower plan does not see it');
  assert.equal(c.read(eve, id).error, 'not_found');
  assert.ok(c.post(ali, id, { text: 'in' }).message);
  rank[ali.uid] = 0;   // the subscription expired
  assert.equal(c.read(ali, id).error, 'not_found'); assert.equal(c.list(ali).channels.some((x) => x.id === id), false);
  const free = c.create(boss, { name: 'General', access: 'plan', minRank: 0 }).channel.id;
  assert.ok(c.read(eve, free).channel, 'free groups are open to every signed-in member');
});

/* ── v358: everyday chat features ── */
test('v358 direct chats need a shared group, can be blocked, and saved messages are private', () => {
  const { c } = setup2();
  assert.equal(c.openDm(ali, { uid: eve.uid }).error, 'not_found', 'eve is in no chat at all yet');
  const g = c.create(boss, { name: 'Friends' }).channel.id; c.addMember(boss, g, { email: 'ali@site.test' }); c.addMember(boss, g, { email: 'eve@site.test' });
  const dm = c.openDm(ali, { uid: eve.uid }).channel; assert.equal(dm.type, 'dm'); assert.equal(dm.name, 'Eve');
  assert.equal(c.openDm(eve, { uid: ali.uid }).channel.id, dm.id, 'one chat per pair');
  assert.ok(c.post(ali, dm.id, { text: 'hi eve' }).message);
  c.block(eve, dm.id, true);
  assert.equal(c.post(ali, dm.id, { text: 'hello?' }).error, 'blocked'); assert.equal(c.post(eve, dm.id, { text: 'x' }).error, 'you_blocked');
  assert.equal(c.read(boss, dm.id).error, 'not_found', 'nobody else reads a direct chat');
  const sv = c.openSaved(ali).channel; assert.equal(sv.type, 'saved'); assert.equal(c.openSaved(ali).channel.id, sv.id);
  assert.equal(c.read(eve, sv.id).error, 'not_found');
  const m = c.post(boss, g, { text: 'keep this' }).message;
  const f = c.forward(ali, g, m.id, { to: sv.id }).message; assert.equal(f.text, 'keep this'); assert.equal(f.fwd.name, 'Boss');
  assert.equal(c.post(ali, sv.id, { text: 'x' }, {}).message.fwd, null, 'nobody can fake a forwarded label');
  assert.equal(c.post(ali, sv.id, { text: 'x', fwd: { name: 'CEO' } }).message.fwd, null);
});

test('v358 voice notes and documents are checked and documents always download', () => {
  const { c } = setup2();
  const g = c.create(boss, { name: 'Docs' }).channel.id;
  assert.equal(c.upload(boss, g, Buffer.from('not audio at all'), { as: 'voice' }).error, 'bad_media');
  const ogg = Buffer.concat([Buffer.from('OggS'), Buffer.alloc(200)]);
  const v = c.upload(boss, g, ogg, { as: 'voice' }); assert.equal(v.kind, 'voice');
  const vm = c.post(boss, g, { media: v.media, dur: 4.2 }).message; assert.equal(vm.kind, 'voice'); assert.equal(vm.dur, 4.2);
  const d = c.upload(boss, g, Buffer.from('<script>alert(1)</script>'), { as: 'file', name: '../../evil<>.html' });
  const dm = c.post(boss, g, { media: d.media }).message; assert.equal(dm.kind, 'file'); assert.equal(dm.fileName, '_.._evil__.html'.replace(/^_/, '_')); 
  const got = c.getFile(boss, g, dm.file); assert.equal(got.type, 'application/octet-stream'); assert.ok(got.name);
});

test('v358 polls, mentions, slow mode and filters', () => {
  const { c } = setup2();
  const g = c.create(boss, { name: 'Club' }).channel.id; c.addMember(boss, g, { email: 'ali@site.test' }); c.addMember(boss, g, { email: 'eve@site.test' });
  assert.equal(c.post(boss, g, { poll: { q: 'Pizza?', options: ['yes'] } }).error, 'bad_poll');
  const p = c.post(boss, g, { poll: { q: 'Pizza or burger?', options: ['Pizza', 'Burger'] } }).message;
  c.vote(ali, g, p.id, { option: 0 }); c.vote(eve, g, p.id, { option: 1 }); const v = c.vote(ali, g, p.id, { option: 1 }).message.poll;
  assert.deepEqual(v.options.map((o) => o.n), [0, 2], 'single choice moves the vote'); assert.equal(v.total, 2);
  assert.equal(c.vote(ali, g, p.id, { close: true }).error, 'forbidden');
  const m = c.post(ali, g, { text: '@Eve look', mentions: [eve.uid, 'ghost', ali.uid] }).message; assert.deepEqual(m.mentions, [eve.uid]);
  assert.equal(c.list(eve).channels.find((x) => x.id === g).mentions, 1);
  c.update(boss, g, { slow: 30, filterLinks: true, words: 'spam, scam' });
  assert.equal(c.post(eve, g, { text: 'visit www.bad.com' }).error, 'links_off');
  assert.equal(c.post(eve, g, { text: 'this is a SCAM' }).error, 'blocked_word');
  assert.ok(c.post(eve, g, { text: 'ok' }).message); assert.equal(c.post(eve, g, { text: 'again' }).error, 'slow_mode');
  assert.ok(c.post(boss, g, { text: 'admins skip it www.ok.com' }).message);
});

test('v358 invite links, join requests, admin permissions and the activity log', () => {
  const { c } = setup2();
  const g = c.create(boss, { name: 'Open club' }).channel.id;
  const open = c.makeInvite(boss, g, {}).code; assert.equal(c.invitePeek(eve, open).name, 'Open club');
  assert.equal(c.joinInvite(eve, open).joined, true); assert.ok(c.read(eve, g).channel);
  const ask = c.makeInvite(boss, g, { approve: true }).code;
  assert.equal(c.joinInvite(ali, ask).asked, true); assert.equal(c.read(ali, g).error, 'not_found');
  assert.equal(c.members(boss, g).requests.length, 1);
  c.answerRequest(boss, g, ali.uid, { accept: true }); assert.ok(c.read(ali, g).channel);
  c.moderate(boss, g, eve.uid, { action: 'ban' }); assert.equal(c.joinInvite(eve, open).error, 'banned');
  assert.equal(c.invitePeek(eve, 'zzzzzzzzzzzz').error, 'not_found');
  // a limited admin
  c.setRole(boss, g, ali.uid, { role: 'admin', perms: { ban: false, members: false } });
  assert.equal(c.moderate(ali, g, 'x', { action: 'mute' }).error, 'forbidden');
  assert.equal(c.addMember(ali, g, { email: 'mod@site.test' }).error, 'forbidden');
  assert.equal(c.setRole(ali, g, boss.uid, { role: 'member' }).error, 'forbidden', 'only the creator names admins');
  const log = c.activity(boss, g).log.map((x) => x.act); assert.ok(log.includes('ban') && log.includes('accept') && log.includes('promote'));
  assert.equal(c.activity(eve, g).error, 'not_found');
});

/* ── v359 ── */
const PNG9 = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(64)]);
test('v359 disappearing messages and topics', () => {
  let t = 1_000_000; const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-'));
  const c = createChatChannels({ dir, secret: SECRET, env: { NODE_ENV: 'test' }, now: () => t, isOwnerEmail: (u) => u?.email === 'boss@site.test', findMember: (e) => people.find((p) => p.email === e) || null });
  const g = c.create(boss, { name: 'Ghost' }).channel.id; c.addMember(boss, g, { email: 'ali@site.test' });
  assert.equal(c.setTtl(ali, g, { ttl: 86400 }).error, 'forbidden');
  c.setTtl(boss, g, { ttl: 86400 }); c.post(boss, g, { text: 'gone tomorrow' });
  assert.ok(c.read(ali, g).messages.some((m) => m.text === 'gone tomorrow'));
  t += 86_400_001; assert.ok(!c.read(ali, g).messages.some((m) => m.text === 'gone tomorrow'), 'it disappears for everyone');
  const ch = c.topicAdd(boss, g, { name: 'Trips', emoji: '🏖️' }).channel; const tid = ch.topics[0].id;
  assert.equal(c.post(ali, g, { text: 'x', topic: 'tzzzzzzzz' }).error, 'bad_topic');
  assert.equal(c.post(ali, g, { text: 'beach?', topic: tid }).message.topic, tid);
  c.topicDel(boss, g, tid); assert.equal(c.read(ali, g).messages.at(-1).topic, null);
});

test('v359 stickers are private to their maker until sent, stories follow the circle and expire', () => {
  let t = 5_000_000; const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-'));
  const c = createChatChannels({ dir, secret: SECRET, env: { NODE_ENV: 'test' }, now: () => t, isOwnerEmail: (u) => u?.email === 'boss@site.test', findMember: (e) => people.find((p) => p.email === e) || null });
  const g = c.create(boss, { name: 'Fun' }).channel.id; c.addMember(boss, g, { email: 'ali@site.test' });
  assert.equal(c.stickerAdd(ali, Buffer.from('<svg/>')).error, 'bad_image');
  const fid = c.stickerAdd(ali, PNG9).stickers[0];
  assert.equal(c.stickerFile(eve, fid), null, 'nobody else reads my sticker');
  const m = c.post(ali, g, { sticker: fid }).message; assert.equal(m.sticker, true); assert.ok(c.getFile(boss, g, m.file));
  c.storyAdd(ali, PNG9, { caption: 'sunset' });
  assert.equal(c.stories(boss).stories[0].name, 'Ali'); assert.equal(c.stories(eve).stories.length, 0, 'not shared with strangers');
  const s0 = c.stories(boss).stories[0].items[0]; assert.ok(c.storyGet(boss, ali.uid, s0.fid)); assert.equal(c.storyGet(eve, ali.uid, s0.fid), null);
  assert.deepEqual(c.stories(ali).stories[0].items[0].views, ['Boss']);
  t += 86_400_001; assert.equal(c.stories(boss).stories.length, 0, 'gone after a day');
});

test('v359 translation is cached and marked as AI', async () => {
  let calls = 0; const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-'));
  const c = createChatChannels({ dir, secret: SECRET, env: { NODE_ENV: 'test' }, isOwnerEmail: (u) => u?.email === 'boss@site.test', findMember: (e) => people.find((p) => p.email === e) || null, translate: async () => { calls++; return { text: 'مرحبا' }; } });
  const g = c.create(boss, { name: 'Tr' }).channel.id; const m = c.post(boss, g, { text: 'hello' }).message;
  const r = await c.translateMsg(boss, g, m.id, 'ar'); assert.equal(r.text, 'مرحبا'); assert.equal(r.ai, true);
  await c.translateMsg(boss, g, m.id, 'ar'); assert.equal(calls, 1);
  assert.equal((await c.translateMsg(eve, g, m.id, 'ar')).error, 'not_found');
});

/* ── v360 ── */
test('v360 profiles, usernames, DM privacy and people search', () => {
  const { c } = setup2();
  assert.equal(c.setProfile(ali, { username: 'Al' }).error, 'bad_username');
  assert.equal(c.setProfile(ali, { username: '@Ali_Cool', bio: 'hi' }).username, 'ali_cool');
  assert.equal(c.setProfile(eve, { username: 'ali_cool' }).error, 'username_taken');
  assert.equal(c.people(eve, 'ali_').people[0].uid, ali.uid);
  assert.equal(c.openDm(eve, { uid: ali.uid }).error, 'dm_closed', 'strangers need the person to allow it');
  c.setProfile(ali, { dmFrom: 'all' }); assert.equal(c.openDm(eve, { uid: ali.uid }).channel.type, 'dm');
  assert.equal(c.setAvatar(ali, Buffer.from('nope')).error, 'bad_image');
  assert.ok(c.setAvatar(ali, PNG9).av > 0); assert.ok(c.avatarFile(ali.uid));
  assert.equal(c.profile(eve, ali.uid).username, 'ali_cool'); assert.equal(c.profile(eve, boss.uid).error, 'not_found');
});

test('v360 archive, pin, timed mute, global search, shared media, delete for me, readers, scheduled', () => {
  let t = 10_000_000; const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-')); const sent = [];
  const c = createChatChannels({ dir, secret: SECRET, env: { NODE_ENV: 'test' }, now: () => t, isOwnerEmail: (u) => u?.email === 'boss@site.test', findMember: (e) => people.find((p) => p.email === e) || null, notify: (uid, n) => sent.push(uid) });
  const a = c.create(boss, { name: 'A room' }).channel.id; const b = c.create(boss, { name: 'B room' }).channel.id;
  c.addMember(boss, a, { email: 'ali@site.test' }); c.addMember(boss, b, { email: 'ali@site.test' });
  c.setPrefs(ali, a, { pinned: true, mute: 60 }); c.setPrefs(ali, b, { archived: true });
  const l = c.list(ali).channels; assert.equal(l[0].id, a, 'pinned chat first'); assert.equal(l.find((x) => x.id === b).archived, true);
  t += 100_000; sent.length = 0; c.post(boss, a, { text: 'muted for an hour' }); assert.equal(sent.includes(ali.uid), false);
  t += 3_700_000; c.post(boss, a, { text: 'after the hour' }); assert.equal(sent.includes(ali.uid), true);
  sent.length = 0; t += 120_000; c.post(boss, b, { text: 'quiet one https://example.com', silent: true }); assert.equal(sent.length, 0, 'silent sends no notice');
  assert.equal(c.searchAll(ali, 'hour').results.length, 2);
  assert.equal(c.sharedMedia(ali, b, 'link').items[0].link, 'https://example.com');
  const m = c.post(boss, a, { text: 'hide me' }).message; c.hideForMe(ali, a, m.id);
  assert.ok(!c.read(ali, a).messages.some((x) => x.id === m.id)); assert.ok(c.read(boss, a).messages.some((x) => x.id === m.id), 'only hidden for me');
  c.markRead(ali, a, c.read(ali, a).rev); assert.deepEqual(c.readers(boss, a, m.id).readers.map((x) => x.name), ['Ali']);
  assert.equal(c.readers(ali, a, m.id).error, 'forbidden');
  assert.equal(c.schedule(ali, a, { text: 'x', at: t + 1000 }).error, 'bad_time');
  assert.equal(c.schedule(ali, a, { text: 'good morning', at: t + 3600_000 }).scheduled.length, 1);
  c.runScheduled(); assert.ok(!c.read(boss, a).messages.some((x) => x.text === 'good morning'));
  t += 3600_001; c.runScheduled(); assert.ok(c.read(boss, a).messages.some((x) => x.text === 'good morning' && x.uid === ali.uid));
  const dm = c.openDm(ali, { uid: boss.uid }).channel.id; assert.ok(c.callAct(ali, dm, { action: 'start' }).id || c.callAct(ali, dm, { action: 'start' }).call, 'either side starts a call in a direct chat');
});

/* ── v361: secret chats ── */
test('v361 secret chats carry only ciphertext and never swap keys', async () => {
  const { c } = setup2();
  const g = c.create(boss, { name: 'Group' }).channel.id; c.addMember(boss, g, { email: 'ali@site.test' });
  const { webcrypto } = await import('node:crypto');
  const mk = async () => Buffer.from(await webcrypto.subtle.exportKey('raw', (await webcrypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveKey'])).publicKey)).toString('base64');
  const pa = await mk(); const pb = await mk();
  assert.equal(c.openSecret(ali, { uid: boss.uid, pub: 'short' }).error, 'bad_key');
  const s = c.openSecret(ali, { uid: boss.uid, pub: pa }).channel; assert.equal(s.type, 'secret'); assert.equal(s.secret.ready, false);
  assert.equal(c.post(ali, s.id, { enc: { iv: 'aaaaaaaaaaaaaaaa', ct: 'bbbbbbbbbbbbbbbb' } }).error, 'secret_pending');
  c.acceptSecret(boss, s.id, { pub: pb }); assert.equal(c.acceptSecret(boss, s.id, { pub: pa }).error, 'already_set', 'no silent key swap');
  assert.equal(c.post(ali, s.id, { text: 'plain text leak' }).error, 'bad_request', 'plain text is refused in a secret chat');
  const m = c.post(ali, s.id, { enc: { iv: 'aaaaaaaaaaaaaaaa', ct: 'Y2lwaGVydGV4dA==' } }).message; assert.equal(m.text, ''); assert.equal(m.enc.ct, 'Y2lwaGVydGV4dA==');
  assert.equal(c.searchAll(ali, 'cipher').results.length, 0);
  assert.equal(c.forward(ali, s.id, m.id, { to: g }).error, 'secret_no_forward');
  assert.equal(c.read(eve, s.id).error, 'not_found');
});

/* ── v362 ── */
test('v362 folders keep only my chats; devices can be signed out', () => {
  const { c } = setup2();
  const g = c.create(boss, { name: 'Group' }).channel.id; const other = c.create(boss, { name: 'Other' }).channel.id; c.addMember(boss, g, { email: 'ali@site.test' });
  const f = c.setFolders(ali, { folders: [{ name: 'Work', emoji: '💼', chats: [g, other, 'cnope'], unread: true }] }).folders[0];
  assert.deepEqual(f.chats, [g], 'a chat I am not in never lands in my folder'); assert.equal(f.emoji, '💼');
  const a1 = { ...ali, authTime: 1000 }; const a2 = { ...ali, authTime: 2000 }; const a3 = { ...ali, authTime: 3000 };
  c.seeDevice(a1, { id: 'd' + '1'.repeat(16), ua: 'Phone' }); c.seeDevice(a2, { id: 'd' + '2'.repeat(16), ua: 'Laptop' }); c.seeDevice(a3, { id: 'd' + '3'.repeat(16), ua: 'Tablet' });
  assert.equal(c.devices(a1).devices.length, 3);
  c.signOutDevices(a3, { id: 'd' + '2'.repeat(16), current: 'd' + '3'.repeat(16) });
  assert.equal(c.revoked(ali.uid, 2000), true); assert.equal(c.revoked(ali.uid, 1000), false);
  c.signOutDevices(a3, { all: true, current: 'd' + '3'.repeat(16) });
  assert.equal(c.revoked(ali.uid, 1000), true); assert.equal(c.revoked(ali.uid, 3000), true, 'v368: everywhere means this device too (a stolen copy has the same sign-in time)');
});

test('v362 bots: commands, welcome, API limited to their groups', async () => {
  const { c } = setup2();
  assert.equal(c.makeBot(ali, { name: 'Helper', username: 'helperbot' }).error, 'forbidden', 'only owners and approved moderators make bots');
  assert.equal(c.makeBot(boss, { name: 'Helper', username: 'helper' }).error, 'bad_bot_username');
  const { bot } = c.makeBot(boss, { name: 'Helper', username: 'helperbot' }); assert.ok(bot.token);
  c.editBot(boss, bot.id, { welcome: 'Welcome {name}!', commands: [{ cmd: '/rules', reply: 'Be kind.' }] });
  const g = c.create(boss, { name: 'Club' }).channel.id; c.addBot(boss, g, { username: '@helperbot' });
  c.addMember(boss, g, { email: 'ali@site.test' }); await new Promise((r) => setTimeout(r, 5));
  assert.ok(c.read(ali, g).messages.some((m) => m.text === 'Welcome Ali!' && m.bot));
  c.post(ali, g, { text: '/rules' }); await new Promise((r) => setTimeout(r, 5));
  assert.ok(c.read(ali, g).messages.some((m) => m.text === 'Be kind.'));
  assert.equal(c.botMe('x'.repeat(30)).error, 'unauthorized');
  const up = c.botUpdates(bot.token, 0); assert.ok(up.updates.some((x) => x.message.text === '/rules'));
  assert.ok(c.botSend(bot.token, { chat: g, text: 'hello from the API' }).message);
  const dm = c.openDm(ali, { uid: boss.uid }).channel.id; assert.equal(c.botSend(bot.token, { chat: dm, text: 'x' }).error, 'not_found', 'never in private chats');
  const t2 = c.editBot(boss, bot.id, { newToken: true }).bot.token; assert.equal(c.botMe(bot.token).error, 'unauthorized', 'the old token stops'); assert.equal(c.botMe(t2).username, 'helperbot');
});

/* ── v363 ── */
test('v363 big calls are off without LiveKit, and tokens are one-room HS256', () => {
  const { c } = setup2(); const g = c.create(boss, { name: 'Big' }).channel.id; c.addMember(boss, g, { email: 'ali@site.test' });
  assert.equal(c.bigCall(boss, g, { action: 'start' }).error, 'big_off');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-'));
  const c2 = createChatChannels({ dir, secret: SECRET, env: { NODE_ENV: 'test', LIVEKIT_URL: 'wss://demo.livekit.cloud', LIVEKIT_API_KEY: 'APIkey', LIVEKIT_API_SECRET: 's'.repeat(32) }, isOwnerEmail: (u) => u?.email === 'boss@site.test', findMember: (e) => people.find((p) => p.email === e) || null });
  const g2 = c2.create(boss, { name: 'Big' }).channel.id; c2.addMember(boss, g2, { email: 'ali@site.test' });
  assert.equal(c2.bigCall(ali, g2, { action: 'start' }).error, 'forbidden'); assert.equal(c2.bigCall(ali, g2, {}).error, 'no_call');
  const r = c2.bigCall(boss, g2, { action: 'start' }); assert.ok(r.url.startsWith('https://meet.livekit.io/custom?liveKitUrl=wss'));
  const [h, b, sig] = c2.bigCall(ali, g2, {}).token.split('.');
  assert.equal(sig, crypto2.createHmac('sha256', 's'.repeat(32)).update(`${h}.${b}`).digest('base64url'));
  const claims = JSON.parse(Buffer.from(b, 'base64url').toString()); assert.equal(claims.sub, ali.uid); assert.equal(claims.video.room, r.room); assert.ok(claims.exp - claims.nbf <= 7210);
  assert.equal(c2.bigCall(eve, g2, {}).error, 'not_found');
});

test('v363 review fixes: limited admins cannot mint admins, forwards check first and count bytes, no plaintext schedule in secret chats', async () => {
  const { c } = setup2();
  const g = c.create(boss, { name: 'Grp' }).channel.id; c.addMember(boss, g, { email: 'ali@site.test' });
  c.setRole(boss, g, ali.uid, { role: 'admin', perms: { ban: false, members: true } });
  c.addMember(ali, g, { email: 'eve@site.test', role: 'admin' });
  assert.equal(c.members(boss, g).members.find((x) => x.uid === eve.uid).role, 'member', 'a limited admin adds members only as members');
  const bc = c.create(boss, { name: 'News', type: 'channel' }).channel.id; c.addMember(boss, bc, { email: 'eve@site.test' });
  const sv = c.openSaved(eve).channel.id; const up = c.upload(eve, sv, PNG9); c.post(eve, sv, { media: up.media });
  const m = c.read(eve, sv).messages.at(-1);
  const before = fs.readdirSync(path.join(c.__dir || '.', '.')).length;
  assert.equal(c.forward(eve, sv, m.id, { to: bc }).error, 'admins_only', 'refused before any copy is written');
  const { webcrypto } = await import('node:crypto');
  const pub = Buffer.from(await webcrypto.subtle.exportKey('raw', (await webcrypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveKey'])).publicKey)).toString('base64');
  const s = c.openSecret(ali, { uid: boss.uid, pub }).channel.id;
  assert.equal(c.schedule(ali, s, { text: 'TOP SECRET', at: Date.now() + 3600_000 }).error, 'bad_request');
  void before;
});

/* ── v364 ── */
test('v364 comments under channel posts, persistent quota, link-preview address guard', async () => {
  const { c } = setup2();
  const ch = c.create(boss, { name: 'News', type: 'channel' }).channel.id; c.addMember(boss, ch, { email: 'ali@site.test' });
  const post = c.post(boss, ch, { text: 'Big update today' }).message;
  assert.equal(c.post(ali, ch, { text: 'hi' }).error, 'admins_only');
  const r = c.addComment(ali, ch, post.id, { text: 'Great news!' }); assert.equal(r.comments.length, 1);
  assert.equal(c.read(ali, ch).messages.find((x) => x.id === post.id).comments, 1);
  assert.equal(c.delComment(eve, ch, post.id, r.comments[0].id).error, 'not_found', 'outsiders see nothing');
  c.delComment(boss, ch, post.id, r.comments[0].id); assert.equal(c.comments(ali, ch, post.id).comments.length, 0);
  for (const ip of ['127.0.0.1', '10.1.2.3', '169.254.169.254', '192.168.1.1', '172.20.0.1', '::1', 'fd00::1', '::ffff:127.0.0.1', '100.64.0.1']) assert.equal(c.privateIp(ip), true, ip);
  for (const ip of ['8.8.8.8', '1.1.1.1', '2606:4700::1111']) assert.equal(c.privateIp(ip), false, ip);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-'));
  const c2 = createChatChannels({ dir, secret: SECRET, env: { NODE_ENV: 'test', __testLookup: (h, o, cb) => cb(null, [{ address: '127.0.0.1', family: 4 }]) }, isOwnerEmail: (u) => u?.email === 'boss@site.test', findMember: () => null });
  const v = await c2.preview(ali, 'http://evil.example/'); assert.equal(v.title, '', 'a name that points inside is never fetched');
  assert.equal((await c2.preview(ali, 'file:///etc/passwd')).error, 'bad_request');
});
