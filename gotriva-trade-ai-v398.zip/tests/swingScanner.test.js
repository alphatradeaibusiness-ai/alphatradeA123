import test from 'node:test';
import assert from 'node:assert/strict';
import { createSwingScanner } from '../src/services/swingScanner.js';

test('swing scanner: real-data only, own state, market states kept, rates for the lot conversion, tracking on live quotes', async () => {
  const NOW = Date.UTC(2026, 10, 16, 12, 0, 30);
  let seed = 3; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const series = (sec, n, p0) => { const end = Math.floor(NOW / 1000 / sec) * sec; let p = p0; return Array.from({ length: n }, (_, i) => { const o = p; p += (rnd() - 0.48) * p0 * 0.003; return { time: end - (n - i) * sec, open: o, high: Math.max(o, p) * 1.001, low: Math.min(o, p) * 0.999, close: p, volume: 100 }; }); };
  const calls = []; const saved = [];
  const deps = {
    getHistory: async (sym, tf, n) => { calls.push(`${sym}:${tf}`); if (sym === 'XAGUSD') return { mode: 'demo', candles: [] }; const sec = { '1m': 60, '1h': 3600, '4h': 14400, '1D': 86400 }[tf]; return { mode: 'live', source: 'test', candles: series(sec, n, sym === 'EURUSD' ? 1.1 : 4000) }; },
    quotes: async (syms) => Object.fromEntries(syms.map((s) => [s, { price: s === 'USDJPY' ? 150 : s === 'EURUSD' ? 1.1 : 4000, at: NOW }])),
    prefetchHtf: async () => {}, htfCandles: () => null, calendar: async () => ({ events: [], at: NOW }),
  };
  const sc = createSwingScanner({ deps, store: { load: () => null, save: (st) => saved.push(JSON.parse(JSON.stringify(st))) }, markets: [{ id: 'EURUSD', name: 'EURUSD', symbol: 'EURUSD', cat: 'forex' }, { id: 'XAGUSD', name: 'XAGUSD', symbol: 'XAGUSD', cat: 'metal' }], now: () => NOW, log: {} });
  await sc.scanOnce();
  const st = sc.state();
  assert.equal(st.markets.XAGUSD.state, 'unavailable'); assert.equal(st.markets.XAGUSD.reason, 'demo_data');
  assert.ok(['live', 'closed', 'stale', 'insufficient'].includes(st.markets.EURUSD.state), st.markets.EURUSD.state);
  assert.equal(st.rates.USDJPY, 150, 'live rates kept for the lot conversion');
  assert.ok(!calls.some((c) => /:(1m|5m|15m)$/.test(c)), 'no lower timeframe is ever analysed');
  assert.deepEqual([...new Set(calls.map((c) => c.split(':')[1]))].sort(), ['1D', '1h', '4h']);
  const n = calls.length; await sc.scanOnce(); assert.equal(calls.length, n, 'each closed candle is evaluated once');
  for (const s of st.signals) assert.ok(['1h', '4h', '1D'].includes(s.tf));
  st.signals.push({ id: 'manual', symbol: 'EURUSD', tf: '4h', direction: 'buy', entryType: 'market', status: 'active', entry: 1.09, stop: 1.08, initialStop: 1.08, targets: [1.095, 1.1, 1.2], rr: [0.5, 1, 11], createdAt: NOW - 600_000, filledAt: NOW - 600_000, hits: 0, pip: 0.0001, maxHoldUntil: NOW + 1e9 });
  const ev = await sc.trackOnce();
  assert.ok(ev.some((e) => e.signal.id === 'manual' && e.status === 'tp1'), JSON.stringify(ev.map((e) => e.status)));
  assert.ok(saved.length >= 3);
});
