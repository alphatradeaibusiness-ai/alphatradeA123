import test from 'node:test';
import assert from 'node:assert/strict';
import { createPaypal } from '../server/bank/paypal.js';

test('PayPal client: off without keys; order → approve link; capture reports payer, amount and capture id', async () => {
  assert.equal(createPaypal({ env: {} }), null);
  const calls = [];
  const fetchImpl = async (url, o) => {
    calls.push([url, o.headers['PayPal-Request-Id'] || '']);
    const J = (b, ok = true) => ({ ok, status: ok ? 200 : 422, json: async () => b });
    if (url.endsWith('/v1/oauth2/token')) return J({ access_token: 'T', expires_in: 3600 });
    if (url.endsWith('/v2/checkout/orders')) { const b = JSON.parse(o.body); assert.equal(b.purchase_units[0].amount.value, '25.00'); assert.equal(b.purchase_units[0].custom_id, 'u1'); return J({ id: 'ORDER12345', links: [{ rel: 'payer-action', href: 'https://pp.test/approve' }] }); }
    if (url.endsWith('/capture')) return J({ status: 'COMPLETED', purchase_units: [{ payments: { captures: [{ id: 'CAPTURE12345', status: 'COMPLETED', custom_id: 'u1', amount: { currency_code: 'USD', value: '25.00' } }] } }] });
    return J({}, false);
  };
  const pp = createPaypal({ env: { PAYPAL_CLIENT_ID: 'id', PAYPAL_CLIENT_SECRET: 's' }, fetchImpl, base: 'https://pp.test' });
  assert.equal(pp.mode, 'sandbox');
  assert.deepEqual(await pp.order({ uid: 'u1', cents: 2500, origin: 'https://site.test' }), { orderId: 'ORDER12345', approveUrl: 'https://pp.test/approve' });
  assert.deepEqual(await pp.capture('ORDER12345'), { uid: 'u1', cents: 2500, captureId: 'CAPTURE12345' });
  assert.equal(calls.filter(([u]) => u.endsWith('/token')).length, 1, 'token reused');
  assert.equal(calls.find(([u]) => u.endsWith('/capture'))[1], 'cap-ORDER12345', 'capture is idempotent at PayPal');
  await assert.rejects(pp.capture('bad id'), { code: 'bad_order' });
});
