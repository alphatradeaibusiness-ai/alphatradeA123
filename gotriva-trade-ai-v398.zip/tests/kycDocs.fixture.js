// v379 test photos for the account-opening check: a tiny valid JPEG header padded to the minimum size.
const jpeg = () => `data:image/jpeg;base64,${Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(3000, 7)]).toString('base64')}`;
export const TEST_DOCS = { front: jpeg(), selfie: jpeg() };
export const TEST_PHONE = '+491701234567';
