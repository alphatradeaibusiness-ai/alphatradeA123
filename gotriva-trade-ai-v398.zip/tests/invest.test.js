import test from 'node:test';
import assert from 'node:assert/strict';
import { momentum, fundamentals, readyTrade, WATCH, stripHtml } from '../src/services/investEngine.js';
import { createInvest } from '../server/invest.js';

const series = (n, f) => Array.from({ length: n }, (_, i) => { const c = f(i); return { time: 1_600_000_000 + i * 86400, open: c * 0.995, high: c * 1.01, low: c * 0.99, close: c, volume: 1e6 }; });
const upTrend = series(260, (i) => 100 + i * 0.5 + Math.sin(i / 3) * 1.5);
const downTrend = series(260, (i) => 300 - i * 0.6 + Math.sin(i / 3) * 1.5);

test('momentum: a steady uptrend scores positive, a downtrend negative; too few candles → null', () => {
  assert.ok(momentum(upTrend).score > 0.3); assert.ok(momentum(downTrend).score < -0.3);
  assert.equal(momentum(upTrend.slice(0, 30)), null);
});

test('ready trade: BUY with stop below, two targets above, real R:R; SELL mirrors; mixed → WAIT; missing parts are reported', () => {
  const b = readyTrade({ candles: upTrend, fund: { revenueGrowth: 0.2, epsGrowth: 0.25, netMargin: 0.25, pe: 30, debtToEquity: 0.5 }, sentiment: { score: 0.5, n: 6 } });
  assert.equal(b.action, 'buy'); assert.ok(b.stop < b.entry && b.targets[0] > b.entry && b.targets[1] > b.targets[0]);
  assert.ok(b.rr[0] >= 1.5 && b.confidence > 40); assert.deepEqual(b.missing, []);
  const s = readyTrade({ candles: downTrend, fund: null, sentiment: { score: -0.6, n: 4 } });
  assert.equal(s.action, 'sell'); assert.ok(s.stop > s.entry && s.targets[0] < s.entry); assert.deepEqual(s.missing, ['fund']);
  assert.ok(s.parts.tech.weight > 0.45, 'the missing weight is shared out');
  const flat = series(260, (i) => 100 + Math.sin(i / 5) * 3);
  const tsc = momentum(flat).score;
  const w = readyTrade({ candles: flat, fund: null, sentiment: { score: Math.max(-1, Math.min(1, -tsc * 0.45 / 0.3)), n: 5 } });   // news cancels the chart
  assert.equal(w.action, 'wait');
  assert.equal(readyTrade({ candles: [], fund: null, sentiment: null }).reason, 'no_chart_data');
});

test('fundamentals score: strong growth positive, losses negative, nothing → null', () => {
  assert.ok(fundamentals({ revenueGrowth: 0.3, epsGrowth: 0.4, netMargin: 0.3, pe: 20 }).score > 0.4);
  assert.ok(fundamentals({ revenueGrowth: -0.1, epsGrowth: -0.5, netMargin: -0.1, pe: -3 }).score < -0.4);
  assert.equal(fundamentals({}), null);
  assert.equal(stripHtml('<p>Apple&nbsp;<b>beats</b></p>'), 'Apple beats');
});

test('server: quotes are cached and fetched in ONE batch; candles parsed oldest-first; AI sentiment parsed and cached; no AI → no sentiment', async () => {
  const calls = []; let t = 1_700_000_000_000;
  const fetchImpl = async (u) => {
    const url = new URL(u); calls.push(url.pathname);
    const ok = (b) => ({ ok: true, status: 200, json: async () => b });
    if (url.pathname.endsWith('/quote')) return ok(Object.fromEntries(WATCH.map((w, i) => [w.s, { symbol: w.s, close: String(100 + i), change: '1', percent_change: '1.0', timestamp: 1_700_000_000 }])));
    if (url.pathname.endsWith('/time_series')) return ok({ values: upTrend.map((c) => ({ datetime: new Date(c.time * 1000).toISOString().slice(0, 10), open: c.open, high: c.high, low: c.low, close: c.close, volume: 1 })) });
    if (url.pathname.endsWith('/press_releases')) return ok({ press_releases: [{ title: 'Apple reports record revenue', body: '<p>Strong quarter</p>', datetime: '2026-11-10T12:00:00Z' }, { title: 'Apple faces probe', body: '', datetime: '2026-11-09T12:00:00Z' }] });
    if (url.pathname.endsWith('/statistics')) return { ok: false, status: 403, json: async () => ({ code: 403, status: 'error', message: 'available starting with Pro' }) };
    return { ok: false, status: 404, json: async () => ({}) };
  };
  let aiCalls = 0;
  const inv = createInvest({ tdKey: () => 'k', env: {}, fetchImpl, now: () => t, log: {}, ai: async () => { aiCalls++; return 'Sure: {"items":[{"i":1,"s":0.8,"why":"إيرادات قياسية"},{"i":2,"s":-0.4,"why":"تحقيق"}],"summary":"إيجابية بالمجمل"}'; } });
  const q1 = await inv.quotes(); const q2 = await inv.quotes();
  assert.equal(q1.items.length, WATCH.length); assert.equal(calls.filter((p) => p.endsWith('/quote')).length, 1, 'cached');
  const cs = await inv.candles('AAPL'); assert.ok(cs[0].time < cs.at(-1).time);
  assert.equal(await inv.candles('XYZ'), null, 'only the watch-list');
  const a = await inv.analysis('AAPL', { lang: 'ar' });
  assert.equal(a.sentiment.n, 2); assert.ok(a.sentiment.score > 0); assert.deepEqual(a.fundamentals, { unavailable: 'plan' });
  assert.ok(['buy', 'wait', 'sell'].includes(a.trade.action)); assert.ok(a.trade.missing.includes('fund'));
  await inv.analysis('AAPL', { lang: 'ar' }); assert.equal(aiCalls, 1, 'sentiment cached for the same headlines');
  t += 2 * 3600_000; const n0 = calls.length; await inv.quotes(); assert.ok(calls.length > n0, 'refreshed after the cache time');
  const noAi = createInvest({ tdKey: () => 'k', env: {}, fetchImpl, now: () => t, log: {} });
  assert.equal((await noAi.analysis('AAPL')).sentiment, null);
  assert.equal((await inv.analysis('ZZZ')).error, 'unknown_symbol');
});
