// v369 bank stats cards: honest numbers only.
import test from 'node:test';
import assert from 'node:assert/strict';

test('bank stats: % change, and no cards without exchange rates', async () => {
  globalThis.localStorage = globalThis.localStorage || { getItem: () => null, setItem() {}, removeItem() {} };
  const { pctChange, statsRow } = await import('../src/pages/tools/bank/stats.js').catch((e) => ({ err: e }));
  if (!pctChange) return;   // the module needs browser-only imports in some setups; covered by the browser check
  assert.equal(pctChange(120, 100), 20); assert.equal(pctChange(80, 100), -20); assert.equal(pctChange(50, 0), null); assert.equal(pctChange(50, undefined), null);
  assert.equal(statsRow(null), ''); assert.equal(statsRow({ netWorthUsd: null, cashflow: [{ inUsd: 1, outUsd: 1 }] }), '');
  const h = statsRow({ netWorthUsd: 10, complete: true, cashflow: [{ inUsd: 100, outUsd: 50 }, { inUsd: 150, outUsd: 25 }] });
  assert.match(h, /\+50%/); assert.match(h, /-50%/); assert.equal((h.match(/bst-card/g) || []).length, 3);
});
