import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { createBankLogin, strongEnough } from '../server/bank/login.js';

const mk = () => { let t = 1_700_000_000_000; const L = createBankLogin({ db: new DatabaseSync(':memory:'), secret: 'x'.repeat(40), now: () => t }); return { L, adv: (ms) => { t += ms; } }; };

test('approval credentials: temporary password only opens «set your own», then the own password opens the bank', () => {
  const { L } = mk();
  assert.equal(L.allowed('u1', ''), true, 'no bank login yet (older accounts): not asked');
  const { username, password } = L.issue('u1');
  assert.match(username, /^GT-\d{5}$/); assert.match(password, /^\w{3}-\w{4}-\w{4}$/);
  assert.deepEqual(L.state('u1'), { required: true, username, mustChange: true });
  assert.equal(L.allowed('u1', ''), false);
  const r = L.login('u1', username.toLowerCase(), password); assert.ok(r.change && !r.token, 'temp → change ticket only');
  assert.equal(L.allowed('u1', r.change), false, 'a change ticket is not a bank session');
  assert.throws(() => L.setPassword('u1', r.change, 'short1A'), { code: 'weak_password' });
  const s = L.setPassword('u1', r.change, 'Strong-Pass-2026'); assert.equal(L.allowed('u1', s.token), true);
  assert.equal(L.state('u1').mustChange, false);
  assert.throws(() => L.login('u1', username, password), { code: 'bad_login' }, 'the temporary password is dead');
  assert.ok(L.login('u1', username, 'Strong-Pass-2026').token);
  assert.equal(L.allowed('u2', s.token), true, 'u2 has no login'); L.issue('u2'); assert.equal(L.allowed('u2', s.token), false, 'a token never opens someone else');
});

test('temporary password expires after 24 h; 5 wrong tries lock for 15 min; a reset kills old sessions', () => {
  const { L, adv } = mk();
  const a = L.issue('u1'); adv(24 * 3600_000 + 1); assert.throws(() => L.login('u1', a.username, a.password), { code: 'temp_expired' });
  const b = L.issue('u1'); assert.equal(b.username, a.username, 'username stays');
  for (let i = 0; i < 4; i++) assert.throws(() => L.login('u1', b.username, 'nope'), { code: 'bad_login' });
  assert.throws(() => L.login('u1', b.username, 'nope'), { code: 'login_locked' });
  assert.throws(() => L.login('u1', b.username, b.password), { code: 'login_locked' }, 'even the right one waits');
  adv(15 * 60_000 + 1);
  const { token } = L.setPassword('u1', L.login('u1', b.username, b.password).change, 'Another-Good-1');
  assert.equal(L.allowed('u1', token), true); L.issue('u1'); assert.equal(L.allowed('u1', token), false, 'reset ends the old session');
  assert.equal(strongEnough('abcdefghij'), false); assert.equal(strongEnough('Abcdefghi1'), true);
});

test('v383 fingerprint session only after the own password is set; new-device alert skips the first device', () => {
  const { L } = mk(); const c = L.issue('u1');
  assert.throws(() => L.sessionFor('u1'), { code: 'set_password_first' });
  L.setPassword('u1', L.login('u1', c.username, c.password).change, 'Strong-Pass-2026');
  assert.equal(L.allowed('u1', L.sessionFor('u1').token), true);
  assert.equal(L.newDevice('u1', 'iPhone Safari', '10.0.0.7'), false, 'first device: no alert');
  assert.equal(L.newDevice('u1', 'iPhone Safari', '10.0.0.9'), false, 'same device, same network');
  assert.equal(L.newDevice('u1', 'Windows Chrome', '82.1.2.3'), true, 'a new device → alert');
  assert.equal(L.newDevice('u1', 'Windows Chrome', '82.1.2.3'), false, 'only once');
});
