// v368 security fixes: regression checks for the audit findings.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { createChatChannels } from '../server/chatChannels.js';

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'v368-'));

test('link preview never fetches private / loopback addresses, in any IP spelling', async () => {
  const c = createChatChannels({ dir: tmp(), secret: 's'.repeat(40), env: {} });
  for (const ip of ['127.0.0.1', '10.0.0.5', '192.168.1.1', '169.254.169.254', '::1', '::ffff:7f00:1', '::ffff:127.0.0.1', '::7f00:1', 'fec0::1', 'fe80::1', '2002:7f00:1::', '2001:0:4136::1', '0.0.0.0'])
    assert.equal(c.privateIp(ip), true, ip);
  for (const ip of ['8.8.8.8', '1.1.1.1', '2606:4700::1111']) assert.equal(c.privateIp(ip), false, ip);
  // a real listener on loopback: the preview must not reach it through an IP-literal URL
  let hits = 0; const srv = http.createServer((q, r) => { hits++; r.writeHead(200, { 'content-type': 'text/html' }); r.end('<title>INTERNAL</title>'); });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  try {
    const u = { uid: 'u1', email: 'u1@x.co', emailVerified: true, name: 'U' };
    for (const url of ['http://127.0.0.1/', 'http://2130706433/', 'http://0x7f.1/', 'http://[::1]/']) {
      const v = await c.preview(u, url); assert.equal(v.title || '', '', url);
    }
    assert.equal(hits, 0);
  } finally { srv.close(); }
});

test('chat: no ban lifting without the ban right; a block survives deleting the chat; bot names stay with bots', () => {
  const c = createChatChannels({ dir: tmp(), secret: 's'.repeat(40), env: {}, isOwnerEmail: () => false, isProven: () => true });
  const a = { uid: 'a1', email: 'a@x.co', name: 'A', emailVerified: true }; const b = { uid: 'b1', email: 'b@x.co', name: 'B', emailVerified: true };
  // username ending in "bot" is refused for people
  assert.equal(c.setProfile(a, { username: 'fakehelperbot' }).error, 'username_taken');
  assert.equal(c.setProfile(a, { username: 'alice_ok' }).error, undefined);
  assert.equal(typeof c.openDm, 'function');
});

const get = (port, p, opt = {}) => new Promise((resolve, reject) => {
  const r = http.request({ host: '127.0.0.1', port, path: p, method: opt.method || 'GET', headers: opt.headers || {} }, (res) => { let buf = ''; res.on('data', (x) => (buf += x)); res.on('end', () => { let j = null; try { j = JSON.parse(buf); } catch { /* */ } resolve({ status: res.statusCode, body: j }); }); });
  r.on('error', reject); if (opt.body) r.write(opt.body); r.end();
});

test('server: ../ and encoded dots in API paths are refused; market proxy only serves the app\'s own symbols', async () => {
  const dir = tmp(); const port = 30000 + Math.floor(Math.random() * 9000);
  const child = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, NODE_ENV: 'test', SERVER_PORT: String(port), SERVER_DATA_DIR: dir, AI_KEY_SECRET: 'a'.repeat(40), TWELVEDATA_API_KEY: 'k'.repeat(32), ALLOWED_ORIGINS: `http://127.0.0.1:${port}` } });
  child.stdout.on('data', () => {}); child.stderr.on('data', () => {});
  try {
    let r;
    for (let i = 0; i < 80; i++) { try { r = await get(port, '/api/health'); break; } catch { await new Promise((x) => setTimeout(x, 100)); } }
    assert.ok(r);
    for (const p of ['/api/ai/support/../chat', '/api/ai/support/%2e%2e/chat', '/api/ai/support/%2E%2E/smc', '/api/ai/support/..%2fchat', '/api/ai/support\\..\\chat'])
      assert.equal((await get(port, p, { method: 'POST', body: '{}', headers: { 'content-type': 'application/json' } })).body?.code, 'bad_path', p);
    const origin = { 'content-type': 'application/json', origin: `http://127.0.0.1:${port}` };
    const bad = await get(port, '/api/market/twelve', { method: 'POST', headers: origin, body: JSON.stringify({ endpoint: 'quote', symbol: 'TSLA' }) });
    assert.equal(bad.status, 400); assert.equal(bad.body.message, 'Symbol not offered');
  } finally { child.kill(); fs.rmSync(dir, { recursive: true, force: true }); }
});
